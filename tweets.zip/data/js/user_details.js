var user_details =  {
  "expanded_url" : "http://busterbenson.com",
  "screen_name" : "buster",
  "location" : "Berkeley, CA",
  "url" : "http://t.co/JghZ8d7hCO",
  "full_name" : "Buster",
  "bio" : "Helping build things at @Twitter. Soul in the game. Tell me how to tweet here: http://t.co/ymBGP7vtOs See results here: http://t.co/gLPyw54OlB",
  "id" : "2185",
  "created_at" : "2006-07-18 04:35:07 +0000",
  "display_url" : "busterbenson.com"
}