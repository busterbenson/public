var user_details =  {
  "expanded_url" : "http://wayoftheduck.com",
  "screen_name" : "buster",
  "location" : "Newly in SF",
  "url" : "http://t.co/nEb6UnFCgE",
  "full_name" : "Buster",
  "bio" : "Helping build things at @Twitter, aspiring marathoner. http://t.co/kO4I77Bqss",
  "id" : "2185",
  "created_at" : "Tue Jul 18 04:35:07 +0000 2006",
  "display_url" : "wayoftheduck.com"
}