var user_details =  {
  "expanded_url" : "http://wayoftheduck.com",
  "screen_name" : "busterbenson",
  "location" : "Seattle and SF",
  "url" : "http://t.co/bBJaraQw",
  "full_name" : "Buster Benson",
  "bio" : "Helping build @Twitter. Amateur behavior change fanatic. \r\n\r\n[http://t.co/d4uyNcrn, @peabrain, http://t.co/UXCU3B0z, @healthmonth, @bestofbuster, etc]",
  "id" : "2185",
  "created_at" : "Tue Jul 18 04:35:07 +0000 2006",
  "display_url" : "wayoftheduck.com"
}