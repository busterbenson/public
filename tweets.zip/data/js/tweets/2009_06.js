Grailbird.data.tweets_2009_06 = 
 [ {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2414903220",
  "text" : "8:36pm Looking to free Bastille's bar of a few glasses of wine http://flic.kr/p/6AYpp3",
  "id" : 2414903220,
  "created_at" : "Wed Jul 01 03:42:07 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2414700815",
  "text" : "Already out of seats for the night, but the bar's open! (@ Bastille Cafe & Bar in Seattle) http://bit.ly/116NVm",
  "id" : 2414700815,
  "created_at" : "Wed Jul 01 03:26:02 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2414683386",
  "text" : "Already out of seats for the night, but the bar's open!",
  "id" : 2414683386,
  "created_at" : "Wed Jul 01 03:24:39 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Small and Special",
      "screen_name" : "smallandspecial",
      "indices" : [ 27, 43 ],
      "id_str" : "24454827",
      "id" : 24454827
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SandS",
      "indices" : [ 134, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2414494058",
  "text" : "Got two great ideas out of @smallandspecial which I'll explore more tomorrow. One request for the next one: a few \"special failures\". #SandS",
  "id" : 2414494058,
  "created_at" : "Wed Jul 01 03:10:02 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bastille Cafe & Bar",
      "screen_name" : "bastilleseattle",
      "indices" : [ 10, 26 ],
      "id_str" : "43743803",
      "id" : 43743803
    }, {
      "name" : "Small and Special",
      "screen_name" : "smallandspecial",
      "indices" : [ 45, 61 ],
      "id_str" : "24454827",
      "id" : 24454827
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2414455465",
  "text" : "Headed to @bastilleseattle now after the fun @smallandspecial conference. Who's coming?",
  "id" : 2414455465,
  "created_at" : "Wed Jul 01 03:07:00 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jimmy James Hall",
      "screen_name" : "JimmyJameson",
      "indices" : [ 0, 13 ],
      "id_str" : "35141809",
      "id" : 35141809
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "2408982661",
  "geo" : {
  },
  "id_str" : "2409566767",
  "in_reply_to_user_id" : 35141809,
  "text" : "@JimmyJameson I plan on improving it once I catch up on the reading!",
  "id" : 2409566767,
  "in_reply_to_status_id" : 2408982661,
  "created_at" : "Tue Jun 30 20:58:52 +0000 2009",
  "in_reply_to_screen_name" : "JimmyJameson",
  "in_reply_to_user_id_str" : "35141809",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SandS",
      "indices" : [ 133, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2408166314",
  "text" : "Headed on over to Georgetown Ballroom for the Small and Special conference. Excited about it! Anyone else going? http://bit.ly/OcfSe #SandS",
  "id" : 2408166314,
  "created_at" : "Tue Jun 30 19:18:09 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infsum",
      "indices" : [ 121, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2407850632",
  "text" : "Are you reading Infinite Jest this summer? Here's a quick spreadsheet I made to track your progress: http://bit.ly/gJrkE #infsum",
  "id" : 2407850632,
  "created_at" : "Tue Jun 30 18:55:52 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2398454798",
  "text" : "8:36pm Just found my new favorite coffee shop two blocks from my house http://flic.kr/p/6ABDpZ",
  "id" : 2398454798,
  "created_at" : "Tue Jun 30 03:39:32 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infsum",
      "indices" : [ 83, 90 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2398194165",
  "text" : "\"I am seated in an office, surrounded by heads and bodies.\" - Infinite Jest, pg. 1 #infsum Here I go!",
  "id" : 2398194165,
  "created_at" : "Tue Jun 30 03:19:09 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "josh",
      "screen_name" : "joshc",
      "indices" : [ 0, 6 ],
      "id_str" : "2015",
      "id" : 2015
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "2392872931",
  "geo" : {
  },
  "id_str" : "2392997084",
  "in_reply_to_user_id" : 2015,
  "text" : "@joshc Let us say that the storming begins around 8:30-9pm.",
  "id" : 2392997084,
  "in_reply_to_status_id" : 2392872931,
  "created_at" : "Mon Jun 29 20:37:20 +0000 2009",
  "in_reply_to_screen_name" : "joshc",
  "in_reply_to_user_id_str" : "2015",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bastille Cafe & Bar",
      "screen_name" : "bastilleseattle",
      "indices" : [ 35, 51 ],
      "id_str" : "43743803",
      "id" : 43743803
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2391859876",
  "text" : "Anyone wanna go tomorrow night? RT @bastilleseattle: http://twitpic.com/8s2r9 - Opening at 4:30pm tonight...",
  "id" : 2391859876,
  "created_at" : "Mon Jun 29 19:16:04 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charity Gourley",
      "screen_name" : "GourleyGirl",
      "indices" : [ 0, 12 ],
      "id_str" : "19945483",
      "id" : 19945483
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "2391216831",
  "geo" : {
  },
  "id_str" : "2391355493",
  "in_reply_to_user_id" : 19945483,
  "text" : "@GourleyGirl Thank you! Since I don't have a marketing budget, I gotta try to get the word out some other way. This was my first attempt! :)",
  "id" : 2391355493,
  "in_reply_to_status_id" : 2391216831,
  "created_at" : "Mon Jun 29 18:39:20 +0000 2009",
  "in_reply_to_screen_name" : "GourleyGirl",
  "in_reply_to_user_id_str" : "19945483",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Harrison",
      "screen_name" : "sourjayne",
      "indices" : [ 0, 10 ],
      "id_str" : "4981271",
      "id" : 4981271
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "2391073694",
  "geo" : {
  },
  "id_str" : "2391328358",
  "in_reply_to_user_id" : 4981271,
  "text" : "@sourjayne Thanks!  Did you see yours?",
  "id" : 2391328358,
  "in_reply_to_status_id" : 2391073694,
  "created_at" : "Mon Jun 29 18:37:19 +0000 2009",
  "in_reply_to_screen_name" : "sourjayne",
  "in_reply_to_user_id_str" : "4981271",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2391004491",
  "text" : "Here's the first set of pictures drawn for people who're writing about their local food adventures via Locavore: http://bit.ly/K7FMi",
  "id" : 2391004491,
  "created_at" : "Mon Jun 29 18:13:53 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Townsend",
      "screen_name" : "atownsend0824",
      "indices" : [ 0, 14 ],
      "id_str" : "18166976",
      "id" : 18166976
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "2390115505",
  "geo" : {
  },
  "id_str" : "2390207290",
  "in_reply_to_user_id" : 18166976,
  "text" : "@atownsend0824 Thanks! It was my second, but I got the same time last time. Now we're motivated to try the full next time--have you done it?",
  "id" : 2390207290,
  "in_reply_to_status_id" : 2390115505,
  "created_at" : "Mon Jun 29 17:15:31 +0000 2009",
  "in_reply_to_screen_name" : "atownsend0824",
  "in_reply_to_user_id_str" : "18166976",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Townsend",
      "screen_name" : "atownsend0824",
      "indices" : [ 0, 14 ],
      "id_str" : "18166976",
      "id" : 18166976
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "2386971718",
  "geo" : {
  },
  "id_str" : "2390074403",
  "in_reply_to_user_id" : 18166976,
  "text" : "@atownsend0824 Ran with a group and didn't do bad!  2:03, with lion ears, and drank a beer and three shots of vodka during the race!  :)",
  "id" : 2390074403,
  "in_reply_to_status_id" : 2386971718,
  "created_at" : "Mon Jun 29 17:05:32 +0000 2009",
  "in_reply_to_screen_name" : "atownsend0824",
  "in_reply_to_user_id_str" : "18166976",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2382438673",
  "text" : "8:36pm Working late on Locavore while listen to smooth jazz come from across the street http://flic.kr/p/6AiwpR",
  "id" : 2382438673,
  "created_at" : "Mon Jun 29 03:38:15 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2379396268",
  "text" : "Starting to crunch numbers for the first month of frugality. Looks like we cut spending by ~40%! A few more days to go though...",
  "id" : 2379396268,
  "created_at" : "Mon Jun 29 00:49:39 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2365560474",
  "text" : "Oops, I've got a headband tan.",
  "id" : 2365560474,
  "created_at" : "Sun Jun 28 00:28:30 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "matty dawsey",
      "screen_name" : "yeswad",
      "indices" : [ 0, 7 ],
      "id_str" : "24194411",
      "id" : 24194411
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "2363587730",
  "geo" : {
  },
  "id_str" : "2364789159",
  "in_reply_to_user_id" : 24194411,
  "text" : "@yeswad A little, but mostly just astonished how long days are when you wake up at 5:45am in Tukwila!",
  "id" : 2364789159,
  "in_reply_to_status_id" : 2363587730,
  "created_at" : "Sat Jun 27 23:12:09 +0000 2009",
  "in_reply_to_screen_name" : "yeswad",
  "in_reply_to_user_id_str" : "24194411",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2363455620",
  "text" : "It's only 2.",
  "id" : 2363455620,
  "created_at" : "Sat Jun 27 21:00:59 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Rainert",
      "screen_name" : "arainert",
      "indices" : [ 0, 9 ],
      "id_str" : "7482",
      "id" : 7482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "2362771332",
  "geo" : {
  },
  "id_str" : "2363041955",
  "in_reply_to_user_id" : 7482,
  "text" : "@arainert It was so much fun! Already talking about doing the full next!",
  "id" : 2363041955,
  "in_reply_to_status_id" : 2362771332,
  "created_at" : "Sat Jun 27 20:20:25 +0000 2009",
  "in_reply_to_screen_name" : "arainert",
  "in_reply_to_user_id_str" : "7482",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Rainert",
      "screen_name" : "arainert",
      "indices" : [ 0, 9 ],
      "id_str" : "7482",
      "id" : 7482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "2362140295",
  "geo" : {
  },
  "id_str" : "2362389974",
  "in_reply_to_user_id" : 7482,
  "text" : "@arainert Yes the first Seattle Rock and Roll marathon. We just did the half. It was plenty!",
  "id" : 2362389974,
  "in_reply_to_status_id" : 2362140295,
  "created_at" : "Sat Jun 27 19:18:08 +0000 2009",
  "in_reply_to_screen_name" : "arainert",
  "in_reply_to_user_id_str" : "7482",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2361435418",
  "text" : "Our \"after\" picture http://flic.kr/p/6zWNUG",
  "id" : 2361435418,
  "created_at" : "Sat Jun 27 17:49:36 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2361247562",
  "text" : "Finished 13.1mi in 2hrs 3mins. Exactly the same time as last time. But 3000 x more fun with the Krunking team! Now: burgers.",
  "id" : 2361247562,
  "created_at" : "Sat Jun 27 17:32:13 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2360969536",
  "text" : "We totally finished! And the fox got a bum paw http://flic.kr/p/6zWhYq",
  "id" : 2360969536,
  "created_at" : "Sat Jun 27 17:07:05 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2359139543",
  "text" : "Found the start line! http://flic.kr/p/6zUpeU",
  "id" : 2359139543,
  "created_at" : "Sat Jun 27 14:27:12 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2359014853",
  "text" : "We just realized we're walking 1.6 miles TO the starting line http://flic.kr/p/6zQ9zT",
  "id" : 2359014853,
  "created_at" : "Sat Jun 27 14:13:47 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2358639824",
  "text" : "What has 10 legs, 1 tail, one collective hangover, an Altrooist t-shirt, and an unflagging hunger for hamburgers?",
  "id" : 2358639824,
  "created_at" : "Sat Jun 27 13:28:28 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Townsend",
      "screen_name" : "atownsend0824",
      "indices" : [ 0, 14 ],
      "id_str" : "18166976",
      "id" : 18166976
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "2357883596",
  "geo" : {
  },
  "id_str" : "2358628456",
  "in_reply_to_user_id" : 18166976,
  "text" : "@atownsend0824 Thanks Alex!",
  "id" : 2358628456,
  "in_reply_to_status_id" : 2357883596,
  "created_at" : "Sat Jun 27 13:26:55 +0000 2009",
  "in_reply_to_screen_name" : "atownsend0824",
  "in_reply_to_user_id_str" : "18166976",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2355010963",
  "text" : "Elliot Bay Brewhouse sponsored us on the spot for run tomorrow! Last chance! http://krunkingnumbkits.com",
  "id" : 2355010963,
  "created_at" : "Sat Jun 27 04:24:33 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2354964503",
  "text" : "Our running/drinking goals for tomorrow http://flic.kr/p/6zPVEs",
  "id" : 2354964503,
  "created_at" : "Sat Jun 27 04:20:00 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2354538692",
  "text" : "8:36pm Checking in to an Econolodge in Tukwila. 6 people in one room style. http://flic.kr/p/6zKs4n",
  "id" : 2354538692,
  "created_at" : "Sat Jun 27 03:38:44 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "christopher jones",
      "screen_name" : "cjlikearockstar",
      "indices" : [ 0, 16 ],
      "id_str" : "34383091",
      "id" : 34383091
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2353959448",
  "in_reply_to_user_id" : 34383091,
  "text" : "@cjlikearockstar Don't forget animal ears, water balloons and a ridiculous helmet. It's all $$$!",
  "id" : 2353959448,
  "created_at" : "Sat Jun 27 02:46:01 +0000 2009",
  "in_reply_to_screen_name" : "cjlikearockstar",
  "in_reply_to_user_id_str" : "34383091",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Neilson",
      "screen_name" : "TheCulprit",
      "indices" : [ 0, 11 ],
      "id_str" : "6726182",
      "id" : 6726182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "2352339598",
  "geo" : {
  },
  "id_str" : "2352797715",
  "in_reply_to_user_id" : 6726182,
  "text" : "@TheCulprit You mean stick to running and drinking?",
  "id" : 2352797715,
  "in_reply_to_status_id" : 2352339598,
  "created_at" : "Sat Jun 27 01:01:32 +0000 2009",
  "in_reply_to_screen_name" : "TheCulprit",
  "in_reply_to_user_id_str" : "6726182",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2352418438",
  "text" : "Bought so much Gu I got a discount!",
  "id" : 2352418438,
  "created_at" : "Sat Jun 27 00:27:45 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2352314913",
  "text" : "Buying Gu for tomorrow's half-marathon. But now I have to decide between Gu gel, Gu chomps (gummy bears), and Clif shot blocks (gummy bars)!",
  "id" : 2352314913,
  "created_at" : "Sat Jun 27 00:18:35 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2338625942",
  "text" : "8:36pm Talking genetics around a campfire in Deception Pass: http://flic.kr/p/6zAo2G",
  "id" : 2338625942,
  "created_at" : "Fri Jun 26 03:40:15 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2330015178",
  "text" : "Headed to Deception Pass in @danielspil's awesome EuroVan. It's gonna be rough!",
  "id" : 2330015178,
  "created_at" : "Thu Jun 25 18:27:32 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2321180794",
  "text" : "8:36pm I love David Byrne's dancers http://flic.kr/p/6zhd5g",
  "id" : 2321180794,
  "created_at" : "Thu Jun 25 03:41:35 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.twiike.com\" rel=\"nofollow\">Twiike</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nikeplus",
      "indices" : [ 93, 102 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2317365915",
  "text" : "ran 4.18 mi @ a 09:42/mi pace with Nike+ on 06/22/2009 (run time: 40:34) http://bit.ly/6NIxf #nikeplus",
  "id" : 2317365915,
  "created_at" : "Wed Jun 24 22:29:52 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2317021566",
  "text" : "Found out Flickr & Vimeo will process your iPhone 3GS video correctly if you record in landscape mode! Flickr processes faster & wins.",
  "id" : 2317021566,
  "created_at" : "Wed Jun 24 22:02:12 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2316723239",
  "text" : "CHALLENGE: Try out Locavore's new \"I Ate Local\" feature and make me draw you something! Details: http://bit.ly/QbSzM",
  "id" : 2316723239,
  "created_at" : "Wed Jun 24 21:38:50 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2313336711",
  "text" : "I'm excited about today.",
  "id" : 2313336711,
  "created_at" : "Wed Jun 24 17:29:25 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carinna Tarvin",
      "screen_name" : "carinnatarvin",
      "indices" : [ 0, 14 ],
      "id_str" : "20833838",
      "id" : 20833838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "2306647782",
  "geo" : {
  },
  "id_str" : "2306738606",
  "in_reply_to_user_id" : 20833838,
  "text" : "@carinnatarvin Kellianne and I are in for car camping! We might be able to borrow @danielspil's awesome EuroVan.",
  "id" : 2306738606,
  "in_reply_to_status_id" : 2306647782,
  "created_at" : "Wed Jun 24 05:53:38 +0000 2009",
  "in_reply_to_screen_name" : "carinnatarvin",
  "in_reply_to_user_id_str" : "20833838",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carinna Tarvin",
      "screen_name" : "carinnatarvin",
      "indices" : [ 0, 14 ],
      "id_str" : "20833838",
      "id" : 20833838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2305353639",
  "in_reply_to_user_id" : 20833838,
  "text" : "@carinnatarvin I shoulda let you keep your broken phone! But have you checked Address Book on your Mac?",
  "id" : 2305353639,
  "created_at" : "Wed Jun 24 03:42:53 +0000 2009",
  "in_reply_to_screen_name" : "carinnatarvin",
  "in_reply_to_user_id_str" : "20833838",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2305296013",
  "text" : "8:36pm Working a bit late today. This is the view from my office desk. http://flic.kr/p/6z24wV",
  "id" : 2305296013,
  "created_at" : "Wed Jun 24 03:38:13 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ʎǝʞɔıɥ ʇʇɐɯ",
      "screen_name" : "matthickey",
      "indices" : [ 0, 11 ],
      "id_str" : "8710082",
      "id" : 8710082
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "2305019381",
  "geo" : {
  },
  "id_str" : "2305086651",
  "in_reply_to_user_id" : 8710082,
  "text" : "@matthickey Yes, I have something written up... I'll email it to you and we can go from there!",
  "id" : 2305086651,
  "in_reply_to_status_id" : 2305019381,
  "created_at" : "Wed Jun 24 03:21:12 +0000 2009",
  "in_reply_to_screen_name" : "matthickey",
  "in_reply_to_user_id_str" : "8710082",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2304599254",
  "text" : "I need a favor! Help me spread the word about Locavore's new social features: http://bit.ly/Ogzua",
  "id" : 2304599254,
  "created_at" : "Wed Jun 24 02:42:43 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2300526668",
  "text" : "Has anyone been able to email a video from 3GS to Vimeo or Flickr? Vimeo doesn't show up at all and Flickr says \"Unable to process\". :(",
  "id" : 2300526668,
  "created_at" : "Tue Jun 23 21:15:32 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brett Shell",
      "screen_name" : "Brethren",
      "indices" : [ 0, 9 ],
      "id_str" : "9857922",
      "id" : 9857922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "2300022749",
  "geo" : {
  },
  "id_str" : "2300050072",
  "in_reply_to_user_id" : 9857922,
  "text" : "@Brethren Yes! Awesome! You're one step ahead of us who still need to receive our copies.",
  "id" : 2300050072,
  "in_reply_to_status_id" : 2300022749,
  "created_at" : "Tue Jun 23 20:40:16 +0000 2009",
  "in_reply_to_screen_name" : "Brethren",
  "in_reply_to_user_id_str" : "9857922",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "christopher jones",
      "screen_name" : "cjlikearockstar",
      "indices" : [ 43, 59 ],
      "id_str" : "34383091",
      "id" : 34383091
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2299648553",
  "text" : "Send Chris your mens fashion questions! RT @cjlikearockstar: new column idea: a Q and A with me answering your men's fashion ?'s. FIRE AWAY!",
  "id" : 2299648553,
  "created_at" : "Tue Jun 23 20:10:27 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "senoraj",
      "screen_name" : "senoraj",
      "indices" : [ 0, 8 ],
      "id_str" : "13443292",
      "id" : 13443292
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "2290620523",
  "geo" : {
  },
  "id_str" : "2290965433",
  "in_reply_to_user_id" : 13443292,
  "text" : "@senoraj Beautiful post! I believe all those things too, even the ones that don't apply to me.",
  "id" : 2290965433,
  "in_reply_to_status_id" : 2290620523,
  "created_at" : "Tue Jun 23 05:56:16 +0000 2009",
  "in_reply_to_screen_name" : "senoraj",
  "in_reply_to_user_id_str" : "13443292",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2289916174",
  "text" : "8:36pm Just finished a run on this beautiful evening. Go Krunking Numbkits! http://flic.kr/p/6yPdgo",
  "id" : 2289916174,
  "created_at" : "Tue Jun 23 04:09:32 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2275425689",
  "text" : "Here's Dave Eggers's new intro to DFW's Infinite Jest. In case you're on the fence... http://www.laweekly.com/content/printVersion/50552",
  "id" : 2275425689,
  "created_at" : "Mon Jun 22 05:53:22 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carinna Tarvin",
      "screen_name" : "carinnatarvin",
      "indices" : [ 0, 14 ],
      "id_str" : "20833838",
      "id" : 20833838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "2275308072",
  "geo" : {
  },
  "id_str" : "2275360954",
  "in_reply_to_user_id" : 20833838,
  "text" : "@carinnatarvin Yay! I've never read it before. Have you? Also: let's convince more people!",
  "id" : 2275360954,
  "in_reply_to_status_id" : 2275308072,
  "created_at" : "Mon Jun 22 05:45:22 +0000 2009",
  "in_reply_to_screen_name" : "carinnatarvin",
  "in_reply_to_user_id_str" : "20833838",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2274580751",
  "text" : "Finally read about the challenge to read Infinite Jest in 3 mos, starting today. I'm gonna do it! You should too. http://infinitesummer.org/",
  "id" : 2274580751,
  "created_at" : "Mon Jun 22 04:20:07 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2274146123",
  "text" : "8:36pm Reading a friend's manuscript http://flic.kr/p/6yqHRV",
  "id" : 2274146123,
  "created_at" : "Mon Jun 22 03:39:15 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Few",
      "screen_name" : "jfew",
      "indices" : [ 0, 5 ],
      "id_str" : "2067141",
      "id" : 2067141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "2270023481",
  "geo" : {
  },
  "id_str" : "2271032737",
  "in_reply_to_user_id" : 2067141,
  "text" : "@jfew Yes, it's especially crucial to have 2 phones on different versions of the OS when they've got something in beta.",
  "id" : 2271032737,
  "in_reply_to_status_id" : 2270023481,
  "created_at" : "Sun Jun 21 22:50:49 +0000 2009",
  "in_reply_to_screen_name" : "jfew",
  "in_reply_to_user_id_str" : "2067141",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2268919213",
  "text" : "Eater's Manifesto posted at Portage Bay http://flic.kr/p/6ynvT5",
  "id" : 2268919213,
  "created_at" : "Sun Jun 21 19:32:36 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2261350461",
  "text" : "8:36pm Heading to the zoo with a chicken and a fox http://flic.kr/p/6ybyQS",
  "id" : 2261350461,
  "created_at" : "Sun Jun 21 03:39:20 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2248450641",
  "text" : "8:36pm Monster Madness on MegaTouch at the Jones mansion http://flic.kr/p/6xRJMB",
  "id" : 2248450641,
  "created_at" : "Sat Jun 20 03:38:40 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "samantha",
      "screen_name" : "samantham",
      "indices" : [ 0, 10 ],
      "id_str" : "1771141",
      "id" : 1771141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2246683457",
  "in_reply_to_user_id" : 1771141,
  "text" : "@samantham See Everyone and Future People by Jenny Zwick on Facebook. They have a perfect song called Over.",
  "id" : 2246683457,
  "created_at" : "Sat Jun 20 00:58:14 +0000 2009",
  "in_reply_to_screen_name" : "samantham",
  "in_reply_to_user_id_str" : "1771141",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "christopher jones",
      "screen_name" : "cjlikearockstar",
      "indices" : [ 0, 16 ],
      "id_str" : "34383091",
      "id" : 34383091
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2245649436",
  "in_reply_to_user_id" : 34383091,
  "text" : "@cjlikearockstar See, you still want something. You have a will. After 6 miles that goes away. You'll be fine!",
  "id" : 2245649436,
  "created_at" : "Fri Jun 19 23:26:21 +0000 2009",
  "in_reply_to_screen_name" : "cjlikearockstar",
  "in_reply_to_user_id_str" : "34383091",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2232976943",
  "text" : "8:36pm How will I stop from watching all 7 documentaries in the Up Series? http://flic.kr/p/6xCwxH",
  "id" : 2232976943,
  "created_at" : "Fri Jun 19 03:39:39 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2232245204",
  "text" : "7 Up and 7 Plus 7 are both amazing! Can't wait to watch more.",
  "id" : 2232245204,
  "created_at" : "Fri Jun 19 02:39:05 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2217288274",
  "text" : "8:36pm With Megan talking about 7-year olds http://flic.kr/p/6xsDYW",
  "id" : 2217288274,
  "created_at" : "Thu Jun 18 03:39:20 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Baxter",
      "screen_name" : "kbaxter",
      "indices" : [ 0, 8 ],
      "id_str" : "14149882",
      "id" : 14149882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "2210852925",
  "geo" : {
  },
  "id_str" : "2210967277",
  "in_reply_to_user_id" : 14149882,
  "text" : "@kbaxter Hm... no, I have the lowest too.  But I've also bought a phone or two when replacing lost / broken ones. I'm on my 4th paid phone!",
  "id" : 2210967277,
  "in_reply_to_status_id" : 2210852925,
  "created_at" : "Wed Jun 17 19:15:25 +0000 2009",
  "in_reply_to_screen_name" : "kbaxter",
  "in_reply_to_user_id_str" : "14149882",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Baxter",
      "screen_name" : "kbaxter",
      "indices" : [ 0, 8 ],
      "id_str" : "14149882",
      "id" : 14149882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "2210670542",
  "geo" : {
  },
  "id_str" : "2210767293",
  "in_reply_to_user_id" : 14149882,
  "text" : "@kbaxter Strange, I ordered 2G and 3G on first day and they say I'm eligible 9/1/2009. Did you buy the original 2G too?",
  "id" : 2210767293,
  "in_reply_to_status_id" : 2210670542,
  "created_at" : "Wed Jun 17 18:59:52 +0000 2009",
  "in_reply_to_screen_name" : "kbaxter",
  "in_reply_to_user_id_str" : "14149882",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Tomorrow",
      "screen_name" : "ryantomorrow",
      "indices" : [ 3, 16 ],
      "id_str" : "14679007",
      "id" : 14679007
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2210547429",
  "text" : "RT @ryantomorrow: Whoa: AT&T blinked, will offer $199/$299 price for iPhone 3G S to early adopters of iPhone 3G. http://tr.im/oPnR",
  "id" : 2210547429,
  "created_at" : "Wed Jun 17 18:43:13 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2210461975",
  "text" : "Support those of us running 13.1 miles in 10 days: http://bit.ly/19Hxsm Donate per piggy-back ride, shot drunk, water balloon hit, and more!",
  "id" : 2210461975,
  "created_at" : "Wed Jun 17 18:36:54 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2201705791",
  "text" : "8:36pm At Matador with some soon-unemployed friends http://flic.kr/p/6x7ZqB",
  "id" : 2201705791,
  "created_at" : "Wed Jun 17 03:39:19 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan McComb",
      "screen_name" : "danmccomb",
      "indices" : [ 27, 37 ],
      "id_str" : "14385806",
      "id" : 14385806
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2199392047",
  "text" : "I got interviewed today by @danmccomb for his movie Shine about being an entrepreneur. Great topics: risk, sparks, challenge, happiness!",
  "id" : 2199392047,
  "created_at" : "Wed Jun 17 00:26:08 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Adventure School",
      "screen_name" : "adventureschool",
      "indices" : [ 15, 31 ],
      "id_str" : "351312115",
      "id" : 351312115
    }, {
      "name" : "Anti-Buster",
      "screen_name" : "busterbenson",
      "indices" : [ 57, 70 ],
      "id_str" : "1024917050",
      "id" : 1024917050
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2195811335",
  "text" : "I love them RT @AdventureSchool: Want to know more about @busterbenson? Check the blog! http://bit.ly/CLsFJ",
  "id" : 2195811335,
  "created_at" : "Tue Jun 16 18:38:09 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2195587261",
  "text" : "8:36pm, a year later: http://bit.ly/y9WP1",
  "id" : 2195587261,
  "created_at" : "Tue Jun 16 18:19:59 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Caterina Fake",
      "screen_name" : "Caterina",
      "indices" : [ 48, 57 ],
      "id_str" : "5702",
      "id" : 5702
    }, {
      "name" : "Om Malik",
      "screen_name" : "om",
      "indices" : [ 58, 61 ],
      "id_str" : "989",
      "id" : 989
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2189282884",
  "text" : "I've heard a lot of this before but love it! RT @Caterina @om Tips on Innovation & Enterprenuership from Bezos http://tinyurl.com/npokyl",
  "id" : 2189282884,
  "created_at" : "Tue Jun 16 06:40:21 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2187683777",
  "text" : "8:36pm About to see the hangover http://flic.kr/p/6wQePz",
  "id" : 2187683777,
  "created_at" : "Tue Jun 16 03:38:53 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2173475355",
  "text" : "8:36pm Judi's in town and we're catching up at the Pink Door http://flic.kr/p/6wzMiQ",
  "id" : 2173475355,
  "created_at" : "Mon Jun 15 03:46:39 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Buster McLeod",
      "screen_name" : "BusterMcLeod",
      "indices" : [ 49, 62 ],
      "id_str" : "260029475",
      "id" : 260029475
    }, {
      "name" : "Anti-Buster",
      "screen_name" : "busterbenson",
      "indices" : [ 78, 91 ],
      "id_str" : "1024917050",
      "id" : 1024917050
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2167062277",
  "text" : "Hey everyone! I changed my twitter username from @bustermcleod to the all new @busterbenson. Update your... nothing... I guess? Hi!",
  "id" : 2167062277,
  "created_at" : "Sun Jun 14 17:37:26 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2161381315",
  "text" : "8:36pm Working in my new office! About to head to Gossamer Collective's opening http://flic.kr/p/6wfWvm",
  "id" : 2161381315,
  "created_at" : "Sun Jun 14 03:39:33 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "harryh",
      "screen_name" : "harryh",
      "indices" : [ 0, 7 ],
      "id_str" : "4558",
      "id" : 4558
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "2150197414",
  "geo" : {
  },
  "id_str" : "2150210068",
  "in_reply_to_user_id" : 4558,
  "text" : "@harryh That happened with /buster too. Maybe it has something to do with being 6 characters? And awesome?",
  "id" : 2150210068,
  "in_reply_to_status_id" : 2150197414,
  "created_at" : "Sat Jun 13 04:18:56 +0000 2009",
  "in_reply_to_screen_name" : "harryh",
  "in_reply_to_user_id_str" : "4558",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kindrameyer",
      "screen_name" : "kindrameyer",
      "indices" : [ 0, 12 ],
      "id_str" : "16400277",
      "id" : 16400277
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2150092950",
  "in_reply_to_user_id" : 16400277,
  "text" : "@kindrameyer I think my name is reserved! It just redirects to the homepage. Busterbenson I am.",
  "id" : 2150092950,
  "created_at" : "Sat Jun 13 04:08:01 +0000 2009",
  "in_reply_to_screen_name" : "kindrameyer",
  "in_reply_to_user_id_str" : "16400277",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2149962436",
  "text" : "There are 6 Busters on Facebook that I share mutual friends with, but I don't know any of them.",
  "id" : 2149962436,
  "created_at" : "Sat Jun 13 03:56:42 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2149819014",
  "text" : "8:36pm Buying tickets to Kindra's MENAGERIE while waiting for Facebook Nerdernames: http://flic.kr/p/6vWf9z",
  "id" : 2149819014,
  "created_at" : "Sat Jun 13 03:41:42 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.twiike.com\" rel=\"nofollow\">Twiike</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nikeplus",
      "indices" : [ 95, 104 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2138507150",
  "text" : "ran 6.67 mi @ a 09:24/mi pace with Nike+ on 06/12/2009 (run time: 1:02:46) http://bit.ly/l4Rpx #nikeplus",
  "id" : 2138507150,
  "created_at" : "Fri Jun 12 23:51:08 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2135347665",
  "text" : "Pulling off the first snap peas, planting some carrots.",
  "id" : 2135347665,
  "created_at" : "Fri Jun 12 19:15:20 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "D. Keith Robinson",
      "screen_name" : "dkr",
      "indices" : [ 0, 4 ],
      "id_str" : "10877",
      "id" : 10877
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "2132864174",
  "geo" : {
  },
  "id_str" : "2133313628",
  "in_reply_to_user_id" : 10877,
  "text" : "@dkr Congrats on big changes!",
  "id" : 2133313628,
  "in_reply_to_status_id" : 2132864174,
  "created_at" : "Fri Jun 12 16:34:05 +0000 2009",
  "in_reply_to_screen_name" : "dkr",
  "in_reply_to_user_id_str" : "10877",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2133218326",
  "text" : "The new best way to post a photo to Flickr and Twitter at the same time: http://www.flickr.com/groups/flickrtwitterbeta",
  "id" : 2133218326,
  "created_at" : "Fri Jun 12 16:26:41 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ScottieYahtzee",
      "screen_name" : "ScottieYahtzee",
      "indices" : [ 43, 58 ],
      "id_str" : "15486015",
      "id" : 15486015
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2133020160",
  "text" : "Why do they mention ethnicity 38 times? RT @ScottieYahtzee Interesting article and they even mention the ole speakeasy. http://bit.ly/16jwe5",
  "id" : 2133020160,
  "created_at" : "Fri Jun 12 16:11:03 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2128127101",
  "text" : "Walk home from Volunteer Park holding a bowl of strawberries was super nice. Even got to see a little burlesque.",
  "id" : 2128127101,
  "created_at" : "Fri Jun 12 06:06:59 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "&y",
      "screen_name" : "andypixel",
      "indices" : [ 0, 10 ],
      "id_str" : "10015122",
      "id" : 10015122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "2126858279",
  "geo" : {
  },
  "id_str" : "2127173551",
  "in_reply_to_user_id" : 10015122,
  "text" : "@andypixel Mobile Fotos can post to Twitter (or Tweetie in my case) and shortens urls for you.",
  "id" : 2127173551,
  "in_reply_to_status_id" : 2126858279,
  "created_at" : "Fri Jun 12 04:21:37 +0000 2009",
  "in_reply_to_screen_name" : "andypixel",
  "in_reply_to_user_id_str" : "10015122",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2126582598",
  "text" : "8:36pm Picnic at Volunteer Park: http://flic.kr/p/6vGN3i",
  "id" : 2126582598,
  "created_at" : "Fri Jun 12 03:39:02 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Robot Co-op",
      "screen_name" : "robotcoop",
      "indices" : [ 9, 19 ],
      "id_str" : "26297795",
      "id" : 26297795
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2123460576",
  "text" : "Neat! RT @robotcoop 43 Things iPhone app gets a mention at the end of this run down on to-do list apps. Yee haw. http://bit.ly/uTEYJ",
  "id" : 2123460576,
  "created_at" : "Thu Jun 11 23:03:31 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "2112190911",
  "geo" : {
  },
  "id_str" : "2114973946",
  "in_reply_to_user_id" : 23315649,
  "text" : "@TristonDaShorty I don't! Can Jimmy James upload it for me somewhere?",
  "id" : 2114973946,
  "in_reply_to_status_id" : 2112190911,
  "created_at" : "Thu Jun 11 08:51:57 +0000 2009",
  "in_reply_to_screen_name" : "tristontriston",
  "in_reply_to_user_id_str" : "23315649",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2112640229",
  "text" : "8:36pm Post-talk at Licorous: http://flic.kr/p/6vwQsb",
  "id" : 2112640229,
  "created_at" : "Thu Jun 11 03:40:07 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Neilson",
      "screen_name" : "TheCulprit",
      "indices" : [ 0, 11 ],
      "id_str" : "6726182",
      "id" : 6726182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "2107620568",
  "geo" : {
  },
  "id_str" : "2107692711",
  "in_reply_to_user_id" : 6726182,
  "text" : "@TheCulprit Oh, didn't realize he'd be there. We'll compare notes!",
  "id" : 2107692711,
  "in_reply_to_status_id" : 2107620568,
  "created_at" : "Wed Jun 10 20:12:19 +0000 2009",
  "in_reply_to_screen_name" : "TheCulprit",
  "in_reply_to_user_id_str" : "6726182",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Meredith Modzelewski",
      "screen_name" : "meredithmo",
      "indices" : [ 16, 27 ],
      "id_str" : "17069950",
      "id" : 17069950
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2107673381",
  "text" : "Gluttons? :) RT @meredithmo What should we call ourselves, we lovers of fine food, beverages and the experiences that surround them?",
  "id" : 2107673381,
  "created_at" : "Wed Jun 10 20:10:44 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Neilson",
      "screen_name" : "TheCulprit",
      "indices" : [ 0, 11 ],
      "id_str" : "6726182",
      "id" : 6726182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2107546749",
  "in_reply_to_user_id" : 6726182,
  "text" : "@theculprit I wanna see Objectified too! Skip it and watch later!",
  "id" : 2107546749,
  "created_at" : "Wed Jun 10 20:00:07 +0000 2009",
  "in_reply_to_screen_name" : "TheCulprit",
  "in_reply_to_user_id_str" : "6726182",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2107428606",
  "text" : "Gonna see Alain de Botton (related to School of Life and some great books) at 7pm at the Central Library tonight. Wanna join? It's free.",
  "id" : 2107428606,
  "created_at" : "Wed Jun 10 19:49:36 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alicetiara",
      "screen_name" : "alicetiara",
      "indices" : [ 0, 11 ],
      "id_str" : "784078",
      "id" : 784078
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "2107157325",
  "geo" : {
  },
  "id_str" : "2107346968",
  "in_reply_to_user_id" : 784078,
  "text" : "@alicetiara I think I write to the people I follow and have twittered something recently. And I also tweet to myself. Is that wrong?",
  "id" : 2107346968,
  "in_reply_to_status_id" : 2107157325,
  "created_at" : "Wed Jun 10 19:42:16 +0000 2009",
  "in_reply_to_screen_name" : "alicetiara",
  "in_reply_to_user_id_str" : "784078",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Allen",
      "screen_name" : "allenm73",
      "indices" : [ 0, 9 ],
      "id_str" : "571505381",
      "id" : 571505381
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "2099622829",
  "geo" : {
  },
  "id_str" : "2100719005",
  "in_reply_to_user_id" : 22118364,
  "text" : "@allenm73 Both! :) Mostly the ties and suits though. And maybe a shoe or two.",
  "id" : 2100719005,
  "in_reply_to_status_id" : 2099622829,
  "created_at" : "Wed Jun 10 07:19:19 +0000 2009",
  "in_reply_to_screen_name" : "allenmmurray",
  "in_reply_to_user_id_str" : "22118364",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2099602582",
  "text" : "Left my laptop in Ballard. Guess I'm working from House of Chai and peering sadly into Blackbird again tomorrow.",
  "id" : 2099602582,
  "created_at" : "Wed Jun 10 04:44:30 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "&y",
      "screen_name" : "andypixel",
      "indices" : [ 0, 10 ],
      "id_str" : "10015122",
      "id" : 10015122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2099017289",
  "in_reply_to_user_id" : 10015122,
  "text" : "@andypixel Summertime!",
  "id" : 2099017289,
  "created_at" : "Wed Jun 10 03:47:51 +0000 2009",
  "in_reply_to_screen_name" : "andypixel",
  "in_reply_to_user_id_str" : "10015122",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2098924025",
  "text" : "8:36pm At our Ballard date talking about health insurance options: http://flic.kr/p/6vh1Lf",
  "id" : 2098924025,
  "created_at" : "Wed Jun 10 03:39:34 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2098784662",
  "text" : "I no longer have a beard!",
  "id" : 2098784662,
  "created_at" : "Wed Jun 10 03:26:52 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Megan Welling",
      "screen_name" : "MeganWelling",
      "indices" : [ 0, 13 ],
      "id_str" : "26166039",
      "id" : 26166039
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "2094594190",
  "geo" : {
  },
  "id_str" : "2094724367",
  "in_reply_to_user_id" : 26166039,
  "text" : "@MeganWelling My vote is that you get a job as a millionaire.  A summer millionaire.  With a boat.",
  "id" : 2094724367,
  "in_reply_to_status_id" : 2094594190,
  "created_at" : "Tue Jun 09 21:26:46 +0000 2009",
  "in_reply_to_screen_name" : "MeganWelling",
  "in_reply_to_user_id_str" : "26166039",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bcs09",
      "indices" : [ 84, 90 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2094249924",
  "text" : "Okay, I'm attending BarCampSeattle 09. My Pathable profile: http://rubyurl.com/D0tt #bcs09 (Let me know if you're going too!)",
  "id" : 2094249924,
  "created_at" : "Tue Jun 09 20:45:53 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BarCamp Seattle",
      "screen_name" : "barcampseattle",
      "indices" : [ 66, 81 ],
      "id_str" : "14701934",
      "id" : 14701934
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2094172353",
  "text" : "I'm thinking of breaking out of my anti-social shell and going to @barcampseattle. Who else is going?",
  "id" : 2094172353,
  "created_at" : "Tue Jun 09 20:39:06 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Beau Gunderson",
      "screen_name" : "beaugunderson",
      "indices" : [ 0, 14 ],
      "id_str" : "5746882",
      "id" : 5746882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "2081038986",
  "geo" : {
  },
  "id_str" : "2091215914",
  "in_reply_to_user_id" : 5746882,
  "text" : "@beaugunderson I'd sell it for real cheap to someone without an iPhone who let me buy their $199 3GS off of them.",
  "id" : 2091215914,
  "in_reply_to_status_id" : 2081038986,
  "created_at" : "Tue Jun 09 16:21:53 +0000 2009",
  "in_reply_to_screen_name" : "beaugunderson",
  "in_reply_to_user_id_str" : "5746882",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carinna Tarvin",
      "screen_name" : "carinnatarvin",
      "indices" : [ 0, 14 ],
      "id_str" : "20833838",
      "id" : 20833838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2083553514",
  "in_reply_to_user_id" : 20833838,
  "text" : "@carinnatarvin Seriously??? Yay! You're BBQ'ing at the Pixels's's tonight right?",
  "id" : 2083553514,
  "created_at" : "Tue Jun 09 00:44:17 +0000 2009",
  "in_reply_to_screen_name" : "carinnatarvin",
  "in_reply_to_user_id_str" : "20833838",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcelo Calbucci",
      "screen_name" : "calbucci",
      "indices" : [ 0, 9 ],
      "id_str" : "14232711",
      "id" : 14232711
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "2080537844",
  "geo" : {
  },
  "id_str" : "2080977898",
  "in_reply_to_user_id" : 14232711,
  "text" : "@calbucci True, I would be willing to sell a 16GB 3G for $99 in exchange for them letting me buy their $199 16GB 3GS from them. Complicated!",
  "id" : 2080977898,
  "in_reply_to_status_id" : 2080537844,
  "created_at" : "Mon Jun 08 20:45:00 +0000 2009",
  "in_reply_to_screen_name" : "calbucci",
  "in_reply_to_user_id_str" : "14232711",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Rainert",
      "screen_name" : "arainert",
      "indices" : [ 0, 9 ],
      "id_str" : "7482",
      "id" : 7482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "2080371965",
  "geo" : {
  },
  "id_str" : "2080420005",
  "in_reply_to_user_id" : 7482,
  "text" : "@arainert Yeah, but they were still being really aggressive about capturing the market. Maybe they don't think they have to anymore?",
  "id" : 2080420005,
  "in_reply_to_status_id" : 2080371965,
  "created_at" : "Mon Jun 08 19:57:23 +0000 2009",
  "in_reply_to_screen_name" : "arainert",
  "in_reply_to_user_id_str" : "7482",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2080295513",
  "text" : "Crap, can't upgrade the iPhone for less than $399 apparently. I'm gonna have to recruit a non-iPhone friend who wants an old 3G. Anyone?",
  "id" : 2080295513,
  "created_at" : "Mon Jun 08 19:46:42 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Rainert",
      "screen_name" : "arainert",
      "indices" : [ 0, 9 ],
      "id_str" : "7482",
      "id" : 7482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "2080196461",
  "geo" : {
  },
  "id_str" : "2080208341",
  "in_reply_to_user_id" : 7482,
  "text" : "@arainert On one of my accounts I get no upgrade price ($499 for the 16GB) and on another I get $399 for being a valued customer. :(",
  "id" : 2080208341,
  "in_reply_to_status_id" : 2080196461,
  "created_at" : "Mon Jun 08 19:39:18 +0000 2009",
  "in_reply_to_screen_name" : "arainert",
  "in_reply_to_user_id_str" : "7482",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2079792920",
  "text" : "I'm definitely getting the new iPhone 3GS 16GB for $199 in 11 days. Mostly for tap-focus and video.",
  "id" : 2079792920,
  "created_at" : "Mon Jun 08 19:05:53 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nikete",
      "screen_name" : "nikete",
      "indices" : [ 0, 7 ],
      "id_str" : "10239",
      "id" : 10239
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "2078795687",
  "geo" : {
  },
  "id_str" : "2078861674",
  "in_reply_to_user_id" : 10239,
  "text" : "@nikete The general gist? The point is that it can find causal relationships in the data? With so little info, it's not that difficult.",
  "id" : 2078861674,
  "in_reply_to_status_id" : 2078795687,
  "created_at" : "Mon Jun 08 17:53:29 +0000 2009",
  "in_reply_to_screen_name" : "nikete",
  "in_reply_to_user_id_str" : "10239",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nikete",
      "screen_name" : "nikete",
      "indices" : [ 0, 7 ],
      "id_str" : "10239",
      "id" : 10239
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "2078626914",
  "geo" : {
  },
  "id_str" : "2078741487",
  "in_reply_to_user_id" : 10239,
  "text" : "@nikete Interesting, but at first glance it looks way over my head. Any pointers for simplifying it?",
  "id" : 2078741487,
  "in_reply_to_status_id" : 2078626914,
  "created_at" : "Mon Jun 08 17:44:11 +0000 2009",
  "in_reply_to_screen_name" : "nikete",
  "in_reply_to_user_id_str" : "10239",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2078345223",
  "text" : "Apple's WWDC keynote where they announce new iPhones is being watched now (I love the passive voice). http://live.gizmodo.com/",
  "id" : 2078345223,
  "created_at" : "Mon Jun 08 17:12:26 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2072265321",
  "text" : "8:36pm Looking for a very important piece of misplaced paper. Sopor's looking too.: http://flic.kr/p/6uFe81",
  "id" : 2072265321,
  "created_at" : "Mon Jun 08 03:41:53 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2067772451",
  "text" : "How representing ourselves online might change in the next few years: http://bit.ly/pP4sj",
  "id" : 2067772451,
  "created_at" : "Sun Jun 07 19:56:03 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2061332627",
  "text" : "8:36pm Dinner on Heath and Spencer's roof: http://flic.kr/p/6umsqq",
  "id" : 2061332627,
  "created_at" : "Sun Jun 07 03:38:59 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2057515442",
  "text" : "Working on my new company's Facebook page.  Will you be a fan? http://bit.ly/5KE0i",
  "id" : 2057515442,
  "created_at" : "Sat Jun 06 20:08:52 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "andy kleitsch",
      "screen_name" : "kleitsch",
      "indices" : [ 0, 9 ],
      "id_str" : "14248569",
      "id" : 14248569
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "2053417680",
  "geo" : {
  },
  "id_str" : "2056127620",
  "in_reply_to_user_id" : 14248569,
  "text" : "@kleitsch After one degree you have to start counting the rows of separation!",
  "id" : 2056127620,
  "in_reply_to_status_id" : 2053417680,
  "created_at" : "Sat Jun 06 17:34:36 +0000 2009",
  "in_reply_to_screen_name" : "kleitsch",
  "in_reply_to_user_id_str" : "14248569",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2051446020",
  "text" : "Okay, Hulu Desktop is pretty rad. If only any of the shows were as good.",
  "id" : 2051446020,
  "created_at" : "Sat Jun 06 05:02:26 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2051238596",
  "text" : "8:36pm Kellianne in contemplation: http://flic.kr/p/6u74gu",
  "id" : 2051238596,
  "created_at" : "Sat Jun 06 04:16:54 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2040672046",
  "text" : "I think I fell in love with Emily Haines and @MetricBand all over again. I love the Metric philosophy on life.",
  "id" : 2040672046,
  "created_at" : "Fri Jun 05 08:19:21 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2025844938",
  "text" : "8:36pm Meeting Cori and Aviva who I already love!: http://flic.kr/p/6tytwF",
  "id" : 2025844938,
  "created_at" : "Thu Jun 04 04:40:08 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Adventure School",
      "screen_name" : "adventureschool",
      "indices" : [ 20, 36 ],
      "id_str" : "351312115",
      "id" : 351312115
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2024604658",
  "text" : "I'm excited to meet @adventureschool at the top of the Space Needle!",
  "id" : 2024604658,
  "created_at" : "Thu Jun 04 02:31:37 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ignite Seattle",
      "screen_name" : "ignitesea",
      "indices" : [ 45, 55 ],
      "id_str" : "3567281",
      "id" : 3567281
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2024226482",
  "text" : "I want to do a talk for the upcoming Ignite (@ignitesea). But I need to come up with a really good topic. Think, Buster, think!",
  "id" : 2024226482,
  "created_at" : "Thu Jun 04 01:55:52 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leeni",
      "screen_name" : "leenirama",
      "indices" : [ 0, 10 ],
      "id_str" : "17236443",
      "id" : 17236443
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "2023169207",
  "geo" : {
  },
  "id_str" : "2024170873",
  "in_reply_to_user_id" : 17236443,
  "text" : "@leenirama I feel so bad for what happened, and can't explain how it happened. It is not okay for us to come over and be rude. So sorry!",
  "id" : 2024170873,
  "in_reply_to_status_id" : 2023169207,
  "created_at" : "Thu Jun 04 01:50:27 +0000 2009",
  "in_reply_to_screen_name" : "leenirama",
  "in_reply_to_user_id_str" : "17236443",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2017130413",
  "text" : "Up early to be in a random commercial that will film me being \"hip and nerdy\" at my p-patch. What to wear?",
  "id" : 2017130413,
  "created_at" : "Wed Jun 03 14:54:31 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2012455515",
  "text" : "8:36pm At La Carta de Octopus pre-Up: http://flic.kr/p/6tmZam",
  "id" : 2012455515,
  "created_at" : "Wed Jun 03 03:40:54 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chadwick Dahlquist",
      "screen_name" : "bugeats",
      "indices" : [ 0, 8 ],
      "id_str" : "9074342",
      "id" : 9074342
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "2011131564",
  "geo" : {
  },
  "id_str" : "2011152221",
  "in_reply_to_user_id" : 9074342,
  "text" : "@bugeats Start something!",
  "id" : 2011152221,
  "in_reply_to_status_id" : 2011131564,
  "created_at" : "Wed Jun 03 01:33:50 +0000 2009",
  "in_reply_to_screen_name" : "bugeats",
  "in_reply_to_user_id_str" : "9074342",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Megan Welling",
      "screen_name" : "MeganWelling",
      "indices" : [ 22, 35 ],
      "id_str" : "26166039",
      "id" : 26166039
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2010797655",
  "text" : "I'm still sweating RT @meganwelling Just finished a 7 mile, 1 hour and 5 minute, 80 million degree run with Buster and Matt Hodge. Go team!",
  "id" : 2010797655,
  "created_at" : "Wed Jun 03 00:59:14 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "2007363260",
  "text" : "Will you sponsor me + friends on the Rock and Roll half-marathon on June 27th? Pretty please? http://bit.ly/19Hxsm",
  "id" : 2007363260,
  "created_at" : "Tue Jun 02 19:31:52 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Megan Welling",
      "screen_name" : "MeganWelling",
      "indices" : [ 0, 13 ],
      "id_str" : "26166039",
      "id" : 26166039
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "2006919570",
  "geo" : {
  },
  "id_str" : "2007114521",
  "in_reply_to_user_id" : 26166039,
  "text" : "@MeganWelling Ready to run in this big bad heat?",
  "id" : 2007114521,
  "in_reply_to_status_id" : 2006919570,
  "created_at" : "Tue Jun 02 19:10:05 +0000 2009",
  "in_reply_to_screen_name" : "MeganWelling",
  "in_reply_to_user_id_str" : "26166039",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kindrameyer",
      "screen_name" : "kindrameyer",
      "indices" : [ 0, 12 ],
      "id_str" : "16400277",
      "id" : 16400277
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "2006419224",
  "geo" : {
  },
  "id_str" : "2006477183",
  "in_reply_to_user_id" : 16400277,
  "text" : "@kindrameyer That sounds perfect! Get better!",
  "id" : 2006477183,
  "in_reply_to_status_id" : 2006419224,
  "created_at" : "Tue Jun 02 18:13:31 +0000 2009",
  "in_reply_to_screen_name" : "kindrameyer",
  "in_reply_to_user_id_str" : "16400277",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kindrameyer",
      "screen_name" : "kindrameyer",
      "indices" : [ 0, 12 ],
      "id_str" : "16400277",
      "id" : 16400277
    }, {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 35, 45 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "2006071611",
  "geo" : {
  },
  "id_str" : "2006239533",
  "in_reply_to_user_id" : 16400277,
  "text" : "@kindrameyer I want to see Up, but @kellianne doesn't get back from Ballard til 9 or so.  Late show?",
  "id" : 2006239533,
  "in_reply_to_status_id" : 2006071611,
  "created_at" : "Tue Jun 02 17:52:14 +0000 2009",
  "in_reply_to_screen_name" : "kindrameyer",
  "in_reply_to_user_id_str" : "16400277",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aja West",
      "screen_name" : "ajawest",
      "indices" : [ 0, 8 ],
      "id_str" : "126676985",
      "id" : 126676985
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "2001268780",
  "geo" : {
  },
  "id_str" : "2005905506",
  "in_reply_to_user_id" : 13551722,
  "text" : "@ajawest That's a nice thing to hear!  Thanks, Aja.",
  "id" : 2005905506,
  "in_reply_to_status_id" : 2001268780,
  "created_at" : "Tue Jun 02 17:21:32 +0000 2009",
  "in_reply_to_screen_name" : "shaebot",
  "in_reply_to_user_id_str" : "13551722",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Megan Welling",
      "screen_name" : "MeganWelling",
      "indices" : [ 0, 13 ],
      "id_str" : "26166039",
      "id" : 26166039
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "2000046467",
  "geo" : {
  },
  "id_str" : "2000071869",
  "in_reply_to_user_id" : 26166039,
  "text" : "@MeganWelling Yes! When should we run? I have a meeting at 6... so maybe it should be an early afternoon run?",
  "id" : 2000071869,
  "in_reply_to_status_id" : 2000046467,
  "created_at" : "Tue Jun 02 04:21:15 +0000 2009",
  "in_reply_to_screen_name" : "MeganWelling",
  "in_reply_to_user_id_str" : "26166039",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "1999703293",
  "text" : "8:36pm Setting up the tomatoes, strawberries, & petunias while BBQing: http://flic.kr/p/6sZPRx",
  "id" : 1999703293,
  "created_at" : "Tue Jun 02 03:40:32 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Dean",
      "screen_name" : "dandean",
      "indices" : [ 0, 8 ],
      "id_str" : "9525212",
      "id" : 9525212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1998561063",
  "geo" : {
  },
  "id_str" : "1998634228",
  "in_reply_to_user_id" : 9525212,
  "text" : "@dandean Very true. I primed the question! Shit, now I'll never know. Actually, it should've been \"How is Clearwire? 0-10\"",
  "id" : 1998634228,
  "in_reply_to_status_id" : 1998561063,
  "created_at" : "Tue Jun 02 01:52:30 +0000 2009",
  "in_reply_to_screen_name" : "dandean",
  "in_reply_to_user_id_str" : "9525212",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Boscardin",
      "screen_name" : "abosco",
      "indices" : [ 0, 7 ],
      "id_str" : "16742020",
      "id" : 16742020
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1998413590",
  "geo" : {
  },
  "id_str" : "1998490997",
  "in_reply_to_user_id" : 16742020,
  "text" : "@abosco I've heard many horror stories about Comcast. Weren't they chosen as one of the 2nd worst company by Gizmodo? http://bit.ly/gn60b",
  "id" : 1998490997,
  "in_reply_to_status_id" : 1998413590,
  "created_at" : "Tue Jun 02 01:38:13 +0000 2009",
  "in_reply_to_screen_name" : "abosco",
  "in_reply_to_user_id_str" : "16742020",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Boscardin",
      "screen_name" : "abosco",
      "indices" : [ 0, 7 ],
      "id_str" : "16742020",
      "id" : 16742020
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1998404430",
  "geo" : {
  },
  "id_str" : "1998418837",
  "in_reply_to_user_id" : 16742020,
  "text" : "@abosco Then who do you recommend? (I've been using them 10+ years too for both residences and businesses and have been pretty happy...)",
  "id" : 1998418837,
  "in_reply_to_status_id" : 1998404430,
  "created_at" : "Tue Jun 02 01:30:59 +0000 2009",
  "in_reply_to_screen_name" : "abosco",
  "in_reply_to_user_id_str" : "16742020",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "1998388232",
  "text" : "10+ people have told me Clearwire sucks in less than 30 minutes, and nobody has said anything nice. I'm gonna spend $20 more on Speakeasy!",
  "id" : 1998388232,
  "created_at" : "Tue Jun 02 01:28:01 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "1998154927",
  "text" : "Does Clearwire suck?",
  "id" : 1998154927,
  "created_at" : "Tue Jun 02 01:05:00 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "1997568032",
  "text" : "Getting the keys to my new work space (at Vain)",
  "id" : 1997568032,
  "created_at" : "Tue Jun 02 00:04:36 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael McDaniel",
      "screen_name" : "michaelmcdaniel",
      "indices" : [ 0, 16 ],
      "id_str" : "7565162",
      "id" : 7565162
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1997372403",
  "geo" : {
  },
  "id_str" : "1997537525",
  "in_reply_to_user_id" : 7565162,
  "text" : "@michaelmcdaniel Haha, okay, I'll try this out tomorrow!",
  "id" : 1997537525,
  "in_reply_to_status_id" : 1997372403,
  "created_at" : "Tue Jun 02 00:01:28 +0000 2009",
  "in_reply_to_screen_name" : "michaelmcdaniel",
  "in_reply_to_user_id_str" : "7565162",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "1997060228",
  "text" : "My all-fruit lunch left me feeling a little ill after the sugar wore off (I assume). Might need to alter strategy. Help!",
  "id" : 1997060228,
  "created_at" : "Mon Jun 01 23:10:55 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "1994590017",
  "text" : "Today is a big beginning. The extragood frugal life starts in 3... 2... 1... now!",
  "id" : 1994590017,
  "created_at" : "Mon Jun 01 19:09:17 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
} ]