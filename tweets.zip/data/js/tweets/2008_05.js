Grailbird.data.tweets_2008_05 = 
 [ {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "824385373",
  "text" : "8:36pm at Maneki for Jenn's birthday, giving Sedea a hard time for secretly seeing Sex and the City",
  "id" : 824385373,
  "created_at" : "2008-06-01 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "824392537",
  "text" : "Accidentally ordered twice as much sushi as I thought I did.",
  "id" : 824392537,
  "created_at" : "2008-06-01 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "823790530",
  "text" : "8:36pm at this place called Cellar's talking about secret things.",
  "id" : 823790530,
  "created_at" : "2008-05-31 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "824193888",
  "text" : "My strategy for paying bills is rather loosey-goosey.  It saves a lot of time, but often involves late fees.",
  "id" : 824193888,
  "created_at" : "2008-05-31 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "824241501",
  "text" : "Why does each business tax agency have 3 names, completely different ways to file (electronically, paper, web), and different pay schedules?",
  "id" : 824241501,
  "created_at" : "2008-05-31 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "822928299",
  "text" : "Holy American Jesus! Our building has a front door again!",
  "id" : 822928299,
  "created_at" : "2008-05-30 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "823041505",
  "text" : "8:36pm Eating asparagus and talking about changed relationship statuses on Facebook.",
  "id" : 823041505,
  "created_at" : "2008-05-30 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "823063308",
  "text" : "Watching Lost on time delay. No Twitter spoilers!",
  "id" : 823063308,
  "created_at" : "2008-05-30 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "823113737",
  "text" : "Woah!",
  "id" : 823113737,
  "created_at" : "2008-05-30 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Harrison",
      "screen_name" : "sourjayne",
      "indices" : [ 0, 10 ],
      "id_str" : "4981271",
      "id" : 4981271
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "823117609",
  "geo" : { },
  "id_str" : "823120634",
  "in_reply_to_user_id" : 4981271,
  "text" : "@sourjayne yeah, woah!",
  "id" : 823120634,
  "in_reply_to_status_id" : 823117609,
  "created_at" : "2008-05-30 00:00:00 +0000",
  "in_reply_to_screen_name" : "sourjayne",
  "in_reply_to_user_id_str" : "4981271",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "822124776",
  "text" : "Lindyhop class strikes again!",
  "id" : 822124776,
  "created_at" : "2008-05-29 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "822216668",
  "text" : "8:36pm having a birthday dinner at Machiavelli, talking about public failure and lucky success.",
  "id" : 822216668,
  "created_at" : "2008-05-29 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "821429675",
  "text" : "8:36pm Telling Kellianne all about my meeting with Scott Kuhlman and my bespoke suit. And other things.",
  "id" : 821429675,
  "created_at" : "2008-05-28 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Harrison",
      "screen_name" : "sourjayne",
      "indices" : [ 0, 10 ],
      "id_str" : "4981271",
      "id" : 4981271
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "821443576",
  "geo" : { },
  "id_str" : "821444561",
  "in_reply_to_user_id" : 4981271,
  "text" : "@sourjayne Jump on it! Jump on it! It's gonna be big.",
  "id" : 821444561,
  "in_reply_to_status_id" : 821443576,
  "created_at" : "2008-05-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "sourjayne",
  "in_reply_to_user_id_str" : "4981271",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "821510276",
  "text" : "It's my birthday! Let's open that Clear Creek Pear Brandy I hid the other night.",
  "id" : 821510276,
  "created_at" : "2008-05-28 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ali Berman",
      "screen_name" : "spangley",
      "indices" : [ 0, 9 ],
      "id_str" : "776429",
      "id" : 776429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "821991058",
  "geo" : { },
  "id_str" : "821994370",
  "in_reply_to_user_id" : 776429,
  "text" : "@spangley You should get the Teany Pumpkin Chai, or something like that.  It's the tastiest!",
  "id" : 821994370,
  "in_reply_to_status_id" : 821991058,
  "created_at" : "2008-05-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "spangley",
  "in_reply_to_user_id_str" : "776429",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "820621313",
  "text" : "8:36pm Breaking into McLeod to get Rick's jacket after deliciousness at Black Bottle",
  "id" : 820621313,
  "created_at" : "2008-05-27 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "821218971",
  "text" : "I gained 5 pounds during the last week of birthdaying it up. Oops!",
  "id" : 821218971,
  "created_at" : "2008-05-27 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "819918199",
  "text" : "8:36pm eating cake with my favorite people! celebrating!",
  "id" : 819918199,
  "created_at" : "2008-05-26 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "819948994",
  "text" : "Using my elbow to type.",
  "id" : 819948994,
  "created_at" : "2008-05-26 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ingopixel",
      "screen_name" : "ingopixel",
      "indices" : [ 0, 10 ],
      "id_str" : "7943892",
      "id" : 7943892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "820072155",
  "geo" : { },
  "id_str" : "820314464",
  "in_reply_to_user_id" : 7943892,
  "text" : "@ingopixel By \"I left the rest of the milky way for a hobo\" I thought we'd never see you again, not that you were done snacking.",
  "id" : 820314464,
  "in_reply_to_status_id" : 820072155,
  "created_at" : "2008-05-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "ingopixel",
  "in_reply_to_user_id_str" : "7943892",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "820315148",
  "text" : "That was a fun party!",
  "id" : 820315148,
  "created_at" : "2008-05-26 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "samantha",
      "screen_name" : "samantham",
      "indices" : [ 0, 10 ],
      "id_str" : "1771141",
      "id" : 1771141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "820331939",
  "geo" : { },
  "id_str" : "820337504",
  "in_reply_to_user_id" : 1771141,
  "text" : "@samantham I'm glad you have some pictures cause I didn't take any, just video.",
  "id" : 820337504,
  "in_reply_to_status_id" : 820331939,
  "created_at" : "2008-05-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "samantham",
  "in_reply_to_user_id_str" : "1771141",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "820496222",
  "text" : "Having our 3rd BBQ in 3days.",
  "id" : 820496222,
  "created_at" : "2008-05-26 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "819371525",
  "text" : "Sacrificed a burger to the fire and a kabob to the earth.",
  "id" : 819371525,
  "created_at" : "2008-05-25 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "819434654",
  "text" : "Gemini rehearsal party: success. Real deal tomorrowland.",
  "id" : 819434654,
  "created_at" : "2008-05-25 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "819706203",
  "text" : "Birthday weekend, Sun 12:55pm: going to pick up my grandpa pants.",
  "id" : 819706203,
  "created_at" : "2008-05-25 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "819783170",
  "text" : "3:56pm hopping roof decks, breaking open the mashed potato bar!",
  "id" : 819783170,
  "created_at" : "2008-05-25 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "819791995",
  "text" : "Ed just ate mashed potatoes on a Top Pot donut. As if it were a steak.",
  "id" : 819791995,
  "created_at" : "2008-05-25 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "819298553",
  "text" : "0 to BBQ in 75 minutes. Now for some Pimm's and Jager.",
  "id" : 819298553,
  "created_at" : "2008-05-25 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenn",
      "screen_name" : "terrajen",
      "indices" : [ 0, 9 ],
      "id_str" : "765671",
      "id" : 765671
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "819299075",
  "geo" : { },
  "id_str" : "819299513",
  "in_reply_to_user_id" : 765671,
  "text" : "@terrajen yes this is a rehearsal party.",
  "id" : 819299513,
  "in_reply_to_status_id" : 819299075,
  "created_at" : "2008-05-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "terrajen",
  "in_reply_to_user_id_str" : "765671",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "819339094",
  "text" : "8:36pm just had a short nap on our amazing deck!",
  "id" : 819339094,
  "created_at" : "2008-05-25 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "818718616",
  "text" : "Can't beat coconut cream pie and clear creek pear brandy for de-ssert.",
  "id" : 818718616,
  "created_at" : "2008-05-24 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "818762102",
  "text" : "8:36pm I mentioned how I wanted to steal Viceroy's lamp while the waitress overheard. It's been stolen twice, now bolted down.",
  "id" : 818762102,
  "created_at" : "2008-05-24 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "819130689",
  "text" : "Birthday weekend is off to a grand start!",
  "id" : 819130689,
  "created_at" : "2008-05-24 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "819175739",
  "text" : "Buying a BBQ for tomorrow. You're coming, right?",
  "id" : 819175739,
  "created_at" : "2008-05-24 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "817978854",
  "text" : "8:36pm Eating gingerbread cake with Judi, Brady, and Kellianne, talking about SXSW.",
  "id" : 817978854,
  "created_at" : "2008-05-23 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "818655618",
  "text" : "\"Someone should do something about all the problems.\" Ingo quoting the Onion but oh so true.",
  "id" : 818655618,
  "created_at" : "2008-05-23 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "817101578",
  "text" : "8:36pm Finishing a second bottle of rose with the Pixels at Cafe Presse.",
  "id" : 817101578,
  "created_at" : "2008-05-22 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chadwick Dahlquist",
      "screen_name" : "bugeats",
      "indices" : [ 0, 8 ],
      "id_str" : "9074342",
      "id" : 9074342
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "817709116",
  "geo" : { },
  "id_str" : "817712117",
  "in_reply_to_user_id" : 9074342,
  "text" : "@bugeats Yes, keep doing it. I'm recruiting too... just started a 43things goal for it.",
  "id" : 817712117,
  "in_reply_to_status_id" : 817709116,
  "created_at" : "2008-05-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "bugeats",
  "in_reply_to_user_id_str" : "9074342",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chadwick Dahlquist",
      "screen_name" : "bugeats",
      "indices" : [ 104, 112 ],
      "id_str" : "9074342",
      "id" : 9074342
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "817820284",
  "text" : "Just registered 836pm.com.  It's cracking me up.  I now own that minute on the internet.  With props to @bugeats, please don't sue me.",
  "id" : 817820284,
  "created_at" : "2008-05-22 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Watson",
      "screen_name" : "twatson",
      "indices" : [ 11, 19 ],
      "id_str" : "43273",
      "id" : 43273
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "817825853",
  "text" : "Looks like @twatson owns 110am.com... who else owns a minute on the internet?  There can only be 1,338 more of you out there.",
  "id" : 817825853,
  "created_at" : "2008-05-22 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "josh",
      "screen_name" : "joshc",
      "indices" : [ 0, 6 ],
      "id_str" : "2015",
      "id" : 2015
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "817838852",
  "geo" : { },
  "id_str" : "817849717",
  "in_reply_to_user_id" : 2015,
  "text" : "@joshc Oh yeah, I've seen 601am.com before.  Okay, only 1,437 left to find.",
  "id" : 817849717,
  "in_reply_to_status_id" : 817838852,
  "created_at" : "2008-05-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "joshc",
  "in_reply_to_user_id_str" : "2015",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "816252386",
  "text" : "8:36pm drinking margaritas with Carinna at Mama's talking about not being throw-up drunk anymore.",
  "id" : 816252386,
  "created_at" : "2008-05-21 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "816069128",
  "text" : "Holy shit there IS an Easter Bunny!",
  "id" : 816069128,
  "created_at" : "2008-05-20 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "814533115",
  "text" : "Emery Carl gave McLeod a rad hula hoop in exchange for a membership, and I'm taking it to the Pixel BBQ!",
  "id" : 814533115,
  "created_at" : "2008-05-19 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "814621883",
  "text" : "8:36pm eating BBQ chicken kabobs at Andy and Ingo's, while Kellianne mocks this project.",
  "id" : 814621883,
  "created_at" : "2008-05-19 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "815088089",
  "text" : "Almost passed.",
  "id" : 815088089,
  "created_at" : "2008-05-19 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "815110379",
  "text" : "Keeping the option of magic miracle open is important.",
  "id" : 815110379,
  "created_at" : "2008-05-19 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "815298548",
  "text" : "Second try: PASS!",
  "id" : 815298548,
  "created_at" : "2008-05-19 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Cottrell",
      "screen_name" : "rgcottrell",
      "indices" : [ 0, 11 ],
      "id_str" : "752553",
      "id" : 752553
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "815324667",
  "geo" : { },
  "id_str" : "815325825",
  "in_reply_to_user_id" : 752553,
  "text" : "@rgcottrell if you make a submission I'll include you in version 2!",
  "id" : 815325825,
  "in_reply_to_status_id" : 815324667,
  "created_at" : "2008-05-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "rgcottrell",
  "in_reply_to_user_id_str" : "752553",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "813964872",
  "text" : "8:36pm on the roof contemplating if we should burn the umbrella's ornamental, but ugly, top. I vote yes.",
  "id" : 813964872,
  "created_at" : "2008-05-18 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "814030885",
  "text" : "Is having a bonfire on the 3rd floor roof legal?",
  "id" : 814030885,
  "created_at" : "2008-05-18 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "813724112",
  "text" : "Uploading the first version of my 2008 friend book to blurb.com right now.",
  "id" : 813724112,
  "created_at" : "2008-05-17 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chadwick Dahlquist",
      "screen_name" : "bugeats",
      "indices" : [ 15, 23 ],
      "id_str" : "9074342",
      "id" : 9074342
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "813744740",
  "text" : "I'm gonna copy @bugeats and twitter what I'm doing at 8:36pm every day for a week.  Alarm set.",
  "id" : 813744740,
  "created_at" : "2008-05-17 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "813768684",
  "text" : "My book of friends, thanks to blurb: http://www.blurb.com/bookstore/detail/246229",
  "id" : 813768684,
  "created_at" : "2008-05-17 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "813788296",
  "text" : "It's too hot. Yup I said it.",
  "id" : 813788296,
  "created_at" : "2008-05-17 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "812506968",
  "text" : "Kellianne's sick and I'm restless at home. Anyone have a teleporter to fun?",
  "id" : 812506968,
  "created_at" : "2008-05-16 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "811510113",
  "text" : "Istwitterdown.com",
  "id" : 811510113,
  "created_at" : "2008-05-15 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tara Tiger Brown",
      "screen_name" : "tarabrown",
      "indices" : [ 0, 10 ],
      "id_str" : "17400089",
      "id" : 17400089
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "811589026",
  "geo" : { },
  "id_str" : "811633855",
  "in_reply_to_user_id" : 10959642,
  "text" : "@tarabrown I agree that you should start your own company. Best (work) experience possible!",
  "id" : 811633855,
  "in_reply_to_status_id" : 811589026,
  "created_at" : "2008-05-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "tara",
  "in_reply_to_user_id_str" : "10959642",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tara Tiger Brown",
      "screen_name" : "tarabrown",
      "indices" : [ 0, 10 ],
      "id_str" : "17400089",
      "id" : 17400089
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "810626623",
  "geo" : { },
  "id_str" : "810639605",
  "in_reply_to_user_id" : 10959642,
  "text" : "@tarabrown yes get the pro!",
  "id" : 810639605,
  "in_reply_to_status_id" : 810626623,
  "created_at" : "2008-05-14 00:00:00 +0000",
  "in_reply_to_screen_name" : "tara",
  "in_reply_to_user_id_str" : "10959642",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "811345104",
  "text" : "Is it just coincidence that I always feel extra-stressed on days I have acupuncture later?",
  "id" : 811345104,
  "created_at" : "2008-05-14 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "810350291",
  "text" : "Barista said I looked glorious today. And I even left my chariot at home.",
  "id" : 810350291,
  "created_at" : "2008-05-13 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "810417274",
  "text" : "Just found my first girlfriend on the internet.  Not gonna write to her.",
  "id" : 810417274,
  "created_at" : "2008-05-13 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "810624145",
  "text" : "I'm leaving work and my shopping list is coffee, a chicken, and toilet paper.  I don't know why that cracks me up.",
  "id" : 810624145,
  "created_at" : "2008-05-13 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "809035852",
  "text" : "Playing guitar hero for the first time. Ouch.",
  "id" : 809035852,
  "created_at" : "2008-05-12 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "809497998",
  "text" : "Today I'm not going to use any exclamation points or emoticons.  Think I can do it?",
  "id" : 809497998,
  "created_at" : "2008-05-12 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "809548745",
  "text" : "Oops, I've already accidentally used 4 exclamation points in an IM conversation.",
  "id" : 809548745,
  "created_at" : "2008-05-12 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "809607280",
  "text" : "Tried a new mental trick in slow weights this morning and did much better, but also had to lie down immediately after to avoid puking.",
  "id" : 809607280,
  "created_at" : "2008-05-12 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tara Tiger Brown",
      "screen_name" : "tarabrown",
      "indices" : [ 0, 10 ],
      "id_str" : "17400089",
      "id" : 17400089
    }, {
      "name" : "Sarah Harrison",
      "screen_name" : "sourjayne",
      "indices" : [ 11, 21 ],
      "id_str" : "4981271",
      "id" : 4981271
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "809620685",
  "geo" : { },
  "id_str" : "809644725",
  "in_reply_to_user_id" : 10959642,
  "text" : "@tarabrown @sourjayne Thanks, re-reading it 8 months later and still feel all of it intensely and amazingly.",
  "id" : 809644725,
  "in_reply_to_status_id" : 809620685,
  "created_at" : "2008-05-12 00:00:00 +0000",
  "in_reply_to_screen_name" : "tara",
  "in_reply_to_user_id_str" : "10959642",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "808731057",
  "text" : "Why is Flickr in Italian for me this morning?",
  "id" : 808731057,
  "created_at" : "2008-05-11 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "808900503",
  "text" : "Google maps should estimate cab fare when it gives directions.",
  "id" : 808900503,
  "created_at" : "2008-05-11 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "808906450",
  "text" : "Kellianne's talking to her mom with a Delaware accent.",
  "id" : 808906450,
  "created_at" : "2008-05-11 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "808252941",
  "text" : "Watching the Jonestown documentary as reward for finishing finance stuff.",
  "id" : 808252941,
  "created_at" : "2008-05-10 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "808288470",
  "text" : "Sadly, making all the naked McLeod Residence photo booth pictures friends only.",
  "id" : 808288470,
  "created_at" : "2008-05-10 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "&y",
      "screen_name" : "andypixel",
      "indices" : [ 0, 10 ],
      "id_str" : "10015122",
      "id" : 10015122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "808293855",
  "geo" : { },
  "id_str" : "808304977",
  "in_reply_to_user_id" : 10015122,
  "text" : "@andypixel 22,598 pictures to be exact.  I've gone through 1/10th so far.",
  "id" : 808304977,
  "in_reply_to_status_id" : 808293855,
  "created_at" : "2008-05-10 00:00:00 +0000",
  "in_reply_to_screen_name" : "andypixel",
  "in_reply_to_user_id_str" : "10015122",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "807377313",
  "text" : "The moment of reckoning is here.",
  "id" : 807377313,
  "created_at" : "2008-05-09 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "807406570",
  "text" : "Did not die.",
  "id" : 807406570,
  "created_at" : "2008-05-09 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "805241114",
  "text" : "Manning the door for a while because our door guy is puking from the stomach flu.",
  "id" : 805241114,
  "created_at" : "2008-05-07 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "804415528",
  "text" : "Prod ye the donkey's rump he are sure of a kick.",
  "id" : 804415528,
  "created_at" : "2008-05-06 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "804787723",
  "text" : "Send me your tumblr username pls!",
  "id" : 804787723,
  "created_at" : "2008-05-06 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sungeb",
      "screen_name" : "All",
      "indices" : [ 0, 4 ],
      "id_str" : "1741728181",
      "id" : 1741728181
    }, {
      "name" : "Aubrey Sabala",
      "screen_name" : "Aubs",
      "indices" : [ 33, 38 ],
      "id_str" : "2781",
      "id" : 2781
    }, {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 43, 53 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "600358022",
  "geo" : { },
  "id_str" : "804217940",
  "in_reply_to_user_id" : 3462401,
  "text" : "@all yall - I'm an ENFJ. Same as @aubs and @kellianne and more according to http://tinyurl.com/6p8vwa",
  "id" : 804217940,
  "in_reply_to_status_id" : 600358022,
  "created_at" : "2008-05-05 00:00:00 +0000",
  "in_reply_to_screen_name" : "iAmTommySimms",
  "in_reply_to_user_id_str" : "3462401",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "804242345",
  "text" : "I just Facebook friended Whitney from America's Next Top Model.",
  "id" : 804242345,
  "created_at" : "2008-05-05 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "803351394",
  "text" : "The scene outside my condo of crackheads rolling around in the sun and interacting with tourist traffic is... what's the word?",
  "id" : 803351394,
  "created_at" : "2008-05-04 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitterhelp.blogspot.com/2008/05/twitter-via-mobile-web-mtwittercom.html\" rel=\"nofollow\">mobile web</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "802285042",
  "text" : "Pants",
  "id" : 802285042,
  "created_at" : "2008-05-03 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "802717206",
  "text" : "I think I ate poisonous flowers last night.",
  "id" : 802717206,
  "created_at" : "2008-05-03 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tantek \u00C7elik",
      "screen_name" : "t",
      "indices" : [ 0, 2 ],
      "id_str" : "11628",
      "id" : 11628
    }, {
      "name" : "Tara Tiger Brown",
      "screen_name" : "tarabrown",
      "indices" : [ 7, 17 ],
      "id_str" : "17400089",
      "id" : 17400089
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "801692978",
  "geo" : { },
  "id_str" : "801698879",
  "in_reply_to_user_id" : 11628,
  "text" : "@t and @tarabrown I promise to work less and play more tomorrow! With less pants!",
  "id" : 801698879,
  "in_reply_to_status_id" : 801692978,
  "created_at" : "2008-05-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "t",
  "in_reply_to_user_id_str" : "11628",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitterhelp.blogspot.com/2008/05/twitter-via-mobile-web-mtwittercom.html\" rel=\"nofollow\">mobile web</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Harrison",
      "screen_name" : "sourjayne",
      "indices" : [ 0, 10 ],
      "id_str" : "4981271",
      "id" : 4981271
    }, {
      "name" : "Jeff Croft",
      "screen_name" : "jcroft",
      "indices" : [ 16, 23 ],
      "id_str" : "25993",
      "id" : 25993
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "801967034",
  "geo" : { },
  "id_str" : "801968885",
  "in_reply_to_user_id" : 4981271,
  "text" : "@sourjayne what @jcroft said.",
  "id" : 801968885,
  "in_reply_to_status_id" : 801967034,
  "created_at" : "2008-05-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "sourjayne",
  "in_reply_to_user_id_str" : "4981271",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "802105533",
  "text" : "I fixed my Flip Video!",
  "id" : 802105533,
  "created_at" : "2008-05-02 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
} ]