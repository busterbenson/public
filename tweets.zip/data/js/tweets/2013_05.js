Grailbird.data.tweets_2013_05 = 
 [ {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Chen",
      "screen_name" : "andrewchen",
      "indices" : [ 3, 14 ],
      "id_str" : "3283901",
      "id" : 3283901
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http://t.co/019kuKZr25",
      "expanded_url" : "http://bit.ly/10YnmDk",
      "display_url" : "bit.ly/10YnmDk"
    } ]
  },
  "geo" : {
  },
  "id_str" : "340709298550222848",
  "text" : "RT @andrewchen: 'Mobile is eating the world' \u2014 Benedict Evans http://t.co/019kuKZr25",
  "retweeted_status" : {
    "source" : "<a href=\"http://bufferapp.com\" rel=\"nofollow\">Buffer</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 46, 68 ],
        "url" : "http://t.co/019kuKZr25",
        "expanded_url" : "http://bit.ly/10YnmDk",
        "display_url" : "bit.ly/10YnmDk"
      } ]
    },
    "geo" : {
    },
    "id_str" : "340573474252804097",
    "text" : "'Mobile is eating the world' \u2014 Benedict Evans http://t.co/019kuKZr25",
    "id" : 340573474252804097,
    "created_at" : "Fri May 31 21:00:18 +0000 2013",
    "user" : {
      "name" : "Andrew Chen",
      "screen_name" : "andrewchen",
      "protected" : false,
      "id_str" : "3283901",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2199553637/IMG_1584_normal.JPG",
      "id" : 3283901,
      "verified" : false
    }
  },
  "id" : 340709298550222848,
  "created_at" : "Sat Jun 01 06:00:01 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew J. Rosenthal",
      "screen_name" : "rosenthal",
      "indices" : [ 0, 10 ],
      "id_str" : "15792969",
      "id" : 15792969
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "340672786223751168",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597540329, -122.2755061341 ]
  },
  "id_str" : "340681285234221056",
  "in_reply_to_user_id" : 15792969,
  "text" : "@rosenthal Yeah, let's get a drink when you get back! Is there anyone else in Seattle I can help connect you with?",
  "id" : 340681285234221056,
  "in_reply_to_status_id" : 340672786223751168,
  "created_at" : "Sat Jun 01 04:08:42 +0000 2013",
  "in_reply_to_screen_name" : "rosenthal",
  "in_reply_to_user_id_str" : "15792969",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 50 ],
      "url" : "http://t.co/4wk4dXadOq",
      "expanded_url" : "http://flic.kr/p/ezbtxP",
      "display_url" : "flic.kr/p/ezbtxP"
    } ]
  },
  "geo" : {
  },
  "id_str" : "340674813934858240",
  "text" : "8:36pm Family portrait hour http://t.co/4wk4dXadOq",
  "id" : 340674813934858240,
  "created_at" : "Sat Jun 01 03:42:59 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason W",
      "screen_name" : "J2XL",
      "indices" : [ 0, 5 ],
      "id_str" : "1593141",
      "id" : 1593141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "340668682923569152",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597432738, -122.2755598284 ]
  },
  "id_str" : "340671271304040448",
  "in_reply_to_user_id" : 1593141,
  "text" : "@J2XL Woah you still use it??",
  "id" : 340671271304040448,
  "in_reply_to_status_id" : 340668682923569152,
  "created_at" : "Sat Jun 01 03:28:55 +0000 2013",
  "in_reply_to_screen_name" : "J2XL",
  "in_reply_to_user_id_str" : "1593141",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Buster",
      "screen_name" : "buster",
      "indices" : [ 14, 21 ],
      "id_str" : "2185",
      "id" : 2185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http://t.co/CjzzWNYzG3",
      "expanded_url" : "http://my.yahoo.com",
      "display_url" : "my.yahoo.com"
    } ]
  },
  "in_reply_to_status_id_str" : "340656537804632064",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596636317, -122.2758336772 ]
  },
  "id_str" : "340657196545236992",
  "in_reply_to_user_id" : 2185,
  "text" : "erikbelieves \"@buster: MT with your yahoo username if you had http://t.co/CjzzWNYzG3 as your homepage for longer than a year.\"",
  "id" : 340657196545236992,
  "in_reply_to_status_id" : 340656537804632064,
  "created_at" : "Sat Jun 01 02:32:59 +0000 2013",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 63 ],
      "url" : "http://t.co/CjzzWNYzG3",
      "expanded_url" : "http://my.yahoo.com",
      "display_url" : "my.yahoo.com"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8589555761, -122.2756889464 ]
  },
  "id_str" : "340656537804632064",
  "text" : "MT with your yahoo username if you had a http://t.co/CjzzWNYzG3 as your homepage for longer than a year.",
  "id" : 340656537804632064,
  "created_at" : "Sat Jun 01 02:30:22 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u028E\u01DD\u029E\u0254\u0131\u0265 \u0287\u0287\u0250\u026F",
      "screen_name" : "matthickey",
      "indices" : [ 0, 11 ],
      "id_str" : "8710082",
      "id" : 8710082
    }, {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 12, 21 ],
      "id_str" : "761628",
      "id" : 761628
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "340654909810679809",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8584796641, -122.2751157758 ]
  },
  "id_str" : "340655649367146496",
  "in_reply_to_user_id" : 8710082,
  "text" : "@matthickey @RickWebb dot tumblr dot com.",
  "id" : 340655649367146496,
  "in_reply_to_status_id" : 340654909810679809,
  "created_at" : "Sat Jun 01 02:26:50 +0000 2013",
  "in_reply_to_screen_name" : "matthickey",
  "in_reply_to_user_id_str" : "8710082",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "josh",
      "screen_name" : "joshc",
      "indices" : [ 0, 6 ],
      "id_str" : "2015",
      "id" : 2015
    }, {
      "name" : "Radiolab",
      "screen_name" : "Radiolab",
      "indices" : [ 18, 27 ],
      "id_str" : "28583197",
      "id" : 28583197
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "340653576080719872",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8585772589, -122.2743678746 ]
  },
  "id_str" : "340655461294542848",
  "in_reply_to_user_id" : 2015,
  "text" : "@joshc I heard on @radiolab that our brains are innately born with base 2. Seems about right but need a scientist to confirm.",
  "id" : 340655461294542848,
  "in_reply_to_status_id" : 340653576080719872,
  "created_at" : "Sat Jun 01 02:26:05 +0000 2013",
  "in_reply_to_screen_name" : "joshc",
  "in_reply_to_user_id_str" : "2015",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 0, 9 ],
      "id_str" : "761628",
      "id" : 761628
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "340653371864268801",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8561234946, -122.2711633822 ]
  },
  "id_str" : "340653830414954496",
  "in_reply_to_user_id" : 761628,
  "text" : "@RickWebb Let's start a \"bad meditators\" yahoo group / tumblr / support group or something. #$$$\u20AC\u00A3\u00A5",
  "id" : 340653830414954496,
  "in_reply_to_status_id" : 340653371864268801,
  "created_at" : "Sat Jun 01 02:19:36 +0000 2013",
  "in_reply_to_screen_name" : "RickWebb",
  "in_reply_to_user_id_str" : "761628",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew J. Rosenthal",
      "screen_name" : "rosenthal",
      "indices" : [ 0, 10 ],
      "id_str" : "15792969",
      "id" : 15792969
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "340647770501312512",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8540193661, -122.270737461 ]
  },
  "id_str" : "340652771650961408",
  "in_reply_to_user_id" : 15792969,
  "text" : "@rosenthal I'm in SF now! Berkeley actually.",
  "id" : 340652771650961408,
  "in_reply_to_status_id" : 340647770501312512,
  "created_at" : "Sat Jun 01 02:15:24 +0000 2013",
  "in_reply_to_screen_name" : "rosenthal",
  "in_reply_to_user_id_str" : "15792969",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benjamin L. Haas",
      "screen_name" : "delohaas",
      "indices" : [ 0, 9 ],
      "id_str" : "24212532",
      "id" : 24212532
    }, {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 10, 19 ],
      "id_str" : "761628",
      "id" : 761628
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "340650670535360512",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8534034454, -122.2702810263 ]
  },
  "id_str" : "340652721617108992",
  "in_reply_to_user_id" : 24212532,
  "text" : "@delohaas @RickWebb Nah it's overrated.",
  "id" : 340652721617108992,
  "in_reply_to_status_id" : 340650670535360512,
  "created_at" : "Sat Jun 01 02:15:12 +0000 2013",
  "in_reply_to_screen_name" : "delohaas",
  "in_reply_to_user_id_str" : "24212532",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 0, 9 ],
      "id_str" : "761628",
      "id" : 761628
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "340615312657494016",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8305453128, -122.2662584347 ]
  },
  "id_str" : "340651809934802946",
  "in_reply_to_user_id" : 761628,
  "text" : "@RickWebb Put together a personal board of directors. Learn how to meditate. Not necessarily in that order.",
  "id" : 340651809934802946,
  "in_reply_to_status_id" : 340615312657494016,
  "created_at" : "Sat Jun 01 02:11:35 +0000 2013",
  "in_reply_to_screen_name" : "RickWebb",
  "in_reply_to_user_id_str" : "761628",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7792061648, -122.414256471 ]
  },
  "id_str" : "340644879879266305",
  "text" : "Relationship b/t money &amp; happiness is logarithmic. So are attempts at communication &amp; other people understanding what you're trying to say.",
  "id" : 340644879879266305,
  "created_at" : "Sat Jun 01 01:44:02 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Corrin Foster",
      "screen_name" : "corrinrenee",
      "indices" : [ 3, 15 ],
      "id_str" : "3538721",
      "id" : 3538721
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "340589385672179712",
  "text" : "RT @corrinrenee: Dear all websites ever. My day phone is my evening phone is my home phone is my cell phone. Sincerely, 2013",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "336930504790138880",
    "text" : "Dear all websites ever. My day phone is my evening phone is my home phone is my cell phone. Sincerely, 2013",
    "id" : 336930504790138880,
    "created_at" : "Tue May 21 19:44:26 +0000 2013",
    "user" : {
      "name" : "Corrin Foster",
      "screen_name" : "corrinrenee",
      "protected" : false,
      "id_str" : "3538721",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2719056911/3208c53ed9757ee87f42a970616c3a6e_normal.jpeg",
      "id" : 3538721,
      "verified" : false
    }
  },
  "id" : 340589385672179712,
  "created_at" : "Fri May 31 22:03:32 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Sarver",
      "screen_name" : "rsarver",
      "indices" : [ 0, 8 ],
      "id_str" : "795649",
      "id" : 795649
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "340558880281088001",
  "geo" : {
  },
  "id_str" : "340561396183990276",
  "in_reply_to_user_id" : 795649,
  "text" : "@rsarver NOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO!!!! (But okay, fine. And thanks for being awesome.)",
  "id" : 340561396183990276,
  "in_reply_to_status_id" : 340558880281088001,
  "created_at" : "Fri May 31 20:12:18 +0000 2013",
  "in_reply_to_screen_name" : "rsarver",
  "in_reply_to_user_id_str" : "795649",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian Padgham",
      "screen_name" : "origiful",
      "indices" : [ 0, 9 ],
      "id_str" : "15603374",
      "id" : 15603374
    }, {
      "name" : "April Schiller",
      "screen_name" : "the_april",
      "indices" : [ 10, 20 ],
      "id_str" : "16644937",
      "id" : 16644937
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "340560635186249730",
  "geo" : {
  },
  "id_str" : "340560946353303552",
  "in_reply_to_user_id" : 15603374,
  "text" : "@origiful @the_april Woah, you beat Vine to profile pages. Nice!",
  "id" : 340560946353303552,
  "in_reply_to_status_id" : 340560635186249730,
  "created_at" : "Fri May 31 20:10:31 +0000 2013",
  "in_reply_to_screen_name" : "origiful",
  "in_reply_to_user_id_str" : "15603374",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "April Schiller",
      "screen_name" : "the_april",
      "indices" : [ 0, 10 ],
      "id_str" : "16644937",
      "id" : 16644937
    }, {
      "name" : "Ian Padgham",
      "screen_name" : "origiful",
      "indices" : [ 46, 55 ],
      "id_str" : "15603374",
      "id" : 15603374
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 80 ],
      "url" : "https://t.co/6By4fWtorg",
      "expanded_url" : "https://twitter.com/search?q=%40origiful%20vine.co&src=typd",
      "display_url" : "twitter.com/search?q=%40or\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "340559128277688320",
  "geo" : {
  },
  "id_str" : "340560030271143936",
  "in_reply_to_user_id" : 16644937,
  "text" : "@the_april For another Vine-master, check out @origiful: https://t.co/6By4fWtorg",
  "id" : 340560030271143936,
  "in_reply_to_status_id" : 340559128277688320,
  "created_at" : "Fri May 31 20:06:53 +0000 2013",
  "in_reply_to_screen_name" : "the_april",
  "in_reply_to_user_id_str" : "16644937",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://vine.co\" rel=\"nofollow\">Vine - Make a Scene</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Lynch",
      "screen_name" : "DAVID_LYNCH",
      "indices" : [ 10, 22 ],
      "id_str" : "15962096",
      "id" : 15962096
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mysteries",
      "indices" : [ 37, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 48, 71 ],
      "url" : "https://t.co/oAG0a0zuIu",
      "expanded_url" : "https://vine.co/v/bYx2FX3Qbx2",
      "display_url" : "vine.co/v/bYx2FX3Qbx2"
    } ]
  },
  "geo" : {
  },
  "id_str" : "340555326803828737",
  "text" : "Hey look, @david_lynch's first Vine! #mysteries https://t.co/oAG0a0zuIu",
  "id" : 340555326803828737,
  "created_at" : "Fri May 31 19:48:11 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrei Pop",
      "screen_name" : "andreimpop",
      "indices" : [ 0, 11 ],
      "id_str" : "82801305",
      "id" : 82801305
    }, {
      "name" : "naveen",
      "screen_name" : "naveen",
      "indices" : [ 12, 19 ],
      "id_str" : "5215",
      "id" : 5215
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "340515150572449793",
  "geo" : {
  },
  "id_str" : "340517124588052480",
  "in_reply_to_user_id" : 82801305,
  "text" : "@andreimpop @naveen Woah, so happy that people are thinking in this direction. I'd love to try it out if you're inviting people in...",
  "id" : 340517124588052480,
  "in_reply_to_status_id" : 340515150572449793,
  "created_at" : "Fri May 31 17:16:23 +0000 2013",
  "in_reply_to_screen_name" : "andreimpop",
  "in_reply_to_user_id_str" : "82801305",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "naveen",
      "screen_name" : "naveen",
      "indices" : [ 0, 7 ],
      "id_str" : "5215",
      "id" : 5215
    }, {
      "name" : "Branch",
      "screen_name" : "branch",
      "indices" : [ 40, 47 ],
      "id_str" : "494518813",
      "id" : 494518813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "340514681062060032",
  "geo" : {
  },
  "id_str" : "340515003809533953",
  "in_reply_to_user_id" : 5215,
  "text" : "@naveen Can you start a mailing list or @branch or something about this so we can talk it out?",
  "id" : 340515003809533953,
  "in_reply_to_status_id" : 340514681062060032,
  "created_at" : "Fri May 31 17:07:58 +0000 2013",
  "in_reply_to_screen_name" : "naveen",
  "in_reply_to_user_id_str" : "5215",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "naveen",
      "screen_name" : "naveen",
      "indices" : [ 16, 23 ],
      "id_str" : "5215",
      "id" : 5215
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http://t.co/mOVXKjcK0x",
      "expanded_url" : "http://x.naveen.com/post/51808692792/a-personal-api",
      "display_url" : "x.naveen.com/post/518086927\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "340514521649123328",
  "text" : "I LOVE THIS. RT @naveen: new: 'a personal API' \u2013 streams that you can use to access my real-time personal statistics. http://t.co/mOVXKjcK0x",
  "id" : 340514521649123328,
  "created_at" : "Fri May 31 17:06:03 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "naveen",
      "screen_name" : "naveen",
      "indices" : [ 0, 7 ],
      "id_str" : "5215",
      "id" : 5215
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "340495667225059328",
  "geo" : {
  },
  "id_str" : "340514318586089472",
  "in_reply_to_user_id" : 5215,
  "text" : "@naveen Holy shitballs, that's awesome. I need to ponder on this. Nicely done!",
  "id" : 340514318586089472,
  "in_reply_to_status_id" : 340495667225059328,
  "created_at" : "Fri May 31 17:05:14 +0000 2013",
  "in_reply_to_screen_name" : "naveen",
  "in_reply_to_user_id_str" : "5215",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8286565533, -122.2673318487 ]
  },
  "id_str" : "340498507691618304",
  "text" : "For things that are easier said than done maybe it's better to do them before you say them.",
  "id" : 340498507691618304,
  "created_at" : "Fri May 31 16:02:25 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Asteroid Watch",
      "screen_name" : "AsteroidWatch",
      "indices" : [ 3, 17 ],
      "id_str" : "23503181",
      "id" : 23503181
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "340495599969378304",
  "text" : "RT @AsteroidWatch: Asteroid 1998 QE2 - and its tiny moon -will safely pass Earth by 3.6 million miles (5.86 million km) today at 4:59pm EDT.",
  "retweeted_status" : {
    "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "340490336776359937",
    "text" : "Asteroid 1998 QE2 - and its tiny moon -will safely pass Earth by 3.6 million miles (5.86 million km) today at 4:59pm EDT.",
    "id" : 340490336776359937,
    "created_at" : "Fri May 31 15:29:56 +0000 2013",
    "user" : {
      "name" : "Asteroid Watch",
      "screen_name" : "AsteroidWatch",
      "protected" : false,
      "id_str" : "23503181",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1272791828/Picture_76_normal_done_normal.png",
      "id" : 23503181,
      "verified" : true
    }
  },
  "id" : 340495599969378304,
  "created_at" : "Fri May 31 15:50:51 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "rstevens 3.01",
      "screen_name" : "rstevens",
      "indices" : [ 3, 12 ],
      "id_str" : "643653",
      "id" : 643653
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "340495483644547073",
  "text" : "RT @rstevens: Carbs Against Humanity",
  "retweeted_status" : {
    "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "340490013122899969",
    "text" : "Carbs Against Humanity",
    "id" : 340490013122899969,
    "created_at" : "Fri May 31 15:28:39 +0000 2013",
    "user" : {
      "name" : "rstevens 3.01",
      "screen_name" : "rstevens",
      "protected" : false,
      "id_str" : "643653",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1828254293/coffeepot-twitter_normal.png",
      "id" : 643653,
      "verified" : false
    }
  },
  "id" : 340495483644547073,
  "created_at" : "Fri May 31 15:50:24 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "d11",
      "indices" : [ 12, 16 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8532271093, -122.2704171644 ]
  },
  "id_str" : "340495413654204418",
  "text" : "Elon Musk's #d11 interview was inspiring, but the intro and questions started off very painfully.",
  "id" : 340495413654204418,
  "created_at" : "Fri May 31 15:50:07 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Technori",
      "screen_name" : "Technori",
      "indices" : [ 3, 12 ],
      "id_str" : "176211652",
      "id" : 176211652
    }, {
      "name" : "Buster",
      "screen_name" : "buster",
      "indices" : [ 116, 123 ],
      "id_str" : "2185",
      "id" : 2185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "340479868686962689",
  "text" : "RT @Technori: \u201CEvery day, the accumulation of mostly meaningless, uncurated life feels a tiny bit more beautiful.\u201D\u2013 @buster http://t.co/TbG\u2026",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Buster",
        "screen_name" : "buster",
        "indices" : [ 102, 109 ],
        "id_str" : "2185",
        "id" : 2185
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "QS",
        "indices" : [ 133, 136 ]
      } ],
      "urls" : [ {
        "indices" : [ 110, 132 ],
        "url" : "http://t.co/TbGp7yehot",
        "expanded_url" : "http://bit.ly/11bZDQZ",
        "display_url" : "bit.ly/11bZDQZ"
      } ]
    },
    "geo" : {
    },
    "id_str" : "340471420687642624",
    "text" : "\u201CEvery day, the accumulation of mostly meaningless, uncurated life feels a tiny bit more beautiful.\u201D\u2013 @buster http://t.co/TbGp7yehot #QS",
    "id" : 340471420687642624,
    "created_at" : "Fri May 31 14:14:47 +0000 2013",
    "user" : {
      "name" : "Technori",
      "screen_name" : "Technori",
      "protected" : false,
      "id_str" : "176211652",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2307682895/6kpr75qoxb2nzgzbriw6_normal.jpeg",
      "id" : 176211652,
      "verified" : false
    }
  },
  "id" : 340479868686962689,
  "created_at" : "Fri May 31 14:48:21 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Omid Ashtari",
      "screen_name" : "omid",
      "indices" : [ 0, 5 ],
      "id_str" : "114971521",
      "id" : 114971521
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "340324454854971392",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597708316, -122.2755821518 ]
  },
  "id_str" : "340324691782823936",
  "in_reply_to_user_id" : 114971521,
  "text" : "@omid Yeah, Math Workout. The online world challenge is quite addictive.",
  "id" : 340324691782823936,
  "in_reply_to_status_id" : 340324454854971392,
  "created_at" : "Fri May 31 04:31:44 +0000 2013",
  "in_reply_to_screen_name" : "omid",
  "in_reply_to_user_id_str" : "114971521",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http://t.co/8pr3R7sEPC",
      "expanded_url" : "http://flic.kr/p/eyjt7G",
      "display_url" : "flic.kr/p/eyjt7G"
    } ]
  },
  "geo" : {
  },
  "id_str" : "340323664769732608",
  "text" : "8:36pm Was putting Niko to bed but now just scoring horribly on Math Workout's world challenge http://t.co/8pr3R7sEPC",
  "id" : 340323664769732608,
  "created_at" : "Fri May 31 04:27:39 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://vine.co\" rel=\"nofollow\">Vine - Make a Scene</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 36 ],
      "url" : "https://t.co/3Qb46FIlBq",
      "expanded_url" : "https://vine.co/v/bYTuwqQdzm7",
      "display_url" : "vine.co/v/bYTuwqQdzm7"
    } ]
  },
  "geo" : {
  },
  "id_str" : "340306915890438144",
  "text" : "Kale-stealer https://t.co/3Qb46FIlBq",
  "id" : 340306915890438144,
  "created_at" : "Fri May 31 03:21:06 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Damon Cortesi",
      "screen_name" : "dacort",
      "indices" : [ 0, 7 ],
      "id_str" : "99723",
      "id" : 99723
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "340215858351706112",
  "geo" : {
  },
  "id_str" : "340235214934638595",
  "in_reply_to_user_id" : 99723,
  "text" : "@dacort Yeah, one of my favorite little corners of tweeterland.",
  "id" : 340235214934638595,
  "in_reply_to_status_id" : 340215858351706112,
  "created_at" : "Thu May 30 22:36:11 +0000 2013",
  "in_reply_to_screen_name" : "dacort",
  "in_reply_to_user_id_str" : "99723",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "harryh",
      "screen_name" : "harryh",
      "indices" : [ 0, 7 ],
      "id_str" : "4558",
      "id" : 4558
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "340212017304580096",
  "geo" : {
  },
  "id_str" : "340212977355599873",
  "in_reply_to_user_id" : 4558,
  "text" : "@harryh Sadly, no. Possibly through the API, but I haven't checked lately.",
  "id" : 340212977355599873,
  "in_reply_to_status_id" : 340212017304580096,
  "created_at" : "Thu May 30 21:07:49 +0000 2013",
  "in_reply_to_screen_name" : "harryh",
  "in_reply_to_user_id_str" : "4558",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zachary Jeans",
      "screen_name" : "zacharyjeans",
      "indices" : [ 0, 13 ],
      "id_str" : "16267003",
      "id" : 16267003
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 52 ],
      "url" : "https://t.co/CCkGhgMWxJ",
      "expanded_url" : "https://twitter.com/TwitterForNews/status/340206438364368896",
      "display_url" : "twitter.com/TwitterForNews\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "340209163286241280",
  "geo" : {
  },
  "id_str" : "340209418316681216",
  "in_reply_to_user_id" : 16267003,
  "text" : "@zacharyjeans No, just this: https://t.co/CCkGhgMWxJ",
  "id" : 340209418316681216,
  "in_reply_to_status_id" : 340209163286241280,
  "created_at" : "Thu May 30 20:53:40 +0000 2013",
  "in_reply_to_screen_name" : "zacharyjeans",
  "in_reply_to_user_id_str" : "16267003",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "340208034682908672",
  "text" : "Awesome update to Twitter Lists: You can now make up to 1,000 lists (up from 20), and each list can include up to 5,000 accounts.",
  "id" : 340208034682908672,
  "created_at" : "Thu May 30 20:48:10 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Daigle",
      "screen_name" : "kdaigle",
      "indices" : [ 0, 8 ],
      "id_str" : "4958621",
      "id" : 4958621
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "340074321143816192",
  "geo" : {
  },
  "id_str" : "340111920742932481",
  "in_reply_to_user_id" : 4958621,
  "text" : "@kdaigle 2 for 2 so far.",
  "id" : 340111920742932481,
  "in_reply_to_status_id" : 340074321143816192,
  "created_at" : "Thu May 30 14:26:15 +0000 2013",
  "in_reply_to_screen_name" : "kdaigle",
  "in_reply_to_user_id_str" : "4958621",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DietBet",
      "screen_name" : "DietBet",
      "indices" : [ 13, 21 ],
      "id_str" : "185399301",
      "id" : 185399301
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http://t.co/O3eSi33P4M",
      "expanded_url" : "http://www.dietbet.com/games/16030",
      "display_url" : "dietbet.com/games/16030"
    } ]
  },
  "geo" : {
  },
  "id_str" : "339994518151639041",
  "text" : "Doing my 3rd @dietbet starting June 1st. You should join! Only $25 on the line this time but over $10k in the pot: http://t.co/O3eSi33P4M",
  "id" : 339994518151639041,
  "created_at" : "Thu May 30 06:39:44 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erica Anderson",
      "screen_name" : "EricaAmerica",
      "indices" : [ 0, 13 ],
      "id_str" : "14124673",
      "id" : 14124673
    }, {
      "name" : "Dan Rollman",
      "screen_name" : "snerko",
      "indices" : [ 14, 21 ],
      "id_str" : "11915002",
      "id" : 11915002
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/buster/status/339989109638565888/photo/1",
      "indices" : [ 35, 57 ],
      "url" : "http://t.co/vc1AwZMb1a",
      "media_url" : "http://pbs.twimg.com/media/BLfiSzwCEAE8nXl.jpg",
      "id_str" : "339989109646954497",
      "id" : 339989109646954497,
      "media_url_https" : "https://pbs.twimg.com/media/BLfiSzwCEAE8nXl.jpg",
      "sizes" : [ {
        "h" : 1496,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 438,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 248,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 748,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com/vc1AwZMb1a"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "339982028617416704",
  "geo" : {
  },
  "id_str" : "339989109638565888",
  "in_reply_to_user_id" : 14124673,
  "text" : "@EricaAmerica @snerko Orkut'ed it: http://t.co/vc1AwZMb1a",
  "id" : 339989109638565888,
  "in_reply_to_status_id" : 339982028617416704,
  "created_at" : "Thu May 30 06:18:15 +0000 2013",
  "in_reply_to_screen_name" : "EricaAmerica",
  "in_reply_to_user_id_str" : "14124673",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Medium",
      "screen_name" : "Medium",
      "indices" : [ 3, 10 ],
      "id_str" : "571202103",
      "id" : 571202103
    }, {
      "name" : "Jason Oberholtzer",
      "screen_name" : "ilovecharts",
      "indices" : [ 69, 81 ],
      "id_str" : "116498184",
      "id" : 116498184
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "339972131976773632",
  "text" : "RT @Medium: He may never get the dating advice he's looking for, but @ilovecharts sure knows a lot about Kim Kardashian:  https://t.co/XXHP\u2026",
  "retweeted_status" : {
    "source" : "<a href=\"http://sproutsocial.com\" rel=\"nofollow\">Sprout Social</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jason Oberholtzer",
        "screen_name" : "ilovecharts",
        "indices" : [ 57, 69 ],
        "id_str" : "116498184",
        "id" : 116498184
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 110, 133 ],
        "url" : "https://t.co/XXHPLWeC6t",
        "expanded_url" : "https://medium.com/dating-advice-from-the-internet/93cecb8b67d5?utm_source=GoogleplusAccount&utm_medium=googleplus&utm_campaign=GoogleplusAccount",
        "display_url" : "medium.com/dating-advice-\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "339969673552592897",
    "text" : "He may never get the dating advice he's looking for, but @ilovecharts sure knows a lot about Kim Kardashian:  https://t.co/XXHPLWeC6t",
    "id" : 339969673552592897,
    "created_at" : "Thu May 30 05:01:01 +0000 2013",
    "user" : {
      "name" : "Medium",
      "screen_name" : "Medium",
      "protected" : false,
      "id_str" : "571202103",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2504297462/wtbq3hoquj8no6t2ysz4_normal.jpeg",
      "id" : 571202103,
      "verified" : true
    }
  },
  "id" : 339972131976773632,
  "created_at" : "Thu May 30 05:10:47 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Freitas",
      "screen_name" : "ryanchris",
      "indices" : [ 0, 10 ],
      "id_str" : "13349",
      "id" : 13349
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "339962053190103040",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597251236, -122.2756649117 ]
  },
  "id_str" : "339963302069276672",
  "in_reply_to_user_id" : 13349,
  "text" : "@ryanchris I've tested it on myself and found it to be a way to imagine visual imagery, but the direction isn't consistent with everyone.",
  "id" : 339963302069276672,
  "in_reply_to_status_id" : 339962053190103040,
  "created_at" : "Thu May 30 04:35:42 +0000 2013",
  "in_reply_to_screen_name" : "ryanchris",
  "in_reply_to_user_id_str" : "13349",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Freitas",
      "screen_name" : "ryanchris",
      "indices" : [ 0, 10 ],
      "id_str" : "13349",
      "id" : 13349
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "339959751205060608",
  "geo" : {
  },
  "id_str" : "339961858977067008",
  "in_reply_to_user_id" : 13349,
  "text" : "@ryanchris Not quite. It's associated with  imagination.",
  "id" : 339961858977067008,
  "in_reply_to_status_id" : 339959751205060608,
  "created_at" : "Thu May 30 04:29:58 +0000 2013",
  "in_reply_to_screen_name" : "ryanchris",
  "in_reply_to_user_id_str" : "13349",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http://t.co/5YStQ2sRQ9",
      "expanded_url" : "http://flic.kr/p/excANP",
      "display_url" : "flic.kr/p/excANP"
    } ]
  },
  "geo" : {
  },
  "id_str" : "339949628353032192",
  "text" : "8:36pm Me: \"When did you learn how to use a track pad?\" Niko: \"I don't know!\" http://t.co/5YStQ2sRQ9",
  "id" : 339949628353032192,
  "created_at" : "Thu May 30 03:41:22 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niko Benson",
      "screen_name" : "nikobenson",
      "indices" : [ 3, 14 ],
      "id_str" : "142467448",
      "id" : 142467448
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/buster/status/339946812871962625/photo/1",
      "indices" : [ 112, 134 ],
      "url" : "http://t.co/pSGI6zdUA1",
      "media_url" : "http://pbs.twimg.com/media/BLe700BCcAE4soj.jpg",
      "id_str" : "339946812880351233",
      "id" : 339946812880351233,
      "media_url_https" : "https://pbs.twimg.com/media/BLe700BCcAE4soj.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com/pSGI6zdUA1"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "339946812871962625",
  "text" : "So @nikobenson (3.01 years) just figured out how to use a track pad to click on Mr. Rogers' flash trolley game. http://t.co/pSGI6zdUA1",
  "id" : 339946812871962625,
  "created_at" : "Thu May 30 03:30:10 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Jackson",
      "screen_name" : "mjackson",
      "indices" : [ 0, 9 ],
      "id_str" : "734903",
      "id" : 734903
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "339821657319428097",
  "geo" : {
  },
  "id_str" : "339821837540265984",
  "in_reply_to_user_id" : 734903,
  "text" : "@mjackson I paid $500 for bud.ge a couple years ago, which I thought was low.",
  "id" : 339821837540265984,
  "in_reply_to_status_id" : 339821657319428097,
  "created_at" : "Wed May 29 19:13:34 +0000 2013",
  "in_reply_to_screen_name" : "mjackson",
  "in_reply_to_user_id_str" : "734903",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Wolf",
      "screen_name" : "agaricus",
      "indices" : [ 0, 9 ],
      "id_str" : "21678279",
      "id" : 21678279
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "339807998111264768",
  "geo" : {
  },
  "id_str" : "339808227963318272",
  "in_reply_to_user_id" : 2185,
  "text" : "@agaricus Ah, nevermind, they're the same thing! Good to know it has an official name too. :)",
  "id" : 339808227963318272,
  "in_reply_to_status_id" : 339807998111264768,
  "created_at" : "Wed May 29 18:19:29 +0000 2013",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Wolf",
      "screen_name" : "agaricus",
      "indices" : [ 0, 9 ],
      "id_str" : "21678279",
      "id" : 21678279
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "338400164886745088",
  "geo" : {
  },
  "id_str" : "339807998111264768",
  "in_reply_to_user_id" : 21678279,
  "text" : "@agaricus It was the Tilden Park steam train, but now I'm very interested in learning more about the Redwood Valley Railroad!",
  "id" : 339807998111264768,
  "in_reply_to_status_id" : 338400164886745088,
  "created_at" : "Wed May 29 18:18:34 +0000 2013",
  "in_reply_to_screen_name" : "agaricus",
  "in_reply_to_user_id_str" : "21678279",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 13, 21 ],
      "id_str" : "783214",
      "id" : 783214
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cooldemo",
      "indices" : [ 0, 9 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https://t.co/PBuyd9ZT6s",
      "expanded_url" : "https://vine.co/v/bY5dEjLxeJd",
      "display_url" : "vine.co/v/bY5dEjLxeJd"
    } ]
  },
  "geo" : {
  },
  "id_str" : "339804996730228736",
  "text" : "#cooldemo RT @twitter: Tweet a photo in under six seconds with our new mobile update! https://t.co/PBuyd9ZT6s",
  "id" : 339804996730228736,
  "created_at" : "Wed May 29 18:06:39 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "339780416066187265",
  "text" : "Finished \"Intuition Pump\" which was the best philosophy book I've read in a while. On to \"American Gods\" for a fiction break.",
  "id" : 339780416066187265,
  "created_at" : "Wed May 29 16:28:58 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 32, 42 ],
      "id_str" : "7362142",
      "id" : 7362142
    }, {
      "name" : "April Schiller",
      "screen_name" : "the_april",
      "indices" : [ 47, 57 ],
      "id_str" : "16644937",
      "id" : 16644937
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "deeeelicious",
      "indices" : [ 58, 71 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http://t.co/d9mUZbZW01",
      "expanded_url" : "http://flic.kr/p/ewfggR",
      "display_url" : "flic.kr/p/ewfggR"
    } ]
  },
  "geo" : {
  },
  "id_str" : "339616591769640960",
  "text" : "Bo Ssam bday dinner courtesy of @kellianne and @the_april #deeeelicious http://t.co/d9mUZbZW01",
  "id" : 339616591769640960,
  "created_at" : "Wed May 29 05:37:59 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://vine.co\" rel=\"nofollow\">Vine - Make a Scene</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 45 ],
      "url" : "https://t.co/scIFBvZvJp",
      "expanded_url" : "https://vine.co/v/bYhK1Ki09vi",
      "display_url" : "vine.co/v/bYhK1Ki09vi"
    } ]
  },
  "geo" : {
  },
  "id_str" : "339613660022448128",
  "text" : "Babies holding babies https://t.co/scIFBvZvJp",
  "id" : 339613660022448128,
  "created_at" : "Wed May 29 05:26:20 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http://t.co/MkdLLFCtP2",
      "expanded_url" : "http://flic.kr/p/ewfcjd",
      "display_url" : "flic.kr/p/ewfcjd"
    } ]
  },
  "geo" : {
  },
  "id_str" : "339593778081964033",
  "text" : "8:36pm Enjoying the company of these friendly people http://t.co/MkdLLFCtP2",
  "id" : 339593778081964033,
  "created_at" : "Wed May 29 04:07:20 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "adam tratt",
      "screen_name" : "adamtr",
      "indices" : [ 35, 42 ],
      "id_str" : "9981012",
      "id" : 9981012
    }, {
      "name" : "Haiku Deck",
      "screen_name" : "HaikuDeck",
      "indices" : [ 46, 56 ],
      "id_str" : "352538333",
      "id" : 352538333
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "awesome",
      "indices" : [ 95, 103 ]
    } ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http://t.co/82Z38cafB9",
      "expanded_url" : "http://www.haikudeck.com/p/B3hAtme6JU",
      "display_url" : "haikudeck.com/p/B3hAtme6JU"
    } ]
  },
  "geo" : {
  },
  "id_str" : "339537858132058113",
  "text" : "The history of the spreadsheet, by @adamtr in @haikudeck: http://t.co/82Z38cafB9 Thanks, Adam! #awesome",
  "id" : 339537858132058113,
  "created_at" : "Wed May 29 00:25:08 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "adam tratt",
      "screen_name" : "adamtr",
      "indices" : [ 0, 7 ],
      "id_str" : "9981012",
      "id" : 9981012
    }, {
      "name" : "Haiku Deck",
      "screen_name" : "HaikuDeck",
      "indices" : [ 8, 18 ],
      "id_str" : "352538333",
      "id" : 352538333
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "339511775345119232",
  "geo" : {
  },
  "id_str" : "339528033897684992",
  "in_reply_to_user_id" : 9981012,
  "text" : "@adamtr @haikudeck Absolutely!",
  "id" : 339528033897684992,
  "in_reply_to_status_id" : 339511775345119232,
  "created_at" : "Tue May 28 23:46:06 +0000 2013",
  "in_reply_to_screen_name" : "adamtr",
  "in_reply_to_user_id_str" : "9981012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "susan wu",
      "screen_name" : "sw",
      "indices" : [ 0, 3 ],
      "id_str" : "893211",
      "id" : 893211
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "339495241130340352",
  "geo" : {
  },
  "id_str" : "339495995916304384",
  "in_reply_to_user_id" : 893211,
  "text" : "@sw Thanks, Susan!",
  "id" : 339495995916304384,
  "in_reply_to_status_id" : 339495241130340352,
  "created_at" : "Tue May 28 21:38:47 +0000 2013",
  "in_reply_to_screen_name" : "sw",
  "in_reply_to_user_id_str" : "893211",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sharon",
      "screen_name" : "sharon",
      "indices" : [ 0, 7 ],
      "id_str" : "260",
      "id" : 260
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "339487212905304064",
  "geo" : {
  },
  "id_str" : "339487508033314816",
  "in_reply_to_user_id" : 260,
  "text" : "@sharon On August 9th, you'll have exactly 43 years of life expectancy left. Enjoy! :)",
  "id" : 339487508033314816,
  "in_reply_to_status_id" : 339487212905304064,
  "created_at" : "Tue May 28 21:05:03 +0000 2013",
  "in_reply_to_screen_name" : "sharon",
  "in_reply_to_user_id_str" : "260",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "339481945518006272",
  "geo" : {
  },
  "id_str" : "339483317210587136",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez Thanks, Ernesto!",
  "id" : 339483317210587136,
  "in_reply_to_status_id" : 339481945518006272,
  "created_at" : "Tue May 28 20:48:24 +0000 2013",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://bufferapp.com\" rel=\"nofollow\">Buffer</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http://t.co/Uwl8MNTktx",
      "expanded_url" : "http://bit.ly/12ffIM7",
      "display_url" : "bit.ly/12ffIM7"
    } ]
  },
  "geo" : {
  },
  "id_str" : "339457345304289282",
  "text" : "Updated my manifesto for living, beliefs file, and motto for year 37: http://t.co/Uwl8MNTktx",
  "id" : 339457345304289282,
  "created_at" : "Tue May 28 19:05:12 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "339447678817693696",
  "text" : "Has someone written a dramatic history of the spreadsheet? I would totally read that.",
  "id" : 339447678817693696,
  "created_at" : "Tue May 28 18:26:47 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Winnie Lim",
      "screen_name" : "wynlim",
      "indices" : [ 0, 7 ],
      "id_str" : "7729652",
      "id" : 7729652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "339444994186293248",
  "geo" : {
  },
  "id_str" : "339445285644279808",
  "in_reply_to_user_id" : 7729652,
  "text" : "@wynlim Thanks, Winnie!",
  "id" : 339445285644279808,
  "in_reply_to_status_id" : 339444994186293248,
  "created_at" : "Tue May 28 18:17:17 +0000 2013",
  "in_reply_to_screen_name" : "wynlim",
  "in_reply_to_user_id_str" : "7729652",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "calliaphone",
      "screen_name" : "calliaphone",
      "indices" : [ 0, 12 ],
      "id_str" : "63510137",
      "id" : 63510137
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "339442232622977024",
  "geo" : {
  },
  "id_str" : "339442947332403200",
  "in_reply_to_user_id" : 63510137,
  "text" : "@calliaphone I need to figure out if the SMS-provider I'm using supports more countries now\u2026 they might.",
  "id" : 339442947332403200,
  "in_reply_to_status_id" : 339442232622977024,
  "created_at" : "Tue May 28 18:07:59 +0000 2013",
  "in_reply_to_screen_name" : "calliaphone",
  "in_reply_to_user_id_str" : "63510137",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jill Slowbloom",
      "screen_name" : "outseide",
      "indices" : [ 0, 9 ],
      "id_str" : "143694663",
      "id" : 143694663
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "339441386728333312",
  "geo" : {
  },
  "id_str" : "339442767291891712",
  "in_reply_to_user_id" : 143694663,
  "text" : "@outseide Thanks, Jill!",
  "id" : 339442767291891712,
  "in_reply_to_status_id" : 339441386728333312,
  "created_at" : "Tue May 28 18:07:16 +0000 2013",
  "in_reply_to_screen_name" : "outseide",
  "in_reply_to_user_id_str" : "143694663",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Goldberg",
      "screen_name" : "bostonsteamer",
      "indices" : [ 0, 14 ],
      "id_str" : "2029651",
      "id" : 2029651
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "339440963351105536",
  "geo" : {
  },
  "id_str" : "339442672517394433",
  "in_reply_to_user_id" : 2029651,
  "text" : "@bostonsteamer Thanks, Joe!",
  "id" : 339442672517394433,
  "in_reply_to_status_id" : 339440963351105536,
  "created_at" : "Tue May 28 18:06:54 +0000 2013",
  "in_reply_to_screen_name" : "bostonsteamer",
  "in_reply_to_user_id_str" : "2029651",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ali Berman",
      "screen_name" : "spangley",
      "indices" : [ 0, 9 ],
      "id_str" : "776429",
      "id" : 776429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "339439301341372416",
  "geo" : {
  },
  "id_str" : "339442640921694208",
  "in_reply_to_user_id" : 776429,
  "text" : "@spangley Thanks, Ali!",
  "id" : 339442640921694208,
  "in_reply_to_status_id" : 339439301341372416,
  "created_at" : "Tue May 28 18:06:46 +0000 2013",
  "in_reply_to_screen_name" : "spangley",
  "in_reply_to_user_id_str" : "776429",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Silas",
      "screen_name" : "matty8r",
      "indices" : [ 0, 8 ],
      "id_str" : "1657191",
      "id" : 1657191
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "339440130756591617",
  "geo" : {
  },
  "id_str" : "339440392812523520",
  "in_reply_to_user_id" : 1657191,
  "text" : "@matty8r Thanks! If iMessage had an API I would totally integrate it.",
  "id" : 339440392812523520,
  "in_reply_to_status_id" : 339440130756591617,
  "created_at" : "Tue May 28 17:57:50 +0000 2013",
  "in_reply_to_screen_name" : "matty8r",
  "in_reply_to_user_id_str" : "1657191",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fred Oliveira",
      "screen_name" : "f",
      "indices" : [ 0, 2 ],
      "id_str" : "5511",
      "id" : 5511
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "339438434659729408",
  "geo" : {
  },
  "id_str" : "339438756190892032",
  "in_reply_to_user_id" : 5511,
  "text" : "@f Thanks! It's definitely something that I built to scratch my own itch.",
  "id" : 339438756190892032,
  "in_reply_to_status_id" : 339438434659729408,
  "created_at" : "Tue May 28 17:51:20 +0000 2013",
  "in_reply_to_screen_name" : "f",
  "in_reply_to_user_id_str" : "5511",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 29 ],
      "url" : "http://t.co/E6jcaxhW1J",
      "expanded_url" : "http://peabrain.co",
      "display_url" : "peabrain.co"
    } ]
  },
  "geo" : {
  },
  "id_str" : "339437958614634497",
  "text" : "Dusted http://t.co/E6jcaxhW1J off a bit last weekend. Check it out if a private SMS-based journal that has analytics is of any interest.",
  "id" : 339437958614634497,
  "created_at" : "Tue May 28 17:48:10 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arjun Balaji",
      "screen_name" : "arjunblj",
      "indices" : [ 0, 9 ],
      "id_str" : "25552514",
      "id" : 25552514
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hashtags",
      "indices" : [ 21, 30 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "339413319616196608",
  "geo" : {
  },
  "id_str" : "339422835917340672",
  "in_reply_to_user_id" : 25552514,
  "text" : "@arjunblj If you use #hashtags repeatedly in your notes they'll start showing up after a day or two.",
  "id" : 339422835917340672,
  "in_reply_to_status_id" : 339413319616196608,
  "created_at" : "Tue May 28 16:48:04 +0000 2013",
  "in_reply_to_screen_name" : "arjunblj",
  "in_reply_to_user_id_str" : "25552514",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "April Schiller",
      "screen_name" : "the_april",
      "indices" : [ 0, 10 ],
      "id_str" : "16644937",
      "id" : 16644937
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "339408580874731521",
  "geo" : {
  },
  "id_str" : "339412857034797056",
  "in_reply_to_user_id" : 16644937,
  "text" : "@the_april Glassbaby... comes in turquoise, flesh, and pink. \uD83C\uDFB6\uD83C\uDFB7",
  "id" : 339412857034797056,
  "in_reply_to_status_id" : 339408580874731521,
  "created_at" : "Tue May 28 16:08:25 +0000 2013",
  "in_reply_to_screen_name" : "the_april",
  "in_reply_to_user_id_str" : "16644937",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arjun Balaji",
      "screen_name" : "arjunblj",
      "indices" : [ 0, 9 ],
      "id_str" : "25552514",
      "id" : 25552514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "339404695028252673",
  "geo" : {
  },
  "id_str" : "339412591094943744",
  "in_reply_to_user_id" : 25552514,
  "text" : "@arjunblj Awesome! What resonates with you?",
  "id" : 339412591094943744,
  "in_reply_to_status_id" : 339404695028252673,
  "created_at" : "Tue May 28 16:07:22 +0000 2013",
  "in_reply_to_screen_name" : "arjunblj",
  "in_reply_to_user_id_str" : "25552514",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kenton Kivestu",
      "screen_name" : "kivestu",
      "indices" : [ 0, 8 ],
      "id_str" : "14906420",
      "id" : 14906420
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "339403078824501248",
  "geo" : {
  },
  "id_str" : "339412496316248064",
  "in_reply_to_user_id" : 14906420,
  "text" : "@kivestu Thanks, Kenton!",
  "id" : 339412496316248064,
  "in_reply_to_status_id" : 339403078824501248,
  "created_at" : "Tue May 28 16:06:59 +0000 2013",
  "in_reply_to_screen_name" : "kivestu",
  "in_reply_to_user_id_str" : "14906420",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://bufferapp.com\" rel=\"nofollow\">Buffer</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 46 ],
      "url" : "http://t.co/EzTtiQOb3Y",
      "expanded_url" : "http://bit.ly/115zWBB",
      "display_url" : "bit.ly/115zWBB"
    } ]
  },
  "geo" : {
  },
  "id_str" : "339408505335320576",
  "text" : "Thoughts on turning 37: http://t.co/EzTtiQOb3Y",
  "id" : 339408505335320576,
  "created_at" : "Tue May 28 15:51:08 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http://t.co/A2GpvX9Al0",
      "expanded_url" : "http://wayoftheduck.com/37",
      "display_url" : "wayoftheduck.com/37"
    } ]
  },
  "geo" : {
  },
  "id_str" : "339386405102956545",
  "text" : "http://t.co/A2GpvX9Al0",
  "id" : 339386405102956545,
  "created_at" : "Tue May 28 14:23:19 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Bonner",
      "screen_name" : "seanbonner",
      "indices" : [ 0, 11 ],
      "id_str" : "765",
      "id" : 765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "339242844529258496",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597649964, -122.2755058165 ]
  },
  "id_str" : "339248426967523328",
  "in_reply_to_user_id" : 765,
  "text" : "@seanbonner What regrets will you most likely have on your death bed?",
  "id" : 339248426967523328,
  "in_reply_to_status_id" : 339242844529258496,
  "created_at" : "Tue May 28 05:15:02 +0000 2013",
  "in_reply_to_screen_name" : "seanbonner",
  "in_reply_to_user_id_str" : "765",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "April Schiller",
      "screen_name" : "the_april",
      "indices" : [ 21, 31 ],
      "id_str" : "16644937",
      "id" : 16644937
    }, {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 36, 46 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http://t.co/96xcqs5eTG",
      "expanded_url" : "http://flic.kr/p/evbtrf",
      "display_url" : "flic.kr/p/evbtrf"
    } ]
  },
  "geo" : {
  },
  "id_str" : "339225966238904320",
  "text" : "8:36pm Niko captures @the_april and @kellianne talking kanban boards http://t.co/96xcqs5eTG",
  "id" : 339225966238904320,
  "created_at" : "Tue May 28 03:45:47 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://vine.co\" rel=\"nofollow\">Vine - Make a Scene</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 52 ],
      "url" : "https://t.co/CYY8VsHuqg",
      "expanded_url" : "https://vine.co/v/bVlVWnODBU7",
      "display_url" : "vine.co/v/bVlVWnODBU7"
    } ]
  },
  "geo" : {
  },
  "id_str" : "339205844262600704",
  "text" : "Niko got me this for my bday https://t.co/CYY8VsHuqg",
  "id" : 339205844262600704,
  "created_at" : "Tue May 28 02:25:50 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/buster/status/339203493430706176/photo/1",
      "indices" : [ 113, 135 ],
      "url" : "http://t.co/Sos3RDq0Xg",
      "media_url" : "http://pbs.twimg.com/media/BLUXx7UCQAAkCYs.jpg",
      "id_str" : "339203493439094784",
      "id" : 339203493439094784,
      "media_url_https" : "https://pbs.twimg.com/media/BLUXx7UCQAAkCYs.jpg",
      "sizes" : [ {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      } ],
      "display_url" : "pic.twitter.com/Sos3RDq0Xg"
    } ],
    "hashtags" : [ {
      "text" : "kiloslog",
      "indices" : [ 15, 24 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "339203493430706176",
  "text" : "949. Moving my #kiloslog tracking over to peabrain.co where I don't feel the need to filter *super* boring stuff http://t.co/Sos3RDq0Xg",
  "id" : 339203493430706176,
  "created_at" : "Tue May 28 02:16:29 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "339193472449925120",
  "geo" : {
  },
  "id_str" : "339201847841665025",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez I run with headphones and the RunKeeper voice-overs, which work well for me... what number(s) do you want to access?",
  "id" : 339201847841665025,
  "in_reply_to_status_id" : 339193472449925120,
  "created_at" : "Tue May 28 02:09:57 +0000 2013",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    }, {
      "name" : "Basis",
      "screen_name" : "mybasis",
      "indices" : [ 50, 58 ],
      "id_str" : "216453702",
      "id" : 216453702
    }, {
      "name" : "Pebble",
      "screen_name" : "Pebble",
      "indices" : [ 102, 109 ],
      "id_str" : "515766653",
      "id" : 515766653
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "339188358767063040",
  "geo" : {
  },
  "id_str" : "339190555030474752",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez I don't. Still holding out hope for the @mybasis, but if my next unit doesn't work I'll try @pebble. Curious about Apple too.",
  "id" : 339190555030474752,
  "in_reply_to_status_id" : 339188358767063040,
  "created_at" : "Tue May 28 01:25:04 +0000 2013",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    }, {
      "name" : "Jun",
      "screen_name" : "junnibug",
      "indices" : [ 10, 19 ],
      "id_str" : "19210703",
      "id" : 19210703
    }, {
      "name" : "Pebble",
      "screen_name" : "Pebble",
      "indices" : [ 20, 27 ],
      "id_str" : "515766653",
      "id" : 515766653
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "339139310542520321",
  "geo" : {
  },
  "id_str" : "339187732142235649",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez @junnibug @pebble That *does* look worth checking out.",
  "id" : 339187732142235649,
  "in_reply_to_status_id" : 339139310542520321,
  "created_at" : "Tue May 28 01:13:51 +0000 2013",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Bogan",
      "screen_name" : "waferbaby",
      "indices" : [ 3, 13 ],
      "id_str" : "821753",
      "id" : 821753
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "339116746680172544",
  "text" : "RT @waferbaby: NewFlickr: we had an aggressive deadline, this is just the beginning, and if you want to help guide things instead of yellin\u2026",
  "retweeted_status" : {
    "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "337414014734848000",
    "text" : "NewFlickr: we had an aggressive deadline, this is just the beginning, and if you want to help guide things instead of yelling, we\u2019re hiring!",
    "id" : 337414014734848000,
    "created_at" : "Thu May 23 03:45:44 +0000 2013",
    "user" : {
      "name" : "Daniel Bogan",
      "screen_name" : "waferbaby",
      "protected" : false,
      "id_str" : "821753",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000065072823/da9d1c742f978ff86687465dd01fbb49_normal.jpeg",
      "id" : 821753,
      "verified" : false
    }
  },
  "id" : 339116746680172544,
  "created_at" : "Mon May 27 20:31:47 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jad Abumrad",
      "screen_name" : "JadAbumrad",
      "indices" : [ 3, 14 ],
      "id_str" : "135316691",
      "id" : 135316691
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "339051106460106753",
  "text" : "RT @JadAbumrad: Maybe I'm the last to see this AMAZING video of a woman concentrating REALLY HARD. Killer reveal at end - http://t.co/CVWJ6\u2026",
  "retweeted_status" : {
    "source" : "<a href=\"http://bufferapp.com\" rel=\"nofollow\">Buffer</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 106, 128 ],
        "url" : "http://t.co/CVWJ6z8dNB",
        "expanded_url" : "http://buff.ly/1aqE7w3",
        "display_url" : "buff.ly/1aqE7w3"
      } ]
    },
    "geo" : {
    },
    "id_str" : "339048389943644163",
    "text" : "Maybe I'm the last to see this AMAZING video of a woman concentrating REALLY HARD. Killer reveal at end - http://t.co/CVWJ6z8dNB",
    "id" : 339048389943644163,
    "created_at" : "Mon May 27 16:00:10 +0000 2013",
    "user" : {
      "name" : "Jad Abumrad",
      "screen_name" : "JadAbumrad",
      "protected" : false,
      "id_str" : "135316691",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1529014082/Jad-Pic2_normal.jpg",
      "id" : 135316691,
      "verified" : true
    }
  },
  "id" : 339051106460106753,
  "created_at" : "Mon May 27 16:10:57 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http://t.co/yFhpI5e1mt",
      "expanded_url" : "http://flic.kr/p/eu3mBS",
      "display_url" : "flic.kr/p/eu3mBS"
    } ]
  },
  "geo" : {
  },
  "id_str" : "338868325134245888",
  "text" : "8:36pm This guy ate a lot of dessert, including the leftovers he was holding in his bike trailer on the way home.  http://t.co/yFhpI5e1mt",
  "id" : 338868325134245888,
  "created_at" : "Mon May 27 04:04:39 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://vine.co\" rel=\"nofollow\">Vine - Make a Scene</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 44 ],
      "url" : "https://t.co/rbMrxgw6l1",
      "expanded_url" : "https://vine.co/v/bVxh3qp2BP7",
      "display_url" : "vine.co/v/bVxh3qp2BP7"
    } ]
  },
  "geo" : {
  },
  "id_str" : "338852389958320128",
  "text" : "Niko likes ice cream https://t.co/rbMrxgw6l1",
  "id" : 338852389958320128,
  "created_at" : "Mon May 27 03:01:19 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "newinvention",
      "indices" : [ 15, 28 ]
    } ],
    "urls" : [ {
      "indices" : [ 29, 51 ],
      "url" : "http://t.co/doPUawU71S",
      "expanded_url" : "http://flic.kr/p/etHU3Y",
      "display_url" : "flic.kr/p/etHU3Y"
    } ]
  },
  "geo" : {
  },
  "id_str" : "338760911768674304",
  "text" : "Apple sandwich #newinvention http://t.co/doPUawU71S",
  "id" : 338760911768674304,
  "created_at" : "Sun May 26 20:57:49 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zack Shapiro",
      "screen_name" : "ZackShapiro",
      "indices" : [ 0, 12 ],
      "id_str" : "15999465",
      "id" : 15999465
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "338713935807131648",
  "geo" : {
  },
  "id_str" : "338732026440060930",
  "in_reply_to_user_id" : 15999465,
  "text" : "@ZackShapiro I keep meaning to.",
  "id" : 338732026440060930,
  "in_reply_to_status_id" : 338713935807131648,
  "created_at" : "Sun May 26 19:03:03 +0000 2013",
  "in_reply_to_screen_name" : "ZackShapiro",
  "in_reply_to_user_id_str" : "15999465",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Les Hill",
      "screen_name" : "leshill",
      "indices" : [ 0, 8 ],
      "id_str" : "12495752",
      "id" : 12495752
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "338720934653489152",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597230166, -122.2755261488 ]
  },
  "id_str" : "338723474682032128",
  "in_reply_to_user_id" : 12495752,
  "text" : "@leshill Yeah that'll take a bit longer.",
  "id" : 338723474682032128,
  "in_reply_to_status_id" : 338720934653489152,
  "created_at" : "Sun May 26 18:29:04 +0000 2013",
  "in_reply_to_screen_name" : "leshill",
  "in_reply_to_user_id_str" : "12495752",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carinna Tarvin",
      "screen_name" : "carinnatarvin",
      "indices" : [ 0, 14 ],
      "id_str" : "20833838",
      "id" : 20833838
    }, {
      "name" : "April Schiller",
      "screen_name" : "the_april",
      "indices" : [ 15, 25 ],
      "id_str" : "16644937",
      "id" : 16644937
    }, {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 26, 36 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "338717550995206144",
  "geo" : {
  },
  "id_str" : "338718039614836737",
  "in_reply_to_user_id" : 20833838,
  "text" : "@carinnatarvin @the_april @kellianne We didn't try it! We were told that it was basically a Coke knock-off.",
  "id" : 338718039614836737,
  "in_reply_to_status_id" : 338717550995206144,
  "created_at" : "Sun May 26 18:07:28 +0000 2013",
  "in_reply_to_screen_name" : "carinnatarvin",
  "in_reply_to_user_id_str" : "20833838",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sharon",
      "screen_name" : "sharon",
      "indices" : [ 0, 7 ],
      "id_str" : "260",
      "id" : 260
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "338715954752135168",
  "geo" : {
  },
  "id_str" : "338717831346679808",
  "in_reply_to_user_id" : 260,
  "text" : "@sharon Ooh, let's discuss the differences! Also, I highly recommend people to make/maintain their own beliefs files\u2026 you should try it!",
  "id" : 338717831346679808,
  "in_reply_to_status_id" : 338715954752135168,
  "created_at" : "Sun May 26 18:06:38 +0000 2013",
  "in_reply_to_screen_name" : "sharon",
  "in_reply_to_user_id_str" : "260",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 55 ],
      "url" : "http://t.co/lQ606pTReQ",
      "expanded_url" : "http://bit.ly/Rk6Ijh",
      "display_url" : "bit.ly/Rk6Ijh"
    } ]
  },
  "geo" : {
  },
  "id_str" : "338713034157596673",
  "text" : "Cleaned up my Beliefs file a bit http://t.co/lQ606pTReQ",
  "id" : 338713034157596673,
  "created_at" : "Sun May 26 17:47:34 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grant Monroe",
      "screen_name" : "tnarg",
      "indices" : [ 0, 6 ],
      "id_str" : "36519354",
      "id" : 36519354
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "338706439558295552",
  "geo" : {
  },
  "id_str" : "338709662021083136",
  "in_reply_to_user_id" : 36519354,
  "text" : "@tnarg They match against their own usernames, and look for auth'd Twitter accounts. If it exists, they swap it in, otherwise they strip @.",
  "id" : 338709662021083136,
  "in_reply_to_status_id" : 338706439558295552,
  "created_at" : "Sun May 26 17:34:11 +0000 2013",
  "in_reply_to_screen_name" : "tnarg",
  "in_reply_to_user_id_str" : "36519354",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Prateek Sharma",
      "screen_name" : "prateeks",
      "indices" : [ 0, 9 ],
      "id_str" : "15436125",
      "id" : 15436125
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "338566142421499905",
  "geo" : {
  },
  "id_str" : "338580231361282048",
  "in_reply_to_user_id" : 15436125,
  "text" : "@prateeks That's what I hear! Do the millions appreciate the misspelling?",
  "id" : 338580231361282048,
  "in_reply_to_status_id" : 338566142421499905,
  "created_at" : "Sun May 26 08:59:52 +0000 2013",
  "in_reply_to_screen_name" : "prateeks",
  "in_reply_to_user_id_str" : "15436125",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ingopixel",
      "screen_name" : "ingopixel",
      "indices" : [ 0, 10 ],
      "id_str" : "7943892",
      "id" : 7943892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "338564920478150657",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597354576, -122.2754710704 ]
  },
  "id_str" : "338565426462224384",
  "in_reply_to_user_id" : 7943892,
  "text" : "@ingopixel This is good news.",
  "id" : 338565426462224384,
  "in_reply_to_status_id" : 338564920478150657,
  "created_at" : "Sun May 26 08:01:02 +0000 2013",
  "in_reply_to_screen_name" : "ingopixel",
  "in_reply_to_user_id_str" : "7943892",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 57 ],
      "url" : "http://t.co/qgJgZBIsfi",
      "expanded_url" : "http://instagram.com/p/Zw98tHI0OE/",
      "display_url" : "instagram.com/p/Zw98tHI0OE/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.87027, -122.266076 ]
  },
  "id_str" : "338544271336566784",
  "text" : "Thums up! @ East Bay Spice Company http://t.co/qgJgZBIsfi",
  "id" : 338544271336566784,
  "created_at" : "Sun May 26 06:36:58 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Maura McGovern",
      "screen_name" : "mmcgovern",
      "indices" : [ 0, 10 ],
      "id_str" : "15856582",
      "id" : 15856582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "338521838927896577",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8695507703, -122.2662187603 ]
  },
  "id_str" : "338529602794299392",
  "in_reply_to_user_id" : 15856582,
  "text" : "@mmcgovern Let's talk! Email me at busterbenson at gmail.",
  "id" : 338529602794299392,
  "in_reply_to_status_id" : 338521838927896577,
  "created_at" : "Sun May 26 05:38:41 +0000 2013",
  "in_reply_to_screen_name" : "mmcgovern",
  "in_reply_to_user_id_str" : "15856582",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "April Schiller",
      "screen_name" : "the_april",
      "indices" : [ 13, 23 ],
      "id_str" : "16644937",
      "id" : 16644937
    }, {
      "name" : "Gather Restaurant",
      "screen_name" : "GatherBerkeley",
      "indices" : [ 40, 55 ],
      "id_str" : "78127882",
      "id" : 78127882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http://t.co/JxAshdC9kn",
      "expanded_url" : "http://4sq.com/12VGo1c",
      "display_url" : "4sq.com/12VGo1c"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8695659746, -122.2660759947 ]
  },
  "id_str" : "338505650529255424",
  "text" : "Stop #2 with @the_april, Kellianne. (at @GatherBerkeley w/ 3 others) http://t.co/JxAshdC9kn",
  "id" : 338505650529255424,
  "created_at" : "Sun May 26 04:03:30 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Davidson",
      "screen_name" : "mikeindustries",
      "indices" : [ 0, 15 ],
      "id_str" : "74523",
      "id" : 74523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "338491398108114944",
  "geo" : {
  },
  "id_str" : "338501571048529920",
  "in_reply_to_user_id" : 74523,
  "text" : "@mikeindustries It was different but really good. Made from homemade beet-infused ginger beer. Felt healthy.",
  "id" : 338501571048529920,
  "in_reply_to_status_id" : 338491398108114944,
  "created_at" : "Sun May 26 03:47:18 +0000 2013",
  "in_reply_to_screen_name" : "mikeindustries",
  "in_reply_to_user_id_str" : "74523",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 71 ],
      "url" : "http://t.co/A3SmD7aEtd",
      "expanded_url" : "http://instagram.com/p/ZwqT5II0JP/",
      "display_url" : "instagram.com/p/ZwqT5II0JP/"
    } ]
  },
  "geo" : {
  },
  "id_str" : "338501278999138305",
  "text" : "8:36pm Biking birthday pub crawl in the East Bay http://t.co/A3SmD7aEtd",
  "id" : 338501278999138305,
  "created_at" : "Sun May 26 03:46:08 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 55 ],
      "url" : "http://t.co/not7G3mlsj",
      "expanded_url" : "http://instagram.com/p/ZwlrjRo0Bv/",
      "display_url" : "instagram.com/p/ZwlrjRo0Bv/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7937280584, -122.274480029 ]
  },
  "id_str" : "338491226384916480",
  "text" : "Beet-Infused Moscow Mule @ Haven http://t.co/not7G3mlsj",
  "id" : 338491226384916480,
  "created_at" : "Sun May 26 03:06:11 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 49 ],
      "url" : "http://t.co/wsKOi6XhUG",
      "expanded_url" : "http://flic.kr/p/erbyWM",
      "display_url" : "flic.kr/p/erbyWM"
    } ]
  },
  "geo" : {
  },
  "id_str" : "338399462835765248",
  "text" : "Holding the golden ticket  http://t.co/wsKOi6XhUG",
  "id" : 338399462835765248,
  "created_at" : "Sat May 25 21:01:33 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 29 ],
      "url" : "http://t.co/CkIp1wkF6A",
      "expanded_url" : "http://flic.kr/p/esetEA",
      "display_url" : "flic.kr/p/esetEA"
    } ]
  },
  "geo" : {
  },
  "id_str" : "338365692950745088",
  "text" : "Cuties http://t.co/CkIp1wkF6A",
  "id" : 338365692950745088,
  "created_at" : "Sat May 25 18:47:22 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "April Schiller",
      "screen_name" : "the_april",
      "indices" : [ 7, 17 ],
      "id_str" : "16644937",
      "id" : 16644937
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http://t.co/NcBX4HUY1t",
      "expanded_url" : "http://flic.kr/p/eqyutP",
      "display_url" : "flic.kr/p/eqyutP"
    } ]
  },
  "geo" : {
  },
  "id_str" : "338141845366390785",
  "text" : "8:36pm @the_april is in town for my birthday weekend. Who wants to get a drink with us tomorrow night? http://t.co/NcBX4HUY1t",
  "id" : 338141845366390785,
  "created_at" : "Sat May 25 03:57:52 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 35, 44 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "338020890732273664",
  "text" : "\"Cognitive dissonance is rough.\" - @eramirez",
  "id" : 338020890732273664,
  "created_at" : "Fri May 24 19:57:15 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CreativeMornings/SF",
      "screen_name" : "SanFrancisco_CM",
      "indices" : [ 18, 34 ],
      "id_str" : "234486602",
      "id" : 234486602
    }, {
      "name" : "Kevin Cheng",
      "screen_name" : "k",
      "indices" : [ 64, 66 ],
      "id_str" : "11222",
      "id" : 11222
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sfcm",
      "indices" : [ 131, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "337979377000267776",
  "text" : "Attended my first @sanfrancisco_cm Creative Morning talk, where @k convinced me to draw more. Gonna be coming to these more often! #sfcm",
  "id" : 337979377000267776,
  "created_at" : "Fri May 24 17:12:17 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Cheng",
      "screen_name" : "k",
      "indices" : [ 12, 14 ],
      "id_str" : "11222",
      "id" : 11222
    }, {
      "name" : "PARISOMA",
      "screen_name" : "parisoma",
      "indices" : [ 38, 47 ],
      "id_str" : "14556090",
      "id" : 14556090
    }, {
      "name" : "Kevin Cheng",
      "screen_name" : "k",
      "indices" : [ 51, 53 ],
      "id_str" : "11222",
      "id" : 11222
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "creativemornings",
      "indices" : [ 16, 33 ]
    } ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http://t.co/7ZXNdnD6PE",
      "expanded_url" : "http://4sq.com/11fu6we",
      "display_url" : "4sq.com/11fu6we"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7735175909, -122.4159818888 ]
  },
  "id_str" : "337959905019449345",
  "text" : "Here to see @k. #creativemornings (at @Parisoma w/ @k) http://t.co/7ZXNdnD6PE",
  "id" : 337959905019449345,
  "created_at" : "Fri May 24 15:54:55 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Davidson",
      "screen_name" : "mikeindustries",
      "indices" : [ 9, 24 ],
      "id_str" : "74523",
      "id" : 74523
    }, {
      "name" : "KING 5 News ",
      "screen_name" : "KING5Seattle",
      "indices" : [ 42, 55 ],
      "id_str" : "19430999",
      "id" : 19430999
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/KING5Seattle/status/337764910580785152/photo/1",
      "indices" : [ 108, 130 ],
      "url" : "http://t.co/us11Eg5Mzi",
      "media_url" : "http://pbs.twimg.com/media/BK_7ZYkCYAAb4F4.jpg",
      "id_str" : "337764910584979456",
      "id" : 337764910584979456,
      "media_url_https" : "https://pbs.twimg.com/media/BK_7ZYkCYAAb4F4.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1224,
        "resize" : "fit",
        "w" : 1632
      } ],
      "display_url" : "pic.twitter.com/us11Eg5Mzi"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "337797336711442432",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7937124763, -122.2745428049 ]
  },
  "id_str" : "337817959579926529",
  "in_reply_to_user_id" : 74523,
  "text" : "Woah. RT @mikeindustries: Amazing photo. \u201C@KING5Seattle: Photo of man on his car after I-5 bridge collapse: http://t.co/us11Eg5Mzi",
  "id" : 337817959579926529,
  "in_reply_to_status_id" : 337797336711442432,
  "created_at" : "Fri May 24 06:30:52 +0000 2013",
  "in_reply_to_screen_name" : "mikeindustries",
  "in_reply_to_user_id_str" : "74523",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://vine.co\" rel=\"nofollow\">Vine - Make a Scene</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 33 ],
      "url" : "https://t.co/CZTo7U9rwW",
      "expanded_url" : "https://vine.co/v/bVZYanWKDzF",
      "display_url" : "vine.co/v/bVZYanWKDzF"
    } ]
  },
  "geo" : {
  },
  "id_str" : "337810724158070785",
  "text" : "Song time https://t.co/CZTo7U9rwW",
  "id" : 337810724158070785,
  "created_at" : "Fri May 24 06:02:07 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http://t.co/cNV0vnVLBI",
      "expanded_url" : "http://flic.kr/p/eqygBW",
      "display_url" : "flic.kr/p/eqygBW"
    } ]
  },
  "geo" : {
  },
  "id_str" : "337807256844382209",
  "text" : "First and Last Chance, opened in 1833, built from the timbers of an old whaling ship http://t.co/cNV0vnVLBI",
  "id" : 337807256844382209,
  "created_at" : "Fri May 24 05:48:20 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helen Jane",
      "screen_name" : "helenjane",
      "indices" : [ 0, 10 ],
      "id_str" : "798542",
      "id" : 798542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "337749094351118336",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.79547079, -122.2703418789 ]
  },
  "id_str" : "337779095020646401",
  "in_reply_to_user_id" : 798542,
  "text" : "@helenjane We need to visit you again soon!",
  "id" : 337779095020646401,
  "in_reply_to_status_id" : 337749094351118336,
  "created_at" : "Fri May 24 03:56:26 +0000 2013",
  "in_reply_to_screen_name" : "helenjane",
  "in_reply_to_user_id_str" : "798542",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 67 ],
      "url" : "http://t.co/hFrxKU3twr",
      "expanded_url" : "http://flic.kr/p/equh2E",
      "display_url" : "flic.kr/p/equh2E"
    } ]
  },
  "geo" : {
  },
  "id_str" : "337775719528681472",
  "text" : "8:36pm Celebrating an early bday in Oakland! http://t.co/hFrxKU3twr",
  "id" : 337775719528681472,
  "created_at" : "Fri May 24 03:43:01 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http://t.co/eoT6gH9hYx",
      "expanded_url" : "http://flic.kr/p/epuAGR",
      "display_url" : "flic.kr/p/epuAGR"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859666, -122.2755 ]
  },
  "id_str" : "337745456530612224",
  "text" : "8:36pm Niko: \"Close the windows so I'm not scared by the wind.\" Me: \"Ok.\" Niko: \"Why am I scared by the wind?\" http://t.co/eoT6gH9hYx",
  "id" : 337745456530612224,
  "created_at" : "Fri May 24 01:42:46 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 7, 16 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http://t.co/RiltbyoZWz",
      "expanded_url" : "http://flic.kr/p/eqqfyq",
      "display_url" : "flic.kr/p/eqqfyq"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.775666, -122.4135 ]
  },
  "id_str" : "337741366207578113",
  "text" : "8:36pm @eramirez is wearing an LED necklace that displays his heart rate http://t.co/RiltbyoZWz",
  "id" : 337741366207578113,
  "created_at" : "Fri May 24 01:26:31 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "girl jo",
      "screen_name" : "octavekitten",
      "indices" : [ 0, 13 ],
      "id_str" : "16366882",
      "id" : 16366882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "337732486324944898",
  "geo" : {
  },
  "id_str" : "337732823505072130",
  "in_reply_to_user_id" : 16366882,
  "text" : "@octavekitten that is amazing.",
  "id" : 337732823505072130,
  "in_reply_to_status_id" : 337732486324944898,
  "created_at" : "Fri May 24 00:52:34 +0000 2013",
  "in_reply_to_screen_name" : "octavekitten",
  "in_reply_to_user_id_str" : "16366882",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Cheng",
      "screen_name" : "k",
      "indices" : [ 86, 88 ],
      "id_str" : "11222",
      "id" : 11222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http://t.co/riPyHXJW48",
      "expanded_url" : "http://sfcreativemornings-estw.eventbrite.com",
      "display_url" : "sfcreativemornings-estw.eventbrite.com"
    } ]
  },
  "geo" : {
  },
  "id_str" : "337732483359580161",
  "text" : "Gonna go to this tomorrow morning (7 tickets left!): Creative Mornings: Kevin Cheng  (@k) http://t.co/riPyHXJW48",
  "id" : 337732483359580161,
  "created_at" : "Fri May 24 00:51:13 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nancy Dougherty",
      "screen_name" : "nancyhd",
      "indices" : [ 0, 8 ],
      "id_str" : "19854731",
      "id" : 19854731
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "337702480798433282",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7763597077, -122.4175987999 ]
  },
  "id_str" : "337703406728798208",
  "in_reply_to_user_id" : 19854731,
  "text" : "@nancyhd I don't, unfortunately. Background + continuous is what I'm looking for too... I'll keep looking and report back.",
  "id" : 337703406728798208,
  "in_reply_to_status_id" : 337702480798433282,
  "created_at" : "Thu May 23 22:55:41 +0000 2013",
  "in_reply_to_screen_name" : "nancyhd",
  "in_reply_to_user_id_str" : "19854731",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nancy Dougherty",
      "screen_name" : "nancyhd",
      "indices" : [ 0, 8 ],
      "id_str" : "19854731",
      "id" : 19854731
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "337694628201500673",
  "geo" : {
  },
  "id_str" : "337696652230012928",
  "in_reply_to_user_id" : 19854731,
  "text" : "@nancyhd Following up from last night: what are your favorite kindness/compassion/stress sensors? Thoughts on HeartMath, emWave2, etc?",
  "id" : 337696652230012928,
  "in_reply_to_status_id" : 337694628201500673,
  "created_at" : "Thu May 23 22:28:50 +0000 2013",
  "in_reply_to_screen_name" : "nancyhd",
  "in_reply_to_user_id_str" : "19854731",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lift",
      "screen_name" : "liftapp",
      "indices" : [ 33, 41 ],
      "id_str" : "353195232",
      "id" : 353195232
    }, {
      "name" : "Buster",
      "screen_name" : "buster",
      "indices" : [ 116, 123 ],
      "id_str" : "2185",
      "id" : 2185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http://t.co/Xfvq48bGfS",
      "expanded_url" : "http://bit.ly/12KHDRe",
      "display_url" : "bit.ly/12KHDRe"
    } ]
  },
  "geo" : {
  },
  "id_str" : "337688242646286336",
  "text" : "The opposite of a tiny habit. RT @liftapp: How to build a habit in 1,000 steps: http://t.co/Xfvq48bGfS interview w/ @buster",
  "id" : 337688242646286336,
  "created_at" : "Thu May 23 21:55:25 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://bufferapp.com\" rel=\"nofollow\">Buffer</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Foursquare",
      "screen_name" : "foursquare",
      "indices" : [ 24, 35 ],
      "id_str" : "14120151",
      "id" : 14120151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http://t.co/ItHpILxQ5U",
      "expanded_url" : "http://bit.ly/13O835g",
      "display_url" : "bit.ly/13O835g"
    } ]
  },
  "geo" : {
  },
  "id_str" : "337670832052658176",
  "text" : "This is really cool: RT @foursquare Giving data nerds access to the realtime pulse of check-ins around the world http://t.co/ItHpILxQ5U",
  "id" : 337670832052658176,
  "created_at" : "Thu May 23 20:46:14 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Farhad Manjoo",
      "screen_name" : "fmanjoo",
      "indices" : [ 3, 11 ],
      "id_str" : "2195241",
      "id" : 2195241
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http://t.co/N7xugmK0po",
      "expanded_url" : "http://fm4.fm/14VSYO4",
      "display_url" : "fm4.fm/14VSYO4"
    } ]
  },
  "geo" : {
  },
  "id_str" : "337652315609776128",
  "text" : "RT @fmanjoo: Can You Find the Artist Hidden in this Photograph? THIS IS AMAZING. http://t.co/N7xugmK0po",
  "retweeted_status" : {
    "source" : "<a href=\"http://bitly.com\" rel=\"nofollow\">bitly</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 68, 90 ],
        "url" : "http://t.co/N7xugmK0po",
        "expanded_url" : "http://fm4.fm/14VSYO4",
        "display_url" : "fm4.fm/14VSYO4"
      } ]
    },
    "geo" : {
    },
    "id_str" : "337651864982142976",
    "text" : "Can You Find the Artist Hidden in this Photograph? THIS IS AMAZING. http://t.co/N7xugmK0po",
    "id" : 337651864982142976,
    "created_at" : "Thu May 23 19:30:52 +0000 2013",
    "user" : {
      "name" : "Farhad Manjoo",
      "screen_name" : "fmanjoo",
      "protected" : false,
      "id_str" : "2195241",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/52957485/farhad2_normal.jpg",
      "id" : 2195241,
      "verified" : true
    }
  },
  "id" : 337652315609776128,
  "created_at" : "Thu May 23 19:32:39 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Sippey",
      "screen_name" : "sippey",
      "indices" : [ 0, 7 ],
      "id_str" : "4711",
      "id" : 4711
    }, {
      "name" : "Jason Goldman",
      "screen_name" : "goldman",
      "indices" : [ 8, 16 ],
      "id_str" : "291",
      "id" : 291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "337433729188372480",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597249787, -122.2754943697 ]
  },
  "id_str" : "337452793042456577",
  "in_reply_to_user_id" : 4711,
  "text" : "@sippey @goldman Everything worth building was built by LiveJournal between 1998-2004.",
  "id" : 337452793042456577,
  "in_reply_to_status_id" : 337433729188372480,
  "created_at" : "Thu May 23 06:19:50 +0000 2013",
  "in_reply_to_screen_name" : "sippey",
  "in_reply_to_user_id_str" : "4711",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Dennett",
      "screen_name" : "danieldennett",
      "indices" : [ 103, 117 ],
      "id_str" : "997629601",
      "id" : 997629601
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8573320853, -122.2730516643 ]
  },
  "id_str" : "337440677543698434",
  "text" : "\"It is not so much that we, using our brains, spin yarns, as that our brains, using yarns, spin us.\" - @danieldennett",
  "id" : 337440677543698434,
  "created_at" : "Thu May 23 05:31:41 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Dennett",
      "screen_name" : "danieldennett",
      "indices" : [ 78, 92 ],
      "id_str" : "997629601",
      "id" : 997629601
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7983501841, -122.274514242 ]
  },
  "id_str" : "337436337445670912",
  "text" : "\"I'd rather have a free bottle in front of me than a pre-frontal lobotomy.\" - @danieldennett",
  "id" : 337436337445670912,
  "created_at" : "Thu May 23 05:14:26 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u028E\u01DD\u029E\u0254\u0131\u0265 \u0287\u0287\u0250\u026F",
      "screen_name" : "matthickey",
      "indices" : [ 0, 11 ],
      "id_str" : "8710082",
      "id" : 8710082
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "337402320797200384",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7756877803, -122.4135892746 ]
  },
  "id_str" : "337404140454035458",
  "in_reply_to_user_id" : 8710082,
  "text" : "@matthickey Woah! How?",
  "id" : 337404140454035458,
  "in_reply_to_status_id" : 337402320797200384,
  "created_at" : "Thu May 23 03:06:30 +0000 2013",
  "in_reply_to_screen_name" : "matthickey",
  "in_reply_to_user_id_str" : "8710082",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7755532459, -122.4135291249 ]
  },
  "id_str" : "337401532326752256",
  "text" : "\"A lot of people haven't seen themselves as a 3D computer simulation.\"",
  "id" : 337401532326752256,
  "created_at" : "Thu May 23 02:56:08 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Storify",
      "screen_name" : "Storify",
      "indices" : [ 21, 29 ],
      "id_str" : "17814938",
      "id" : 17814938
    }, {
      "name" : "Emilio Ramirez",
      "screen_name" : "e_ramirez",
      "indices" : [ 36, 46 ],
      "id_str" : "1273564632",
      "id" : 1273564632
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "quantifiedself",
      "indices" : [ 0, 15 ]
    } ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http://t.co/fblWeDK2LN",
      "expanded_url" : "http://4sq.com/1a9eT5d",
      "display_url" : "4sq.com/1a9eT5d"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.77569862, -122.413593 ]
  },
  "id_str" : "337392464417673216",
  "text" : "#quantifiedself! (at @Storify HQ w/ @e_ramirez) http://t.co/fblWeDK2LN",
  "id" : 337392464417673216,
  "created_at" : "Thu May 23 02:20:06 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "quantifiedself",
      "indices" : [ 22, 37 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http://t.co/1EmOGMkWdK",
      "expanded_url" : "http://meetu.ps/173pqv",
      "display_url" : "meetu.ps/173pqv"
    } ]
  },
  "geo" : {
  },
  "id_str" : "337312200177893377",
  "text" : "Who's going to the SF #quantifiedself meetup tonight? There are a few spots left: http://t.co/1EmOGMkWdK See ya there.",
  "id" : 337312200177893377,
  "created_at" : "Wed May 22 21:01:10 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan King",
      "screen_name" : "rk",
      "indices" : [ 3, 6 ],
      "id_str" : "19853",
      "id" : 19853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 88 ],
      "url" : "https://t.co/wMn7KlhDkg",
      "expanded_url" : "https://blog.twitter.com/2013/getting-started-login-verification",
      "display_url" : "blog.twitter.com/2013/getting-s\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "337300795819167744",
  "text" : "RT @rk: We just released 2 factor auth for twitter. Sign up now: https://t.co/wMn7KlhDkg",
  "retweeted_status" : {
    "source" : "<a href=\"http://sites.google.com/site/yorufukurou/\" rel=\"nofollow\">YoruFukurou</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 57, 80 ],
        "url" : "https://t.co/wMn7KlhDkg",
        "expanded_url" : "https://blog.twitter.com/2013/getting-started-login-verification",
        "display_url" : "blog.twitter.com/2013/getting-s\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "337299894832345089",
    "text" : "We just released 2 factor auth for twitter. Sign up now: https://t.co/wMn7KlhDkg",
    "id" : 337299894832345089,
    "created_at" : "Wed May 22 20:12:16 +0000 2013",
    "user" : {
      "name" : "Ryan King",
      "screen_name" : "rk",
      "protected" : false,
      "id_str" : "19853",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1202040731/70847_7101903_1567328_n_normal.jpg",
      "id" : 19853,
      "verified" : false
    }
  },
  "id" : 337300795819167744,
  "created_at" : "Wed May 22 20:15:51 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sara Riggare",
      "screen_name" : "SaraRiggare",
      "indices" : [ 0, 12 ],
      "id_str" : "175875334",
      "id" : 175875334
    }, {
      "name" : "Yago Veith",
      "screen_name" : "yago1",
      "indices" : [ 13, 19 ],
      "id_str" : "28676128",
      "id" : 28676128
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "337087172870025217",
  "geo" : {
  },
  "id_str" : "337098129063165952",
  "in_reply_to_user_id" : 175875334,
  "text" : "@SaraRiggare @yago1 I'd be interesting in hearing them.",
  "id" : 337098129063165952,
  "in_reply_to_status_id" : 337087172870025217,
  "created_at" : "Wed May 22 06:50:31 +0000 2013",
  "in_reply_to_screen_name" : "SaraRiggare",
  "in_reply_to_user_id_str" : "175875334",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http://t.co/yjKfXttQmi",
      "expanded_url" : "http://flic.kr/p/enUTsf",
      "display_url" : "flic.kr/p/enUTsf"
    } ]
  },
  "geo" : {
  },
  "id_str" : "337073517004722177",
  "text" : "8:36pm Niko: \"Close the windows so I'm not scared by the wind.\" Me: \"Ok.\" Niko: \"Why am I scared by the wind?\" http://t.co/yjKfXttQmi",
  "id" : 337073517004722177,
  "created_at" : "Wed May 22 05:12:43 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Will Kessler",
      "screen_name" : "Atlas3650",
      "indices" : [ 0, 10 ],
      "id_str" : "24755466",
      "id" : 24755466
    }, {
      "name" : "Dave McClure",
      "screen_name" : "davemcclure",
      "indices" : [ 127, 139 ],
      "id_str" : "1081",
      "id" : 1081
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "337026939887951874",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597431021, -122.2755739309 ]
  },
  "id_str" : "337049654858506240",
  "in_reply_to_user_id" : 24755466,
  "text" : "@Atlas3650 Go to your profile -&gt; gear -&gt; Settings -&gt; change font size. Can't help with the side effects of following  @davemcclure though.",
  "id" : 337049654858506240,
  "in_reply_to_status_id" : 337026939887951874,
  "created_at" : "Wed May 22 03:37:54 +0000 2013",
  "in_reply_to_screen_name" : "Atlas3650",
  "in_reply_to_user_id_str" : "24755466",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Damon Cortesi",
      "screen_name" : "dacort",
      "indices" : [ 0, 7 ],
      "id_str" : "99723",
      "id" : 99723
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "337037907246346240",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597208016, -122.2755715813 ]
  },
  "id_str" : "337043264655998976",
  "in_reply_to_user_id" : 99723,
  "text" : "@dacort As long as you hit the start button occasionally.",
  "id" : 337043264655998976,
  "in_reply_to_status_id" : 337037907246346240,
  "created_at" : "Wed May 22 03:12:30 +0000 2013",
  "in_reply_to_screen_name" : "dacort",
  "in_reply_to_user_id_str" : "99723",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 38 ],
      "url" : "http://t.co/2hij47tUbc",
      "expanded_url" : "http://7-min.com",
      "display_url" : "7-min.com"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597356945, -122.2754703365 ]
  },
  "id_str" : "337037664601636865",
  "text" : "Is anyone doing http://t.co/2hij47tUbc? Looks fun.",
  "id" : 337037664601636865,
  "created_at" : "Wed May 22 02:50:15 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"https://findings.com\" rel=\"nofollow\">Findings</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Findings",
      "screen_name" : "findings",
      "indices" : [ 109, 118 ],
      "id_str" : "208197274",
      "id" : 208197274
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 143 ],
      "url" : "http://t.co/b9Jvt2EGyS",
      "expanded_url" : "http://fnd.gs/18gqfVZ",
      "display_url" : "fnd.gs/18gqfVZ"
    } ]
  },
  "geo" : {
  },
  "id_str" : "336990851987292162",
  "text" : "\"Their vulnerability comes from embracing cheese while understanding the humor &amp; playfulness in it.\" via @findings - http://t.co/b9Jvt2EGyS",
  "id" : 336990851987292162,
  "created_at" : "Tue May 21 23:44:14 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "whitney erin boesel",
      "screen_name" : "phenatypical",
      "indices" : [ 0, 13 ],
      "id_str" : "264101497",
      "id" : 264101497
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "336939738374238208",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7769724564, -122.4172611528 ]
  },
  "id_str" : "336941864982806528",
  "in_reply_to_user_id" : 264101497,
  "text" : "@phenatypical Send me an email with details. (buster@twitter.com)",
  "id" : 336941864982806528,
  "in_reply_to_status_id" : 336939738374238208,
  "created_at" : "Tue May 21 20:29:35 +0000 2013",
  "in_reply_to_screen_name" : "phenatypical",
  "in_reply_to_user_id_str" : "264101497",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    }, {
      "name" : "whitney erin boesel",
      "screen_name" : "phenatypical",
      "indices" : [ 10, 23 ],
      "id_str" : "264101497",
      "id" : 264101497
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "336904931913113601",
  "geo" : {
  },
  "id_str" : "336905604083875841",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez @phenatypical I could join from 11-11:30 on Friday.",
  "id" : 336905604083875841,
  "in_reply_to_status_id" : 336904931913113601,
  "created_at" : "Tue May 21 18:05:30 +0000 2013",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "whitney erin boesel",
      "screen_name" : "phenatypical",
      "indices" : [ 0, 13 ],
      "id_str" : "264101497",
      "id" : 264101497
    }, {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 14, 23 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "336859658599936000",
  "geo" : {
  },
  "id_str" : "336904343926210561",
  "in_reply_to_user_id" : 264101497,
  "text" : "@phenatypical @eramirez I could do it Thursday or Friday around 12pm (Pacific). Would that work?",
  "id" : 336904343926210561,
  "in_reply_to_status_id" : 336859658599936000,
  "created_at" : "Tue May 21 18:00:29 +0000 2013",
  "in_reply_to_screen_name" : "phenatypical",
  "in_reply_to_user_id_str" : "264101497",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Lewis",
      "screen_name" : "plewis67",
      "indices" : [ 0, 9 ],
      "id_str" : "251583860",
      "id" : 251583860
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "336899023036375040",
  "geo" : {
  },
  "id_str" : "336899813746540544",
  "in_reply_to_user_id" : 251583860,
  "text" : "@plewis67 I think people in QS generally way underestimate the length of time that continued awareness is necessary.",
  "id" : 336899813746540544,
  "in_reply_to_status_id" : 336899023036375040,
  "created_at" : "Tue May 21 17:42:29 +0000 2013",
  "in_reply_to_screen_name" : "plewis67",
  "in_reply_to_user_id_str" : "251583860",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Lewis",
      "screen_name" : "plewis67",
      "indices" : [ 0, 9 ],
      "id_str" : "251583860",
      "id" : 251583860
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "336898870346936322",
  "geo" : {
  },
  "id_str" : "336899232952897538",
  "in_reply_to_user_id" : 251583860,
  "text" : "@plewis67 That's true *if* your motivation is now coming from a different source (like your identity and sense of the new normal).",
  "id" : 336899232952897538,
  "in_reply_to_status_id" : 336898870346936322,
  "created_at" : "Tue May 21 17:40:11 +0000 2013",
  "in_reply_to_screen_name" : "plewis67",
  "in_reply_to_user_id_str" : "251583860",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Lewis",
      "screen_name" : "plewis67",
      "indices" : [ 0, 9 ],
      "id_str" : "251583860",
      "id" : 251583860
    }, {
      "name" : "Branch",
      "screen_name" : "branch",
      "indices" : [ 39, 46 ],
      "id_str" : "494518813",
      "id" : 494518813
    }, {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 67, 76 ],
      "id_str" : "21135674",
      "id" : 21135674
    }, {
      "name" : "whitney erin boesel",
      "screen_name" : "phenatypical",
      "indices" : [ 77, 90 ],
      "id_str" : "264101497",
      "id" : 264101497
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "336897806797258752",
  "geo" : {
  },
  "id_str" : "336898547565883392",
  "in_reply_to_user_id" : 251583860,
  "text" : "@plewis67 You should join us in our QS @branch later this week /cc @eramirez @phenatypical",
  "id" : 336898547565883392,
  "in_reply_to_status_id" : 336897806797258752,
  "created_at" : "Tue May 21 17:37:27 +0000 2013",
  "in_reply_to_screen_name" : "plewis67",
  "in_reply_to_user_id_str" : "251583860",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Lewis",
      "screen_name" : "plewis67",
      "indices" : [ 0, 9 ],
      "id_str" : "251583860",
      "id" : 251583860
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "336897656183984128",
  "geo" : {
  },
  "id_str" : "336898242971303938",
  "in_reply_to_user_id" : 251583860,
  "text" : "@plewis67 I guess that's the more subtle point I was trying to make. I don't think motivation will sustain without learning about yourself.",
  "id" : 336898242971303938,
  "in_reply_to_status_id" : 336897656183984128,
  "created_at" : "Tue May 21 17:36:15 +0000 2013",
  "in_reply_to_screen_name" : "plewis67",
  "in_reply_to_user_id_str" : "251583860",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "benji shine",
      "screen_name" : "bshine",
      "indices" : [ 0, 7 ],
      "id_str" : "7305682",
      "id" : 7305682
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 67 ],
      "url" : "http://t.co/NFZhoYAFMh",
      "expanded_url" : "http://bustr.me/post/50999346984/john-paul-flintoff-the-quantified-self",
      "display_url" : "bustr.me/post/509993469\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "336896839351668737",
  "geo" : {
  },
  "id_str" : "336897527288852482",
  "in_reply_to_user_id" : 7305682,
  "text" : "@bshine Should be working again, but if not: http://t.co/NFZhoYAFMh",
  "id" : 336897527288852482,
  "in_reply_to_status_id" : 336896839351668737,
  "created_at" : "Tue May 21 17:33:24 +0000 2013",
  "in_reply_to_screen_name" : "bshine",
  "in_reply_to_user_id_str" : "7305682",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Lewis",
      "screen_name" : "plewis67",
      "indices" : [ 0, 9 ],
      "id_str" : "251583860",
      "id" : 251583860
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "336897197289377792",
  "geo" : {
  },
  "id_str" : "336897416458563584",
  "in_reply_to_user_id" : 251583860,
  "text" : "@plewis67 Can you elaborate? I bet there is but I am not sure exactly what distinction you're implying.",
  "id" : 336897416458563584,
  "in_reply_to_status_id" : 336897197289377792,
  "created_at" : "Tue May 21 17:32:57 +0000 2013",
  "in_reply_to_screen_name" : "plewis67",
  "in_reply_to_user_id_str" : "251583860",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http://t.co/58xCytIR2j",
      "expanded_url" : "http://bit.ly/119lOGi",
      "display_url" : "bit.ly/119lOGi"
    } ]
  },
  "geo" : {
  },
  "id_str" : "336895539541049344",
  "text" : "\"Quantified Self is a kind of secular ritual. To be meaningful, it can\u2019t be carried out on our behalf by gadgets.\" http://t.co/58xCytIR2j",
  "id" : 336895539541049344,
  "created_at" : "Tue May 21 17:25:30 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8451336954, -122.2708163068 ]
  },
  "id_str" : "336878219288522752",
  "text" : "We're each on an insanely long winning streak. *One hundred percent* of our millions of ancestors had children. What are the chances???",
  "id" : 336878219288522752,
  "created_at" : "Tue May 21 16:16:41 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jelly",
      "screen_name" : "jellyhq",
      "indices" : [ 17, 25 ],
      "id_str" : "1316672252",
      "id" : 1316672252
    }, {
      "name" : "Lift",
      "screen_name" : "liftapp",
      "indices" : [ 31, 39 ],
      "id_str" : "353195232",
      "id" : 353195232
    }, {
      "name" : "Chris Aniszczyk",
      "screen_name" : "cra",
      "indices" : [ 115, 119 ],
      "id_str" : "14602130",
      "id" : 14602130
    }, {
      "name" : "Peter Morelli",
      "screen_name" : "pmorelli",
      "indices" : [ 120, 129 ],
      "id_str" : "14161459",
      "id" : 14161459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https://t.co/5cHDwqs1Pw",
      "expanded_url" : "https://blog.twitter.com/2013/brewing-our-first-innovator%E2%80%99s-patent-agreement-patent-0",
      "display_url" : "blog.twitter.com/2013/brewing-o\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "336848153313693696",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597296797, -122.2754921609 ]
  },
  "id_str" : "336859730716811265",
  "in_reply_to_user_id" : 14602130,
  "text" : "This is awesome. @jellyhq  and @liftapp  adopt the IPA patent structure. More should! https://t.co/5cHDwqs1Pw /via @cra @pmorelli",
  "id" : 336859730716811265,
  "in_reply_to_status_id" : 336848153313693696,
  "created_at" : "Tue May 21 15:03:13 +0000 2013",
  "in_reply_to_screen_name" : "cra",
  "in_reply_to_user_id_str" : "14602130",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    }, {
      "name" : "whitney erin boesel",
      "screen_name" : "phenatypical",
      "indices" : [ 10, 23 ],
      "id_str" : "264101497",
      "id" : 264101497
    }, {
      "name" : "Branch",
      "screen_name" : "branch",
      "indices" : [ 40, 47 ],
      "id_str" : "494518813",
      "id" : 494518813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "336854369561608192",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859735495, -122.2756024363 ]
  },
  "id_str" : "336858849925554176",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez @phenatypical I'd be in for a @branch chat!",
  "id" : 336858849925554176,
  "in_reply_to_status_id" : 336854369561608192,
  "created_at" : "Tue May 21 14:59:43 +0000 2013",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "whitney erin boesel",
      "screen_name" : "phenatypical",
      "indices" : [ 12, 25 ],
      "id_str" : "264101497",
      "id" : 264101497
    }, {
      "name" : "quantifiedself",
      "screen_name" : "quantifiedself",
      "indices" : [ 87, 102 ],
      "id_str" : "35056570",
      "id" : 35056570
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http://t.co/BPfkFnvQI6",
      "expanded_url" : "http://www.aeonmagazine.com/being-human/john-paul-flintoff-quantified-self/",
      "display_url" : "aeonmagazine.com/being-human/jo\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "336843229251117058",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8598285813, -122.2753522528 ]
  },
  "id_str" : "336848465797738496",
  "in_reply_to_user_id" : 264101497,
  "text" : "I agree! RT @phenatypical: some points i want to argue with, but overall this essay on @quantifiedself is great http://t.co/BPfkFnvQI6",
  "id" : 336848465797738496,
  "in_reply_to_status_id" : 336843229251117058,
  "created_at" : "Tue May 21 14:18:27 +0000 2013",
  "in_reply_to_screen_name" : "phenatypical",
  "in_reply_to_user_id_str" : "264101497",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carinna Tarvin",
      "screen_name" : "carinnatarvin",
      "indices" : [ 0, 14 ],
      "id_str" : "20833838",
      "id" : 20833838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 54 ],
      "url" : "http://t.co/Ai3Xyv0xtI",
      "expanded_url" : "http://www.amazon.com/gp/aw/d/0439199964",
      "display_url" : "amazon.com/gp/aw/d/043919\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "336703232669794304",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596963687, -122.2754316219 ]
  },
  "id_str" : "336703504334856194",
  "in_reply_to_user_id" : 20833838,
  "text" : "@carinnatarvin Three Questions! http://t.co/Ai3Xyv0xtI",
  "id" : 336703504334856194,
  "in_reply_to_status_id" : 336703232669794304,
  "created_at" : "Tue May 21 04:42:25 +0000 2013",
  "in_reply_to_screen_name" : "carinnatarvin",
  "in_reply_to_user_id_str" : "20833838",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http://t.co/4ej7uaH051",
      "expanded_url" : "http://flic.kr/p/emis5G",
      "display_url" : "flic.kr/p/emis5G"
    } ]
  },
  "geo" : {
  },
  "id_str" : "336695864447889408",
  "text" : "8:36pm Reading Niko Crane a new kid book by Tolstoy that has 3 questions, a Niko, and a crane in it http://t.co/4ej7uaH051",
  "id" : 336695864447889408,
  "created_at" : "Tue May 21 04:12:04 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "todd sawicki",
      "screen_name" : "sawickipedia",
      "indices" : [ 0, 13 ],
      "id_str" : "1784841",
      "id" : 1784841
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "336599210738716674",
  "geo" : {
  },
  "id_str" : "336599665556459520",
  "in_reply_to_user_id" : 1784841,
  "text" : "@sawickipedia Yeah, seems like a no-brainer feature to add. I've never used that though, I take way more photos than I want to keep.",
  "id" : 336599665556459520,
  "in_reply_to_status_id" : 336599210738716674,
  "created_at" : "Mon May 20 21:49:48 +0000 2013",
  "in_reply_to_screen_name" : "sawickipedia",
  "in_reply_to_user_id_str" : "1784841",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Flickr",
      "screen_name" : "Flickr",
      "indices" : [ 12, 19 ],
      "id_str" : "21237045",
      "id" : 21237045
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http://t.co/wLueQu3ZYG",
      "expanded_url" : "http://www.flickr.com/photos/erikbenson/",
      "display_url" : "flickr.com/photos/erikben\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "336598972992995328",
  "text" : "I've been a @Flickr user since Feb 2004. Love it 1000%. My only wish is that I could change my username: http://t.co/wLueQu3ZYG",
  "id" : 336598972992995328,
  "created_at" : "Mon May 20 21:47:03 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Flickr",
      "screen_name" : "Flickr",
      "indices" : [ 12, 19 ],
      "id_str" : "21237045",
      "id" : 21237045
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Flickr",
      "indices" : [ 32, 39 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http://t.co/q56NkKDVT3",
      "expanded_url" : "http://bit.ly/16FPPqa",
      "display_url" : "bit.ly/16FPPqa"
    } ]
  },
  "geo" : {
  },
  "id_str" : "336595422531440640",
  "text" : "Awesome! RT @Flickr: A brighter #Flickr is here. New design, a stunning Android app, and... 1 free terabyte of space: http://t.co/q56NkKDVT3",
  "id" : 336595422531440640,
  "created_at" : "Mon May 20 21:32:57 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "336525389688102914",
  "text" : "Rooting for Tumblr and Yahoo. For some reason, I feel optimistic about this one.",
  "id" : 336525389688102914,
  "created_at" : "Mon May 20 16:54:39 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "leftsider",
      "screen_name" : "Leftsider",
      "indices" : [ 0, 10 ],
      "id_str" : "3796",
      "id" : 3796
    }, {
      "name" : "Lane Collins",
      "screen_name" : "lane",
      "indices" : [ 11, 16 ],
      "id_str" : "541",
      "id" : 541
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "336280031489830912",
  "geo" : {
  },
  "id_str" : "336521734977114112",
  "in_reply_to_user_id" : 3796,
  "text" : "@Leftsider @lane Ha. Thanks. I do also remember Jack telling me at sxsw 2007 that Twitter's \"what's happening?\" was inspired by 43things.",
  "id" : 336521734977114112,
  "in_reply_to_status_id" : 336280031489830912,
  "created_at" : "Mon May 20 16:40:08 +0000 2013",
  "in_reply_to_screen_name" : "Leftsider",
  "in_reply_to_user_id_str" : "3796",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "April Schiller",
      "screen_name" : "the_april",
      "indices" : [ 0, 10 ],
      "id_str" : "16644937",
      "id" : 16644937
    }, {
      "name" : "josh",
      "screen_name" : "joshc",
      "indices" : [ 11, 17 ],
      "id_str" : "2015",
      "id" : 2015
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "336500217924968448",
  "geo" : {
  },
  "id_str" : "336521099594563584",
  "in_reply_to_user_id" : 16644937,
  "text" : "@the_april @joshc I suspect you've made slow life changes because you have a will of steel. Put your mind to it = done. :)",
  "id" : 336521099594563584,
  "in_reply_to_status_id" : 336500217924968448,
  "created_at" : "Mon May 20 16:37:37 +0000 2013",
  "in_reply_to_screen_name" : "the_april",
  "in_reply_to_user_id_str" : "16644937",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sara Miller",
      "screen_name" : "nishushan",
      "indices" : [ 0, 10 ],
      "id_str" : "712822328",
      "id" : 712822328
    }, {
      "name" : "josh",
      "screen_name" : "joshc",
      "indices" : [ 11, 17 ],
      "id_str" : "2015",
      "id" : 2015
    }, {
      "name" : "April Schiller",
      "screen_name" : "the_april",
      "indices" : [ 18, 28 ],
      "id_str" : "16644937",
      "id" : 16644937
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "336429668741816321",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596490839, -122.2754382856 ]
  },
  "id_str" : "336498923768262657",
  "in_reply_to_user_id" : 712822328,
  "text" : "@nishushan @joshc @the_april But if you find something that works, stick with it!",
  "id" : 336498923768262657,
  "in_reply_to_status_id" : 336429668741816321,
  "created_at" : "Mon May 20 15:09:29 +0000 2013",
  "in_reply_to_screen_name" : "nishushan",
  "in_reply_to_user_id_str" : "712822328",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sara Miller",
      "screen_name" : "nishushan",
      "indices" : [ 0, 10 ],
      "id_str" : "712822328",
      "id" : 712822328
    }, {
      "name" : "josh",
      "screen_name" : "joshc",
      "indices" : [ 11, 17 ],
      "id_str" : "2015",
      "id" : 2015
    }, {
      "name" : "April Schiller",
      "screen_name" : "the_april",
      "indices" : [ 18, 28 ],
      "id_str" : "16644937",
      "id" : 16644937
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "336429668741816321",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859709229, -122.2754971433 ]
  },
  "id_str" : "336498762698608640",
  "in_reply_to_user_id" : 712822328,
  "text" : "@nishushan @joshc @the_april Both calorie counting &amp; meal photos help you gain awareness of what yr eating. I think that's the main thing.",
  "id" : 336498762698608640,
  "in_reply_to_status_id" : 336429668741816321,
  "created_at" : "Mon May 20 15:08:51 +0000 2013",
  "in_reply_to_screen_name" : "nishushan",
  "in_reply_to_user_id_str" : "712822328",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "josh",
      "screen_name" : "joshc",
      "indices" : [ 0, 6 ],
      "id_str" : "2015",
      "id" : 2015
    }, {
      "name" : "April Schiller",
      "screen_name" : "the_april",
      "indices" : [ 7, 17 ],
      "id_str" : "16644937",
      "id" : 16644937
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "336354495976050688",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596114402, -122.2755124163 ]
  },
  "id_str" : "336355666832814081",
  "in_reply_to_user_id" : 2015,
  "text" : "@joshc @the_april Be careful, it's a rabbit hole for people who want to feel organized. The Eatery is my fave eating app.",
  "id" : 336355666832814081,
  "in_reply_to_status_id" : 336354495976050688,
  "created_at" : "Mon May 20 05:40:14 +0000 2013",
  "in_reply_to_screen_name" : "joshc",
  "in_reply_to_user_id_str" : "2015",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ariel Waldman",
      "screen_name" : "arielwaldman",
      "indices" : [ 11, 24 ],
      "id_str" : "814304",
      "id" : 814304
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http://t.co/hX3kOVdduq",
      "expanded_url" : "http://technoccult.net/archives/2013/05/19/humans-are-really-just-biomechanical-suit-cities-for-bacteria/",
      "display_url" : "technoccult.net/archives/2013/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "336350827847483392",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596557584, -122.275530696 ]
  },
  "id_str" : "336354865058050049",
  "in_reply_to_user_id" : 814304,
  "text" : "Me too. RT @arielwaldman: Humans Are Really Just Biomechanical Suit-Cities For Bacteria http://t.co/hX3kOVdduq (&lt;3 this headline)",
  "id" : 336354865058050049,
  "in_reply_to_status_id" : 336350827847483392,
  "created_at" : "Mon May 20 05:37:03 +0000 2013",
  "in_reply_to_screen_name" : "arielwaldman",
  "in_reply_to_user_id_str" : "814304",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "josh",
      "screen_name" : "joshc",
      "indices" : [ 0, 6 ],
      "id_str" : "2015",
      "id" : 2015
    }, {
      "name" : "April Schiller",
      "screen_name" : "the_april",
      "indices" : [ 7, 17 ],
      "id_str" : "16644937",
      "id" : 16644937
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "336347677304442881",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596791844, -122.2754716322 ]
  },
  "id_str" : "336353878524190720",
  "in_reply_to_user_id" : 2015,
  "text" : "@joshc @the_april Which app? Sounds like a terrible idea. :)",
  "id" : 336353878524190720,
  "in_reply_to_status_id" : 336347677304442881,
  "created_at" : "Mon May 20 05:33:08 +0000 2013",
  "in_reply_to_screen_name" : "joshc",
  "in_reply_to_user_id_str" : "2015",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 39 ],
      "url" : "http://t.co/pM1XY4bjzf",
      "expanded_url" : "http://flic.kr/p/ekFwYc",
      "display_url" : "flic.kr/p/ekFwYc"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859833, -122.2755 ]
  },
  "id_str" : "336325458234863616",
  "text" : "8:36pm Relaxing. http://t.co/pM1XY4bjzf",
  "id" : 336325458234863616,
  "created_at" : "Mon May 20 03:40:12 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://vine.co\" rel=\"nofollow\">Vine - Make a Scene</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 47 ],
      "url" : "https://t.co/BnLSxJf4Ug",
      "expanded_url" : "https://vine.co/v/b9qUQhi5I0L",
      "display_url" : "vine.co/v/b9qUQhi5I0L"
    } ]
  },
  "geo" : {
  },
  "id_str" : "336309645259976704",
  "text" : "Snoring after a big day https://t.co/BnLSxJf4Ug",
  "id" : 336309645259976704,
  "created_at" : "Mon May 20 02:37:22 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Messina\u2122",
      "screen_name" : "chrismessina",
      "indices" : [ 0, 13 ],
      "id_str" : "1186",
      "id" : 1186
    }, {
      "name" : "brynn evans",
      "screen_name" : "brynn",
      "indices" : [ 14, 20 ],
      "id_str" : "8708232",
      "id" : 8708232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "336293322312269824",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859661101, -122.275556539 ]
  },
  "id_str" : "336305381859012608",
  "in_reply_to_user_id" : 1186,
  "text" : "@chrismessina @brynn Interesting. Both flat and 3-D at the same time.",
  "id" : 336305381859012608,
  "in_reply_to_status_id" : 336293322312269824,
  "created_at" : "Mon May 20 02:20:25 +0000 2013",
  "in_reply_to_screen_name" : "chrismessina",
  "in_reply_to_user_id_str" : "1186",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Messina\u2122",
      "screen_name" : "chrismessina",
      "indices" : [ 0, 13 ],
      "id_str" : "1186",
      "id" : 1186
    }, {
      "name" : "brynn evans",
      "screen_name" : "brynn",
      "indices" : [ 14, 20 ],
      "id_str" : "8708232",
      "id" : 8708232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "336265402197880833",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597565496, -122.2755000979 ]
  },
  "id_str" : "336278188768514049",
  "in_reply_to_user_id" : 1186,
  "text" : "@chrismessina @brynn So it functions as emotional lift? I find it to be flashy... drawing my attention away from diving into content.",
  "id" : 336278188768514049,
  "in_reply_to_status_id" : 336265402197880833,
  "created_at" : "Mon May 20 00:32:22 +0000 2013",
  "in_reply_to_screen_name" : "chrismessina",
  "in_reply_to_user_id_str" : "1186",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "leftsider",
      "screen_name" : "Leftsider",
      "indices" : [ 0, 10 ],
      "id_str" : "3796",
      "id" : 3796
    }, {
      "name" : "Lane Collins",
      "screen_name" : "lane",
      "indices" : [ 11, 16 ],
      "id_str" : "541",
      "id" : 541
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "336191029990543361",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597482353, -122.2755260387 ]
  },
  "id_str" : "336276959594176513",
  "in_reply_to_user_id" : 3796,
  "text" : "@Leftsider @lane I was a co-founder and agree that it was neglected over the years! So much potential there...",
  "id" : 336276959594176513,
  "in_reply_to_status_id" : 336191029990543361,
  "created_at" : "Mon May 20 00:27:29 +0000 2013",
  "in_reply_to_screen_name" : "Leftsider",
  "in_reply_to_user_id_str" : "3796",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 38 ],
      "url" : "http://t.co/FvMmDt4SDj",
      "expanded_url" : "http://flic.kr/p/ekD13e",
      "display_url" : "flic.kr/p/ekD13e"
    } ]
  },
  "geo" : {
  },
  "id_str" : "336276141004427266",
  "text" : "Balloon monster http://t.co/FvMmDt4SDj",
  "id" : 336276141004427266,
  "created_at" : "Mon May 20 00:24:14 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://vine.co\" rel=\"nofollow\">Vine - Make a Scene</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 49 ],
      "url" : "https://t.co/KzS8qRCxPd",
      "expanded_url" : "https://vine.co/v/b9mrZ6xar02",
      "display_url" : "vine.co/v/b9mrZ6xar02"
    } ]
  },
  "geo" : {
  },
  "id_str" : "336199991934730241",
  "text" : "Birthday balloon delivery https://t.co/KzS8qRCxPd",
  "id" : 336199991934730241,
  "created_at" : "Sun May 19 19:21:39 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://vine.co\" rel=\"nofollow\">Vine - Make a Scene</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 54 ],
      "url" : "https://t.co/4rD6shDyCJ",
      "expanded_url" : "https://vine.co/v/b9ZOAXwOaUU",
      "display_url" : "vine.co/v/b9ZOAXwOaUU"
    } ]
  },
  "geo" : {
  },
  "id_str" : "336161382850519042",
  "text" : "Bubble machine vs baseball bat https://t.co/4rD6shDyCJ",
  "id" : 336161382850519042,
  "created_at" : "Sun May 19 16:48:13 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 41 ],
      "url" : "http://t.co/7YuHfalllb",
      "expanded_url" : "http://flic.kr/p/ekAXfb",
      "display_url" : "flic.kr/p/ekAXfb"
    } ]
  },
  "geo" : {
  },
  "id_str" : "336138152391634944",
  "text" : "Birthday party boy http://t.co/7YuHfalllb",
  "id" : 336138152391634944,
  "created_at" : "Sun May 19 15:15:55 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http://t.co/oxsBqhUCtI",
      "expanded_url" : "http://flic.kr/p/ekrPKQ",
      "display_url" : "flic.kr/p/ekrPKQ"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859666, -122.2755 ]
  },
  "id_str" : "335963292826730496",
  "text" : "8:36pm Letting Niko watch Caillou while we work on his bday party todo list for tomorrow. http://t.co/oxsBqhUCtI",
  "id" : 335963292826730496,
  "created_at" : "Sun May 19 03:41:05 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luke Muehlhauser",
      "screen_name" : "lukeprog",
      "indices" : [ 3, 12 ],
      "id_str" : "24847747",
      "id" : 24847747
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http://t.co/NEFtFF9rzu",
      "expanded_url" : "http://intelligence.org/2013/05/15/when-will-ai-be-created/",
      "display_url" : "intelligence.org/2013/05/15/whe\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "335930228952154112",
  "text" : "RT @lukeprog: My thoughts on the difficulty of estimating AI timelines: http://t.co/NEFtFF9rzu",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 58, 80 ],
        "url" : "http://t.co/NEFtFF9rzu",
        "expanded_url" : "http://intelligence.org/2013/05/15/when-will-ai-be-created/",
        "display_url" : "intelligence.org/2013/05/15/whe\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "335922332986134528",
    "text" : "My thoughts on the difficulty of estimating AI timelines: http://t.co/NEFtFF9rzu",
    "id" : 335922332986134528,
    "created_at" : "Sun May 19 00:58:19 +0000 2013",
    "user" : {
      "name" : "Luke Muehlhauser",
      "screen_name" : "lukeprog",
      "protected" : false,
      "id_str" : "24847747",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1976032383/LukeFace_normal.png",
      "id" : 24847747,
      "verified" : false
    }
  },
  "id" : 335930228952154112,
  "created_at" : "Sun May 19 01:29:42 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mihow",
      "screen_name" : "mihow",
      "indices" : [ 1, 7 ],
      "id_str" : "764757",
      "id" : 764757
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "335923539238608897",
  "geo" : {
  },
  "id_str" : "335923689231118337",
  "in_reply_to_user_id" : 764757,
  "text" : ".@mihow Yeah, realized that alcohol poisoning and drug overdose counted in that number, which makes more sense.",
  "id" : 335923689231118337,
  "in_reply_to_status_id" : 335923539238608897,
  "created_at" : "Sun May 19 01:03:43 +0000 2013",
  "in_reply_to_screen_name" : "mihow",
  "in_reply_to_user_id_str" : "764757",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Susan Ito",
      "screen_name" : "foodiemcbody",
      "indices" : [ 0, 13 ],
      "id_str" : "20121694",
      "id" : 20121694
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "335914513079607296",
  "geo" : {
  },
  "id_str" : "335916157498433536",
  "in_reply_to_user_id" : 20121694,
  "text" : "@foodiemcbody I'm guessing drug overdoses, but I can't haven't found the breakdown yet.",
  "id" : 335916157498433536,
  "in_reply_to_status_id" : 335914513079607296,
  "created_at" : "Sun May 19 00:33:47 +0000 2013",
  "in_reply_to_screen_name" : "foodiemcbody",
  "in_reply_to_user_id_str" : "20121694",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "thingsyoulearnreadingmortalityreports",
      "indices" : [ 82, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "335913444702302209",
  "text" : "Did you know that poisoning killed more people last year than both cars and guns? #thingsyoulearnreadingmortalityreports",
  "id" : 335913444702302209,
  "created_at" : "Sun May 19 00:23:00 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 55 ],
      "url" : "http://t.co/agiE7suqE3",
      "expanded_url" : "http://www.cdc.gov/nchs/features/nosologists.htm",
      "display_url" : "cdc.gov/nchs/features/\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "335911887940222976",
  "text" : "Do any of you know a nosologist? http://t.co/agiE7suqE3",
  "id" : 335911887940222976,
  "created_at" : "Sun May 19 00:16:49 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "A.J. Pape",
      "screen_name" : "ajpape",
      "indices" : [ 0, 7 ],
      "id_str" : "168930910",
      "id" : 168930910
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "335896863301570560",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596784162, -122.2754904312 ]
  },
  "id_str" : "335899969863168002",
  "in_reply_to_user_id" : 168930910,
  "text" : "@ajpape Complain on Twitter? :)",
  "id" : 335899969863168002,
  "in_reply_to_status_id" : 335896863301570560,
  "created_at" : "Sat May 18 23:29:28 +0000 2013",
  "in_reply_to_screen_name" : "ajpape",
  "in_reply_to_user_id_str" : "168930910",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Messina\u2122",
      "screen_name" : "chrismessina",
      "indices" : [ 81, 94 ],
      "id_str" : "1186",
      "id" : 1186
    }, {
      "name" : "brynn evans",
      "screen_name" : "brynn",
      "indices" : [ 95, 101 ],
      "id_str" : "8708232",
      "id" : 8708232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597060339, -122.2755836327 ]
  },
  "id_str" : "335896374086365185",
  "text" : "Why do posts need to fly in to the bottom of your stream in the Google+ app? /cc @chrismessina @brynn",
  "id" : 335896374086365185,
  "created_at" : "Sat May 18 23:15:10 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Weil",
      "screen_name" : "kevinweil",
      "indices" : [ 51, 61 ],
      "id_str" : "3452911",
      "id" : 3452911
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http://t.co/2VUtuiPCdj",
      "expanded_url" : "http://googleappsdeveloper.blogspot.co.uk/2013/05/introducing-actions-in-inbox-powered-by.html",
      "display_url" : "googleappsdeveloper.blogspot.co.uk/2013/05/introd\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "335882733391855617",
  "text" : "Ooh, I might be able to use this for something. RT @kevinweil: Google\u2019s new Inbox Actions are a GREAT idea: http://t.co/2VUtuiPCdj",
  "id" : 335882733391855617,
  "created_at" : "Sat May 18 22:20:58 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Coates",
      "screen_name" : "tomcoates",
      "indices" : [ 0, 10 ],
      "id_str" : "12514",
      "id" : 12514
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "longliverss",
      "indices" : [ 107, 119 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "335812261316816896",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597466182, -122.2754707654 ]
  },
  "id_str" : "335824338240544769",
  "in_reply_to_user_id" : 12514,
  "text" : "@tomcoates Death by a thousand tiny cuts. I think it just generalized too much... abstracted too much out. #longliverss",
  "id" : 335824338240544769,
  "in_reply_to_status_id" : 335812261316816896,
  "created_at" : "Sat May 18 18:28:56 +0000 2013",
  "in_reply_to_screen_name" : "tomcoates",
  "in_reply_to_user_id_str" : "12514",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "david whittemore",
      "screen_name" : "xpollen8",
      "indices" : [ 0, 9 ],
      "id_str" : "21778063",
      "id" : 21778063
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "335766340335968256",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597063775, -122.2756009273 ]
  },
  "id_str" : "335767563004952576",
  "in_reply_to_user_id" : 21778063,
  "text" : "@xpollen8 Working on it. Most won't know what to do with a script though...",
  "id" : 335767563004952576,
  "in_reply_to_status_id" : 335766340335968256,
  "created_at" : "Sat May 18 14:43:19 +0000 2013",
  "in_reply_to_screen_name" : "xpollen8",
  "in_reply_to_user_id_str" : "21778063",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erik Michaels-Ober",
      "screen_name" : "sferik",
      "indices" : [ 0, 7 ],
      "id_str" : "7505382",
      "id" : 7505382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "335597141261160448",
  "geo" : {
  },
  "id_str" : "335627454796423168",
  "in_reply_to_user_id" : 7505382,
  "text" : "@sferik On July 21st, you'll have exactly 51 years of life expectancy left. I haven't done what you suggest, but that would be neat.",
  "id" : 335627454796423168,
  "in_reply_to_status_id" : 335597141261160448,
  "created_at" : "Sat May 18 05:26:35 +0000 2013",
  "in_reply_to_screen_name" : "sferik",
  "in_reply_to_user_id_str" : "7505382",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matilda444",
      "screen_name" : "Matilda444",
      "indices" : [ 0, 11 ],
      "id_str" : "4250751",
      "id" : 4250751
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "deathday",
      "indices" : [ 86, 95 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "335585769420890113",
  "geo" : {
  },
  "id_str" : "335627172691705856",
  "in_reply_to_user_id" : 4250751,
  "text" : "@Matilda444 On Feb 21st, you'll have exactly 26 years of life expectancy left. Enjoy! #deathday",
  "id" : 335627172691705856,
  "in_reply_to_status_id" : 335585769420890113,
  "created_at" : "Sat May 18 05:25:28 +0000 2013",
  "in_reply_to_screen_name" : "Matilda444",
  "in_reply_to_user_id_str" : "4250751",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Jacobs",
      "screen_name" : "capndesign",
      "indices" : [ 0, 11 ],
      "id_str" : "5504",
      "id" : 5504
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "deathday",
      "indices" : [ 86, 95 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "335584312835575808",
  "geo" : {
  },
  "id_str" : "335626995369136128",
  "in_reply_to_user_id" : 5504,
  "text" : "@capndesign On Oct 11th, you'll have exactly 47 years of life expectancy left. Enjoy! #deathday",
  "id" : 335626995369136128,
  "in_reply_to_status_id" : 335584312835575808,
  "created_at" : "Sat May 18 05:24:46 +0000 2013",
  "in_reply_to_screen_name" : "capndesign",
  "in_reply_to_user_id_str" : "5504",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Schappell",
      "screen_name" : "daveschappell",
      "indices" : [ 0, 14 ],
      "id_str" : "820661",
      "id" : 820661
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "deathday",
      "indices" : [ 89, 98 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "335581881879912448",
  "geo" : {
  },
  "id_str" : "335626828049944576",
  "in_reply_to_user_id" : 820661,
  "text" : "@daveschappell On June 27th, you'll have exactly 37 years of life expectancy left. Happy #deathday!",
  "id" : 335626828049944576,
  "in_reply_to_status_id" : 335581881879912448,
  "created_at" : "Sat May 18 05:24:06 +0000 2013",
  "in_reply_to_screen_name" : "daveschappell",
  "in_reply_to_user_id_str" : "820661",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carol Tilley",
      "screen_name" : "CarolGSLIS",
      "indices" : [ 0, 11 ],
      "id_str" : "14072510",
      "id" : 14072510
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "deathday",
      "indices" : [ 85, 94 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "335581392098447360",
  "geo" : {
  },
  "id_str" : "335626632062701573",
  "in_reply_to_user_id" : 14072510,
  "text" : "@CarolGSLIS On May 20th you'll have exactly 38 years of life expectancy left. Enjoy! #deathday",
  "id" : 335626632062701573,
  "in_reply_to_status_id" : 335581392098447360,
  "created_at" : "Sat May 18 05:23:19 +0000 2013",
  "in_reply_to_screen_name" : "CarolGSLIS",
  "in_reply_to_user_id_str" : "14072510",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ron Diver",
      "screen_name" : "rondiver",
      "indices" : [ 0, 9 ],
      "id_str" : "12661782",
      "id" : 12661782
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "deathday",
      "indices" : [ 83, 92 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "335576177467088897",
  "geo" : {
  },
  "id_str" : "335626328579661824",
  "in_reply_to_user_id" : 12661782,
  "text" : "@rondiver On May 20th you'll have exactly 38 years of life expectancy left. Enjoy! #deathday",
  "id" : 335626328579661824,
  "in_reply_to_status_id" : 335576177467088897,
  "created_at" : "Sat May 18 05:22:07 +0000 2013",
  "in_reply_to_screen_name" : "rondiver",
  "in_reply_to_user_id_str" : "12661782",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peg Spadaro",
      "screen_name" : "515Peg",
      "indices" : [ 0, 7 ],
      "id_str" : "1084595826",
      "id" : 1084595826
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "deathday",
      "indices" : [ 81, 90 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "335573614051090434",
  "geo" : {
  },
  "id_str" : "335626103764959232",
  "in_reply_to_user_id" : 1084595826,
  "text" : "@515Peg On Aug 6th, you'll have exactly 24 years of life expectancy left. Enjoy! #deathday",
  "id" : 335626103764959232,
  "in_reply_to_status_id" : 335573614051090434,
  "created_at" : "Sat May 18 05:21:13 +0000 2013",
  "in_reply_to_screen_name" : "515Peg",
  "in_reply_to_user_id_str" : "1084595826",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Cottrell",
      "screen_name" : "rgcottrell",
      "indices" : [ 0, 11 ],
      "id_str" : "752553",
      "id" : 752553
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "deathday",
      "indices" : [ 92, 101 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "335571563703316481",
  "geo" : {
  },
  "id_str" : "335624766599872512",
  "in_reply_to_user_id" : 752553,
  "text" : "@rgcottrell On Mar 13th, 2014, you'll have exactly 40 years of life expectancy left. Enjoy! #deathday",
  "id" : 335624766599872512,
  "in_reply_to_status_id" : 335571563703316481,
  "created_at" : "Sat May 18 05:15:54 +0000 2013",
  "in_reply_to_screen_name" : "rgcottrell",
  "in_reply_to_user_id_str" : "752553",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 24, 34 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http://t.co/PMVsHioId9",
      "expanded_url" : "http://flic.kr/p/ek6CWc",
      "display_url" : "flic.kr/p/ek6CWc"
    } ]
  },
  "geo" : {
  },
  "id_str" : "335601496186052609",
  "text" : "8:36pm Dude night while @kellianne is out. Niko painted me.  http://t.co/PMVsHioId9",
  "id" : 335601496186052609,
  "created_at" : "Sat May 18 03:43:26 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Raffi Krikorian",
      "screen_name" : "raffi",
      "indices" : [ 0, 6 ],
      "id_str" : "8285392",
      "id" : 8285392
    }, {
      "name" : "Kai",
      "screen_name" : "babyparasite",
      "indices" : [ 7, 20 ],
      "id_str" : "950199696",
      "id" : 950199696
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "335596018546667520",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596653138, -122.2755496391 ]
  },
  "id_str" : "335597581159780352",
  "in_reply_to_user_id" : 8285392,
  "text" : "@raffi @babyparasite Welcome to parenthood! Your response is exactly appropriate.",
  "id" : 335597581159780352,
  "in_reply_to_status_id" : 335596018546667520,
  "created_at" : "Sat May 18 03:27:53 +0000 2013",
  "in_reply_to_screen_name" : "raffi",
  "in_reply_to_user_id_str" : "8285392",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carinna Tarvin",
      "screen_name" : "carinnatarvin",
      "indices" : [ 0, 14 ],
      "id_str" : "20833838",
      "id" : 20833838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "335574132274118657",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.789101166, -122.4020155453 ]
  },
  "id_str" : "335574695288111104",
  "in_reply_to_user_id" : 20833838,
  "text" : "@carinnatarvin Get the beer with an egg in it!",
  "id" : 335574695288111104,
  "in_reply_to_status_id" : 335574132274118657,
  "created_at" : "Sat May 18 01:56:56 +0000 2013",
  "in_reply_to_screen_name" : "carinnatarvin",
  "in_reply_to_user_id_str" : "20833838",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jane McGonigal",
      "screen_name" : "avantgame",
      "indices" : [ 0, 10 ],
      "id_str" : "681813",
      "id" : 681813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "335572028599980032",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7792015936, -122.4142597171 ]
  },
  "id_str" : "335574409198837760",
  "in_reply_to_user_id" : 681813,
  "text" : "@avantgame *licks feather quill scrunches face and gets to work* THE LEVITAS MOVEMENT... DEAR DUCKLINGS...",
  "id" : 335574409198837760,
  "in_reply_to_status_id" : 335572028599980032,
  "created_at" : "Sat May 18 01:55:48 +0000 2013",
  "in_reply_to_screen_name" : "avantgame",
  "in_reply_to_user_id_str" : "681813",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jane McGonigal",
      "screen_name" : "avantgame",
      "indices" : [ 0, 10 ],
      "id_str" : "681813",
      "id" : 681813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "335569739843776512",
  "geo" : {
  },
  "id_str" : "335570874096836611",
  "in_reply_to_user_id" : 681813,
  "text" : "@avantgame My favorite pseudo-made-up word lately is \"levitas\". The playful side of the gravitas coin. Can we start the Levitas Movement?",
  "id" : 335570874096836611,
  "in_reply_to_status_id" : 335569739843776512,
  "created_at" : "Sat May 18 01:41:45 +0000 2013",
  "in_reply_to_screen_name" : "avantgame",
  "in_reply_to_user_id_str" : "681813",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jane McGonigal",
      "screen_name" : "avantgame",
      "indices" : [ 0, 10 ],
      "id_str" : "681813",
      "id" : 681813
    }, {
      "name" : "Kiyash Monsef",
      "screen_name" : "kiyash",
      "indices" : [ 11, 18 ],
      "id_str" : "16630999",
      "id" : 16630999
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http://t.co/HKQhNVa5WH",
      "expanded_url" : "http://bit.ly/103EpYf",
      "display_url" : "bit.ly/103EpYf"
    } ]
  },
  "in_reply_to_status_id_str" : "335569879711219712",
  "geo" : {
  },
  "id_str" : "335570573860167680",
  "in_reply_to_user_id" : 681813,
  "text" : "@avantgame @kiyash A fun twist on the game: imagine living 100 lives in parallel. Which %ile of yourself are you? http://t.co/HKQhNVa5WH",
  "id" : 335570573860167680,
  "in_reply_to_status_id" : 335569879711219712,
  "created_at" : "Sat May 18 01:40:34 +0000 2013",
  "in_reply_to_screen_name" : "avantgame",
  "in_reply_to_user_id_str" : "681813",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Annie Londonderry",
      "screen_name" : "LondonderryFilm",
      "indices" : [ 0, 16 ],
      "id_str" : "1350072764",
      "id" : 1350072764
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "335569342722883585",
  "geo" : {
  },
  "id_str" : "335569829819973633",
  "in_reply_to_user_id" : 1350072764,
  "text" : "@LondonderryFilm Then you don't have to ask me for the date. :)",
  "id" : 335569829819973633,
  "in_reply_to_status_id" : 335569342722883585,
  "created_at" : "Sat May 18 01:37:36 +0000 2013",
  "in_reply_to_screen_name" : "LondonderryFilm",
  "in_reply_to_user_id_str" : "1350072764",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jane McGonigal",
      "screen_name" : "avantgame",
      "indices" : [ 0, 10 ],
      "id_str" : "681813",
      "id" : 681813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "335569324779655168",
  "geo" : {
  },
  "id_str" : "335569649557200896",
  "in_reply_to_user_id" : 681813,
  "text" : "@avantgame We totally are. I think we should call ourselves Gamificationists. j/k",
  "id" : 335569649557200896,
  "in_reply_to_status_id" : 335569324779655168,
  "created_at" : "Sat May 18 01:36:53 +0000 2013",
  "in_reply_to_screen_name" : "avantgame",
  "in_reply_to_user_id_str" : "681813",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Janna Ostoya",
      "screen_name" : "jannamark",
      "indices" : [ 0, 10 ],
      "id_str" : "77150368",
      "id" : 77150368
    }, {
      "name" : "Jane McGonigal",
      "screen_name" : "avantgame",
      "indices" : [ 11, 21 ],
      "id_str" : "681813",
      "id" : 681813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "335569014573117441",
  "geo" : {
  },
  "id_str" : "335569358552195073",
  "in_reply_to_user_id" : 77150368,
  "text" : "@jannamark @avantgame Another fun side effect is that the day changes every year.",
  "id" : 335569358552195073,
  "in_reply_to_status_id" : 335569014573117441,
  "created_at" : "Sat May 18 01:35:44 +0000 2013",
  "in_reply_to_screen_name" : "jannamark",
  "in_reply_to_user_id_str" : "77150368",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jane McGonigal",
      "screen_name" : "avantgame",
      "indices" : [ 0, 10 ],
      "id_str" : "681813",
      "id" : 681813
    }, {
      "name" : "Kiyash Monsef",
      "screen_name" : "kiyash",
      "indices" : [ 29, 36 ],
      "id_str" : "16630999",
      "id" : 16630999
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "deathday",
      "indices" : [ 95, 104 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "335568635483533312",
  "geo" : {
  },
  "id_str" : "335569061373173760",
  "in_reply_to_user_id" : 681813,
  "text" : "@avantgame On December 14th, @kiyash will have exactly 44 years of life expectancy left. Happy #deathday!",
  "id" : 335569061373173760,
  "in_reply_to_status_id" : 335568635483533312,
  "created_at" : "Sat May 18 01:34:33 +0000 2013",
  "in_reply_to_screen_name" : "avantgame",
  "in_reply_to_user_id_str" : "681813",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jane McGonigal",
      "screen_name" : "avantgame",
      "indices" : [ 0, 10 ],
      "id_str" : "681813",
      "id" : 681813
    }, {
      "name" : "Janna Ostoya",
      "screen_name" : "jannamark",
      "indices" : [ 11, 21 ],
      "id_str" : "77150368",
      "id" : 77150368
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "335568436178599937",
  "geo" : {
  },
  "id_str" : "335568880950992897",
  "in_reply_to_user_id" : 681813,
  "text" : "@avantgame @jannamark I was hoping someone would think it was as interesting as I did. There's much more to explore, too.",
  "id" : 335568880950992897,
  "in_reply_to_status_id" : 335568436178599937,
  "created_at" : "Sat May 18 01:33:50 +0000 2013",
  "in_reply_to_screen_name" : "avantgame",
  "in_reply_to_user_id_str" : "681813",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jane McGonigal",
      "screen_name" : "avantgame",
      "indices" : [ 0, 10 ],
      "id_str" : "681813",
      "id" : 681813
    }, {
      "name" : "Janna Ostoya",
      "screen_name" : "jannamark",
      "indices" : [ 11, 21 ],
      "id_str" : "77150368",
      "id" : 77150368
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "335568264337977344",
  "geo" : {
  },
  "id_str" : "335568677854408704",
  "in_reply_to_user_id" : 681813,
  "text" : "@avantgame @jannamark Exactly.",
  "id" : 335568677854408704,
  "in_reply_to_status_id" : 335568264337977344,
  "created_at" : "Sat May 18 01:33:02 +0000 2013",
  "in_reply_to_screen_name" : "avantgame",
  "in_reply_to_user_id_str" : "681813",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lillian Cohen-Moore",
      "screen_name" : "lilyorit",
      "indices" : [ 0, 9 ],
      "id_str" : "26699815",
      "id" : 26699815
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "deathday",
      "indices" : [ 84, 93 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "335567752314105857",
  "geo" : {
  },
  "id_str" : "335568606077284353",
  "in_reply_to_user_id" : 26699815,
  "text" : "@lilyorit On July 21st you'll have exactly 51 years of life expectancy left. Enjoy! #deathday",
  "id" : 335568606077284353,
  "in_reply_to_status_id" : 335567752314105857,
  "created_at" : "Sat May 18 01:32:44 +0000 2013",
  "in_reply_to_screen_name" : "lilyorit",
  "in_reply_to_user_id_str" : "26699815",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donovan Rice",
      "screen_name" : "donpmft",
      "indices" : [ 0, 8 ],
      "id_str" : "18093610",
      "id" : 18093610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "deathday",
      "indices" : [ 93, 102 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "335567681157734400",
  "geo" : {
  },
  "id_str" : "335568436463796224",
  "in_reply_to_user_id" : 18093610,
  "text" : "@donpmft On May 20th (coming right up!) you'll have 54 years of life expectancy left. Enjoy! #deathday",
  "id" : 335568436463796224,
  "in_reply_to_status_id" : 335567681157734400,
  "created_at" : "Sat May 18 01:32:04 +0000 2013",
  "in_reply_to_screen_name" : "donpmft",
  "in_reply_to_user_id_str" : "18093610",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Janna Ostoya",
      "screen_name" : "jannamark",
      "indices" : [ 0, 10 ],
      "id_str" : "77150368",
      "id" : 77150368
    }, {
      "name" : "Jane McGonigal",
      "screen_name" : "avantgame",
      "indices" : [ 11, 21 ],
      "id_str" : "681813",
      "id" : 681813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "335567663323574272",
  "geo" : {
  },
  "id_str" : "335568268762959872",
  "in_reply_to_user_id" : 77150368,
  "text" : "@jannamark @avantgame If not that, then what?",
  "id" : 335568268762959872,
  "in_reply_to_status_id" : 335567663323574272,
  "created_at" : "Sat May 18 01:31:24 +0000 2013",
  "in_reply_to_screen_name" : "jannamark",
  "in_reply_to_user_id_str" : "77150368",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Seth Miller",
      "screen_name" : "mostlymuppet",
      "indices" : [ 0, 13 ],
      "id_str" : "13740",
      "id" : 13740
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "deathday",
      "indices" : [ 85, 94 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "335567579290681344",
  "geo" : {
  },
  "id_str" : "335568215738548224",
  "in_reply_to_user_id" : 13740,
  "text" : "@mostlymuppet On Dec 14th you'll have 44 whole years of life expectancy left. Enjoy! #deathday",
  "id" : 335568215738548224,
  "in_reply_to_status_id" : 335567579290681344,
  "created_at" : "Sat May 18 01:31:11 +0000 2013",
  "in_reply_to_screen_name" : "mostlymuppet",
  "in_reply_to_user_id_str" : "13740",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Campbell",
      "screen_name" : "bitdepth",
      "indices" : [ 0, 9 ],
      "id_str" : "7680",
      "id" : 7680
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "deathday",
      "indices" : [ 86, 95 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "335567479105544192",
  "geo" : {
  },
  "id_str" : "335567726141661185",
  "in_reply_to_user_id" : 7680,
  "text" : "@bitdepth Same here! On Oct 23rd you'll have 34 years of life expectancy left. Enjoy! #deathday",
  "id" : 335567726141661185,
  "in_reply_to_status_id" : 335567479105544192,
  "created_at" : "Sat May 18 01:29:15 +0000 2013",
  "in_reply_to_screen_name" : "bitdepth",
  "in_reply_to_user_id_str" : "7680",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jane McGonigal",
      "screen_name" : "avantgame",
      "indices" : [ 0, 10 ],
      "id_str" : "681813",
      "id" : 681813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "335567109289558016",
  "geo" : {
  },
  "id_str" : "335567316534321152",
  "in_reply_to_user_id" : 681813,
  "text" : "@avantgame No need to be scared! Come Nov 23rd you'll still have 45 whole years of life expectancy left. :)",
  "id" : 335567316534321152,
  "in_reply_to_status_id" : 335567109289558016,
  "created_at" : "Sat May 18 01:27:37 +0000 2013",
  "in_reply_to_screen_name" : "avantgame",
  "in_reply_to_user_id_str" : "681813",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BuzzFeed Animals",
      "screen_name" : "BuzzFeedAnimals",
      "indices" : [ 71, 87 ],
      "id_str" : "545336345",
      "id" : 545336345
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 66 ],
      "url" : "http://t.co/bMubUIf30G",
      "expanded_url" : "http://www.buzzfeed.com/mattbellassai/the-creepiest-cats-you-meet-on-okcupid",
      "display_url" : "buzzfeed.com/mattbellassai/\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "335567096228503552",
  "text" : "\"The 17 Creepiest Cats You Meet On OkCupid\" http://t.co/bMubUIf30G via @BuzzFeedAnimals",
  "id" : 335567096228503552,
  "created_at" : "Sat May 18 01:26:44 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Isaac Hepworth",
      "screen_name" : "isaach",
      "indices" : [ 26, 33 ],
      "id_str" : "7852612",
      "id" : 7852612
    }, {
      "name" : "Buster",
      "screen_name" : "buster",
      "indices" : [ 54, 61 ],
      "id_str" : "2185",
      "id" : 2185
    }, {
      "name" : "Isaac Hepworth",
      "screen_name" : "isaach",
      "indices" : [ 63, 70 ],
      "id_str" : "7852612",
      "id" : 7852612
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "deathday",
      "indices" : [ 115, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "335566274149113857",
  "text" : "HYHY is the new RT. HYHY: @isaach: hear ye hear ye RT @buster: @isaach Deathdays are the new birthday. Pass it on. #deathday",
  "id" : 335566274149113857,
  "created_at" : "Sat May 18 01:23:28 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Isaac Hepworth",
      "screen_name" : "isaach",
      "indices" : [ 0, 7 ],
      "id_str" : "7852612",
      "id" : 7852612
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "335565242534866944",
  "geo" : {
  },
  "id_str" : "335565358004043779",
  "in_reply_to_user_id" : 7852612,
  "text" : "@isaach Deathdays are the new birthday. Pass it on.",
  "id" : 335565358004043779,
  "in_reply_to_status_id" : 335565242534866944,
  "created_at" : "Sat May 18 01:19:50 +0000 2013",
  "in_reply_to_screen_name" : "isaach",
  "in_reply_to_user_id_str" : "7852612",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gaby Pe\u00F1a",
      "screen_name" : "gpena",
      "indices" : [ 0, 6 ],
      "id_str" : "133583134",
      "id" : 133583134
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "deathday",
      "indices" : [ 126, 135 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "335564816058040321",
  "geo" : {
  },
  "id_str" : "335565207323672576",
  "in_reply_to_user_id" : 133583134,
  "text" : "@gpena The crystal ball says that on May 20th (coming right up!) you'll have exactly 54 years of life expectancy left. Enjoy! #deathday",
  "id" : 335565207323672576,
  "in_reply_to_status_id" : 335564816058040321,
  "created_at" : "Sat May 18 01:19:14 +0000 2013",
  "in_reply_to_screen_name" : "gpena",
  "in_reply_to_user_id_str" : "133583134",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Isaac Hepworth",
      "screen_name" : "isaach",
      "indices" : [ 0, 7 ],
      "id_str" : "7852612",
      "id" : 7852612
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "deathday",
      "indices" : [ 85, 94 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "335564619039010816",
  "geo" : {
  },
  "id_str" : "335564981955350530",
  "in_reply_to_user_id" : 7852612,
  "text" : "@isaach On Feb 24th, you'll have exactly 41 years of life expectancy left. Have fun! #deathday",
  "id" : 335564981955350530,
  "in_reply_to_status_id" : 335564619039010816,
  "created_at" : "Sat May 18 01:18:20 +0000 2013",
  "in_reply_to_screen_name" : "isaach",
  "in_reply_to_user_id_str" : "7852612",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vix Richardson",
      "screen_name" : "nefarious_vix",
      "indices" : [ 0, 14 ],
      "id_str" : "8605402",
      "id" : 8605402
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "deathday",
      "indices" : [ 93, 102 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "335564452768395264",
  "geo" : {
  },
  "id_str" : "335564816896913410",
  "in_reply_to_user_id" : 8605402,
  "text" : "@nefarious_vix On May 1st, 2014 you'll have exactly 55 years of life expectancy left. Enjoy! #deathday",
  "id" : 335564816896913410,
  "in_reply_to_status_id" : 335564452768395264,
  "created_at" : "Sat May 18 01:17:41 +0000 2013",
  "in_reply_to_screen_name" : "nefarious_vix",
  "in_reply_to_user_id_str" : "8605402",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Cook",
      "screen_name" : "theSeanCook",
      "indices" : [ 0, 12 ],
      "id_str" : "38895958",
      "id" : 38895958
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "deathday",
      "indices" : [ 86, 95 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "335564401400750080",
  "geo" : {
  },
  "id_str" : "335564603675267072",
  "in_reply_to_user_id" : 38895958,
  "text" : "@theSeanCook On Aug 29th you'll have exactly 49 years of life expectancy left. Enjoy! #deathday",
  "id" : 335564603675267072,
  "in_reply_to_status_id" : 335564401400750080,
  "created_at" : "Sat May 18 01:16:50 +0000 2013",
  "in_reply_to_screen_name" : "theSeanCook",
  "in_reply_to_user_id_str" : "38895958",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "deathday",
      "indices" : [ 39, 48 ]
    } ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http://t.co/R4dDoMo7PJ",
      "expanded_url" : "http://wayoftheduck.com/deathday",
      "display_url" : "wayoftheduck.com/deathday"
    } ]
  },
  "geo" : {
  },
  "id_str" : "335564106885132289",
  "text" : "Tweet me if you want to know when your #deathday is: http://t.co/R4dDoMo7PJ",
  "id" : 335564106885132289,
  "created_at" : "Sat May 18 01:14:52 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivier Lafleur",
      "screen_name" : "olivierlafleur",
      "indices" : [ 0, 15 ],
      "id_str" : "167521718",
      "id" : 167521718
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "deathday",
      "indices" : [ 108, 117 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "335546416128733185",
  "geo" : {
  },
  "id_str" : "335564005747851264",
  "in_reply_to_user_id" : 167521718,
  "text" : "@olivierlafleur On May 20th (coming right up!) you'll have exactly 54 years of life expectancy left. Enjoy! #deathday",
  "id" : 335564005747851264,
  "in_reply_to_status_id" : 335546416128733185,
  "created_at" : "Sat May 18 01:14:28 +0000 2013",
  "in_reply_to_screen_name" : "olivierlafleur",
  "in_reply_to_user_id_str" : "167521718",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "335557224208420864",
  "text" : "\"Time is short. Let's go do this.\"",
  "id" : 335557224208420864,
  "created_at" : "Sat May 18 00:47:31 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cristin Carey",
      "screen_name" : "cristin_carey",
      "indices" : [ 0, 14 ],
      "id_str" : "15950030",
      "id" : 15950030
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "deathday",
      "indices" : [ 79, 88 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "335498063202365442",
  "geo" : {
  },
  "id_str" : "335498773507751936",
  "in_reply_to_user_id" : 15950030,
  "text" : "@cristin_carey On Sept 20th, you'll have a life expectancy of 48 years. Enjoy! #deathday",
  "id" : 335498773507751936,
  "in_reply_to_status_id" : 335498063202365442,
  "created_at" : "Fri May 17 20:55:15 +0000 2013",
  "in_reply_to_screen_name" : "cristin_carey",
  "in_reply_to_user_id_str" : "15950030",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ioan Mitrea",
      "screen_name" : "awarenesss",
      "indices" : [ 0, 11 ],
      "id_str" : "18603224",
      "id" : 18603224
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "deathday",
      "indices" : [ 89, 98 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "335490095455014913",
  "geo" : {
  },
  "id_str" : "335490887167655936",
  "in_reply_to_user_id" : 18603224,
  "text" : "@awarenesss On Feb 24th, next year, your life expectancy will be exactly 41 years. Happy #deathday :)",
  "id" : 335490887167655936,
  "in_reply_to_status_id" : 335490095455014913,
  "created_at" : "Fri May 17 20:23:55 +0000 2013",
  "in_reply_to_screen_name" : "awarenesss",
  "in_reply_to_user_id_str" : "18603224",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stanislav Shabalin",
      "screen_name" : "voxpuibr",
      "indices" : [ 0, 9 ],
      "id_str" : "41597893",
      "id" : 41597893
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "deathday",
      "indices" : [ 77, 86 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "335462666539786240",
  "geo" : {
  },
  "id_str" : "335465644373991424",
  "in_reply_to_user_id" : 41597893,
  "text" : "@voxpuibr On May 20th, your life expectancy will be exactly 54 years. Enjoy! #deathday",
  "id" : 335465644373991424,
  "in_reply_to_status_id" : 335462666539786240,
  "created_at" : "Fri May 17 18:43:36 +0000 2013",
  "in_reply_to_screen_name" : "voxpuibr",
  "in_reply_to_user_id_str" : "41597893",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Majcher",
      "screen_name" : "majcher",
      "indices" : [ 0, 8 ],
      "id_str" : "1289051",
      "id" : 1289051
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "deathday",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "335461921291644928",
  "geo" : {
  },
  "id_str" : "335465362755829761",
  "in_reply_to_user_id" : 1289051,
  "text" : "@majcher You will die on May 20th, 2052 (38.9 years from now). Happy #deathday!",
  "id" : 335465362755829761,
  "in_reply_to_status_id" : 335461921291644928,
  "created_at" : "Fri May 17 18:42:29 +0000 2013",
  "in_reply_to_screen_name" : "majcher",
  "in_reply_to_user_id_str" : "1289051",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elisabeth Flottman",
      "screen_name" : "flottman",
      "indices" : [ 0, 9 ],
      "id_str" : "261383611",
      "id" : 261383611
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "deathday",
      "indices" : [ 84, 93 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "335451500396560384",
  "geo" : {
  },
  "id_str" : "335456274521145344",
  "in_reply_to_user_id" : 261383611,
  "text" : "@flottman On July 21st you'll have exactly 51 years of life expectancy left. Enjoy! #deathday",
  "id" : 335456274521145344,
  "in_reply_to_status_id" : 335451500396560384,
  "created_at" : "Fri May 17 18:06:22 +0000 2013",
  "in_reply_to_screen_name" : "flottman",
  "in_reply_to_user_id_str" : "261383611",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Z. Lewis",
      "screen_name" : "aaronzlewis",
      "indices" : [ 0, 12 ],
      "id_str" : "237160435",
      "id" : 237160435
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "deathday",
      "indices" : [ 95, 104 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "335442660494020610",
  "geo" : {
  },
  "id_str" : "335456109554982912",
  "in_reply_to_user_id" : 237160435,
  "text" : "@aaronzlewis On January 1st, 2014 you'll have exactly 61 years of life expectancy left. Enjoy! #deathday",
  "id" : 335456109554982912,
  "in_reply_to_status_id" : 335442660494020610,
  "created_at" : "Fri May 17 18:05:43 +0000 2013",
  "in_reply_to_screen_name" : "aaronzlewis",
  "in_reply_to_user_id_str" : "237160435",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sharon",
      "screen_name" : "sharon",
      "indices" : [ 0, 7 ],
      "id_str" : "260",
      "id" : 260
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "335444104773255168",
  "geo" : {
  },
  "id_str" : "335455763608788992",
  "in_reply_to_user_id" : 260,
  "text" : "@sharon Ha, awesome. We'd make a good team. :)",
  "id" : 335455763608788992,
  "in_reply_to_status_id" : 335444104773255168,
  "created_at" : "Fri May 17 18:04:21 +0000 2013",
  "in_reply_to_screen_name" : "sharon",
  "in_reply_to_user_id_str" : "260",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jess",
      "screen_name" : "mibi",
      "indices" : [ 0, 5 ],
      "id_str" : "14965636",
      "id" : 14965636
    }, {
      "name" : "James Clear",
      "screen_name" : "james_clear",
      "indices" : [ 6, 18 ],
      "id_str" : "226428094",
      "id" : 226428094
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "335440619650555907",
  "geo" : {
  },
  "id_str" : "335455348699840512",
  "in_reply_to_user_id" : 14965636,
  "text" : "@mibi @james_clear That's not what I've found anecdotally, but happy to see any studies that say otherwise.",
  "id" : 335455348699840512,
  "in_reply_to_status_id" : 335440619650555907,
  "created_at" : "Fri May 17 18:02:42 +0000 2013",
  "in_reply_to_screen_name" : "mibi",
  "in_reply_to_user_id_str" : "14965636",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Clear",
      "screen_name" : "james_clear",
      "indices" : [ 1, 13 ],
      "id_str" : "226428094",
      "id" : 226428094
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "335435946684207104",
  "geo" : {
  },
  "id_str" : "335436787679903745",
  "in_reply_to_user_id" : 226428094,
  "text" : ".@james_clear About those 100 studies\u2026 were they randomized double blind with placebo control? Were they statistically significant?",
  "id" : 335436787679903745,
  "in_reply_to_status_id" : 335435946684207104,
  "created_at" : "Fri May 17 16:48:56 +0000 2013",
  "in_reply_to_screen_name" : "james_clear",
  "in_reply_to_user_id_str" : "226428094",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Clear",
      "screen_name" : "james_clear",
      "indices" : [ 1, 13 ],
      "id_str" : "226428094",
      "id" : 226428094
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "335435946684207104",
  "geo" : {
  },
  "id_str" : "335436226339422208",
  "in_reply_to_user_id" : 226428094,
  "text" : ".@james_clear I've seen many programs/apps/etc use this method and continue to lose about 80% of people after 3 months. That's not success.",
  "id" : 335436226339422208,
  "in_reply_to_status_id" : 335435946684207104,
  "created_at" : "Fri May 17 16:46:43 +0000 2013",
  "in_reply_to_screen_name" : "james_clear",
  "in_reply_to_user_id_str" : "226428094",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen VanDelinder",
      "screen_name" : "Stevans311",
      "indices" : [ 0, 11 ],
      "id_str" : "143940248",
      "id" : 143940248
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "deathday",
      "indices" : [ 131, 140 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "335424572096659458",
  "geo" : {
  },
  "id_str" : "335433504949157889",
  "in_reply_to_user_id" : 143940248,
  "text" : "@Stevans311 On May 1st, 2014 (looks like your last one just passed a bit ago) your life expectancy will be exactly 55 years. Happy #deathday",
  "id" : 335433504949157889,
  "in_reply_to_status_id" : 335424572096659458,
  "created_at" : "Fri May 17 16:35:54 +0000 2013",
  "in_reply_to_screen_name" : "Stevans311",
  "in_reply_to_user_id_str" : "143940248",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcel Molina",
      "screen_name" : "noradio",
      "indices" : [ 0, 8 ],
      "id_str" : "3191321",
      "id" : 3191321
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "deathday",
      "indices" : [ 78, 87 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "335420412953501697",
  "geo" : {
  },
  "id_str" : "335433275852091392",
  "in_reply_to_user_id" : 3191321,
  "text" : "@noradio On August 29th your life expectancy will be exactly 49 years. Enjoy! #deathday",
  "id" : 335433275852091392,
  "in_reply_to_status_id" : 335420412953501697,
  "created_at" : "Fri May 17 16:34:59 +0000 2013",
  "in_reply_to_screen_name" : "noradio",
  "in_reply_to_user_id_str" : "3191321",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "@boylerob",
      "screen_name" : "boylerob",
      "indices" : [ 0, 9 ],
      "id_str" : "16641704",
      "id" : 16641704
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "deathday",
      "indices" : [ 72, 81 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "335420379432636417",
  "geo" : {
  },
  "id_str" : "335432892492693505",
  "in_reply_to_user_id" : 16641704,
  "text" : "@boylerob On July 21st you'll have exactly 51 years left to live. Happy #deathday :)",
  "id" : 335432892492693505,
  "in_reply_to_status_id" : 335420379432636417,
  "created_at" : "Fri May 17 16:33:28 +0000 2013",
  "in_reply_to_screen_name" : "boylerob",
  "in_reply_to_user_id_str" : "16641704",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ola Olusoga",
      "screen_name" : "olaolusoga",
      "indices" : [ 0, 11 ],
      "id_str" : "225261033",
      "id" : 225261033
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "deathday",
      "indices" : [ 72, 81 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "335416701883662337",
  "geo" : {
  },
  "id_str" : "335432592478306304",
  "in_reply_to_user_id" : 225261033,
  "text" : "@olaolusoga On May 20th (3 days away!) you'll have 54 years left. Happy #deathday",
  "id" : 335432592478306304,
  "in_reply_to_status_id" : 335416701883662337,
  "created_at" : "Fri May 17 16:32:16 +0000 2013",
  "in_reply_to_screen_name" : "olaolusoga",
  "in_reply_to_user_id_str" : "225261033",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Clear",
      "screen_name" : "james_clear",
      "indices" : [ 1, 13 ],
      "id_str" : "226428094",
      "id" : 226428094
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "335401893163573248",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8021622289, -122.2795743812 ]
  },
  "id_str" : "335424653189332993",
  "in_reply_to_user_id" : 226428094,
  "text" : ".@james_clear I don't think it's honest to claim benefits when results are counted in days/weeks. Does this trick work 3 months out? 6? 60?",
  "id" : 335424653189332993,
  "in_reply_to_status_id" : 335401893163573248,
  "created_at" : "Fri May 17 16:00:43 +0000 2013",
  "in_reply_to_screen_name" : "james_clear",
  "in_reply_to_user_id_str" : "226428094",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http://t.co/d4Y0JK4aL9",
      "expanded_url" : "http://bit.ly/18Qbj22",
      "display_url" : "bit.ly/18Qbj22"
    } ]
  },
  "geo" : {
  },
  "id_str" : "335415699390472192",
  "text" : "My next deathday is December 14th, when I'll have 44 years left. What's yours? http://t.co/d4Y0JK4aL9",
  "id" : 335415699390472192,
  "created_at" : "Fri May 17 15:25:09 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Rainert",
      "screen_name" : "arainert",
      "indices" : [ 3, 12 ],
      "id_str" : "7482",
      "id" : 7482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http://t.co/AKIED8BR1n",
      "expanded_url" : "http://www.wired.com/gadgetlab/2013/05/on-google-island/",
      "display_url" : "wired.com/gadgetlab/2013\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "335401563021516800",
  "text" : "RT @arainert: Smart, fun, read to kick off your Friday &gt;&gt; Welcome to Google Island http://t.co/AKIED8BR1n",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 75, 97 ],
        "url" : "http://t.co/AKIED8BR1n",
        "expanded_url" : "http://www.wired.com/gadgetlab/2013/05/on-google-island/",
        "display_url" : "wired.com/gadgetlab/2013\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "335393754196365312",
    "text" : "Smart, fun, read to kick off your Friday &gt;&gt; Welcome to Google Island http://t.co/AKIED8BR1n",
    "id" : 335393754196365312,
    "created_at" : "Fri May 17 13:57:56 +0000 2013",
    "user" : {
      "name" : "Alex Rainert",
      "screen_name" : "arainert",
      "protected" : false,
      "id_str" : "7482",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2818437555/d807940fc40f9eb0abc24cf89e667af6_normal.png",
      "id" : 7482,
      "verified" : false
    }
  },
  "id" : 335401563021516800,
  "created_at" : "Fri May 17 14:28:58 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "335283475676557312",
  "text" : "Think Bayesianly.",
  "id" : 335283475676557312,
  "created_at" : "Fri May 17 06:39:44 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "335275746035646464",
  "text" : "For people between 35-44, accidents are the leading cause of death.",
  "id" : 335275746035646464,
  "created_at" : "Fri May 17 06:09:01 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Crocker",
      "screen_name" : "nickcrocker",
      "indices" : [ 98, 110 ],
      "id_str" : "30801469",
      "id" : 30801469
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https://t.co/tFK2a20nFT",
      "expanded_url" : "https://medium.com/health-the-future/b69bb4b5c2c0",
      "display_url" : "medium.com/health-the-fut\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "335259648162689024",
  "text" : "I'd say the *shortest*. &gt;10 is good too. \"The only health timeline that matters is 10 years.\" -@nickcrocker https://t.co/tFK2a20nFT",
  "id" : 335259648162689024,
  "created_at" : "Fri May 17 05:05:03 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "335255219766169600",
  "text" : "The average chance of dying at any given age has dropped 60% since 1935 in the US.",
  "id" : 335255219766169600,
  "created_at" : "Fri May 17 04:47:27 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Torrez",
      "screen_name" : "torrez",
      "indices" : [ 3, 10 ],
      "id_str" : "11604",
      "id" : 11604
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 39 ],
      "url" : "http://t.co/5rYVktkk8i",
      "expanded_url" : "http://www.etsy.com/shop/SuAmi",
      "display_url" : "etsy.com/shop/SuAmi"
    } ]
  },
  "geo" : {
  },
  "id_str" : "335253025469898754",
  "text" : "RT @torrez: Whoa http://t.co/5rYVktkk8i miniature crocheted animals.",
  "retweeted_status" : {
    "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 5, 27 ],
        "url" : "http://t.co/5rYVktkk8i",
        "expanded_url" : "http://www.etsy.com/shop/SuAmi",
        "display_url" : "etsy.com/shop/SuAmi"
      } ]
    },
    "geo" : {
    },
    "id_str" : "335251886393417728",
    "text" : "Whoa http://t.co/5rYVktkk8i miniature crocheted animals.",
    "id" : 335251886393417728,
    "created_at" : "Fri May 17 04:34:13 +0000 2013",
    "user" : {
      "name" : "Andre Torrez",
      "screen_name" : "torrez",
      "protected" : false,
      "id_str" : "11604",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000074230414/8dc0509ae34aa9187c69d9d563f5a8db_normal.png",
      "id" : 11604,
      "verified" : false
    }
  },
  "id" : 335253025469898754,
  "created_at" : "Fri May 17 04:38:44 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 52 ],
      "url" : "http://t.co/ngzgEnVDwx",
      "expanded_url" : "http://flic.kr/p/ejWkby",
      "display_url" : "flic.kr/p/ejWkby"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859666, -122.2755 ]
  },
  "id_str" : "335238566357651456",
  "text" : "8:36pm qwertyujkkuiol\u00ECopassdv http://t.co/ngzgEnVDwx",
  "id" : 335238566357651456,
  "created_at" : "Fri May 17 03:41:17 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"https://itunes.apple.com/us/app/polar/id563322683?mt=8&uo=4\" rel=\"nofollow\">Polar on iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 49 ],
      "url" : "http://t.co/vRRuR1dMED",
      "expanded_url" : "http://polarb.com/88533",
      "display_url" : "polarb.com/88533"
    } ]
  },
  "geo" : {
  },
  "id_str" : "335205265215459328",
  "text" : "Which Would You Rather Be? http://t.co/vRRuR1dMED",
  "id" : 335205265215459328,
  "created_at" : "Fri May 17 01:28:57 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rock Health",
      "screen_name" : "Rock_Health",
      "indices" : [ 28, 40 ],
      "id_str" : "161372707",
      "id" : 161372707
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "335171771215011840",
  "text" : "How many work? 0.73%? :) RT @Rock_Health: New study shows 73% of employers have digital strategies for keeping their employees healthy...",
  "id" : 335171771215011840,
  "created_at" : "Thu May 16 23:15:52 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Polar",
      "screen_name" : "polarpolls",
      "indices" : [ 3, 14 ],
      "id_str" : "870483607",
      "id" : 870483607
    }, {
      "name" : "Buster",
      "screen_name" : "buster",
      "indices" : [ 16, 23 ],
      "id_str" : "2185",
      "id" : 2185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http://t.co/rBBYjLoQqm",
      "expanded_url" : "http://polarb.com/88419",
      "display_url" : "polarb.com/88419"
    } ]
  },
  "geo" : {
  },
  "id_str" : "335074654802804736",
  "text" : "RT @polarpolls: @buster More Good Bands or Good Band Names? http://t.co/rBBYjLoQqm Put it to a vote!",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Buster",
        "screen_name" : "buster",
        "indices" : [ 0, 7 ],
        "id_str" : "2185",
        "id" : 2185
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 44, 66 ],
        "url" : "http://t.co/rBBYjLoQqm",
        "expanded_url" : "http://polarb.com/88419",
        "display_url" : "polarb.com/88419"
      } ]
    },
    "in_reply_to_status_id_str" : "335061067308883968",
    "geo" : {
    },
    "id_str" : "335070941073772544",
    "in_reply_to_user_id" : 2185,
    "text" : "@buster More Good Bands or Good Band Names? http://t.co/rBBYjLoQqm Put it to a vote!",
    "id" : 335070941073772544,
    "in_reply_to_status_id" : 335061067308883968,
    "created_at" : "Thu May 16 16:35:12 +0000 2013",
    "in_reply_to_screen_name" : "buster",
    "in_reply_to_user_id_str" : "2185",
    "user" : {
      "name" : "Polar",
      "screen_name" : "polarpolls",
      "protected" : false,
      "id_str" : "870483607",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2699403897/76af188bcecfbebdf2a35af536937e81_normal.png",
      "id" : 870483607,
      "verified" : false
    }
  },
  "id" : 335074654802804736,
  "created_at" : "Thu May 16 16:49:57 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7933822878, -122.3962498724 ]
  },
  "id_str" : "335070440131293185",
  "text" : "\"You can't find love in a dictionary.\"",
  "id" : 335070440131293185,
  "created_at" : "Thu May 16 16:33:12 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jane McGonigal",
      "screen_name" : "avantgame",
      "indices" : [ 0, 10 ],
      "id_str" : "681813",
      "id" : 681813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "335060555024986112",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596867295, -122.2754482181 ]
  },
  "id_str" : "335061500848906240",
  "in_reply_to_user_id" : 681813,
  "text" : "@avantgame I just prepare myself for death. :)",
  "id" : 335061500848906240,
  "in_reply_to_status_id" : 335060555024986112,
  "created_at" : "Thu May 16 15:57:41 +0000 2013",
  "in_reply_to_screen_name" : "avantgame",
  "in_reply_to_user_id_str" : "681813",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597252196, -122.275399354 ]
  },
  "id_str" : "335061067308883968",
  "text" : "Are there more good bands or more good band names in the world?",
  "id" : 335061067308883968,
  "created_at" : "Thu May 16 15:55:58 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Venessa Goldberg",
      "screen_name" : "kernelsandseeds",
      "indices" : [ 0, 16 ],
      "id_str" : "174538822",
      "id" : 174538822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "334880509568114688",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597234641, -122.2755763192 ]
  },
  "id_str" : "334884955928805377",
  "in_reply_to_user_id" : 174538822,
  "text" : "@kernelsandseeds He's exploring names for me right now: poppa, daddy, Buster, and his favorite: moppa. It's pretty hilarious.",
  "id" : 334884955928805377,
  "in_reply_to_status_id" : 334880509568114688,
  "created_at" : "Thu May 16 04:16:10 +0000 2013",
  "in_reply_to_screen_name" : "kernelsandseeds",
  "in_reply_to_user_id_str" : "174538822",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http://t.co/pZQzxyAmx4",
      "expanded_url" : "http://flic.kr/p/ejDDTb",
      "display_url" : "flic.kr/p/ejDDTb"
    } ]
  },
  "geo" : {
  },
  "id_str" : "334879206632742912",
  "text" : "There's no party like bubble wrap in a bathtub party http://t.co/pZQzxyAmx4",
  "id" : 334879206632742912,
  "created_at" : "Thu May 16 03:53:19 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http://t.co/hivvGbBtsX",
      "expanded_url" : "http://flic.kr/p/ejxMse",
      "display_url" : "flic.kr/p/ejxMse"
    } ]
  },
  "geo" : {
  },
  "id_str" : "334875101117964288",
  "text" : "8:36pm 3 years with Niko. I'm really excited about the guy he's becoming.  http://t.co/hivvGbBtsX",
  "id" : 334875101117964288,
  "created_at" : "Thu May 16 03:37:00 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://vine.co\" rel=\"nofollow\">Vine - Make a Scene</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 41 ],
      "url" : "https://t.co/eZZNkrfZem",
      "expanded_url" : "https://vine.co/v/bEiOEA2whDY",
      "display_url" : "vine.co/v/bEiOEA2whDY"
    } ]
  },
  "geo" : {
  },
  "id_str" : "334865746817581058",
  "text" : "Birthday cupcake! https://t.co/eZZNkrfZem",
  "id" : 334865746817581058,
  "created_at" : "Thu May 16 02:59:50 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://vine.co\" rel=\"nofollow\">Vine - Make a Scene</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 46 ],
      "url" : "https://t.co/Az1IkZ2t3j",
      "expanded_url" : "https://vine.co/v/bEiADTYgYnM",
      "display_url" : "vine.co/v/bEiADTYgYnM"
    } ]
  },
  "geo" : {
  },
  "id_str" : "334862188709814274",
  "text" : "Niko's birthday trick! https://t.co/Az1IkZ2t3j",
  "id" : 334862188709814274,
  "created_at" : "Thu May 16 02:45:41 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/instagram/id389801252?mt=8&uo=4\" rel=\"nofollow\">Instagram on iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http://t.co/Hq8Pjn5fJk",
      "expanded_url" : "http://instagram.com/p/ZWbn-HuFdH/",
      "display_url" : "instagram.com/p/ZWbn-HuFdH/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.776565, -122.416808 ]
  },
  "id_str" : "334841162567409664",
  "text" : "Niko's birthday wish: brown cupcakes with pink frosting and eyeballs http://t.co/Hq8Pjn5fJk",
  "id" : 334841162567409664,
  "created_at" : "Thu May 16 01:22:08 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Stump",
      "screen_name" : "joestump",
      "indices" : [ 0, 9 ],
      "id_str" : "4234581",
      "id" : 4234581
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "334703584719564800",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8280864517, -122.2672972364 ]
  },
  "id_str" : "334704321373536256",
  "in_reply_to_user_id" : 4234581,
  "text" : "@joestump Yeah, but with an attempt to find the price. It's not necessarily \"all my money\", right",
  "id" : 334704321373536256,
  "in_reply_to_status_id" : 334703584719564800,
  "created_at" : "Wed May 15 16:18:23 +0000 2013",
  "in_reply_to_screen_name" : "joestump",
  "in_reply_to_user_id_str" : "4234581",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "whitney erin boesel",
      "screen_name" : "phenatypical",
      "indices" : [ 3, 16 ],
      "id_str" : "264101497",
      "id" : 264101497
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "qseu13",
      "indices" : [ 22, 29 ]
    }, {
      "text" : "QuantifiedSelf",
      "indices" : [ 67, 82 ]
    }, {
      "text" : "QuantifiedWorkplace",
      "indices" : [ 86, 106 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "334703552314347521",
  "text" : "RT @phenatypical: hey #qseu13: a few of us just moved our conv re: #QuantifiedSelf vs #QuantifiedWorkplace over to QS Forums\u2014join us! https\u2026",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "qseu13",
        "indices" : [ 4, 11 ]
      }, {
        "text" : "QuantifiedSelf",
        "indices" : [ 49, 64 ]
      }, {
        "text" : "QuantifiedWorkplace",
        "indices" : [ 68, 88 ]
      } ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https://t.co/HMYPjuZpwz",
        "expanded_url" : "https://forum.quantifiedself.com/thread-quantified-self-vs-quantified-workplace",
        "display_url" : "forum.quantifiedself.com/thread-quantif\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "334702286922207232",
    "text" : "hey #qseu13: a few of us just moved our conv re: #QuantifiedSelf vs #QuantifiedWorkplace over to QS Forums\u2014join us! https://t.co/HMYPjuZpwz",
    "id" : 334702286922207232,
    "created_at" : "Wed May 15 16:10:18 +0000 2013",
    "user" : {
      "name" : "whitney erin boesel",
      "screen_name" : "phenatypical",
      "protected" : false,
      "id_str" : "264101497",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2270262889/sit262rf3jg1n4ne6qp4_normal.jpeg",
      "id" : 264101497,
      "verified" : false
    }
  },
  "id" : 334703552314347521,
  "created_at" : "Wed May 15 16:15:20 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8531921061, -122.2704087862 ]
  },
  "id_str" : "334703466641518592",
  "text" : "Considering how much money you actually have access to, what is the max price you'd pay to opt out of Russian Roulette?",
  "id" : 334703466641518592,
  "created_at" : "Wed May 15 16:14:59 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carinna Tarvin",
      "screen_name" : "carinnatarvin",
      "indices" : [ 48, 62 ],
      "id_str" : "20833838",
      "id" : 20833838
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "3years",
      "indices" : [ 84, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http://t.co/fjpbLIJaIa",
      "expanded_url" : "http://flic.kr/p/ejoeLg",
      "display_url" : "flic.kr/p/ejoeLg"
    } ]
  },
  "geo" : {
  },
  "id_str" : "334693780190023680",
  "text" : "Telling Niko his birth story with the baby book @carinnatarvin put together for him #3years http://t.co/fjpbLIJaIa",
  "id" : 334693780190023680,
  "created_at" : "Wed May 15 15:36:30 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "rstevens 3.01",
      "screen_name" : "rstevens",
      "indices" : [ 3, 12 ],
      "id_str" : "643653",
      "id" : 643653
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "334687815931674625",
  "text" : "RT @rstevens: Self-driving cars aren\u2019t quite there yet. Still in the Uncanny Valet.",
  "retweeted_status" : {
    "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "334686406234492928",
    "text" : "Self-driving cars aren\u2019t quite there yet. Still in the Uncanny Valet.",
    "id" : 334686406234492928,
    "created_at" : "Wed May 15 15:07:12 +0000 2013",
    "user" : {
      "name" : "rstevens 3.01",
      "screen_name" : "rstevens",
      "protected" : false,
      "id_str" : "643653",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1828254293/coffeepot-twitter_normal.png",
      "id" : 643653,
      "verified" : false
    }
  },
  "id" : 334687815931674625,
  "created_at" : "Wed May 15 15:12:48 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twitter Books",
      "screen_name" : "TwitterBooks",
      "indices" : [ 34, 47 ],
      "id_str" : "427475002",
      "id" : 427475002
    }, {
      "name" : "Richard Dawkins",
      "screen_name" : "RichardDawkins",
      "indices" : [ 49, 64 ],
      "id_str" : "15143478",
      "id" : 15143478
    }, {
      "name" : "Daniel Dennett",
      "screen_name" : "danieldennett",
      "indices" : [ 77, 91 ],
      "id_str" : "997629601",
      "id" : 997629601
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http://t.co/rI97VDhVU9",
      "expanded_url" : "http://storify.com/wwnorton/richard-dawkins-livetweets-while-reading-daniel-de",
      "display_url" : "storify.com/wwnorton/richa\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "334685351836790784",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597099236, -122.2755501469 ]
  },
  "id_str" : "334687578680877056",
  "in_reply_to_user_id" : 427475002,
  "text" : "Reading this now. Anyone else? RT @TwitterBooks: @richarddawkins live-tweets @danieldennett's new book: http://t.co/rI97VDhVU9",
  "id" : 334687578680877056,
  "in_reply_to_status_id" : 334685351836790784,
  "created_at" : "Wed May 15 15:11:51 +0000 2013",
  "in_reply_to_screen_name" : "TwitterBooks",
  "in_reply_to_user_id_str" : "427475002",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jack Dorsey",
      "screen_name" : "jack",
      "indices" : [ 35, 40 ],
      "id_str" : "12",
      "id" : 12
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 31 ],
      "url" : "http://t.co/ps0awRhBu2",
      "expanded_url" : "http://bustr.me/post/15673522373/no-biggie",
      "display_url" : "bustr.me/post/156735223\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "334673389367209984",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596893568, -122.2755196034 ]
  },
  "id_str" : "334677943760588801",
  "in_reply_to_user_id" : 12,
  "text" : "Related: http://t.co/ps0awRhBu2 RT @jack: \u201CEveryone thinks of changing the world, but no one thinks of changing himself.\u201D\u2015Leo Tolstoy",
  "id" : 334677943760588801,
  "in_reply_to_status_id" : 334673389367209984,
  "created_at" : "Wed May 15 14:33:34 +0000 2013",
  "in_reply_to_screen_name" : "jack",
  "in_reply_to_user_id_str" : "12",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jane McGonigal",
      "screen_name" : "avantgame",
      "indices" : [ 3, 13 ],
      "id_str" : "681813",
      "id" : 681813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "334676694675886081",
  "text" : "RT @avantgame: The idea that \"a bit of friendly competition\" is always good for motivation is so wrong and so broken and yet SO ENTRENCHED \u2026",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "334671697603096577",
    "text" : "The idea that \"a bit of friendly competition\" is always good for motivation is so wrong and so broken and yet SO ENTRENCHED it's shocking.",
    "id" : 334671697603096577,
    "created_at" : "Wed May 15 14:08:45 +0000 2013",
    "user" : {
      "name" : "Jane McGonigal",
      "screen_name" : "avantgame",
      "protected" : false,
      "id_str" : "681813",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000116152853/47c4501ee2d80e97b423129fe0db016a_normal.jpeg",
      "id" : 681813,
      "verified" : false
    }
  },
  "id" : 334676694675886081,
  "created_at" : "Wed May 15 14:28:36 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jane McGonigal",
      "screen_name" : "avantgame",
      "indices" : [ 1, 11 ],
      "id_str" : "681813",
      "id" : 681813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "334667654575042560",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596980451, -122.2754545883 ]
  },
  "id_str" : "334674489981943810",
  "in_reply_to_user_id" : 681813,
  "text" : ".@avantgame Pulling the motivation levers is like scanning a crowd with a flashlight. You'll always hit someone, and miss a whole bunch too.",
  "id" : 334674489981943810,
  "in_reply_to_status_id" : 334667654575042560,
  "created_at" : "Wed May 15 14:19:51 +0000 2013",
  "in_reply_to_screen_name" : "avantgame",
  "in_reply_to_user_id_str" : "681813",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Deterding",
      "screen_name" : "dingstweets",
      "indices" : [ 0, 12 ],
      "id_str" : "14435477",
      "id" : 14435477
    }, {
      "name" : "Jane McGonigal",
      "screen_name" : "avantgame",
      "indices" : [ 13, 23 ],
      "id_str" : "681813",
      "id" : 681813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "334667018802446336",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596988833, -122.275448721 ]
  },
  "id_str" : "334673171066265601",
  "in_reply_to_user_id" : 14435477,
  "text" : "@dingstweets @avantgame I don't think it's possible to find a perfect balance though. Adding prizes will gain some, lose others.",
  "id" : 334673171066265601,
  "in_reply_to_status_id" : 334667018802446336,
  "created_at" : "Wed May 15 14:14:36 +0000 2013",
  "in_reply_to_screen_name" : "dingstweets",
  "in_reply_to_user_id_str" : "14435477",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "whitney erin boesel",
      "screen_name" : "phenatypical",
      "indices" : [ 90, 103 ],
      "id_str" : "264101497",
      "id" : 264101497
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "followateen",
      "indices" : [ 25, 37 ]
    }, {
      "text" : "followanadult",
      "indices" : [ 41, 55 ]
    } ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http://t.co/VR7atDu41e",
      "expanded_url" : "http://gawker.com/followateen-twitter-trend-sparks-epic-teen-vs-adult-w-489397307",
      "display_url" : "gawker.com/followateen-tw\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596134497, -122.2755814849 ]
  },
  "id_str" : "334671296040423428",
  "text" : "Where can I get my teen? #followateen vs #followanadult wars: http://t.co/VR7atDu41e /via @phenatypical",
  "id" : 334671296040423428,
  "created_at" : "Wed May 15 14:07:09 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Metcalf",
      "screen_name" : "robbymet",
      "indices" : [ 0, 9 ],
      "id_str" : "27112594",
      "id" : 27112594
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "334565994594959360",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8595422652, -122.2755518513 ]
  },
  "id_str" : "334667302308044800",
  "in_reply_to_user_id" : 27112594,
  "text" : "@robbymet You get all the credit for this kind of achievement. Congrats!",
  "id" : 334667302308044800,
  "in_reply_to_status_id" : 334565994594959360,
  "created_at" : "Wed May 15 13:51:17 +0000 2013",
  "in_reply_to_screen_name" : "robbymet",
  "in_reply_to_user_id_str" : "27112594",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Metcalf",
      "screen_name" : "robbymet",
      "indices" : [ 12, 21 ],
      "id_str" : "27112594",
      "id" : 27112594
    }, {
      "name" : "Buster",
      "screen_name" : "buster",
      "indices" : [ 86, 93 ],
      "id_str" : "2185",
      "id" : 2185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http://t.co/qjUH5AFHun",
      "expanded_url" : "http://750words.com",
      "display_url" : "750words.com"
    } ]
  },
  "in_reply_to_status_id_str" : "334565994594959360",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596452515, -122.2755467431 ]
  },
  "id_str" : "334666996341952512",
  "in_reply_to_user_id" : 27112594,
  "text" : "Amazing! RT @robbymet: Wrote for my 500th day in a row at http://t.co/qjUH5AFHun. Thx @buster for building the venue for such a great habit!",
  "id" : 334666996341952512,
  "in_reply_to_status_id" : 334565994594959360,
  "created_at" : "Wed May 15 13:50:04 +0000 2013",
  "in_reply_to_screen_name" : "robbymet",
  "in_reply_to_user_id_str" : "27112594",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 79 ],
      "url" : "http://t.co/t0YHiQLoMz",
      "expanded_url" : "http://flic.kr/p/ejhsLF",
      "display_url" : "flic.kr/p/ejhsLF"
    } ]
  },
  "geo" : {
  },
  "id_str" : "334531584864706560",
  "text" : "8:36pm Special Niko birthday eve bedtime reading edition http://t.co/t0YHiQLoMz",
  "id" : 334531584864706560,
  "created_at" : "Wed May 15 04:51:59 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8560683414, -122.2712846271 ]
  },
  "id_str" : "334490133002870784",
  "text" : "If the Internet has computing power and memory X, how many X would an artificial human brain need to power it? Henry Markram says 500X.",
  "id" : 334490133002870784,
  "created_at" : "Wed May 15 02:07:16 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Crocker",
      "screen_name" : "nickcrocker",
      "indices" : [ 8, 20 ],
      "id_str" : "30801469",
      "id" : 30801469
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https://t.co/tFK2a20nFT",
      "expanded_url" : "https://medium.com/health-the-future/b69bb4b5c2c0",
      "display_url" : "medium.com/health-the-fut\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "334481045439254528",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8033293875, -122.2915249105 ]
  },
  "id_str" : "334485658255118336",
  "in_reply_to_user_id" : 30801469,
  "text" : "Yes! RT @nickcrocker: I just published \"Health With a 10 Year Horizon\" https://t.co/tFK2a20nFT",
  "id" : 334485658255118336,
  "in_reply_to_status_id" : 334481045439254528,
  "created_at" : "Wed May 15 01:49:30 +0000 2013",
  "in_reply_to_screen_name" : "nickcrocker",
  "in_reply_to_user_id_str" : "30801469",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ingopixel",
      "screen_name" : "ingopixel",
      "indices" : [ 0, 10 ],
      "id_str" : "7943892",
      "id" : 7943892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "334453925963001856",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7769760535, -122.4172067393 ]
  },
  "id_str" : "334457017156653056",
  "in_reply_to_user_id" : 7943892,
  "text" : "@ingopixel YAY!!!",
  "id" : 334457017156653056,
  "in_reply_to_status_id" : 334453925963001856,
  "created_at" : "Tue May 14 23:55:41 +0000 2013",
  "in_reply_to_screen_name" : "ingopixel",
  "in_reply_to_user_id_str" : "7943892",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Porad",
      "screen_name" : "scottporad",
      "indices" : [ 45, 56 ],
      "id_str" : "15876737",
      "id" : 15876737
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http://t.co/DGvrjVwdBp",
      "expanded_url" : "http://tnnmn.com",
      "display_url" : "tnnmn.com"
    } ]
  },
  "geo" : {
  },
  "id_str" : "334366679012372480",
  "text" : "News about how news is changing - awesome RT @scottporad: I launched a new site about online media and storytelling: http://t.co/DGvrjVwdBp",
  "id" : 334366679012372480,
  "created_at" : "Tue May 14 17:56:43 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7881893538, -122.4024601126 ]
  },
  "id_str" : "334346232787005441",
  "text" : "A habit is something you do because it's normal to you. Forget intrinsic/extrinsic motivation, homeostatic motivation is where it's at.",
  "id" : 334346232787005441,
  "created_at" : "Tue May 14 16:35:28 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http://t.co/j9YjwcA9HA",
      "expanded_url" : "http://flic.kr/p/ej7FC5",
      "display_url" : "flic.kr/p/ej7FC5"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859833, -122.2755 ]
  },
  "id_str" : "334154409758044163",
  "text" : "8:36pm Nice soft bed after 24 hours of flying in last couple days http://t.co/j9YjwcA9HA",
  "id" : 334154409758044163,
  "created_at" : "Tue May 14 03:53:14 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Moschel",
      "screen_name" : "MarkMoschel",
      "indices" : [ 0, 12 ],
      "id_str" : "431195617",
      "id" : 431195617
    }, {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 13, 22 ],
      "id_str" : "21135674",
      "id" : 21135674
    }, {
      "name" : "Gary Wolf",
      "screen_name" : "agaricus",
      "indices" : [ 23, 32 ],
      "id_str" : "21678279",
      "id" : 21678279
    }, {
      "name" : "David Andre",
      "screen_name" : "dandre",
      "indices" : [ 33, 40 ],
      "id_str" : "10148302",
      "id" : 10148302
    }, {
      "name" : "Joost Plattel",
      "screen_name" : "jplattel",
      "indices" : [ 41, 50 ],
      "id_str" : "16376925",
      "id" : 16376925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "334044953875472385",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596951533, -122.2754550074 ]
  },
  "id_str" : "334103329254821888",
  "in_reply_to_user_id" : 431195617,
  "text" : "@MarkMoschel @eramirez @agaricus @dandre @jplattel Agree! Truly an inspirational group.",
  "id" : 334103329254821888,
  "in_reply_to_status_id" : 334044953875472385,
  "created_at" : "Tue May 14 00:30:15 +0000 2013",
  "in_reply_to_screen_name" : "MarkMoschel",
  "in_reply_to_user_id_str" : "431195617",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Maarten den Braber",
      "screen_name" : "mdbraber",
      "indices" : [ 0, 9 ],
      "id_str" : "9938952",
      "id" : 9938952
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "qseu13",
      "indices" : [ 47, 54 ]
    } ],
    "urls" : [ {
      "indices" : [ 24, 46 ],
      "url" : "http://t.co/A0UFBaIRjV",
      "expanded_url" : "http://bit.ly/qseu13-836",
      "display_url" : "bit.ly/qseu13-836"
    } ]
  },
  "in_reply_to_status_id_str" : "334051113001160704",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8288148353, -122.2489946134 ]
  },
  "id_str" : "334053316894011394",
  "in_reply_to_user_id" : 9938952,
  "text" : "@mdbraber Trying again: http://t.co/A0UFBaIRjV #qseu13",
  "id" : 334053316894011394,
  "in_reply_to_status_id" : 334051113001160704,
  "created_at" : "Mon May 13 21:11:31 +0000 2013",
  "in_reply_to_screen_name" : "mdbraber",
  "in_reply_to_user_id_str" : "9938952",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "qseu13",
      "indices" : [ 63, 70 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http://t.co/cmynIxBm74",
      "expanded_url" : "http://flic.kr/p/eiLdVz",
      "display_url" : "flic.kr/p/eiLdVz"
    } ]
  },
  "geo" : {
  },
  "id_str" : "333840308490084353",
  "text" : "Had a great time at Quantified Self Europe. Thanks, everybody! #qseu13 http://t.co/cmynIxBm74",
  "id" : 333840308490084353,
  "created_at" : "Mon May 13 07:05:06 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 59 ],
      "url" : "http://t.co/ag0JLscCdO",
      "expanded_url" : "http://flic.kr/p/eiBvQ4",
      "display_url" : "flic.kr/p/eiBvQ4"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.387666, 4.873 ]
  },
  "id_str" : "333669301225672704",
  "text" : "8:36pm Amsterdam food truck festival http://t.co/ag0JLscCdO",
  "id" : 333669301225672704,
  "created_at" : "Sun May 12 19:45:35 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "vonhaller",
      "screen_name" : "vonhaller",
      "indices" : [ 0, 10 ],
      "id_str" : "14685808",
      "id" : 14685808
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "333599130297438210",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.3500220589, 4.9184094326 ]
  },
  "id_str" : "333605786343337986",
  "in_reply_to_user_id" : 14685808,
  "text" : "@vonhaller Yeah you're right. That's why I put \"uncurated\" in quotes... but neglected to mention it.",
  "id" : 333605786343337986,
  "in_reply_to_status_id" : 333599130297438210,
  "created_at" : "Sun May 12 15:33:12 +0000 2013",
  "in_reply_to_screen_name" : "vonhaller",
  "in_reply_to_user_id_str" : "14685808",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Maarten den Braber",
      "screen_name" : "mdbraber",
      "indices" : [ 3, 12 ],
      "id_str" : "9938952",
      "id" : 9938952
    }, {
      "name" : "Buster",
      "screen_name" : "buster",
      "indices" : [ 73, 80 ],
      "id_str" : "2185",
      "id" : 2185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "333598792714698752",
  "text" : "RT @mdbraber: \u201CPrivacy is a side-effect of people not being connected\u201D \u2014 @buster",
  "retweeted_status" : {
    "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Buster",
        "screen_name" : "buster",
        "indices" : [ 59, 66 ],
        "id_str" : "2185",
        "id" : 2185
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "333594651745472512",
    "text" : "\u201CPrivacy is a side-effect of people not being connected\u201D \u2014 @buster",
    "id" : 333594651745472512,
    "created_at" : "Sun May 12 14:48:57 +0000 2013",
    "user" : {
      "name" : "Maarten den Braber",
      "screen_name" : "mdbraber",
      "protected" : false,
      "id_str" : "9938952",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2434726905/7uwtpskvegrocpu03tta_normal.jpeg",
      "id" : 9938952,
      "verified" : false
    }
  },
  "id" : 333598792714698752,
  "created_at" : "Sun May 12 15:05:24 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "qseu13",
      "indices" : [ 61, 68 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.3498256402, 4.918517237 ]
  },
  "id_str" : "333582626092900353",
  "text" : "\"When things become more fool-proof we become better fools.\" #qseu13 talk on measuring subjective states about creating feedback loops",
  "id" : 333582626092900353,
  "created_at" : "Sun May 12 14:01:10 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carlos Rizo, MD",
      "screen_name" : "carlosrizo",
      "indices" : [ 85, 96 ],
      "id_str" : "14128901",
      "id" : 14128901
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/buster/status/333531336159666176/photo/1",
      "indices" : [ 98, 120 ],
      "url" : "http://t.co/zTs2l3QjjE",
      "media_url" : "http://pbs.twimg.com/media/BKDw-62CIAAMxbc.jpg",
      "id_str" : "333531336163860480",
      "id" : 333531336163860480,
      "media_url_https" : "https://pbs.twimg.com/media/BKDw-62CIAAMxbc.jpg",
      "sizes" : [ {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      } ],
      "display_url" : "pic.twitter.com/zTs2l3QjjE"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.3497912154, 4.9185151154 ]
  },
  "id_str" : "333531336159666176",
  "text" : "Just changed my phone password to something that makes me happy. Thanks for the tip, @carlosrizo! http://t.co/zTs2l3QjjE",
  "id" : 333531336159666176,
  "created_at" : "Sun May 12 10:37:22 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Jonas",
      "screen_name" : "skjonas",
      "indices" : [ 3, 11 ],
      "id_str" : "8039012",
      "id" : 8039012
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "QSEU13",
      "indices" : [ 123, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "333498825568292864",
  "text" : "RT @skjonas: Normally treated as the rarely seen unicorn of gadgets, it's surprising to see the ubiquity of Basis Bands at #QSEU13.",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "QSEU13",
        "indices" : [ 110, 117 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "333487471499296768",
    "text" : "Normally treated as the rarely seen unicorn of gadgets, it's surprising to see the ubiquity of Basis Bands at #QSEU13.",
    "id" : 333487471499296768,
    "created_at" : "Sun May 12 07:43:03 +0000 2013",
    "user" : {
      "name" : "Steven Jonas",
      "screen_name" : "skjonas",
      "protected" : false,
      "id_str" : "8039012",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2282774040/97lekzxeau4saonze5rh_normal.jpeg",
      "id" : 8039012,
      "verified" : false
    }
  },
  "id" : 333498825568292864,
  "created_at" : "Sun May 12 08:28:10 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sara M. Watson",
      "screen_name" : "smwat",
      "indices" : [ 3, 9 ],
      "id_str" : "20609587",
      "id" : 20609587
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "QSEU13",
      "indices" : [ 51, 58 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "333494507834318850",
  "text" : "RT @smwat: metaphysical questions: what is a step? #QSEU13",
  "retweeted_status" : {
    "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "QSEU13",
        "indices" : [ 40, 47 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "333493311421685760",
    "text" : "metaphysical questions: what is a step? #QSEU13",
    "id" : 333493311421685760,
    "created_at" : "Sun May 12 08:06:16 +0000 2013",
    "user" : {
      "name" : "Sara M. Watson",
      "screen_name" : "smwat",
      "protected" : false,
      "id_str" : "20609587",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3744587292/66e9eace9f91650e567a47d4ec1fe1dd_normal.jpeg",
      "id" : 20609587,
      "verified" : false
    }
  },
  "id" : 333494507834318850,
  "created_at" : "Sun May 12 08:11:01 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Wolf",
      "screen_name" : "agaricus",
      "indices" : [ 105, 114 ],
      "id_str" : "21678279",
      "id" : 21678279
    }, {
      "name" : "David Andre",
      "screen_name" : "dandre",
      "indices" : [ 119, 126 ],
      "id_str" : "10148302",
      "id" : 10148302
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "qseu13",
      "indices" : [ 18, 25 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 52.349825017, 4.918455261 ]
  },
  "id_str" : "333494330243293184",
  "text" : "Super interesting #qseu13 talk about how to create data that can be compared and merged with other data. @agaricus and @dandre nailed it.",
  "id" : 333494330243293184,
  "created_at" : "Sun May 12 08:10:19 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 29, 38 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/buster/status/333475264174641153/photo/1",
      "indices" : [ 47, 69 ],
      "url" : "http://t.co/q9ycKpQUK0",
      "media_url" : "http://pbs.twimg.com/media/BKC9_GbCUAAJLH7.jpg",
      "id_str" : "333475264178835456",
      "id" : 333475264178835456,
      "media_url_https" : "https://pbs.twimg.com/media/BKC9_GbCUAAJLH7.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com/q9ycKpQUK0"
    } ],
    "hashtags" : [ {
      "text" : "qseu13",
      "indices" : [ 39, 46 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "333475264174641153",
  "text" : "Our cool bow-tied organizer, @eramirez #qseu13 http://t.co/q9ycKpQUK0",
  "id" : 333475264174641153,
  "created_at" : "Sun May 12 06:54:33 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "qseu13",
      "indices" : [ 81, 88 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http://t.co/jtVuLNTSGE",
      "expanded_url" : "http://flic.kr/p/eikbPM",
      "display_url" : "flic.kr/p/eikbPM"
    } ]
  },
  "geo" : {
  },
  "id_str" : "333318165335523329",
  "text" : "8:36pm Fun discussion at dinner in Amsterdam with mostly pacific northwesterners #qseu13 http://t.co/jtVuLNTSGE",
  "id" : 333318165335523329,
  "created_at" : "Sat May 11 20:30:18 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Memoto",
      "screen_name" : "Memototeam",
      "indices" : [ 31, 42 ],
      "id_str" : "527334899",
      "id" : 527334899
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "qseu13",
      "indices" : [ 46, 53 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "333257220542304256",
  "text" : "Talking about life-logging and @memototeam at #qseu13 and think I'm in the minority for believing privacy is unimportant in the future.",
  "id" : 333257220542304256,
  "created_at" : "Sat May 11 16:28:07 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "selfselected",
      "indices" : [ 95, 108 ]
    }, {
      "text" : "qseu13",
      "indices" : [ 109, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "333223197212295169",
  "text" : "\"Who in this room would be willing to share their raw EEG (brain wave) data?\" All hands go up. #selfselected #qseu13",
  "id" : 333223197212295169,
  "created_at" : "Sat May 11 14:12:55 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kitty Ireland",
      "screen_name" : "kittyireland",
      "indices" : [ 0, 13 ],
      "id_str" : "2118301",
      "id" : 2118301
    }, {
      "name" : "david reeves",
      "screen_name" : "dreeves",
      "indices" : [ 14, 22 ],
      "id_str" : "947851",
      "id" : 947851
    }, {
      "name" : "Brian DeWeese",
      "screen_name" : "briandeweese",
      "indices" : [ 23, 36 ],
      "id_str" : "8315532",
      "id" : 8315532
    }, {
      "name" : "Saga for Android/iOS",
      "screen_name" : "GetSaga",
      "indices" : [ 37, 45 ],
      "id_str" : "550600060",
      "id" : 550600060
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "332964853381742593",
  "geo" : {
  },
  "id_str" : "333221753486704640",
  "in_reply_to_user_id" : 2118301,
  "text" : "@kittyireland @dreeves @briandeweese @GetSaga Yes please find me and say hi!",
  "id" : 333221753486704640,
  "in_reply_to_status_id" : 332964853381742593,
  "created_at" : "Sat May 11 14:07:11 +0000 2013",
  "in_reply_to_screen_name" : "kittyireland",
  "in_reply_to_user_id_str" : "2118301",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nonaps",
      "indices" : [ 87, 94 ]
    }, {
      "text" : "qseu13",
      "indices" : [ 95, 102 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "333177583292276736",
  "text" : "Hours of sleep on my plane: 0. Time in my time zone: 4am. Time here in Amsterdam: 1pm. #nonaps #qseu13",
  "id" : 333177583292276736,
  "created_at" : "Sat May 11 11:11:40 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TriemTeam",
      "screen_name" : "TriemTeam",
      "indices" : [ 0, 10 ],
      "id_str" : "24792603",
      "id" : 24792603
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "332955312015433729",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.611623587, -122.3901003501 ]
  },
  "id_str" : "332959174659035136",
  "in_reply_to_user_id" : 24792603,
  "text" : "@TriemTeam The continent of Amsterdam.",
  "id" : 332959174659035136,
  "in_reply_to_status_id" : 332955312015433729,
  "created_at" : "Fri May 10 20:43:47 +0000 2013",
  "in_reply_to_screen_name" : "TriemTeam",
  "in_reply_to_user_id_str" : "24792603",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "qseu13",
      "indices" : [ 75, 82 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.6118600462, -122.3902067823 ]
  },
  "id_str" : "332954510706237440",
  "text" : "Battery life anxiety as I board a 10.5 hour flight with a great audiobook. #qseu13",
  "id" : 332954510706237440,
  "created_at" : "Fri May 10 20:25:16 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lane Becker",
      "screen_name" : "monstro",
      "indices" : [ 96, 104 ],
      "id_str" : "4030",
      "id" : 4030
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "QSEU13",
      "indices" : [ 40, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http://t.co/4F9pla7VtC",
      "expanded_url" : "http://4sq.com/15VeW7Y",
      "display_url" : "4sq.com/15VeW7Y"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.6164240527, -122.3862791061 ]
  },
  "id_str" : "332940747626119168",
  "text" : "SFO -&gt; Amsterdam for Quantified Self #QSEU13 (@ San Francisco International Airport (SFO) w/ @monstro) http://t.co/4F9pla7VtC",
  "id" : 332940747626119168,
  "created_at" : "Fri May 10 19:30:34 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Medium Editors Picks",
      "screen_name" : "MediumEditorial",
      "indices" : [ 3, 19 ],
      "id_str" : "1069496695",
      "id" : 1069496695
    }, {
      "name" : "A Googler",
      "screen_name" : "google",
      "indices" : [ 41, 48 ],
      "id_str" : "20536157",
      "id" : 20536157
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http://t.co/eS36Ea5FXS",
      "expanded_url" : "http://world.time.com/timelapse/?hpt=hp_t5",
      "display_url" : "world.time.com/timelapse/?hpt\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "332887885462249472",
  "text" : "RT @MediumEditorial: if you haven't seen @google's time-lapse project yet, get on it: http://t.co/eS36Ea5FXS",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "A Googler",
        "screen_name" : "google",
        "indices" : [ 20, 27 ],
        "id_str" : "20536157",
        "id" : 20536157
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 65, 87 ],
        "url" : "http://t.co/eS36Ea5FXS",
        "expanded_url" : "http://world.time.com/timelapse/?hpt=hp_t5",
        "display_url" : "world.time.com/timelapse/?hpt\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "332886992725606400",
    "text" : "if you haven't seen @google's time-lapse project yet, get on it: http://t.co/eS36Ea5FXS",
    "id" : 332886992725606400,
    "created_at" : "Fri May 10 15:56:58 +0000 2013",
    "user" : {
      "name" : "Medium Editors Picks",
      "screen_name" : "MediumEditorial",
      "protected" : false,
      "id_str" : "1069496695",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3079768739/c963c078fb69eb44060bf67486267a43_normal.png",
      "id" : 1069496695,
      "verified" : false
    }
  },
  "id" : 332887885462249472,
  "created_at" : "Fri May 10 16:00:31 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Galen Ward",
      "screen_name" : "galenward",
      "indices" : [ 3, 13 ],
      "id_str" : "2854761",
      "id" : 2854761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http://t.co/vyw35HMmql",
      "expanded_url" : "http://bits.blogs.nytimes.com/2013/05/09/30-percent-of-passengers-accidentally-leave-a-device-on-during-flight/",
      "display_url" : "bits.blogs.nytimes.com/2013/05/09/30-\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "332886489786630145",
  "text" : "RT @galenward: Pretty sure we all knew this: Many Air Passengers Never Turn Off Electronics  http://t.co/vyw35HMmql",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.apple.com\" rel=\"nofollow\">Safari on iOS</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 78, 100 ],
        "url" : "http://t.co/vyw35HMmql",
        "expanded_url" : "http://bits.blogs.nytimes.com/2013/05/09/30-percent-of-passengers-accidentally-leave-a-device-on-during-flight/",
        "display_url" : "bits.blogs.nytimes.com/2013/05/09/30-\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "332880205662261248",
    "text" : "Pretty sure we all knew this: Many Air Passengers Never Turn Off Electronics  http://t.co/vyw35HMmql",
    "id" : 332880205662261248,
    "created_at" : "Fri May 10 15:30:00 +0000 2013",
    "user" : {
      "name" : "Galen Ward",
      "screen_name" : "galenward",
      "protected" : false,
      "id_str" : "2854761",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1795457065/Galen_Ward_-_its_okay_to_have_a_crush_normal.jpg",
      "id" : 2854761,
      "verified" : false
    }
  },
  "id" : 332886489786630145,
  "created_at" : "Fri May 10 15:54:58 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http://t.co/WjuhK7U8PS",
      "expanded_url" : "http://flic.kr/p/ei2tsU",
      "display_url" : "flic.kr/p/ei2tsU"
    } ]
  },
  "geo" : {
  },
  "id_str" : "332701926678487040",
  "text" : "8:36pm Talking about 8:36pm and sarcasm with my date http://t.co/WjuhK7U8PS",
  "id" : 332701926678487040,
  "created_at" : "Fri May 10 03:41:35 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Frank Jania",
      "screen_name" : "fjania",
      "indices" : [ 0, 7 ],
      "id_str" : "797383",
      "id" : 797383
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "332633617748615168",
  "geo" : {
  },
  "id_str" : "332633977313718272",
  "in_reply_to_user_id" : 797383,
  "text" : "@fjania Let me know if you run into it because I can't think of any way to summarize it in fewer words than that.",
  "id" : 332633977313718272,
  "in_reply_to_status_id" : 332633617748615168,
  "created_at" : "Thu May 09 23:11:34 +0000 2013",
  "in_reply_to_screen_name" : "fjania",
  "in_reply_to_user_id_str" : "797383",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "332633329247604736",
  "text" : "The tendency to not realize that one is not doing something that one will later regret not doing.",
  "id" : 332633329247604736,
  "created_at" : "Thu May 09 23:09:00 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "david reeves",
      "screen_name" : "dreeves",
      "indices" : [ 30, 38 ],
      "id_str" : "947851",
      "id" : 947851
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "qseu13",
      "indices" : [ 102, 109 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "332503269681295360",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596564709, -122.2754480505 ]
  },
  "id_str" : "332505387809001472",
  "in_reply_to_user_id" : 947851,
  "text" : "Me too! Who else is going? RT @dreeves: Excited for Quantified Self Europe this weekend in Amsterdam! #qseu13",
  "id" : 332505387809001472,
  "in_reply_to_status_id" : 332503269681295360,
  "created_at" : "Thu May 09 14:40:36 +0000 2013",
  "in_reply_to_screen_name" : "dreeves",
  "in_reply_to_user_id_str" : "947851",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "david reeves",
      "screen_name" : "dreeves",
      "indices" : [ 0, 8 ],
      "id_str" : "947851",
      "id" : 947851
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "332503269681295360",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596564611, -122.2755649729 ]
  },
  "id_str" : "332505167461228544",
  "in_reply_to_user_id" : 947851,
  "text" : "@dreeves See ya there!",
  "id" : 332505167461228544,
  "in_reply_to_status_id" : 332503269681295360,
  "created_at" : "Thu May 09 14:39:44 +0000 2013",
  "in_reply_to_screen_name" : "dreeves",
  "in_reply_to_user_id_str" : "947851",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Bittman",
      "screen_name" : "bittman",
      "indices" : [ 3, 11 ],
      "id_str" : "20778387",
      "id" : 20778387
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http://t.co/TNS75c8c0w",
      "expanded_url" : "http://markbittman.com/mark-bittmans-new-vegan-mantra-leaves-room-for-play/",
      "display_url" : "markbittman.com/mark-bittmans-\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "332504781102919680",
  "text" : "RT @bittman: Mark Bittman's New Vegan Mantra Leaves Room for Play - http://t.co/TNS75c8c0w",
  "retweeted_status" : {
    "source" : "<a href=\"http://markbittman.com\" rel=\"nofollow\">NextScripts-Bittman</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 55, 77 ],
        "url" : "http://t.co/TNS75c8c0w",
        "expanded_url" : "http://markbittman.com/mark-bittmans-new-vegan-mantra-leaves-room-for-play/",
        "display_url" : "markbittman.com/mark-bittmans-\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "332500208976027648",
    "text" : "Mark Bittman's New Vegan Mantra Leaves Room for Play - http://t.co/TNS75c8c0w",
    "id" : 332500208976027648,
    "created_at" : "Thu May 09 14:20:02 +0000 2013",
    "user" : {
      "name" : "Mark Bittman",
      "screen_name" : "bittman",
      "protected" : false,
      "id_str" : "20778387",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1293112347/Mark_Bittman_new_blk_75_normal.jpg",
      "id" : 20778387,
      "verified" : true
    }
  },
  "id" : 332504781102919680,
  "created_at" : "Thu May 09 14:38:12 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Carson",
      "screen_name" : "ryancarson",
      "indices" : [ 0, 11 ],
      "id_str" : "14763",
      "id" : 14763
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "332369826548957184",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596729413, -122.2754963302 ]
  },
  "id_str" : "332500060350861312",
  "in_reply_to_user_id" : 14763,
  "text" : "@ryancarson Where are you buying them from?",
  "id" : 332500060350861312,
  "in_reply_to_status_id" : 332369826548957184,
  "created_at" : "Thu May 09 14:19:26 +0000 2013",
  "in_reply_to_screen_name" : "ryancarson",
  "in_reply_to_user_id_str" : "14763",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.apple.com\" rel=\"nofollow\">iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Dots",
      "indices" : [ 42, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 49, 71 ],
      "url" : "http://t.co/s5BCZ7o3r5",
      "expanded_url" : "http://nerdyoctopus.com/a/b9e3742efdc0a47d23b6",
      "display_url" : "nerdyoctopus.com/a/b9e3742efdc0\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "332348077459509249",
  "text" : "How do you people get such high scores on #Dots? http://t.co/s5BCZ7o3r5",
  "id" : 332348077459509249,
  "created_at" : "Thu May 09 04:15:31 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "William Morgan",
      "screen_name" : "wm",
      "indices" : [ 0, 3 ],
      "id_str" : "15504330",
      "id" : 15504330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "332339427173097472",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596913396, -122.2754629703 ]
  },
  "id_str" : "332342747317030912",
  "in_reply_to_user_id" : 15504330,
  "text" : "@wm It's the \"you'll get your way but I'm only gaming the system\" look.",
  "id" : 332342747317030912,
  "in_reply_to_status_id" : 332339427173097472,
  "created_at" : "Thu May 09 03:54:20 +0000 2013",
  "in_reply_to_screen_name" : "wm",
  "in_reply_to_user_id_str" : "15504330",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http://t.co/XZSOqjldzA",
      "expanded_url" : "http://flic.kr/p/ehFxH8",
      "display_url" : "flic.kr/p/ehFxH8"
    } ]
  },
  "geo" : {
  },
  "id_str" : "332339255324078081",
  "text" : "8:36pm Giving this guy another chance for story time if he's nice http://t.co/XZSOqjldzA",
  "id" : 332339255324078081,
  "created_at" : "Thu May 09 03:40:27 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter   for    iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "john roderick",
      "screen_name" : "johnroderick",
      "indices" : [ 3, 16 ],
      "id_str" : "17431654",
      "id" : 17431654
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "332311882226601984",
  "text" : "RT @johnroderick: Twitter bots are out there talking, retweeting each other in ways we\u2019ll never fully understand. Here\u2019s where Skynet becom\u2026",
  "retweeted_status" : {
    "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "332292712353107968",
    "text" : "Twitter bots are out there talking, retweeting each other in ways we\u2019ll never fully understand. Here\u2019s where Skynet becomes self-aware.",
    "id" : 332292712353107968,
    "created_at" : "Thu May 09 00:35:30 +0000 2013",
    "user" : {
      "name" : "john roderick",
      "screen_name" : "johnroderick",
      "protected" : false,
      "id_str" : "17431654",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1389703525/Bambi_normal.jpg",
      "id" : 17431654,
      "verified" : true
    }
  },
  "id" : 332311882226601984,
  "created_at" : "Thu May 09 01:51:41 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter   for    iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jane McGonigal",
      "screen_name" : "avantgame",
      "indices" : [ 12, 22 ],
      "id_str" : "681813",
      "id" : 681813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "332172161605312513",
  "geo" : {
  },
  "id_str" : "332238949596672000",
  "in_reply_to_user_id" : 681813,
  "text" : "Awesome! RT @avantgame: Made-up rules for my Spring Discardia game: 1pt for everything I donate that's easy to give up, 3pt for tough calls.",
  "id" : 332238949596672000,
  "in_reply_to_status_id" : 332172161605312513,
  "created_at" : "Wed May 08 21:01:52 +0000 2013",
  "in_reply_to_screen_name" : "avantgame",
  "in_reply_to_user_id_str" : "681813",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Greenberg",
      "screen_name" : "greenberg",
      "indices" : [ 61, 71 ],
      "id_str" : "7378572",
      "id" : 7378572
    }, {
      "name" : "Double Robotics",
      "screen_name" : "doublerobotics",
      "indices" : [ 72, 87 ],
      "id_str" : "625391951",
      "id" : 625391951
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 56 ],
      "url" : "http://t.co/s9SxqxBUWR",
      "expanded_url" : "http://flic.kr/p/ehAZk4",
      "display_url" : "flic.kr/p/ehAZk4"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.776755, -122.416748 ]
  },
  "id_str" : "332228330126462981",
  "text" : "I see wheeled robotic iPad people http://t.co/s9SxqxBUWR /cc @greenberg @doublerobotics",
  "id" : 332228330126462981,
  "created_at" : "Wed May 08 20:19:41 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Cibelli",
      "screen_name" : "cibelli",
      "indices" : [ 0, 8 ],
      "id_str" : "25954522",
      "id" : 25954522
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "332208975221256192",
  "geo" : {
  },
  "id_str" : "332209156687790082",
  "in_reply_to_user_id" : 25954522,
  "text" : "@cibelli I have! Best book I've read all year probably.",
  "id" : 332209156687790082,
  "in_reply_to_status_id" : 332208975221256192,
  "created_at" : "Wed May 08 19:03:29 +0000 2013",
  "in_reply_to_screen_name" : "cibelli",
  "in_reply_to_user_id_str" : "25954522",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Judd Welch",
      "screen_name" : "sjw",
      "indices" : [ 0, 4 ],
      "id_str" : "278220302",
      "id" : 278220302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "332183003189104641",
  "geo" : {
  },
  "id_str" : "332183400460996608",
  "in_reply_to_user_id" : 278220302,
  "text" : "@sjw Also, I have a 3-year old son\u2026 perfect the age to get a monitor installed?",
  "id" : 332183400460996608,
  "in_reply_to_status_id" : 332183003189104641,
  "created_at" : "Wed May 08 17:21:08 +0000 2013",
  "in_reply_to_screen_name" : "sjw",
  "in_reply_to_user_id_str" : "278220302",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GB Bowers",
      "screen_name" : "gb",
      "indices" : [ 0, 3 ],
      "id_str" : "37873",
      "id" : 37873
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "332181996434497537",
  "geo" : {
  },
  "id_str" : "332182187355013121",
  "in_reply_to_user_id" : 37873,
  "text" : "@gb The opening had mulitple, but it looks like it settled down to a single one after the first chapter... which seems more reasonable.",
  "id" : 332182187355013121,
  "in_reply_to_status_id" : 332181996434497537,
  "created_at" : "Wed May 08 17:16:19 +0000 2013",
  "in_reply_to_screen_name" : "gb",
  "in_reply_to_user_id_str" : "37873",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Judd Welch",
      "screen_name" : "sjw",
      "indices" : [ 0, 4 ],
      "id_str" : "278220302",
      "id" : 278220302
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "332181735381012481",
  "geo" : {
  },
  "id_str" : "332181986594652162",
  "in_reply_to_user_id" : 278220302,
  "text" : "@sjw Agreed! I read the first 3 when I was in high school and *loved* them. Curious what I'll think 20 years later\u2026",
  "id" : 332181986594652162,
  "in_reply_to_status_id" : 332181735381012481,
  "created_at" : "Wed May 08 17:15:31 +0000 2013",
  "in_reply_to_screen_name" : "sjw",
  "in_reply_to_user_id_str" : "278220302",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jess",
      "screen_name" : "mibi",
      "indices" : [ 0, 5 ],
      "id_str" : "14965636",
      "id" : 14965636
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "332180289998684161",
  "geo" : {
  },
  "id_str" : "332181745686413312",
  "in_reply_to_user_id" : 14965636,
  "text" : "@mibi On my commute (I have about 40 minutes of walking + BART each way).",
  "id" : 332181745686413312,
  "in_reply_to_status_id" : 332180289998684161,
  "created_at" : "Wed May 08 17:14:34 +0000 2013",
  "in_reply_to_screen_name" : "mibi",
  "in_reply_to_user_id_str" : "14965636",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Bonner",
      "screen_name" : "seanbonner",
      "indices" : [ 0, 11 ],
      "id_str" : "765",
      "id" : 765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "332179895738302464",
  "geo" : {
  },
  "id_str" : "332181614278881281",
  "in_reply_to_user_id" : 765,
  "text" : "@seanbonner I'm hoping I get used to it but it is sort of awkward.",
  "id" : 332181614278881281,
  "in_reply_to_status_id" : 332179895738302464,
  "created_at" : "Wed May 08 17:14:03 +0000 2013",
  "in_reply_to_screen_name" : "seanbonner",
  "in_reply_to_user_id_str" : "765",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "332179655316606976",
  "text" : "Started the Ender's Game audiobook, my first fiction audio. Surprised to hear voice acting happening.",
  "id" : 332179655316606976,
  "created_at" : "Wed May 08 17:06:16 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Ducker",
      "screen_name" : "miradu",
      "indices" : [ 0, 7 ],
      "id_str" : "1530531",
      "id" : 1530531
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "332168965302415361",
  "geo" : {
  },
  "id_str" : "332179147457691649",
  "in_reply_to_user_id" : 1530531,
  "text" : "@miradu Yeah, there are a couple UI annoyances like that. But more than made up for by iPhone/web/Mac syncing and general simplicity.",
  "id" : 332179147457691649,
  "in_reply_to_status_id" : 332168965302415361,
  "created_at" : "Wed May 08 17:04:15 +0000 2013",
  "in_reply_to_screen_name" : "miradu",
  "in_reply_to_user_id_str" : "1530531",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Ducker",
      "screen_name" : "miradu",
      "indices" : [ 0, 7 ],
      "id_str" : "1530531",
      "id" : 1530531
    }, {
      "name" : "Day One",
      "screen_name" : "dayoneapp",
      "indices" : [ 15, 25 ],
      "id_str" : "246011382",
      "id" : 246011382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "332165219608559616",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8515656486, -122.2700185478 ]
  },
  "id_str" : "332166715377070080",
  "in_reply_to_user_id" : 1530531,
  "text" : "@miradu I like @dayoneapp for that.",
  "id" : 332166715377070080,
  "in_reply_to_status_id" : 332165219608559616,
  "created_at" : "Wed May 08 16:14:50 +0000 2013",
  "in_reply_to_screen_name" : "miradu",
  "in_reply_to_user_id_str" : "1530531",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter   for    iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "332021877797187584",
  "text" : "Okay now I gotta read Ender's Game again.",
  "id" : 332021877797187584,
  "created_at" : "Wed May 08 06:39:18 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "chris jones",
      "screen_name" : "cjlikearockstar",
      "indices" : [ 0, 16 ],
      "id_str" : "34383091",
      "id" : 34383091
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "332006349825245184",
  "geo" : {
  },
  "id_str" : "332019313714270208",
  "in_reply_to_user_id" : 34383091,
  "text" : "@cjlikearockstar good call.",
  "id" : 332019313714270208,
  "in_reply_to_status_id" : 332006349825245184,
  "created_at" : "Wed May 08 06:29:07 +0000 2013",
  "in_reply_to_screen_name" : "cjlikearockstar",
  "in_reply_to_user_id_str" : "34383091",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ArielMeadowStallings",
      "screen_name" : "OffbeatAriel",
      "indices" : [ 0, 13 ],
      "id_str" : "14095370",
      "id" : 14095370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "331997482387140608",
  "geo" : {
  },
  "id_str" : "331997704819470336",
  "in_reply_to_user_id" : 14095370,
  "text" : "@OffbeatAriel Can you just do the next 10 slides for me? This beer is too tasty. Thanks.",
  "id" : 331997704819470336,
  "in_reply_to_status_id" : 331997482387140608,
  "created_at" : "Wed May 08 05:03:15 +0000 2013",
  "in_reply_to_screen_name" : "OffbeatAriel",
  "in_reply_to_user_id_str" : "14095370",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ArielMeadowStallings",
      "screen_name" : "OffbeatAriel",
      "indices" : [ 0, 13 ],
      "id_str" : "14095370",
      "id" : 14095370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "331997062730227712",
  "geo" : {
  },
  "id_str" : "331997198856384513",
  "in_reply_to_user_id" : 14095370,
  "text" : "@OffbeatAriel Ooh, I like that actually.",
  "id" : 331997198856384513,
  "in_reply_to_status_id" : 331997062730227712,
  "created_at" : "Wed May 08 05:01:15 +0000 2013",
  "in_reply_to_screen_name" : "OffbeatAriel",
  "in_reply_to_user_id_str" : "14095370",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "331996887995535361",
  "text" : "What should my next slide say?",
  "id" : 331996887995535361,
  "created_at" : "Wed May 08 05:00:00 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mario Esposito",
      "screen_name" : "windrago",
      "indices" : [ 0, 9 ],
      "id_str" : "14420428",
      "id" : 14420428
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "331979732562358274",
  "geo" : {
  },
  "id_str" : "331994653631066113",
  "in_reply_to_user_id" : 14420428,
  "text" : "@windrago In Amsterdam.",
  "id" : 331994653631066113,
  "in_reply_to_status_id" : 331979732562358274,
  "created_at" : "Wed May 08 04:51:08 +0000 2013",
  "in_reply_to_screen_name" : "windrago",
  "in_reply_to_user_id_str" : "14420428",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "quantifiedself",
      "indices" : [ 43, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http://t.co/xGouFL0B52",
      "expanded_url" : "http://flic.kr/p/ehwUX3",
      "display_url" : "flic.kr/p/ehwUX3"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859666, -122.2755 ]
  },
  "id_str" : "331977991368347648",
  "text" : "8:36pm I'm gonna drink this and work on my #quantifiedself conference talk for this weekend http://t.co/xGouFL0B52",
  "id" : 331977991368347648,
  "created_at" : "Wed May 08 03:44:55 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ingopixel",
      "screen_name" : "ingopixel",
      "indices" : [ 0, 10 ],
      "id_str" : "7943892",
      "id" : 7943892
    }, {
      "name" : "Damien Echols",
      "screen_name" : "damienechols",
      "indices" : [ 53, 66 ],
      "id_str" : "358311362",
      "id" : 358311362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "331962789931409408",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596462869, -122.2754013633 ]
  },
  "id_str" : "331973335057575936",
  "in_reply_to_user_id" : 7943892,
  "text" : "@ingopixel I haven't! I'll check it out, thanks! /cc @damienechols",
  "id" : 331973335057575936,
  "in_reply_to_status_id" : 331962789931409408,
  "created_at" : "Wed May 08 03:26:25 +0000 2013",
  "in_reply_to_screen_name" : "ingopixel",
  "in_reply_to_user_id_str" : "7943892",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596947343, -122.2755928059 ]
  },
  "id_str" : "331954845386936321",
  "text" : "Just finished Flourish, which was about 75% interesting and 25% sorta too much. I need a new book!",
  "id" : 331954845386936321,
  "created_at" : "Wed May 08 02:12:57 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http://t.co/OjX5LA8VoM",
      "expanded_url" : "http://flic.kr/p/ehvMCA",
      "display_url" : "flic.kr/p/ehvMCA"
    } ]
  },
  "geo" : {
  },
  "id_str" : "331950565514948610",
  "text" : "How Niko greets me when I get home: \"I unwrapped the butter!\" http://t.co/OjX5LA8VoM",
  "id" : 331950565514948610,
  "created_at" : "Wed May 08 01:55:56 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 0, 9 ],
      "id_str" : "761628",
      "id" : 761628
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "331914989952724993",
  "geo" : {
  },
  "id_str" : "331929140389347328",
  "in_reply_to_user_id" : 761628,
  "text" : "@RickWebb I think it's time we turned push notifications on. We're there, right?",
  "id" : 331929140389347328,
  "in_reply_to_status_id" : 331914989952724993,
  "created_at" : "Wed May 08 00:30:48 +0000 2013",
  "in_reply_to_screen_name" : "RickWebb",
  "in_reply_to_user_id_str" : "761628",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 0, 9 ],
      "id_str" : "761628",
      "id" : 761628
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "331906541898829824",
  "geo" : {
  },
  "id_str" : "331913569803317248",
  "in_reply_to_user_id" : 761628,
  "text" : "@RickWebb You should follow me on the Twitter. I'll share all kinds of interesting and relevant tidbits that cross my path. PS. HAPPY BDAY!",
  "id" : 331913569803317248,
  "in_reply_to_status_id" : 331906541898829824,
  "created_at" : "Tue May 07 23:28:56 +0000 2013",
  "in_reply_to_screen_name" : "RickWebb",
  "in_reply_to_user_id_str" : "761628",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Cheng",
      "screen_name" : "k",
      "indices" : [ 0, 2 ],
      "id_str" : "11222",
      "id" : 11222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "331829875038109696",
  "geo" : {
  },
  "id_str" : "331832729912082432",
  "in_reply_to_user_id" : 11222,
  "text" : "@k If you like it that much, I'm grabbing it too. :)",
  "id" : 331832729912082432,
  "in_reply_to_status_id" : 331829875038109696,
  "created_at" : "Tue May 07 18:07:42 +0000 2013",
  "in_reply_to_screen_name" : "k",
  "in_reply_to_user_id_str" : "11222",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Fuchs",
      "screen_name" : "jfuchs",
      "indices" : [ 0, 7 ],
      "id_str" : "1026",
      "id" : 1026
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "331668534709059585",
  "geo" : {
  },
  "id_str" : "331669237766709248",
  "in_reply_to_user_id" : 1026,
  "text" : "@jfuchs That's my initial thought, but I haven't thought about it much. I do really love the \"read\" metric... how is that determined?",
  "id" : 331669237766709248,
  "in_reply_to_status_id" : 331668534709059585,
  "created_at" : "Tue May 07 07:18:03 +0000 2013",
  "in_reply_to_screen_name" : "jfuchs",
  "in_reply_to_user_id_str" : "1026",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Fuchs",
      "screen_name" : "jfuchs",
      "indices" : [ 0, 7 ],
      "id_str" : "1026",
      "id" : 1026
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "331665340595589120",
  "geo" : {
  },
  "id_str" : "331666391465881601",
  "in_reply_to_user_id" : 1026,
  "text" : "@jfuchs Okay, here's one: I wish counts of public \"notes\" also showed up in the graphs.",
  "id" : 331666391465881601,
  "in_reply_to_status_id" : 331665340595589120,
  "created_at" : "Tue May 07 07:06:44 +0000 2013",
  "in_reply_to_screen_name" : "jfuchs",
  "in_reply_to_user_id_str" : "1026",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kc",
      "screen_name" : "kris",
      "indices" : [ 0, 5 ],
      "id_str" : "115734106",
      "id" : 115734106
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "331660532916568064",
  "geo" : {
  },
  "id_str" : "331662030228566017",
  "in_reply_to_user_id" : 115734106,
  "text" : "@kris I wish I knew how to quit me.",
  "id" : 331662030228566017,
  "in_reply_to_status_id" : 331660532916568064,
  "created_at" : "Tue May 07 06:49:24 +0000 2013",
  "in_reply_to_screen_name" : "kris",
  "in_reply_to_user_id_str" : "115734106",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Medium",
      "screen_name" : "Medium",
      "indices" : [ 38, 45 ],
      "id_str" : "571202103",
      "id" : 571202103
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/buster/status/331656511615033344/photo/1",
      "indices" : [ 76, 98 ],
      "url" : "http://t.co/hlBcRyWWci",
      "media_url" : "http://pbs.twimg.com/media/BJpH1xKCYAAyaGV.png",
      "id_str" : "331656511619227648",
      "id" : 331656511619227648,
      "media_url_https" : "https://pbs.twimg.com/media/BJpH1xKCYAAyaGV.png",
      "sizes" : [ {
        "h" : 718,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 421,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1602,
        "resize" : "fit",
        "w" : 2284
      }, {
        "h" : 238,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com/hlBcRyWWci"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "331656511615033344",
  "text" : "Sort of addicted to the stats page on @medium. Feels like early 2000 again. http://t.co/hlBcRyWWci",
  "id" : 331656511615033344,
  "created_at" : "Tue May 07 06:27:29 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http://t.co/r2DC8LlrDa",
      "expanded_url" : "http://flic.kr/p/ehhBJs",
      "display_url" : "flic.kr/p/ehhBJs"
    } ]
  },
  "geo" : {
  },
  "id_str" : "331649476425052161",
  "text" : "Just had the coolest conversation with this guy.  http://t.co/r2DC8LlrDa",
  "id" : 331649476425052161,
  "created_at" : "Tue May 07 05:59:31 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http://t.co/SijHJjn2zb",
      "expanded_url" : "http://flic.kr/p/ehgqAE",
      "display_url" : "flic.kr/p/ehgqAE"
    } ]
  },
  "geo" : {
  },
  "id_str" : "331616059671056384",
  "text" : "8:36pm Infinite loop why game turned into an awesome interview about Niko's understanding of the world.  http://t.co/SijHJjn2zb",
  "id" : 331616059671056384,
  "created_at" : "Tue May 07 03:46:44 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sara Mauskopf",
      "screen_name" : "sm",
      "indices" : [ 0, 3 ],
      "id_str" : "22273667",
      "id" : 22273667
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "331601076107218944",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597252025, -122.2754526605 ]
  },
  "id_str" : "331601808713732097",
  "in_reply_to_user_id" : 22273667,
  "text" : "@sm Him: \"Why do you want to give me up for adoption?\"",
  "id" : 331601808713732097,
  "in_reply_to_status_id" : 331601076107218944,
  "created_at" : "Tue May 07 02:50:06 +0000 2013",
  "in_reply_to_screen_name" : "sm",
  "in_reply_to_user_id_str" : "22273667",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "help",
      "indices" : [ 134, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597925092, -122.2755185423 ]
  },
  "id_str" : "331600712062611456",
  "text" : "Niko: \"We should eat outside!\" Me: \"Okay.\" Niko: \"Why should we eat outside?\" Me: \"Because you wanted to.\" Niko: \"Why did I want to?\" #help",
  "id" : 331600712062611456,
  "created_at" : "Tue May 07 02:45:45 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8586485051, -122.2742621788 ]
  },
  "id_str" : "331590801496875010",
  "text" : "\"We have an under-developed way of reporting and telling the positive stories of life.\" - M. Seligman at the end of Flourish.",
  "id" : 331590801496875010,
  "created_at" : "Tue May 07 02:06:22 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8220566661, -122.268807805 ]
  },
  "id_str" : "331587146404225024",
  "text" : "\"We are bad weather animals for whom the first thing we want to do is find what's wrong in our lives, and to worry it.\" - M. Seligman",
  "id" : 331587146404225024,
  "created_at" : "Tue May 07 01:51:50 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ArielMeadowStallings",
      "screen_name" : "OffbeatAriel",
      "indices" : [ 96, 109 ],
      "id_str" : "14095370",
      "id" : 14095370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http://t.co/YMQShsXSBy",
      "expanded_url" : "http://bit.ly/18P4nQa",
      "display_url" : "bit.ly/18P4nQa"
    } ]
  },
  "geo" : {
  },
  "id_str" : "331533902990671872",
  "text" : "There are more people living inside this circle than outside of it: http://t.co/YMQShsXSBy /via @OffbeatAriel",
  "id" : 331533902990671872,
  "created_at" : "Mon May 06 22:20:16 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "girl jo",
      "screen_name" : "octavekitten",
      "indices" : [ 0, 13 ],
      "id_str" : "16366882",
      "id" : 16366882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "331516015307550721",
  "geo" : {
  },
  "id_str" : "331516305654022144",
  "in_reply_to_user_id" : 16366882,
  "text" : "@octavekitten Yeah, it's a master class in how to be hacked.",
  "id" : 331516305654022144,
  "in_reply_to_status_id" : 331516015307550721,
  "created_at" : "Mon May 06 21:10:21 +0000 2013",
  "in_reply_to_screen_name" : "octavekitten",
  "in_reply_to_user_id_str" : "16366882",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "girl jo",
      "screen_name" : "octavekitten",
      "indices" : [ 0, 13 ],
      "id_str" : "16366882",
      "id" : 16366882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 41 ],
      "url" : "http://t.co/mBzHJRanUS",
      "expanded_url" : "http://huff.to/18OKY1C",
      "display_url" : "huff.to/18OKY1C"
    } ]
  },
  "in_reply_to_status_id_str" : "331513878959759360",
  "geo" : {
  },
  "id_str" : "331515072033742848",
  "in_reply_to_user_id" : 16366882,
  "text" : "@octavekitten j/k: http://t.co/mBzHJRanUS",
  "id" : 331515072033742848,
  "in_reply_to_status_id" : 331513878959759360,
  "created_at" : "Mon May 06 21:05:27 +0000 2013",
  "in_reply_to_screen_name" : "octavekitten",
  "in_reply_to_user_id_str" : "16366882",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "331511332169973760",
  "text" : "Syrian Electronic Army Was Heere",
  "id" : 331511332169973760,
  "created_at" : "Mon May 06 20:50:35 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https://t.co/6hBNhkGqQ7",
      "expanded_url" : "https://medium.com/self-knowledge-through-numbers/806222d3d4e",
      "display_url" : "medium.com/self-knowledge\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "331447238020694016",
  "text" : "\"If I Lived 100 Times\" (my experiments with forecasting your year of death using recent life estimation data): https://t.co/6hBNhkGqQ7",
  "id" : 331447238020694016,
  "created_at" : "Mon May 06 16:35:54 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter   for    iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tracey Ryan Briones",
      "screen_name" : "trbriones",
      "indices" : [ 0, 10 ],
      "id_str" : "17550502",
      "id" : 17550502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "331236813035433985",
  "geo" : {
  },
  "id_str" : "331278879606071296",
  "in_reply_to_user_id" : 17550502,
  "text" : "@trbriones Both I guess! And also, fancy wine, delicious exotic foods, etc.",
  "id" : 331278879606071296,
  "in_reply_to_status_id" : 331236813035433985,
  "created_at" : "Mon May 06 05:26:54 +0000 2013",
  "in_reply_to_screen_name" : "trbriones",
  "in_reply_to_user_id_str" : "17550502",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http://t.co/HDm3wD1srO",
      "expanded_url" : "http://flic.kr/p/egRoKP",
      "display_url" : "flic.kr/p/egRoKP"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859666, -122.275334 ]
  },
  "id_str" : "331251895341563904",
  "text" : "8:36pm Eating salads, portrait by Niko http://t.co/HDm3wD1srO",
  "id" : 331251895341563904,
  "created_at" : "Mon May 06 03:39:40 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://vine.co\" rel=\"nofollow\">Vine - Make a Scene</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 32 ],
      "url" : "https://t.co/POBe4iuD5A",
      "expanded_url" : "https://vine.co/v/b27KhmxPMjZ",
      "display_url" : "vine.co/v/b27KhmxPMjZ"
    } ]
  },
  "geo" : {
  },
  "id_str" : "331238861470564354",
  "text" : "Bubbles. https://t.co/POBe4iuD5A",
  "id" : 331238861470564354,
  "created_at" : "Mon May 06 02:47:53 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter   for    iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Danielle Morrill",
      "screen_name" : "DanielleMorrill",
      "indices" : [ 0, 16 ],
      "id_str" : "7017692",
      "id" : 7017692
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "331216131891286017",
  "geo" : {
  },
  "id_str" : "331217865149669377",
  "in_reply_to_user_id" : 7017692,
  "text" : "@DanielleMorrill Just a new app I'm playing around with.",
  "id" : 331217865149669377,
  "in_reply_to_status_id" : 331216131891286017,
  "created_at" : "Mon May 06 01:24:27 +0000 2013",
  "in_reply_to_screen_name" : "DanielleMorrill",
  "in_reply_to_user_id_str" : "7017692",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://days.am\" rel=\"nofollow\">Days</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 45 ],
      "url" : "https://t.co/eWttarPMP3",
      "expanded_url" : "https://www.days.am/stories/Q9eSy8Odah0",
      "display_url" : "days.am/stories/Q9eSy8\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "331215870242201601",
  "text" : "Saturday, May 4, 2013 https://t.co/eWttarPMP3",
  "id" : 331215870242201601,
  "created_at" : "Mon May 06 01:16:31 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "331193659313766402",
  "text" : "If your favorite fancy exclusive thing became free and available to everyone all of a sudden, would you still like it as much?",
  "id" : 331193659313766402,
  "created_at" : "Sun May 05 23:48:16 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeffery Bennett",
      "screen_name" : "meandmybadself",
      "indices" : [ 0, 15 ],
      "id_str" : "1797691",
      "id" : 1797691
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http://t.co/yRbZOV0lq2",
      "expanded_url" : "http://bit.ly/16Jqx9L",
      "display_url" : "bit.ly/16Jqx9L"
    } ]
  },
  "geo" : {
  },
  "id_str" : "331166581721812993",
  "in_reply_to_user_id" : 1797691,
  "text" : "@meandmybadself Can't DM you. :) Here's the link you were looking for though: http://t.co/yRbZOV0lq2 Copy and edit with your own birthday.",
  "id" : 331166581721812993,
  "created_at" : "Sun May 05 22:00:40 +0000 2013",
  "in_reply_to_screen_name" : "meandmybadself",
  "in_reply_to_user_id_str" : "1797691",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http://t.co/RBmBsODPXZ",
      "expanded_url" : "http://4sq.com/10cBd8v",
      "display_url" : "4sq.com/10cBd8v"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8614000041, -122.2982250687 ]
  },
  "id_str" : "331157161608609792",
  "text" : "This place is kinda amazing. (@ Vik\u2019s Chaat Corner w/ 2 others) http://t.co/RBmBsODPXZ",
  "id" : 331157161608609792,
  "created_at" : "Sun May 05 21:23:14 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter   for    iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erik Bruchez",
      "screen_name" : "ebruchez",
      "indices" : [ 0, 9 ],
      "id_str" : "6087842",
      "id" : 6087842
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "331143865962754048",
  "geo" : {
  },
  "id_str" : "331145807296348160",
  "in_reply_to_user_id" : 6087842,
  "text" : "@ebruchez True, it's a baseline for predictions of progress to be made from.",
  "id" : 331145807296348160,
  "in_reply_to_status_id" : 331143865962754048,
  "created_at" : "Sun May 05 20:38:07 +0000 2013",
  "in_reply_to_screen_name" : "ebruchez",
  "in_reply_to_user_id_str" : "6087842",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter   for    iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Hogan",
      "screen_name" : "AlanHogan",
      "indices" : [ 0, 10 ],
      "id_str" : "13801912",
      "id" : 13801912
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "331084396272701440",
  "geo" : {
  },
  "id_str" : "331085816724066305",
  "in_reply_to_user_id" : 13801912,
  "text" : "@AlanHogan I'll post it later today.",
  "id" : 331085816724066305,
  "in_reply_to_status_id" : 331084396272701440,
  "created_at" : "Sun May 05 16:39:44 +0000 2013",
  "in_reply_to_screen_name" : "AlanHogan",
  "in_reply_to_user_id_str" : "13801912",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter   for    iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Goldman",
      "screen_name" : "goldman",
      "indices" : [ 0, 8 ],
      "id_str" : "291",
      "id" : 291
    }, {
      "name" : "Tony Stubblebine",
      "screen_name" : "tonystubblebine",
      "indices" : [ 9, 25 ],
      "id_str" : "17",
      "id" : 17
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "331081604422311936",
  "geo" : {
  },
  "id_str" : "331083267539337216",
  "in_reply_to_user_id" : 291,
  "text" : "@goldman @tonystubblebine Happy to help 36 year olds 'round the web.",
  "id" : 331083267539337216,
  "in_reply_to_status_id" : 331081604422311936,
  "created_at" : "Sun May 05 16:29:36 +0000 2013",
  "in_reply_to_screen_name" : "goldman",
  "in_reply_to_user_id_str" : "291",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http://t.co/HKQhNVa5WH",
      "expanded_url" : "http://bit.ly/103EpYf",
      "display_url" : "bit.ly/103EpYf"
    } ]
  },
  "geo" : {
  },
  "id_str" : "330943630154006528",
  "text" : "If I lived 100 times, here's the distribution of years I'd die in: http://t.co/HKQhNVa5WH (uses the CDC's latest life expectancy report)",
  "id" : 330943630154006528,
  "created_at" : "Sun May 05 07:14:44 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "330925416711864321",
  "text" : "What if instead of celebrating birthdays by how many years we've been alive we celebrated years we expect to have left? I've got 45.",
  "id" : 330925416711864321,
  "created_at" : "Sun May 05 06:02:22 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "maggim",
      "screen_name" : "maggim",
      "indices" : [ 0, 7 ],
      "id_str" : "14290242",
      "id" : 14290242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "330922497555959808",
  "geo" : {
  },
  "id_str" : "330922848510177280",
  "in_reply_to_user_id" : 14290242,
  "text" : "@maggim For some, but I think lots of people (including myself, often) feel compelled to appear witty/professional/smart on Twitter.",
  "id" : 330922848510177280,
  "in_reply_to_status_id" : 330922497555959808,
  "created_at" : "Sun May 05 05:52:09 +0000 2013",
  "in_reply_to_screen_name" : "maggim",
  "in_reply_to_user_id_str" : "14290242",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "330920869834682368",
  "text" : "Nobody will ever really know you unless you let your uncurated, unfiltered, BORING self out once in a while, if not often.",
  "id" : 330920869834682368,
  "created_at" : "Sun May 05 05:44:18 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http://t.co/Exic9q3oJ0",
      "expanded_url" : "http://flic.kr/p/egwMyH",
      "display_url" : "flic.kr/p/egwMyH"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859666, -122.2755 ]
  },
  "id_str" : "330889518100144128",
  "text" : "8:36pm Niko, upon seeing Kermit moving around, \"Oh my gosh, he walks!\" (No idea.) http://t.co/Exic9q3oJ0",
  "id" : 330889518100144128,
  "created_at" : "Sun May 05 03:39:43 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter   for    iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carinna Tarvin",
      "screen_name" : "carinnatarvin",
      "indices" : [ 0, 14 ],
      "id_str" : "20833838",
      "id" : 20833838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "330833658971815937",
  "geo" : {
  },
  "id_str" : "330851513209602049",
  "in_reply_to_user_id" : 20833838,
  "text" : "@carinnatarvin Woah! Good luck!",
  "id" : 330851513209602049,
  "in_reply_to_status_id" : 330833658971815937,
  "created_at" : "Sun May 05 01:08:42 +0000 2013",
  "in_reply_to_screen_name" : "carinnatarvin",
  "in_reply_to_user_id_str" : "20833838",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter   for    iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "harryh",
      "screen_name" : "harryh",
      "indices" : [ 0, 7 ],
      "id_str" : "4558",
      "id" : 4558
    }, {
      "name" : "Baz Scott",
      "screen_name" : "bazscott",
      "indices" : [ 8, 17 ],
      "id_str" : "2223291",
      "id" : 2223291
    }, {
      "name" : "David Marwick",
      "screen_name" : "dmarwick",
      "indices" : [ 18, 27 ],
      "id_str" : "63315859",
      "id" : 63315859
    }, {
      "name" : "Todd Berman",
      "screen_name" : "tberman",
      "indices" : [ 28, 36 ],
      "id_str" : "15275073",
      "id" : 15275073
    }, {
      "name" : "I Are Andrew",
      "screen_name" : "andrewwatson",
      "indices" : [ 37, 50 ],
      "id_str" : "6247112",
      "id" : 6247112
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "330774874895286272",
  "geo" : {
  },
  "id_str" : "330781168716873728",
  "in_reply_to_user_id" : 4558,
  "text" : "@harryh @bazscott @dmarwick @tberman @andrewwatson If you store your Dropbox password in 1Password store it on multiple computers/devices.",
  "id" : 330781168716873728,
  "in_reply_to_status_id" : 330774874895286272,
  "created_at" : "Sat May 04 20:29:10 +0000 2013",
  "in_reply_to_screen_name" : "harryh",
  "in_reply_to_user_id_str" : "4558",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 39 ],
      "url" : "http://t.co/HsyB052B29",
      "expanded_url" : "http://flic.kr/p/egwX7Y",
      "display_url" : "flic.kr/p/egwX7Y"
    } ]
  },
  "geo" : {
  },
  "id_str" : "330764488313827328",
  "text" : "Post-brunch coma http://t.co/HsyB052B29",
  "id" : 330764488313827328,
  "created_at" : "Sat May 04 19:22:53 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://vine.co\" rel=\"nofollow\">Vine - Make a Scene</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 38 ],
      "url" : "https://t.co/aVnWEXSiYp",
      "expanded_url" : "https://vine.co/v/bQx9FdHd2vw",
      "display_url" : "vine.co/v/bQx9FdHd2vw"
    } ]
  },
  "geo" : {
  },
  "id_str" : "330731196285849601",
  "text" : "Race car wheel https://t.co/aVnWEXSiYp",
  "id" : 330731196285849601,
  "created_at" : "Sat May 04 17:10:36 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter   for    iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Davidson",
      "screen_name" : "mikeindustries",
      "indices" : [ 3, 18 ],
      "id_str" : "74523",
      "id" : 74523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http://t.co/yrDcMMpqr4",
      "expanded_url" : "http://arstechnica.com/gadgets/2013/05/the-first-entirely-3d-printed-handgun-is-here/",
      "display_url" : "arstechnica.com/gadgets/2013/0\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "330725670793641987",
  "text" : "RT @mikeindustries: The first entirely 3D-printed handgun is here. Welcome to our future :( http://t.co/yrDcMMpqr4",
  "retweeted_status" : {
    "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 72, 94 ],
        "url" : "http://t.co/yrDcMMpqr4",
        "expanded_url" : "http://arstechnica.com/gadgets/2013/05/the-first-entirely-3d-printed-handgun-is-here/",
        "display_url" : "arstechnica.com/gadgets/2013/0\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "330719319472345089",
    "text" : "The first entirely 3D-printed handgun is here. Welcome to our future :( http://t.co/yrDcMMpqr4",
    "id" : 330719319472345089,
    "created_at" : "Sat May 04 16:23:24 +0000 2013",
    "user" : {
      "name" : "Mike Davidson",
      "screen_name" : "mikeindustries",
      "protected" : false,
      "id_str" : "74523",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000140947856/95a29c5136780e58afd8f8b1887997f9_normal.jpeg",
      "id" : 74523,
      "verified" : false
    }
  },
  "id" : 330725670793641987,
  "created_at" : "Sat May 04 16:48:39 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter   for    iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Davidson",
      "screen_name" : "mikeindustries",
      "indices" : [ 0, 15 ],
      "id_str" : "74523",
      "id" : 74523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "330719319472345089",
  "geo" : {
  },
  "id_str" : "330725643488747520",
  "in_reply_to_user_id" : 74523,
  "text" : "@mikeindustries Yeah, seems like one of those tech pandora's boxes. Starting to believe we'll all have guns in the future.",
  "id" : 330725643488747520,
  "in_reply_to_status_id" : 330719319472345089,
  "created_at" : "Sat May 04 16:48:32 +0000 2013",
  "in_reply_to_screen_name" : "mikeindustries",
  "in_reply_to_user_id_str" : "74523",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter   for    iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Hoover",
      "screen_name" : "rrhoover",
      "indices" : [ 0, 9 ],
      "id_str" : "14417215",
      "id" : 14417215
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "330723846481141760",
  "geo" : {
  },
  "id_str" : "330724178053455872",
  "in_reply_to_user_id" : 14417215,
  "text" : "@rrhoover I like it! The day delay on posting is both cool and maybe too much of an obstacle, though.",
  "id" : 330724178053455872,
  "in_reply_to_status_id" : 330723846481141760,
  "created_at" : "Sat May 04 16:42:43 +0000 2013",
  "in_reply_to_screen_name" : "rrhoover",
  "in_reply_to_user_id_str" : "14417215",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://days.am\" rel=\"nofollow\">Days</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 43 ],
      "url" : "https://t.co/3c4VOri3bf",
      "expanded_url" : "https://www.days.am/stories/wSqpb0SMpjA",
      "display_url" : "days.am/stories/wSqpb0\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "330720956861534208",
  "text" : "Friday, May 3, 2013 https://t.co/3c4VOri3bf",
  "id" : 330720956861534208,
  "created_at" : "Sat May 04 16:29:55 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Haughey",
      "screen_name" : "mathowie",
      "indices" : [ 3, 12 ],
      "id_str" : "761975",
      "id" : 761975
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "330715801273380864",
  "text" : "RT @mathowie: \"The Russian dashcam videos made me cry.\" -- words I never thought I'd put together in a sentence during my lifetime.\nhttp://\u2026",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http://t.co/DCgu4m9Hy2",
        "expanded_url" : "http://kottke.org/13/05/tender-moments-caught-on-russian-dash-cams",
        "display_url" : "kottke.org/13/05/tender-m\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "330382885972475904",
    "text" : "\"The Russian dashcam videos made me cry.\" -- words I never thought I'd put together in a sentence during my lifetime.\nhttp://t.co/DCgu4m9Hy2",
    "id" : 330382885972475904,
    "created_at" : "Fri May 03 18:06:32 +0000 2013",
    "user" : {
      "name" : "Matt Haughey",
      "screen_name" : "mathowie",
      "protected" : false,
      "id_str" : "761975",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/344513261566498314/4760bf6a70acdd781fee1335c851bcf6_normal.png",
      "id" : 761975,
      "verified" : false
    }
  },
  "id" : 330715801273380864,
  "created_at" : "Sat May 04 16:09:26 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter   for    iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Willo O'Brien",
      "screen_name" : "WilloLovesYou",
      "indices" : [ 0, 14 ],
      "id_str" : "772386",
      "id" : 772386
    }, {
      "name" : "Ryan Gantz",
      "screen_name" : "sixfoot6",
      "indices" : [ 15, 24 ],
      "id_str" : "822030",
      "id" : 822030
    }, {
      "name" : "Instagram",
      "screen_name" : "instagram",
      "indices" : [ 25, 35 ],
      "id_str" : "180505807",
      "id" : 180505807
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "330567341895208960",
  "geo" : {
  },
  "id_str" : "330586851851247617",
  "in_reply_to_user_id" : 772386,
  "text" : "@WilloLovesYou @sixfoot6 @instagram I live in a world naive enough to wish the same thing! Competitive businesses are lose-lose.",
  "id" : 330586851851247617,
  "in_reply_to_status_id" : 330567341895208960,
  "created_at" : "Sat May 04 07:37:02 +0000 2013",
  "in_reply_to_screen_name" : "WilloLovesYou",
  "in_reply_to_user_id_str" : "772386",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http://t.co/BJcvWDt30W",
      "expanded_url" : "http://flic.kr/p/eghnTF",
      "display_url" : "flic.kr/p/eghnTF"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859833, -122.2755 ]
  },
  "id_str" : "330537434121113601",
  "text" : "8:36pm Niko captures Melanie and Brian http://t.co/BJcvWDt30W",
  "id" : 330537434121113601,
  "created_at" : "Sat May 04 04:20:40 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anders Thoresson",
      "screen_name" : "thoresson",
      "indices" : [ 0, 10 ],
      "id_str" : "11124112",
      "id" : 11124112
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "330410349125832707",
  "geo" : {
  },
  "id_str" : "330411055991881728",
  "in_reply_to_user_id" : 11124112,
  "text" : "@thoresson Yup!",
  "id" : 330411055991881728,
  "in_reply_to_status_id" : 330410349125832707,
  "created_at" : "Fri May 03 19:58:29 +0000 2013",
  "in_reply_to_screen_name" : "thoresson",
  "in_reply_to_user_id_str" : "11124112",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anders Thoresson",
      "screen_name" : "thoresson",
      "indices" : [ 0, 10 ],
      "id_str" : "11124112",
      "id" : 11124112
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "330409228953071616",
  "geo" : {
  },
  "id_str" : "330409446972981249",
  "in_reply_to_user_id" : 11124112,
  "text" : "@thoresson Thank you!",
  "id" : 330409446972981249,
  "in_reply_to_status_id" : 330409228953071616,
  "created_at" : "Fri May 03 19:52:05 +0000 2013",
  "in_reply_to_screen_name" : "thoresson",
  "in_reply_to_user_id_str" : "11124112",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anders Thoresson",
      "screen_name" : "thoresson",
      "indices" : [ 0, 10 ],
      "id_str" : "11124112",
      "id" : 11124112
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "330408575597957121",
  "geo" : {
  },
  "id_str" : "330409034073137152",
  "in_reply_to_user_id" : 11124112,
  "text" : "@thoresson I don't use my phone to log\u2026 I just use Numbers on my Mac at 11am every morning to log the previous day.",
  "id" : 330409034073137152,
  "in_reply_to_status_id" : 330408575597957121,
  "created_at" : "Fri May 03 19:50:27 +0000 2013",
  "in_reply_to_screen_name" : "thoresson",
  "in_reply_to_user_id_str" : "11124112",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8594475443, -122.2758365664 ]
  },
  "id_str" : "330348004613697538",
  "text" : "A social network where we wrote eulogies about each other.",
  "id" : 330348004613697538,
  "created_at" : "Fri May 03 15:47:56 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Clear",
      "screen_name" : "james_clear",
      "indices" : [ 13, 25 ],
      "id_str" : "226428094",
      "id" : 226428094
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http://t.co/cck5aSci7c",
      "expanded_url" : "http://bit.ly/YkX1Uw",
      "display_url" : "bit.ly/YkX1Uw"
    } ]
  },
  "in_reply_to_status_id_str" : "330339977907027970",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597699326, -122.2754000495 ]
  },
  "id_str" : "330341666093404160",
  "in_reply_to_user_id" : 226428094,
  "text" : "Right on! RT @james_clear: Identity-Based Habits: How to Actually Stick to Your Goals http://t.co/cck5aSci7c",
  "id" : 330341666093404160,
  "in_reply_to_status_id" : 330339977907027970,
  "created_at" : "Fri May 03 15:22:45 +0000 2013",
  "in_reply_to_screen_name" : "james_clear",
  "in_reply_to_user_id_str" : "226428094",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TechCrunch",
      "screen_name" : "TechCrunch",
      "indices" : [ 19, 30 ],
      "id_str" : "816653",
      "id" : 816653
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http://t.co/vj72vHMuPJ",
      "expanded_url" : "http://tcrn.ch/11H6nHy",
      "display_url" : "tcrn.ch/11H6nHy"
    } ]
  },
  "in_reply_to_status_id_str" : "330327156104232960",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597498453, -122.2753716913 ]
  },
  "id_str" : "330334353190182912",
  "in_reply_to_user_id" : 816653,
  "text" : "This looks neat RT @TechCrunch: Wander Launches Days App, Looks To Change Your Perspective Of Photo-Sharing Entirely http://t.co/vj72vHMuPJ",
  "id" : 330334353190182912,
  "in_reply_to_status_id" : 330327156104232960,
  "created_at" : "Fri May 03 14:53:41 +0000 2013",
  "in_reply_to_screen_name" : "TechCrunch",
  "in_reply_to_user_id_str" : "816653",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tara Tiger Brown",
      "screen_name" : "tara",
      "indices" : [ 0, 5 ],
      "id_str" : "10959642",
      "id" : 10959642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "330202516421746688",
  "geo" : {
  },
  "id_str" : "330203436714975233",
  "in_reply_to_user_id" : 10959642,
  "text" : "@tara He cycles in and out these days, depending on the value of sleep*alcohol/sick. I'm wearing smurf pajamas if that helps offset at all.",
  "id" : 330203436714975233,
  "in_reply_to_status_id" : 330202516421746688,
  "created_at" : "Fri May 03 06:13:28 +0000 2013",
  "in_reply_to_screen_name" : "tara",
  "in_reply_to_user_id_str" : "10959642",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Bonner",
      "screen_name" : "seanbonner",
      "indices" : [ 0, 11 ],
      "id_str" : "765",
      "id" : 765
    }, {
      "name" : "Anil Dash",
      "screen_name" : "anildash",
      "indices" : [ 12, 21 ],
      "id_str" : "36823",
      "id" : 36823
    }, {
      "name" : "Chris Messina\u2122",
      "screen_name" : "chrismessina",
      "indices" : [ 22, 35 ],
      "id_str" : "1186",
      "id" : 1186
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "330191820904603648",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8594939953, -122.275408791 ]
  },
  "id_str" : "330201392654475264",
  "in_reply_to_user_id" : 765,
  "text" : "@seanbonner @anildash @chrismessina There is a criteria, it's just not uniformly distributed. Much like the future.",
  "id" : 330201392654475264,
  "in_reply_to_status_id" : 330191820904603648,
  "created_at" : "Fri May 03 06:05:21 +0000 2013",
  "in_reply_to_screen_name" : "seanbonner",
  "in_reply_to_user_id_str" : "765",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Kelly",
      "screen_name" : "kevin2kelly",
      "indices" : [ 3, 15 ],
      "id_str" : "1532061",
      "id" : 1532061
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "330173821753626624",
  "text" : "RT @kevin2kelly: This guy leaves the internet for one year. Now he's back and not so sure his unconnected year was a good idea. http://t.co\u2026",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 111, 133 ],
        "url" : "http://t.co/U6WfJvj9lQ",
        "expanded_url" : "http://www.theverge.com/2013/5/1/4279674/im-still-here-back-online-after-a-year-without-the-internet",
        "display_url" : "theverge.com/2013/5/1/42796\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "330172014830682112",
    "text" : "This guy leaves the internet for one year. Now he's back and not so sure his unconnected year was a good idea. http://t.co/U6WfJvj9lQ",
    "id" : 330172014830682112,
    "created_at" : "Fri May 03 04:08:37 +0000 2013",
    "user" : {
      "name" : "Kevin Kelly",
      "screen_name" : "kevin2kelly",
      "protected" : false,
      "id_str" : "1532061",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/65000713/KKlaughsm_normal.jpg",
      "id" : 1532061,
      "verified" : false
    }
  },
  "id" : 330173821753626624,
  "created_at" : "Fri May 03 04:15:48 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http://t.co/hqBpnrMQBa",
      "expanded_url" : "http://flic.kr/p/eg3wVc",
      "display_url" : "flic.kr/p/eg3wVc"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8565, -122.253 ]
  },
  "id_str" : "330166900841644033",
  "text" : "8:36pm Trying a nearby Greek place while I wait for Kellianne and Niko to land http://t.co/hqBpnrMQBa",
  "id" : 330166900841644033,
  "created_at" : "Fri May 03 03:48:18 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Instagram",
      "screen_name" : "instagram",
      "indices" : [ 28, 38 ],
      "id_str" : "180505807",
      "id" : 180505807
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8595894786, -122.2755571573 ]
  },
  "id_str" : "330151583214100480",
  "text" : "Gotta admit that the latest @instagram update is slick. Now that Twitter cards have deep app linking they should turn 'em back on, right?",
  "id" : 330151583214100480,
  "created_at" : "Fri May 03 02:47:26 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kris Kr\u00FCg",
      "screen_name" : "kk",
      "indices" : [ 0, 3 ],
      "id_str" : "13669",
      "id" : 13669
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "330132370684534784",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.776076797, -122.4199794718 ]
  },
  "id_str" : "330132555762372611",
  "in_reply_to_user_id" : 13669,
  "text" : "@kk Don't forget levitas.",
  "id" : 330132555762372611,
  "in_reply_to_status_id" : 330132370684534784,
  "created_at" : "Fri May 03 01:31:49 +0000 2013",
  "in_reply_to_screen_name" : "kk",
  "in_reply_to_user_id_str" : "13669",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Santangelo",
      "screen_name" : "endquote",
      "indices" : [ 0, 9 ],
      "id_str" : "408",
      "id" : 408
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "330023709526069249",
  "geo" : {
  },
  "id_str" : "330026033912901632",
  "in_reply_to_user_id" : 408,
  "text" : "@endquote Any attention is welcome. :)",
  "id" : 330026033912901632,
  "in_reply_to_status_id" : 330023709526069249,
  "created_at" : "Thu May 02 18:28:32 +0000 2013",
  "in_reply_to_screen_name" : "endquote",
  "in_reply_to_user_id_str" : "408",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Santangelo",
      "screen_name" : "endquote",
      "indices" : [ 0, 9 ],
      "id_str" : "408",
      "id" : 408
    }, {
      "name" : "twilio",
      "screen_name" : "twilio",
      "indices" : [ 19, 26 ],
      "id_str" : "15936194",
      "id" : 15936194
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "330022001219616768",
  "geo" : {
  },
  "id_str" : "330022473867358208",
  "in_reply_to_user_id" : 408,
  "text" : "@endquote Good ol' @twilio.",
  "id" : 330022473867358208,
  "in_reply_to_status_id" : 330022001219616768,
  "created_at" : "Thu May 02 18:14:23 +0000 2013",
  "in_reply_to_screen_name" : "endquote",
  "in_reply_to_user_id_str" : "408",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "330015280560496640",
  "geo" : {
  },
  "id_str" : "330015893008576512",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez I think you need to blog/branch this up for a full reply. :)",
  "id" : 330015893008576512,
  "in_reply_to_status_id" : 330015280560496640,
  "created_at" : "Thu May 02 17:48:14 +0000 2013",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "330014581722341377",
  "geo" : {
  },
  "id_str" : "330015109080576000",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez I've come to dislike streaks as a way to track progress. The kiloslog is a heap, and single slogs are simply symbols of the heap.",
  "id" : 330015109080576000,
  "in_reply_to_status_id" : 330014581722341377,
  "created_at" : "Thu May 02 17:45:08 +0000 2013",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "'80s Don Draper",
      "screen_name" : "80sDonDraper",
      "indices" : [ 3, 16 ],
      "id_str" : "229221986",
      "id" : 229221986
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "329990271347593217",
  "text" : "RT @80sDonDraper: Come back to me when you know why I should care about these bears.",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "327215930541219841",
    "text" : "Come back to me when you know why I should care about these bears.",
    "id" : 327215930541219841,
    "created_at" : "Thu Apr 25 00:22:11 +0000 2013",
    "user" : {
      "name" : "'80s Don Draper",
      "screen_name" : "80sDonDraper",
      "protected" : false,
      "id_str" : "229221986",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3570753279/85941ee1cdf7a520ee5054b29046bcb0_normal.jpeg",
      "id" : 229221986,
      "verified" : false
    }
  },
  "id" : 329990271347593217,
  "created_at" : "Thu May 02 16:06:26 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "April V. Walters",
      "screen_name" : "aprilini",
      "indices" : [ 0, 9 ],
      "id_str" : "875511",
      "id" : 875511
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "329988084663992321",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7765049974, -122.4167381732 ]
  },
  "id_str" : "329989427541721089",
  "in_reply_to_user_id" : 875511,
  "text" : "@aprilini Ha! I posted this from BART why it was under the bay.",
  "id" : 329989427541721089,
  "in_reply_to_status_id" : 329988084663992321,
  "created_at" : "Thu May 02 16:03:05 +0000 2013",
  "in_reply_to_screen_name" : "aprilini",
  "in_reply_to_user_id_str" : "875511",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Capecelatro",
      "screen_name" : "jcap49",
      "indices" : [ 0, 7 ],
      "id_str" : "78733683",
      "id" : 78733683
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "329986420540313601",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8025318078, -122.314872366 ]
  },
  "id_str" : "329987213578338304",
  "in_reply_to_user_id" : 78733683,
  "text" : "@jcap49 Solve for all deltas that you consider likely.",
  "id" : 329987213578338304,
  "in_reply_to_status_id" : 329986420540313601,
  "created_at" : "Thu May 02 15:54:17 +0000 2013",
  "in_reply_to_screen_name" : "jcap49",
  "in_reply_to_user_id_str" : "78733683",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "April V. Walters",
      "screen_name" : "aprilini",
      "indices" : [ 0, 9 ],
      "id_str" : "875511",
      "id" : 875511
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "329985288019529728",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8025318078, -122.314872366 ]
  },
  "id_str" : "329986559338246145",
  "in_reply_to_user_id" : 875511,
  "text" : "@aprilini Which day do you have your morbid thinking scheduled. :)",
  "id" : 329986559338246145,
  "in_reply_to_status_id" : 329985288019529728,
  "created_at" : "Thu May 02 15:51:41 +0000 2013",
  "in_reply_to_screen_name" : "aprilini",
  "in_reply_to_user_id_str" : "875511",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Watson",
      "screen_name" : "paulmwatson",
      "indices" : [ 0, 12 ],
      "id_str" : "11214",
      "id" : 11214
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "329982328178892800",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8025418767, -122.3147846407 ]
  },
  "id_str" : "329986334766809088",
  "in_reply_to_user_id" : 11214,
  "text" : "@paulmwatson By your own account.",
  "id" : 329986334766809088,
  "in_reply_to_status_id" : 329982328178892800,
  "created_at" : "Thu May 02 15:50:47 +0000 2013",
  "in_reply_to_screen_name" : "paulmwatson",
  "in_reply_to_user_id_str" : "11214",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "goodmorning",
      "indices" : [ 114, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8098708781, -122.2992558289 ]
  },
  "id_str" : "329984810158288896",
  "text" : "Remember, you will die. What % of your life's fulfillment do you want to eke out of your remaining healthy years? #goodmorning",
  "id" : 329984810158288896,
  "created_at" : "Thu May 02 15:44:44 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Owens",
      "screen_name" : "mko",
      "indices" : [ 0, 4 ],
      "id_str" : "11822502",
      "id" : 11822502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "329981227698360322",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8418104716, -122.2666009513 ]
  },
  "id_str" : "329981652765921282",
  "in_reply_to_user_id" : 11822502,
  "text" : "@mko Awesome. What's your game plan? Hop on the Singularity?",
  "id" : 329981652765921282,
  "in_reply_to_status_id" : 329981227698360322,
  "created_at" : "Thu May 02 15:32:11 +0000 2013",
  "in_reply_to_screen_name" : "mko",
  "in_reply_to_user_id_str" : "11822502",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8522750126, -122.270272797 ]
  },
  "id_str" : "329980905865236480",
  "text" : "What is the last age you want to be considered \"healthy\"? 30? 40? 60? 80? 100?",
  "id" : 329980905865236480,
  "created_at" : "Thu May 02 15:29:13 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gretchen Rubin",
      "screen_name" : "gretchenrubin",
      "indices" : [ 3, 17 ],
      "id_str" : "14289835",
      "id" : 14289835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "329959270282051589",
  "text" : "RT @gretchenrubin: This is one of my new favorite ideas: the \"one-coin argument.\" Do you make this argument to yourself? http://t.co/uHlCsy\u2026",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 102, 124 ],
        "url" : "http://t.co/uHlCsyKDF3",
        "expanded_url" : "http://www.happiness-project.com/happiness_project/2013/03/do-you-make-excuses-for-yourself-based-on-the-one-coin-argument-i-do/",
        "display_url" : "happiness-project.com/happiness_proj\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "329957328910684160",
    "text" : "This is one of my new favorite ideas: the \"one-coin argument.\" Do you make this argument to yourself? http://t.co/uHlCsyKDF3",
    "id" : 329957328910684160,
    "created_at" : "Thu May 02 13:55:32 +0000 2013",
    "user" : {
      "name" : "Gretchen Rubin",
      "screen_name" : "gretchenrubin",
      "protected" : false,
      "id_str" : "14289835",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1436632135/Gretchenonphone_normal.JPG",
      "id" : 14289835,
      "verified" : true
    }
  },
  "id" : 329959270282051589,
  "created_at" : "Thu May 02 14:03:15 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 92, 101 ],
      "id_str" : "21135674",
      "id" : 21135674
    }, {
      "name" : "Jane McGonigal",
      "screen_name" : "avantgame",
      "indices" : [ 102, 112 ],
      "id_str" : "681813",
      "id" : 681813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "329836846592950272",
  "geo" : {
  },
  "id_str" : "329850213298749441",
  "in_reply_to_user_id" : 21135674,
  "text" : "Buzzwords like gamification, tiny habits, etc don't solve problems, they sell \"answers\" /cc @eramirez @avantgame",
  "id" : 329850213298749441,
  "in_reply_to_status_id" : 329836846592950272,
  "created_at" : "Thu May 02 06:49:53 +0000 2013",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Morelli",
      "screen_name" : "pmorelli",
      "indices" : [ 0, 9 ],
      "id_str" : "14161459",
      "id" : 14161459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "329828914509783040",
  "geo" : {
  },
  "id_str" : "329829378638876672",
  "in_reply_to_user_id" : 14161459,
  "text" : "@pmorelli I'll probably regret not having enough Japanese booze on my death bed.",
  "id" : 329829378638876672,
  "in_reply_to_status_id" : 329828914509783040,
  "created_at" : "Thu May 02 05:27:06 +0000 2013",
  "in_reply_to_screen_name" : "pmorelli",
  "in_reply_to_user_id_str" : "14161459",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Morelli",
      "screen_name" : "pmorelli",
      "indices" : [ 1, 10 ],
      "id_str" : "14161459",
      "id" : 14161459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "329826704384208896",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859611685, -122.2754713504 ]
  },
  "id_str" : "329828067411374081",
  "in_reply_to_user_id" : 14161459,
  "text" : ".@pmorelli \"for its own sake\": n. Belonging to the set of things one regrets not getting enough while on one's death bed.",
  "id" : 329828067411374081,
  "in_reply_to_status_id" : 329826704384208896,
  "created_at" : "Thu May 02 05:21:53 +0000 2013",
  "in_reply_to_screen_name" : "pmorelli",
  "in_reply_to_user_id_str" : "14161459",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8595930496, -122.275631341 ]
  },
  "id_str" : "329826222689361923",
  "text" : "\"Well-being theory is a theory of uncoerced choice. Essentially, what free people will choose for their own sake.\" - M. Seligman in Flourish",
  "id" : 329826222689361923,
  "created_at" : "Thu May 02 05:14:34 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gabe Zichermann",
      "screen_name" : "gzicherm",
      "indices" : [ 0, 9 ],
      "id_str" : "5907582",
      "id" : 5907582
    }, {
      "name" : "Jane McGonigal",
      "screen_name" : "avantgame",
      "indices" : [ 10, 20 ],
      "id_str" : "681813",
      "id" : 681813
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gamification",
      "indices" : [ 21, 34 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "329808613952598017",
  "geo" : {
  },
  "id_str" : "329822798589603840",
  "in_reply_to_user_id" : 5907582,
  "text" : "@gzicherm @avantgame #gamification has turned into the signifier of the unsavory application.",
  "id" : 329822798589603840,
  "in_reply_to_status_id" : 329808613952598017,
  "created_at" : "Thu May 02 05:00:57 +0000 2013",
  "in_reply_to_screen_name" : "gzicherm",
  "in_reply_to_user_id_str" : "5907582",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keezy",
      "screen_name" : "Keezy",
      "indices" : [ 14, 20 ],
      "id_str" : "446573026",
      "id" : 446573026
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "318045186603233284",
  "geo" : {
  },
  "id_str" : "329820509321695233",
  "in_reply_to_user_id" : 446573026,
  "text" : "I want in! RT @Keezy: It's easy with Keezy.\nComing soon.",
  "id" : 329820509321695233,
  "in_reply_to_status_id" : 318045186603233284,
  "created_at" : "Thu May 02 04:51:51 +0000 2013",
  "in_reply_to_screen_name" : "Keezy",
  "in_reply_to_user_id_str" : "446573026",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Couch",
      "screen_name" : "couch",
      "indices" : [ 33, 39 ],
      "id_str" : "631823",
      "id" : 631823
    }, {
      "name" : "Buzz Andersen",
      "screen_name" : "buzz",
      "indices" : [ 41, 46 ],
      "id_str" : "528",
      "id" : 528
    }, {
      "name" : "Brett Camper",
      "screen_name" : "professorlemeza",
      "indices" : [ 47, 63 ],
      "id_str" : "20949658",
      "id" : 20949658
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https://t.co/785lzmE7ny",
      "expanded_url" : "https://twitter.com/anildash/status/329656928181559297",
      "display_url" : "twitter.com/anildash/statu\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "329818122003554306",
  "geo" : {
  },
  "id_str" : "329820103266942976",
  "in_reply_to_user_id" : 631823,
  "text" : "Evolution of the face Segway. RT @couch: @buzz @professorlemeza This and everything before it. https://t.co/785lzmE7ny",
  "id" : 329820103266942976,
  "in_reply_to_status_id" : 329818122003554306,
  "created_at" : "Thu May 02 04:50:15 +0000 2013",
  "in_reply_to_screen_name" : "couch",
  "in_reply_to_user_id_str" : "631823",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 23, 33 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http://t.co/9dqx4I03IG",
      "expanded_url" : "http://flic.kr/p/efMSTz",
      "display_url" : "flic.kr/p/efMSTz"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.776833, -122.416834 ]
  },
  "id_str" : "329804369237266433",
  "text" : "8:36pm Apparently when @kellianne's out of town I just stay at work! http://t.co/9dqx4I03IG",
  "id" : 329804369237266433,
  "created_at" : "Thu May 02 03:47:43 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Hall",
      "screen_name" : "JamesHallPhoto",
      "indices" : [ 0, 15 ],
      "id_str" : "63792306",
      "id" : 63792306
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "329760471748067330",
  "geo" : {
  },
  "id_str" : "329772567265161218",
  "in_reply_to_user_id" : 63792306,
  "text" : "@JamesHallPhoto Awesome! I will check them out! Which one should I start with?",
  "id" : 329772567265161218,
  "in_reply_to_status_id" : 329760471748067330,
  "created_at" : "Thu May 02 01:41:21 +0000 2013",
  "in_reply_to_screen_name" : "JamesHallPhoto",
  "in_reply_to_user_id_str" : "63792306",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian Chan",
      "screen_name" : "chanian",
      "indices" : [ 3, 11 ],
      "id_str" : "22891211",
      "id" : 22891211
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "329696359395500034",
  "text" : "RT @chanian: \u27FF Twitter+Data+Viz. I need help (interns/front/backend) building/improving Twitter Website Analytics. Email me chanian@twitter\u2026",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "329669916972167170",
    "text" : "\u27FF Twitter+Data+Viz. I need help (interns/front/backend) building/improving Twitter Website Analytics. Email me chanian@twitter.com",
    "id" : 329669916972167170,
    "created_at" : "Wed May 01 18:53:27 +0000 2013",
    "user" : {
      "name" : "Ian Chan",
      "screen_name" : "chanian",
      "protected" : false,
      "id_str" : "22891211",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2467844172/image_normal.jpg",
      "id" : 22891211,
      "verified" : false
    }
  },
  "id" : 329696359395500034,
  "created_at" : "Wed May 01 20:38:32 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Robinson",
      "screen_name" : "i8joe",
      "indices" : [ 0, 6 ],
      "id_str" : "29387184",
      "id" : 29387184
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "329634070130745344",
  "geo" : {
  },
  "id_str" : "329638917697572865",
  "in_reply_to_user_id" : 29387184,
  "text" : "@i8joe To feel like I'm actually aware of the present moment.",
  "id" : 329638917697572865,
  "in_reply_to_status_id" : 329634070130745344,
  "created_at" : "Wed May 01 16:50:17 +0000 2013",
  "in_reply_to_screen_name" : "i8joe",
  "in_reply_to_user_id_str" : "29387184",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "329630901409574912",
  "text" : "My only meditation goal after 62 days is to start meditating every day. Sometimes I sit there for 5 mins and don't start. So I do another 5.",
  "id" : 329630901409574912,
  "created_at" : "Wed May 01 16:18:25 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/buster/status/329628100210094080/photo/1",
      "indices" : [ 115, 137 ],
      "url" : "http://t.co/lli1RZN6QG",
      "media_url" : "http://pbs.twimg.com/media/BJMTAr2CcAEhgpm.jpg",
      "id_str" : "329628100218482689",
      "id" : 329628100218482689,
      "media_url_https" : "https://pbs.twimg.com/media/BJMTAr2CcAEhgpm.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 927
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 927
      }, {
        "h" : 414,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 235,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com/lli1RZN6QG"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "329628100210094080",
  "text" : "958. My New Year's Resolution started as a complicated morning routine but is now just meditation. 2 mos in a row! http://t.co/lli1RZN6QG",
  "id" : 329628100210094080,
  "created_at" : "Wed May 01 16:07:18 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Guarraci",
      "screen_name" : "eismcc",
      "indices" : [ 3, 10 ],
      "id_str" : "13257392",
      "id" : 13257392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "329612370181758977",
  "text" : "RT @eismcc: Saying \"What's new?\" was the earliest form of pagination.",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter   for  iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "329608682126077952",
    "text" : "Saying \"What's new?\" was the earliest form of pagination.",
    "id" : 329608682126077952,
    "created_at" : "Wed May 01 14:50:08 +0000 2013",
    "user" : {
      "name" : "Brian Guarraci",
      "screen_name" : "eismcc",
      "protected" : false,
      "id_str" : "13257392",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2606722836/rnos07zonatvv51w7tea_normal.png",
      "id" : 13257392,
      "verified" : false
    }
  },
  "id" : 329612370181758977,
  "created_at" : "Wed May 01 15:04:47 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.apple.com\" rel=\"nofollow\">iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Moberg",
      "screen_name" : "patrickmoberg",
      "indices" : [ 23, 37 ],
      "id_str" : "4102571",
      "id" : 4102571
    }, {
      "name" : "Dots",
      "screen_name" : "playdots",
      "indices" : [ 96, 105 ],
      "id_str" : "1390195350",
      "id" : 1390195350
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http://t.co/xwUKY4BXE5",
      "expanded_url" : "http://nerdyoctopus.com/a/fom8d",
      "display_url" : "nerdyoctopus.com/a/fom8d"
    } ]
  },
  "geo" : {
  },
  "id_str" : "329605950212300800",
  "text" : "Fun and pretty game by @patrickmoberg. Check out my trophy on Dots. http://t.co/xwUKY4BXE5 /via @playdots",
  "id" : 329605950212300800,
  "created_at" : "Wed May 01 14:39:16 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 37 ],
      "url" : "http://t.co/DWC0oz1i6i",
      "expanded_url" : "http://wayoftheduck.com/how-to-change-yourself-v01",
      "display_url" : "wayoftheduck.com/how-to-change-\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "329601405256073218",
  "text" : "Rabbit rabbit! http://t.co/DWC0oz1i6i",
  "id" : 329601405256073218,
  "created_at" : "Wed May 01 14:21:13 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
} ]