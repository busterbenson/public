Grailbird.data.tweets_2012_09 = 
 [ {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 3, 13 ],
      "id_str" : "7362142",
      "id" : 7362142
    }, {
      "name" : "Niko Benson",
      "screen_name" : "nikobenson",
      "indices" : [ 23, 34 ],
      "id_str" : "142467448",
      "id" : 142467448
    }, {
      "name" : "Anti-Buster",
      "screen_name" : "busterbenson",
      "indices" : [ 41, 54 ],
      "id_str" : "1024917050",
      "id" : 1024917050
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "252641975088607233",
  "text" : "RT @kellianne: Tonight @nikobenson threw @busterbenson's nose out the window to San Francisco and then said, \"Go get your boogers!\"",
  "retweeted_status" : {
    "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Niko Benson",
        "screen_name" : "nikobenson",
        "indices" : [ 8, 19 ],
        "id_str" : "142467448",
        "id" : 142467448
      }, {
        "name" : "Anti-Buster",
        "screen_name" : "busterbenson",
        "indices" : [ 26, 39 ],
        "id_str" : "1024917050",
        "id" : 1024917050
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "252641467116441600",
    "text" : "Tonight @nikobenson threw @busterbenson's nose out the window to San Francisco and then said, \"Go get your boogers!\"",
    "id" : 252641467116441600,
    "created_at" : "Mon Oct 01 05:29:54 +0000 2012",
    "user" : {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "protected" : false,
      "id_str" : "7362142",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3058433557/056b99ecb9df9b6b9b382b2470b6ee82_normal.jpeg",
      "id" : 7362142,
      "verified" : false
    }
  },
  "id" : 252641975088607233,
  "created_at" : "Mon Oct 01 05:31:55 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/#!/download/ipad\" rel=\"nofollow\">Twitter for iPad</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "david carr",
      "screen_name" : "carr2n",
      "indices" : [ 71, 78 ],
      "id_str" : "24773177",
      "id" : 24773177
    }, {
      "name" : "Wired",
      "screen_name" : "wired",
      "indices" : [ 108, 114 ],
      "id_str" : "1344951",
      "id" : 1344951
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 135 ],
      "url" : "http://t.co/kfHEm63u",
      "expanded_url" : "http://bit.ly/StzaNt",
      "display_url" : "bit.ly/StzaNt"
    } ]
  },
  "geo" : {
  },
  "id_str" : "252638436996026370",
  "text" : "I remember really liking Mary from the Amazon days. Good interview. RT @carr2n: Mary Meeker talks shop with @wired http://t.co/kfHEm63u",
  "id" : 252638436996026370,
  "created_at" : "Mon Oct 01 05:17:51 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "that drew",
      "screen_name" : "thatdrew",
      "indices" : [ 105, 114 ],
      "id_str" : "1002913782",
      "id" : 1002913782
    }, {
      "name" : "Bill Couch",
      "screen_name" : "couch",
      "indices" : [ 115, 121 ],
      "id_str" : "631823",
      "id" : 631823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "252596743458418688",
  "geo" : {
  },
  "id_str" : "252597501549498368",
  "in_reply_to_user_id" : 10221,
  "text" : "Looks like my iOS 6 beta expired. Even though I couldn't upgrade via regular software updates. Lame! Thx @thatdrew @couch for the clue.",
  "id" : 252597501549498368,
  "in_reply_to_status_id" : 252596743458418688,
  "created_at" : "Mon Oct 01 02:35:12 +0000 2012",
  "in_reply_to_screen_name" : "drew",
  "in_reply_to_user_id_str" : "10221",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "252596481805139968",
  "text" : "My iPhone suddenly requires activation, and can't sync to iTunes or be restored to factory settings. Heard of this before?",
  "id" : 252596481805139968,
  "created_at" : "Mon Oct 01 02:31:08 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "harryh",
      "screen_name" : "harryh",
      "indices" : [ 0, 7 ],
      "id_str" : "4558",
      "id" : 4558
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "252544790372155393",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6087113945, -122.3058165168 ]
  },
  "id_str" : "252545309966749696",
  "in_reply_to_user_id" : 4558,
  "text" : "@harryh Damn spreadsheets are impossible to beat.",
  "id" : 252545309966749696,
  "in_reply_to_status_id" : 252544790372155393,
  "created_at" : "Sun Sep 30 23:07:48 +0000 2012",
  "in_reply_to_screen_name" : "harryh",
  "in_reply_to_user_id_str" : "4558",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "harryh",
      "screen_name" : "harryh",
      "indices" : [ 0, 7 ],
      "id_str" : "4558",
      "id" : 4558
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "252537252259975168",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6087499593, -122.3059378887 ]
  },
  "id_str" : "252544331104280576",
  "in_reply_to_user_id" : 4558,
  "text" : "@harryh Awesome! Using anything in particular to track stuff?",
  "id" : 252544331104280576,
  "in_reply_to_status_id" : 252537252259975168,
  "created_at" : "Sun Sep 30 23:03:55 +0000 2012",
  "in_reply_to_screen_name" : "harryh",
  "in_reply_to_user_id_str" : "4558",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.apple.com\" rel=\"nofollow\">iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 27 ],
      "url" : "http://t.co/6MRIpIKz",
      "expanded_url" : "http://youtu.be/xYrme7VIELs",
      "display_url" : "youtu.be/xYrme7VIELs"
    } ]
  },
  "geo" : {
  },
  "id_str" : "252455924239839232",
  "text" : "✔ ABCs http://t.co/6MRIpIKz",
  "id" : 252455924239839232,
  "created_at" : "Sun Sep 30 17:12:37 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carinna Tarvin",
      "screen_name" : "carinnatarvin",
      "indices" : [ 0, 14 ],
      "id_str" : "20833838",
      "id" : 20833838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "252444175407132672",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6086826328, -122.3061228877 ]
  },
  "id_str" : "252445972397957121",
  "in_reply_to_user_id" : 20833838,
  "text" : "@carinnatarvin I've been loving that app.",
  "id" : 252445972397957121,
  "in_reply_to_status_id" : 252444175407132672,
  "created_at" : "Sun Sep 30 16:33:04 +0000 2012",
  "in_reply_to_screen_name" : "carinnatarvin",
  "in_reply_to_user_id_str" : "20833838",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Esther Dyson",
      "screen_name" : "edyson",
      "indices" : [ 117, 124 ],
      "id_str" : "15921173",
      "id" : 15921173
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MedX",
      "indices" : [ 128, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6086692524, -122.3062103896 ]
  },
  "id_str" : "252445226394849281",
  "text" : "Wish I was hearing this! \"Some of the more interesting unsolved problems are health care, medicine, human behavior\" -@edyson at #MedX",
  "id" : 252445226394849281,
  "created_at" : "Sun Sep 30 16:30:06 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 0, 10 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "252249308127195136",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6087016101, -122.3060868402 ]
  },
  "id_str" : "252252916289765376",
  "in_reply_to_user_id" : 7362142,
  "text" : "@kellianne You bungled the URL. :)",
  "id" : 252252916289765376,
  "in_reply_to_status_id" : 252249308127195136,
  "created_at" : "Sun Sep 30 03:45:56 +0000 2012",
  "in_reply_to_screen_name" : "kellianne",
  "in_reply_to_user_id_str" : "7362142",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagr.am\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 79 ],
      "url" : "http://t.co/kjoW2uPs",
      "expanded_url" : "http://instagr.am/p/QL0bZio0HS/",
      "display_url" : "instagr.am/p/QL0bZio0HS/"
    } ]
  },
  "geo" : {
  },
  "id_str" : "252251360173649921",
  "text" : "8:36pm Trying to decide if Thomas is Really Useful or not  http://t.co/kjoW2uPs",
  "id" : 252251360173649921,
  "created_at" : "Sun Sep 30 03:39:45 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagr.am\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 39, 49 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 72 ],
      "url" : "http://t.co/0l3mHQsN",
      "expanded_url" : "http://instagr.am/p/QLffdEo0BK/",
      "display_url" : "instagr.am/p/QLffdEo0BK/"
    } ]
  },
  "geo" : {
  },
  "id_str" : "252205587864096769",
  "text" : "My weekend exercise routine!  Taken by @kellianne . http://t.co/0l3mHQsN",
  "id" : 252205587864096769,
  "created_at" : "Sun Sep 30 00:37:52 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Levie",
      "screen_name" : "levie",
      "indices" : [ 3, 9 ],
      "id_str" : "914061",
      "id" : 914061
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "252195151462686721",
  "text" : "RT @levie: If no one thinks your idea is crazy, it probably sucks.",
  "retweeted_status" : {
    "source" : "<a href=\"http://mobile.twitter.com\" rel=\"nofollow\">Mobile Web</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "252194156376649728",
    "text" : "If no one thinks your idea is crazy, it probably sucks.",
    "id" : 252194156376649728,
    "created_at" : "Sat Sep 29 23:52:27 +0000 2012",
    "user" : {
      "name" : "Aaron Levie",
      "screen_name" : "levie",
      "protected" : false,
      "id_str" : "914061",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1626898956/twitter_normal.png",
      "id" : 914061,
      "verified" : false
    }
  },
  "id" : 252195151462686721,
  "created_at" : "Sat Sep 29 23:56:24 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sharon",
      "screen_name" : "sharon",
      "indices" : [ 0, 7 ],
      "id_str" : "260",
      "id" : 260
    }, {
      "name" : "Willo O'Brien",
      "screen_name" : "WilloToons",
      "indices" : [ 8, 19 ],
      "id_str" : "772386",
      "id" : 772386
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "252187431615463424",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6087112073, -122.3059819826 ]
  },
  "id_str" : "252190739868573696",
  "in_reply_to_user_id" : 260,
  "text" : "@sharon @willotoons Ah got it. Now I know who to bug for future updates! :)",
  "id" : 252190739868573696,
  "in_reply_to_status_id" : 252187431615463424,
  "created_at" : "Sat Sep 29 23:38:52 +0000 2012",
  "in_reply_to_screen_name" : "sharon",
  "in_reply_to_user_id_str" : "260",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Willo O'Brien",
      "screen_name" : "WilloToons",
      "indices" : [ 0, 11 ],
      "id_str" : "772386",
      "id" : 772386
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "252178419205427200",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6086836578, -122.3058524274 ]
  },
  "id_str" : "252185068997582848",
  "in_reply_to_user_id" : 772386,
  "text" : "@WilloToons Wait is something happening with Baby Berman???",
  "id" : 252185068997582848,
  "in_reply_to_status_id" : 252178419205427200,
  "created_at" : "Sat Sep 29 23:16:20 +0000 2012",
  "in_reply_to_screen_name" : "WilloToons",
  "in_reply_to_user_id_str" : "772386",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagr.am\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 80 ],
      "url" : "http://t.co/2PZnpVcV",
      "expanded_url" : "http://instagr.am/p/QLDcJxo0Ea/",
      "display_url" : "instagr.am/p/QLDcJxo0Ea/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6101432521, -122.34375677 ]
  },
  "id_str" : "252143596948553728",
  "text" : "\"Hey birds, come back! Hold'em!\"  @ Victor Steinbrueck Park http://t.co/2PZnpVcV",
  "id" : 252143596948553728,
  "created_at" : "Sat Sep 29 20:31:32 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Britt Selvitelle",
      "screen_name" : "bs",
      "indices" : [ 61, 64 ],
      "id_str" : "309073",
      "id" : 309073
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 115 ],
      "url" : "http://t.co/SfCRoIkE",
      "expanded_url" : "http://worrydream.com/LearnableProgramming/",
      "display_url" : "worrydream.com/LearnableProgr…"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6121408726, -122.3434050848 ]
  },
  "id_str" : "252128020058488832",
  "text" : "Even if you're just curious about programming, read this! RT @bs: If you're a programmer, read http://t.co/SfCRoIkE",
  "id" : 252128020058488832,
  "created_at" : "Sat Sep 29 19:29:38 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amy Jo Kim",
      "screen_name" : "amyjokim",
      "indices" : [ 0, 9 ],
      "id_str" : "780991",
      "id" : 780991
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "252089065254572032",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6087513566, -122.3062364572 ]
  },
  "id_str" : "252090474393903104",
  "in_reply_to_user_id" : 780991,
  "text" : "@amyjokim I think you've convinced me to check it out.",
  "id" : 252090474393903104,
  "in_reply_to_status_id" : 252089065254572032,
  "created_at" : "Sat Sep 29 17:00:27 +0000 2012",
  "in_reply_to_screen_name" : "amyjokim",
  "in_reply_to_user_id_str" : "780991",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "April Schiller",
      "screen_name" : "the_april",
      "indices" : [ 0, 10 ],
      "id_str" : "16644937",
      "id" : 16644937
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "252081827542601728",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6086772187, -122.3061497045 ]
  },
  "id_str" : "252083302612221952",
  "in_reply_to_user_id" : 16644937,
  "text" : "@the_april Ha. Yeah...",
  "id" : 252083302612221952,
  "in_reply_to_status_id" : 252081827542601728,
  "created_at" : "Sat Sep 29 16:31:57 +0000 2012",
  "in_reply_to_screen_name" : "the_april",
  "in_reply_to_user_id_str" : "16644937",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "noah kagan",
      "screen_name" : "noahkagan",
      "indices" : [ 45, 55 ],
      "id_str" : "13737",
      "id" : 13737
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http://t.co/WOU0PfCQ",
      "expanded_url" : "http://okdork.com/2012/09/29/why-i-got-fired-from-facebook-a-100-million-dollar-lesson/",
      "display_url" : "okdork.com/2012/09/29/why…"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6086861454, -122.3061449268 ]
  },
  "id_str" : "252083101675692032",
  "text" : "Great story, Noah. Thanks for telling it. RT @noahkagan: Why I got Fired from Facebook (a $100 Million dollar lesson) http://t.co/WOU0PfCQ",
  "id" : 252083101675692032,
  "created_at" : "Sat Sep 29 16:31:09 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://bufferapp.com\" rel=\"nofollow\">Buffer</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 58 ],
      "url" : "http://t.co/0QGN1U0q",
      "expanded_url" : "http://www.fastcompany.com/1784823/bill-nguyen-boy-bubble",
      "display_url" : "fastcompany.com/1784823/bill-n…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "252073048436510720",
  "text" : "Bill Nguyen is a textbook psychopath. http://t.co/0QGN1U0q",
  "id" : 252073048436510720,
  "created_at" : "Sat Sep 29 15:51:12 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "that drew",
      "screen_name" : "thatdrew",
      "indices" : [ 3, 12 ],
      "id_str" : "1002913782",
      "id" : 1002913782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "251904423507415041",
  "text" : "RT @thatdrew: Here's your nightly Gangnam Style update: 308,036,998 views",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "251898660097499139",
    "text" : "Here's your nightly Gangnam Style update: 308,036,998 views",
    "id" : 251898660097499139,
    "created_at" : "Sat Sep 29 04:18:15 +0000 2012",
    "user" : {
      "name" : "drew olanoff",
      "screen_name" : "drew",
      "protected" : false,
      "id_str" : "10221",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3062210851/7438f1182c3940d3d2596181d758863d_normal.jpeg",
      "id" : 10221,
      "verified" : false
    }
  },
  "id" : 251904423507415041,
  "created_at" : "Sat Sep 29 04:41:09 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Reichhold",
      "screen_name" : "jreichhold",
      "indices" : [ 0, 11 ],
      "id_str" : "14934401",
      "id" : 14934401
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "251899703615188992",
  "geo" : {
  },
  "id_str" : "251900488310718464",
  "in_reply_to_user_id" : 14934401,
  "text" : "@jreichhold True. I think evolving algorithms will eventually (if not already) understand us better than we can ever understand them.",
  "id" : 251900488310718464,
  "in_reply_to_status_id" : 251899703615188992,
  "created_at" : "Sat Sep 29 04:25:31 +0000 2012",
  "in_reply_to_screen_name" : "jreichhold",
  "in_reply_to_user_id_str" : "14934401",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "deepthoughtsonaplane",
      "indices" : [ 49, 70 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "251899611525042176",
  "text" : "Electronics need to be turned off now. Thus ends #deepthoughtsonaplane.",
  "id" : 251899611525042176,
  "created_at" : "Sat Sep 29 04:22:02 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "251899364748972033",
  "text" : "In other words, the language of computers were designed by us to be the perfect drug for our deep need to trust that everything is solvable.",
  "id" : 251899364748972033,
  "created_at" : "Sat Sep 29 04:21:03 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Becky Jewell",
      "screen_name" : "beckyjewell",
      "indices" : [ 0, 12 ],
      "id_str" : "26406166",
      "id" : 26406166
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "251898214771466241",
  "geo" : {
  },
  "id_str" : "251898663566180352",
  "in_reply_to_user_id" : 26406166,
  "text" : "@beckyjewell Not so magic when you realize it's man-made, and therefore designed to give us back exactly what we want from it.",
  "id" : 251898663566180352,
  "in_reply_to_status_id" : 251898214771466241,
  "created_at" : "Sat Sep 29 04:18:16 +0000 2012",
  "in_reply_to_screen_name" : "beckyjewell",
  "in_reply_to_user_id_str" : "26406166",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "251897930804498435",
  "text" : "Maybe people who think programming is magic haven't stuck with it long enough to get addicted to the answers returned by every question.",
  "id" : 251897930804498435,
  "created_at" : "Sat Sep 29 04:15:21 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Natalya",
      "screen_name" : "talof2cities",
      "indices" : [ 0, 13 ],
      "id_str" : "62600226",
      "id" : 62600226
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "251896384884715520",
  "geo" : {
  },
  "id_str" : "251897410010378240",
  "in_reply_to_user_id" : 62600226,
  "text" : "@talof2cities I believe it is, but the \"eventually\" is probably longer than a lifetime. Maybe longer than humanity's lifetime too.",
  "id" : 251897410010378240,
  "in_reply_to_status_id" : 251896384884715520,
  "created_at" : "Sat Sep 29 04:13:17 +0000 2012",
  "in_reply_to_screen_name" : "talof2cities",
  "in_reply_to_user_id_str" : "62600226",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 44 ],
      "url" : "http://t.co/EOvsSVb0",
      "expanded_url" : "http://flic.kr/p/deZGKp",
      "display_url" : "flic.kr/p/deZGKp"
    } ]
  },
  "geo" : {
  },
  "id_str" : "251892894800166913",
  "text" : "8:36pm Scala on a plane http://t.co/EOvsSVb0",
  "id" : 251892894800166913,
  "created_at" : "Sat Sep 29 03:55:20 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Reichhold",
      "screen_name" : "jreichhold",
      "indices" : [ 0, 11 ],
      "id_str" : "14934401",
      "id" : 14934401
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "251889412080799744",
  "geo" : {
  },
  "id_str" : "251890947527426048",
  "in_reply_to_user_id" : 14934401,
  "text" : "@jreichhold I'm doing my functional programming in Scala homework.",
  "id" : 251890947527426048,
  "in_reply_to_status_id" : 251889412080799744,
  "created_at" : "Sat Sep 29 03:47:36 +0000 2012",
  "in_reply_to_screen_name" : "jreichhold",
  "in_reply_to_user_id_str" : "14934401",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "251888795396472833",
  "text" : "Writing code is addictive because everything is (eventually) understandable. Putting in effort can always results in an answer of some sort.",
  "id" : 251888795396472833,
  "created_at" : "Sat Sep 29 03:39:03 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amy Jo Kim",
      "screen_name" : "amyjokim",
      "indices" : [ 11, 20 ],
      "id_str" : "780991",
      "id" : 780991
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http://t.co/5vOMPZGs",
      "expanded_url" : "http://nyti.ms/RoGKrY",
      "display_url" : "nyti.ms/RoGKrY"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.6173822572, -122.3804508951 ]
  },
  "id_str" : "251874796231593984",
  "text" : "AKA me. RT @amyjokim: Most likely buyer of a self-help book is one who bought another self-help book in the last 18mo http://t.co/5vOMPZGs",
  "id" : 251874796231593984,
  "created_at" : "Sat Sep 29 02:43:25 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://bufferapp.com\" rel=\"nofollow\">Buffer</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Radiolab",
      "screen_name" : "Radiolab",
      "indices" : [ 82, 91 ],
      "id_str" : "28583197",
      "id" : 28583197
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 112 ],
      "url" : "http://t.co/RkQWkP9N",
      "expanded_url" : "http://www.radiolab.org/2012/sep/24/",
      "display_url" : "radiolab.org/2012/sep/24/"
    } ]
  },
  "geo" : {
  },
  "id_str" : "251832440304308224",
  "text" : "\"The pursuit of truth shouldn't stop short of insanity.\" - Errol Morris in latest @radiolab http://t.co/RkQWkP9N",
  "id" : 251832440304308224,
  "created_at" : "Fri Sep 28 23:55:07 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Radiolab",
      "screen_name" : "Radiolab",
      "indices" : [ 6, 15 ],
      "id_str" : "28583197",
      "id" : 28583197
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7792141067, -122.4142383474 ]
  },
  "id_str" : "251819000676356097",
  "text" : "I'm a @Radiolab junkie. Luckily today I can get my fix.",
  "id" : 251819000676356097,
  "created_at" : "Fri Sep 28 23:01:42 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Slackulator",
      "screen_name" : "slackulator",
      "indices" : [ 13, 25 ],
      "id_str" : "282910433",
      "id" : 282910433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "251805523408744448",
  "text" : "According to @slackulator, I get about 4 tweets per minute (tpm), or 5,844 tpd.",
  "id" : 251805523408744448,
  "created_at" : "Fri Sep 28 22:08:09 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joel Bez",
      "screen_name" : "lejoe",
      "indices" : [ 0, 6 ],
      "id_str" : "2129311",
      "id" : 2129311
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "251788889583390720",
  "geo" : {
  },
  "id_str" : "251789210812551168",
  "in_reply_to_user_id" : 2129311,
  "text" : "@lejoe Awesome. I'll be here all week that week.",
  "id" : 251789210812551168,
  "in_reply_to_status_id" : 251788889583390720,
  "created_at" : "Fri Sep 28 21:03:20 +0000 2012",
  "in_reply_to_screen_name" : "lejoe",
  "in_reply_to_user_id_str" : "2129311",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joel Bez",
      "screen_name" : "lejoe",
      "indices" : [ 0, 6 ],
      "id_str" : "2129311",
      "id" : 2129311
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "251788239525015553",
  "geo" : {
  },
  "id_str" : "251788671215341569",
  "in_reply_to_user_id" : 2129311,
  "text" : "@lejoe Great meeting you too! Definitely up for a beer. Are you still in SF week after next?",
  "id" : 251788671215341569,
  "in_reply_to_status_id" : 251788239525015553,
  "created_at" : "Fri Sep 28 21:01:11 +0000 2012",
  "in_reply_to_screen_name" : "lejoe",
  "in_reply_to_user_id_str" : "2129311",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ragnar Freyr",
      "screen_name" : "ragnarfreyr",
      "indices" : [ 0, 12 ],
      "id_str" : "16509622",
      "id" : 16509622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "251774186610106369",
  "geo" : {
  },
  "id_str" : "251784856076443650",
  "in_reply_to_user_id" : 16509622,
  "text" : "@ragnarfreyr I'm not sure yet... that's part of the fun with this experiment. I'm judging on a case by case basis.",
  "id" : 251784856076443650,
  "in_reply_to_status_id" : 251774186610106369,
  "created_at" : "Fri Sep 28 20:46:02 +0000 2012",
  "in_reply_to_screen_name" : "ragnarfreyr",
  "in_reply_to_user_id_str" : "16509622",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://bufferapp.com\" rel=\"nofollow\">Buffer</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 62 ],
      "url" : "http://t.co/ghEoWeKs",
      "expanded_url" : "http://bit.ly/PwmjXE",
      "display_url" : "bit.ly/PwmjXE"
    } ]
  },
  "geo" : {
  },
  "id_str" : "251759463344787456",
  "text" : "There's something wrong with the universe http://t.co/ghEoWeKs",
  "id" : 251759463344787456,
  "created_at" : "Fri Sep 28 19:05:08 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://bufferapp.com\" rel=\"nofollow\">Buffer</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 137 ],
      "url" : "http://t.co/6LuqV0lH",
      "expanded_url" : "http://tcrn.ch/PwoBpE",
      "display_url" : "tcrn.ch/PwoBpE"
    } ]
  },
  "geo" : {
  },
  "id_str" : "251733494865215488",
  "text" : "I've been playing with the new Discover stuff on Twitter and it has gotten MUCH better than it used to be. Check it. http://t.co/6LuqV0lH",
  "id" : 251733494865215488,
  "created_at" : "Fri Sep 28 17:21:56 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suzanne asprea",
      "screen_name" : "sasprea",
      "indices" : [ 0, 8 ],
      "id_str" : "15140098",
      "id" : 15140098
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http://t.co/YmFeplSP",
      "expanded_url" : "http://maps.google.com",
      "display_url" : "maps.google.com"
    } ]
  },
  "in_reply_to_status_id_str" : "251717311243898880",
  "geo" : {
  },
  "id_str" : "251728267260862464",
  "in_reply_to_user_id" : 15140098,
  "text" : "@sasprea I think it's generally overblown, unless you really use it to figure out bus routes a lot. I just bookmarked http://t.co/YmFeplSP.",
  "id" : 251728267260862464,
  "in_reply_to_status_id" : 251717311243898880,
  "created_at" : "Fri Sep 28 17:01:10 +0000 2012",
  "in_reply_to_screen_name" : "sasprea",
  "in_reply_to_user_id_str" : "15140098",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 64 ],
      "url" : "http://t.co/UXCU3B0z",
      "expanded_url" : "http://750words.com",
      "display_url" : "750words.com"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.776382125, -122.4167728886 ]
  },
  "id_str" : "251718564774572032",
  "text" : "Your favorite private journaling community, http://t.co/UXCU3B0z, is working again. What, you haven't heard of it? Go check it out!",
  "id" : 251718564774572032,
  "created_at" : "Fri Sep 28 16:22:37 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Foursquare",
      "screen_name" : "foursquare",
      "indices" : [ 12, 23 ],
      "id_str" : "14120151",
      "id" : 14120151
    }, {
      "name" : "Dennis Crowley",
      "screen_name" : "dens",
      "indices" : [ 112, 117 ],
      "id_str" : "418",
      "id" : 418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 106 ],
      "url" : "https://t.co/ncPhb7zs",
      "expanded_url" : "https://foursquare.com/app/last-tweet/CJSPYMTCS4SEAZZJFBYQB1FFSYJUQ2WRDUXPCDPFFS3ER3PY",
      "display_url" : "foursquare.com/app/last-tweet…"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7871496188, -122.4113514718 ]
  },
  "id_str" : "251709543778750464",
  "text" : "Really cool @foursquare app that pings you w/ last tweet from places you check in to https://t.co/ncPhb7zs /via @dens",
  "id" : 251709543778750464,
  "created_at" : "Fri Sep 28 15:46:46 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Bodge",
      "screen_name" : "mikebodge",
      "indices" : [ 0, 10 ],
      "id_str" : "19344531",
      "id" : 19344531
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "251700835778695168",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7870268734, -122.4113652351 ]
  },
  "id_str" : "251702854941818881",
  "in_reply_to_user_id" : 19344531,
  "text" : "@mikebodge Oh shit! That sounds horrendous.",
  "id" : 251702854941818881,
  "in_reply_to_status_id" : 251700835778695168,
  "created_at" : "Fri Sep 28 15:20:11 +0000 2012",
  "in_reply_to_screen_name" : "mikebodge",
  "in_reply_to_user_id_str" : "19344531",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http://t.co/UXCU3B0z",
      "expanded_url" : "http://750words.com",
      "display_url" : "750words.com"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7869885063, -122.4113176228 ]
  },
  "id_str" : "251700101129576448",
  "text" : "Oops,the secure server certificate for http://t.co/UXCU3B0z expired. We're working on it and should have it fixed soon.",
  "id" : 251700101129576448,
  "created_at" : "Fri Sep 28 15:09:15 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Sippey",
      "screen_name" : "sippey",
      "indices" : [ 3, 10 ],
      "id_str" : "4711",
      "id" : 4711
    }, {
      "name" : "Barack Obama",
      "screen_name" : "BarackObama",
      "indices" : [ 27, 39 ],
      "id_str" : "813286",
      "id" : 813286
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 61 ],
      "url" : "http://t.co/iGKdP5Rs",
      "expanded_url" : "http://www.youtube.com/watch?feature=player_embedded&v=B9xCCaseop4",
      "display_url" : "youtube.com/watch?feature=…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "251566455714349056",
  "text" : "RT @sippey: Amazing ad for @BarackObama. http://t.co/iGKdP5Rs",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Barack Obama",
        "screen_name" : "BarackObama",
        "indices" : [ 15, 27 ],
        "id_str" : "813286",
        "id" : 813286
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 29, 49 ],
        "url" : "http://t.co/iGKdP5Rs",
        "expanded_url" : "http://www.youtube.com/watch?feature=player_embedded&v=B9xCCaseop4",
        "display_url" : "youtube.com/watch?feature=…"
      } ]
    },
    "geo" : {
    },
    "id_str" : "251556735888785408",
    "text" : "Amazing ad for @BarackObama. http://t.co/iGKdP5Rs",
    "id" : 251556735888785408,
    "created_at" : "Fri Sep 28 05:39:34 +0000 2012",
    "user" : {
      "name" : "Michael Sippey",
      "screen_name" : "sippey",
      "protected" : false,
      "id_str" : "4711",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2990071228/1badb0fe82fced7ac4068c6669a54a76_normal.jpeg",
      "id" : 4711,
      "verified" : false
    }
  },
  "id" : 251566455714349056,
  "created_at" : "Fri Sep 28 06:18:11 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ArielMeadowStallings",
      "screen_name" : "OffbeatAriel",
      "indices" : [ 0, 13 ],
      "id_str" : "14095370",
      "id" : 14095370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "251561067958906880",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7869697248, -122.411297785 ]
  },
  "id_str" : "251565637040754688",
  "in_reply_to_user_id" : 14095370,
  "text" : "@OffbeatAriel Yay! I thought you'd like it.",
  "id" : 251565637040754688,
  "in_reply_to_status_id" : 251561067958906880,
  "created_at" : "Fri Sep 28 06:14:56 +0000 2012",
  "in_reply_to_screen_name" : "OffbeatAriel",
  "in_reply_to_user_id_str" : "14095370",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Om Malik",
      "screen_name" : "om",
      "indices" : [ 3, 6 ],
      "id_str" : "989",
      "id" : 989
    }, {
      "name" : "Donna",
      "screen_name" : "donna",
      "indices" : [ 9, 15 ],
      "id_str" : "385159039",
      "id" : 385159039
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "251549913186443264",
  "text" : "RT @om: .@donna blog is now open &amp; now you can learn about one of coolest apps. Coming soon 2 iPhone home screens near you \nhttp://t ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Donna",
        "screen_name" : "donna",
        "indices" : [ 1, 7 ],
        "id_str" : "385159039",
        "id" : 385159039
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 120, 140 ],
        "url" : "http://t.co/nMwgkFDK",
        "expanded_url" : "http://blog.don.na/post/32406160834/the-age-of-anticipatory-assistants",
        "display_url" : "blog.don.na/post/324061608…"
      } ]
    },
    "geo" : {
    },
    "id_str" : "251539071783010304",
    "text" : ".@donna blog is now open &amp; now you can learn about one of coolest apps. Coming soon 2 iPhone home screens near you \nhttp://t.co/nMwgkFDK",
    "id" : 251539071783010304,
    "created_at" : "Fri Sep 28 04:29:22 +0000 2012",
    "user" : {
      "name" : "Om Malik",
      "screen_name" : "om",
      "protected" : false,
      "id_str" : "989",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2601170258/z3bo77mwfuz7ll7fd9z0_normal.jpeg",
      "id" : 989,
      "verified" : true
    }
  },
  "id" : 251549913186443264,
  "created_at" : "Fri Sep 28 05:12:27 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Wolf",
      "screen_name" : "agaricus",
      "indices" : [ 3, 12 ],
      "id_str" : "21678279",
      "id" : 21678279
    }, {
      "name" : "Anti-Buster",
      "screen_name" : "busterbenson",
      "indices" : [ 14, 27 ],
      "id_str" : "1024917050",
      "id" : 1024917050
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "251537179812184065",
  "text" : "RT @agaricus: @busterbenson for our memories: topics included kids, words, numbers, silence, animals, and -not changing-.",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Anti-Buster",
        "screen_name" : "busterbenson",
        "indices" : [ 0, 13 ],
        "id_str" : "1024917050",
        "id" : 1024917050
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "251527518849478657",
    "geo" : {
    },
    "id_str" : "251536414699835393",
    "in_reply_to_user_id" : 2185,
    "text" : "@busterbenson for our memories: topics included kids, words, numbers, silence, animals, and -not changing-.",
    "id" : 251536414699835393,
    "in_reply_to_status_id" : 251527518849478657,
    "created_at" : "Fri Sep 28 04:18:49 +0000 2012",
    "in_reply_to_screen_name" : "buster",
    "in_reply_to_user_id_str" : "2185",
    "user" : {
      "name" : "Gary Wolf",
      "screen_name" : "agaricus",
      "protected" : false,
      "id_str" : "21678279",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/105835994/agaricus_normal.jpg",
      "id" : 21678279,
      "verified" : false
    }
  },
  "id" : 251537179812184065,
  "created_at" : "Fri Sep 28 04:21:51 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagr.am\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Wolf",
      "screen_name" : "agaricus",
      "indices" : [ 85, 94 ],
      "id_str" : "21678279",
      "id" : 21678279
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 116 ],
      "url" : "http://t.co/DuvzVgrQ",
      "expanded_url" : "http://instagr.am/p/QGrBnrI0CL/",
      "display_url" : "instagr.am/p/QGrBnrI0CL/"
    } ]
  },
  "geo" : {
  },
  "id_str" : "251527518849478657",
  "text" : "8:36pm Met and had a great conversation with one of my long time heroes, Gary Wolf / @agaricus! http://t.co/DuvzVgrQ",
  "id" : 251527518849478657,
  "created_at" : "Fri Sep 28 03:43:28 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Ledwith",
      "screen_name" : "sledwith",
      "indices" : [ 0, 9 ],
      "id_str" : "21778255",
      "id" : 21778255
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "trolling",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "251463652748709888",
  "geo" : {
  },
  "id_str" : "251470943162093568",
  "in_reply_to_user_id" : 21778255,
  "text" : "@sledwith Yes, but were they meant for factory farming? #trolling",
  "id" : 251470943162093568,
  "in_reply_to_status_id" : 251463652748709888,
  "created_at" : "Thu Sep 27 23:58:39 +0000 2012",
  "in_reply_to_screen_name" : "sledwith",
  "in_reply_to_user_id_str" : "21778255",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://bufferapp.com\" rel=\"nofollow\">Buffer</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Ducker",
      "screen_name" : "miradu",
      "indices" : [ 116, 123 ],
      "id_str" : "1530531",
      "id" : 1530531
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 110 ],
      "url" : "http://t.co/MrAnsSLH",
      "expanded_url" : "http://bit.ly/PswVGT",
      "display_url" : "bit.ly/PswVGT"
    } ]
  },
  "geo" : {
  },
  "id_str" : "251470085556928512",
  "text" : "Woah this is sort of awesome and depressing at the same time. Tracking homophobic tweets: http://t.co/MrAnsSLH /via @miradu",
  "id" : 251470085556928512,
  "created_at" : "Thu Sep 27 23:55:15 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Guarraci",
      "screen_name" : "eismcc",
      "indices" : [ 0, 7 ],
      "id_str" : "13257392",
      "id" : 13257392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "251413952968392705",
  "geo" : {
  },
  "id_str" : "251424255110172672",
  "in_reply_to_user_id" : 13257392,
  "text" : "@eismcc I'm talking more about the fact that most animals are raised in torturous conditions, etc before moving.",
  "id" : 251424255110172672,
  "in_reply_to_status_id" : 251413952968392705,
  "created_at" : "Thu Sep 27 20:53:08 +0000 2012",
  "in_reply_to_screen_name" : "eismcc",
  "in_reply_to_user_id_str" : "13257392",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://bufferapp.com\" rel=\"nofollow\">Buffer</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 130 ],
      "url" : "http://t.co/EJTbsNf5",
      "expanded_url" : "http://bit.ly/Qrcjlu",
      "display_url" : "bit.ly/Qrcjlu"
    } ]
  },
  "geo" : {
  },
  "id_str" : "251397074560630784",
  "text" : "True or false? \"By far the most cruel thing any of us does each day is consume animals (and their products).\" http://t.co/EJTbsNf5",
  "id" : 251397074560630784,
  "created_at" : "Thu Sep 27 19:05:07 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://bufferapp.com\" rel=\"nofollow\">Buffer</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 105 ],
      "url" : "http://t.co/hhC4enXB",
      "expanded_url" : "http://bit.ly/PmLlZ4",
      "display_url" : "bit.ly/PmLlZ4"
    } ]
  },
  "geo" : {
  },
  "id_str" : "251348279038709761",
  "text" : "If you see me with an alcoholic drink and it's not red wine, I'll give you a dollar. http://t.co/hhC4enXB",
  "id" : 251348279038709761,
  "created_at" : "Thu Sep 27 15:51:14 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leo Babauta",
      "screen_name" : "zen_habits",
      "indices" : [ 38, 49 ],
      "id_str" : "15859268",
      "id" : 15859268
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 122 ],
      "url" : "http://t.co/L9gSPeSA",
      "expanded_url" : "http://zenhabits.net/plants/",
      "display_url" : "zenhabits.net/plants/"
    } ]
  },
  "geo" : {
  },
  "id_str" : "251347362184839171",
  "text" : "Working on moving to this (slowly) RT @zen_habits: on zenhabits: A Guide to Eating a Plant-Based Diet http://t.co/L9gSPeSA",
  "id" : 251347362184839171,
  "created_at" : "Thu Sep 27 15:47:35 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "christopher jones",
      "screen_name" : "cjlikearockstar",
      "indices" : [ 0, 16 ],
      "id_str" : "34383091",
      "id" : 34383091
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "251207893964177408",
  "geo" : {
  },
  "id_str" : "251209153350094848",
  "in_reply_to_user_id" : 34383091,
  "text" : "@cjlikearockstar Are you ever in SF?",
  "id" : 251209153350094848,
  "in_reply_to_status_id" : 251207893964177408,
  "created_at" : "Thu Sep 27 06:38:24 +0000 2012",
  "in_reply_to_screen_name" : "cjlikearockstar",
  "in_reply_to_user_id_str" : "34383091",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Haughey",
      "screen_name" : "mathowie",
      "indices" : [ 0, 9 ],
      "id_str" : "761975",
      "id" : 761975
    }, {
      "name" : "Buzz Andersen",
      "screen_name" : "buzz",
      "indices" : [ 10, 15 ],
      "id_str" : "528",
      "id" : 528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "251205554544975872",
  "geo" : {
  },
  "id_str" : "251207435413508098",
  "in_reply_to_user_id" : 761975,
  "text" : "@mathowie @buzz But yeah I think you're right. And yet another part of me doesn't care if I sabotage myself by calling a spade a spade.",
  "id" : 251207435413508098,
  "in_reply_to_status_id" : 251205554544975872,
  "created_at" : "Thu Sep 27 06:31:34 +0000 2012",
  "in_reply_to_screen_name" : "mathowie",
  "in_reply_to_user_id_str" : "761975",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Haughey",
      "screen_name" : "mathowie",
      "indices" : [ 0, 9 ],
      "id_str" : "761975",
      "id" : 761975
    }, {
      "name" : "Buzz Andersen",
      "screen_name" : "buzz",
      "indices" : [ 10, 15 ],
      "id_str" : "528",
      "id" : 528
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jk",
      "indices" : [ 61, 64 ]
    }, {
      "text" : "maybe",
      "indices" : [ 65, 71 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "251205554544975872",
  "geo" : {
  },
  "id_str" : "251206459814182913",
  "in_reply_to_user_id" : 761975,
  "text" : "@mathowie @buzz Yeah I can't believe you said that about me. #jk #maybe",
  "id" : 251206459814182913,
  "in_reply_to_status_id" : 251205554544975872,
  "created_at" : "Thu Sep 27 06:27:41 +0000 2012",
  "in_reply_to_screen_name" : "mathowie",
  "in_reply_to_user_id_str" : "761975",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Cottrell",
      "screen_name" : "rgcottrell",
      "indices" : [ 0, 11 ],
      "id_str" : "752553",
      "id" : 752553
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "251203658446958593",
  "geo" : {
  },
  "id_str" : "251204246605795328",
  "in_reply_to_user_id" : 752553,
  "text" : "@rgcottrell If i was, I'd now tell you that you owe me a buck.",
  "id" : 251204246605795328,
  "in_reply_to_status_id" : 251203658446958593,
  "created_at" : "Thu Sep 27 06:18:54 +0000 2012",
  "in_reply_to_screen_name" : "rgcottrell",
  "in_reply_to_user_id_str" : "752553",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Buzz Andersen",
      "screen_name" : "buzz",
      "indices" : [ 0, 5 ],
      "id_str" : "528",
      "id" : 528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "251203595251372032",
  "geo" : {
  },
  "id_str" : "251204016791486464",
  "in_reply_to_user_id" : 528,
  "text" : "@buzz Yup. Like all things I'm making it a public game to help me find my own line.",
  "id" : 251204016791486464,
  "in_reply_to_status_id" : 251203595251372032,
  "created_at" : "Thu Sep 27 06:17:59 +0000 2012",
  "in_reply_to_screen_name" : "buzz",
  "in_reply_to_user_id_str" : "528",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Wallin",
      "screen_name" : "joewallin",
      "indices" : [ 0, 10 ],
      "id_str" : "14857106",
      "id" : 14857106
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 93 ],
      "url" : "http://t.co/bBJaraQw",
      "expanded_url" : "http://wayoftheduck.com",
      "display_url" : "wayoftheduck.com"
    } ]
  },
  "in_reply_to_status_id_str" : "251202781162119168",
  "geo" : {
  },
  "id_str" : "251203420323733504",
  "in_reply_to_user_id" : 14857106,
  "text" : "@joewallin Yup! For complaints, gossip, junk food, and most alcohol. See http://t.co/bBJaraQw...",
  "id" : 251203420323733504,
  "in_reply_to_status_id" : 251202781162119168,
  "created_at" : "Thu Sep 27 06:15:37 +0000 2012",
  "in_reply_to_screen_name" : "joewallin",
  "in_reply_to_user_id_str" : "14857106",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Buzz Andersen",
      "screen_name" : "buzz",
      "indices" : [ 3, 8 ],
      "id_str" : "528",
      "id" : 528
    }, {
      "name" : "Anti-Buster",
      "screen_name" : "busterbenson",
      "indices" : [ 10, 23 ],
      "id_str" : "1024917050",
      "id" : 1024917050
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "251203102500347905",
  "text" : "RT @buzz: @busterbenson Shit talking can serve a social function. All that it takes for evil to triumph is for good people not to shit talk.",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Anti-Buster",
        "screen_name" : "busterbenson",
        "indices" : [ 0, 13 ],
        "id_str" : "1024917050",
        "id" : 1024917050
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "251200196371947520",
    "geo" : {
    },
    "id_str" : "251202276683816961",
    "in_reply_to_user_id" : 2185,
    "text" : "@busterbenson Shit talking can serve a social function. All that it takes for evil to triumph is for good people not to shit talk.",
    "id" : 251202276683816961,
    "in_reply_to_status_id" : 251200196371947520,
    "created_at" : "Thu Sep 27 06:11:04 +0000 2012",
    "in_reply_to_screen_name" : "buster",
    "in_reply_to_user_id_str" : "2185",
    "user" : {
      "name" : "Buzz Andersen",
      "screen_name" : "buzz",
      "protected" : false,
      "id_str" : "528",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1688674062/image_normal.jpg",
      "id" : 528,
      "verified" : false
    }
  },
  "id" : 251203102500347905,
  "created_at" : "Thu Sep 27 06:14:21 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Buzz Andersen",
      "screen_name" : "buzz",
      "indices" : [ 0, 5 ],
      "id_str" : "528",
      "id" : 528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "251202276683816961",
  "geo" : {
  },
  "id_str" : "251202986905333760",
  "in_reply_to_user_id" : 528,
  "text" : "@buzz I totally agree. I take pride in not concealing bad behavior of others. But I'm trying try keep it civil rather than personal.",
  "id" : 251202986905333760,
  "in_reply_to_status_id" : 251202276683816961,
  "created_at" : "Thu Sep 27 06:13:53 +0000 2012",
  "in_reply_to_screen_name" : "buzz",
  "in_reply_to_user_id_str" : "528",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kimberly",
      "screen_name" : "FertilityFlower",
      "indices" : [ 0, 16 ],
      "id_str" : "140362289",
      "id" : 140362289
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "251200760497438721",
  "geo" : {
  },
  "id_str" : "251202439435411456",
  "in_reply_to_user_id" : 140362289,
  "text" : "@FertilityFlower Yup! Now it's all modernized etc.",
  "id" : 251202439435411456,
  "in_reply_to_status_id" : 251200760497438721,
  "created_at" : "Thu Sep 27 06:11:43 +0000 2012",
  "in_reply_to_screen_name" : "FertilityFlower",
  "in_reply_to_user_id_str" : "140362289",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "251200196371947520",
  "text" : "My new game has made me realize how often I talk shit about people. I'm not even counting the purely factual stuff that reflects badly...",
  "id" : 251200196371947520,
  "created_at" : "Thu Sep 27 06:02:48 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "christopher jones",
      "screen_name" : "cjlikearockstar",
      "indices" : [ 0, 16 ],
      "id_str" : "34383091",
      "id" : 34383091
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "251196561990774784",
  "geo" : {
  },
  "id_str" : "251198518956535808",
  "in_reply_to_user_id" : 34383091,
  "text" : "@cjlikearockstar If I complain about you that's what I will do. Only problem is that that will never happen!",
  "id" : 251198518956535808,
  "in_reply_to_status_id" : 251196561990774784,
  "created_at" : "Thu Sep 27 05:56:08 +0000 2012",
  "in_reply_to_screen_name" : "cjlikearockstar",
  "in_reply_to_user_id_str" : "34383091",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jordy Mont-Reynaud",
      "screen_name" : "curiousjordy",
      "indices" : [ 4, 17 ],
      "id_str" : "1000",
      "id" : 1000
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "251195634500112384",
  "text" : "Pay @curiousjordy $10 because I had 3 beers and talked negatively about at least 7 people. But his story &amp; conversation was worth it!",
  "id" : 251195634500112384,
  "created_at" : "Thu Sep 27 05:44:40 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Singer",
      "screen_name" : "singy",
      "indices" : [ 0, 6 ],
      "id_str" : "15310552",
      "id" : 15310552
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "251194303345459200",
  "geo" : {
  },
  "id_str" : "251194997536329728",
  "in_reply_to_user_id" : 15310552,
  "text" : "@singy I like that. I'll add that too. And call you out if I see it. :)",
  "id" : 251194997536329728,
  "in_reply_to_status_id" : 251194303345459200,
  "created_at" : "Thu Sep 27 05:42:09 +0000 2012",
  "in_reply_to_screen_name" : "singy",
  "in_reply_to_user_id_str" : "15310552",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amber Rae",
      "screen_name" : "heyamberrae",
      "indices" : [ 3, 15 ],
      "id_str" : "15019184",
      "id" : 15019184
    }, {
      "name" : "Anti-Buster",
      "screen_name" : "busterbenson",
      "indices" : [ 17, 30 ],
      "id_str" : "1024917050",
      "id" : 1024917050
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "251194090199326720",
  "text" : "RT @heyamberrae: @busterbenson Wishes are complaints from optimists. I'll reply, \"You wish or you will?\" to filter importance &amp; then ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Tweetie for Mac</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Anti-Buster",
        "screen_name" : "busterbenson",
        "indices" : [ 0, 13 ],
        "id_str" : "1024917050",
        "id" : 1024917050
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "251134740785147904",
    "geo" : {
    },
    "id_str" : "251140156386590720",
    "in_reply_to_user_id" : 2185,
    "text" : "@busterbenson Wishes are complaints from optimists. I'll reply, \"You wish or you will?\" to filter importance &amp; then \"What's the first step?\"",
    "id" : 251140156386590720,
    "in_reply_to_status_id" : 251134740785147904,
    "created_at" : "Thu Sep 27 02:04:13 +0000 2012",
    "in_reply_to_screen_name" : "buster",
    "in_reply_to_user_id_str" : "2185",
    "user" : {
      "name" : "Amber Rae",
      "screen_name" : "heyamberrae",
      "protected" : false,
      "id_str" : "15019184",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2930327018/bec3c6e4216aafadcf5bb1dbb017fb83_normal.jpeg",
      "id" : 15019184,
      "verified" : false
    }
  },
  "id" : 251194090199326720,
  "created_at" : "Thu Sep 27 05:38:32 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luke Millar",
      "screen_name" : "luketmillar",
      "indices" : [ 0, 12 ],
      "id_str" : "927933800",
      "id" : 927933800
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "251155645083049985",
  "geo" : {
  },
  "id_str" : "251193944841535488",
  "in_reply_to_user_id" : 14616067,
  "text" : "@luketmillar Sweets and processed carbs, mostly.",
  "id" : 251193944841535488,
  "in_reply_to_status_id" : 251155645083049985,
  "created_at" : "Thu Sep 27 05:37:58 +0000 2012",
  "in_reply_to_screen_name" : "ltm",
  "in_reply_to_user_id_str" : "14616067",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Singer",
      "screen_name" : "singy",
      "indices" : [ 0, 6 ],
      "id_str" : "15310552",
      "id" : 15310552
    }, {
      "name" : "Chirpify",
      "screen_name" : "Chirpify",
      "indices" : [ 14, 23 ],
      "id_str" : "526548703",
      "id" : 526548703
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "251159275173470208",
  "geo" : {
  },
  "id_str" : "251193719628369920",
  "in_reply_to_user_id" : 15310552,
  "text" : "@singy Do it! @chirpify is sorta awesome and convenient for this purpose.",
  "id" : 251193719628369920,
  "in_reply_to_status_id" : 251159275173470208,
  "created_at" : "Thu Sep 27 05:37:04 +0000 2012",
  "in_reply_to_screen_name" : "singy",
  "in_reply_to_user_id_str" : "15310552",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 3, 13 ],
      "id_str" : "7362142",
      "id" : 7362142
    }, {
      "name" : "Anti-Buster",
      "screen_name" : "busterbenson",
      "indices" : [ 15, 28 ],
      "id_str" : "1024917050",
      "id" : 1024917050
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "251193466648936449",
  "text" : "RT @kellianne: @busterbenson I should collect dollars when you don't call your wife!",
  "retweeted_status" : {
    "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Anti-Buster",
        "screen_name" : "busterbenson",
        "indices" : [ 0, 13 ],
        "id_str" : "1024917050",
        "id" : 1024917050
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "251155221307326464",
    "geo" : {
    },
    "id_str" : "251172089233539072",
    "in_reply_to_user_id" : 2185,
    "text" : "@busterbenson I should collect dollars when you don't call your wife!",
    "id" : 251172089233539072,
    "in_reply_to_status_id" : 251155221307326464,
    "created_at" : "Thu Sep 27 04:11:07 +0000 2012",
    "in_reply_to_screen_name" : "buster",
    "in_reply_to_user_id_str" : "2185",
    "user" : {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "protected" : false,
      "id_str" : "7362142",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3058433557/056b99ecb9df9b6b9b382b2470b6ee82_normal.jpeg",
      "id" : 7362142,
      "verified" : false
    }
  },
  "id" : 251193466648936449,
  "created_at" : "Thu Sep 27 05:36:04 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagr.am\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jordy Mont-Reynaud",
      "screen_name" : "curiousjordy",
      "indices" : [ 21, 34 ],
      "id_str" : "1000",
      "id" : 1000
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 99 ],
      "url" : "http://t.co/EUAYIDnz",
      "expanded_url" : "http://instagr.am/p/QEJccwI0BZ/",
      "display_url" : "instagr.am/p/QEJccwI0BZ/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.777089, -122.421494 ]
  },
  "id_str" : "251171727537762304",
  "text" : "8:36pm I'm gonna owe @curiousjordy a ton by the end of this night  @ The Grove http://t.co/EUAYIDnz",
  "id" : 251171727537762304,
  "created_at" : "Thu Sep 27 04:09:41 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://bufferapp.com\" rel=\"nofollow\">Buffer</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 88 ],
      "url" : "http://t.co/hhC4enXB",
      "expanded_url" : "http://bit.ly/PmLlZ4",
      "display_url" : "bit.ly/PmLlZ4"
    } ]
  },
  "geo" : {
  },
  "id_str" : "251155221307326464",
  "text" : "If you see me eat junk food, or drink soda, I'll give you a dollar. http://t.co/hhC4enXB",
  "id" : 251155221307326464,
  "created_at" : "Thu Sep 27 03:04:05 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "251134740785147904",
  "text" : "Are wishes complaints?",
  "id" : 251134740785147904,
  "created_at" : "Thu Sep 27 01:42:42 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kav Latiolais",
      "screen_name" : "kavla",
      "indices" : [ 4, 10 ],
      "id_str" : "28838912",
      "id" : 28838912
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "251114811792957440",
  "geo" : {
  },
  "id_str" : "251115907793973248",
  "in_reply_to_user_id" : 28838912,
  "text" : "Pay @kavla $1 because I complained about not having access to envelopes with answers. Oops.",
  "id" : 251115907793973248,
  "in_reply_to_status_id" : 251114811792957440,
  "created_at" : "Thu Sep 27 00:27:52 +0000 2012",
  "in_reply_to_screen_name" : "kavla",
  "in_reply_to_user_id_str" : "28838912",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sara Mauskopf",
      "screen_name" : "sm",
      "indices" : [ 0, 3 ],
      "id_str" : "22273667",
      "id" : 22273667
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "251111955228672000",
  "geo" : {
  },
  "id_str" : "251112979230240768",
  "in_reply_to_user_id" : 22273667,
  "text" : "@sm Yeah, I'm on the 7th floor near Pipit and Prion. No desk number since I still commute from Seattle. Let's gossip.",
  "id" : 251112979230240768,
  "in_reply_to_status_id" : 251111955228672000,
  "created_at" : "Thu Sep 27 00:16:14 +0000 2012",
  "in_reply_to_screen_name" : "sm",
  "in_reply_to_user_id_str" : "22273667",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sammy Larbi",
      "screen_name" : "codeodor",
      "indices" : [ 0, 9 ],
      "id_str" : "7853992",
      "id" : 7853992
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "251109188447649792",
  "geo" : {
  },
  "id_str" : "251110162906099712",
  "in_reply_to_user_id" : 7853992,
  "text" : "@codeodor It does count! And someone already collected. :)",
  "id" : 251110162906099712,
  "in_reply_to_status_id" : 251109188447649792,
  "created_at" : "Thu Sep 27 00:05:02 +0000 2012",
  "in_reply_to_screen_name" : "codeodor",
  "in_reply_to_user_id_str" : "7853992",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sara Mauskopf",
      "screen_name" : "sm",
      "indices" : [ 0, 3 ],
      "id_str" : "22273667",
      "id" : 22273667
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "251109374259507200",
  "geo" : {
  },
  "id_str" : "251109877982830592",
  "in_reply_to_user_id" : 22273667,
  "text" : "@sm Yeah it's just a 1 month experiment... I have no idea how often I do it and thought this would be a fun way to find out. And lose money.",
  "id" : 251109877982830592,
  "in_reply_to_status_id" : 251109374259507200,
  "created_at" : "Thu Sep 27 00:03:54 +0000 2012",
  "in_reply_to_screen_name" : "sm",
  "in_reply_to_user_id_str" : "22273667",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "251109458887983104",
  "text" : "Who's hogging all the envelopes with the answers inside?",
  "id" : 251109458887983104,
  "created_at" : "Thu Sep 27 00:02:15 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://bufferapp.com\" rel=\"nofollow\">Buffer</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 122 ],
      "url" : "http://t.co/hhC4enXB",
      "expanded_url" : "http://bit.ly/PmLlZ4",
      "display_url" : "bit.ly/PmLlZ4"
    } ]
  },
  "geo" : {
  },
  "id_str" : "251107673976745985",
  "text" : "If you hear me speak negatively behind someone's back, and you call me on it, I'll give you a dollar. http://t.co/hhC4enXB",
  "id" : 251107673976745985,
  "created_at" : "Wed Sep 26 23:55:09 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrei Pop",
      "screen_name" : "andreimpop",
      "indices" : [ 0, 11 ],
      "id_str" : "82801305",
      "id" : 82801305
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "251031906412535809",
  "geo" : {
  },
  "id_str" : "251055291960029187",
  "in_reply_to_user_id" : 82801305,
  "text" : "@andreimpop Sorry, I never check my LinkedIn mail. My life is a bit crazy for the next few months... where do you live?",
  "id" : 251055291960029187,
  "in_reply_to_status_id" : 251031906412535809,
  "created_at" : "Wed Sep 26 20:27:00 +0000 2012",
  "in_reply_to_screen_name" : "andreimpop",
  "in_reply_to_user_id_str" : "82801305",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sarah kathleen peck",
      "screen_name" : "sarahkpeck",
      "indices" : [ 0, 11 ],
      "id_str" : "196745496",
      "id" : 196745496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "251035229328904193",
  "geo" : {
  },
  "id_str" : "251054973020942336",
  "in_reply_to_user_id" : 196745496,
  "text" : "@sarahkpeck Yeah, I meant complaint in the context of whining. Complaining about something without any effort to change it.",
  "id" : 251054973020942336,
  "in_reply_to_status_id" : 251035229328904193,
  "created_at" : "Wed Sep 26 20:25:44 +0000 2012",
  "in_reply_to_screen_name" : "sarahkpeck",
  "in_reply_to_user_id_str" : "196745496",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://bufferapp.com\" rel=\"nofollow\">Buffer</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 107 ],
      "url" : "http://t.co/hhC4enXB",
      "expanded_url" : "http://bit.ly/PmLlZ4",
      "display_url" : "bit.ly/PmLlZ4"
    } ]
  },
  "geo" : {
  },
  "id_str" : "251034729497886720",
  "text" : "If you hear me complain about anything, and call me out on it, I'll give you a dollar. http://t.co/hhC4enXB",
  "id" : 251034729497886720,
  "created_at" : "Wed Sep 26 19:05:18 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Wolfson",
      "screen_name" : "awolfson0",
      "indices" : [ 0, 10 ],
      "id_str" : "19576161",
      "id" : 19576161
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "251023028664803328",
  "geo" : {
  },
  "id_str" : "251025239163678720",
  "in_reply_to_user_id" : 19576161,
  "text" : "@awolfson0 Was it falsifiable before? I sort of came to this conclusion because I couldn't find any truly intrinsic motivators.",
  "id" : 251025239163678720,
  "in_reply_to_status_id" : 251023028664803328,
  "created_at" : "Wed Sep 26 18:27:35 +0000 2012",
  "in_reply_to_screen_name" : "awolfson0",
  "in_reply_to_user_id_str" : "19576161",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brennan Novak",
      "screen_name" : "brennannovak",
      "indices" : [ 0, 13 ],
      "id_str" : "17958179",
      "id" : 17958179
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "251005683800092672",
  "geo" : {
  },
  "id_str" : "251007019245527040",
  "in_reply_to_user_id" : 17958179,
  "text" : "@brennannovak Yeah, I have! It's so easy to use that I can't believe it's accurate. I like the passive nature of the ring though.",
  "id" : 251007019245527040,
  "in_reply_to_status_id" : 251005683800092672,
  "created_at" : "Wed Sep 26 17:15:11 +0000 2012",
  "in_reply_to_screen_name" : "brennannovak",
  "in_reply_to_user_id_str" : "17958179",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "251002885423382530",
  "text" : "New hunch: all motivation is extrinsic. Our identities are wrapped up in each other and can't be fully teased apart.",
  "id" : 251002885423382530,
  "created_at" : "Wed Sep 26 16:58:45 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "that drew",
      "screen_name" : "thatdrew",
      "indices" : [ 0, 9 ],
      "id_str" : "1002913782",
      "id" : 1002913782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "250987029263949824",
  "geo" : {
  },
  "id_str" : "250987658979979265",
  "in_reply_to_user_id" : 10221,
  "text" : "@thatdrew Let me know where you are and I'll come say hi.",
  "id" : 250987658979979265,
  "in_reply_to_status_id" : 250987029263949824,
  "created_at" : "Wed Sep 26 15:58:15 +0000 2012",
  "in_reply_to_screen_name" : "drew",
  "in_reply_to_user_id_str" : "10221",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "that drew",
      "screen_name" : "thatdrew",
      "indices" : [ 0, 9 ],
      "id_str" : "1002913782",
      "id" : 1002913782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "250986132463046656",
  "geo" : {
  },
  "id_str" : "250986680176234497",
  "in_reply_to_user_id" : 10221,
  "text" : "@thatdrew Yup. Are you coming by?",
  "id" : 250986680176234497,
  "in_reply_to_status_id" : 250986132463046656,
  "created_at" : "Wed Sep 26 15:54:22 +0000 2012",
  "in_reply_to_screen_name" : "drew",
  "in_reply_to_user_id_str" : "10221",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://bufferapp.com\" rel=\"nofollow\">Buffer</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 56 ],
      "url" : "http://t.co/hhC4enXB",
      "expanded_url" : "http://bit.ly/PmLlZ4",
      "display_url" : "bit.ly/PmLlZ4"
    } ]
  },
  "geo" : {
  },
  "id_str" : "250985890216816640",
  "text" : "\"$1 behavior change self-challenge\" http://t.co/hhC4enXB",
  "id" : 250985890216816640,
  "created_at" : "Wed Sep 26 15:51:13 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marci Ikeler",
      "screen_name" : "marciikeler",
      "indices" : [ 16, 28 ],
      "id_str" : "1627381",
      "id" : 1627381
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http://t.co/FTBTEzJA",
      "expanded_url" : "http://ow.ly/dZz8o",
      "display_url" : "ow.ly/dZz8o"
    } ]
  },
  "geo" : {
  },
  "id_str" : "250979375808393217",
  "text" : "I need this! RT @marciikeler: Pulse is a prototype ring that keeps track of your heart rate and syncs with your iPhone. http://t.co/FTBTEzJA",
  "id" : 250979375808393217,
  "created_at" : "Wed Sep 26 15:25:20 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ashley",
      "screen_name" : "spratlas",
      "indices" : [ 0, 9 ],
      "id_str" : "822724",
      "id" : 822724
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "250960622760628225",
  "geo" : {
  },
  "id_str" : "250962092935499777",
  "in_reply_to_user_id" : 822724,
  "text" : "@spratlas Thank you! Which ones have you used / found helpful?",
  "id" : 250962092935499777,
  "in_reply_to_status_id" : 250960622760628225,
  "created_at" : "Wed Sep 26 14:16:40 +0000 2012",
  "in_reply_to_screen_name" : "spratlas",
  "in_reply_to_user_id_str" : "822724",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Calvin Spealman",
      "screen_name" : "ironfroggy",
      "indices" : [ 0, 11 ],
      "id_str" : "5622042",
      "id" : 5622042
    }, {
      "name" : "Michael Owens",
      "screen_name" : "mko",
      "indices" : [ 17, 21 ],
      "id_str" : "11822502",
      "id" : 11822502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "250921316033646593",
  "geo" : {
  },
  "id_str" : "250957574625697792",
  "in_reply_to_user_id" : 5622042,
  "text" : "@ironfroggy Yup. @mko spotted that one and has been paid. :)",
  "id" : 250957574625697792,
  "in_reply_to_status_id" : 250921316033646593,
  "created_at" : "Wed Sep 26 13:58:43 +0000 2012",
  "in_reply_to_screen_name" : "ironfroggy",
  "in_reply_to_user_id_str" : "5622042",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rym",
      "screen_name" : "schezar",
      "indices" : [ 0, 8 ],
      "id_str" : "16435523",
      "id" : 16435523
    }, {
      "name" : "Mark Bittman",
      "screen_name" : "bittman",
      "indices" : [ 9, 17 ],
      "id_str" : "20778387",
      "id" : 20778387
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "250880124931694592",
  "geo" : {
  },
  "id_str" : "250957399240871936",
  "in_reply_to_user_id" : 16435523,
  "text" : "@schezar @bittman I'd love to see more evidence on either side... let me know if you find any.",
  "id" : 250957399240871936,
  "in_reply_to_status_id" : 250880124931694592,
  "created_at" : "Wed Sep 26 13:58:01 +0000 2012",
  "in_reply_to_screen_name" : "schezar",
  "in_reply_to_user_id_str" : "16435523",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Owen Williams",
      "screen_name" : "findingnewo",
      "indices" : [ 0, 12 ],
      "id_str" : "14767730",
      "id" : 14767730
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "250872696156606465",
  "geo" : {
  },
  "id_str" : "250957132260835328",
  "in_reply_to_user_id" : 14767730,
  "text" : "@findingnewo Awesome! If you write anything up about it (now or later) let me know!",
  "id" : 250957132260835328,
  "in_reply_to_status_id" : 250872696156606465,
  "created_at" : "Wed Sep 26 13:56:57 +0000 2012",
  "in_reply_to_screen_name" : "findingnewo",
  "in_reply_to_user_id_str" : "14767730",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"https://chirpify.com\" rel=\"nofollow\">Chirpify</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Owens",
      "screen_name" : "mko",
      "indices" : [ 4, 8 ],
      "id_str" : "11822502",
      "id" : 11822502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "250867405285371904",
  "text" : "Pay @mko $1 for noticing that I complained about complaining being stupid.",
  "id" : 250867405285371904,
  "created_at" : "Wed Sep 26 08:00:24 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Omid Ashtari",
      "screen_name" : "omid",
      "indices" : [ 0, 5 ],
      "id_str" : "114971521",
      "id" : 114971521
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "250864482954383360",
  "geo" : {
  },
  "id_str" : "250865774313484288",
  "in_reply_to_user_id" : 114971521,
  "text" : "@omid 7th floor near the arch of the foot if the floor plan was a foot. Hadn't considered that people might start baiting me...",
  "id" : 250865774313484288,
  "in_reply_to_status_id" : 250864482954383360,
  "created_at" : "Wed Sep 26 07:53:56 +0000 2012",
  "in_reply_to_screen_name" : "omid",
  "in_reply_to_user_id_str" : "114971521",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jane McGonigal",
      "screen_name" : "avantgame",
      "indices" : [ 0, 10 ],
      "id_str" : "681813",
      "id" : 681813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "250855695749095424",
  "geo" : {
  },
  "id_str" : "250861517476605952",
  "in_reply_to_user_id" : 681813,
  "text" : "@avantgame I know, right? Even if it's not 100% right, the correlation alone is rather scary. Diet-related health costs just doubled!",
  "id" : 250861517476605952,
  "in_reply_to_status_id" : 250855695749095424,
  "created_at" : "Wed Sep 26 07:37:01 +0000 2012",
  "in_reply_to_screen_name" : "avantgame",
  "in_reply_to_user_id_str" : "681813",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://bufferapp.com\" rel=\"nofollow\">Buffer</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http://t.co/hhC4enXB",
      "expanded_url" : "http://bit.ly/PmLlZ4",
      "display_url" : "bit.ly/PmLlZ4"
    } ]
  },
  "geo" : {
  },
  "id_str" : "250860286616141825",
  "text" : "A new behavior-change test for myself: http://t.co/hhC4enXB",
  "id" : 250860286616141825,
  "created_at" : "Wed Sep 26 07:32:07 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Bittman",
      "screen_name" : "bittman",
      "indices" : [ 57, 65 ],
      "id_str" : "20778387",
      "id" : 20778387
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 52 ],
      "url" : "http://t.co/LufxOc4d",
      "expanded_url" : "http://opinionator.blogs.nytimes.com/2012/09/25/bittman-is-alzheimers-type-3-diabetes/?smid=tw-share",
      "display_url" : "opinionator.blogs.nytimes.com/2012/09/25/bit…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "250835037300355072",
  "text" : "Is Alzheimer's Type 3 Diabetes? http://t.co/LufxOc4d /by @bittman Great summary of the theory, which seems plausible.",
  "id" : 250835037300355072,
  "created_at" : "Wed Sep 26 05:51:47 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Freitas",
      "screen_name" : "ryanchris",
      "indices" : [ 0, 10 ],
      "id_str" : "13349",
      "id" : 13349
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "halfjoking",
      "indices" : [ 126, 137 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "250820187295715328",
  "geo" : {
  },
  "id_str" : "250821455871369217",
  "in_reply_to_user_id" : 13349,
  "text" : "@ryanchris Do we build memes (and set their turnarounds) or are memes just becoming more efficient at reproducing through us? #halfjoking",
  "id" : 250821455871369217,
  "in_reply_to_status_id" : 250820187295715328,
  "created_at" : "Wed Sep 26 04:57:49 +0000 2012",
  "in_reply_to_screen_name" : "ryanchris",
  "in_reply_to_user_id_str" : "13349",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Freitas",
      "screen_name" : "ryanchris",
      "indices" : [ 0, 10 ],
      "id_str" : "13349",
      "id" : 13349
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "250818108783218688",
  "geo" : {
  },
  "id_str" : "250819817693646848",
  "in_reply_to_user_id" : 13349,
  "text" : "@ryanchris The older we are, the longer we can remember memes living.",
  "id" : 250819817693646848,
  "in_reply_to_status_id" : 250818108783218688,
  "created_at" : "Wed Sep 26 04:51:19 +0000 2012",
  "in_reply_to_screen_name" : "ryanchris",
  "in_reply_to_user_id_str" : "13349",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harper",
      "screen_name" : "harper",
      "indices" : [ 0, 7 ],
      "id_str" : "1497",
      "id" : 1497
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "250788126446977024",
  "geo" : {
  },
  "id_str" : "250811383267074048",
  "in_reply_to_user_id" : 1497,
  "text" : "@harper Who is this Evan Miller fellow? I'm blown away by Wizard and would love to learn more about it.",
  "id" : 250811383267074048,
  "in_reply_to_status_id" : 250788126446977024,
  "created_at" : "Wed Sep 26 04:17:48 +0000 2012",
  "in_reply_to_screen_name" : "harper",
  "in_reply_to_user_id_str" : "1497",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "quantifiedself",
      "indices" : [ 14, 29 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 128 ],
      "url" : "http://t.co/QSDeuBzo",
      "expanded_url" : "http://wizard.evanmiller.org/",
      "display_url" : "wizard.evanmiller.org"
    } ]
  },
  "geo" : {
  },
  "id_str" : "250810350625247232",
  "text" : "Attention all #quantifiedself-ers: your prayers have been answered. Rev up your self-tracking spreadsheets! http://t.co/QSDeuBzo",
  "id" : 250810350625247232,
  "created_at" : "Wed Sep 26 04:13:42 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 86 ],
      "url" : "http://t.co/MHmtz9Ed",
      "expanded_url" : "http://flic.kr/p/debyM5",
      "display_url" : "flic.kr/p/debyM5"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7795, -122.416834 ]
  },
  "id_str" : "250802674247819265",
  "text" : "8:36pm Thinking about ideas, ideating about thoughts, you know... http://t.co/MHmtz9Ed",
  "id" : 250802674247819265,
  "created_at" : "Wed Sep 26 03:43:11 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harper",
      "screen_name" : "harper",
      "indices" : [ 13, 20 ],
      "id_str" : "1497",
      "id" : 1497
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 139 ],
      "url" : "http://t.co/OdhJ4r7a",
      "expanded_url" : "http://gg.ly/QwAYoo",
      "display_url" : "gg.ly/QwAYoo"
    } ]
  },
  "geo" : {
  },
  "id_str" : "250793274854494208",
  "text" : "Ooh neat! RT @harper: Awesome new easy-to-use tool for statistics and data analysis from Evan Miller - Wizard for Mac: http://t.co/OdhJ4r7a",
  "id" : 250793274854494208,
  "created_at" : "Wed Sep 26 03:05:50 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Wolf",
      "screen_name" : "agaricus",
      "indices" : [ 0, 9 ],
      "id_str" : "21678279",
      "id" : 21678279
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "250762847943008257",
  "geo" : {
  },
  "id_str" : "250763397644304385",
  "in_reply_to_user_id" : 21678279,
  "text" : "@agaricus Interesting. I'll find out if that's available. What would you do with this data if you knew it?",
  "id" : 250763397644304385,
  "in_reply_to_status_id" : 250762847943008257,
  "created_at" : "Wed Sep 26 01:07:07 +0000 2012",
  "in_reply_to_screen_name" : "agaricus",
  "in_reply_to_user_id_str" : "21678279",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 95 ],
      "url" : "http://t.co/MPjMdqFw",
      "expanded_url" : "http://bustr.me/post/32298659097/when-youre-habituated-to-constant-stimulation",
      "display_url" : "bustr.me/post/322986590…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "250762337223602177",
  "text" : "\"Oh my god, I should be doing something.\" And we reach for the smartphone. http://t.co/MPjMdqFw",
  "id" : 250762337223602177,
  "created_at" : "Wed Sep 26 01:02:54 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Minbox",
      "screen_name" : "minboxco",
      "indices" : [ 0, 9 ],
      "id_str" : "499069217",
      "id" : 499069217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "250735507783421952",
  "in_reply_to_user_id" : 499069217,
  "text" : "@minboxco I'm dying. Let me in! :)",
  "id" : 250735507783421952,
  "created_at" : "Tue Sep 25 23:16:18 +0000 2012",
  "in_reply_to_screen_name" : "minboxco",
  "in_reply_to_user_id_str" : "499069217",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shrutarshi Basu",
      "screen_name" : "basus",
      "indices" : [ 0, 6 ],
      "id_str" : "9469312",
      "id" : 9469312
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "250731798718451712",
  "geo" : {
  },
  "id_str" : "250732841208541185",
  "in_reply_to_user_id" : 9469312,
  "text" : "@basus Oh yeah, I totally understand the emotions behind it.",
  "id" : 250732841208541185,
  "in_reply_to_status_id" : 250731798718451712,
  "created_at" : "Tue Sep 25 23:05:42 +0000 2012",
  "in_reply_to_screen_name" : "basus",
  "in_reply_to_user_id_str" : "9469312",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Cottrell",
      "screen_name" : "rgcottrell",
      "indices" : [ 0, 11 ],
      "id_str" : "752553",
      "id" : 752553
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "250731733341831168",
  "geo" : {
  },
  "id_str" : "250732465528909825",
  "in_reply_to_user_id" : 752553,
  "text" : "@rgcottrell I think Tweetbot has that market cornered.",
  "id" : 250732465528909825,
  "in_reply_to_status_id" : 250731733341831168,
  "created_at" : "Tue Sep 25 23:04:12 +0000 2012",
  "in_reply_to_screen_name" : "rgcottrell",
  "in_reply_to_user_id_str" : "752553",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shrutarshi Basu",
      "screen_name" : "basus",
      "indices" : [ 0, 6 ],
      "id_str" : "9469312",
      "id" : 9469312
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 133 ],
      "url" : "http://t.co/2qsybcv9",
      "expanded_url" : "http://dashes.com/anil/2012/09/what-developers-want.html",
      "display_url" : "dashes.com/anil/2012/09/w…"
    } ]
  },
  "in_reply_to_status_id_str" : "250717539628363776",
  "geo" : {
  },
  "id_str" : "250720048073809920",
  "in_reply_to_user_id" : 9469312,
  "text" : "@basus I disagree with your assumption, but also work at Twitter now and hope to help win people back. See also: http://t.co/2qsybcv9",
  "id" : 250720048073809920,
  "in_reply_to_status_id" : 250717539628363776,
  "created_at" : "Tue Sep 25 22:14:52 +0000 2012",
  "in_reply_to_screen_name" : "basus",
  "in_reply_to_user_id_str" : "9469312",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "twitterhackweek",
      "indices" : [ 42, 58 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "250715556100063232",
  "text" : "Trying to think of something to build for #twitterhackweek next week. Any ideas?",
  "id" : 250715556100063232,
  "created_at" : "Tue Sep 25 21:57:01 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anil Dash",
      "screen_name" : "anildash",
      "indices" : [ 46, 55 ],
      "id_str" : "36823",
      "id" : 36823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 41 ],
      "url" : "http://t.co/2qsybcv9",
      "expanded_url" : "http://dashes.com/anil/2012/09/what-developers-want.html",
      "display_url" : "dashes.com/anil/2012/09/w…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "250647558957961216",
  "text" : "What Developers Want http://t.co/2qsybcv9 /by @anildash",
  "id" : 250647558957961216,
  "created_at" : "Tue Sep 25 17:26:49 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anil Dash",
      "screen_name" : "anildash",
      "indices" : [ 3, 12 ],
      "id_str" : "36823",
      "id" : 36823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "250646878125953024",
  "text" : "RT @anildash: Real bloggers blog.",
  "retweeted_status" : {
    "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "250627458481659904",
    "text" : "Real bloggers blog.",
    "id" : 250627458481659904,
    "created_at" : "Tue Sep 25 16:06:57 +0000 2012",
    "user" : {
      "name" : "Anil Dash",
      "screen_name" : "anildash",
      "protected" : false,
      "id_str" : "36823",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2819125443/08240a3283301594794bcf6333ce8e6f_normal.png",
      "id" : 36823,
      "verified" : true
    }
  },
  "id" : 250646878125953024,
  "created_at" : "Tue Sep 25 17:24:07 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "250476063065518080",
  "text" : "&lt;%= ideas %&gt;",
  "id" : 250476063065518080,
  "created_at" : "Tue Sep 25 06:05:21 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagr.am\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Ward",
      "screen_name" : "BenWard",
      "indices" : [ 27, 35 ],
      "id_str" : "12249",
      "id" : 12249
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 95 ],
      "url" : "http://t.co/PmghWtIm",
      "expanded_url" : "http://instagr.am/p/P-8Z5mI0Me/",
      "display_url" : "instagr.am/p/P-8Z5mI0Me/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7770876072, -122.41689812 ]
  },
  "id_str" : "250439425316761601",
  "text" : "8:36pm Conceding defeat to @benward for last man standing  @ Twitter, Inc. http://t.co/PmghWtIm",
  "id" : 250439425316761601,
  "created_at" : "Tue Sep 25 03:39:46 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Britt Selvitelle",
      "screen_name" : "bs",
      "indices" : [ 0, 3 ],
      "id_str" : "309073",
      "id" : 309073
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "250273480438870016",
  "in_reply_to_user_id" : 309073,
  "text" : "@bs Just learned about brittspace. Well done. :) PS. I'm in SF this week... wanna get a drink?",
  "id" : 250273480438870016,
  "created_at" : "Mon Sep 24 16:40:22 +0000 2012",
  "in_reply_to_screen_name" : "bs",
  "in_reply_to_user_id_str" : "309073",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "250217061354196992",
  "text" : "Excited to see Eric Vadon commuting to SF from Seattle on my flight too. Renaming it the ex-Amazon TPM shuttle.",
  "id" : 250217061354196992,
  "created_at" : "Mon Sep 24 12:56:10 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "250216110304157696",
  "text" : "Though, what happens when 50 million years from now it's impossible to find a quartz glass sliver reader anywhere?",
  "id" : 250216110304157696,
  "created_at" : "Mon Sep 24 12:52:24 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 123 ],
      "url" : "http://t.co/y6riKw3r",
      "expanded_url" : "http://phys.org/news/2012-09-japan-hitachi.html",
      "display_url" : "phys.org/news/2012-09-j…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "250215778970902529",
  "text" : "Need your data to last 100 million years? Slivers of quartz glass may be your preferred backup choice. http://t.co/y6riKw3r",
  "id" : 250215778970902529,
  "created_at" : "Mon Sep 24 12:51:05 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kotaku",
      "screen_name" : "Kotaku",
      "indices" : [ 3, 10 ],
      "id_str" : "11928542",
      "id" : 11928542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 103 ],
      "url" : "http://t.co/e2IeTQkx",
      "expanded_url" : "http://bit.ly/QP30Jk",
      "display_url" : "bit.ly/QP30Jk"
    } ]
  },
  "geo" : {
  },
  "id_str" : "250205618437238784",
  "text" : "RT @Kotaku: The Factory That Makes The iPhone 5 Is Under Attack by Its Own Workers http://t.co/e2IeTQkx",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.socialflow.com\" rel=\"nofollow\">SocialFlow</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 71, 91 ],
        "url" : "http://t.co/e2IeTQkx",
        "expanded_url" : "http://bit.ly/QP30Jk",
        "display_url" : "bit.ly/QP30Jk"
      } ]
    },
    "geo" : {
    },
    "id_str" : "250183882744414209",
    "text" : "The Factory That Makes The iPhone 5 Is Under Attack by Its Own Workers http://t.co/e2IeTQkx",
    "id" : 250183882744414209,
    "created_at" : "Mon Sep 24 10:44:20 +0000 2012",
    "user" : {
      "name" : "Kotaku",
      "screen_name" : "Kotaku",
      "protected" : false,
      "id_str" : "11928542",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2976435509/5bf6f7a63b4628faf59928ff4ca911f3_normal.jpeg",
      "id" : 11928542,
      "verified" : true
    }
  },
  "id" : 250205618437238784,
  "created_at" : "Mon Sep 24 12:10:42 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Ford",
      "screen_name" : "ftrain",
      "indices" : [ 3, 10 ],
      "id_str" : "6981492",
      "id" : 6981492
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "250204900326268929",
  "text" : "RT @ftrain: Who will speak for the brands?",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "250200607166717952",
    "text" : "Who will speak for the brands?",
    "id" : 250200607166717952,
    "created_at" : "Mon Sep 24 11:50:47 +0000 2012",
    "user" : {
      "name" : "Paul Ford",
      "screen_name" : "ftrain",
      "protected" : false,
      "id_str" : "6981492",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3011615576/526cb024f6d50ed582f687565cbadd84_normal.png",
      "id" : 6981492,
      "verified" : false
    }
  },
  "id" : 250204900326268929,
  "created_at" : "Mon Sep 24 12:07:51 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 128 ],
      "url" : "http://t.co/x8VDrI1v",
      "expanded_url" : "http://4sq.com/Q0PEZw",
      "display_url" : "4sq.com/Q0PEZw"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.4436465828, -122.3025941849 ]
  },
  "id_str" : "250198599177207809",
  "text" : "Seattle -&gt; San Francisco for the whole week! (@ Seattle-Tacoma International Airport (SEA) w/ 10 others) http://t.co/x8VDrI1v",
  "id" : 250198599177207809,
  "created_at" : "Mon Sep 24 11:42:49 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 57 ],
      "url" : "http://t.co/VRp7KGeS",
      "expanded_url" : "http://flic.kr/p/ddy8f2",
      "display_url" : "flic.kr/p/ddy8f2"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.608666, -122.306 ]
  },
  "id_str" : "250079412685512705",
  "text" : "8:36pm Bath time pouring experiments http://t.co/VRp7KGeS",
  "id" : 250079412685512705,
  "created_at" : "Mon Sep 24 03:49:12 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "250072634715422720",
  "text" : "I only have 1929142 points.",
  "id" : 250072634715422720,
  "created_at" : "Mon Sep 24 03:22:16 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagr.am\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Instagram",
      "screen_name" : "instagram",
      "indices" : [ 20, 30 ],
      "id_str" : "180505807",
      "id" : 180505807
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 116 ],
      "url" : "http://t.co/Enmdy1R6",
      "expanded_url" : "http://instagr.am/p/Cy6f/",
      "display_url" : "instagr.am/p/Cy6f/"
    } ]
  },
  "geo" : {
  },
  "id_str" : "250034800738574336",
  "text" : "What was your first @instagram photo? I've been doing exclusive Niko photos from the beginning: http://t.co/Enmdy1R6",
  "id" : 250034800738574336,
  "created_at" : "Mon Sep 24 00:51:56 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagr.am\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "donttryathome",
      "indices" : [ 22, 36 ]
    } ],
    "urls" : [ {
      "indices" : [ 37, 57 ],
      "url" : "http://t.co/Lo4PTqd9",
      "expanded_url" : "http://instagr.am/p/P8DPfMI0Do/",
      "display_url" : "instagr.am/p/P8DPfMI0Do/"
    } ]
  },
  "geo" : {
  },
  "id_str" : "250032264124170241",
  "text" : "Pancaking and driving #donttryathome http://t.co/Lo4PTqd9",
  "id" : 250032264124170241,
  "created_at" : "Mon Sep 24 00:41:51 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keenan Cummings",
      "screen_name" : "KeenanCummings",
      "indices" : [ 108, 123 ],
      "id_str" : "29252102",
      "id" : 29252102
    }, {
      "name" : "Michael S Galpert",
      "screen_name" : "msg",
      "indices" : [ 129, 133 ],
      "id_str" : "937961",
      "id" : 937961
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "250002458011639809",
  "text" : "\"A history and future of formats: mind ➡ voice ➡ tablet ➡ scroll ➡ book ➡ scroll ➡ tablet ➡ voice ➡ mind\" - @KeenanCummings /via @msg",
  "id" : 250002458011639809,
  "created_at" : "Sun Sep 23 22:43:25 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Waxy.org Links Feed",
      "screen_name" : "waxylinks",
      "indices" : [ 3, 13 ],
      "id_str" : "219952089",
      "id" : 219952089
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "249976016825618433",
  "text" : "RT @waxylinks: We Are Legion: The Story of the Hacktivists: full-length documentary on the history of Anonymous and net-based h... http: ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitterfeed.com\" rel=\"nofollow\">twitterfeed</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 136 ],
        "url" : "http://t.co/URlnPWnO",
        "expanded_url" : "http://bit.ly/PYj5eB",
        "display_url" : "bit.ly/PYj5eB"
      } ]
    },
    "geo" : {
    },
    "id_str" : "249972587642380288",
    "text" : "We Are Legion: The Story of the Hacktivists: full-length documentary on the history of Anonymous and net-based h... http://t.co/URlnPWnO",
    "id" : 249972587642380288,
    "created_at" : "Sun Sep 23 20:44:43 +0000 2012",
    "user" : {
      "name" : "Waxy.org Links Feed",
      "screen_name" : "waxylinks",
      "protected" : false,
      "id_str" : "219952089",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1175952227/Screen_shot_2010-11-26_at_11.48.43_normal.png",
      "id" : 219952089,
      "verified" : false
    }
  },
  "id" : 249976016825618433,
  "created_at" : "Sun Sep 23 20:58:21 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Davis",
      "screen_name" : "kgdavis",
      "indices" : [ 0, 8 ],
      "id_str" : "14416035",
      "id" : 14416035
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "249958892719730688",
  "geo" : {
  },
  "id_str" : "249960484101554176",
  "in_reply_to_user_id" : 14416035,
  "text" : "@kgdavis Woah you're right. And I'm an idiot! Thank you.",
  "id" : 249960484101554176,
  "in_reply_to_status_id" : 249958892719730688,
  "created_at" : "Sun Sep 23 19:56:38 +0000 2012",
  "in_reply_to_screen_name" : "kgdavis",
  "in_reply_to_user_id_str" : "14416035",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "249959754250727425",
  "text" : "I wonder if Spaghetti Factory salads have any nutritional value at all.",
  "id" : 249959754250727425,
  "created_at" : "Sun Sep 23 19:53:44 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "249929481018544128",
  "text" : "Is there really any advantage to forgetting our mortality for any amount of time? Happy Sunday!",
  "id" : 249929481018544128,
  "created_at" : "Sun Sep 23 17:53:26 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amit superamit Gupta",
      "screen_name" : "superamit",
      "indices" : [ 78, 88 ],
      "id_str" : "10609",
      "id" : 10609
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "249928955304488960",
  "text" : "I wish I could more completely experience the urgency and beauty of life that @superamit must feel now. Minus the terrible leukemia part.",
  "id" : 249928955304488960,
  "created_at" : "Sun Sep 23 17:51:21 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amit superamit Gupta",
      "screen_name" : "superamit",
      "indices" : [ 13, 23 ],
      "id_str" : "10609",
      "id" : 10609
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http://t.co/pcPa6CHs",
      "expanded_url" : "http://tumblr.amitgupta.com/post/32074225382/one-year-ago",
      "display_url" : "tumblr.amitgupta.com/post/320742253…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "249923436141506561",
  "text" : "One year ago @superamit was diagnosed. I heard from someone at one of our drives that became a match for someone too. http://t.co/pcPa6CHs",
  "id" : 249923436141506561,
  "created_at" : "Sun Sep 23 17:29:25 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicholas Carlson",
      "screen_name" : "nichcarlson",
      "indices" : [ 3, 15 ],
      "id_str" : "9549942",
      "id" : 9549942
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 112 ],
      "url" : "http://t.co/Vd6E8KPj",
      "expanded_url" : "http://twitter.com/nichcarlson/status/249861921015222272/photo/1",
      "display_url" : "pic.twitter.com/Vd6E8KPj"
    } ]
  },
  "geo" : {
  },
  "id_str" : "249867580171513857",
  "text" : "RT @nichcarlson: Remember what Twitter used to look like on your iPhone? This is from 2009. http://t.co/Vd6E8KPj",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.apple.com\" rel=\"nofollow\">Photos on iOS</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http://twitter.com/nichcarlson/status/249861921015222272/photo/1",
        "indices" : [ 75, 95 ],
        "url" : "http://t.co/Vd6E8KPj",
        "media_url" : "http://pbs.twimg.com/media/A3ewF-dCUAADvzI.png",
        "id_str" : "249861921052971008",
        "id" : 249861921052971008,
        "media_url_https" : "https://pbs.twimg.com/media/A3ewF-dCUAADvzI.png",
        "sizes" : [ {
          "h" : 480,
          "resize" : "fit",
          "w" : 320
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 320
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 320
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 320
        } ],
        "display_url" : "pic.twitter.com/Vd6E8KPj"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "249861921015222272",
    "text" : "Remember what Twitter used to look like on your iPhone? This is from 2009. http://t.co/Vd6E8KPj",
    "id" : 249861921015222272,
    "created_at" : "Sun Sep 23 13:24:59 +0000 2012",
    "user" : {
      "name" : "Nicholas Carlson",
      "screen_name" : "nichcarlson",
      "protected" : false,
      "id_str" : "9549942",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3054676909/735f44fecffcd4230cc430bf38933296_normal.jpeg",
      "id" : 9549942,
      "verified" : false
    }
  },
  "id" : 249867580171513857,
  "created_at" : "Sun Sep 23 13:47:28 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Deterding",
      "screen_name" : "dingstweets",
      "indices" : [ 3, 15 ],
      "id_str" : "14435477",
      "id" : 14435477
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "quantifiedself",
      "indices" : [ 64, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 101 ],
      "url" : "http://t.co/FLdMRi6n",
      "expanded_url" : "http://j.mp/QswgrM",
      "display_url" : "j.mp/QswgrM"
    } ]
  },
  "geo" : {
  },
  "id_str" : "249867309433380865",
  "text" : "RT @dingstweets: Is mindfulness the most important benefit of a #quantifiedself? http://t.co/FLdMRi6n",
  "retweeted_status" : {
    "source" : "<a href=\"http://bitly.com\" rel=\"nofollow\">bitly</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "quantifiedself",
        "indices" : [ 47, 62 ]
      } ],
      "urls" : [ {
        "indices" : [ 64, 84 ],
        "url" : "http://t.co/FLdMRi6n",
        "expanded_url" : "http://j.mp/QswgrM",
        "display_url" : "j.mp/QswgrM"
      } ]
    },
    "geo" : {
    },
    "id_str" : "249848403826204672",
    "text" : "Is mindfulness the most important benefit of a #quantifiedself? http://t.co/FLdMRi6n",
    "id" : 249848403826204672,
    "created_at" : "Sun Sep 23 12:31:16 +0000 2012",
    "user" : {
      "name" : "Sebastian Deterding",
      "screen_name" : "dingstweets",
      "protected" : false,
      "id_str" : "14435477",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/279099712/GMDH02_00721_normal.png",
      "id" : 14435477,
      "verified" : false
    }
  },
  "id" : 249867309433380865,
  "created_at" : "Sun Sep 23 13:46:23 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Silas",
      "screen_name" : "matty8r",
      "indices" : [ 0, 8 ],
      "id_str" : "1657191",
      "id" : 1657191
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "249721994831081472",
  "geo" : {
  },
  "id_str" : "249724982769373184",
  "in_reply_to_user_id" : 1657191,
  "text" : "@matty8r That is certainly true!",
  "id" : 249724982769373184,
  "in_reply_to_status_id" : 249721994831081472,
  "created_at" : "Sun Sep 23 04:20:50 +0000 2012",
  "in_reply_to_screen_name" : "matty8r",
  "in_reply_to_user_id_str" : "1657191",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Silas",
      "screen_name" : "matty8r",
      "indices" : [ 0, 8 ],
      "id_str" : "1657191",
      "id" : 1657191
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "249715088209104896",
  "geo" : {
  },
  "id_str" : "249721308882034688",
  "in_reply_to_user_id" : 1657191,
  "text" : "@matty8r Not sure really. Just self-correct whenever documenting starts to detract from enjoying the moment.",
  "id" : 249721308882034688,
  "in_reply_to_status_id" : 249715088209104896,
  "created_at" : "Sun Sep 23 04:06:14 +0000 2012",
  "in_reply_to_screen_name" : "matty8r",
  "in_reply_to_user_id_str" : "1657191",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagr.am\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 85 ],
      "url" : "http://t.co/g5XEope7",
      "expanded_url" : "http://instagr.am/p/P5ygdFo0Le/",
      "display_url" : "instagr.am/p/P5ygdFo0Le/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6640723109, -122.298082709 ]
  },
  "id_str" : "249713879037399042",
  "text" : "8:36pm Niko enjoys loitering here as much as I do  @ Apple Store http://t.co/g5XEope7",
  "id" : 249713879037399042,
  "created_at" : "Sun Sep 23 03:36:42 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagr.am\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niko Benson",
      "screen_name" : "nikobenson",
      "indices" : [ 16, 27 ],
      "id_str" : "142467448",
      "id" : 142467448
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 68 ],
      "url" : "http://t.co/tQaXEIvZ",
      "expanded_url" : "http://instagr.am/p/P5iQ2Oo0Mu/",
      "display_url" : "instagr.am/p/P5iQ2Oo0Mu/"
    } ]
  },
  "geo" : {
  },
  "id_str" : "249678184176553985",
  "text" : "Trying to teach @nikobenson how to use a camera http://t.co/tQaXEIvZ",
  "id" : 249678184176553985,
  "created_at" : "Sun Sep 23 01:14:52 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagr.am\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 28 ],
      "url" : "http://t.co/F4oGhquy",
      "expanded_url" : "http://instagr.am/p/P5ghjco0Kz/",
      "display_url" : "instagr.am/p/P5ghjco0Kz/"
    } ]
  },
  "geo" : {
  },
  "id_str" : "249674164296900608",
  "text" : "Caw caw http://t.co/F4oGhquy",
  "id" : 249674164296900608,
  "created_at" : "Sun Sep 23 00:58:54 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marina Martin",
      "screen_name" : "MarinaMartin",
      "indices" : [ 0, 13 ],
      "id_str" : "60663",
      "id" : 60663
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "249615000841371648",
  "geo" : {
  },
  "id_str" : "249634087881555968",
  "in_reply_to_user_id" : 60663,
  "text" : "@MarinaMartin Depends on the person but plank for a minute, pushups, or just sitting still all classify for me.",
  "id" : 249634087881555968,
  "in_reply_to_status_id" : 249615000841371648,
  "created_at" : "Sat Sep 22 22:19:39 +0000 2012",
  "in_reply_to_screen_name" : "MarinaMartin",
  "in_reply_to_user_id_str" : "60663",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Johns",
      "screen_name" : "marcjohns",
      "indices" : [ 0, 10 ],
      "id_str" : "1594021",
      "id" : 1594021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "249214495321370625",
  "geo" : {
  },
  "id_str" : "249580559217594368",
  "in_reply_to_user_id" : 1594021,
  "text" : "@marcjohns Thanks a lot, Marc! It’s fun to be writing again.",
  "id" : 249580559217594368,
  "in_reply_to_status_id" : 249214495321370625,
  "created_at" : "Sat Sep 22 18:46:56 +0000 2012",
  "in_reply_to_screen_name" : "marcjohns",
  "in_reply_to_user_id_str" : "1594021",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 79 ],
      "url" : "http://t.co/Ib6QTs8p",
      "expanded_url" : "http://wayoftheduck.com/the-i-dont-want-to-habit/",
      "display_url" : "wayoftheduck.com/the-i-dont-wan…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "249572980034793473",
  "text" : "One habit to rule them all. ‘The “I don’t want to” habit’: http://t.co/Ib6QTs8p",
  "id" : 249572980034793473,
  "created_at" : "Sat Sep 22 18:16:49 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Shapiro",
      "screen_name" : "danshapiro",
      "indices" : [ 50, 61 ],
      "id_str" : "8070502",
      "id" : 8070502
    }, {
      "name" : "Joe Heitzeberg",
      "screen_name" : "jheitzeb",
      "indices" : [ 107, 116 ],
      "id_str" : "6629572",
      "id" : 6629572
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "deadpool",
      "indices" : [ 34, 43 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http://t.co/avjGWVKA",
      "expanded_url" : "http://www.geekwire.com/2012/startupville-hot-social-game-play-future/",
      "display_url" : "geekwire.com/2012/startupvi…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "249396064610840576",
  "text" : "Earned most of these badges, plus #deadpool :) MT @danshapiro: It's Startupville! The game I invented with @jheitzeb. http://t.co/avjGWVKA",
  "id" : 249396064610840576,
  "created_at" : "Sat Sep 22 06:33:50 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Britt Selvitelle",
      "screen_name" : "bs",
      "indices" : [ 0, 3 ],
      "id_str" : "309073",
      "id" : 309073
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 66 ],
      "url" : "http://t.co/16nhlX9O",
      "expanded_url" : "http://www.theatlantic.com/health/archive/2012/09/study-athletes-perform-better-under-pressure-when-they-make-a-fist-with-their-left-hand/262605/",
      "display_url" : "theatlantic.com/health/archive…"
    } ]
  },
  "in_reply_to_status_id_str" : "249383180560392192",
  "geo" : {
  },
  "id_str" : "249386371624611841",
  "in_reply_to_user_id" : 309073,
  "text" : "@bs See previous tweet, which linked to this: http://t.co/16nhlX9O (and following tweet, for balance)",
  "id" : 249386371624611841,
  "in_reply_to_status_id" : 249383180560392192,
  "created_at" : "Sat Sep 22 05:55:19 +0000 2012",
  "in_reply_to_screen_name" : "bs",
  "in_reply_to_user_id_str" : "309073",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "249382681937330176",
  "text" : "That kind of science is almost too tweetable to be true.",
  "id" : 249382681937330176,
  "created_at" : "Sat Sep 22 05:40:39 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "249382543571423232",
  "text" : "Shake your left fist in the air when you’re under pressure. It’ll prime the right side of your brain to perform, and prevent over-thinking.",
  "id" : 249382543571423232,
  "created_at" : "Sat Sep 22 05:40:06 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 128 ],
      "url" : "http://t.co/16nhlX9O",
      "expanded_url" : "http://www.theatlantic.com/health/archive/2012/09/study-athletes-perform-better-under-pressure-when-they-make-a-fist-with-their-left-hand/262605/",
      "display_url" : "theatlantic.com/health/archive…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "249381815096340480",
  "text" : "“According to the researchers, freaking out is primarily associated with the left hemisphere of the brain.” http://t.co/16nhlX9O",
  "id" : 249381815096340480,
  "created_at" : "Sat Sep 22 05:37:12 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jane McGonigal",
      "screen_name" : "avantgame",
      "indices" : [ 0, 10 ],
      "id_str" : "681813",
      "id" : 681813
    }, {
      "name" : "SuperBetter",
      "screen_name" : "SuperBetter",
      "indices" : [ 11, 23 ],
      "id_str" : "351204906",
      "id" : 351204906
    }, {
      "name" : "Rose Broome",
      "screen_name" : "rosical",
      "indices" : [ 24, 32 ],
      "id_str" : "140145169",
      "id" : 140145169
    }, {
      "name" : "John W. Solomon",
      "screen_name" : "JohnWrede",
      "indices" : [ 33, 43 ],
      "id_str" : "125733",
      "id" : 125733
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "249379184273657857",
  "geo" : {
  },
  "id_str" : "249381627317329920",
  "in_reply_to_user_id" : 681813,
  "text" : "@avantgame @SuperBetter @rosical @JohnWrede That article is awesome.",
  "id" : 249381627317329920,
  "in_reply_to_status_id" : 249379184273657857,
  "created_at" : "Sat Sep 22 05:36:27 +0000 2012",
  "in_reply_to_screen_name" : "avantgame",
  "in_reply_to_user_id_str" : "681813",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "249376924961484800",
  "text" : "Knowing and relating to both sides of the story make it harder to come up with simple angry quips.",
  "id" : 249376924961484800,
  "created_at" : "Sat Sep 22 05:17:46 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Howard",
      "screen_name" : "digiphile",
      "indices" : [ 3, 13 ],
      "id_str" : "1175221",
      "id" : 1175221
    }, {
      "name" : "emily bell",
      "screen_name" : "emilybell",
      "indices" : [ 57, 67 ],
      "id_str" : "1489691",
      "id" : 1489691
    }, {
      "name" : "dick costolo",
      "screen_name" : "dickc",
      "indices" : [ 97, 103 ],
      "id_str" : "6385432",
      "id" : 6385432
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "249375352990863360",
  "text" : "RT @digiphile: \"When can we download all of our tweets?\"-@EmilyBell \"Before the end of the year\"-@DickC, with a caveat on an engineer's  ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "emily bell",
        "screen_name" : "emilybell",
        "indices" : [ 42, 52 ],
        "id_str" : "1489691",
        "id" : 1489691
      }, {
        "name" : "dick costolo",
        "screen_name" : "dickc",
        "indices" : [ 82, 88 ],
        "id_str" : "6385432",
        "id" : 6385432
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ONA12",
        "indices" : [ 133, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "249249411643883520",
    "text" : "\"When can we download all of our tweets?\"-@EmilyBell \"Before the end of the year\"-@DickC, with a caveat on an engineer's capability. #ONA12",
    "id" : 249249411643883520,
    "created_at" : "Fri Sep 21 20:51:05 +0000 2012",
    "user" : {
      "name" : "Alex Howard",
      "screen_name" : "digiphile",
      "protected" : false,
      "id_str" : "1175221",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2203436180/IMG_3481-1_normal.jpg",
      "id" : 1175221,
      "verified" : false
    }
  },
  "id" : 249375352990863360,
  "created_at" : "Sat Sep 22 05:11:31 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Craig Silverman",
      "screen_name" : "CraigSilverman",
      "indices" : [ 3, 18 ],
      "id_str" : "975731",
      "id" : 975731
    }, {
      "name" : "emily bell",
      "screen_name" : "emilybell",
      "indices" : [ 35, 45 ],
      "id_str" : "1489691",
      "id" : 1489691
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ONA12",
      "indices" : [ 88, 94 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 116 ],
      "url" : "http://t.co/GzsVb3dB",
      "expanded_url" : "http://silvr.me/OKdUnj",
      "display_url" : "silvr.me/OKdUnj"
    } ]
  },
  "geo" : {
  },
  "id_str" : "249374569230635008",
  "text" : "RT @CraigSilverman: My story about @emilybell's excellent Q&amp;A with Twitter's CEO at #ONA12: http://t.co/GzsVb3dB",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "emily bell",
        "screen_name" : "emilybell",
        "indices" : [ 15, 25 ],
        "id_str" : "1489691",
        "id" : 1489691
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ONA12",
        "indices" : [ 68, 74 ]
      } ],
      "urls" : [ {
        "indices" : [ 76, 96 ],
        "url" : "http://t.co/GzsVb3dB",
        "expanded_url" : "http://silvr.me/OKdUnj",
        "display_url" : "silvr.me/OKdUnj"
      } ]
    },
    "geo" : {
    },
    "id_str" : "249309623054651392",
    "text" : "My story about @emilybell's excellent Q&amp;A with Twitter's CEO at #ONA12: http://t.co/GzsVb3dB",
    "id" : 249309623054651392,
    "created_at" : "Sat Sep 22 00:50:20 +0000 2012",
    "user" : {
      "name" : "Craig Silverman",
      "screen_name" : "CraigSilverman",
      "protected" : false,
      "id_str" : "975731",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/257641193/silverman05webSM_normal.jpg",
      "id" : 975731,
      "verified" : false
    }
  },
  "id" : 249374569230635008,
  "created_at" : "Sat Sep 22 05:08:25 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Winer ☮",
      "screen_name" : "davewiner",
      "indices" : [ 33, 43 ],
      "id_str" : "3839",
      "id" : 3839
    }, {
      "name" : "dick costolo",
      "screen_name" : "dickc",
      "indices" : [ 52, 58 ],
      "id_str" : "6385432",
      "id" : 6385432
    }, {
      "name" : "emily bell",
      "screen_name" : "emilybell",
      "indices" : [ 74, 84 ],
      "id_str" : "1489691",
      "id" : 1489691
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ona12",
      "indices" : [ 88, 94 ]
    } ],
    "urls" : [ {
      "indices" : [ 124, 144 ],
      "url" : "http://t.co/kS2F0ZOc",
      "expanded_url" : "http://blork.ly/SfTPWu",
      "display_url" : "blork.ly/SfTPWu"
    } ]
  },
  "geo" : {
  },
  "id_str" : "249373271219380224",
  "text" : "Lots of clear answers in here RT @davewiner: MP3 of @dickc interview with @emilybell at #ona12 about APIs &amp; developers. http://t.co/kS2F0ZOc",
  "id" : 249373271219380224,
  "created_at" : "Sat Sep 22 05:03:15 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagr.am\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 116 ],
      "url" : "http://t.co/ZoALemgW",
      "expanded_url" : "http://instagr.am/p/P3PSMvI0Bs/",
      "display_url" : "instagr.am/p/P3PSMvI0Bs/"
    } ]
  },
  "geo" : {
  },
  "id_str" : "249355061405294593",
  "text" : "8:36pm Finally understood what this guy was saying under his sobs, thus making him happy again. http://t.co/ZoALemgW",
  "id" : 249355061405294593,
  "created_at" : "Sat Sep 22 03:50:54 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagr.am\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 105 ],
      "url" : "http://t.co/YvBrj2fa",
      "expanded_url" : "http://instagr.am/p/P29b8Mo0DS/",
      "display_url" : "instagr.am/p/P29b8Mo0DS/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.613929, -122.345453 ]
  },
  "id_str" : "249315846403526656",
  "text" : "One way to send me stuff is to mail it to my favorite coffee shop.   @ Bedlam Coffee http://t.co/YvBrj2fa",
  "id" : 249315846403526656,
  "created_at" : "Sat Sep 22 01:15:04 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jake Harding",
      "screen_name" : "JakeHarding",
      "indices" : [ 0, 12 ],
      "id_str" : "58502284",
      "id" : 58502284
    }, {
      "name" : "André Pinter",
      "screen_name" : "endform",
      "indices" : [ 13, 21 ],
      "id_str" : "93731096",
      "id" : 93731096
    }, {
      "name" : "Brian Guarraci",
      "screen_name" : "eismcc",
      "indices" : [ 22, 29 ],
      "id_str" : "13257392",
      "id" : 13257392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "249258160244813824",
  "geo" : {
  },
  "id_str" : "249266259882033153",
  "in_reply_to_user_id" : 58502284,
  "text" : "@JakeHarding @endform @eismcc Are you doing the Coursera course and/or the Intro to Scala course?",
  "id" : 249266259882033153,
  "in_reply_to_status_id" : 249258160244813824,
  "created_at" : "Fri Sep 21 21:58:02 +0000 2012",
  "in_reply_to_screen_name" : "JakeHarding",
  "in_reply_to_user_id_str" : "58502284",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "April Schiller",
      "screen_name" : "the_april",
      "indices" : [ 0, 10 ],
      "id_str" : "16644937",
      "id" : 16644937
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "249258338037166080",
  "geo" : {
  },
  "id_str" : "249265683257507840",
  "in_reply_to_user_id" : 16644937,
  "text" : "@the_april $299 for the 32GB, instead of $549 or whatever. I'm sure you can talk them into it too!",
  "id" : 249265683257507840,
  "in_reply_to_status_id" : 249258338037166080,
  "created_at" : "Fri Sep 21 21:55:44 +0000 2012",
  "in_reply_to_screen_name" : "the_april",
  "in_reply_to_user_id_str" : "16644937",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "K. Thrills Jensen",
      "screen_name" : "kthorjensen",
      "indices" : [ 0, 12 ],
      "id_str" : "25319959",
      "id" : 25319959
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "249245323535458305",
  "geo" : {
  },
  "id_str" : "249255729083609088",
  "in_reply_to_user_id" : 25319959,
  "text" : "@kthorjensen I have no idea. Maybe the cost of supporting confused users is higher than the cost of annoying/losing irked ones?",
  "id" : 249255729083609088,
  "in_reply_to_status_id" : 249245323535458305,
  "created_at" : "Fri Sep 21 21:16:11 +0000 2012",
  "in_reply_to_screen_name" : "kthorjensen",
  "in_reply_to_user_id_str" : "25319959",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 45 ],
      "url" : "http://t.co/DHbalnrX",
      "expanded_url" : "http://bit.ly/Sa7xVp",
      "display_url" : "bit.ly/Sa7xVp"
    } ]
  },
  "geo" : {
  },
  "id_str" : "249254656063184896",
  "text" : "Learning Scala today via http://t.co/DHbalnrX (which is awesome). Not as awesome: Eclipse has already crashed on me 4 times.",
  "id" : 249254656063184896,
  "created_at" : "Fri Sep 21 21:11:55 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "K. Thrills Jensen",
      "screen_name" : "kthorjensen",
      "indices" : [ 0, 12 ],
      "id_str" : "25319959",
      "id" : 25319959
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "249222813637025792",
  "geo" : {
  },
  "id_str" : "249228521237516288",
  "in_reply_to_user_id" : 25319959,
  "text" : "@kthorjensen I don't know what the official answer is. My guess is that it's never been consistently supported across clients =&gt; confusion.",
  "id" : 249228521237516288,
  "in_reply_to_status_id" : 249222813637025792,
  "created_at" : "Fri Sep 21 19:28:04 +0000 2012",
  "in_reply_to_screen_name" : "kthorjensen",
  "in_reply_to_user_id_str" : "25319959",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Morgan",
      "screen_name" : "Philip_Morgan",
      "indices" : [ 0, 14 ],
      "id_str" : "127602015",
      "id" : 127602015
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "249204148057292800",
  "geo" : {
  },
  "id_str" : "249204989308854272",
  "in_reply_to_user_id" : 127602015,
  "text" : "@Philip_Morgan It's good logic on their part. We just need to remember to ask more often.",
  "id" : 249204989308854272,
  "in_reply_to_status_id" : 249204148057292800,
  "created_at" : "Fri Sep 21 17:54:34 +0000 2012",
  "in_reply_to_screen_name" : "Philip_Morgan",
  "in_reply_to_user_id_str" : "127602015",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "249204754582994944",
  "text" : "While researching my AT&amp;T account, I realized I've also been paying $25/mo in roaming international data for the last 4 years. I'm an idiot.",
  "id" : 249204754582994944,
  "created_at" : "Fri Sep 21 17:53:38 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "249203419737382912",
  "text" : "My 2yr-contract with AT&amp;T doesn't end til next May, but I called them and they gave me the cheaper price anyway. That was surprisingly nice.",
  "id" : 249203419737382912,
  "created_at" : "Fri Sep 21 17:48:19 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anil Dash",
      "screen_name" : "anildash",
      "indices" : [ 3, 12 ],
      "id_str" : "36823",
      "id" : 36823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "249179679146258432",
  "text" : "RT @anildash: Did you know we just got our very own tech industry equivalent of the RIAA? Let's keep it from going to the dark side: htt ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://bitly.com\" rel=\"nofollow\">bitly</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 119, 139 ],
        "url" : "http://t.co/xcrW0Bkb",
        "expanded_url" : "http://2.dashes.com/OHICO3",
        "display_url" : "2.dashes.com/OHICO3"
      } ]
    },
    "geo" : {
    },
    "id_str" : "249175373852598272",
    "text" : "Did you know we just got our very own tech industry equivalent of the RIAA? Let's keep it from going to the dark side: http://t.co/xcrW0Bkb",
    "id" : 249175373852598272,
    "created_at" : "Fri Sep 21 15:56:53 +0000 2012",
    "user" : {
      "name" : "Anil Dash",
      "screen_name" : "anildash",
      "protected" : false,
      "id_str" : "36823",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2819125443/08240a3283301594794bcf6333ce8e6f_normal.png",
      "id" : 36823,
      "verified" : true
    }
  },
  "id" : 249179679146258432,
  "created_at" : "Fri Sep 21 16:13:59 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Ellin",
      "screen_name" : "brianellin",
      "indices" : [ 0, 11 ],
      "id_str" : "26123649",
      "id" : 26123649
    }, {
      "name" : "Ben Ward",
      "screen_name" : "BenWard",
      "indices" : [ 23, 31 ],
      "id_str" : "12249",
      "id" : 12249
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "248952987400146945",
  "geo" : {
  },
  "id_str" : "249018465837514752",
  "in_reply_to_user_id" : 26123649,
  "text" : "@brianellin My idea of @benward has changed forever. But I'm not sure how.",
  "id" : 249018465837514752,
  "in_reply_to_status_id" : 248952987400146945,
  "created_at" : "Fri Sep 21 05:33:23 +0000 2012",
  "in_reply_to_screen_name" : "brianellin",
  "in_reply_to_user_id_str" : "26123649",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 17, 27 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 85 ],
      "url" : "http://t.co/s0mSlOI3",
      "expanded_url" : "http://flic.kr/p/dcDzLa",
      "display_url" : "flic.kr/p/dcDzLa"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.614, -122.322667 ]
  },
  "id_str" : "248990323374694400",
  "text" : "8:36pm Date with @kellianne at Saint Johns! (Pete in background) http://t.co/s0mSlOI3",
  "id" : 248990323374694400,
  "created_at" : "Fri Sep 21 03:41:33 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dennis Crowley",
      "screen_name" : "dens",
      "indices" : [ 9, 14 ],
      "id_str" : "418",
      "id" : 418
    }, {
      "name" : "Foursquare",
      "screen_name" : "foursquare",
      "indices" : [ 49, 60 ],
      "id_str" : "14120151",
      "id" : 14120151
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SpreadTheWord",
      "indices" : [ 114, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "248980255619047424",
  "text" : "Okay! RT @dens: Your homework for tonight:  open @foursquare, tap Explore, search for something using the map  :) #SpreadTheWord",
  "id" : 248980255619047424,
  "created_at" : "Fri Sep 21 03:01:33 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "248969891040870400",
  "text" : "Damn you no auto correct on the web.",
  "id" : 248969891040870400,
  "created_at" : "Fri Sep 21 02:20:22 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 88 ],
      "url" : "http://t.co/BVX4mhPm",
      "expanded_url" : "http://on.fb.me/R3TdB8",
      "display_url" : "on.fb.me/R3TdB8"
    } ]
  },
  "geo" : {
  },
  "id_str" : "248969184585859072",
  "text" : "Nassim N. Taleb on why it's not easy to find a genuine reasearcher: http://t.co/BVX4mhPm",
  "id" : 248969184585859072,
  "created_at" : "Fri Sep 21 02:17:33 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Sippey",
      "screen_name" : "sippey",
      "indices" : [ 3, 10 ],
      "id_str" : "4711",
      "id" : 4711
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 117 ],
      "url" : "http://t.co/qKzlxM21",
      "expanded_url" : "http://thebhj.com/journal/2012/9/11/its-almost-three-football-fields-to-being-a-person.html",
      "display_url" : "thebhj.com/journal/2012/9…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "248870615270948865",
  "text" : "RT @sippey: \"We gave him some food, played a lot of good music, blinked, and now he’s a person.\" http://t.co/qKzlxM21",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 85, 105 ],
        "url" : "http://t.co/qKzlxM21",
        "expanded_url" : "http://thebhj.com/journal/2012/9/11/its-almost-three-football-fields-to-being-a-person.html",
        "display_url" : "thebhj.com/journal/2012/9…"
      } ]
    },
    "geo" : {
    },
    "id_str" : "248656769306476546",
    "text" : "\"We gave him some food, played a lot of good music, blinked, and now he’s a person.\" http://t.co/qKzlxM21",
    "id" : 248656769306476546,
    "created_at" : "Thu Sep 20 05:36:08 +0000 2012",
    "user" : {
      "name" : "Michael Sippey",
      "screen_name" : "sippey",
      "protected" : false,
      "id_str" : "4711",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2990071228/1badb0fe82fced7ac4068c6669a54a76_normal.jpeg",
      "id" : 4711,
      "verified" : false
    }
  },
  "id" : 248870615270948865,
  "created_at" : "Thu Sep 20 19:45:53 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Sippey",
      "screen_name" : "sippey",
      "indices" : [ 1, 8 ],
      "id_str" : "4711",
      "id" : 4711
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "248865600053592064",
  "text" : ".@sippey And reply to it if you want to tattoo it on your lower back.",
  "id" : 248865600053592064,
  "created_at" : "Thu Sep 20 19:25:57 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "248864981007884288",
  "text" : "Retweet this tweet if you want to favorite it, and favorite it if you want to retweet it.",
  "id" : 248864981007884288,
  "created_at" : "Thu Sep 20 19:23:29 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "McDonalds NYTriState",
      "screen_name" : "McDNYTriState",
      "indices" : [ 3, 17 ],
      "id_str" : "158498801",
      "id" : 158498801
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cheeseburgers",
      "indices" : [ 46, 60 ]
    }, {
      "text" : "hamburgers",
      "indices" : [ 90, 101 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "248824370443739136",
  "text" : "RT @McDNYTriState: Retweet this if you prefer #cheeseburgers. Favorite this if you prefer #hamburgers.",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.hootsuite.com\" rel=\"nofollow\">HootSuite</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "cheeseburgers",
        "indices" : [ 27, 41 ]
      }, {
        "text" : "hamburgers",
        "indices" : [ 71, 82 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "248816690882818048",
    "text" : "Retweet this if you prefer #cheeseburgers. Favorite this if you prefer #hamburgers.",
    "id" : 248816690882818048,
    "created_at" : "Thu Sep 20 16:11:36 +0000 2012",
    "user" : {
      "name" : "McDonalds NYTriState",
      "screen_name" : "McDNYTriState",
      "protected" : false,
      "id_str" : "158498801",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1721823083/Twitter_normal.jpg",
      "id" : 158498801,
      "verified" : true
    }
  },
  "id" : 248824370443739136,
  "created_at" : "Thu Sep 20 16:42:07 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PandoDaily",
      "screen_name" : "PandoDaily",
      "indices" : [ 3, 14 ],
      "id_str" : "419710142",
      "id" : 419710142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 101 ],
      "url" : "http://t.co/PkCtq0yW",
      "expanded_url" : "http://pandodaily.com/2012/09/20/21-jonah-peretti-quotes-that-will-restore-your-faith-in-buzzfeed/",
      "display_url" : "pandodaily.com/2012/09/20/21-…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "248823336929464320",
  "text" : "RT @PandoDaily: 21 Jonah Peretti Quotes That Will Restore Your Faith in Buzzfeed http://t.co/PkCtq0yW",
  "retweeted_status" : {
    "source" : "<a href=\"http://pandodaily.com/\" rel=\"nofollow\">PandoDaily</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 65, 85 ],
        "url" : "http://t.co/PkCtq0yW",
        "expanded_url" : "http://pandodaily.com/2012/09/20/21-jonah-peretti-quotes-that-will-restore-your-faith-in-buzzfeed/",
        "display_url" : "pandodaily.com/2012/09/20/21-…"
      } ]
    },
    "geo" : {
    },
    "id_str" : "248815008434225152",
    "text" : "21 Jonah Peretti Quotes That Will Restore Your Faith in Buzzfeed http://t.co/PkCtq0yW",
    "id" : 248815008434225152,
    "created_at" : "Thu Sep 20 16:04:55 +0000 2012",
    "user" : {
      "name" : "PandoDaily",
      "screen_name" : "PandoDaily",
      "protected" : false,
      "id_str" : "419710142",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1764819620/Pando_Twitter_Logo_normal.jpg",
      "id" : 419710142,
      "verified" : false
    }
  },
  "id" : 248823336929464320,
  "created_at" : "Thu Sep 20 16:38:01 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagr.am\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 70 ],
      "url" : "http://t.co/GcjAu22N",
      "expanded_url" : "http://instagr.am/p/PyEwWGo0Ay/",
      "display_url" : "instagr.am/p/PyEwWGo0Ay/"
    } ]
  },
  "geo" : {
  },
  "id_str" : "248628342755049473",
  "text" : "8:36pm Reading Chicka Chicka Boom Boom before bed http://t.co/GcjAu22N",
  "id" : 248628342755049473,
  "created_at" : "Thu Sep 20 03:43:10 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Baio",
      "screen_name" : "waxpancake",
      "indices" : [ 3, 14 ],
      "id_str" : "13461",
      "id" : 13461
    }, {
      "name" : "Ryan Gantz",
      "screen_name" : "sixfoot6",
      "indices" : [ 29, 38 ],
      "id_str" : "822030",
      "id" : 822030
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 114 ],
      "url" : "http://t.co/NLqhuEsU",
      "expanded_url" : "http://www.theverge.com/2012/9/19/3359592/xoxo-festival-2012-internet-party-conference",
      "display_url" : "theverge.com/2012/9/19/3359…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "248567835616477184",
  "text" : "RT @waxpancake: So, so good. @sixfoot6's writing debut on The Verge is a love letter to XOXO. http://t.co/NLqhuEsU",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ryan Gantz",
        "screen_name" : "sixfoot6",
        "indices" : [ 13, 22 ],
        "id_str" : "822030",
        "id" : 822030
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 78, 98 ],
        "url" : "http://t.co/NLqhuEsU",
        "expanded_url" : "http://www.theverge.com/2012/9/19/3359592/xoxo-festival-2012-internet-party-conference",
        "display_url" : "theverge.com/2012/9/19/3359…"
      } ]
    },
    "geo" : {
    },
    "id_str" : "248566886168666112",
    "text" : "So, so good. @sixfoot6's writing debut on The Verge is a love letter to XOXO. http://t.co/NLqhuEsU",
    "id" : 248566886168666112,
    "created_at" : "Wed Sep 19 23:38:58 +0000 2012",
    "user" : {
      "name" : "Andy Baio",
      "screen_name" : "waxpancake",
      "protected" : false,
      "id_str" : "13461",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2722964270/4abc9d219d7bab89df50106c26e3a812_normal.png",
      "id" : 13461,
      "verified" : false
    }
  },
  "id" : 248567835616477184,
  "created_at" : "Wed Sep 19 23:42:44 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Haughey",
      "screen_name" : "mathowie",
      "indices" : [ 111, 120 ],
      "id_str" : "761975",
      "id" : 761975
    }, {
      "name" : "Andy Baio",
      "screen_name" : "waxpancake",
      "indices" : [ 121, 132 ],
      "id_str" : "13461",
      "id" : 13461
    }, {
      "name" : "Eric Case",
      "screen_name" : "Case",
      "indices" : [ 133, 138 ],
      "id_str" : "409",
      "id" : 409
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 20 ],
      "url" : "http://t.co/v43YxLRA",
      "expanded_url" : "http://Upcoming.org",
      "display_url" : "Upcoming.org"
    }, {
      "indices" : [ 86, 106 ],
      "url" : "http://t.co/gqFTtoZc",
      "expanded_url" : "http://bit.ly/PUJTjB",
      "display_url" : "bit.ly/PUJTjB"
    } ]
  },
  "geo" : {
  },
  "id_str" : "248553486478893057",
  "text" : "http://t.co/v43YxLRA launched 9 years ago today. Since we're checking… I was user 46. http://t.co/gqFTtoZc /cc @mathowie @waxpancake @case",
  "id" : 248553486478893057,
  "created_at" : "Wed Sep 19 22:45:43 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "248496558608371712",
  "text" : "Does Passbook work for anyone yet? I get an error when I click on the \"app store\" button after the app launches.",
  "id" : 248496558608371712,
  "created_at" : "Wed Sep 19 18:59:31 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Greg Linden",
      "screen_name" : "greglinden",
      "indices" : [ 0, 11 ],
      "id_str" : "87719108",
      "id" : 87719108
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "248489200217907200",
  "geo" : {
  },
  "id_str" : "248489474206605313",
  "in_reply_to_user_id" : 87719108,
  "text" : "@greglinden Ooh, what are you launching??",
  "id" : 248489474206605313,
  "in_reply_to_status_id" : 248489200217907200,
  "created_at" : "Wed Sep 19 18:31:22 +0000 2012",
  "in_reply_to_screen_name" : "greglinden",
  "in_reply_to_user_id_str" : "87719108",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 0, 9 ],
      "id_str" : "761628",
      "id" : 761628
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 82 ],
      "url" : "http://t.co/Mm6dxvd9",
      "expanded_url" : "http://rickwebb.net",
      "display_url" : "rickwebb.net"
    } ]
  },
  "in_reply_to_status_id_str" : "248448273919119360",
  "geo" : {
  },
  "id_str" : "248449341189128192",
  "in_reply_to_user_id" : 761628,
  "text" : "@RickWebb I'm surprised you haven't been archiving the all on http://t.co/Mm6dxvd9 this whole time.",
  "id" : 248449341189128192,
  "in_reply_to_status_id" : 248448273919119360,
  "created_at" : "Wed Sep 19 15:51:53 +0000 2012",
  "in_reply_to_screen_name" : "RickWebb",
  "in_reply_to_user_id_str" : "761628",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Baio",
      "screen_name" : "waxpancake",
      "indices" : [ 0, 11 ],
      "id_str" : "13461",
      "id" : 13461
    }, {
      "name" : "Anil Dash",
      "screen_name" : "anildash",
      "indices" : [ 12, 21 ],
      "id_str" : "36823",
      "id" : 36823
    }, {
      "name" : "John Gruber",
      "screen_name" : "gruber",
      "indices" : [ 22, 29 ],
      "id_str" : "33423",
      "id" : 33423
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 116 ],
      "url" : "http://t.co/YmFeplSP",
      "expanded_url" : "http://maps.google.com",
      "display_url" : "maps.google.com"
    } ]
  },
  "in_reply_to_status_id_str" : "248445308768497664",
  "geo" : {
  },
  "id_str" : "248446795770912768",
  "in_reply_to_user_id" : 13461,
  "text" : "@waxpancake @anildash @gruber It's a terrible hack but I've been using a homescreen bookmark of http://t.co/YmFeplSP for transit directions.",
  "id" : 248446795770912768,
  "in_reply_to_status_id" : 248445308768497664,
  "created_at" : "Wed Sep 19 15:41:46 +0000 2012",
  "in_reply_to_screen_name" : "waxpancake",
  "in_reply_to_user_id_str" : "13461",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Couch",
      "screen_name" : "couch",
      "indices" : [ 0, 6 ],
      "id_str" : "631823",
      "id" : 631823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "248288259933863936",
  "geo" : {
  },
  "id_str" : "248292368380461056",
  "in_reply_to_user_id" : 631823,
  "text" : "@couch I'll send you a link in a couple days.",
  "id" : 248292368380461056,
  "in_reply_to_status_id" : 248288259933863936,
  "created_at" : "Wed Sep 19 05:28:08 +0000 2012",
  "in_reply_to_screen_name" : "couch",
  "in_reply_to_user_id_str" : "631823",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Cheng",
      "screen_name" : "k",
      "indices" : [ 125, 127 ],
      "id_str" : "11222",
      "id" : 11222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "248286926283628544",
  "text" : "My script that tells me when people update their Twitter bios was cracking me up today with all the new profile changes. /cc @k",
  "id" : 248286926283628544,
  "created_at" : "Wed Sep 19 05:06:30 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "248277047921737728",
  "text" : "We feel invincible because time moves slowly, life is short, and memory is poor.",
  "id" : 248277047921737728,
  "created_at" : "Wed Sep 19 04:27:15 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 64 ],
      "url" : "http://t.co/wld89Psn",
      "expanded_url" : "http://flic.kr/p/dc7648",
      "display_url" : "flic.kr/p/dc7648"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.608666, -122.383834 ]
  },
  "id_str" : "248265389593735171",
  "text" : "8:36pm My flight is late. Finally boarding. http://t.co/wld89Psn",
  "id" : 248265389593735171,
  "created_at" : "Wed Sep 19 03:40:56 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Galen Ward",
      "screen_name" : "galenward",
      "indices" : [ 0, 10 ],
      "id_str" : "2854761",
      "id" : 2854761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "248234407767457792",
  "geo" : {
  },
  "id_str" : "248236422434279425",
  "in_reply_to_user_id" : 2854761,
  "text" : "@galenward Well I guess that's fair given that one of the goals was to simplify.",
  "id" : 248236422434279425,
  "in_reply_to_status_id" : 248234407767457792,
  "created_at" : "Wed Sep 19 01:45:49 +0000 2012",
  "in_reply_to_screen_name" : "galenward",
  "in_reply_to_user_id_str" : "2854761",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Galen Ward",
      "screen_name" : "galenward",
      "indices" : [ 0, 10 ],
      "id_str" : "2854761",
      "id" : 2854761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "248231047802785792",
  "geo" : {
  },
  "id_str" : "248233771239878656",
  "in_reply_to_user_id" : 2854761,
  "text" : "@galenward I haven't used it much yet (Niko owns ours). Is it worse than before or just still not as good as Tweetbot? (which I also love)",
  "id" : 248233771239878656,
  "in_reply_to_status_id" : 248231047802785792,
  "created_at" : "Wed Sep 19 01:35:17 +0000 2012",
  "in_reply_to_screen_name" : "galenward",
  "in_reply_to_user_id_str" : "2854761",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chloe Sladden",
      "screen_name" : "ChloeS",
      "indices" : [ 3, 10 ],
      "id_str" : "2363571",
      "id" : 2363571
    }, {
      "name" : "Andrew Fitzgerald",
      "screen_name" : "magicandrew",
      "indices" : [ 52, 64 ],
      "id_str" : "2139211",
      "id" : 2139211
    }, {
      "name" : "Ryan Seacrest",
      "screen_name" : "RyanSeacrest",
      "indices" : [ 66, 79 ],
      "id_str" : "16190898",
      "id" : 16190898
    }, {
      "name" : "Robin Sloan",
      "screen_name" : "robinsloan",
      "indices" : [ 81, 92 ],
      "id_str" : "13919072",
      "id" : 13919072
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OnlyOnTwitter",
      "indices" : [ 118, 132 ]
    }, {
      "text" : "bo",
      "indices" : [ 133, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "248131834892918784",
  "text" : "RT @ChloeS: Winners of the new Twitter page so far: @magicandrew, @ryanseacrest, @robinsloan. Send me your favorites. #OnlyOnTwitter #bo ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andrew Fitzgerald",
        "screen_name" : "magicandrew",
        "indices" : [ 40, 52 ],
        "id_str" : "2139211",
        "id" : 2139211
      }, {
        "name" : "Ryan Seacrest",
        "screen_name" : "RyanSeacrest",
        "indices" : [ 54, 67 ],
        "id_str" : "16190898",
        "id" : 16190898
      }, {
        "name" : "Robin Sloan",
        "screen_name" : "robinsloan",
        "indices" : [ 69, 80 ],
        "id_str" : "13919072",
        "id" : 13919072
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "OnlyOnTwitter",
        "indices" : [ 106, 120 ]
      }, {
        "text" : "bobbleheads",
        "indices" : [ 121, 133 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "248123540895842306",
    "text" : "Winners of the new Twitter page so far: @magicandrew, @ryanseacrest, @robinsloan. Send me your favorites. #OnlyOnTwitter #bobbleheads",
    "id" : 248123540895842306,
    "created_at" : "Tue Sep 18 18:17:16 +0000 2012",
    "user" : {
      "name" : "Chloe Sladden",
      "screen_name" : "ChloeS",
      "protected" : false,
      "id_str" : "2363571",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2629284715/34ca19f17cea2b1e9883646cc1e7adb5_normal.png",
      "id" : 2363571,
      "verified" : false
    }
  },
  "id" : 248131834892918784,
  "created_at" : "Tue Sep 18 18:50:14 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lifehacker",
      "screen_name" : "lifehacker",
      "indices" : [ 3, 14 ],
      "id_str" : "7144422",
      "id" : 7144422
    }, {
      "name" : "Maria Popova",
      "screen_name" : "brainpicker",
      "indices" : [ 20, 32 ],
      "id_str" : "9207632",
      "id" : 9207632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "248064818316181504",
  "text" : "RT @lifehacker: The @brainpicker herself, Maria Popova, chatted with us about her fave apps, gadgets, tunes, and more. Check it out! htt ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.socialflow.com\" rel=\"nofollow\">SocialFlow</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Maria Popova",
        "screen_name" : "brainpicker",
        "indices" : [ 4, 16 ],
        "id_str" : "9207632",
        "id" : 9207632
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 137 ],
        "url" : "http://t.co/uT9ofoZg",
        "expanded_url" : "http://lifehac.kr/pyXaeD",
        "display_url" : "lifehac.kr/pyXaeD"
      } ]
    },
    "geo" : {
    },
    "id_str" : "245998930809208832",
    "text" : "The @brainpicker herself, Maria Popova, chatted with us about her fave apps, gadgets, tunes, and more. Check it out! http://t.co/uT9ofoZg",
    "id" : 245998930809208832,
    "created_at" : "Wed Sep 12 21:34:50 +0000 2012",
    "user" : {
      "name" : "Lifehacker",
      "screen_name" : "lifehacker",
      "protected" : false,
      "id_str" : "7144422",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1861146796/Twitter_-_Avatar_normal.png",
      "id" : 7144422,
      "verified" : true
    }
  },
  "id" : 248064818316181504,
  "created_at" : "Tue Sep 18 14:23:56 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "248063872722956289",
  "text" : "New Twitter things are out! Go get 'em.",
  "id" : 248063872722956289,
  "created_at" : "Tue Sep 18 14:20:10 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian Ownbey",
      "screen_name" : "iano",
      "indices" : [ 0, 5 ],
      "id_str" : "14409856",
      "id" : 14409856
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "247922760137973761",
  "geo" : {
  },
  "id_str" : "247924125551706115",
  "in_reply_to_user_id" : 14409856,
  "text" : "@iano Same goes for me and my anxieties.",
  "id" : 247924125551706115,
  "in_reply_to_status_id" : 247922760137973761,
  "created_at" : "Tue Sep 18 05:04:52 +0000 2012",
  "in_reply_to_screen_name" : "iano",
  "in_reply_to_user_id_str" : "14409856",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian Ownbey",
      "screen_name" : "iano",
      "indices" : [ 0, 5 ],
      "id_str" : "14409856",
      "id" : 14409856
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "247920276178886656",
  "geo" : {
  },
  "id_str" : "247922516532805632",
  "in_reply_to_user_id" : 14409856,
  "text" : "@iano Yeah, I need to find the door to your T universe.",
  "id" : 247922516532805632,
  "in_reply_to_status_id" : 247920276178886656,
  "created_at" : "Tue Sep 18 04:58:28 +0000 2012",
  "in_reply_to_screen_name" : "iano",
  "in_reply_to_user_id_str" : "14409856",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "brian ball",
      "screen_name" : "brianball",
      "indices" : [ 0, 10 ],
      "id_str" : "7305822",
      "id" : 7305822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "247912787358130176",
  "geo" : {
  },
  "id_str" : "247913272425193473",
  "in_reply_to_user_id" : 7305822,
  "text" : "@brianball Ha, yeah, that was a mistake. Those reminders shouldn't have gone out to people who ran out of their trials. Sorry about that.",
  "id" : 247913272425193473,
  "in_reply_to_status_id" : 247912787358130176,
  "created_at" : "Tue Sep 18 04:21:44 +0000 2012",
  "in_reply_to_screen_name" : "brianball",
  "in_reply_to_user_id_str" : "7305822",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "girl jo",
      "screen_name" : "octavekitten",
      "indices" : [ 0, 13 ],
      "id_str" : "16366882",
      "id" : 16366882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "247905594902716416",
  "geo" : {
  },
  "id_str" : "247907294900256769",
  "in_reply_to_user_id" : 16366882,
  "text" : "@octavekitten Even I felt naustalgic watching that.",
  "id" : 247907294900256769,
  "in_reply_to_status_id" : 247905594902716416,
  "created_at" : "Tue Sep 18 03:57:59 +0000 2012",
  "in_reply_to_screen_name" : "octavekitten",
  "in_reply_to_user_id_str" : "16366882",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "girl jo",
      "screen_name" : "octavekitten",
      "indices" : [ 0, 13 ],
      "id_str" : "16366882",
      "id" : 16366882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "247904372875460608",
  "geo" : {
  },
  "id_str" : "247904749737885696",
  "in_reply_to_user_id" : 16366882,
  "text" : "@octavekitten Shoot, I should've requested that room. And 2008!",
  "id" : 247904749737885696,
  "in_reply_to_status_id" : 247904372875460608,
  "created_at" : "Tue Sep 18 03:47:52 +0000 2012",
  "in_reply_to_screen_name" : "octavekitten",
  "in_reply_to_user_id_str" : "16366882",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagr.am\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 95 ],
      "url" : "http://t.co/LLWqeGJR",
      "expanded_url" : "http://instagr.am/p/Ps7c0Wo0CV/",
      "display_url" : "instagr.am/p/Ps7c0Wo0CV/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7867574207, -122.411289821 ]
  },
  "id_str" : "247903937921961984",
  "text" : "8:36pm Working from bed, listening to new Animal Collective  @ Clift Hotel http://t.co/LLWqeGJR",
  "id" : 247903937921961984,
  "created_at" : "Tue Sep 18 03:44:39 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kare Anderson",
      "screen_name" : "KareAnderson",
      "indices" : [ 98, 111 ],
      "id_str" : "819284",
      "id" : 819284
    }, {
      "name" : "Ellen Feaheny",
      "screen_name" : "ellenfeaheny",
      "indices" : [ 117, 130 ],
      "id_str" : "16614690",
      "id" : 16614690
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 93 ],
      "url" : "http://t.co/7UYJMBUR",
      "expanded_url" : "http://onforb.es/PaILX6",
      "display_url" : "onforb.es/PaILX6"
    } ]
  },
  "geo" : {
  },
  "id_str" : "247881216852897792",
  "text" : "\"What Vulnerability Looks Like to Psychopaths, Monks and the Rest of Us\" http://t.co/7UYJMBUR /by @KareAnderson /via @ellenfeaheny",
  "id" : 247881216852897792,
  "created_at" : "Tue Sep 18 02:14:22 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Loren Drummond",
      "screen_name" : "girlonfoot",
      "indices" : [ 0, 11 ],
      "id_str" : "16407047",
      "id" : 16407047
    }, {
      "name" : "Lauren Groff",
      "screen_name" : "legroff",
      "indices" : [ 94, 102 ],
      "id_str" : "182035401",
      "id" : 182035401
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "247871946098892800",
  "geo" : {
  },
  "id_str" : "247876334120996864",
  "in_reply_to_user_id" : 16407047,
  "text" : "@girlonfoot Just read the NYT book review for it. Sounds amazing! Thanks for the tip off. /cc @legroff",
  "id" : 247876334120996864,
  "in_reply_to_status_id" : 247871946098892800,
  "created_at" : "Tue Sep 18 01:54:58 +0000 2012",
  "in_reply_to_screen_name" : "girlonfoot",
  "in_reply_to_user_id_str" : "16407047",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "247870323582701569",
  "text" : "I forget -- how long is a meme allowed to be funny again? 1 day or 2?",
  "id" : 247870323582701569,
  "created_at" : "Tue Sep 18 01:31:05 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nikki thompson",
      "screen_name" : "tastiertomato",
      "indices" : [ 0, 14 ],
      "id_str" : "14984379",
      "id" : 14984379
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "247757000023355393",
  "geo" : {
  },
  "id_str" : "247788343335735297",
  "in_reply_to_user_id" : 14984379,
  "text" : "@tastiertomato Ooh, yeah! I'm here tonight if you are free. Staying at the Clift.",
  "id" : 247788343335735297,
  "in_reply_to_status_id" : 247757000023355393,
  "created_at" : "Mon Sep 17 20:05:19 +0000 2012",
  "in_reply_to_screen_name" : "tastiertomato",
  "in_reply_to_user_id_str" : "14984379",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.apple.com\" rel=\"nofollow\">Safari on iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 39 ],
      "url" : "http://t.co/kaZw2A2g",
      "expanded_url" : "http://wayoftheduck.com/tweet-fearlessly",
      "display_url" : "wayoftheduck.com/tweet-fearless…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "247724251426217984",
  "text" : "\"Tweet fearlessly\" http://t.co/kaZw2A2g",
  "id" : 247724251426217984,
  "created_at" : "Mon Sep 17 15:50:38 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 116 ],
      "url" : "http://t.co/CcKs6uaA",
      "expanded_url" : "http://4sq.com/Stg6en",
      "display_url" : "4sq.com/Stg6en"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.4436465828, -122.3025941849 ]
  },
  "id_str" : "247666055886032896",
  "text" : "Working from SF today and tomorrow. (@ Seattle-Tacoma International Airport (SEA) w/ 20 others) http://t.co/CcKs6uaA",
  "id" : 247666055886032896,
  "created_at" : "Mon Sep 17 11:59:23 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TechCrunch",
      "screen_name" : "TechCrunch",
      "indices" : [ 20, 31 ],
      "id_str" : "816653",
      "id" : 816653
    }, {
      "name" : "Fitbit",
      "screen_name" : "fitbit",
      "indices" : [ 51, 58 ],
      "id_str" : "17424053",
      "id" : 17424053
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 83 ],
      "url" : "http://t.co/bq0L9FdT",
      "expanded_url" : "http://tcrn.ch/OSDdPZ",
      "display_url" : "tcrn.ch/OSDdPZ"
    } ]
  },
  "geo" : {
  },
  "id_str" : "247665181260382209",
  "text" : "Ooh new Fitbits! RT @TechCrunch: Hands-On With The @Fitbit Zip http://t.co/bq0L9FdT",
  "id" : 247665181260382209,
  "created_at" : "Mon Sep 17 11:55:55 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagr.am\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 92 ],
      "url" : "http://t.co/XtaIZrRq",
      "expanded_url" : "http://instagr.am/p/PqV8W5o0GX/",
      "display_url" : "instagr.am/p/PqV8W5o0GX/"
    } ]
  },
  "geo" : {
  },
  "id_str" : "247540061590155265",
  "text" : "8:36pm Replaying scenes from The Little Engine That Could in toy trains http://t.co/XtaIZrRq",
  "id" : 247540061590155265,
  "created_at" : "Mon Sep 17 03:38:44 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "EFF",
      "screen_name" : "EFF",
      "indices" : [ 3, 7 ],
      "id_str" : "4816",
      "id" : 4816
    }, {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 25, 33 ],
      "id_str" : "783214",
      "id" : 783214
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OWS",
      "indices" : [ 47, 51 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 139 ],
      "url" : "https://t.co/RgVbiOEn",
      "expanded_url" : "https://eff.org/r.a6kU",
      "display_url" : "eff.org/r.a6kU"
    } ]
  },
  "geo" : {
  },
  "id_str" : "247413088041705472",
  "text" : "RT @EFF: NY judge forces @Twitter to hand over #OWS user info under threat of fine; records sealed until 9/21 hearing https://t.co/RgVbiOEn",
  "retweeted_status" : {
    "source" : "<a href=\"https://www.eff.org/\" rel=\"nofollow\">Thingie</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Twitter",
        "screen_name" : "twitter",
        "indices" : [ 16, 24 ],
        "id_str" : "783214",
        "id" : 783214
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "OWS",
        "indices" : [ 38, 42 ]
      } ],
      "urls" : [ {
        "indices" : [ 109, 130 ],
        "url" : "https://t.co/RgVbiOEn",
        "expanded_url" : "https://eff.org/r.a6kU",
        "display_url" : "eff.org/r.a6kU"
      } ]
    },
    "geo" : {
    },
    "id_str" : "246730126983835648",
    "text" : "NY judge forces @Twitter to hand over #OWS user info under threat of fine; records sealed until 9/21 hearing https://t.co/RgVbiOEn",
    "id" : 246730126983835648,
    "created_at" : "Fri Sep 14 22:00:20 +0000 2012",
    "user" : {
      "name" : "EFF",
      "screen_name" : "EFF",
      "protected" : false,
      "id_str" : "4816",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2903921395/1b64b272ba0865a659f3c38d7881b2ac_normal.png",
      "id" : 4816,
      "verified" : true
    }
  },
  "id" : 247413088041705472,
  "created_at" : "Sun Sep 16 19:14:11 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Andrew",
      "screen_name" : "scottandrew",
      "indices" : [ 3, 15 ],
      "id_str" : "6854",
      "id" : 6854
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "xoxofest",
      "indices" : [ 102, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "247399337259315200",
  "text" : "RT @scottandrew: Dan Harmon: \"Once you know how the system works, you lose the ability to change it.\" #xoxofest",
  "retweeted_status" : {
    "source" : "<a href=\"http://bufferapp.com\" rel=\"nofollow\">Buffer</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "xoxofest",
        "indices" : [ 85, 94 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "247392424836624385",
    "text" : "Dan Harmon: \"Once you know how the system works, you lose the ability to change it.\" #xoxofest",
    "id" : 247392424836624385,
    "created_at" : "Sun Sep 16 17:52:05 +0000 2012",
    "user" : {
      "name" : "Scott Andrew",
      "screen_name" : "scottandrew",
      "protected" : false,
      "id_str" : "6854",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/14226352/543159902_a23f3b14b9_normal.jpg",
      "id" : 6854,
      "verified" : false
    }
  },
  "id" : 247399337259315200,
  "created_at" : "Sun Sep 16 18:19:33 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagr.am\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "makesnosense",
      "indices" : [ 70, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 104 ],
      "url" : "http://t.co/sRWGZPct",
      "expanded_url" : "http://instagr.am/p/Pnzj9_o0MZ/",
      "display_url" : "instagr.am/p/Pnzj9_o0MZ/"
    } ]
  },
  "geo" : {
  },
  "id_str" : "247182988054519808",
  "text" : "8:36pm Niko's convinced that the drain is a nose, taking boogers away #makesnosense http://t.co/sRWGZPct",
  "id" : 247182988054519808,
  "created_at" : "Sun Sep 16 03:59:51 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anil Dash",
      "screen_name" : "anildash",
      "indices" : [ 0, 9 ],
      "id_str" : "36823",
      "id" : 36823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "247091374200082432",
  "geo" : {
  },
  "id_str" : "247097557933764609",
  "in_reply_to_user_id" : 36823,
  "text" : "@anildash Thank you! I also expect coverage of every interesting conversation in the hallways &amp; serenditipitous meeting of brilliant minds.",
  "id" : 247097557933764609,
  "in_reply_to_status_id" : 247091374200082432,
  "created_at" : "Sat Sep 15 22:20:23 +0000 2012",
  "in_reply_to_screen_name" : "anildash",
  "in_reply_to_user_id_str" : "36823",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jgschoolmeester",
      "screen_name" : "jgschoolmeester",
      "indices" : [ 0, 16 ],
      "id_str" : "17532947",
      "id" : 17532947
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "246898999716626432",
  "geo" : {
  },
  "id_str" : "247095271224389632",
  "in_reply_to_user_id" : 17532947,
  "text" : "@jgschoolmeester Thank you! I pull them in with their API.",
  "id" : 247095271224389632,
  "in_reply_to_status_id" : 246898999716626432,
  "created_at" : "Sat Sep 15 22:11:18 +0000 2012",
  "in_reply_to_screen_name" : "jgschoolmeester",
  "in_reply_to_user_id_str" : "17532947",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagr.am\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 61 ],
      "url" : "http://t.co/4qnf5fMs",
      "expanded_url" : "http://instagr.am/p/PmpZnkI0EW/",
      "display_url" : "instagr.am/p/PmpZnkI0EW/"
    } ]
  },
  "geo" : {
  },
  "id_str" : "247019738239229952",
  "text" : "Niko puts his pants on one leg at a time http://t.co/4qnf5fMs",
  "id" : 247019738239229952,
  "created_at" : "Sat Sep 15 17:11:09 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagr.am\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 38 ],
      "url" : "http://t.co/WB2a045A",
      "expanded_url" : "http://instagr.am/p/Pmm2a_I0Bx/",
      "display_url" : "instagr.am/p/Pmm2a_I0Bx/"
    } ]
  },
  "geo" : {
  },
  "id_str" : "247014165863075842",
  "text" : "Niko and Vivienne http://t.co/WB2a045A",
  "id" : 247014165863075842,
  "created_at" : "Sat Sep 15 16:49:01 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagr.am\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 78 ],
      "url" : "http://t.co/b66tExWe",
      "expanded_url" : "http://instagr.am/p/Pma8Aio0HZ/",
      "display_url" : "instagr.am/p/Pma8Aio0HZ/"
    } ]
  },
  "geo" : {
  },
  "id_str" : "246988089233375232",
  "text" : "Closet kitchen at Ben and Nicole's Ballard house/campsite http://t.co/b66tExWe",
  "id" : 246988089233375232,
  "created_at" : "Sat Sep 15 15:05:23 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 85 ],
      "url" : "http://t.co/nR9o2T2E",
      "expanded_url" : "http://flic.kr/p/daPb9A",
      "display_url" : "flic.kr/p/daPb9A"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.675166, -122.363834 ]
  },
  "id_str" : "246815875909423104",
  "text" : "8:36pm Camping in Ballard mean double jamming and cardamom milk. http://t.co/nR9o2T2E",
  "id" : 246815875909423104,
  "created_at" : "Sat Sep 15 03:41:05 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagr.am\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 39 ],
      "url" : "http://t.co/5dD0pUcA",
      "expanded_url" : "http://instagr.am/p/PlAAJQI0Bt/",
      "display_url" : "instagr.am/p/PlAAJQI0Bt/"
    } ]
  },
  "geo" : {
  },
  "id_str" : "246787963030212608",
  "text" : "Camping in Ballard http://t.co/5dD0pUcA",
  "id" : 246787963030212608,
  "created_at" : "Sat Sep 15 01:50:10 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://bufferapp.com\" rel=\"nofollow\">Buffer</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 55 ],
      "url" : "http://t.co/f5qEv2GF",
      "expanded_url" : "http://bit.ly/SlWtVm",
      "display_url" : "bit.ly/SlWtVm"
    } ]
  },
  "geo" : {
  },
  "id_str" : "246759008931807232",
  "text" : "Not resting. Not doing. Then what? http://t.co/f5qEv2GF",
  "id" : 246759008931807232,
  "created_at" : "Fri Sep 14 23:55:06 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Buffer",
      "screen_name" : "bufferapp",
      "indices" : [ 0, 10 ],
      "id_str" : "197962366",
      "id" : 197962366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "246681218291216384",
  "geo" : {
  },
  "id_str" : "246682658812350465",
  "in_reply_to_user_id" : 197962366,
  "text" : "@bufferapp Thank you!",
  "id" : 246682658812350465,
  "in_reply_to_status_id" : 246681218291216384,
  "created_at" : "Fri Sep 14 18:51:43 +0000 2012",
  "in_reply_to_screen_name" : "bufferapp",
  "in_reply_to_user_id_str" : "197962366",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Buffer",
      "screen_name" : "bufferapp",
      "indices" : [ 0, 10 ],
      "id_str" : "197962366",
      "id" : 197962366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "246595181271478272",
  "geo" : {
  },
  "id_str" : "246643846245646337",
  "in_reply_to_user_id" : 197962366,
  "text" : "@bufferapp My buff'd tweets always seem to go out at 1:30am, even though the app schedules them for 8:30pm. Do I have a time zone problem?",
  "id" : 246643846245646337,
  "in_reply_to_status_id" : 246595181271478272,
  "created_at" : "Fri Sep 14 16:17:30 +0000 2012",
  "in_reply_to_screen_name" : "bufferapp",
  "in_reply_to_user_id_str" : "197962366",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Maggie Mason",
      "screen_name" : "Maggie",
      "indices" : [ 50, 57 ],
      "id_str" : "448",
      "id" : 448
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 121 ],
      "url" : "http://t.co/N2NS10qG",
      "expanded_url" : "http://bit.ly/U9cJKU",
      "display_url" : "bit.ly/U9cJKU"
    } ]
  },
  "geo" : {
  },
  "id_str" : "246641726662537216",
  "text" : "I like it! Directions, actions, and appetites! RT @Maggie: An easy system for organizing your goals: http://t.co/N2NS10qG",
  "id" : 246641726662537216,
  "created_at" : "Fri Sep 14 16:09:04 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daryn Nakhuda",
      "screen_name" : "daryn",
      "indices" : [ 0, 6 ],
      "id_str" : "804808",
      "id" : 804808
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "246632547214311424",
  "geo" : {
  },
  "id_str" : "246634205184946176",
  "in_reply_to_user_id" : 804808,
  "text" : "@daryn Haha! What a varied career I've had!",
  "id" : 246634205184946176,
  "in_reply_to_status_id" : 246632547214311424,
  "created_at" : "Fri Sep 14 15:39:11 +0000 2012",
  "in_reply_to_screen_name" : "daryn",
  "in_reply_to_user_id_str" : "804808",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://bufferapp.com\" rel=\"nofollow\">Buffer</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "246516409935462400",
  "text" : "The illusion of habit change is that we've all changed a habit or two at some point with little effort. Replicating it is the problem.",
  "id" : 246516409935462400,
  "created_at" : "Fri Sep 14 07:51:06 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagr.am\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 28, 38 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 83 ],
      "url" : "http://t.co/TuvJev5l",
      "expanded_url" : "http://instagr.am/p/PioY9ao0LJ/",
      "display_url" : "instagr.am/p/PioY9ao0LJ/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.5996899391, -122.326432484 ]
  },
  "id_str" : "246454658481156098",
  "text" : "8:36pm On a date at Maneki. @kellianne's first time!  @ Maneki http://t.co/TuvJev5l",
  "id" : 246454658481156098,
  "created_at" : "Fri Sep 14 03:45:44 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Dary",
      "screen_name" : "chrisdary",
      "indices" : [ 0, 10 ],
      "id_str" : "15441990",
      "id" : 15441990
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "246370012804288512",
  "geo" : {
  },
  "id_str" : "246379856105979904",
  "in_reply_to_user_id" : 15441990,
  "text" : "@chrisdary I’ll take it! :) Still… jealous.",
  "id" : 246379856105979904,
  "in_reply_to_status_id" : 246370012804288512,
  "created_at" : "Thu Sep 13 22:48:29 +0000 2012",
  "in_reply_to_screen_name" : "chrisdary",
  "in_reply_to_user_id_str" : "15441990",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Dary",
      "screen_name" : "chrisdary",
      "indices" : [ 0, 10 ],
      "id_str" : "15441990",
      "id" : 15441990
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "246367988494770177",
  "geo" : {
  },
  "id_str" : "246369462079594496",
  "in_reply_to_user_id" : 15441990,
  "text" : "@chrisdary Unfortunately, I'm not going to the latter... just wishing I was. Timing and work conflicted. But have fun for me!",
  "id" : 246369462079594496,
  "in_reply_to_status_id" : 246367988494770177,
  "created_at" : "Thu Sep 13 22:07:11 +0000 2012",
  "in_reply_to_screen_name" : "chrisdary",
  "in_reply_to_user_id_str" : "15441990",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Iris Hoppenbrouwers",
      "screen_name" : "IrisMKH",
      "indices" : [ 0, 8 ],
      "id_str" : "491994799",
      "id" : 491994799
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/buster/status/246361744820273153/photo/1",
      "indices" : [ 43, 63 ],
      "url" : "http://t.co/8kLZ0zHB",
      "media_url" : "http://pbs.twimg.com/media/A2tAs57CAAA8Bax.jpg",
      "id_str" : "246361744828661760",
      "id" : 246361744828661760,
      "media_url_https" : "https://pbs.twimg.com/media/A2tAs57CAAA8Bax.jpg",
      "sizes" : [ {
        "h" : 160,
        "resize" : "fit",
        "w" : 160
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 160,
        "resize" : "fit",
        "w" : 160
      }, {
        "h" : 160,
        "resize" : "fit",
        "w" : 160
      }, {
        "h" : 160,
        "resize" : "fit",
        "w" : 160
      } ],
      "display_url" : "pic.twitter.com/8kLZ0zHB"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "246360119686885376",
  "geo" : {
  },
  "id_str" : "246361744820273153",
  "in_reply_to_user_id" : 491994799,
  "text" : "@IrisMKH Sure. Will this one work for you? http://t.co/8kLZ0zHB",
  "id" : 246361744820273153,
  "in_reply_to_status_id" : 246360119686885376,
  "created_at" : "Thu Sep 13 21:36:32 +0000 2012",
  "in_reply_to_screen_name" : "IrisMKH",
  "in_reply_to_user_id_str" : "491994799",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Haughey",
      "screen_name" : "mathowie",
      "indices" : [ 0, 9 ],
      "id_str" : "761975",
      "id" : 761975
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "246323830816133120",
  "geo" : {
  },
  "id_str" : "246329251069034496",
  "in_reply_to_user_id" : 761975,
  "text" : "@mathowie I know. :( I blame babies and 24-hour days. I’ll definitely be better positioned to go next year, if it happens again.",
  "id" : 246329251069034496,
  "in_reply_to_status_id" : 246323830816133120,
  "created_at" : "Thu Sep 13 19:27:24 +0000 2012",
  "in_reply_to_screen_name" : "mathowie",
  "in_reply_to_user_id_str" : "761975",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kellan",
      "screen_name" : "kellan",
      "indices" : [ 0, 7 ],
      "id_str" : "47",
      "id" : 47
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "246316403907522560",
  "geo" : {
  },
  "id_str" : "246323658933538816",
  "in_reply_to_user_id" : 47,
  "text" : "@kellan I missed a bunch, but how is Lightning planned obsolescence? Think they'll switch again soon? Or should've gone with micro USB?",
  "id" : 246323658933538816,
  "in_reply_to_status_id" : 246316403907522560,
  "created_at" : "Thu Sep 13 19:05:11 +0000 2012",
  "in_reply_to_screen_name" : "kellan",
  "in_reply_to_user_id_str" : "47",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "April V. Walters",
      "screen_name" : "aprilini",
      "indices" : [ 0, 9 ],
      "id_str" : "875511",
      "id" : 875511
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "246320023063384065",
  "geo" : {
  },
  "id_str" : "246321734876286976",
  "in_reply_to_user_id" : 875511,
  "text" : "@aprilini “Baffling one baby at a time.” PS. I love your Twitter bio.",
  "id" : 246321734876286976,
  "in_reply_to_status_id" : 246320023063384065,
  "created_at" : "Thu Sep 13 18:57:32 +0000 2012",
  "in_reply_to_screen_name" : "aprilini",
  "in_reply_to_user_id_str" : "875511",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "XOXO Festival",
      "screen_name" : "xoxo",
      "indices" : [ 5, 10 ],
      "id_str" : "516875194",
      "id" : 516875194
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 98 ],
      "url" : "https://t.co/S1UR8m36",
      "expanded_url" : "https://twitter.com/bump/xoxo/members",
      "display_url" : "twitter.com/bump/xoxo/memb…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "246321394630135808",
  "text" : "This @xoxo attendee list is like a Who’s Who of making the interweb awesome: https://t.co/S1UR8m36",
  "id" : 246321394630135808,
  "created_at" : "Thu Sep 13 18:56:11 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "April Schiller",
      "screen_name" : "the_april",
      "indices" : [ 0, 10 ],
      "id_str" : "16644937",
      "id" : 16644937
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "246304058221146112",
  "geo" : {
  },
  "id_str" : "246315882115125248",
  "in_reply_to_user_id" : 16644937,
  "text" : "@the_april o_O",
  "id" : 246315882115125248,
  "in_reply_to_status_id" : 246304058221146112,
  "created_at" : "Thu Sep 13 18:34:17 +0000 2012",
  "in_reply_to_screen_name" : "the_april",
  "in_reply_to_user_id_str" : "16644937",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "246296288579162114",
  "text" : "I like giving babies the bug eye when their parents aren't looking. It's your word against mine, baby.",
  "id" : 246296288579162114,
  "created_at" : "Thu Sep 13 17:16:25 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "senilearity",
      "indices" : [ 104, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "246293943908708353",
  "text" : "Do you think that by the time we all go senile we'll have enough apps that nobody will be able to tell? #senilearity",
  "id" : 246293943908708353,
  "created_at" : "Thu Sep 13 17:07:06 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Lowell",
      "screen_name" : "jthomas",
      "indices" : [ 0, 8 ],
      "id_str" : "760181",
      "id" : 760181
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "246259072482021376",
  "geo" : {
  },
  "id_str" : "246270629702152193",
  "in_reply_to_user_id" : 760181,
  "text" : "@jthomas Why do you like Strava more that RunKeeper?",
  "id" : 246270629702152193,
  "in_reply_to_status_id" : 246259072482021376,
  "created_at" : "Thu Sep 13 15:34:28 +0000 2012",
  "in_reply_to_screen_name" : "jthomas",
  "in_reply_to_user_id_str" : "760181",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "XOXO Festival",
      "screen_name" : "xoxo",
      "indices" : [ 29, 34 ],
      "id_str" : "516875194",
      "id" : 516875194
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "246269418236174336",
  "text" : "I really wish I was going to @xoxo this weekend. Someone hi-5 everyone for me please.",
  "id" : 246269418236174336,
  "created_at" : "Thu Sep 13 15:29:39 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.apple.com\" rel=\"nofollow\">Safari on iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 82 ],
      "url" : "http://t.co/ymzn15s5",
      "expanded_url" : "http://m.io9.com/5942616/dalai-lama-tells-his-facebook-friends-that-religion-is-no-longer-adequate",
      "display_url" : "m.io9.com/5942616/dalai-…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "246268553660100610",
  "text" : "I wish Sam Harris and the Dalai Lama had a podcast together.  http://t.co/ymzn15s5",
  "id" : 246268553660100610,
  "created_at" : "Thu Sep 13 15:26:13 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 94 ],
      "url" : "http://t.co/5aGTdmmo",
      "expanded_url" : "http://flic.kr/p/daiwkf",
      "display_url" : "flic.kr/p/daiwkf"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.608666, -122.306 ]
  },
  "id_str" : "246094407168835585",
  "text" : "8:36pm Was reading Cat in the Hat but didn't want to interrupt for 8:36pm http://t.co/5aGTdmmo",
  "id" : 246094407168835585,
  "created_at" : "Thu Sep 13 03:54:13 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hugh MacLeod",
      "screen_name" : "gapingvoid",
      "indices" : [ 9, 20 ],
      "id_str" : "50193",
      "id" : 50193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "246082907884638208",
  "text" : "True. RT @gapingvoid: Apple. I didn't need more skinny. I needed more battery.",
  "id" : 246082907884638208,
  "created_at" : "Thu Sep 13 03:08:31 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Singer",
      "screen_name" : "singy",
      "indices" : [ 0, 6 ],
      "id_str" : "15310552",
      "id" : 15310552
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "246056157683257344",
  "geo" : {
  },
  "id_str" : "246056663298232320",
  "in_reply_to_user_id" : 15310552,
  "text" : "@singy Awesome! I'll check it out.",
  "id" : 246056663298232320,
  "in_reply_to_status_id" : 246056157683257344,
  "created_at" : "Thu Sep 13 01:24:14 +0000 2012",
  "in_reply_to_screen_name" : "singy",
  "in_reply_to_user_id_str" : "15310552",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "246054437611765760",
  "text" : "Is there an app that let's you say how far you want to run and it gives you a nice route to take from whatever starting point?",
  "id" : 246054437611765760,
  "created_at" : "Thu Sep 13 01:15:24 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Square, Inc.",
      "screen_name" : "Square",
      "indices" : [ 18, 25 ],
      "id_str" : "93017945",
      "id" : 93017945
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "246053941366906881",
  "text" : "I wish buses used @Square.",
  "id" : 246053941366906881,
  "created_at" : "Thu Sep 13 01:13:25 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 0, 9 ],
      "id_str" : "761628",
      "id" : 761628
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "246045931324186624",
  "geo" : {
  },
  "id_str" : "246046146865270784",
  "in_reply_to_user_id" : 761628,
  "text" : "@RickWebb I generally need to hear that like 10 times a day on a good day.",
  "id" : 246046146865270784,
  "in_reply_to_status_id" : 246045931324186624,
  "created_at" : "Thu Sep 13 00:42:27 +0000 2012",
  "in_reply_to_screen_name" : "RickWebb",
  "in_reply_to_user_id_str" : "761628",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 0, 9 ],
      "id_str" : "761628",
      "id" : 761628
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "246017426590953472",
  "geo" : {
  },
  "id_str" : "246045593607237634",
  "in_reply_to_user_id" : 761628,
  "text" : "@RickWebb Can we gauge our current emotional state by determining if \"it's all gonna be okay\" or \"it's gonna be awesome\" resonates more?",
  "id" : 246045593607237634,
  "in_reply_to_status_id" : 246017426590953472,
  "created_at" : "Thu Sep 13 00:40:15 +0000 2012",
  "in_reply_to_screen_name" : "RickWebb",
  "in_reply_to_user_id_str" : "761628",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 130 ],
      "url" : "http://t.co/aki6WL9h",
      "expanded_url" : "http://io9.com/5942797/the-zombieland-writers-next-movie-follows-a-failed-robot-revolution",
      "display_url" : "io9.com/5942797/the-zo…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "246040926441578496",
  "text" : "Woah. A new movie by Zombieland writers about a failed robot revolution where they train humans as pets? YES! http://t.co/aki6WL9h",
  "id" : 246040926441578496,
  "created_at" : "Thu Sep 13 00:21:42 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ʎǝʞɔıɥ ʇʇɐɯ",
      "screen_name" : "matthickey",
      "indices" : [ 0, 11 ],
      "id_str" : "8710082",
      "id" : 8710082
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "246033849887379457",
  "geo" : {
  },
  "id_str" : "246039101835468800",
  "in_reply_to_user_id" : 8710082,
  "text" : "@matthickey Not necessarily if you consider that I choose to pursue a job at Twitter over Facebook.",
  "id" : 246039101835468800,
  "in_reply_to_status_id" : 246033849887379457,
  "created_at" : "Thu Sep 13 00:14:27 +0000 2012",
  "in_reply_to_screen_name" : "matthickey",
  "in_reply_to_user_id_str" : "8710082",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ʎǝʞɔıɥ ʇʇɐɯ",
      "screen_name" : "matthickey",
      "indices" : [ 0, 11 ],
      "id_str" : "8710082",
      "id" : 8710082
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "246033585075802112",
  "geo" : {
  },
  "id_str" : "246033653220638720",
  "in_reply_to_user_id" : 8710082,
  "text" : "@matthickey Nope. :)",
  "id" : 246033653220638720,
  "in_reply_to_status_id" : 246033585075802112,
  "created_at" : "Wed Sep 12 23:52:48 +0000 2012",
  "in_reply_to_screen_name" : "matthickey",
  "in_reply_to_user_id_str" : "8710082",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amber Rae",
      "screen_name" : "heyamberrae",
      "indices" : [ 0, 12 ],
      "id_str" : "15019184",
      "id" : 15019184
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "246028111433576448",
  "geo" : {
  },
  "id_str" : "246028805762854912",
  "in_reply_to_user_id" : 15019184,
  "text" : "@heyamberrae I would REALLY love to, but I can’t commit to it quite yet… that’s going to be a crazy month for me with moving.",
  "id" : 246028805762854912,
  "in_reply_to_status_id" : 246028111433576448,
  "created_at" : "Wed Sep 12 23:33:32 +0000 2012",
  "in_reply_to_screen_name" : "heyamberrae",
  "in_reply_to_user_id_str" : "15019184",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amber Rae",
      "screen_name" : "heyamberrae",
      "indices" : [ 0, 12 ],
      "id_str" : "15019184",
      "id" : 15019184
    }, {
      "name" : "Nick Crocker",
      "screen_name" : "nickcrocker",
      "indices" : [ 53, 65 ],
      "id_str" : "30801469",
      "id" : 30801469
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "246026640872837120",
  "geo" : {
  },
  "id_str" : "246027329778896896",
  "in_reply_to_user_id" : 15019184,
  "text" : "@heyamberrae I strongly vouch for the awesomeness of @nickcrocker.",
  "id" : 246027329778896896,
  "in_reply_to_status_id" : 246026640872837120,
  "created_at" : "Wed Sep 12 23:27:41 +0000 2012",
  "in_reply_to_screen_name" : "heyamberrae",
  "in_reply_to_user_id_str" : "15019184",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian Ownbey",
      "screen_name" : "iano",
      "indices" : [ 0, 5 ],
      "id_str" : "14409856",
      "id" : 14409856
    }, {
      "name" : "Niko Benson",
      "screen_name" : "nikobenson",
      "indices" : [ 56, 67 ],
      "id_str" : "142467448",
      "id" : 142467448
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "246016617585209344",
  "geo" : {
  },
  "id_str" : "246018768805974016",
  "in_reply_to_user_id" : 14409856,
  "text" : "@iano My son’s Twitter account is older than he is. /cc @nikobenson",
  "id" : 246018768805974016,
  "in_reply_to_status_id" : 246016617585209344,
  "created_at" : "Wed Sep 12 22:53:39 +0000 2012",
  "in_reply_to_screen_name" : "iano",
  "in_reply_to_user_id_str" : "14409856",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jan Schaumann",
      "screen_name" : "jschauma",
      "indices" : [ 0, 9 ],
      "id_str" : "169213944",
      "id" : 169213944
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "246015093102505984",
  "geo" : {
  },
  "id_str" : "246015795405148163",
  "in_reply_to_user_id" : 169213944,
  "text" : "@jschauma That would be awesome. Let me know if you do it!",
  "id" : 246015795405148163,
  "in_reply_to_status_id" : 246015093102505984,
  "created_at" : "Wed Sep 12 22:41:51 +0000 2012",
  "in_reply_to_screen_name" : "jschauma",
  "in_reply_to_user_id_str" : "169213944",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Jacobs",
      "screen_name" : "evanjacobs",
      "indices" : [ 0, 11 ],
      "id_str" : "14803483",
      "id" : 14803483
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "246012294646079488",
  "geo" : {
  },
  "id_str" : "246012488410357760",
  "in_reply_to_user_id" : 14803483,
  "text" : "@evanjacobs I wish for many things that I don’t have the time to actually build. :)",
  "id" : 246012488410357760,
  "in_reply_to_status_id" : 246012294646079488,
  "created_at" : "Wed Sep 12 22:28:42 +0000 2012",
  "in_reply_to_screen_name" : "evanjacobs",
  "in_reply_to_user_id_str" : "14803483",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vix Richardson",
      "screen_name" : "nefarious_vix",
      "indices" : [ 0, 14 ],
      "id_str" : "8605402",
      "id" : 8605402
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "246011936767082497",
  "geo" : {
  },
  "id_str" : "246012235250561025",
  "in_reply_to_user_id" : 8605402,
  "text" : "@nefarious_vix Yes, even if it ran off a cliff.",
  "id" : 246012235250561025,
  "in_reply_to_status_id" : 246011936767082497,
  "created_at" : "Wed Sep 12 22:27:42 +0000 2012",
  "in_reply_to_screen_name" : "nefarious_vix",
  "in_reply_to_user_id_str" : "8605402",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark",
      "screen_name" : "shinypb",
      "indices" : [ 1, 9 ],
      "id_str" : "13166",
      "id" : 13166
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "246011668721704960",
  "geo" : {
  },
  "id_str" : "246012139729461248",
  "in_reply_to_user_id" : 13166,
  "text" : ".@shinypb Ha. I mean, replies and such to the tweet from people I don’t follow would show up in my timeline.",
  "id" : 246012139729461248,
  "in_reply_to_status_id" : 246011668721704960,
  "created_at" : "Wed Sep 12 22:27:19 +0000 2012",
  "in_reply_to_screen_name" : "shinypb",
  "in_reply_to_user_id_str" : "13166",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "246011516955025408",
  "text" : "I wish I could follow a tweet.",
  "id" : 246011516955025408,
  "created_at" : "Wed Sep 12 22:24:50 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amy Jo Kim",
      "screen_name" : "amyjokim",
      "indices" : [ 0, 9 ],
      "id_str" : "780991",
      "id" : 780991
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "245916972511023104",
  "geo" : {
  },
  "id_str" : "245917145165344768",
  "in_reply_to_user_id" : 780991,
  "text" : "@amyjokim 2-bedroom… ideally with a yard of some sort (small is okay). Thanks!",
  "id" : 245917145165344768,
  "in_reply_to_status_id" : 245916972511023104,
  "created_at" : "Wed Sep 12 16:09:50 +0000 2012",
  "in_reply_to_screen_name" : "amyjokim",
  "in_reply_to_user_id_str" : "780991",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amy Jo Kim",
      "screen_name" : "amyjokim",
      "indices" : [ 0, 9 ],
      "id_str" : "780991",
      "id" : 780991
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "245725798055686146",
  "geo" : {
  },
  "id_str" : "245916288206118912",
  "in_reply_to_user_id" : 780991,
  "text" : "@amyjokim Not moving til early 2013, but waiting for the perfect place to pop up on Craigslist.",
  "id" : 245916288206118912,
  "in_reply_to_status_id" : 245725798055686146,
  "created_at" : "Wed Sep 12 16:06:26 +0000 2012",
  "in_reply_to_screen_name" : "amyjokim",
  "in_reply_to_user_id_str" : "780991",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trammell",
      "screen_name" : "trammell",
      "indices" : [ 3, 12 ],
      "id_str" : "666073",
      "id" : 666073
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "245908170487234561",
  "text" : "RT @trammell: Free idea: Automatically send me the newest version of [Apple device I own] &amp; a box w/ prepaid postage for donating th ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "245907415076315136",
    "text" : "Free idea: Automatically send me the newest version of [Apple device I own] &amp; a box w/ prepaid postage for donating the old one to charity.",
    "id" : 245907415076315136,
    "created_at" : "Wed Sep 12 15:31:11 +0000 2012",
    "user" : {
      "name" : "Trammell",
      "screen_name" : "trammell",
      "protected" : false,
      "id_str" : "666073",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2856914747/07a3e543f28d2b732a0161e99358503a_normal.png",
      "id" : 666073,
      "verified" : false
    }
  },
  "id" : 245908170487234561,
  "created_at" : "Wed Sep 12 15:34:11 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 79 ],
      "url" : "http://t.co/rK0cCqqL",
      "expanded_url" : "http://flic.kr/p/da45L8",
      "display_url" : "flic.kr/p/da45L8"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.446666, -122.302167 ]
  },
  "id_str" : "245753756661202944",
  "text" : "8:36pm Was reading Mockingjay on my full 9/11 flight home. http://t.co/rK0cCqqL",
  "id" : 245753756661202944,
  "created_at" : "Wed Sep 12 05:20:36 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amy Jo Kim",
      "screen_name" : "amyjokim",
      "indices" : [ 0, 9 ],
      "id_str" : "780991",
      "id" : 780991
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "245719987497603072",
  "geo" : {
  },
  "id_str" : "245721855779037184",
  "in_reply_to_user_id" : 780991,
  "text" : "@amyjokim Yes in spirit... chocolate has gotten a lot better since then.",
  "id" : 245721855779037184,
  "in_reply_to_status_id" : 245719987497603072,
  "created_at" : "Wed Sep 12 03:13:50 +0000 2012",
  "in_reply_to_screen_name" : "amyjokim",
  "in_reply_to_user_id_str" : "780991",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "airportgiftsftw",
      "indices" : [ 83, 99 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "245718717927944193",
  "text" : "My father used to bring me a Toblerone whenever he came home from a business trip. #airportgiftsftw",
  "id" : 245718717927944193,
  "created_at" : "Wed Sep 12 03:01:22 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagr.am\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 95 ],
      "url" : "http://t.co/UBYch3in",
      "expanded_url" : "http://instagr.am/p/PdSRySo0Ac/",
      "display_url" : "instagr.am/p/PdSRySo0Ac/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.6164240527, -122.386279106 ]
  },
  "id_str" : "245702250318663682",
  "text" : "I love living in the future.   @ San Francisco International Airport (SFO) http://t.co/UBYch3in",
  "id" : 245702250318663682,
  "created_at" : "Wed Sep 12 01:55:56 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daring Fireball",
      "screen_name" : "daringfireball",
      "indices" : [ 36, 51 ],
      "id_str" : "10760422",
      "id" : 10760422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 90 ],
      "url" : "http://t.co/bV0jMPmO",
      "expanded_url" : "http://df4.us/ka8",
      "display_url" : "df4.us/ka8"
    } ]
  },
  "geo" : {
  },
  "id_str" : "245689995208302592",
  "text" : "I agree with the last paragraph. RT @daringfireball: ★ Amazon’s Play: http://t.co/bV0jMPmO",
  "id" : 245689995208302592,
  "created_at" : "Wed Sep 12 01:07:14 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sunrise",
      "screen_name" : "sunriseapp",
      "indices" : [ 0, 11 ],
      "id_str" : "587811802",
      "id" : 587811802
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "245640331868135424",
  "geo" : {
  },
  "id_str" : "245687559999602688",
  "in_reply_to_user_id" : 587811802,
  "text" : "@sunriseapp From what I remember it linked to google maps from my flight and approximated time to check in at my hotel. Is that right?",
  "id" : 245687559999602688,
  "in_reply_to_status_id" : 245640331868135424,
  "created_at" : "Wed Sep 12 00:57:33 +0000 2012",
  "in_reply_to_screen_name" : "sunriseapp",
  "in_reply_to_user_id_str" : "587811802",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Stokes",
      "screen_name" : "samstokes",
      "indices" : [ 3, 13 ],
      "id_str" : "15668664",
      "id" : 15668664
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "245687274602389505",
  "text" : "RT @samstokes: A Turing-complete game of Magic: The Gathering.  Douglas Adams was right: we *are* just parts of a computer program. http ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 137 ],
        "url" : "http://t.co/NidVJgQj",
        "expanded_url" : "http://www.toothycat.net/~hologram/Turing/index.html",
        "display_url" : "toothycat.net/~hologram/Turi…"
      } ]
    },
    "geo" : {
    },
    "id_str" : "245685231284269056",
    "text" : "A Turing-complete game of Magic: The Gathering.  Douglas Adams was right: we *are* just parts of a computer program. http://t.co/NidVJgQj",
    "id" : 245685231284269056,
    "created_at" : "Wed Sep 12 00:48:18 +0000 2012",
    "user" : {
      "name" : "Sam Stokes",
      "screen_name" : "samstokes",
      "protected" : false,
      "id_str" : "15668664",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/295947534/n36903885_38101864_2407_normal.jpg",
      "id" : 15668664,
      "verified" : false
    }
  },
  "id" : 245687274602389505,
  "created_at" : "Wed Sep 12 00:56:25 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Raffi Krikorian",
      "screen_name" : "raffi",
      "indices" : [ 88, 94 ],
      "id_str" : "8285392",
      "id" : 8285392
    }, {
      "name" : "Marc Hedlund",
      "screen_name" : "marcprecipice",
      "indices" : [ 99, 113 ],
      "id_str" : "226976689",
      "id" : 226976689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 135 ],
      "url" : "http://t.co/OcXn3D8O",
      "expanded_url" : "http://codeascraft.etsy.com/2012/09/10/the-engineer-exchange-program/",
      "display_url" : "codeascraft.etsy.com/2012/09/10/the…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "245626406812397569",
  "text" : "Twitter and Etsy have a new engineer exchange program. That’s pretty awesome. Well done @raffi and @marcprecipice! http://t.co/OcXn3D8O",
  "id" : 245626406812397569,
  "created_at" : "Tue Sep 11 20:54:33 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MG Siegler",
      "screen_name" : "parislemon",
      "indices" : [ 3, 14 ],
      "id_str" : "652193",
      "id" : 652193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "245619280404684800",
  "text" : "RT @parislemon: Breaking: Competitor does not think competitor should have done what competitor did.",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "245596488175087616",
    "text" : "Breaking: Competitor does not think competitor should have done what competitor did.",
    "id" : 245596488175087616,
    "created_at" : "Tue Sep 11 18:55:40 +0000 2012",
    "user" : {
      "name" : "MG Siegler",
      "screen_name" : "parislemon",
      "protected" : false,
      "id_str" : "652193",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2748300201/ecc4dbe1c912ebac9a7aee2e85b51859_normal.jpeg",
      "id" : 652193,
      "verified" : true
    }
  },
  "id" : 245619280404684800,
  "created_at" : "Tue Sep 11 20:26:14 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dinah Sanders",
      "screen_name" : "MetaGrrrl",
      "indices" : [ 0, 10 ],
      "id_str" : "6722",
      "id" : 6722
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "245600398881214464",
  "geo" : {
  },
  "id_str" : "245609507428892674",
  "in_reply_to_user_id" : 6722,
  "text" : "@MetaGrrrl That’s an awesome idea. Maybe when specifying directions you can say how much time you have to meander.",
  "id" : 245609507428892674,
  "in_reply_to_status_id" : 245600398881214464,
  "created_at" : "Tue Sep 11 19:47:24 +0000 2012",
  "in_reply_to_screen_name" : "MetaGrrrl",
  "in_reply_to_user_id_str" : "6722",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 135 ],
      "url" : "http://t.co/ooH1M9G1",
      "expanded_url" : "http://www.bloomberg.com/news/2012-09-11/twitter-told-to-produce-protestor-s-posts-or-face-fine.html",
      "display_url" : "bloomberg.com/news/2012-09-1…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "245569221285789696",
  "text" : "“I can’t put Twitter or the little blue bird in jail, so the only way to punish is monetarily,” Sciarrino said. -- http://t.co/ooH1M9G1",
  "id" : 245569221285789696,
  "created_at" : "Tue Sep 11 17:07:19 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Probably Mat Honan",
      "screen_name" : "mat",
      "indices" : [ 46, 50 ],
      "id_str" : "11113",
      "id" : 11113
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 71 ],
      "url" : "http://t.co/ICLfZosh",
      "expanded_url" : "http://www.wired.com/gadgetlab/2012/09/cosmo-the-god-who-fell-to-earth/all/",
      "display_url" : "wired.com/gadgetlab/2012…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "245537161879904257",
  "text" : "Amazingly detailed story of Cosmo the God, by @mat http://t.co/ICLfZosh",
  "id" : 245537161879904257,
  "created_at" : "Tue Sep 11 14:59:55 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay Holler",
      "screen_name" : "jayholler",
      "indices" : [ 0, 10 ],
      "id_str" : "14110325",
      "id" : 14110325
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "245410866281988096",
  "geo" : {
  },
  "id_str" : "245412714812432385",
  "in_reply_to_user_id" : 14110325,
  "text" : "@jayholler Or maybe just at the best times?",
  "id" : 245412714812432385,
  "in_reply_to_status_id" : 245410866281988096,
  "created_at" : "Tue Sep 11 06:45:25 +0000 2012",
  "in_reply_to_screen_name" : "jayholler",
  "in_reply_to_user_id_str" : "14110325",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ScottieYahtzee",
      "screen_name" : "ScottieYahtzee",
      "indices" : [ 0, 15 ],
      "id_str" : "15486015",
      "id" : 15486015
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "245411063598825472",
  "geo" : {
  },
  "id_str" : "245412578149425152",
  "in_reply_to_user_id" : 15486015,
  "text" : "@ScottieYahtzee You win!",
  "id" : 245412578149425152,
  "in_reply_to_status_id" : 245411063598825472,
  "created_at" : "Tue Sep 11 06:44:52 +0000 2012",
  "in_reply_to_screen_name" : "ScottieYahtzee",
  "in_reply_to_user_id_str" : "15486015",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Culver",
      "screen_name" : "bahoo",
      "indices" : [ 0, 6 ],
      "id_str" : "13134132",
      "id" : 13134132
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "245411269820157952",
  "geo" : {
  },
  "id_str" : "245412533400371200",
  "in_reply_to_user_id" : 13134132,
  "text" : "@bahoo So close. It was mashed potato mittens.",
  "id" : 245412533400371200,
  "in_reply_to_status_id" : 245411269820157952,
  "created_at" : "Tue Sep 11 06:44:42 +0000 2012",
  "in_reply_to_screen_name" : "bahoo",
  "in_reply_to_user_id_str" : "13134132",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ingopixel",
      "screen_name" : "ingopixel",
      "indices" : [ 0, 10 ],
      "id_str" : "7943892",
      "id" : 7943892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "245411776320135168",
  "geo" : {
  },
  "id_str" : "245412283684118528",
  "in_reply_to_user_id" : 7943892,
  "text" : "@ingopixel You win!",
  "id" : 245412283684118528,
  "in_reply_to_status_id" : 245411776320135168,
  "created_at" : "Tue Sep 11 06:43:42 +0000 2012",
  "in_reply_to_screen_name" : "ingopixel",
  "in_reply_to_user_id_str" : "7943892",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John W. Solomon",
      "screen_name" : "JohnWrede",
      "indices" : [ 15, 25 ],
      "id_str" : "125733",
      "id" : 125733
    }, {
      "name" : "Rose Broome",
      "screen_name" : "rosical",
      "indices" : [ 30, 38 ],
      "id_str" : "140145169",
      "id" : 140145169
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 121 ],
      "url" : "http://t.co/aWXPKips",
      "expanded_url" : "http://flic.kr/p/d9Lyi1",
      "display_url" : "flic.kr/p/d9Lyi1"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.790833, -122.404001 ]
  },
  "id_str" : "245412232660389888",
  "text" : "8:36pm Meeting @johnwrede and @rosical, two new kindred spirits! Thanks for fun, drinks, and dinner! http://t.co/aWXPKips",
  "id" : 245412232660389888,
  "created_at" : "Tue Sep 11 06:43:30 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay Holler",
      "screen_name" : "jayholler",
      "indices" : [ 0, 10 ],
      "id_str" : "14110325",
      "id" : 14110325
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "245410226633859072",
  "geo" : {
  },
  "id_str" : "245410654440271872",
  "in_reply_to_user_id" : 14110325,
  "text" : "@jayholler You win!",
  "id" : 245410654440271872,
  "in_reply_to_status_id" : 245410226633859072,
  "created_at" : "Tue Sep 11 06:37:14 +0000 2012",
  "in_reply_to_screen_name" : "jayholler",
  "in_reply_to_user_id_str" : "14110325",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "245408523872239616",
  "text" : "What is the secret phrase?",
  "id" : 245408523872239616,
  "created_at" : "Tue Sep 11 06:28:46 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "245346191515189248",
  "text" : "New interview question: what's the average amount of Del Taco that we eat per day?",
  "id" : 245346191515189248,
  "created_at" : "Tue Sep 11 02:21:05 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Neilson",
      "screen_name" : "TheCulprit",
      "indices" : [ 0, 11 ],
      "id_str" : "6726182",
      "id" : 6726182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "245343644259860480",
  "geo" : {
  },
  "id_str" : "245345634796834817",
  "in_reply_to_user_id" : 6726182,
  "text" : "@TheCulprit Yeah, and maybe a wedgie if you get really lost.",
  "id" : 245345634796834817,
  "in_reply_to_status_id" : 245343644259860480,
  "created_at" : "Tue Sep 11 02:18:52 +0000 2012",
  "in_reply_to_screen_name" : "TheCulprit",
  "in_reply_to_user_id_str" : "6726182",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SuperBetter",
      "screen_name" : "SuperBetter",
      "indices" : [ 13, 25 ],
      "id_str" : "351204906",
      "id" : 351204906
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 84 ],
      "url" : "http://t.co/8deDRe3e",
      "expanded_url" : "http://4sq.com/PkCqtK",
      "display_url" : "4sq.com/PkCqtK"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7877398395, -122.4035295207 ]
  },
  "id_str" : "245345346190979073",
  "text" : "Meeting some @SuperBetter...ers. (@ Local Edition w/ 12 others) http://t.co/8deDRe3e",
  "id" : 245345346190979073,
  "created_at" : "Tue Sep 11 02:17:43 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "245340121883357184",
  "text" : "Idea: a map+directions app for walking that you kept in your pocket and it would buzz once when you need to turn right and twice for left.",
  "id" : 245340121883357184,
  "created_at" : "Tue Sep 11 01:56:57 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "christopher jones",
      "screen_name" : "cjlikearockstar",
      "indices" : [ 0, 16 ],
      "id_str" : "34383091",
      "id" : 34383091
    }, {
      "name" : "Jimmy James Hall",
      "screen_name" : "JimmyJameson",
      "indices" : [ 17, 30 ],
      "id_str" : "35141809",
      "id" : 35141809
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "245332026734039041",
  "geo" : {
  },
  "id_str" : "245334926814244864",
  "in_reply_to_user_id" : 34383091,
  "text" : "@cjlikearockstar @JimmyJameson Yeah! I'm in SF until tomorrow night... wanna come over on Fri night for fire pit times / hot robot and wine?",
  "id" : 245334926814244864,
  "in_reply_to_status_id" : 245332026734039041,
  "created_at" : "Tue Sep 11 01:36:19 +0000 2012",
  "in_reply_to_screen_name" : "cjlikearockstar",
  "in_reply_to_user_id_str" : "34383091",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 132 ],
      "url" : "http://t.co/Ehkotdmd",
      "expanded_url" : "http://francispedraza.com/airplane-mode",
      "display_url" : "francispedraza.com/airplane-mode"
    } ]
  },
  "geo" : {
  },
  "id_str" : "245328757009817600",
  "text" : "“The 1st priority is having priorities. The 2nd is removing distractions. The 3rd is entering a state of flow.” http://t.co/Ehkotdmd",
  "id" : 245328757009817600,
  "created_at" : "Tue Sep 11 01:11:48 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Swartz",
      "screen_name" : "aaronsw",
      "indices" : [ 43, 51 ],
      "id_str" : "2696831",
      "id" : 2696831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 93 ],
      "url" : "http://t.co/DdNNaWd5",
      "expanded_url" : "http://www.aaronsw.com/weblog/anders",
      "display_url" : "aaronsw.com/weblog/anders"
    } ]
  },
  "geo" : {
  },
  "id_str" : "245223108607344640",
  "text" : "More great thoughts and great writing from @aaronsw: “Confront reality.” http://t.co/DdNNaWd5",
  "id" : 245223108607344640,
  "created_at" : "Mon Sep 10 18:11:59 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tehgeekmeister",
      "screen_name" : "tehgeekmeister",
      "indices" : [ 0, 15 ],
      "id_str" : "6727082",
      "id" : 6727082
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "245208788569825280",
  "geo" : {
  },
  "id_str" : "245208972360036352",
  "in_reply_to_user_id" : 6727082,
  "text" : "@tehgeekmeister I’m traveling back and forth until I move here in a few months.",
  "id" : 245208972360036352,
  "in_reply_to_status_id" : 245208788569825280,
  "created_at" : "Mon Sep 10 17:15:49 +0000 2012",
  "in_reply_to_screen_name" : "tehgeekmeister",
  "in_reply_to_user_id_str" : "6727082",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 67 ],
      "url" : "https://t.co/o273ySDe",
      "expanded_url" : "https://www.sunrise.im/",
      "display_url" : "sunrise.im"
    } ]
  },
  "geo" : {
  },
  "id_str" : "245208496876965889",
  "text" : "After about a week, I’m pretty impressed with https://t.co/o273ySDe. They auto-included timing and travel directions from SFO to my hotel.",
  "id" : 245208496876965889,
  "created_at" : "Mon Sep 10 17:13:56 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.6164993793, -122.3915827292 ]
  },
  "id_str" : "245198352193560576",
  "text" : "I feel like HD Theroux whenever I pretend I'm not reading my Kindle on takeoff/landing. Except he'd probably still be reading paper books.",
  "id" : 245198352193560576,
  "created_at" : "Mon Sep 10 16:33:37 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.4492040805, -122.3020337867 ]
  },
  "id_str" : "245144202604843008",
  "text" : "Remember this secret phrase until later today: \"pineapple pants\".",
  "id" : 245144202604843008,
  "created_at" : "Mon Sep 10 12:58:27 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 47, 57 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 91 ],
      "url" : "http://t.co/agpgNgPL",
      "expanded_url" : "http://flic.kr/p/d98fkG",
      "display_url" : "flic.kr/p/d98fkG"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.608666, -122.306 ]
  },
  "id_str" : "245003654233485312",
  "text" : "8:36pm He's been patiently waiting all day for @kellianne to come home http://t.co/agpgNgPL",
  "id" : 245003654233485312,
  "created_at" : "Mon Sep 10 03:39:57 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagr.am\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 57 ],
      "url" : "http://t.co/9Nb6FG4F",
      "expanded_url" : "http://instagr.am/p/PVvilwo0FV/",
      "display_url" : "instagr.am/p/PVvilwo0FV/"
    } ]
  },
  "geo" : {
  },
  "id_str" : "244640709855027201",
  "text" : "8:36pm Eating corn in the bath tub.  http://t.co/9Nb6FG4F",
  "id" : 244640709855027201,
  "created_at" : "Sun Sep 09 03:37:45 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagr.am\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 57 ],
      "url" : "http://t.co/c1LKGWT1",
      "expanded_url" : "http://instagr.am/p/PVlZVgI0MA/",
      "display_url" : "instagr.am/p/PVlZVgI0MA/"
    } ]
  },
  "geo" : {
  },
  "id_str" : "244618694066573312",
  "text" : "In the vortex with Tavster and Viv.  http://t.co/c1LKGWT1",
  "id" : 244618694066573312,
  "created_at" : "Sun Sep 09 02:10:16 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagr.am\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 33 ],
      "url" : "http://t.co/9TMaZZUl",
      "expanded_url" : "http://instagr.am/p/PVW3P2I0OB/",
      "display_url" : "instagr.am/p/PVW3P2I0OB/"
    } ]
  },
  "geo" : {
  },
  "id_str" : "244586506742796288",
  "text" : "Party time.  http://t.co/9TMaZZUl",
  "id" : 244586506742796288,
  "created_at" : "Sun Sep 09 00:02:22 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagr.am\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 81 ],
      "url" : "http://t.co/qlomNtsG",
      "expanded_url" : "http://instagr.am/p/PUwU2go0I7/",
      "display_url" : "instagr.am/p/PUwU2go0I7/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6129882798, -122.306100768 ]
  },
  "id_str" : "244501792317124608",
  "text" : "Niko perched on windowsill with cookie  @ Katy's Corner Cafe http://t.co/qlomNtsG",
  "id" : 244501792317124608,
  "created_at" : "Sat Sep 08 18:25:44 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 80 ],
      "url" : "http://t.co/HfAcCPMV",
      "expanded_url" : "http://flic.kr/p/d7P2yU",
      "display_url" : "flic.kr/p/d7P2yU"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.608666, -122.306 ]
  },
  "id_str" : "244287683155853312",
  "text" : "8:36pm Looking for a good romantic comedy. Any suggestions? http://t.co/HfAcCPMV",
  "id" : 244287683155853312,
  "created_at" : "Sat Sep 08 04:14:56 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6154047175, -122.3199582674 ]
  },
  "id_str" : "243965983943974912",
  "text" : "I should be given a ticket or demerit of some sort for singing Nirvava and Nine Inch Nails at karaoke while sitting down.",
  "id" : 243965983943974912,
  "created_at" : "Fri Sep 07 06:56:37 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 74 ],
      "url" : "http://t.co/2zSIunhN",
      "expanded_url" : "http://flic.kr/p/d7itkE",
      "display_url" : "flic.kr/p/d7itkE"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.612, -122.317167 ]
  },
  "id_str" : "243927619127619584",
  "text" : "8:36pm Was fighting. Hopefully the worst is over now. http://t.co/2zSIunhN",
  "id" : 243927619127619584,
  "created_at" : "Fri Sep 07 04:24:11 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twitter Government",
      "screen_name" : "gov",
      "indices" : [ 3, 7 ],
      "id_str" : "222953824",
      "id" : 222953824
    }, {
      "name" : "Barack Obama",
      "screen_name" : "BarackObama",
      "indices" : [ 51, 63 ],
      "id_str" : "813286",
      "id" : 813286
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DNC2012",
      "indices" : [ 130, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "243910380395585536",
  "text" : "RT @gov: A new record political moment on Twitter: @barackobama drives 52,757 Tweets per minute. Over 9 million Tweets sent about #DNC2012.",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Barack Obama",
        "screen_name" : "BarackObama",
        "indices" : [ 42, 54 ],
        "id_str" : "813286",
        "id" : 813286
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "DNC2012",
        "indices" : [ 121, 129 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "243910024282374144",
    "text" : "A new record political moment on Twitter: @barackobama drives 52,757 Tweets per minute. Over 9 million Tweets sent about #DNC2012.",
    "id" : 243910024282374144,
    "created_at" : "Fri Sep 07 03:14:16 +0000 2012",
    "user" : {
      "name" : "Twitter Government",
      "screen_name" : "gov",
      "protected" : false,
      "id_str" : "222953824",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2284291316/xu1u3i11ugj03en53ujr_normal.png",
      "id" : 222953824,
      "verified" : true
    }
  },
  "id" : 243910380395585536,
  "created_at" : "Fri Sep 07 03:15:40 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 82 ],
      "url" : "http://t.co/KLmW31Q2",
      "expanded_url" : "http://4sq.com/QhetQ2",
      "display_url" : "4sq.com/QhetQ2"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.613929, -122.345453 ]
  },
  "id_str" : "243840081960525824",
  "text" : "Excited to be working again in my old hood. (@ Bedlam Coffee) http://t.co/KLmW31Q2",
  "id" : 243840081960525824,
  "created_at" : "Thu Sep 06 22:36:20 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Raffi Krikorian",
      "screen_name" : "raffi",
      "indices" : [ 0, 6 ],
      "id_str" : "8285392",
      "id" : 8285392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "243785552304951296",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6118486942, -122.3480169816 ]
  },
  "id_str" : "243786622053793792",
  "in_reply_to_user_id" : 8285392,
  "text" : "@raffi Yes you should! I'm in SF Mon+Tue and here in Seattle rest of week for the next month or so.",
  "id" : 243786622053793792,
  "in_reply_to_status_id" : 243785552304951296,
  "created_at" : "Thu Sep 06 19:03:54 +0000 2012",
  "in_reply_to_screen_name" : "raffi",
  "in_reply_to_user_id_str" : "8285392",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark",
      "screen_name" : "shinypb",
      "indices" : [ 0, 8 ],
      "id_str" : "13166",
      "id" : 13166
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "243784980046704640",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6118426835, -122.3480273521 ]
  },
  "id_str" : "243785913006702594",
  "in_reply_to_user_id" : 13166,
  "text" : "@shinypb Yup! It's still pretty small.",
  "id" : 243785913006702594,
  "in_reply_to_status_id" : 243784980046704640,
  "created_at" : "Thu Sep 06 19:01:05 +0000 2012",
  "in_reply_to_screen_name" : "shinypb",
  "in_reply_to_user_id_str" : "13166",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 114 ],
      "url" : "http://t.co/jpIEfetJ",
      "expanded_url" : "http://4sq.com/RGVClT",
      "display_url" : "4sq.com/RGVClT"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.611714, -122.347995 ]
  },
  "id_str" : "243784766984433664",
  "text" : "First day at the Seattle office! You can see my loft from here. (@ Twitter Seattle HQ) [pic]: http://t.co/jpIEfetJ",
  "id" : 243784766984433664,
  "created_at" : "Thu Sep 06 18:56:32 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6086263552, -122.306116173 ]
  },
  "id_str" : "243736016626778113",
  "text" : "Will Amazon announce a phone today?",
  "id" : 243736016626778113,
  "created_at" : "Thu Sep 06 15:42:49 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "allison kudla",
      "screen_name" : "allisonx",
      "indices" : [ 0, 9 ],
      "id_str" : "14047537",
      "id" : 14047537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "243587409286164480",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6087778854, -122.3058893626 ]
  },
  "id_str" : "243599919875751936",
  "in_reply_to_user_id" : 14047537,
  "text" : "@allisonx If so, I would be a member of said group. Though, airplane tv often makes me consider tv-reobtainment.",
  "id" : 243599919875751936,
  "in_reply_to_status_id" : 243587409286164480,
  "created_at" : "Thu Sep 06 06:42:01 +0000 2012",
  "in_reply_to_screen_name" : "allisonx",
  "in_reply_to_user_id_str" : "14047537",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Matsuno",
      "screen_name" : "sean",
      "indices" : [ 0, 5 ],
      "id_str" : "14346209",
      "id" : 14346209
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "243598556638892032",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6086163435, -122.305985383 ]
  },
  "id_str" : "243599367532060672",
  "in_reply_to_user_id" : 14346209,
  "text" : "@sean Good to know. Rockridge is top of our list, though haven't actually visited yet. Tokyo: awesome! I have family about an hour north.",
  "id" : 243599367532060672,
  "in_reply_to_status_id" : 243598556638892032,
  "created_at" : "Thu Sep 06 06:39:49 +0000 2012",
  "in_reply_to_screen_name" : "sean",
  "in_reply_to_user_id_str" : "14346209",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Maarten den Braber",
      "screen_name" : "mdbraber",
      "indices" : [ 0, 9 ],
      "id_str" : "9938952",
      "id" : 9938952
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "243595948322861057",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6086724416, -122.3059540298 ]
  },
  "id_str" : "243598305597222912",
  "in_reply_to_user_id" : 9938952,
  "text" : "@mdbraber Thanks! Yeah, loving it here so far...",
  "id" : 243598305597222912,
  "in_reply_to_status_id" : 243595948322861057,
  "created_at" : "Thu Sep 06 06:35:36 +0000 2012",
  "in_reply_to_screen_name" : "mdbraber",
  "in_reply_to_user_id_str" : "9938952",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyler LePard",
      "screen_name" : "tylepard",
      "indices" : [ 0, 9 ],
      "id_str" : "18297300",
      "id" : 18297300
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "243582918956552192",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6086785628, -122.3059584049 ]
  },
  "id_str" : "243598172830711808",
  "in_reply_to_user_id" : 18297300,
  "text" : "@tylepard Thank you! You too! We came by on Saturday. Where did you go this time?",
  "id" : 243598172830711808,
  "in_reply_to_status_id" : 243582918956552192,
  "created_at" : "Thu Sep 06 06:35:04 +0000 2012",
  "in_reply_to_screen_name" : "tylepard",
  "in_reply_to_user_id_str" : "18297300",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Matsuno",
      "screen_name" : "sean",
      "indices" : [ 0, 5 ],
      "id_str" : "14346209",
      "id" : 14346209
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "243591890518282240",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6089979103, -122.3056644761 ]
  },
  "id_str" : "243597830936219649",
  "in_reply_to_user_id" : 14346209,
  "text" : "@sean Yeah I quite like it, now that it's here. Always on time. Did you move for Twitter too? How's Oakland? We're considering it too.",
  "id" : 243597830936219649,
  "in_reply_to_status_id" : 243591890518282240,
  "created_at" : "Thu Sep 06 06:33:43 +0000 2012",
  "in_reply_to_screen_name" : "sean",
  "in_reply_to_user_id_str" : "14346209",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 118 ],
      "url" : "http://t.co/zjpdkia1",
      "expanded_url" : "http://flic.kr/p/d6Mvdh",
      "display_url" : "flic.kr/p/d6Mvdh"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.572, -122.297334 ]
  },
  "id_str" : "243582625355292672",
  "text" : "8:36pm Taking the light rail home after watching Bill Clinton's awesome speech on the flight home http://t.co/zjpdkia1",
  "id" : 243582625355292672,
  "created_at" : "Thu Sep 06 05:33:18 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tanner C",
      "screen_name" : "tannerc",
      "indices" : [ 0, 8 ],
      "id_str" : "9161482",
      "id" : 9161482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "243532140011208704",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.6173323974, -122.3813049702 ]
  },
  "id_str" : "243534101011906560",
  "in_reply_to_user_id" : 9161482,
  "text" : "@tannerc I'm happy to be here too. Gonna keep writing and thinking about habits as well.",
  "id" : 243534101011906560,
  "in_reply_to_status_id" : 243532140011208704,
  "created_at" : "Thu Sep 06 02:20:28 +0000 2012",
  "in_reply_to_screen_name" : "tannerc",
  "in_reply_to_user_id_str" : "9161482",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tanner C",
      "screen_name" : "tannerc",
      "indices" : [ 0, 8 ],
      "id_str" : "9161482",
      "id" : 9161482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "243528417356677120",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.6173587179, -122.3817163822 ]
  },
  "id_str" : "243531019406426112",
  "in_reply_to_user_id" : 9161482,
  "text" : "@tannerc Thanks! Working on what you see when you expand a tweet. And on the team that also just launched embedded timelines. And more!",
  "id" : 243531019406426112,
  "in_reply_to_status_id" : 243528417356677120,
  "created_at" : "Thu Sep 06 02:08:14 +0000 2012",
  "in_reply_to_screen_name" : "tannerc",
  "in_reply_to_user_id_str" : "9161482",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ʎǝʞɔıɥ ʇʇɐɯ",
      "screen_name" : "matthickey",
      "indices" : [ 0, 11 ],
      "id_str" : "8710082",
      "id" : 8710082
    }, {
      "name" : "Gabe Rivera",
      "screen_name" : "gaberivera",
      "indices" : [ 12, 23 ],
      "id_str" : "817288",
      "id" : 817288
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "243482268574830592",
  "geo" : {
  },
  "id_str" : "243490367033458689",
  "in_reply_to_user_id" : 8710082,
  "text" : "@matthickey @gaberivera I'm in the office for another hour or so... who do you want me to punch exactly?",
  "id" : 243490367033458689,
  "in_reply_to_status_id" : 243482268574830592,
  "created_at" : "Wed Sep 05 23:26:41 +0000 2012",
  "in_reply_to_screen_name" : "matthickey",
  "in_reply_to_user_id_str" : "8710082",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "allison kudla",
      "screen_name" : "allisonx",
      "indices" : [ 0, 9 ],
      "id_str" : "14047537",
      "id" : 14047537
    }, {
      "name" : "April Schiller",
      "screen_name" : "the_april",
      "indices" : [ 10, 20 ],
      "id_str" : "16644937",
      "id" : 16644937
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "243387093185867776",
  "geo" : {
  },
  "id_str" : "243409458238210048",
  "in_reply_to_user_id" : 14047537,
  "text" : "@allisonx @the_april Now that I work here I suppose it's part of my civic duty. But if it's an excuse to get a drink, I'll take it!",
  "id" : 243409458238210048,
  "in_reply_to_status_id" : 243387093185867776,
  "created_at" : "Wed Sep 05 18:05:11 +0000 2012",
  "in_reply_to_screen_name" : "allisonx",
  "in_reply_to_user_id_str" : "14047537",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sylvain Carle",
      "screen_name" : "froginthevalley",
      "indices" : [ 3, 19 ],
      "id_str" : "657693",
      "id" : 657693
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 97 ],
      "url" : "http://t.co/NOTmXEqf",
      "expanded_url" : "http://bit.ly/RLEIyr",
      "display_url" : "bit.ly/RLEIyr"
    } ]
  },
  "geo" : {
  },
  "id_str" : "243395076892532737",
  "text" : "RT @froginthevalley: Post your questions about Twitter embedded timelines at http://t.co/NOTmXEqf I will be monitoring this pretty closely.",
  "retweeted_status" : {
    "source" : "<a href=\"http://sites.google.com/site/yorufukurou/\" rel=\"nofollow\">YoruFukurou</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 56, 76 ],
        "url" : "http://t.co/NOTmXEqf",
        "expanded_url" : "http://bit.ly/RLEIyr",
        "display_url" : "bit.ly/RLEIyr"
      } ]
    },
    "geo" : {
    },
    "id_str" : "243392663452266496",
    "text" : "Post your questions about Twitter embedded timelines at http://t.co/NOTmXEqf I will be monitoring this pretty closely.",
    "id" : 243392663452266496,
    "created_at" : "Wed Sep 05 16:58:27 +0000 2012",
    "user" : {
      "name" : "Sylvain Carle",
      "screen_name" : "froginthevalley",
      "protected" : false,
      "id_str" : "657693",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838630046/4b82e286a659fae310012520f4f756bb_normal.png",
      "id" : 657693,
      "verified" : false
    }
  },
  "id" : 243395076892532737,
  "created_at" : "Wed Sep 05 17:08:03 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ximing Yu",
      "screen_name" : "ximyu",
      "indices" : [ 0, 6 ],
      "id_str" : "25930069",
      "id" : 25930069
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "243390049448775680",
  "geo" : {
  },
  "id_str" : "243390216918949889",
  "in_reply_to_user_id" : 25930069,
  "text" : "@ximyu Oops, you’re right.  :)",
  "id" : 243390216918949889,
  "in_reply_to_status_id" : 243390049448775680,
  "created_at" : "Wed Sep 05 16:48:44 +0000 2012",
  "in_reply_to_screen_name" : "ximyu",
  "in_reply_to_user_id_str" : "25930069",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tumblr.com/\" rel=\"nofollow\">Tumblr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 47 ],
      "url" : "http://t.co/ERca2g7a",
      "expanded_url" : "http://tmblr.co/ZQJvaySq1CaE",
      "display_url" : "tmblr.co/ZQJvaySq1CaE"
    } ]
  },
  "geo" : {
  },
  "id_str" : "243383480757653504",
  "text" : "Testing embedded tweets -  http://t.co/ERca2g7a",
  "id" : 243383480757653504,
  "created_at" : "Wed Sep 05 16:21:58 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 55, 63 ],
      "id_str" : "783214",
      "id" : 783214
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http://t.co/r1t87jmL",
      "expanded_url" : "http://blog.twitter.com/2012/09/more-tweets-across-web.html",
      "display_url" : "blog.twitter.com/2012/09/more-t…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "243381212364828672",
  "text" : "Currently witnessing my first launch by my new team at @twitter! You can now embed timelines in a more awesome way: http://t.co/r1t87jmL",
  "id" : 243381212364828672,
  "created_at" : "Wed Sep 05 16:12:57 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "allison kudla",
      "screen_name" : "allisonx",
      "indices" : [ 0, 9 ],
      "id_str" : "14047537",
      "id" : 14047537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 64 ],
      "url" : "https://t.co/K5962QgY",
      "expanded_url" : "https://twitter.com/allisonx/favorites",
      "display_url" : "twitter.com/allisonx/favor…"
    } ]
  },
  "in_reply_to_status_id_str" : "243366510729515008",
  "geo" : {
  },
  "id_str" : "243367343198203906",
  "in_reply_to_user_id" : 14047537,
  "text" : "@allisonx Is this what you're looking for? https://t.co/K5962QgY (it's linked from the side bar of your profile page)",
  "id" : 243367343198203906,
  "in_reply_to_status_id" : 243366510729515008,
  "created_at" : "Wed Sep 05 15:17:50 +0000 2012",
  "in_reply_to_screen_name" : "allisonx",
  "in_reply_to_user_id_str" : "14047537",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Next Web",
      "screen_name" : "TheNextWeb",
      "indices" : [ 3, 14 ],
      "id_str" : "10876852",
      "id" : 10876852
    }, {
      "name" : "Courtney Boyd Myers",
      "screen_name" : "CBM",
      "indices" : [ 108, 112 ],
      "id_str" : "17972431",
      "id" : 17972431
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 104 ],
      "url" : "http://t.co/f2CNz3qt",
      "expanded_url" : "http://tnw.to/e4Lb",
      "display_url" : "tnw.to/e4Lb"
    } ]
  },
  "geo" : {
  },
  "id_str" : "243349786248503296",
  "text" : "RT @TheNextWeb: Foursquare designer launches Sunrise, the new must-have daily email http://t.co/f2CNz3qt by @CBM",
  "retweeted_status" : {
    "source" : "<a href=\"http://spread.us\" rel=\"nofollow\">Spread The Next Web</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Courtney Boyd Myers",
        "screen_name" : "CBM",
        "indices" : [ 92, 96 ],
        "id_str" : "17972431",
        "id" : 17972431
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 68, 88 ],
        "url" : "http://t.co/f2CNz3qt",
        "expanded_url" : "http://tnw.to/e4Lb",
        "display_url" : "tnw.to/e4Lb"
      } ]
    },
    "geo" : {
    },
    "id_str" : "243333257947672576",
    "text" : "Foursquare designer launches Sunrise, the new must-have daily email http://t.co/f2CNz3qt by @CBM",
    "id" : 243333257947672576,
    "created_at" : "Wed Sep 05 13:02:24 +0000 2012",
    "user" : {
      "name" : "The Next Web",
      "screen_name" : "TheNextWeb",
      "protected" : false,
      "id_str" : "10876852",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1574591465/THE_new-twitter-avatar-working_normal.jpg",
      "id" : 10876852,
      "verified" : true
    }
  },
  "id" : 243349786248503296,
  "created_at" : "Wed Sep 05 14:08:04 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "stephdub",
      "screen_name" : "stephdub",
      "indices" : [ 0, 9 ],
      "id_str" : "14936359",
      "id" : 14936359
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "243230887414747136",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7873061607, -122.4111344112 ]
  },
  "id_str" : "243347456413298688",
  "in_reply_to_user_id" : 14936359,
  "text" : "@stephdub So true.",
  "id" : 243347456413298688,
  "in_reply_to_status_id" : 243230887414747136,
  "created_at" : "Wed Sep 05 13:58:49 +0000 2012",
  "in_reply_to_screen_name" : "stephdub",
  "in_reply_to_user_id_str" : "14936359",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://bufferapp.com\" rel=\"nofollow\">Buffer</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "243254924392165376",
  "text" : "What do you wish you knew about behavior change, Twitter, or the universe? I'll research for you and give you my best answer.",
  "id" : 243254924392165376,
  "created_at" : "Wed Sep 05 07:51:08 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twitter Government",
      "screen_name" : "gov",
      "indices" : [ 3, 7 ],
      "id_str" : "222953824",
      "id" : 222953824
    }, {
      "name" : "Michelle Obama",
      "screen_name" : "MichelleObama",
      "indices" : [ 17, 31 ],
      "id_str" : "409486555",
      "id" : 409486555
    }, {
      "name" : "Mitt Romney",
      "screen_name" : "MittRomney",
      "indices" : [ 84, 95 ],
      "id_str" : "50055701",
      "id" : 50055701
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GOP2012",
      "indices" : [ 101, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "243195975106170881",
  "text" : "RT @gov: The end @MichelleObama's speech drove a higher Tweets-per-minute peak than @MittRomney's at #GOP2012. 28,003 vs. 14,289 for the ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Michelle Obama",
        "screen_name" : "MichelleObama",
        "indices" : [ 8, 22 ],
        "id_str" : "409486555",
        "id" : 409486555
      }, {
        "name" : "Mitt Romney",
        "screen_name" : "MittRomney",
        "indices" : [ 75, 86 ],
        "id_str" : "50055701",
        "id" : 50055701
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GOP2012",
        "indices" : [ 92, 100 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "243184479299051521",
    "text" : "The end @MichelleObama's speech drove a higher Tweets-per-minute peak than @MittRomney's at #GOP2012. 28,003 vs. 14,289 for the Gov.",
    "id" : 243184479299051521,
    "created_at" : "Wed Sep 05 03:11:12 +0000 2012",
    "user" : {
      "name" : "Twitter Government",
      "screen_name" : "gov",
      "protected" : false,
      "id_str" : "222953824",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2284291316/xu1u3i11ugj03en53ujr_normal.png",
      "id" : 222953824,
      "verified" : true
    }
  },
  "id" : 243195975106170881,
  "created_at" : "Wed Sep 05 03:56:53 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "dnc2012",
      "indices" : [ 35, 43 ]
    } ],
    "urls" : [ {
      "indices" : [ 61, 81 ],
      "url" : "http://t.co/UEEt502b",
      "expanded_url" : "http://flic.kr/p/d69NmU",
      "display_url" : "flic.kr/p/d69NmU"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.787166, -122.411167 ]
  },
  "id_str" : "243191848523407360",
  "text" : "8:36pm Catching whatever's left of #dnc2012 in my hotel room http://t.co/UEEt502b",
  "id" : 243191848523407360,
  "created_at" : "Wed Sep 05 03:40:29 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zeke Miller",
      "screen_name" : "ZekeJMiller",
      "indices" : [ 3, 15 ],
      "id_str" : "21316253",
      "id" : 21316253
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "243181357986099200",
  "text" : "RT @ZekeJMiller: FLOTUS: \" I have seen firsthand that being president doesn’t change who you are – it reveals who you are.\"",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "243179058605744129",
    "text" : "FLOTUS: \" I have seen firsthand that being president doesn’t change who you are – it reveals who you are.\"",
    "id" : 243179058605744129,
    "created_at" : "Wed Sep 05 02:49:40 +0000 2012",
    "user" : {
      "name" : "Zeke Miller",
      "screen_name" : "ZekeJMiller",
      "protected" : false,
      "id_str" : "21316253",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1365129853/P1030150_normal.JPG",
      "id" : 21316253,
      "verified" : false
    }
  },
  "id" : 243181357986099200,
  "created_at" : "Wed Sep 05 02:58:48 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lynn Collette",
      "screen_name" : "sfposhy",
      "indices" : [ 0, 8 ],
      "id_str" : "268453413",
      "id" : 268453413
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "crossingfingers",
      "indices" : [ 113, 129 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "243176267153821696",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7864797459, -122.4147495783 ]
  },
  "id_str" : "243180080887640065",
  "in_reply_to_user_id" : 268453413,
  "text" : "@sfposhy That just happened to us 2 days ago. Peaked at 103.5. Scary. Then he was back to normal in the morning. #crossingfingers",
  "id" : 243180080887640065,
  "in_reply_to_status_id" : 243176267153821696,
  "created_at" : "Wed Sep 05 02:53:44 +0000 2012",
  "in_reply_to_screen_name" : "sfposhy",
  "in_reply_to_user_id_str" : "268453413",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mitt Romney",
      "screen_name" : "MittRomney",
      "indices" : [ 0, 11 ],
      "id_str" : "50055701",
      "id" : 50055701
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "243172671532187648",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7864529129, -122.4147000501 ]
  },
  "id_str" : "243178526545678336",
  "in_reply_to_user_id" : 50055701,
  "text" : "@MittRomney Why do you have to be such a jerk sometimes?",
  "id" : 243178526545678336,
  "in_reply_to_status_id" : 243172671532187648,
  "created_at" : "Wed Sep 05 02:47:33 +0000 2012",
  "in_reply_to_screen_name" : "MittRomney",
  "in_reply_to_user_id_str" : "50055701",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anina Bennett",
      "screen_name" : "bigredhair",
      "indices" : [ 3, 14 ],
      "id_str" : "15666519",
      "id" : 15666519
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "243176646562177025",
  "text" : "RT @bigredhair: Guys: If you've ever gotten mad at a woman who didn't want to talk to you, READ THIS. Because this is how SHE felt. http ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.facebook.com/twitter\" rel=\"nofollow\">Facebook</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 136 ],
        "url" : "http://t.co/RvPiompp",
        "expanded_url" : "http://fb.me/SlVuKDft",
        "display_url" : "fb.me/SlVuKDft"
      } ]
    },
    "geo" : {
    },
    "id_str" : "243142703775350784",
    "text" : "Guys: If you've ever gotten mad at a woman who didn't want to talk to you, READ THIS. Because this is how SHE felt. http://t.co/RvPiompp",
    "id" : 243142703775350784,
    "created_at" : "Wed Sep 05 00:25:12 +0000 2012",
    "user" : {
      "name" : "Anina Bennett",
      "screen_name" : "bigredhair",
      "protected" : false,
      "id_str" : "15666519",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1854761305/qpilot_square-small_normal.jpg",
      "id" : 15666519,
      "verified" : false
    }
  },
  "id" : 243176646562177025,
  "created_at" : "Wed Sep 05 02:40:05 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7861225295, -122.4147776976 ]
  },
  "id_str" : "243171510485921793",
  "text" : "Do you wish life were more or less predictable? Why?",
  "id" : 243171510485921793,
  "created_at" : "Wed Sep 05 02:19:40 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carinna Tarvin",
      "screen_name" : "carinnatarvin",
      "indices" : [ 0, 14 ],
      "id_str" : "20833838",
      "id" : 20833838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "243155204416102400",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7792393773, -122.4234802337 ]
  },
  "id_str" : "243160120907943936",
  "in_reply_to_user_id" : 20833838,
  "text" : "@carinnatarvin Yup. Embrace it.",
  "id" : 243160120907943936,
  "in_reply_to_status_id" : 243155204416102400,
  "created_at" : "Wed Sep 05 01:34:25 +0000 2012",
  "in_reply_to_screen_name" : "carinnatarvin",
  "in_reply_to_user_id_str" : "20833838",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.779266245, -122.4235133742 ]
  },
  "id_str" : "243158598807605248",
  "text" : "I'm in a good mood.",
  "id" : 243158598807605248,
  "created_at" : "Wed Sep 05 01:28:22 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carinna Tarvin",
      "screen_name" : "carinnatarvin",
      "indices" : [ 0, 14 ],
      "id_str" : "20833838",
      "id" : 20833838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 139 ],
      "url" : "http://t.co/6FC2zOrC",
      "expanded_url" : "http://www.girlswhocode.com/",
      "display_url" : "girlswhocode.com"
    } ]
  },
  "in_reply_to_status_id_str" : "243114077960937472",
  "geo" : {
  },
  "id_str" : "243127473242513408",
  "in_reply_to_user_id" : 20833838,
  "text" : "@carinnatarvin It's an awesome post. Will you leave in the middle bit about agile software development? Speaking of... http://t.co/6FC2zOrC",
  "id" : 243127473242513408,
  "in_reply_to_status_id" : 243114077960937472,
  "created_at" : "Tue Sep 04 23:24:41 +0000 2012",
  "in_reply_to_screen_name" : "carinnatarvin",
  "in_reply_to_user_id_str" : "20833838",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian Chan",
      "screen_name" : "chanian",
      "indices" : [ 0, 8 ],
      "id_str" : "22891211",
      "id" : 22891211
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 66 ],
      "url" : "http://t.co/3hvSznoE",
      "expanded_url" : "http://face.com",
      "display_url" : "face.com"
    } ]
  },
  "in_reply_to_status_id_str" : "243124692821614592",
  "geo" : {
  },
  "id_str" : "243125322717990912",
  "in_reply_to_user_id" : 22891211,
  "text" : "@chanian That's awesome. Did you ever use the http://t.co/3hvSznoE API? How does this compare?",
  "id" : 243125322717990912,
  "in_reply_to_status_id" : 243124692821614592,
  "created_at" : "Tue Sep 04 23:16:08 +0000 2012",
  "in_reply_to_screen_name" : "chanian",
  "in_reply_to_user_id_str" : "22891211",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amit superamit Gupta",
      "screen_name" : "superamit",
      "indices" : [ 17, 27 ],
      "id_str" : "10609",
      "id" : 10609
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 129 ],
      "url" : "http://t.co/vbwN7xsY",
      "expanded_url" : "http://tumblr.amitgupta.com/post/30874722605/with-aml-eventual-recurrence-relapse-after",
      "display_url" : "tumblr.amitgupta.com/post/308747226…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "243075161073528833",
  "text" : "I’m so glad that @superamit is alive. Thank you for reminding us by example to use our remaining lives well. http://t.co/vbwN7xsY",
  "id" : 243075161073528833,
  "created_at" : "Tue Sep 04 19:56:49 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coursera",
      "screen_name" : "coursera",
      "indices" : [ 28, 37 ],
      "id_str" : "352053266",
      "id" : 352053266
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 139 ],
      "url" : "https://t.co/nmdFZ0ty",
      "expanded_url" : "https://www.coursera.org/course/progfun",
      "display_url" : "coursera.org/course/progfun"
    } ]
  },
  "geo" : {
  },
  "id_str" : "243047760348192768",
  "text" : "I just signed up for a free @coursera online class: Functional Programming Principles in Scala. Want to learn it too? https://t.co/nmdFZ0ty",
  "id" : 243047760348192768,
  "created_at" : "Tue Sep 04 18:07:56 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Swartz",
      "screen_name" : "aaronsw",
      "indices" : [ 100, 108 ],
      "id_str" : "2696831",
      "id" : 2696831
    }, {
      "name" : "Amy Jo Kim",
      "screen_name" : "amyjokim",
      "indices" : [ 114, 123 ],
      "id_str" : "780991",
      "id" : 780991
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 95 ],
      "url" : "http://t.co/zFTU2X2L",
      "expanded_url" : "http://bit.ly/RhzpWY",
      "display_url" : "bit.ly/RhzpWY"
    } ]
  },
  "in_reply_to_status_id_str" : "243034970736689152",
  "geo" : {
  },
  "id_str" : "243039968254128128",
  "in_reply_to_user_id" : 780991,
  "text" : "Great post on leaning into the pain (physical and psychological). Read it! http://t.co/zFTU2X2L /by @aaronsw /via @amyjokim",
  "id" : 243039968254128128,
  "in_reply_to_status_id" : 243034970736689152,
  "created_at" : "Tue Sep 04 17:36:58 +0000 2012",
  "in_reply_to_screen_name" : "amyjokim",
  "in_reply_to_user_id_str" : "780991",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mihow",
      "screen_name" : "mihow",
      "indices" : [ 0, 6 ],
      "id_str" : "764757",
      "id" : 764757
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "243031244441526272",
  "geo" : {
  },
  "id_str" : "243032534835941377",
  "in_reply_to_user_id" : 764757,
  "text" : "@mihow Definitely planning to relocate in the next couple months.  This isn’t ideal.",
  "id" : 243032534835941377,
  "in_reply_to_status_id" : 243031244441526272,
  "created_at" : "Tue Sep 04 17:07:26 +0000 2012",
  "in_reply_to_screen_name" : "mihow",
  "in_reply_to_user_id_str" : "764757",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Wang",
      "screen_name" : "brianmwang",
      "indices" : [ 0, 11 ],
      "id_str" : "93478440",
      "id" : 93478440
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "243029233067249665",
  "geo" : {
  },
  "id_str" : "243032417592541185",
  "in_reply_to_user_id" : 93478440,
  "text" : "@brianmwang Yeah, until I move early 2013. But probably won’t be every week.",
  "id" : 243032417592541185,
  "in_reply_to_status_id" : 243029233067249665,
  "created_at" : "Tue Sep 04 17:06:58 +0000 2012",
  "in_reply_to_screen_name" : "brianmwang",
  "in_reply_to_user_id_str" : "93478440",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Uber",
      "screen_name" : "Uber",
      "indices" : [ 108, 113 ],
      "id_str" : "19103481",
      "id" : 19103481
    }, {
      "name" : "Virgin America",
      "screen_name" : "VirginAmerica",
      "indices" : [ 118, 132 ],
      "id_str" : "12101862",
      "id" : 12101862
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "243028953755951104",
  "text" : "Door-to-door commute time from my house in Seattle to office in SF is 4hr 52min. Not too bad actually. /thx @uber and @VirginAmerica",
  "id" : 243028953755951104,
  "created_at" : "Tue Sep 04 16:53:12 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 141 ],
      "url" : "http://t.co/3DtUJyaS",
      "expanded_url" : "http://4sq.com/O8plF2",
      "display_url" : "4sq.com/O8plF2"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.4436465828, -122.3025941849 ]
  },
  "id_str" : "242955151688744960",
  "text" : "Seattle -&gt; San Francisco today and tomorrow. Good morning! (@ Seattle-Tacoma International Airport (SEA) w/ 9 others) http://t.co/3DtUJyaS",
  "id" : 242955151688744960,
  "created_at" : "Tue Sep 04 11:59:56 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagr.am\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 90 ],
      "url" : "http://t.co/8nNwN3qu",
      "expanded_url" : "http://instagr.am/p/PI37_4o0FS/",
      "display_url" : "instagr.am/p/PI37_4o0FS/"
    } ]
  },
  "geo" : {
  },
  "id_str" : "242829757882982400",
  "text" : "8:36pm Niko is feeling much better today. This is his \"cheese!\" face  http://t.co/8nNwN3qu",
  "id" : 242829757882982400,
  "created_at" : "Tue Sep 04 03:41:40 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "harryh",
      "screen_name" : "harryh",
      "indices" : [ 0, 7 ],
      "id_str" : "4558",
      "id" : 4558
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "242741661455769600",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.608972597, -122.306366712 ]
  },
  "id_str" : "242749058387697664",
  "in_reply_to_user_id" : 4558,
  "text" : "@harryh Cool! I'll be in tomorrow night. Any plans yet?",
  "id" : 242749058387697664,
  "in_reply_to_status_id" : 242741661455769600,
  "created_at" : "Mon Sep 03 22:21:00 +0000 2012",
  "in_reply_to_screen_name" : "harryh",
  "in_reply_to_user_id_str" : "4558",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anti-Joke Cat",
      "screen_name" : "AntiJokeCat",
      "indices" : [ 3, 15 ],
      "id_str" : "361965946",
      "id" : 361965946
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "242748541074808833",
  "text" : "RT @AntiJokeCat: You know what makes me smile? Facial muscles.",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.hootsuite.com\" rel=\"nofollow\">HootSuite</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "242738821521874944",
    "text" : "You know what makes me smile? Facial muscles.",
    "id" : 242738821521874944,
    "created_at" : "Mon Sep 03 21:40:19 +0000 2012",
    "user" : {
      "name" : "Anti-Joke Cat",
      "screen_name" : "AntiJokeCat",
      "protected" : false,
      "id_str" : "361965946",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3038657495/3d2f325c92060a35e7ac8c697c57d8d4_normal.jpeg",
      "id" : 361965946,
      "verified" : false
    }
  },
  "id" : 242748541074808833,
  "created_at" : "Mon Sep 03 22:18:56 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sara Haider",
      "screen_name" : "pandemona",
      "indices" : [ 17, 27 ],
      "id_str" : "18337283",
      "id" : 18337283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 80 ],
      "url" : "http://t.co/gjrA6JId",
      "expanded_url" : "http://techcrunch.com/2012/09/03/twitter-bets-on-girls-who-code/",
      "display_url" : "techcrunch.com/2012/09/03/twi…"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6139208815, -122.304348741 ]
  },
  "id_str" : "242724615242276864",
  "text" : "This is cool. RT @pandemona: Twitter Bets On Girls Who Code http://t.co/gjrA6JId",
  "id" : 242724615242276864,
  "created_at" : "Mon Sep 03 20:43:52 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave McClure",
      "screen_name" : "davemcclure",
      "indices" : [ 0, 12 ],
      "id_str" : "1081",
      "id" : 1081
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "242675054402482176",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6131896582, -122.3086720706 ]
  },
  "id_str" : "242719026734850049",
  "in_reply_to_user_id" : 1081,
  "text" : "@davemcclure I feel like moderate discourse is out there, it just has a low CTR.",
  "id" : 242719026734850049,
  "in_reply_to_status_id" : 242675054402482176,
  "created_at" : "Mon Sep 03 20:21:40 +0000 2012",
  "in_reply_to_screen_name" : "davemcclure",
  "in_reply_to_user_id_str" : "1081",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6085632667, -122.3063099665 ]
  },
  "id_str" : "242659908250636288",
  "text" : "SO excited to cancel my $550/mo $4000-deductible private plan insurance that didn't even include vision or dental.",
  "id" : 242659908250636288,
  "created_at" : "Mon Sep 03 16:26:45 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagr.am\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 83 ],
      "url" : "http://t.co/u87drvR8",
      "expanded_url" : "http://instagr.am/p/PGTsCxI0Jb/",
      "display_url" : "instagr.am/p/PGTsCxI0Jb/"
    } ]
  },
  "geo" : {
  },
  "id_str" : "242468903312293889",
  "text" : "8:36pm A sick Niko means more iPad time, and sandwiches in bed http://t.co/u87drvR8",
  "id" : 242468903312293889,
  "created_at" : "Mon Sep 03 03:47:46 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagr.am\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niko Benson",
      "screen_name" : "nikobenson",
      "indices" : [ 5, 16 ],
      "id_str" : "142467448",
      "id" : 142467448
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 56 ],
      "url" : "http://t.co/h5ArLkBo",
      "expanded_url" : "http://instagr.am/p/PGJn_wI0B4/",
      "display_url" : "instagr.am/p/PGJn_wI0B4/"
    } ]
  },
  "geo" : {
  },
  "id_str" : "242446377957863425",
  "text" : "Poor @nikobenson has a 102 fever... http://t.co/h5ArLkBo",
  "id" : 242446377957863425,
  "created_at" : "Mon Sep 03 02:18:15 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Willo O'Brien",
      "screen_name" : "WilloToons",
      "indices" : [ 22, 33 ],
      "id_str" : "772386",
      "id" : 772386
    }, {
      "name" : "Laura Gluhanich",
      "screen_name" : "LauraGlu",
      "indices" : [ 80, 89 ],
      "id_str" : "9428232",
      "id" : 9428232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 130 ],
      "url" : "http://t.co/zO2MOvx5",
      "expanded_url" : "http://therumpus.net/2012/09/knocked-over-on-biology-magical-thinking-and-choice/",
      "display_url" : "therumpus.net/2012/09/knocke…"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6087380713, -122.3061283306 ]
  },
  "id_str" : "242411410687131648",
  "text" : "Agreed. Read this! RT @WilloToons: Wow. This essay is incredible. A must read. “@LauraGlu: choice is power. - http://t.co/zO2MOvx5”",
  "id" : 242411410687131648,
  "created_at" : "Sun Sep 02 23:59:18 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 39, 47 ],
      "id_str" : "783214",
      "id" : 783214
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 128 ],
      "url" : "http://t.co/9Ms0CWyQ",
      "expanded_url" : "http://www.nytimes.com/2012/09/03/technology/twitter-chief-lawyer-alexander-macgillivray-defender-free-speech.html?_r=2&pagewanted=all",
      "display_url" : "nytimes.com/2012/09/03/tec…"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6086400869, -122.3061510456 ]
  },
  "id_str" : "242402672962043905",
  "text" : "One of the reasons I wanted to work at @Twitter was because of their work to protect free speech this much: http://t.co/9Ms0CWyQ",
  "id" : 242402672962043905,
  "created_at" : "Sun Sep 02 23:24:35 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ashton kutcher",
      "screen_name" : "aplusk",
      "indices" : [ 74, 81 ],
      "id_str" : "19058681",
      "id" : 19058681
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 68 ],
      "url" : "http://t.co/AhRGU9s2",
      "expanded_url" : "http://bit.ly/OCuMIX",
      "display_url" : "bit.ly/OCuMIX"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6128836768, -122.3060141691 ]
  },
  "id_str" : "242394526977777665",
  "text" : "1-100 spoken by someone of that age. Beautiful. http://t.co/AhRGU9s2 /via @aplusk",
  "id" : 242394526977777665,
  "created_at" : "Sun Sep 02 22:52:13 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.613237435, -122.3059699965 ]
  },
  "id_str" : "242390412382322689",
  "text" : "Just met my doppelgänger at my address on 20th Ave *E*. He was nice enough to hold my first paycheck for me.",
  "id" : 242390412382322689,
  "created_at" : "Sun Sep 02 22:35:52 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Budge",
      "screen_name" : "budge",
      "indices" : [ 3, 9 ],
      "id_str" : "286384512",
      "id" : 286384512
    }, {
      "name" : "Health Month",
      "screen_name" : "healthmonth",
      "indices" : [ 64, 76 ],
      "id_str" : "154236895",
      "id" : 154236895
    }, {
      "name" : "Sessions",
      "screen_name" : "joinsessions",
      "indices" : [ 98, 111 ],
      "id_str" : "360907906",
      "id" : 360907906
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 52 ],
      "url" : "http://t.co/tQ3fbBJT",
      "expanded_url" : "http://blog.habitlabs.com/post/30746149132/so-long",
      "display_url" : "blog.habitlabs.com/post/307461491…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "242354625544585216",
  "text" : "RT @budge: So long, my friends! http://t.co/tQ3fbBJT (check out @healthmonth, @liftworldwide, and @joinsessions for continued health-imp ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Health Month",
        "screen_name" : "healthmonth",
        "indices" : [ 53, 65 ],
        "id_str" : "154236895",
        "id" : 154236895
      }, {
        "name" : "Sessions",
        "screen_name" : "joinsessions",
        "indices" : [ 87, 100 ],
        "id_str" : "360907906",
        "id" : 360907906
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 21, 41 ],
        "url" : "http://t.co/tQ3fbBJT",
        "expanded_url" : "http://blog.habitlabs.com/post/30746149132/so-long",
        "display_url" : "blog.habitlabs.com/post/307461491…"
      } ]
    },
    "geo" : {
    },
    "id_str" : "242354233574301696",
    "text" : "So long, my friends! http://t.co/tQ3fbBJT (check out @healthmonth, @liftworldwide, and @joinsessions for continued health-improvement needs)",
    "id" : 242354233574301696,
    "created_at" : "Sun Sep 02 20:12:06 +0000 2012",
    "user" : {
      "name" : "Budge",
      "screen_name" : "budge",
      "protected" : false,
      "id_str" : "286384512",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1399066235/budge-snail_normal.png",
      "id" : 286384512,
      "verified" : false
    }
  },
  "id" : 242354625544585216,
  "created_at" : "Sun Sep 02 20:13:40 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twitter Government",
      "screen_name" : "gov",
      "indices" : [ 3, 7 ],
      "id_str" : "222953824",
      "id" : 222953824
    }, {
      "name" : "Barack Obama",
      "screen_name" : "BarackObama",
      "indices" : [ 19, 31 ],
      "id_str" : "813286",
      "id" : 813286
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "242289765821607937",
  "text" : "RT @gov: BREAKING: @BarackObama's \"This seat's taken\" Tweet was the most Retweeted Tweet of the Republican National Convention. https:// ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Barack Obama",
        "screen_name" : "BarackObama",
        "indices" : [ 10, 22 ],
        "id_str" : "813286",
        "id" : 813286
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 119, 140 ],
        "url" : "https://t.co/RriDDHmY",
        "expanded_url" : "https://twitter.com/BarackObama/status/241392153148915712",
        "display_url" : "twitter.com/BarackObama/st…"
      } ]
    },
    "geo" : {
    },
    "id_str" : "242289121287098369",
    "text" : "BREAKING: @BarackObama's \"This seat's taken\" Tweet was the most Retweeted Tweet of the Republican National Convention. https://t.co/RriDDHmY",
    "id" : 242289121287098369,
    "created_at" : "Sun Sep 02 15:53:22 +0000 2012",
    "user" : {
      "name" : "Twitter Government",
      "screen_name" : "gov",
      "protected" : false,
      "id_str" : "222953824",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2284291316/xu1u3i11ugj03en53ujr_normal.png",
      "id" : 222953824,
      "verified" : true
    }
  },
  "id" : 242289765821607937,
  "created_at" : "Sun Sep 02 15:55:56 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Ward",
      "screen_name" : "BenWard",
      "indices" : [ 0, 8 ],
      "id_str" : "12249",
      "id" : 12249
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "242220115058368513",
  "geo" : {
  },
  "id_str" : "242289436740710400",
  "in_reply_to_user_id" : 12249,
  "text" : "@BenWard Awesome post! I want to start writing more again too…",
  "id" : 242289436740710400,
  "in_reply_to_status_id" : 242220115058368513,
  "created_at" : "Sun Sep 02 15:54:37 +0000 2012",
  "in_reply_to_screen_name" : "BenWard",
  "in_reply_to_user_id_str" : "12249",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Ward",
      "screen_name" : "BenWard",
      "indices" : [ 3, 11 ],
      "id_str" : "12249",
      "id" : 12249
    }, {
      "name" : "Anti-Buster",
      "screen_name" : "busterbenson",
      "indices" : [ 13, 26 ],
      "id_str" : "1024917050",
      "id" : 1024917050
    }, {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 74, 82 ],
      "id_str" : "783214",
      "id" : 783214
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "242287530207232000",
  "text" : "RT @BenWard: @busterbenson Started thinking over why I rarely write about @twitter. Turned into why I rarely write. I wrote it down: htt ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Anti-Buster",
        "screen_name" : "busterbenson",
        "indices" : [ 0, 13 ],
        "id_str" : "1024917050",
        "id" : 1024917050
      }, {
        "name" : "Twitter",
        "screen_name" : "twitter",
        "indices" : [ 61, 69 ],
        "id_str" : "783214",
        "id" : 783214
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 120, 140 ],
        "url" : "http://t.co/BKQFNOh8",
        "expanded_url" : "http://benward.me/blog/exhausperation",
        "display_url" : "benward.me/blog/exhausper…"
      } ]
    },
    "in_reply_to_status_id_str" : "241708391901310977",
    "geo" : {
    },
    "id_str" : "242220115058368513",
    "in_reply_to_user_id" : 2185,
    "text" : "@busterbenson Started thinking over why I rarely write about @twitter. Turned into why I rarely write. I wrote it down: http://t.co/BKQFNOh8",
    "id" : 242220115058368513,
    "in_reply_to_status_id" : 241708391901310977,
    "created_at" : "Sun Sep 02 11:19:10 +0000 2012",
    "in_reply_to_screen_name" : "buster",
    "in_reply_to_user_id_str" : "2185",
    "user" : {
      "name" : "Ben Ward",
      "screen_name" : "BenWard",
      "protected" : false,
      "id_str" : "12249",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1409204408/2011_normal.png",
      "id" : 12249,
      "verified" : false
    }
  },
  "id" : 242287530207232000,
  "created_at" : "Sun Sep 02 15:47:03 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 60, 70 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 101 ],
      "url" : "http://t.co/RM7cVycC",
      "expanded_url" : "http://flic.kr/p/d43VnA",
      "display_url" : "flic.kr/p/d43VnA"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.608833, -122.306167 ]
  },
  "id_str" : "242108838923354113",
  "text" : "8:36pm Explaining Dr Who ep 6-8 \"A Good Man Goes To War\" to @kellianne. So good! http://t.co/RM7cVycC",
  "id" : 242108838923354113,
  "created_at" : "Sun Sep 02 03:57:00 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gretchen Rubin",
      "screen_name" : "gretchenrubin",
      "indices" : [ 3, 17 ],
      "id_str" : "14289835",
      "id" : 14289835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "242100448503422976",
  "text" : "RT @gretchenrubin: Secret of Adulthood: I can choose what I do, but I can't choose what I LIKE to do.",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "242091487318392832",
    "text" : "Secret of Adulthood: I can choose what I do, but I can't choose what I LIKE to do.",
    "id" : 242091487318392832,
    "created_at" : "Sun Sep 02 02:48:03 +0000 2012",
    "user" : {
      "name" : "Gretchen Rubin",
      "screen_name" : "gretchenrubin",
      "protected" : false,
      "id_str" : "14289835",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1436632135/Gretchenonphone_normal.JPG",
      "id" : 14289835,
      "verified" : true
    }
  },
  "id" : 242100448503422976,
  "created_at" : "Sun Sep 02 03:23:39 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "megan finley",
      "screen_name" : "meganfinley",
      "indices" : [ 0, 12 ],
      "id_str" : "15330946",
      "id" : 15330946
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "242089976811094016",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6086927252, -122.3061766942 ]
  },
  "id_str" : "242100233415311360",
  "in_reply_to_user_id" : 15330946,
  "text" : "@meganfinley Which season are you on? I think it was season 5 (of the new version) that got way slicker. Didn't like it at first...",
  "id" : 242100233415311360,
  "in_reply_to_status_id" : 242089976811094016,
  "created_at" : "Sun Sep 02 03:22:48 +0000 2012",
  "in_reply_to_screen_name" : "meganfinley",
  "in_reply_to_user_id_str" : "15330946",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amy Jo Kim",
      "screen_name" : "amyjokim",
      "indices" : [ 0, 9 ],
      "id_str" : "780991",
      "id" : 780991
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "242075902358462464",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.5995568699, -122.3010640686 ]
  },
  "id_str" : "242090130003853313",
  "in_reply_to_user_id" : 780991,
  "text" : "@amyjokim Yes indeed.",
  "id" : 242090130003853313,
  "in_reply_to_status_id" : 242075902358462464,
  "created_at" : "Sun Sep 02 02:42:39 +0000 2012",
  "in_reply_to_screen_name" : "amyjokim",
  "in_reply_to_user_id_str" : "780991",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Guarraci",
      "screen_name" : "eismcc",
      "indices" : [ 0, 7 ],
      "id_str" : "13257392",
      "id" : 13257392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "242076962586247169",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.5993001873, -122.3147726481 ]
  },
  "id_str" : "242089640696377344",
  "in_reply_to_user_id" : 13257392,
  "text" : "@eismcc Yeah just a few blocks south of there on the water.",
  "id" : 242089640696377344,
  "in_reply_to_status_id" : 242076962586247169,
  "created_at" : "Sun Sep 02 02:40:42 +0000 2012",
  "in_reply_to_screen_name" : "eismcc",
  "in_reply_to_user_id_str" : "13257392",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagr.am\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 35 ],
      "url" : "http://t.co/EVJ0Bt2z",
      "expanded_url" : "http://instagr.am/p/PDcwZhI0Ap/",
      "display_url" : "instagr.am/p/PDcwZhI0Ap/"
    } ]
  },
  "geo" : {
  },
  "id_str" : "242066155748065280",
  "text" : "Current status http://t.co/EVJ0Bt2z",
  "id" : 242066155748065280,
  "created_at" : "Sun Sep 02 01:07:23 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagr.am\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 78 ],
      "url" : "http://t.co/imUbO0OF",
      "expanded_url" : "http://instagr.am/p/PDcD7xo0AM/",
      "display_url" : "instagr.am/p/PDcD7xo0AM/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6062868998, -122.342141835 ]
  },
  "id_str" : "242064521307500545",
  "text" : "Pretty day from a ferris wheel  @ The Seattle Great Wheel http://t.co/imUbO0OF",
  "id" : 242064521307500545,
  "created_at" : "Sun Sep 02 01:00:53 +0000 2012",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carl Nelson",
      "screen_name" : "CarlNelson",
      "indices" : [ 0, 11 ],
      "id_str" : "13951122",
      "id" : 13951122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "241793420476174336",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6089154743, -122.3058443518 ]
  },
  "id_str" : "241798383612866561",
  "in_reply_to_user_id" : 13951122,
  "text" : "@CarlNelson That was definitely me on my way out of SF. Back next Tuesday!",
  "id" : 241798383612866561,
  "in_reply_to_status_id" : 241793420476174336,
  "created_at" : "Sat Sep 01 07:23:21 +0000 2012",
  "in_reply_to_screen_name" : "CarlNelson",
  "in_reply_to_user_id_str" : "13951122",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
} ]