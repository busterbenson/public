Grailbird.data.tweets_2012_10 = 
 [ {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 89 ],
      "url" : "http://t.co/BXn0ChAq",
      "expanded_url" : "http://flic.kr/p/dpCYAJ",
      "display_url" : "flic.kr/p/dpCYAJ"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.777, -122.423 ]
  },
  "id_str" : "263867654794784768",
  "text" : "8:36pm Halloween with a cat, a mouse, a boxer, a skier, and 2 humans http://t.co/BXn0ChAq",
  "id" : 263867654794784768,
  "created_at" : "2012-11-01 04:58:45 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Foursquare",
      "screen_name" : "foursquare",
      "indices" : [ 39, 50 ],
      "id_str" : "14120151",
      "id" : 14120151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http://t.co/97zXbaRH",
      "expanded_url" : "http://4sq.com/T9mqtL",
      "display_url" : "4sq.com/T9mqtL"
    } ]
  },
  "geo" : { },
  "id_str" : "263826206363885568",
  "text" : "I unlocked the \u201CZombie Swarm\u201D badge on @foursquare for checking in with a crowd on Halloween! Gangnam Style galore. http://t.co/97zXbaRH",
  "id" : 263826206363885568,
  "created_at" : "2012-11-01 02:14:03 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://bufferapp.com\" rel=\"nofollow\">Buffer</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ComfortablySmug",
      "screen_name" : "ComfortablySmug",
      "indices" : [ 85, 101 ],
      "id_str" : "17060573",
      "id" : 17060573
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "doxtrolls",
      "indices" : [ 12, 22 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 123 ],
      "url" : "http://t.co/Rm7d1Vd5",
      "expanded_url" : "http://bit.ly/RtnIOq",
      "display_url" : "bit.ly/RtnIOq"
    } ]
  },
  "geo" : { },
  "id_str" : "263819688499355648",
  "text" : "I'm on team #doxtrolls -- we should bring attention to bad behavior. \"GigaOM debates @ComfortablySmug\" http://t.co/Rm7d1Vd5",
  "id" : 263819688499355648,
  "created_at" : "2012-11-01 01:48:09 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Monica Guzman",
      "screen_name" : "moniguzman",
      "indices" : [ 0, 11 ],
      "id_str" : "3452941",
      "id" : 3452941
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "263789779949342721",
  "geo" : { },
  "id_str" : "263792184719990785",
  "in_reply_to_user_id" : 3452941,
  "text" : "@moniguzman Which email did you send to?  Haven't seen it yet...",
  "id" : 263792184719990785,
  "in_reply_to_status_id" : 263789779949342721,
  "created_at" : "2012-10-31 23:58:52 +0000",
  "in_reply_to_screen_name" : "moniguzman",
  "in_reply_to_user_id_str" : "3452941",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 76 ],
      "url" : "https://t.co/JxkipWhv",
      "expanded_url" : "https://findings.com/clips/CQ3xk5/quote---people-are-often-unreasonable-an/",
      "display_url" : "findings.com/clips/CQ3xk5/q\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "263754503159963648",
  "text" : "Here's a link, in case you don't see the Twitter Card: https://t.co/JxkipWhv",
  "id" : 263754503159963648,
  "created_at" : "2012-10-31 21:29:08 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"https://findings.com\" rel=\"nofollow\">Findings</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 94 ],
      "url" : "http://t.co/hxpyRh5X",
      "expanded_url" : "http://findings.com",
      "display_url" : "findings.com"
    }, {
      "indices" : [ 97, 117 ],
      "url" : "http://t.co/xjWSX3ve",
      "expanded_url" : "http://fnd.gs/Rta1Ck",
      "display_url" : "fnd.gs/Rta1Ck"
    } ]
  },
  "geo" : { },
  "id_str" : "263753895480795136",
  "text" : "Check out this awesome Mother Teresa quote in spooky Halloween font.  via http://t.co/hxpyRh5X - http://t.co/xjWSX3ve",
  "id" : 263753895480795136,
  "created_at" : "2012-10-31 21:26:43 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "giants",
      "indices" : [ 21, 28 ]
    }, {
      "text" : "gopandas",
      "indices" : [ 96, 105 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7785859841, -122.4117944886 ]
  },
  "id_str" : "263685211592728576",
  "text" : "Niko would love this #giants parade - so many people dressed up as his favorite stuffed animal. #gopandas",
  "id" : 263685211592728576,
  "created_at" : "2012-10-31 16:53:48 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emilio Ramirez",
      "screen_name" : "e_ramirez",
      "indices" : [ 0, 10 ],
      "id_str" : "1273564632",
      "id" : 1273564632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "263524400375136256",
  "geo" : { },
  "id_str" : "263525708813447168",
  "in_reply_to_user_id" : 21135674,
  "text" : "@e_ramirez Looking forward to it, as soon as my knee gets its act together. :)",
  "id" : 263525708813447168,
  "in_reply_to_status_id" : 263524400375136256,
  "created_at" : "2012-10-31 06:19:59 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emilio Ramirez",
      "screen_name" : "e_ramirez",
      "indices" : [ 0, 10 ],
      "id_str" : "1273564632",
      "id" : 1273564632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "263524001127743488",
  "geo" : { },
  "id_str" : "263524268158091264",
  "in_reply_to_user_id" : 21135674,
  "text" : "@e_ramirez Yeah, that's what I've been doing. I also just started running again, so probably just need to let everything shake out a bit.",
  "id" : 263524268158091264,
  "in_reply_to_status_id" : 263524001127743488,
  "created_at" : "2012-10-31 06:14:16 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emilio Ramirez",
      "screen_name" : "e_ramirez",
      "indices" : [ 0, 10 ],
      "id_str" : "1273564632",
      "id" : 1273564632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 107 ],
      "url" : "http://t.co/lsWvdrW0",
      "expanded_url" : "http://bit.ly/TmhCyU",
      "display_url" : "bit.ly/TmhCyU"
    } ]
  },
  "in_reply_to_status_id_str" : "263522389311250432",
  "geo" : { },
  "id_str" : "263523526999412736",
  "in_reply_to_user_id" : 21135674,
  "text" : "@e_ramirez I think so. It's definitely on both sides of my knee rather than the front. http://t.co/lsWvdrW0",
  "id" : 263523526999412736,
  "in_reply_to_status_id" : 263522389311250432,
  "created_at" : "2012-10-31 06:11:19 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "marathontraining",
      "indices" : [ 111, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7851263108, -122.4046312514 ]
  },
  "id_str" : "263521039449980928",
  "text" : "Went to the gym to run but sad that my knee still hurts. Guess I gotta just do weights and stretching for now. #marathontraining",
  "id" : 263521039449980928,
  "created_at" : "2012-10-31 06:01:26 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 71 ],
      "url" : "http://t.co/n34H5xla",
      "expanded_url" : "http://flic.kr/p/dpmn1i",
      "display_url" : "flic.kr/p/dpmn1i"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.785, -122.404667 ]
  },
  "id_str" : "263486324990947328",
  "text" : "8:36pm Should I eat this or head to the hotel gym? http://t.co/n34H5xla",
  "id" : 263486324990947328,
  "created_at" : "2012-10-31 03:43:29 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Buzz Andersen",
      "screen_name" : "buzz",
      "indices" : [ 0, 5 ],
      "id_str" : "528",
      "id" : 528
    }, {
      "name" : "Ryan King",
      "screen_name" : "rk",
      "indices" : [ 6, 9 ],
      "id_str" : "19853",
      "id" : 19853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "263477964203769858",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7853988802, -122.4045914146 ]
  },
  "id_str" : "263478635942531073",
  "in_reply_to_user_id" : 528,
  "text" : "@buzz @rk Same.",
  "id" : 263478635942531073,
  "in_reply_to_status_id" : 263477964203769858,
  "created_at" : "2012-10-31 03:12:56 +0000",
  "in_reply_to_screen_name" : "buzz",
  "in_reply_to_user_id_str" : "528",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan King",
      "screen_name" : "rk",
      "indices" : [ 42, 45 ],
      "id_str" : "19853",
      "id" : 19853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 121 ],
      "url" : "http://t.co/HUh2Fpol",
      "expanded_url" : "http://bit.ly/W4AR86",
      "display_url" : "bit.ly/W4AR86"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7849671225, -122.4046142475 ]
  },
  "id_str" : "263477560522977280",
  "text" : "I do! If only to witness its evolution MT @rk: Not sure I can say I want to program for 20 more yrs. http://t.co/HUh2Fpol",
  "id" : 263477560522977280,
  "created_at" : "2012-10-31 03:08:40 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexia Tsotsis",
      "screen_name" : "alexia",
      "indices" : [ 71, 78 ],
      "id_str" : "18327902",
      "id" : 18327902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 114 ],
      "url" : "http://t.co/xBOdmHzm",
      "expanded_url" : "http://tcrn.ch/W4wrOK",
      "display_url" : "tcrn.ch/W4wrOK"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7857960429, -122.4043974165 ]
  },
  "id_str" : "263475456525869056",
  "text" : "Sisyphus, the absurd hero, the great futility, the impossible dream RT @alexia: Gallows Humor http://t.co/xBOdmHzm",
  "id" : 263475456525869056,
  "created_at" : "2012-10-31 03:00:18 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "that drew",
      "screen_name" : "thatdrew",
      "indices" : [ 3, 12 ],
      "id_str" : "1002913782",
      "id" : 1002913782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 47 ],
      "url" : "http://t.co/vARlnzdJ",
      "expanded_url" : "http://scriggity.com/nice-people",
      "display_url" : "scriggity.com/nice-people"
    } ]
  },
  "geo" : { },
  "id_str" : "263473738752864257",
  "text" : "RT @thatdrew: nice people. http://t.co/vARlnzdJ",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 13, 33 ],
        "url" : "http://t.co/vARlnzdJ",
        "expanded_url" : "http://scriggity.com/nice-people",
        "display_url" : "scriggity.com/nice-people"
      } ]
    },
    "geo" : { },
    "id_str" : "263460128408338432",
    "text" : "nice people. http://t.co/vARlnzdJ",
    "id" : 263460128408338432,
    "created_at" : "2012-10-31 01:59:24 +0000",
    "user" : {
      "name" : "drew olanoff",
      "screen_name" : "drew",
      "protected" : false,
      "id_str" : "10221",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000408023956/1710cffecc76204b31adeee75c2bbbe9_normal.jpeg",
      "id" : 10221,
      "verified" : false
    }
  },
  "id" : 263473738752864257,
  "created_at" : "2012-10-31 02:53:29 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cap Watkins",
      "screen_name" : "cap",
      "indices" : [ 0, 4 ],
      "id_str" : "2182141",
      "id" : 2182141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "263455039484477440",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7770554575, -122.4172853368 ]
  },
  "id_str" : "263466230084694017",
  "in_reply_to_user_id" : 2182141,
  "text" : "@cap They apparently do.",
  "id" : 263466230084694017,
  "in_reply_to_status_id" : 263455039484477440,
  "created_at" : "2012-10-31 02:23:38 +0000",
  "in_reply_to_screen_name" : "cap",
  "in_reply_to_user_id_str" : "2182141",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sarahnovotny",
      "screen_name" : "sarahnovotny",
      "indices" : [ 12, 25 ],
      "id_str" : "11547582",
      "id" : 11547582
    }, {
      "name" : "Randy Stewart",
      "screen_name" : "stewtopia",
      "indices" : [ 125, 135 ],
      "id_str" : "5651",
      "id" : 5651
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 111 ],
      "url" : "http://t.co/MWWwNRNp",
      "expanded_url" : "http://www.geekwire.com/2012/5-minutes-mayor-mcginn-signs-ignite-talk/",
      "display_url" : "geekwire.com/2012/5-minutes\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7764708575, -122.4168325691 ]
  },
  "id_str" : "263461423106097152",
  "text" : "Awesome! RT @sarahnovotny: Seattle mayor to give Ignite talk \u2014 here's hoping it's a trend: http://t.co/MWWwNRNp -- well done @stewtopia!",
  "id" : 263461423106097152,
  "created_at" : "2012-10-31 02:04:32 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://dev.twitter.com/\" rel=\"nofollow\">API</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 0, 9 ],
      "id_str" : "761628",
      "id" : 761628
    }, {
      "name" : "josh",
      "screen_name" : "joshc",
      "indices" : [ 10, 16 ],
      "id_str" : "2015",
      "id" : 2015
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "263456207723970561",
  "geo" : { },
  "id_str" : "263457535493824513",
  "in_reply_to_user_id" : 761628,
  "text" : "@RickWebb @joshc David Lynch.",
  "id" : 263457535493824513,
  "in_reply_to_status_id" : 263456207723970561,
  "created_at" : "2012-10-31 01:49:05 +0000",
  "in_reply_to_screen_name" : "RickWebb",
  "in_reply_to_user_id_str" : "761628",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"https://findings.com\" rel=\"nofollow\">Findings</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 75 ],
      "url" : "http://t.co/hxpyRh5X",
      "expanded_url" : "http://findings.com",
      "display_url" : "findings.com"
    }, {
      "indices" : [ 78, 98 ],
      "url" : "http://t.co/uutLWvEM",
      "expanded_url" : "http://fnd.gs/StKNor",
      "display_url" : "fnd.gs/StKNor"
    } ]
  },
  "geo" : { },
  "id_str" : "263453085517635585",
  "text" : "Nice read. \"The Island Where People Forget To Die\" via http://t.co/hxpyRh5X - http://t.co/uutLWvEM",
  "id" : 263453085517635585,
  "created_at" : "2012-10-31 01:31:24 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://dev.twitter.com/\" rel=\"nofollow\">API</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 3, 12 ],
      "id_str" : "761628",
      "id" : 761628
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "263448245601198080",
  "text" : "RT @RickWebb: Fuck it. There should just be STAR WARS LAND.",
  "retweeted_status" : {
    "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "263448067116761088",
    "text" : "Fuck it. There should just be STAR WARS LAND.",
    "id" : 263448067116761088,
    "created_at" : "2012-10-31 01:11:28 +0000",
    "user" : {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "protected" : false,
      "id_str" : "761628",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/23078492/img_2085_normal.jpg",
      "id" : 761628,
      "verified" : false
    }
  },
  "id" : 263448245601198080,
  "created_at" : "2012-10-31 01:12:11 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://bufferapp.com\" rel=\"nofollow\">Buffer</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 51 ],
      "url" : "http://t.co/3P62xaic",
      "expanded_url" : "http://bit.ly/Q4mvlB",
      "display_url" : "bit.ly/Q4mvlB"
    } ]
  },
  "geo" : { },
  "id_str" : "263315310176768000",
  "text" : "\"Zoomed out\" - Way of the Duck http://t.co/3P62xaic",
  "id" : 263315310176768000,
  "created_at" : "2012-10-30 16:23:56 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http://t.co/rWg6Xf5X",
      "expanded_url" : "http://instagr.am/p/RaZ5fmo0Ko/",
      "display_url" : "instagr.am/p/RaZ5fmo0Ko/"
    } ]
  },
  "geo" : { },
  "id_str" : "263311211305771009",
  "text" : "Remembering my dad (11/26/51-10/30/93) http://t.co/rWg6Xf5X",
  "id" : 263311211305771009,
  "created_at" : "2012-10-30 16:07:39 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sandy",
      "indices" : [ 74, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 101 ],
      "url" : "http://t.co/tbE1hIf2",
      "expanded_url" : "http://flic.kr/p/dp53nA",
      "display_url" : "flic.kr/p/dp53nA"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.784833, -122.404834 ]
  },
  "id_str" : "263123823426142208",
  "text" : "8:36pm Exhausted but can't stop reading about east coasters going through #sandy http://t.co/tbE1hIf2",
  "id" : 263123823426142208,
  "created_at" : "2012-10-30 03:43:02 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/buster/status/263100966356799488/photo/1",
      "indices" : [ 50, 70 ],
      "url" : "http://t.co/FFYetDbD",
      "media_url" : "http://pbs.twimg.com/media/A6a471gCUAAJ9q9.jpg",
      "id_str" : "263100966360993792",
      "id" : 263100966360993792,
      "media_url_https" : "https://pbs.twimg.com/media/A6a471gCUAAJ9q9.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 577
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 577
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 603,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 577
      } ],
      "display_url" : "pic.twitter.com/FFYetDbD"
    } ],
    "hashtags" : [ {
      "text" : "Sandy",
      "indices" : [ 43, 49 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7823277479, -122.4042192689 ]
  },
  "id_str" : "263100966356799488",
  "text" : "Everyone text REDCROSS to 90999 right now. #Sandy http://t.co/FFYetDbD",
  "id" : 263100966356799488,
  "created_at" : "2012-10-30 02:12:13 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Berkun",
      "screen_name" : "berkun",
      "indices" : [ 3, 10 ],
      "id_str" : "30495974",
      "id" : 30495974
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sandy",
      "indices" : [ 53, 59 ]
    }, {
      "text" : "sandy",
      "indices" : [ 82, 88 ]
    }, {
      "text" : "frankenstorm",
      "indices" : [ 89, 102 ]
    } ],
    "urls" : [ {
      "indices" : [ 61, 81 ],
      "url" : "http://t.co/KBCcgVAh",
      "expanded_url" : "http://bit.ly/S8ypaP",
      "display_url" : "bit.ly/S8ypaP"
    } ]
  },
  "geo" : { },
  "id_str" : "262973833663901697",
  "text" : "RT @berkun: An inventory of Fake photos of hurricane #sandy: http://t.co/KBCcgVAh #sandy #frankenstorm",
  "retweeted_status" : {
    "source" : "<a href=\"http://bufferapp.com\" rel=\"nofollow\">Buffer</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "sandy",
        "indices" : [ 41, 47 ]
      }, {
        "text" : "sandy",
        "indices" : [ 70, 76 ]
      }, {
        "text" : "frankenstorm",
        "indices" : [ 77, 90 ]
      } ],
      "urls" : [ {
        "indices" : [ 49, 69 ],
        "url" : "http://t.co/KBCcgVAh",
        "expanded_url" : "http://bit.ly/S8ypaP",
        "display_url" : "bit.ly/S8ypaP"
      } ]
    },
    "geo" : { },
    "id_str" : "262972168579719168",
    "text" : "An inventory of Fake photos of hurricane #sandy: http://t.co/KBCcgVAh #sandy #frankenstorm",
    "id" : 262972168579719168,
    "created_at" : "2012-10-29 17:40:25 +0000",
    "user" : {
      "name" : "Scott Berkun",
      "screen_name" : "berkun",
      "protected" : false,
      "id_str" : "30495974",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000401465840/15f3d66a746f653fefddd98f198c58e5_normal.png",
      "id" : 30495974,
      "verified" : false
    }
  },
  "id" : 262973833663901697,
  "created_at" : "2012-10-29 17:47:02 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Ducker",
      "screen_name" : "miradu",
      "indices" : [ 3, 10 ],
      "id_str" : "1530531",
      "id" : 1530531
    }, {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 54, 62 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 49 ],
      "url" : "http://t.co/SQqQVVqS",
      "expanded_url" : "http://www.youtube.com/watch?v=6TiXUF9xbTo&sns=tw",
      "display_url" : "youtube.com/watch?v=6TiXUF\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "262951502258262016",
  "text" : "RT @miradu: Whedon On Romney http://t.co/SQqQVVqS via @youtube",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "YouTube",
        "screen_name" : "YouTube",
        "indices" : [ 42, 50 ],
        "id_str" : "10228272",
        "id" : 10228272
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 17, 37 ],
        "url" : "http://t.co/SQqQVVqS",
        "expanded_url" : "http://www.youtube.com/watch?v=6TiXUF9xbTo&sns=tw",
        "display_url" : "youtube.com/watch?v=6TiXUF\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "262667675333976065",
    "text" : "Whedon On Romney http://t.co/SQqQVVqS via @youtube",
    "id" : 262667675333976065,
    "created_at" : "2012-10-28 21:30:28 +0000",
    "user" : {
      "name" : "Michael Ducker",
      "screen_name" : "miradu",
      "protected" : false,
      "id_str" : "1530531",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3100276416/6a6f2742403a1b78af6544e5fbc2a3c0_normal.jpeg",
      "id" : 1530531,
      "verified" : false
    }
  },
  "id" : 262951502258262016,
  "created_at" : "2012-10-29 16:18:18 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "matt",
      "screen_name" : "mattbuchanan",
      "indices" : [ 3, 16 ],
      "id_str" : "14313712",
      "id" : 14313712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 64 ],
      "url" : "http://t.co/oALNV7QS",
      "expanded_url" : "http://instacane.com/",
      "display_url" : "instacane.com"
    } ]
  },
  "geo" : { },
  "id_str" : "262932049084690434",
  "text" : "RT @mattbuchanan: This is the site to watch http://t.co/oALNV7QS",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.osfoora.com/mac\" rel=\"nofollow\">Osfoora for Mac</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 26, 46 ],
        "url" : "http://t.co/oALNV7QS",
        "expanded_url" : "http://instacane.com/",
        "display_url" : "instacane.com"
      } ]
    },
    "geo" : { },
    "id_str" : "262926514478260224",
    "text" : "This is the site to watch http://t.co/oALNV7QS",
    "id" : 262926514478260224,
    "created_at" : "2012-10-29 14:39:00 +0000",
    "user" : {
      "name" : "matt",
      "screen_name" : "mattbuchanan",
      "protected" : false,
      "id_str" : "14313712",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3674815212/a5ac2c56d10d3ed06a19b788e27ac7cf_normal.jpeg",
      "id" : 14313712,
      "verified" : false
    }
  },
  "id" : 262932049084690434,
  "created_at" : "2012-10-29 15:01:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 93 ],
      "url" : "http://t.co/UpJzaXNi",
      "expanded_url" : "http://instagr.am/p/RWgwXUo0E3/",
      "display_url" : "instagr.am/p/RWgwXUo0E3/"
    } ]
  },
  "geo" : { },
  "id_str" : "262763542791475202",
  "text" : "8:36pm Just had dinner with Kellianne's aunt and grandmother in Salinas. http://t.co/UpJzaXNi",
  "id" : 262763542791475202,
  "created_at" : "2012-10-29 03:51:25 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 68 ],
      "url" : "http://t.co/9b3TZC5l",
      "expanded_url" : "http://instagr.am/p/RV3IYko0Fq/",
      "display_url" : "instagr.am/p/RV3IYko0Fq/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 36.2646212895, -121.800882561 ]
  },
  "id_str" : "262672819773640705",
  "text" : "Pre-wedding family sighting @ Glen Oaks Big Sur http://t.co/9b3TZC5l",
  "id" : 262672819773640705,
  "created_at" : "2012-10-28 21:50:55 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 100 ],
      "url" : "http://t.co/I2q15r6y",
      "expanded_url" : "http://instagr.am/p/RVxqpKI0Pj/",
      "display_url" : "instagr.am/p/RVxqpKI0Pj/"
    } ]
  },
  "geo" : { },
  "id_str" : "262660299247730690",
  "text" : "Car broke down. Stranded in Big Sur. Forced to decide between a nap and a beer. http://t.co/I2q15r6y",
  "id" : 262660299247730690,
  "created_at" : "2012-10-28 21:01:09 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 32 ],
      "url" : "http://t.co/eLK8pp7b",
      "expanded_url" : "http://instagr.am/p/RUI97Uo0J4/",
      "display_url" : "instagr.am/p/RUI97Uo0J4/"
    } ]
  },
  "geo" : { },
  "id_str" : "262429445976121344",
  "text" : "After party http://t.co/eLK8pp7b",
  "id" : 262429445976121344,
  "created_at" : "2012-10-28 05:43:50 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 129 ],
      "url" : "http://t.co/Y7VMDicm",
      "expanded_url" : "http://instagr.am/p/RT8XoyI0Nb/",
      "display_url" : "instagr.am/p/RT8XoyI0Nb/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 36.2646212895, -121.800882561 ]
  },
  "id_str" : "262402076557066240",
  "text" : "8:36pm So happy to be celebrating the wonderful marriage of lifelong friends Jim and Mic @ Glen Oaks Big Sur http://t.co/Y7VMDicm",
  "id" : 262402076557066240,
  "created_at" : "2012-10-28 03:55:04 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "quantifiedself",
      "screen_name" : "quantifiedself",
      "indices" : [ 3, 18 ],
      "id_str" : "35056570",
      "id" : 35056570
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 87 ],
      "url" : "http://t.co/AXX4eECY",
      "expanded_url" : "http://goo.gl/fb/EOi1O",
      "display_url" : "goo.gl/fb/EOi1O"
    } ]
  },
  "geo" : { },
  "id_str" : "261924317925871617",
  "text" : "RT @quantifiedself: QS Blog - Quick and Reliable Mood Measurement: http://t.co/AXX4eECY",
  "retweeted_status" : {
    "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 47, 67 ],
        "url" : "http://t.co/AXX4eECY",
        "expanded_url" : "http://goo.gl/fb/EOi1O",
        "display_url" : "goo.gl/fb/EOi1O"
      } ]
    },
    "geo" : { },
    "id_str" : "261922879803891713",
    "text" : "QS Blog - Quick and Reliable Mood Measurement: http://t.co/AXX4eECY",
    "id" : 261922879803891713,
    "created_at" : "2012-10-26 20:10:55 +0000",
    "user" : {
      "name" : "quantifiedself",
      "screen_name" : "quantifiedself",
      "protected" : false,
      "id_str" : "35056570",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1370964776/QS_logo_150px_vertical_2c_normal.png",
      "id" : 35056570,
      "verified" : false
    }
  },
  "id" : 261924317925871617,
  "created_at" : "2012-10-26 20:16:38 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 33 ],
      "url" : "http://t.co/ozfuyx4P",
      "expanded_url" : "http://instagr.am/p/RQcHAcI0GD/",
      "display_url" : "instagr.am/p/RQcHAcI0GD/"
    } ]
  },
  "geo" : { },
  "id_str" : "261908898951340032",
  "text" : "\"I have it!\" http://t.co/ozfuyx4P",
  "id" : 261908898951340032,
  "created_at" : "2012-10-26 19:15:22 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 101 ],
      "url" : "http://t.co/g9MmWQU7",
      "expanded_url" : "http://instagr.am/p/RQJ2fTI0Iv/",
      "display_url" : "instagr.am/p/RQJ2fTI0Iv/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.4436465828, -122.302594185 ]
  },
  "id_str" : "261868550598299649",
  "text" : "Someone's excited to get on a plane @ Seattle-Tacoma International Airport (SEA) http://t.co/g9MmWQU7",
  "id" : 261868550598299649,
  "created_at" : "2012-10-26 16:35:02 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.dietbet.com\" rel=\"nofollow\">DietBet</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DietBet",
      "screen_name" : "DietBet",
      "indices" : [ 23, 31 ],
      "id_str" : "185399301",
      "id" : 185399301
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 71 ],
      "url" : "http://t.co/Pwb0EMtl",
      "expanded_url" : "http://bit.ly/TISXoP",
      "display_url" : "bit.ly/TISXoP"
    } ]
  },
  "geo" : { },
  "id_str" : "261865184140853248",
  "text" : "Just lost 0.7lbs in my @DietBet. Come cheer me on! http://t.co/Pwb0EMtl",
  "id" : 261865184140853248,
  "created_at" : "2012-10-26 16:21:39 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 85 ],
      "url" : "http://t.co/VOgzaq74",
      "expanded_url" : "http://instagr.am/p/RP3n49o0LG/",
      "display_url" : "instagr.am/p/RP3n49o0LG/"
    } ]
  },
  "geo" : { },
  "id_str" : "261828573835431938",
  "text" : "Suited up for a weekend and Big Sur with all the key accessories http://t.co/VOgzaq74",
  "id" : 261828573835431938,
  "created_at" : "2012-10-26 13:56:11 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"https://findings.com\" rel=\"nofollow\">Findings</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 73 ],
      "url" : "http://t.co/hxpyRh5X",
      "expanded_url" : "http://findings.com",
      "display_url" : "findings.com"
    }, {
      "indices" : [ 76, 96 ],
      "url" : "http://t.co/wnaCBdCi",
      "expanded_url" : "http://fnd.gs/SEopG6",
      "display_url" : "fnd.gs/SEopG6"
    } ]
  },
  "geo" : { },
  "id_str" : "261823252035424256",
  "text" : "First known use of the word \"twitter\" as a verb. via http://t.co/hxpyRh5X - http://t.co/wnaCBdCi",
  "id" : 261823252035424256,
  "created_at" : "2012-10-26 13:35:02 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Berkun",
      "screen_name" : "berkun",
      "indices" : [ 0, 7 ],
      "id_str" : "30495974",
      "id" : 30495974
    }, {
      "name" : "Robin Sloan",
      "screen_name" : "robinsloan",
      "indices" : [ 36, 47 ],
      "id_str" : "13919072",
      "id" : 13919072
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 70 ],
      "url" : "http://t.co/VsgOQMkj",
      "expanded_url" : "http://robinsloan.com/fish",
      "display_url" : "robinsloan.com/fish"
    } ]
  },
  "in_reply_to_status_id_str" : "261695549022023680",
  "geo" : { },
  "id_str" : "261701486524899328",
  "in_reply_to_user_id" : 30495974,
  "text" : "@berkun It's a cryptic reference to @robinsloan's http://t.co/VsgOQMkj tap-essay, which I love.",
  "id" : 261701486524899328,
  "in_reply_to_status_id" : 261695549022023680,
  "created_at" : "2012-10-26 05:31:11 +0000",
  "in_reply_to_screen_name" : "berkun",
  "in_reply_to_user_id_str" : "30495974",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Haiku Deck",
      "screen_name" : "HaikuDeck",
      "indices" : [ 106, 116 ],
      "id_str" : "352538333",
      "id" : 352538333
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 100 ],
      "url" : "http://t.co/XvG2sU9h",
      "expanded_url" : "http://www.haikudeck.com/p/u9qVHcR7Ts/look-look-look",
      "display_url" : "haikudeck.com/p/u9qVHcR7Ts/l\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "261695061836832768",
  "text" : "Look at your fish. Love your family. Eat mostly plants. Remember, you will die. http://t.co/XvG2sU9h /via @haikudeck now with twitter cards",
  "id" : 261695061836832768,
  "created_at" : "2012-10-26 05:05:39 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 129 ],
      "url" : "http://t.co/DbqY1cP6",
      "expanded_url" : "http://instagr.am/p/ROzCQeo0Ji/",
      "display_url" : "instagr.am/p/ROzCQeo0Ji/"
    } ]
  },
  "geo" : { },
  "id_str" : "261677867975471105",
  "text" : "8:36pm After witnessing Niko brush his teeth I understand why humans evolved to eject them all after a few y http://t.co/DbqY1cP6",
  "id" : 261677867975471105,
  "created_at" : "2012-10-26 03:57:20 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Sippey",
      "screen_name" : "sippey",
      "indices" : [ 0, 7 ],
      "id_str" : "4711",
      "id" : 4711
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "261662959535783936",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6108463295, -122.3063906842 ]
  },
  "id_str" : "261663730100752384",
  "in_reply_to_user_id" : 4711,
  "text" : "@sippey Luckily it's a jam band. Might just make it.",
  "id" : 261663730100752384,
  "in_reply_to_status_id" : 261662959535783936,
  "created_at" : "2012-10-26 03:01:09 +0000",
  "in_reply_to_screen_name" : "sippey",
  "in_reply_to_user_id_str" : "4711",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6128040487, -122.3078846746 ]
  },
  "id_str" : "261662795622404096",
  "text" : "What I'm listening to right now is my new jam. \uD83C\uDFB6",
  "id" : 261662795622404096,
  "created_at" : "2012-10-26 02:57:26 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.apple.com\" rel=\"nofollow\">Safari on iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robi Ganguly",
      "screen_name" : "rganguly",
      "indices" : [ 50, 59 ],
      "id_str" : "622663",
      "id" : 622663
    }, {
      "name" : "Apptentive",
      "screen_name" : "apptentive",
      "indices" : [ 64, 75 ],
      "id_str" : "267925827",
      "id" : 267925827
    }, {
      "name" : "techstars",
      "screen_name" : "techstars",
      "indices" : [ 91, 101 ],
      "id_str" : "14277276",
      "id" : 14277276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 129 ],
      "url" : "http://t.co/U0RCNfL5",
      "expanded_url" : "http://tweeterheads.com/big_word/yes",
      "display_url" : "tweeterheads.com/big_word/yes"
    } ]
  },
  "geo" : { },
  "id_str" : "261658422737514496",
  "text" : "Are you an app developer? Should you be following @rganguly and @apptentive in the current @techstars class? http://t.co/U0RCNfL5",
  "id" : 261658422737514496,
  "created_at" : "2012-10-26 02:40:04 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 27 ],
      "url" : "http://t.co/nb7Qm0rW",
      "expanded_url" : "http://tweeterheads.com/big_word/Hello",
      "display_url" : "tweeterheads.com/big_word/Hello"
    } ]
  },
  "geo" : { },
  "id_str" : "261628220774965250",
  "text" : "Hello. http://t.co/nb7Qm0rW",
  "id" : 261628220774965250,
  "created_at" : "2012-10-26 00:40:03 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cap Watkins",
      "screen_name" : "cap",
      "indices" : [ 0, 4 ],
      "id_str" : "2182141",
      "id" : 2182141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "261569064663666688",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6142964818, -122.3495167645 ]
  },
  "id_str" : "261572515502125056",
  "in_reply_to_user_id" : 2182141,
  "text" : "@cap I think there are some defaults on authentication gems (like the popular devise) that people never change.",
  "id" : 261572515502125056,
  "in_reply_to_status_id" : 261569064663666688,
  "created_at" : "2012-10-25 20:58:42 +0000",
  "in_reply_to_screen_name" : "cap",
  "in_reply_to_user_id_str" : "2182141",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Sutter",
      "screen_name" : "pinwheel",
      "indices" : [ 0, 9 ],
      "id_str" : "22483",
      "id" : 22483
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "261569381891461120",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6142964126, -122.3495287019 ]
  },
  "id_str" : "261569893156155392",
  "in_reply_to_user_id" : 22483,
  "text" : "@pinwheel Yeah I guess people don't build their own blogs anymore. Sad times.",
  "id" : 261569893156155392,
  "in_reply_to_status_id" : 261569381891461120,
  "created_at" : "2012-10-25 20:48:16 +0000",
  "in_reply_to_screen_name" : "pinwheel",
  "in_reply_to_user_id_str" : "22483",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Sutter",
      "screen_name" : "pinwheel",
      "indices" : [ 0, 9 ],
      "id_str" : "22483",
      "id" : 22483
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "261567962476064768",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6143171499, -122.3463514914 ]
  },
  "id_str" : "261568453859749888",
  "in_reply_to_user_id" : 22483,
  "text" : "@pinwheel Ha good point.",
  "id" : 261568453859749888,
  "in_reply_to_status_id" : 261567962476064768,
  "created_at" : "2012-10-25 20:42:33 +0000",
  "in_reply_to_screen_name" : "pinwheel",
  "in_reply_to_user_id_str" : "22483",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://bufferapp.com\" rel=\"nofollow\">Buffer</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sylvain Carle",
      "screen_name" : "froginthevalley",
      "indices" : [ 16, 32 ],
      "id_str" : "657693",
      "id" : 657693
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 117 ],
      "url" : "http://t.co/Z0UP0etD",
      "expanded_url" : "http://bit.ly/R32SoH",
      "display_url" : "bit.ly/R32SoH"
    } ]
  },
  "geo" : { },
  "id_str" : "261564866861621248",
  "text" : "Great post from @froginthevalley with examples of how over 2,000 people are using Twitter Cards: http://t.co/Z0UP0etD",
  "id" : 261564866861621248,
  "created_at" : "2012-10-25 20:28:18 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Jacobs",
      "screen_name" : "djacobs",
      "indices" : [ 0, 8 ],
      "id_str" : "774842",
      "id" : 774842
    }, {
      "name" : "Michael Sippey",
      "screen_name" : "sippey",
      "indices" : [ 9, 16 ],
      "id_str" : "4711",
      "id" : 4711
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "261552162415472640",
  "in_reply_to_user_id" : 774842,
  "text" : "@djacobs @sippey Also, email me if you have specific questions or ideas you want to bounce around. buster@twitter.com",
  "id" : 261552162415472640,
  "created_at" : "2012-10-25 19:37:49 +0000",
  "in_reply_to_screen_name" : "djacobs",
  "in_reply_to_user_id_str" : "774842",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Jacobs",
      "screen_name" : "djacobs",
      "indices" : [ 0, 8 ],
      "id_str" : "774842",
      "id" : 774842
    }, {
      "name" : "Michael Sippey",
      "screen_name" : "sippey",
      "indices" : [ 9, 16 ],
      "id_str" : "4711",
      "id" : 4711
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 102 ],
      "url" : "http://t.co/WWtqey07",
      "expanded_url" : "http://bit.ly/UIuaXQ",
      "display_url" : "bit.ly/UIuaXQ"
    }, {
      "indices" : [ 107, 127 ],
      "url" : "http://t.co/RleNBCp9",
      "expanded_url" : "http://bit.ly/QnpTTa",
      "display_url" : "bit.ly/QnpTTa"
    } ]
  },
  "in_reply_to_status_id_str" : "261551340122157057",
  "geo" : { },
  "id_str" : "261551937902751746",
  "in_reply_to_user_id" : 774842,
  "text" : "@djacobs @sippey You just need to add a couple metadata tags to your pages.  See: http://t.co/WWtqey07 and http://t.co/RleNBCp9 for hints.",
  "id" : 261551937902751746,
  "in_reply_to_status_id" : 261551340122157057,
  "created_at" : "2012-10-25 19:36:56 +0000",
  "in_reply_to_screen_name" : "djacobs",
  "in_reply_to_user_id_str" : "774842",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DietBet",
      "screen_name" : "DietBet",
      "indices" : [ 69, 77 ],
      "id_str" : "185399301",
      "id" : 185399301
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http://t.co/TmcHTzab",
      "expanded_url" : "http://www.dietbet.com/games/4319/",
      "display_url" : "dietbet.com/games/4319/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6068512613, -122.3009205851 ]
  },
  "id_str" : "261496576835465217",
  "text" : "As much as I'm skeptical of loss-aversion as sustainable motivation, @dietbet is a pretty great implementation of it. http://t.co/TmcHTzab",
  "id" : 261496576835465217,
  "created_at" : "2012-10-25 15:56:56 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http://t.co/1aiLgUwD",
      "expanded_url" : "http://bit.ly/PRG5Bv",
      "display_url" : "bit.ly/PRG5Bv"
    } ]
  },
  "geo" : { },
  "id_str" : "261333964734750720",
  "text" : "I just joined DietBet to lose 4% of my weight by 11/21. If I fail, I pay $50. If I succeed, I split the pot. Join me! http://t.co/1aiLgUwD",
  "id" : 261333964734750720,
  "created_at" : "2012-10-25 05:10:47 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 64 ],
      "url" : "http://t.co/oNQyg1jq",
      "expanded_url" : "http://instagr.am/p/RMMZMGo0H-/",
      "display_url" : "instagr.am/p/RMMZMGo0H-/"
    } ]
  },
  "geo" : { },
  "id_str" : "261311249814523904",
  "text" : "8:36pm Will wear monkey hat for blueberries http://t.co/oNQyg1jq",
  "id" : 261311249814523904,
  "created_at" : "2012-10-25 03:40:31 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emilio Ramirez",
      "screen_name" : "e_ramirez",
      "indices" : [ 0, 10 ],
      "id_str" : "1273564632",
      "id" : 1273564632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "261291002638241792",
  "geo" : { },
  "id_str" : "261294038815215616",
  "in_reply_to_user_id" : 21135674,
  "text" : "@e_ramirez Woah, that's a pretty impressive clone!",
  "id" : 261294038815215616,
  "in_reply_to_status_id" : 261291002638241792,
  "created_at" : "2012-10-25 02:32:08 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://bufferapp.com\" rel=\"nofollow\">Buffer</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Branch",
      "screen_name" : "branch",
      "indices" : [ 19, 26 ],
      "id_str" : "494518813",
      "id" : 494518813
    }, {
      "name" : "Emilio Ramirez",
      "screen_name" : "e_ramirez",
      "indices" : [ 100, 110 ],
      "id_str" : "1273564632",
      "id" : 1273564632
    }, {
      "name" : "Chris Hogg",
      "screen_name" : "cwhogg",
      "indices" : [ 111, 118 ],
      "id_str" : "15727738",
      "id" : 15727738
    }, {
      "name" : "Aaron Coleman",
      "screen_name" : "aarondcoleman",
      "indices" : [ 119, 133 ],
      "id_str" : "1379965428",
      "id" : 1379965428
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 95 ],
      "url" : "http://t.co/vXfTyLxB",
      "expanded_url" : "http://on.branch.com/Qo1y1u#U28S-XIICFQ",
      "display_url" : "on.branch.com/Qo1y1u#U28S-XI\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "261285514496315397",
  "text" : "Trying to keep the @branch alive: \u201CIf behavior change is belief change...\" http://t.co/vXfTyLxB /cc @e_ramirez @cwhogg @aarondcoleman",
  "id" : 261285514496315397,
  "created_at" : "2012-10-25 01:58:15 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Dean",
      "screen_name" : "dandean",
      "indices" : [ 0, 8 ],
      "id_str" : "9525212",
      "id" : 9525212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "261241679565172740",
  "geo" : { },
  "id_str" : "261277013472600064",
  "in_reply_to_user_id" : 9525212,
  "text" : "@dandean If you don\u2019t hear back in a few days, let me know.",
  "id" : 261277013472600064,
  "in_reply_to_status_id" : 261241679565172740,
  "created_at" : "2012-10-25 01:24:28 +0000",
  "in_reply_to_screen_name" : "dandean",
  "in_reply_to_user_id_str" : "9525212",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Williams",
      "screen_name" : "ev",
      "indices" : [ 3, 6 ],
      "id_str" : "20",
      "id" : 20
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 86 ],
      "url" : "https://t.co/Wtdnh3RF",
      "expanded_url" : "https://medium.com/product-design/87c254033e2c",
      "display_url" : "medium.com/product-design\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "261273021677989889",
  "text" : "RT @ev: Don't buy something unless you've wanted it three times: https://t.co/Wtdnh3RF",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 57, 78 ],
        "url" : "https://t.co/Wtdnh3RF",
        "expanded_url" : "https://medium.com/product-design/87c254033e2c",
        "display_url" : "medium.com/product-design\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "261271539104743424",
    "text" : "Don't buy something unless you've wanted it three times: https://t.co/Wtdnh3RF",
    "id" : 261271539104743424,
    "created_at" : "2012-10-25 01:02:43 +0000",
    "user" : {
      "name" : "Evan Williams",
      "screen_name" : "ev",
      "protected" : false,
      "id_str" : "20",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3669523083/741b9ae8a443ce0a81646314871d2c00_normal.jpeg",
      "id" : 20,
      "verified" : true
    }
  },
  "id" : 261273021677989889,
  "created_at" : "2012-10-25 01:08:37 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Dean",
      "screen_name" : "dandean",
      "indices" : [ 0, 8 ],
      "id_str" : "9525212",
      "id" : 9525212
    }, {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 31, 39 ],
      "id_str" : "783214",
      "id" : 783214
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "261230211335602176",
  "geo" : { },
  "id_str" : "261239914933391362",
  "in_reply_to_user_id" : 9525212,
  "text" : "@dandean Try writing to support@twitter.com, they can release it for you. If that doesn't work, let me know and I'll poke someone.",
  "id" : 261239914933391362,
  "in_reply_to_status_id" : 261230211335602176,
  "created_at" : "2012-10-24 22:57:03 +0000",
  "in_reply_to_screen_name" : "dandean",
  "in_reply_to_user_id_str" : "9525212",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Dean",
      "screen_name" : "dandean",
      "indices" : [ 0, 8 ],
      "id_str" : "9525212",
      "id" : 9525212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "261228750384017408",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6118489813, -122.3478753158 ]
  },
  "id_str" : "261229826327867393",
  "in_reply_to_user_id" : 9525212,
  "text" : "@dandean It's a bit tricky. How long since they tweeted? It also depends on last log in time though.",
  "id" : 261229826327867393,
  "in_reply_to_status_id" : 261228750384017408,
  "created_at" : "2012-10-24 22:16:58 +0000",
  "in_reply_to_screen_name" : "dandean",
  "in_reply_to_user_id_str" : "9525212",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael S Galpert",
      "screen_name" : "msg",
      "indices" : [ 8, 12 ],
      "id_str" : "937961",
      "id" : 937961
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6118591928, -122.3479888507 ]
  },
  "id_str" : "261215335632490497",
  "text" : "Yes pls @msg: for those building a new email client please include a thanks button that doesnt send another email",
  "id" : 261215335632490497,
  "created_at" : "2012-10-24 21:19:23 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"https://findings.com\" rel=\"nofollow\">Findings</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 93 ],
      "url" : "http://t.co/hxpyRh5X",
      "expanded_url" : "http://findings.com",
      "display_url" : "findings.com"
    }, {
      "indices" : [ 96, 116 ],
      "url" : "http://t.co/digdZqgB",
      "expanded_url" : "http://fnd.gs/TVaNFw",
      "display_url" : "fnd.gs/TVaNFw"
    } ]
  },
  "geo" : { },
  "id_str" : "261200128403177472",
  "text" : "A 12 hour period of silence during the Digital Detox sounds amazing. via http://t.co/hxpyRh5X - http://t.co/digdZqgB",
  "id" : 261200128403177472,
  "created_at" : "2012-10-24 20:18:58 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amstel Light",
      "screen_name" : "AmstelLight",
      "indices" : [ 38, 50 ],
      "id_str" : "467652986",
      "id" : 467652986
    }, {
      "name" : "Visually",
      "screen_name" : "Visually",
      "indices" : [ 76, 85 ],
      "id_str" : "273197054",
      "id" : 273197054
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 71 ],
      "url" : "http://t.co/CshxNADD",
      "expanded_url" : "http://create.visual.ly/shared/VThHu2VyK8oXnjgThc8LSe",
      "display_url" : "create.visual.ly/shared/VThHu2V\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "261193101727629312",
  "text" : "Fun infographic of my Twitter Tale by @AmstelLight http://t.co/CshxNADD via @visually",
  "id" : 261193101727629312,
  "created_at" : "2012-10-24 19:51:02 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lauren Leto",
      "screen_name" : "laurenleto",
      "indices" : [ 0, 11 ],
      "id_str" : "15510569",
      "id" : 15510569
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "261163922084732928",
  "geo" : { },
  "id_str" : "261164656582864896",
  "in_reply_to_user_id" : 15510569,
  "text" : "@laurenleto I'll double check but I think that's correct.",
  "id" : 261164656582864896,
  "in_reply_to_status_id" : 261163922084732928,
  "created_at" : "2012-10-24 17:58:00 +0000",
  "in_reply_to_screen_name" : "laurenleto",
  "in_reply_to_user_id_str" : "15510569",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lauren Leto",
      "screen_name" : "laurenleto",
      "indices" : [ 0, 11 ],
      "id_str" : "15510569",
      "id" : 15510569
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "261162718323699712",
  "geo" : { },
  "id_str" : "261163719638257664",
  "in_reply_to_user_id" : 15510569,
  "text" : "@laurenleto I'm seeing it... but what did you see? Did it not appear at first? Was it slow?",
  "id" : 261163719638257664,
  "in_reply_to_status_id" : 261162718323699712,
  "created_at" : "2012-10-24 17:54:17 +0000",
  "in_reply_to_screen_name" : "laurenleto",
  "in_reply_to_user_id_str" : "15510569",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"https://findings.com\" rel=\"nofollow\">Findings</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lauren Leto",
      "screen_name" : "laurenleto",
      "indices" : [ 16, 27 ],
      "id_str" : "15510569",
      "id" : 15510569
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 101 ],
      "url" : "http://t.co/hxpyRh5X",
      "expanded_url" : "http://findings.com",
      "display_url" : "findings.com"
    }, {
      "indices" : [ 104, 124 ],
      "url" : "http://t.co/4aDOuuvP",
      "expanded_url" : "http://fnd.gs/VER7wp",
      "display_url" : "fnd.gs/VER7wp"
    } ]
  },
  "geo" : { },
  "id_str" : "261161302930624513",
  "text" : "Great post from @laurenleto on the potential for Twitter Cards to be awesome via http://t.co/hxpyRh5X - http://t.co/4aDOuuvP",
  "id" : 261161302930624513,
  "created_at" : "2012-10-24 17:44:41 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.apple.com\" rel=\"nofollow\">iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Loren Brichter",
      "screen_name" : "lorenb",
      "indices" : [ 71, 78 ],
      "id_str" : "9943672",
      "id" : 9943672
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Letterpress",
      "indices" : [ 10, 22 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 100 ],
      "url" : "http://t.co/xlLQRUSi",
      "expanded_url" : "http://www.atebits.com/letterpress/",
      "display_url" : "atebits.com/letterpress/"
    } ]
  },
  "geo" : { },
  "id_str" : "261144094728921088",
  "text" : "Check out #Letterpress, a sweet new word game for iPhone and iPad! /by @lorenb  http://t.co/xlLQRUSi",
  "id" : 261144094728921088,
  "created_at" : "2012-10-24 16:36:18 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://timehop.com/\" rel=\"nofollow\">Timehop</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 20 ],
      "url" : "http://t.co/GIpU0dPf",
      "expanded_url" : "http://timehop.com/c/5087fa1ee83e3f0023011179",
      "display_url" : "timehop.com/c/5087fa1ee83e\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "261143088448278528",
  "text" : "http://t.co/GIpU0dPf",
  "id" : 261143088448278528,
  "created_at" : "2012-10-24 16:32:18 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6086786436, -122.3060332799 ]
  },
  "id_str" : "260987808641069056",
  "text" : "Who's the funniest Republican comedian?",
  "id" : 260987808641069056,
  "created_at" : "2012-10-24 06:15:17 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "maggim",
      "screen_name" : "maggim",
      "indices" : [ 0, 7 ],
      "id_str" : "14290242",
      "id" : 14290242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "260959269577433088",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.608710914, -122.3059694098 ]
  },
  "id_str" : "260980082980569088",
  "in_reply_to_user_id" : 14290242,
  "text" : "@maggim I work pretty close by! :)",
  "id" : 260980082980569088,
  "in_reply_to_status_id" : 260959269577433088,
  "created_at" : "2012-10-24 05:44:35 +0000",
  "in_reply_to_screen_name" : "maggim",
  "in_reply_to_user_id_str" : "14290242",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ali.",
      "screen_name" : "knockedup",
      "indices" : [ 0, 10 ],
      "id_str" : "518079559",
      "id" : 518079559
    }, {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 59, 69 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "2ndplace",
      "indices" : [ 88, 97 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "260957135389732864",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6143578361, -122.325418365 ]
  },
  "id_str" : "260958630726234112",
  "in_reply_to_user_id" : 518079559,
  "text" : "@knockedup The next level up is in the mouth. Luckily only @kellianne made it that far. #2ndplace",
  "id" : 260958630726234112,
  "in_reply_to_status_id" : 260957135389732864,
  "created_at" : "2012-10-24 04:19:20 +0000",
  "in_reply_to_screen_name" : "knockedup",
  "in_reply_to_user_id_str" : "518079559",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 80 ],
      "url" : "http://t.co/C8YMHnXx",
      "expanded_url" : "http://instagr.am/p/RJpWefI0Hk/",
      "display_url" : "instagr.am/p/RJpWefI0Hk/"
    } ]
  },
  "geo" : { },
  "id_str" : "260952567310327808",
  "text" : "8:36pm Defining the definitions of what needs to be defined http://t.co/C8YMHnXx",
  "id" : 260952567310327808,
  "created_at" : "2012-10-24 03:55:14 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Simple",
      "screen_name" : "Simplify",
      "indices" : [ 0, 9 ],
      "id_str" : "71165241",
      "id" : 71165241
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "260846522227384320",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.611846132, -122.3479592532 ]
  },
  "id_str" : "260848804461441024",
  "in_reply_to_user_id" : 71165241,
  "text" : "@Simplify When will goals be in the iPhone app?",
  "id" : 260848804461441024,
  "in_reply_to_status_id" : 260846522227384320,
  "created_at" : "2012-10-23 21:02:55 +0000",
  "in_reply_to_screen_name" : "Simplify",
  "in_reply_to_user_id_str" : "71165241",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kay Vreeland",
      "screen_name" : "cay_anchor",
      "indices" : [ 0, 11 ],
      "id_str" : "16275525",
      "id" : 16275525
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "260750838723649537",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6086840919, -122.3059802224 ]
  },
  "id_str" : "260758550685548544",
  "in_reply_to_user_id" : 16275525,
  "text" : "@cay_anchor Write 50,000 words on 750 during Nov and the badge is yours!",
  "id" : 260758550685548544,
  "in_reply_to_status_id" : 260750838723649537,
  "created_at" : "2012-10-23 15:04:17 +0000",
  "in_reply_to_screen_name" : "cay_anchor",
  "in_reply_to_user_id_str" : "16275525",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twitter Government",
      "screen_name" : "gov",
      "indices" : [ 3, 7 ],
      "id_str" : "222953824",
      "id" : 222953824
    }, {
      "name" : "Barack Obama",
      "screen_name" : "BarackObama",
      "indices" : [ 74, 86 ],
      "id_str" : "813286",
      "id" : 813286
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lynndebate",
      "indices" : [ 34, 45 ]
    }, {
      "text" : "debates",
      "indices" : [ 128, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "260597466582364160",
  "text" : "RT @gov: Most tweeted moment from #lynndebate: 105,767 tweets per minute- @BarackObama \"We also have fewer horses and bayonets\" #debates",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Barack Obama",
        "screen_name" : "BarackObama",
        "indices" : [ 65, 77 ],
        "id_str" : "813286",
        "id" : 813286
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "lynndebate",
        "indices" : [ 25, 36 ]
      }, {
        "text" : "debates",
        "indices" : [ 119, 127 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "260585717418315777",
    "text" : "Most tweeted moment from #lynndebate: 105,767 tweets per minute- @BarackObama \"We also have fewer horses and bayonets\" #debates",
    "id" : 260585717418315777,
    "created_at" : "2012-10-23 03:37:31 +0000",
    "user" : {
      "name" : "Twitter Government",
      "screen_name" : "gov",
      "protected" : false,
      "id_str" : "222953824",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2284291316/xu1u3i11ugj03en53ujr_normal.png",
      "id" : 222953824,
      "verified" : true
    }
  },
  "id" : 260597466582364160,
  "created_at" : "2012-10-23 04:24:12 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 82 ],
      "url" : "http://t.co/bOaO7i2l",
      "expanded_url" : "http://instagr.am/p/RHCvZ2o0BN/",
      "display_url" : "instagr.am/p/RHCvZ2o0BN/"
    } ]
  },
  "geo" : { },
  "id_str" : "260586639036907520",
  "text" : "8:36pm Me: \"Who won the debate?\" Niko: \"I want more raisins!\" http://t.co/bOaO7i2l",
  "id" : 260586639036907520,
  "created_at" : "2012-10-23 03:41:10 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lane Becker",
      "screen_name" : "monstro",
      "indices" : [ 3, 11 ],
      "id_str" : "4030",
      "id" : 4030
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "260561600816234498",
  "text" : "RT @monstro: We are also 4 years closer to the sun flaming out.",
  "retweeted_status" : {
    "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "260560544547872768",
    "text" : "We are also 4 years closer to the sun flaming out.",
    "id" : 260560544547872768,
    "created_at" : "2012-10-23 01:57:29 +0000",
    "user" : {
      "name" : "Lane Becker",
      "screen_name" : "monstro",
      "protected" : false,
      "id_str" : "4030",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1248189330/Judith_s_40th_Birthday-248_normal.jpg",
      "id" : 4030,
      "verified" : false
    }
  },
  "id" : 260561600816234498,
  "created_at" : "2012-10-23 02:01:41 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "startyourmemes",
      "indices" : [ 69, 84 ]
    }, {
      "text" : "debates",
      "indices" : [ 85, 93 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6087122132, -122.3061990739 ]
  },
  "id_str" : "260546885171961856",
  "text" : "Everyone open up incognito tabs on Twitter and Tumblr sign up pages! #startyourmemes #debates",
  "id" : 260546885171961856,
  "created_at" : "2012-10-23 01:03:12 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RunKeeper",
      "screen_name" : "RunKeeper",
      "indices" : [ 11, 21 ],
      "id_str" : "15445811",
      "id" : 15445811
    }, {
      "name" : "Jon Gilman",
      "screen_name" : "jongilman",
      "indices" : [ 105, 115 ],
      "id_str" : "16908938",
      "id" : 16908938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "260494228298280960",
  "text" : "Just added @runkeeper's 16-week \"Beginner Marathon\" trainer package, which are apparently FREE now. /thx @jongilman",
  "id" : 260494228298280960,
  "created_at" : "2012-10-22 21:33:58 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://bufferapp.com\" rel=\"nofollow\">Buffer</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 72 ],
      "url" : "http://t.co/1pk5zxxa",
      "expanded_url" : "http://Amazon.com",
      "display_url" : "Amazon.com"
    }, {
      "indices" : [ 109, 129 ],
      "url" : "http://t.co/MC5hStx4",
      "expanded_url" : "http://bit.ly/QOgR1M",
      "display_url" : "bit.ly/QOgR1M"
    } ]
  },
  "geo" : { },
  "id_str" : "260456830340329472",
  "text" : "I've been testing this for months -- it's awesome! \"http://t.co/1pk5zxxa vets launch news service Goldfinch\" http://t.co/MC5hStx4",
  "id" : 260456830340329472,
  "created_at" : "2012-10-22 19:05:22 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emilio Ramirez",
      "screen_name" : "e_ramirez",
      "indices" : [ 0, 10 ],
      "id_str" : "1273564632",
      "id" : 1273564632
    }, {
      "name" : "Beau Gunderson",
      "screen_name" : "beaugunderson",
      "indices" : [ 11, 25 ],
      "id_str" : "5746882",
      "id" : 5746882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "260243916077531136",
  "geo" : { },
  "id_str" : "260245185819193345",
  "in_reply_to_user_id" : 21135674,
  "text" : "@e_ramirez @beaugunderson Isn\u2019t that the mission of QS in a way?",
  "id" : 260245185819193345,
  "in_reply_to_status_id" : 260243916077531136,
  "created_at" : "2012-10-22 05:04:22 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emilio Ramirez",
      "screen_name" : "e_ramirez",
      "indices" : [ 0, 10 ],
      "id_str" : "1273564632",
      "id" : 1273564632
    }, {
      "name" : "Beau Gunderson",
      "screen_name" : "beaugunderson",
      "indices" : [ 11, 25 ],
      "id_str" : "5746882",
      "id" : 5746882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "260243205260455936",
  "geo" : { },
  "id_str" : "260243743335137281",
  "in_reply_to_user_id" : 21135674,
  "text" : "@e_ramirez @beaugunderson I do like R. But it\u2019s not a consumer product. That\u2019s the only mode I think in.",
  "id" : 260243743335137281,
  "in_reply_to_status_id" : 260243205260455936,
  "created_at" : "2012-10-22 04:58:38 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emilio Ramirez",
      "screen_name" : "e_ramirez",
      "indices" : [ 0, 10 ],
      "id_str" : "1273564632",
      "id" : 1273564632
    }, {
      "name" : "Beau Gunderson",
      "screen_name" : "beaugunderson",
      "indices" : [ 11, 25 ],
      "id_str" : "5746882",
      "id" : 5746882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "260191640042491905",
  "geo" : { },
  "id_str" : "260242927685623808",
  "in_reply_to_user_id" : 21135674,
  "text" : "@e_ramirez @beaugunderson Wizard is awesome and by far the closest I\u2019ve found so far. StatWing is way off. I have a specific idea here...",
  "id" : 260242927685623808,
  "in_reply_to_status_id" : 260191640042491905,
  "created_at" : "2012-10-22 04:55:23 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "fambai",
      "screen_name" : "fambai",
      "indices" : [ 21, 28 ],
      "id_str" : "12476332",
      "id" : 12476332
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 63 ],
      "url" : "http://t.co/cZ6DLJfM",
      "expanded_url" : "http://instagr.am/p/REd941o0IO/",
      "display_url" : "instagr.am/p/REd941o0IO/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6133424229, -122.346343719 ]
  },
  "id_str" : "260223993016107008",
  "text" : "8:36pm Reunited with @fambai!  @ Local 360 http://t.co/cZ6DLJfM",
  "id" : 260223993016107008,
  "created_at" : "2012-10-22 03:40:09 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emilio Ramirez",
      "screen_name" : "e_ramirez",
      "indices" : [ 0, 10 ],
      "id_str" : "1273564632",
      "id" : 1273564632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "260176564791177217",
  "geo" : { },
  "id_str" : "260177404989952002",
  "in_reply_to_user_id" : 21135674,
  "text" : "@e_ramirez Nice, thanks!",
  "id" : 260177404989952002,
  "in_reply_to_status_id" : 260176564791177217,
  "created_at" : "2012-10-22 00:35:01 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emilio Ramirez",
      "screen_name" : "e_ramirez",
      "indices" : [ 0, 10 ],
      "id_str" : "1273564632",
      "id" : 1273564632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "260173591075766272",
  "geo" : { },
  "id_str" : "260176427721318400",
  "in_reply_to_user_id" : 21135674,
  "text" : "@e_ramirez Correlation and visualization mostly. Probably more once those were done right too.",
  "id" : 260176427721318400,
  "in_reply_to_status_id" : 260173591075766272,
  "created_at" : "2012-10-22 00:31:08 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emilio Ramirez",
      "screen_name" : "e_ramirez",
      "indices" : [ 0, 10 ],
      "id_str" : "1273564632",
      "id" : 1273564632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "260164477016752128",
  "geo" : { },
  "id_str" : "260165091180285952",
  "in_reply_to_user_id" : 21135674,
  "text" : "@e_ramirez Yeah, I know that one, but what about a web service-ified version of that?",
  "id" : 260165091180285952,
  "in_reply_to_status_id" : 260164477016752128,
  "created_at" : "2012-10-21 23:46:06 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emilio Ramirez",
      "screen_name" : "e_ramirez",
      "indices" : [ 0, 10 ],
      "id_str" : "1273564632",
      "id" : 1273564632
    }, {
      "name" : "Dropbox",
      "screen_name" : "Dropbox",
      "indices" : [ 86, 94 ],
      "id_str" : "14749606",
      "id" : 14749606
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "quantifiedself",
      "indices" : [ 30, 45 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "260163996836052993",
  "in_reply_to_user_id" : 21135674,
  "text" : "@e_ramirez Do you know of any #quantifiedself tools that take a CSV file (i.e. public @dropbox file) and make correlations from it?",
  "id" : 260163996836052993,
  "created_at" : "2012-10-21 23:41:45 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emilio Ramirez",
      "screen_name" : "e_ramirez",
      "indices" : [ 0, 10 ],
      "id_str" : "1273564632",
      "id" : 1273564632
    }, {
      "name" : "Svbtle",
      "screen_name" : "Svbtle",
      "indices" : [ 32, 39 ],
      "id_str" : "776098190",
      "id" : 776098190
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "260145882584981504",
  "geo" : { },
  "id_str" : "260146121568038913",
  "in_reply_to_user_id" : 21135674,
  "text" : "@e_ramirez Then I have won! /cc @svbtle",
  "id" : 260146121568038913,
  "in_reply_to_status_id" : 260145882584981504,
  "created_at" : "2012-10-21 22:30:43 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Svbtle Feed",
      "screen_name" : "SvbtleFeed",
      "indices" : [ 39, 50 ],
      "id_str" : "1352847072",
      "id" : 1352847072
    }, {
      "name" : "Dalton Caldwell",
      "screen_name" : "daltonc",
      "indices" : [ 107, 115 ],
      "id_str" : "9151842",
      "id" : 9151842
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 102 ],
      "url" : "http://t.co/QnMcLLhf",
      "expanded_url" : "http://daltoncaldwell.com/reflections-on-startup-school",
      "display_url" : "daltoncaldwell.com/reflections-on\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6086525318, -122.3061069795 ]
  },
  "id_str" : "260142972341989377",
  "text" : "Talk about things you'd rather hide RT @SvbtleFeed: Reflections on Startup School http://t.co/QnMcLLhf /by @daltonc",
  "id" : 260142972341989377,
  "created_at" : "2012-10-21 22:18:12 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Malcolm Browne Dash",
      "screen_name" : "malcolmdash",
      "indices" : [ 0, 12 ],
      "id_str" : "235732875",
      "id" : 235732875
    }, {
      "name" : "Niko Benson",
      "screen_name" : "nikobenson",
      "indices" : [ 22, 33 ],
      "id_str" : "142467448",
      "id" : 142467448
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "260092173737922560",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6150261751, -122.3544439675 ]
  },
  "id_str" : "260115517686308864",
  "in_reply_to_user_id" : 235732875,
  "text" : "@malcolmdash That was @nikobenson's first guess always too! I think it's just the most fun to say.",
  "id" : 260115517686308864,
  "in_reply_to_status_id" : 260092173737922560,
  "created_at" : "2012-10-21 20:29:06 +0000",
  "in_reply_to_screen_name" : "malcolmdash",
  "in_reply_to_user_id_str" : "235732875",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles Mudede",
      "screen_name" : "mudede",
      "indices" : [ 3, 10 ],
      "id_str" : "33412856",
      "id" : 33412856
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "260114362268786689",
  "text" : "RT @mudede: \"All attempts to say what [beauty] is, are as foolish as cutting out the head of a drum to find whence comes the sound.\"",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "260099163696541696",
    "text" : "\"All attempts to say what [beauty] is, are as foolish as cutting out the head of a drum to find whence comes the sound.\"",
    "id" : 260099163696541696,
    "created_at" : "2012-10-21 19:24:07 +0000",
    "user" : {
      "name" : "Charles Mudede",
      "screen_name" : "mudede",
      "protected" : false,
      "id_str" : "33412856",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1005741619/l_9523fb95b5434e7f93d4c3c476ca5d4e_normal.jpg",
      "id" : 33412856,
      "verified" : false
    }
  },
  "id" : 260114362268786689,
  "created_at" : "2012-10-21 20:24:31 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ron Diver",
      "screen_name" : "rondiver",
      "indices" : [ 17, 26 ],
      "id_str" : "12661782",
      "id" : 12661782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 130 ],
      "url" : "http://t.co/XwW7grdV",
      "expanded_url" : "http://www.allvoices.com/contributed-news/13221476-romney-family-buys-voting-machines-through-bain-capital-investment",
      "display_url" : "allvoices.com/contributed-ne\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6153141281, -122.3544963905 ]
  },
  "id_str" : "260113909070049280",
  "text" : "Crazy if true RT @rondiver: Romney family actually OWNS the voting machines to be used in OH, TX, OK, WA, CO. http://t.co/XwW7grdV",
  "id" : 260113909070049280,
  "created_at" : "2012-10-21 20:22:43 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 76 ],
      "url" : "http://t.co/UsnODP3z",
      "expanded_url" : "http://instagr.am/p/RDoLVkI0N7/",
      "display_url" : "instagr.am/p/RDoLVkI0N7/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.615071, -122.354059 ]
  },
  "id_str" : "260105688846585856",
  "text" : "A perfect day for choo-spotting @ Old Spaghetti Factory http://t.co/UsnODP3z",
  "id" : 260105688846585856,
  "created_at" : "2012-10-21 19:50:03 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.608624748, -122.306074435 ]
  },
  "id_str" : "260095455839547392",
  "text" : "Me: \"Let's go.\"\nNiko: \"4 more minutes.\"\nMe: \"Uh, okay.\"\n(4 minutes later...)\nMe: \"Time's up!\"\nNiko: \"No, time's down!\"",
  "id" : 260095455839547392,
  "created_at" : "2012-10-21 19:09:23 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "fambai",
      "screen_name" : "fambai",
      "indices" : [ 44, 51 ],
      "id_str" : "12476332",
      "id" : 12476332
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 73 ],
      "url" : "http://t.co/1lafzUgq",
      "expanded_url" : "http://instagr.am/p/RDQ1lmo0DS/",
      "display_url" : "instagr.am/p/RDQ1lmo0DS/"
    } ]
  },
  "geo" : { },
  "id_str" : "260054259394039809",
  "text" : "New York Times from Niko's birthday! Thanks @fambai! http://t.co/1lafzUgq",
  "id" : 260054259394039809,
  "created_at" : "2012-10-21 16:25:41 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"https://lightt.com\" rel=\"nofollow\">Lightt</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 44 ],
      "url" : "http://t.co/ZZSl4fby",
      "expanded_url" : "http://ligh.tt/a4E",
      "display_url" : "ligh.tt/a4E"
    } ]
  },
  "geo" : { },
  "id_str" : "259915905960648704",
  "text" : "Nightly face exercises  http://t.co/ZZSl4fby",
  "id" : 259915905960648704,
  "created_at" : "2012-10-21 07:15:55 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Sutter",
      "screen_name" : "pinwheel",
      "indices" : [ 0, 9 ],
      "id_str" : "22483",
      "id" : 22483
    }, {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 21, 31 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "259906971103285250",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6086782665, -122.3061452621 ]
  },
  "id_str" : "259911300338036736",
  "in_reply_to_user_id" : 22483,
  "text" : "@pinwheel I'm making @kellianne drink the rest for not corking it.",
  "id" : 259911300338036736,
  "in_reply_to_status_id" : 259906971103285250,
  "created_at" : "2012-10-21 06:57:37 +0000",
  "in_reply_to_screen_name" : "pinwheel",
  "in_reply_to_user_id_str" : "22483",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6086355187, -122.306158254 ]
  },
  "id_str" : "259901346411601920",
  "text" : "Realized after half a glass of wine that was opened yesterday that the chunky stuff wasn't sediment, but rather fruit flies.",
  "id" : 259901346411601920,
  "created_at" : "2012-10-21 06:18:04 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bastian Greshake",
      "screen_name" : "gedankenstuecke",
      "indices" : [ 0, 16 ],
      "id_str" : "14286491",
      "id" : 14286491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "259899054719397888",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6085964591, -122.3060380575 ]
  },
  "id_str" : "259900170165178368",
  "in_reply_to_user_id" : 14286491,
  "text" : "@gedankenstuecke Nike Running iPhone app.",
  "id" : 259900170165178368,
  "in_reply_to_status_id" : 259899054719397888,
  "created_at" : "2012-10-21 06:13:23 +0000",
  "in_reply_to_screen_name" : "gedankenstuecke",
  "in_reply_to_user_id_str" : "14286491",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Path",
      "screen_name" : "path",
      "indices" : [ 49, 54 ],
      "id_str" : "106333951",
      "id" : 106333951
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/buster/status/259884825668902912/photo/1",
      "indices" : [ 72, 92 ],
      "url" : "http://t.co/NhomqEXL",
      "media_url" : "http://pbs.twimg.com/media/A5tL3z0CYAAz6EH.jpg",
      "id_str" : "259884825677291520",
      "id" : 259884825677291520,
      "media_url_https" : "https://pbs.twimg.com/media/A5tL3z0CYAAz6EH.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 577
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 577
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 603,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 577
      } ],
      "display_url" : "pic.twitter.com/NhomqEXL"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.608642811, -122.3062005826 ]
  },
  "id_str" : "259884825668902912",
  "text" : "Gotta admit that Nike Running's integration with @Path is pretty sweet. http://t.co/NhomqEXL",
  "id" : 259884825668902912,
  "created_at" : "2012-10-21 05:12:26 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 57 ],
      "url" : "http://t.co/WTlJxVDx",
      "expanded_url" : "http://instagr.am/p/RB5Ir1o0LR/",
      "display_url" : "instagr.am/p/RB5Ir1o0LR/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.661832322, -122.299976349 ]
  },
  "id_str" : "259861493368107008",
  "text" : "8:36pm \"I'm a robot!\" @ Blue C Sushi http://t.co/WTlJxVDx",
  "id" : 259861493368107008,
  "created_at" : "2012-10-21 03:39:42 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 65 ],
      "url" : "http://t.co/q4v7QVob",
      "expanded_url" : "http://instagr.am/p/RBxVXco0Cy/",
      "display_url" : "instagr.am/p/RBxVXco0Cy/"
    } ]
  },
  "geo" : { },
  "id_str" : "259844345866371072",
  "text" : "Had to stop and take a picture during my run http://t.co/q4v7QVob",
  "id" : 259844345866371072,
  "created_at" : "2012-10-21 02:31:34 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Jacobs",
      "screen_name" : "djacobs",
      "indices" : [ 4, 12 ],
      "id_str" : "774842",
      "id" : 774842
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "259833508644655104",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6087127566, -122.3060176859 ]
  },
  "id_str" : "259841531278675968",
  "in_reply_to_user_id" : 774842,
  "text" : "Pay @djacobs $1 for complaining about  the nonplussed nature of my body after a run.",
  "id" : 259841531278675968,
  "in_reply_to_status_id" : 259833508644655104,
  "created_at" : "2012-10-21 02:20:23 +0000",
  "in_reply_to_screen_name" : "djacobs",
  "in_reply_to_user_id_str" : "774842",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 11, 21 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6086614188, -122.3060691544 ]
  },
  "id_str" : "259830988836851712",
  "text" : "I promised @kellianne last week that I'd run a marathon by her next birthday. My body just got the memo and is a bit nonplussed. Ouch.",
  "id" : 259830988836851712,
  "created_at" : "2012-10-21 01:38:29 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/nike-gps/id387771637?mt=8&uo=4\" rel=\"nofollow\">Nike+ GPS on iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nikeplus",
      "indices" : [ 97, 106 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "259826361194139648",
  "text" : "1st run in 2+ years.  I just finished a 4.68 mi run with a pace of 11'52\"/mi with Nike+ Running. #nikeplus",
  "id" : 259826361194139648,
  "created_at" : "2012-10-21 01:20:06 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emilio Ramirez",
      "screen_name" : "e_ramirez",
      "indices" : [ 0, 10 ],
      "id_str" : "1273564632",
      "id" : 1273564632
    }, {
      "name" : "Lightt",
      "screen_name" : "lightt",
      "indices" : [ 61, 68 ],
      "id_str" : "583124837",
      "id" : 583124837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "259743291212451841",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6086339681, -122.3061186915 ]
  },
  "id_str" : "259757997851553792",
  "in_reply_to_user_id" : 21135674,
  "text" : "@e_ramirez Thanks for the rec! That is pretty dang cool. /cc @lightt",
  "id" : 259757997851553792,
  "in_reply_to_status_id" : 259743291212451841,
  "created_at" : "2012-10-20 20:48:27 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"https://lightt.com\" rel=\"nofollow\">Lightt</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lightt",
      "screen_name" : "lightt",
      "indices" : [ 8, 15 ],
      "id_str" : "583124837",
      "id" : 583124837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http://t.co/T2iyXjKr",
      "expanded_url" : "http://ligh.tt/i3w",
      "display_url" : "ligh.tt/i3w"
    } ]
  },
  "geo" : { },
  "id_str" : "259749617929973761",
  "text" : "Testing @lightt http://t.co/T2iyXjKr",
  "id" : 259749617929973761,
  "created_at" : "2012-10-20 20:15:09 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Rainert",
      "screen_name" : "arainert",
      "indices" : [ 0, 9 ],
      "id_str" : "7482",
      "id" : 7482
    }, {
      "name" : "Vine",
      "screen_name" : "vineapp",
      "indices" : [ 22, 30 ],
      "id_str" : "586671909",
      "id" : 586671909
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "259734579563343872",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6086424195, -122.3061924398 ]
  },
  "id_str" : "259735628730732544",
  "in_reply_to_user_id" : 7482,
  "text" : "@arainert I will! /cc @vineapp",
  "id" : 259735628730732544,
  "in_reply_to_status_id" : 259734579563343872,
  "created_at" : "2012-10-20 19:19:34 +0000",
  "in_reply_to_screen_name" : "arainert",
  "in_reply_to_user_id_str" : "7482",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 22, 32 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6086477144, -122.3062688113 ]
  },
  "id_str" : "259541587703517185",
  "text" : "I'm home and Niko and @Kellianne are asleep so I'm stalking old Instagram photos of them. Should I wake them up and throw a party??",
  "id" : 259541587703517185,
  "created_at" : "2012-10-20 06:28:31 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "metired",
      "indices" : [ 41, 49 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 137 ],
      "url" : "http://t.co/NXJhGash",
      "expanded_url" : "http://4sq.com/OQeFKQ",
      "display_url" : "4sq.com/OQeFKQ"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.4436465828, -122.3025941849 ]
  },
  "id_str" : "259526715003502592",
  "text" : "8:36pm Back in Seattle for a whole week! #metired (@ Seattle-Tacoma International Airport (SEA) w/ 80 others) [pic]: http://t.co/NXJhGash",
  "id" : 259526715003502592,
  "created_at" : "2012-10-20 05:29:25 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cap Watkins",
      "screen_name" : "cap",
      "indices" : [ 125, 129 ],
      "id_str" : "2182141",
      "id" : 2182141
    }, {
      "name" : "kottke.org",
      "screen_name" : "kottke",
      "indices" : [ 130, 137 ],
      "id_str" : "14120215",
      "id" : 14120215
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 120 ],
      "url" : "http://t.co/HQOd3T3l",
      "expanded_url" : "http://wayoftheduck.com/blogs-vs-tweets",
      "display_url" : "wayoftheduck.com/blogs-vs-tweets"
    } ]
  },
  "geo" : { },
  "id_str" : "259512222013874176",
  "text" : "Tweeting doesn't have an obvious correlation to # of blog posts I've written over the last 13 years http://t.co/HQOd3T3l /cc @cap @kottke",
  "id" : 259512222013874176,
  "created_at" : "2012-10-20 04:31:49 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ximing Yu \u4E8E\u5E0C\u660E",
      "screen_name" : "ximyu",
      "indices" : [ 0, 6 ],
      "id_str" : "25930069",
      "id" : 25930069
    }, {
      "name" : "Jake Harding",
      "screen_name" : "JakeHarding",
      "indices" : [ 7, 19 ],
      "id_str" : "58502284",
      "id" : 58502284
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "coincidence",
      "indices" : [ 100, 112 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "259485129897025536",
  "geo" : { },
  "id_str" : "259495578705199104",
  "in_reply_to_user_id" : 25930069,
  "text" : "@ximyu @JakeHarding Personally, I think the TweetDeck Mac app is pretty awesome. Plus it has cards! #coincidence?",
  "id" : 259495578705199104,
  "in_reply_to_status_id" : 259485129897025536,
  "created_at" : "2012-10-20 03:25:41 +0000",
  "in_reply_to_screen_name" : "ximyu",
  "in_reply_to_user_id_str" : "25930069",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Neil deGrasse Tyson",
      "screen_name" : "neiltyson",
      "indices" : [ 3, 13 ],
      "id_str" : "19725644",
      "id" : 19725644
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "259488025724190720",
  "text" : "RT @neiltyson: A H R B Q D W E F L M N S X G I J K O P C T V Y U Z -- Gotta love what the alphabet looks like in alphabetical order.",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "259486092766625793",
    "text" : "A H R B Q D W E F L M N S X G I J K O P C T V Y U Z -- Gotta love what the alphabet looks like in alphabetical order.",
    "id" : 259486092766625793,
    "created_at" : "2012-10-20 02:48:00 +0000",
    "user" : {
      "name" : "Neil deGrasse Tyson",
      "screen_name" : "neiltyson",
      "protected" : false,
      "id_str" : "19725644",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/74188698/NeilTysonOriginsA-Crop_normal.jpg",
      "id" : 19725644,
      "verified" : true
    }
  },
  "id" : 259488025724190720,
  "created_at" : "2012-10-20 02:55:41 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lane Collins",
      "screen_name" : "lane",
      "indices" : [ 0, 5 ],
      "id_str" : "541",
      "id" : 541
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "259485159378788352",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.6138049969, -122.3858730573 ]
  },
  "id_str" : "259486251458117632",
  "in_reply_to_user_id" : 541,
  "text" : "@lane Oh man. I'm sorry. For what it's worth my flight is really warm.",
  "id" : 259486251458117632,
  "in_reply_to_status_id" : 259485159378788352,
  "created_at" : "2012-10-20 02:48:38 +0000",
  "in_reply_to_screen_name" : "lane",
  "in_reply_to_user_id_str" : "541",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jake Harding",
      "screen_name" : "JakeHarding",
      "indices" : [ 0, 12 ],
      "id_str" : "58502284",
      "id" : 58502284
    }, {
      "name" : "Ximing Yu \u4E8E\u5E0C\u660E",
      "screen_name" : "ximyu",
      "indices" : [ 13, 19 ],
      "id_str" : "25930069",
      "id" : 25930069
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "259481497197760512",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.6138297096, -122.3853650597 ]
  },
  "id_str" : "259483308025602048",
  "in_reply_to_user_id" : 58502284,
  "text" : "@JakeHarding @ximyu Are you just trying to hog the user token so someone else can't have it?",
  "id" : 259483308025602048,
  "in_reply_to_status_id" : 259481497197760512,
  "created_at" : "2012-10-20 02:36:56 +0000",
  "in_reply_to_screen_name" : "JakeHarding",
  "in_reply_to_user_id_str" : "58502284",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cap Watkins",
      "screen_name" : "cap",
      "indices" : [ 0, 4 ],
      "id_str" : "2182141",
      "id" : 2182141
    }, {
      "name" : "Mathew Ingram",
      "screen_name" : "mathewi",
      "indices" : [ 5, 13 ],
      "id_str" : "824157",
      "id" : 824157
    }, {
      "name" : "Circa",
      "screen_name" : "Circa",
      "indices" : [ 67, 73 ],
      "id_str" : "441389311",
      "id" : 441389311
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "259477836920922113",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.6135694029, -122.3854669138 ]
  },
  "id_str" : "259480007410323457",
  "in_reply_to_user_id" : 2182141,
  "text" : "@cap @mathewi Which of those do you think will be more successful? @Circa would be my pick.",
  "id" : 259480007410323457,
  "in_reply_to_status_id" : 259477836920922113,
  "created_at" : "2012-10-20 02:23:49 +0000",
  "in_reply_to_screen_name" : "cap",
  "in_reply_to_user_id_str" : "2182141",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cap Watkins",
      "screen_name" : "cap",
      "indices" : [ 0, 4 ],
      "id_str" : "2182141",
      "id" : 2182141
    }, {
      "name" : "Mathew Ingram",
      "screen_name" : "mathewi",
      "indices" : [ 5, 13 ],
      "id_str" : "824157",
      "id" : 824157
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "259477836920922113",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.6136629209, -122.3853492288 ]
  },
  "id_str" : "259479585706610688",
  "in_reply_to_user_id" : 2182141,
  "text" : "@cap @mathewi I'm gonna look up my total blog post count per year since 1998 and get back to you. N of 1 but am mildly curious.",
  "id" : 259479585706610688,
  "in_reply_to_status_id" : 259477836920922113,
  "created_at" : "2012-10-20 02:22:08 +0000",
  "in_reply_to_screen_name" : "cap",
  "in_reply_to_user_id_str" : "2182141",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cap Watkins",
      "screen_name" : "cap",
      "indices" : [ 0, 4 ],
      "id_str" : "2182141",
      "id" : 2182141
    }, {
      "name" : "Mathew Ingram",
      "screen_name" : "mathewi",
      "indices" : [ 5, 13 ],
      "id_str" : "824157",
      "id" : 824157
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "259470819628040192",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.6132468451, -122.3847281005 ]
  },
  "id_str" : "259477285902618624",
  "in_reply_to_user_id" : 2182141,
  "text" : "@cap @mathewi Yeah but I can't tell you how many of my blog posts have died because they fit into a tweet.",
  "id" : 259477285902618624,
  "in_reply_to_status_id" : 259470819628040192,
  "created_at" : "2012-10-20 02:13:00 +0000",
  "in_reply_to_screen_name" : "cap",
  "in_reply_to_user_id_str" : "2182141",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ingopixel",
      "screen_name" : "ingopixel",
      "indices" : [ 0, 10 ],
      "id_str" : "7943892",
      "id" : 7943892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "259473997144670208",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.6132103687, -122.3849372501 ]
  },
  "id_str" : "259476664524869632",
  "in_reply_to_user_id" : 7943892,
  "text" : "@ingopixel Good eye!",
  "id" : 259476664524869632,
  "in_reply_to_status_id" : 259473997144670208,
  "created_at" : "2012-10-20 02:10:32 +0000",
  "in_reply_to_screen_name" : "ingopixel",
  "in_reply_to_user_id_str" : "7943892",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "gavin gourley",
      "screen_name" : "summitandolive",
      "indices" : [ 0, 15 ],
      "id_str" : "38113339",
      "id" : 38113339
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "259467958307397632",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.6129860148, -122.3845749401 ]
  },
  "id_str" : "259471257219764224",
  "in_reply_to_user_id" : 38113339,
  "text" : "@summitandolive Woah it never even occurred to me to put a folder on the dock! Neat.",
  "id" : 259471257219764224,
  "in_reply_to_status_id" : 259467958307397632,
  "created_at" : "2012-10-20 01:49:03 +0000",
  "in_reply_to_screen_name" : "summitandolive",
  "in_reply_to_user_id_str" : "38113339",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emilio Ramirez",
      "screen_name" : "e_ramirez",
      "indices" : [ 0, 10 ],
      "id_str" : "1273564632",
      "id" : 1273564632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "259466078399369217",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.6132100459, -122.3848415157 ]
  },
  "id_str" : "259471106459701249",
  "in_reply_to_user_id" : 21135674,
  "text" : "@e_ramirez Yeah I pretty much never use it.",
  "id" : 259471106459701249,
  "in_reply_to_status_id" : 259466078399369217,
  "created_at" : "2012-10-20 01:48:27 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 47, 57 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/buster/status/259462175435927552/photo/1",
      "indices" : [ 65, 85 ],
      "url" : "http://t.co/njryeh2q",
      "media_url" : "http://pbs.twimg.com/media/A5nLeVACMAAu0Eb.jpg",
      "id_str" : "259462175444316160",
      "id" : 259462175444316160,
      "media_url_https" : "https://pbs.twimg.com/media/A5nLeVACMAAu0Eb.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 577
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 577
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 603,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 577
      } ],
      "display_url" : "pic.twitter.com/njryeh2q"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.6166907046, -122.4022483082 ]
  },
  "id_str" : "259462175435927552",
  "text" : "Simplified my phone's home screen so I can see @kellianne better http://t.co/njryeh2q",
  "id" : 259462175435927552,
  "created_at" : "2012-10-20 01:12:58 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "teatime",
      "indices" : [ 16, 24 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7788396704, -122.4145560491 ]
  },
  "id_str" : "259454413960278017",
  "text" : "That was a good #teatime.",
  "id" : 259454413960278017,
  "created_at" : "2012-10-20 00:42:07 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://bufferapp.com\" rel=\"nofollow\">Buffer</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robin Sloan",
      "screen_name" : "robinsloan",
      "indices" : [ 52, 63 ],
      "id_str" : "13919072",
      "id" : 13919072
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 46 ],
      "url" : "http://t.co/GIiOudtj",
      "expanded_url" : "http://bit.ly/PGYwbP",
      "display_url" : "bit.ly/PGYwbP"
    } ]
  },
  "geo" : { },
  "id_str" : "259442611113299968",
  "text" : "\u201CWeird Twitter\u201D explained http://t.co/GIiOudtj /via @robinsloan",
  "id" : 259442611113299968,
  "created_at" : "2012-10-19 23:55:13 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jessica Zollman",
      "screen_name" : "jayzombie",
      "indices" : [ 12, 22 ],
      "id_str" : "14973634",
      "id" : 14973634
    }, {
      "name" : "Instagram",
      "screen_name" : "instagram",
      "indices" : [ 50, 60 ],
      "id_str" : "180505807",
      "id" : 180505807
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 129 ],
      "url" : "http://t.co/i0jMeEoc",
      "expanded_url" : "http://bit.ly/TjAUvh",
      "display_url" : "bit.ly/TjAUvh"
    } ]
  },
  "in_reply_to_status_id_str" : "259354292819996672",
  "geo" : { },
  "id_str" : "259356445466849281",
  "in_reply_to_user_id" : 14973634,
  "text" : "Awesome! RT @jayzombie THIS! 1,000 times this. RT @instagram: Instagram @-mentions now translate to Twitter! http://t.co/i0jMeEoc",
  "id" : 259356445466849281,
  "in_reply_to_status_id" : 259354292819996672,
  "created_at" : "2012-10-19 18:12:49 +0000",
  "in_reply_to_screen_name" : "jayzombie",
  "in_reply_to_user_id_str" : "14973634",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Hefferan",
      "screen_name" : "danhefferan",
      "indices" : [ 0, 12 ],
      "id_str" : "102861135",
      "id" : 102861135
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "259335153975963648",
  "geo" : { },
  "id_str" : "259335638938185728",
  "in_reply_to_user_id" : 102861135,
  "text" : "@danhefferan Decided while not a complaint, it's still not something I should be doing. Thanks!",
  "id" : 259335638938185728,
  "in_reply_to_status_id" : 259335153975963648,
  "created_at" : "2012-10-19 16:50:09 +0000",
  "in_reply_to_screen_name" : "danhefferan",
  "in_reply_to_user_id_str" : "102861135",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Hefferan",
      "screen_name" : "danhefferan",
      "indices" : [ 4, 16 ],
      "id_str" : "102861135",
      "id" : 102861135
    }, {
      "name" : "Pheed",
      "screen_name" : "Pheed",
      "indices" : [ 98, 104 ],
      "id_str" : "442559690",
      "id" : 442559690
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 69 ],
      "url" : "http://t.co/Sgyr4QiL",
      "expanded_url" : "http://pheed.com",
      "display_url" : "pheed.com"
    } ]
  },
  "geo" : { },
  "id_str" : "259335472210382848",
  "text" : "Pay @danhefferan $1 for talking negatively about http://t.co/Sgyr4QiL's without being direct. So\u2026 @pheed -- you're doing it wrong. Stop.",
  "id" : 259335472210382848,
  "created_at" : "2012-10-19 16:49:29 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Hefferan",
      "screen_name" : "danhefferan",
      "indices" : [ 0, 12 ],
      "id_str" : "102861135",
      "id" : 102861135
    }, {
      "name" : "Pheed",
      "screen_name" : "Pheed",
      "indices" : [ 64, 70 ],
      "id_str" : "442559690",
      "id" : 442559690
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "259334512960487424",
  "geo" : { },
  "id_str" : "259334861012217856",
  "in_reply_to_user_id" : 102861135,
  "text" : "@danhefferan No I don't think so.  A complaint would be \"why is @pheed so stoooopid!?\" :) But it's your call\u2026 what do you think?",
  "id" : 259334861012217856,
  "in_reply_to_status_id" : 259334512960487424,
  "created_at" : "2012-10-19 16:47:03 +0000",
  "in_reply_to_screen_name" : "danhefferan",
  "in_reply_to_user_id_str" : "102861135",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 27 ],
      "url" : "http://t.co/Sgyr4QiL",
      "expanded_url" : "http://pheed.com",
      "display_url" : "pheed.com"
    } ]
  },
  "geo" : { },
  "id_str" : "259333396147347457",
  "text" : "Beware http://t.co/Sgyr4QiL's auto-tweeting signup flow. PS that site is cray cray.",
  "id" : 259333396147347457,
  "created_at" : "2012-10-19 16:41:14 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.pheed.com\" rel=\"nofollow\">Pheed</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 70 ],
      "url" : "https://t.co/x56hTa1I",
      "expanded_url" : "https://www.pheed.com/brynnevans",
      "display_url" : "pheed.com/brynnevans"
    } ]
  },
  "geo" : { },
  "id_str" : "259314256971984896",
  "text" : "I just subscribed to brynn evans's Pheed channel https://t.co/x56hTa1I",
  "id" : 259314256971984896,
  "created_at" : "2012-10-19 15:25:11 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sung Hu Kim",
      "screen_name" : "sunghu",
      "indices" : [ 113, 120 ],
      "id_str" : "11407672",
      "id" : 11407672
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 107 ],
      "url" : "http://t.co/9P3rMyW6",
      "expanded_url" : "http://www.avc.com/a_vc/2012/10/feature-friday-twitter-mobile-notifications-on-android.html",
      "display_url" : "avc.com/a_vc/2012/10/f\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7795553621, -122.4139170147 ]
  },
  "id_str" : "259309269541867521",
  "text" : "Turn on mobile notifications for people you love and want to *super-follow* on Twitter http://t.co/9P3rMyW6 /via @sunghu",
  "id" : 259309269541867521,
  "created_at" : "2012-10-19 15:05:22 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 99 ],
      "url" : "http://t.co/8qe183lG",
      "expanded_url" : "http://flic.kr/p/dkVzjB",
      "display_url" : "flic.kr/p/dkVzjB"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7775, -122.415167 ]
  },
  "id_str" : "259136490720878592",
  "text" : "8:36pm The fitness center is broken so watching Nate Silver on The Daily Show. http://t.co/8qe183lG",
  "id" : 259136490720878592,
  "created_at" : "2012-10-19 03:38:48 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.pheed.com\" rel=\"nofollow\">Pheed</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 66 ],
      "url" : "https://t.co/9tyxGUsk",
      "expanded_url" : "https://www.pheed.com/busterbenson",
      "display_url" : "pheed.com/busterbenson"
    } ]
  },
  "geo" : { },
  "id_str" : "259119767938531328",
  "text" : "I just opened my Pheed channel, check it out https://t.co/9tyxGUsk",
  "id" : 259119767938531328,
  "created_at" : "2012-10-19 02:32:21 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Galen Ward",
      "screen_name" : "galenward",
      "indices" : [ 97, 107 ],
      "id_str" : "2854761",
      "id" : 2854761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 91 ],
      "url" : "http://t.co/e233TcKA",
      "expanded_url" : "http://j.mp/QtrAhX",
      "display_url" : "j.mp/QtrAhX"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7764662573, -122.4167745755 ]
  },
  "id_str" : "259043383375429634",
  "text" : "An amazing narrative: Henry Blodget's State of The Internet slide deck http://t.co/e233TcKA /via @galenward",
  "id" : 259043383375429634,
  "created_at" : "2012-10-18 21:28:50 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Jacobs",
      "screen_name" : "jjacobs22",
      "indices" : [ 0, 10 ],
      "id_str" : "14850356",
      "id" : 14850356
    }, {
      "name" : "Jon Pierce",
      "screen_name" : "jonpierce",
      "indices" : [ 11, 21 ],
      "id_str" : "186923",
      "id" : 186923
    }, {
      "name" : "Ryan Sarver",
      "screen_name" : "rsarver",
      "indices" : [ 22, 30 ],
      "id_str" : "795649",
      "id" : 795649
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "258871184446328834",
  "geo" : { },
  "id_str" : "258972581825216512",
  "in_reply_to_user_id" : 14850356,
  "text" : "@jjacobs22 @jonpierce @rsarver Thanks, Jason! Let me know if you need any help with that implementation\u2026 or want to talk it out at all.",
  "id" : 258972581825216512,
  "in_reply_to_status_id" : 258871184446328834,
  "created_at" : "2012-10-18 16:47:29 +0000",
  "in_reply_to_screen_name" : "jjacobs22",
  "in_reply_to_user_id_str" : "14850356",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "harscoat",
      "screen_name" : "harscoat",
      "indices" : [ 0, 9 ],
      "id_str" : "18143096",
      "id" : 18143096
    }, {
      "name" : "Emilio Ramirez",
      "screen_name" : "e_ramirez",
      "indices" : [ 10, 20 ],
      "id_str" : "1273564632",
      "id" : 1273564632
    }, {
      "name" : "Gary Wolf",
      "screen_name" : "agaricus",
      "indices" : [ 21, 30 ],
      "id_str" : "21678279",
      "id" : 21678279
    }, {
      "name" : "Jane McGonigal",
      "screen_name" : "avantgame",
      "indices" : [ 31, 41 ],
      "id_str" : "681813",
      "id" : 681813
    }, {
      "name" : "Tim O'Reilly",
      "screen_name" : "timoreilly",
      "indices" : [ 42, 53 ],
      "id_str" : "2384071",
      "id" : 2384071
    }, {
      "name" : "fredtrotter",
      "screen_name" : "fredtrotter",
      "indices" : [ 54, 66 ],
      "id_str" : "16971428",
      "id" : 16971428
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "258945816046227456",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7764341578, -122.416755765 ]
  },
  "id_str" : "258967009218400257",
  "in_reply_to_user_id" : 18143096,
  "text" : "@harscoat @e_ramirez @agaricus @avantgame @timoreilly @fredtrotter Remember it's programmable *self* not programmable *others*.",
  "id" : 258967009218400257,
  "in_reply_to_status_id" : 258945816046227456,
  "created_at" : "2012-10-18 16:25:21 +0000",
  "in_reply_to_screen_name" : "harscoat",
  "in_reply_to_user_id_str" : "18143096",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Wolf",
      "screen_name" : "agaricus",
      "indices" : [ 0, 9 ],
      "id_str" : "21678279",
      "id" : 21678279
    }, {
      "name" : "Emilio Ramirez",
      "screen_name" : "e_ramirez",
      "indices" : [ 10, 20 ],
      "id_str" : "1273564632",
      "id" : 1273564632
    }, {
      "name" : "Jane McGonigal",
      "screen_name" : "avantgame",
      "indices" : [ 21, 31 ],
      "id_str" : "681813",
      "id" : 681813
    }, {
      "name" : "Tim O'Reilly",
      "screen_name" : "timoreilly",
      "indices" : [ 32, 43 ],
      "id_str" : "2384071",
      "id" : 2384071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "258931190361362432",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.776423747, -122.4167540105 ]
  },
  "id_str" : "258966746931818496",
  "in_reply_to_user_id" : 21678279,
  "text" : "@agaricus @e_ramirez @avantgame @timoreilly I'm way more interested in changing my behaviors. That step is of moon-landing proportions.",
  "id" : 258966746931818496,
  "in_reply_to_status_id" : 258931190361362432,
  "created_at" : "2012-10-18 16:24:18 +0000",
  "in_reply_to_screen_name" : "agaricus",
  "in_reply_to_user_id_str" : "21678279",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Wolf",
      "screen_name" : "agaricus",
      "indices" : [ 0, 9 ],
      "id_str" : "21678279",
      "id" : 21678279
    }, {
      "name" : "Emilio Ramirez",
      "screen_name" : "e_ramirez",
      "indices" : [ 10, 20 ],
      "id_str" : "1273564632",
      "id" : 1273564632
    }, {
      "name" : "Jane McGonigal",
      "screen_name" : "avantgame",
      "indices" : [ 21, 31 ],
      "id_str" : "681813",
      "id" : 681813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "258931190361362432",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7767123856, -122.4165847215 ]
  },
  "id_str" : "258966012668542976",
  "in_reply_to_user_id" : 21678279,
  "text" : "@agaricus @e_ramirez @avantgame Behavior does change over time. The questions are: 1) can we change ourselves? 2) can we help others change?",
  "id" : 258966012668542976,
  "in_reply_to_status_id" : 258931190361362432,
  "created_at" : "2012-10-18 16:21:23 +0000",
  "in_reply_to_screen_name" : "agaricus",
  "in_reply_to_user_id_str" : "21678279",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://mobile.twitter.com\" rel=\"nofollow\">Mobile Web</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Macgillivray",
      "screen_name" : "amac",
      "indices" : [ 3, 8 ],
      "id_str" : "9946842",
      "id" : 9946842
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 120 ],
      "url" : "https://t.co/uzGF0Y4w",
      "expanded_url" : "https://www.chillingeffects.org/notice.cgi?sID=625342",
      "display_url" : "chillingeffects.org/notice.cgi?sID\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "258826996044406784",
  "text" : "RT @amac: Never want to withhold content; good to have tools to do it narrowly &amp; transparently https://t.co/uzGF0Y4w. More info http ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 89, 110 ],
        "url" : "https://t.co/uzGF0Y4w",
        "expanded_url" : "https://www.chillingeffects.org/notice.cgi?sID=625342",
        "display_url" : "chillingeffects.org/notice.cgi?sID\u2026"
      }, {
        "indices" : [ 122, 143 ],
        "url" : "https://t.co/yFrYbfUb",
        "expanded_url" : "https://support.twitter.com/articles/20169222-country-withheld-content",
        "display_url" : "support.twitter.com/articles/20169\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "258745846584188928",
    "text" : "Never want to withhold content; good to have tools to do it narrowly &amp; transparently https://t.co/uzGF0Y4w. More info https://t.co/yFrYbfUb",
    "id" : 258745846584188928,
    "created_at" : "2012-10-18 01:46:31 +0000",
    "user" : {
      "name" : "Alex Macgillivray",
      "screen_name" : "amac",
      "protected" : false,
      "id_str" : "9946842",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/189545828/120_2004_IMG.thumb_normal.jpg",
      "id" : 9946842,
      "verified" : false
    }
  },
  "id" : 258826996044406784,
  "created_at" : "2012-10-18 07:08:59 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moka Pantages",
      "screen_name" : "Moka",
      "indices" : [ 19, 24 ],
      "id_str" : "754980",
      "id" : 754980
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 45 ],
      "url" : "http://t.co/M5cnzjum",
      "expanded_url" : "http://flic.kr/p/dkGbiQ",
      "display_url" : "flic.kr/p/dkGbiQ"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.764666, -122.422667 ]
  },
  "id_str" : "258810293348610048",
  "text" : "8:36pm Drinks with @moka http://t.co/M5cnzjum",
  "id" : 258810293348610048,
  "created_at" : "2012-10-18 06:02:37 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Deepika Pujji",
      "screen_name" : "tweepika",
      "indices" : [ 3, 12 ],
      "id_str" : "14354772",
      "id" : 14354772
    }, {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 71, 79 ],
      "id_str" : "783214",
      "id" : 783214
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 66 ],
      "url" : "http://t.co/gKFiSq9X",
      "expanded_url" : "http://blog.twitter.com/2012/10/twitter-at-town-hall-debate.html",
      "display_url" : "blog.twitter.com/2012/10/twitte\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "258599372214910976",
  "text" : "RT @tweepika: Twitter at the Town Hall Debate http://t.co/gKFiSq9X via @twitter",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Twitter",
        "screen_name" : "twitter",
        "indices" : [ 57, 65 ],
        "id_str" : "783214",
        "id" : 783214
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 32, 52 ],
        "url" : "http://t.co/gKFiSq9X",
        "expanded_url" : "http://blog.twitter.com/2012/10/twitter-at-town-hall-debate.html",
        "display_url" : "blog.twitter.com/2012/10/twitte\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "258597758846509056",
    "text" : "Twitter at the Town Hall Debate http://t.co/gKFiSq9X via @twitter",
    "id" : 258597758846509056,
    "created_at" : "2012-10-17 15:58:04 +0000",
    "user" : {
      "name" : "Deepika Pujji",
      "screen_name" : "tweepika",
      "protected" : false,
      "id_str" : "14354772",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000281626335/5d8ea096a4c77127f2e3e06321872c43_normal.jpeg",
      "id" : 14354772,
      "verified" : false
    }
  },
  "id" : 258599372214910976,
  "created_at" : "2012-10-17 16:04:29 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 82 ],
      "url" : "http://t.co/GMGAwiaF",
      "expanded_url" : "http://4sq.com/V7bPPM",
      "display_url" : "4sq.com/V7bPPM"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7770876072, -122.4168981204 ]
  },
  "id_str" : "258597642483929088",
  "text" : "I need a binder full of coffee. (@ Twitter, Inc. w/ 3 others) http://t.co/GMGAwiaF",
  "id" : 258597642483929088,
  "created_at" : "2012-10-17 15:57:37 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getprismatic.com\" rel=\"nofollow\">getprismatic.com</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Prismatic",
      "screen_name" : "Prismatic",
      "indices" : [ 128, 138 ],
      "id_str" : "229709694",
      "id" : 229709694
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 123 ],
      "url" : "http://t.co/9FWOW1AI",
      "expanded_url" : "http://prsm.tc/IuyfFt",
      "display_url" : "prsm.tc/IuyfFt"
    } ]
  },
  "geo" : { },
  "id_str" : "258591180118446080",
  "text" : "What if we had an email address where all conversations were public? Maybe an interesting experiment:  http://t.co/9FWOW1AI via @prismatic",
  "id" : 258591180118446080,
  "created_at" : "2012-10-17 15:31:56 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 47 ],
      "url" : "http://t.co/kYnrfFUw",
      "expanded_url" : "http://flic.kr/p/dkpGhk",
      "display_url" : "flic.kr/p/dkpGhk"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.611, -122.333 ]
  },
  "id_str" : "258417252569849856",
  "text" : "8:36pm Gonna watch Looper! http://t.co/kYnrfFUw",
  "id" : 258417252569849856,
  "created_at" : "2012-10-17 04:00:48 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Keys",
      "screen_name" : "ProducerMatthew",
      "indices" : [ 3, 19 ],
      "id_str" : "901069933",
      "id" : 901069933
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "debates",
      "indices" : [ 123, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "258411981856452608",
  "text" : "RT @ProducerMatthew: Twitter says it peaked at 109,560 tweets per minute at 9:57pm ET, during the question on immigration. #debates",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "debates",
        "indices" : [ 102, 110 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "258399699009142785",
    "text" : "Twitter says it peaked at 109,560 tweets per minute at 9:57pm ET, during the question on immigration. #debates",
    "id" : 258399699009142785,
    "created_at" : "2012-10-17 02:51:03 +0000",
    "user" : {
      "name" : "Matthew Keys",
      "screen_name" : "MatthewKeysLive",
      "protected" : false,
      "id_str" : "754485",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3009755836/e53e32d865128c1ee24328737994ebf6_normal.png",
      "id" : 754485,
      "verified" : false
    }
  },
  "id" : 258411981856452608,
  "created_at" : "2012-10-17 03:39:52 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Onion",
      "screen_name" : "TheOnion",
      "indices" : [ 3, 12 ],
      "id_str" : "14075928",
      "id" : 14075928
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 106 ],
      "url" : "http://t.co/AbN02osD",
      "expanded_url" : "http://onion.com/RAamjN",
      "display_url" : "onion.com/RAamjN"
    } ]
  },
  "geo" : { },
  "id_str" : "258400690295148544",
  "text" : "RT @TheOnion: Millions Head To Internet To Figure Out Their Own Opinions About Debate http://t.co/AbN02osD",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.hootsuite.com\" rel=\"nofollow\">HootSuite</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 72, 92 ],
        "url" : "http://t.co/AbN02osD",
        "expanded_url" : "http://onion.com/RAamjN",
        "display_url" : "onion.com/RAamjN"
      } ]
    },
    "geo" : { },
    "id_str" : "258397575714062336",
    "text" : "Millions Head To Internet To Figure Out Their Own Opinions About Debate http://t.co/AbN02osD",
    "id" : 258397575714062336,
    "created_at" : "2012-10-17 02:42:37 +0000",
    "user" : {
      "name" : "The Onion",
      "screen_name" : "TheOnion",
      "protected" : false,
      "id_str" : "14075928",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3654358881/476bd54bd9c2bc0f9a38b4e097ce6af5_normal.jpeg",
      "id" : 14075928,
      "verified" : true
    }
  },
  "id" : 258400690295148544,
  "created_at" : "2012-10-17 02:55:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bindersfullofwomen",
      "indices" : [ 0, 19 ]
    }, {
      "text" : "bigbird",
      "indices" : [ 31, 39 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6140489155, -122.3225232152 ]
  },
  "id_str" : "258385810544525313",
  "text" : "#bindersfullofwomen is the new #bigbird. Obama's doing much better today. Yay.",
  "id" : 258385810544525313,
  "created_at" : "2012-10-17 01:55:52 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "joerandazzo",
      "screen_name" : "joerandazzo",
      "indices" : [ 0, 12 ],
      "id_str" : "15068489",
      "id" : 15068489
    }, {
      "name" : "josh",
      "screen_name" : "joshc",
      "indices" : [ 13, 19 ],
      "id_str" : "2015",
      "id" : 2015
    }, {
      "name" : "michaeldavidlee",
      "screen_name" : "michaeldavidlee",
      "indices" : [ 20, 36 ],
      "id_str" : "14058032",
      "id" : 14058032
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "258376538448355328",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6140478778, -122.3225487553 ]
  },
  "id_str" : "258378212441202690",
  "in_reply_to_user_id" : 15068489,
  "text" : "@joerandazzo @joshc @michaeldavidlee It's packed! Lots of cheering so far.",
  "id" : 258378212441202690,
  "in_reply_to_status_id" : 258376538448355328,
  "created_at" : "2012-10-17 01:25:40 +0000",
  "in_reply_to_screen_name" : "joerandazzo",
  "in_reply_to_user_id_str" : "15068489",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "debates",
      "indices" : [ 9, 17 ]
    } ],
    "urls" : [ {
      "indices" : [ 53, 73 ],
      "url" : "http://t.co/LyrrwQQY",
      "expanded_url" : "http://4sq.com/QoLwCv",
      "display_url" : "4sq.com/QoLwCv"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6140516553, -122.3226039044 ]
  },
  "id_str" : "258370432506396672",
  "text" : "Food and #debates! (@ Saint John's Bar &amp; Eatery) http://t.co/LyrrwQQY",
  "id" : 258370432506396672,
  "created_at" : "2012-10-17 00:54:46 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "April V. Walters",
      "screen_name" : "aprilini",
      "indices" : [ 0, 9 ],
      "id_str" : "875511",
      "id" : 875511
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "258346331087724544",
  "geo" : { },
  "id_str" : "258359144086634497",
  "in_reply_to_user_id" : 875511,
  "text" : "@aprilini That's awesome! Bringing together two of my favorite things: slapping and behavior change!",
  "id" : 258359144086634497,
  "in_reply_to_status_id" : 258346331087724544,
  "created_at" : "2012-10-17 00:09:54 +0000",
  "in_reply_to_screen_name" : "aprilini",
  "in_reply_to_user_id_str" : "875511",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 35 ],
      "url" : "http://t.co/a3wuL2s4",
      "expanded_url" : "http://instagr.am/p/Q25PbCI0GF/",
      "display_url" : "instagr.am/p/Q25PbCI0GF/"
    } ]
  },
  "geo" : { },
  "id_str" : "258313821918220288",
  "text" : "Current status http://t.co/a3wuL2s4",
  "id" : 258313821918220288,
  "created_at" : "2012-10-16 21:09:49 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Galligan",
      "screen_name" : "mg",
      "indices" : [ 0, 3 ],
      "id_str" : "607",
      "id" : 607
    }, {
      "name" : "Circa",
      "screen_name" : "Circa",
      "indices" : [ 4, 10 ],
      "id_str" : "441389311",
      "id" : 441389311
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "258287980458938368",
  "geo" : { },
  "id_str" : "258289411895209984",
  "in_reply_to_user_id" : 607,
  "text" : "@mg @Circa Awesome. I think sharing specific points from a story is a great use case for cards. Well done all around.",
  "id" : 258289411895209984,
  "in_reply_to_status_id" : 258287980458938368,
  "created_at" : "2012-10-16 19:32:49 +0000",
  "in_reply_to_screen_name" : "mg",
  "in_reply_to_user_id_str" : "607",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Greg Crisci",
      "screen_name" : "gregcrisci",
      "indices" : [ 0, 11 ],
      "id_str" : "79320134",
      "id" : 79320134
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "258282514299359233",
  "geo" : { },
  "id_str" : "258283616143015937",
  "in_reply_to_user_id" : 79320134,
  "text" : "@gregcrisci Thanks! Yeah, built it a couple years ago and really needs to be updated with new stuff.",
  "id" : 258283616143015937,
  "in_reply_to_status_id" : 258282514299359233,
  "created_at" : "2012-10-16 19:09:47 +0000",
  "in_reply_to_screen_name" : "gregcrisci",
  "in_reply_to_user_id_str" : "79320134",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse James Herlitz",
      "screen_name" : "strikeux",
      "indices" : [ 0, 9 ],
      "id_str" : "18037082",
      "id" : 18037082
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "258271618676174848",
  "geo" : { },
  "id_str" : "258272634649862145",
  "in_reply_to_user_id" : 18037082,
  "text" : "@strikeux Yeah, things are in flux, but this direction with Cards is one that should help developers feel better about long term prospects.",
  "id" : 258272634649862145,
  "in_reply_to_status_id" : 258271618676174848,
  "created_at" : "2012-10-16 18:26:09 +0000",
  "in_reply_to_screen_name" : "strikeux",
  "in_reply_to_user_id_str" : "18037082",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://bufferapp.com\" rel=\"nofollow\">Buffer</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http://t.co/RleNBCp9",
      "expanded_url" : "http://bit.ly/QnpTTa",
      "display_url" : "bit.ly/QnpTTa"
    } ]
  },
  "geo" : { },
  "id_str" : "258266724871311360",
  "text" : "Wrote up some quick thoughts on ways to take advantage of Twitter Cards that might not be immediately obvious at first: http://t.co/RleNBCp9",
  "id" : 258266724871311360,
  "created_at" : "2012-10-16 18:02:40 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Questlove Jenkins",
      "screen_name" : "questlove",
      "indices" : [ 3, 13 ],
      "id_str" : "14939981",
      "id" : 14939981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "258247057695989760",
  "text" : "RT @questlove: i stand corrected... Mitt Romney finally explains his $5 Trillion Dollar Tax Plan just in time for the debates http://t.c ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 111, 131 ],
        "url" : "http://t.co/Qxs85dnQ",
        "expanded_url" : "http://www.romneytaxplan.com",
        "display_url" : "romneytaxplan.com"
      } ]
    },
    "geo" : { },
    "id_str" : "258235020366462976",
    "text" : "i stand corrected... Mitt Romney finally explains his $5 Trillion Dollar Tax Plan just in time for the debates http://t.co/Qxs85dnQ",
    "id" : 258235020366462976,
    "created_at" : "2012-10-16 15:56:41 +0000",
    "user" : {
      "name" : "Questlove Jenkins",
      "screen_name" : "questlove",
      "protected" : false,
      "id_str" : "14939981",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1168342829/Screen_shot_2010-11-15_at_9.08.26_PM_normal.png",
      "id" : 14939981,
      "verified" : true
    }
  },
  "id" : 258247057695989760,
  "created_at" : "2012-10-16 16:44:31 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cabana App",
      "screen_name" : "CabanaApp",
      "indices" : [ 51, 61 ],
      "id_str" : "188524925",
      "id" : 188524925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 102 ],
      "url" : "http://t.co/bvwjK9UL",
      "expanded_url" : "http://m.techcrunch.com/2012/10/16/twitter-acqui-hires-mobile-app-development-platform-cabana-shuts-its-down/",
      "display_url" : "m.techcrunch.com/2012/10/16/twi\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6086520662, -122.3059755858 ]
  },
  "id_str" : "258241742992728065",
  "text" : "Our team just got better! Excited to work with the @CabanaApp team on cool stuff. http://t.co/bvwjK9UL",
  "id" : 258241742992728065,
  "created_at" : "2012-10-16 16:23:24 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tehgeekmeister",
      "screen_name" : "tehgeekmeister",
      "indices" : [ 0, 15 ],
      "id_str" : "6727082",
      "id" : 6727082
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "258221237573136387",
  "geo" : { },
  "id_str" : "258228896120573952",
  "in_reply_to_user_id" : 6727082,
  "text" : "@tehgeekmeister They're very different, but trying to solve a similar problem. Both worth watching.",
  "id" : 258228896120573952,
  "in_reply_to_status_id" : 258221237573136387,
  "created_at" : "2012-10-16 15:32:21 +0000",
  "in_reply_to_screen_name" : "tehgeekmeister",
  "in_reply_to_user_id_str" : "6727082",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luke McGrath",
      "screen_name" : "lukejmcgrath",
      "indices" : [ 0, 13 ],
      "id_str" : "19496652",
      "id" : 19496652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "258094409780961280",
  "geo" : { },
  "id_str" : "258228597008003072",
  "in_reply_to_user_id" : 19496652,
  "text" : "@lukejmcgrath I'm not sure that it is\u2026 it's pretty factual. I'll pay up if you think it is though.",
  "id" : 258228597008003072,
  "in_reply_to_status_id" : 258094409780961280,
  "created_at" : "2012-10-16 15:31:09 +0000",
  "in_reply_to_screen_name" : "lukejmcgrath",
  "in_reply_to_user_id_str" : "19496652",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "258071712594264064",
  "text" : "The New Girl is the best show on tv right now. And I'm sticking with that story.",
  "id" : 258071712594264064,
  "created_at" : "2012-10-16 05:07:45 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 61 ],
      "url" : "http://t.co/AxBHMK79",
      "expanded_url" : "http://instagr.am/p/Q1A_ojI0JJ/",
      "display_url" : "instagr.am/p/Q1A_ojI0JJ/"
    } ]
  },
  "geo" : { },
  "id_str" : "258049223361167360",
  "text" : "8:36pm Playing hide and seek in the bath http://t.co/AxBHMK79",
  "id" : 258049223361167360,
  "created_at" : "2012-10-16 03:38:23 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://bufferapp.com\" rel=\"nofollow\">Buffer</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ArielMeadowStallings",
      "screen_name" : "OffbeatAriel",
      "indices" : [ 22, 35 ],
      "id_str" : "14095370",
      "id" : 14095370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 112 ],
      "url" : "http://t.co/huq59QM8",
      "expanded_url" : "http://bit.ly/QjXxJh",
      "display_url" : "bit.ly/QjXxJh"
    } ]
  },
  "geo" : { },
  "id_str" : "258040594725740544",
  "text" : "Amazing thoughts from @offbeatariel relevant to anyone who participates in online community http://t.co/huq59QM8",
  "id" : 258040594725740544,
  "created_at" : "2012-10-16 03:04:06 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getprismatic.com\" rel=\"nofollow\">getprismatic.com</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Circa",
      "screen_name" : "Circa",
      "indices" : [ 21, 27 ],
      "id_str" : "441389311",
      "id" : 441389311
    }, {
      "name" : "Prismatic",
      "screen_name" : "Prismatic",
      "indices" : [ 120, 130 ],
      "id_str" : "229709694",
      "id" : 229709694
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 115 ],
      "url" : "http://t.co/wEt8X4wc",
      "expanded_url" : "http://prsm.tc/vgpLaQ",
      "display_url" : "prsm.tc/vgpLaQ"
    } ]
  },
  "geo" : { },
  "id_str" : "258035826099892224",
  "text" : "Super impressed with @circa (now that the app isn't crashing). Excited to use it for a while.  http://t.co/wEt8X4wc via @prismatic",
  "id" : 258035826099892224,
  "created_at" : "2012-10-16 02:45:09 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://bufferapp.com\" rel=\"nofollow\">Buffer</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 95 ],
      "url" : "http://t.co/Wug1iMW4",
      "expanded_url" : "http://bit.ly/Qj0p9w",
      "display_url" : "bit.ly/Qj0p9w"
    } ]
  },
  "geo" : { },
  "id_str" : "257993067846578177",
  "text" : "\"How To Be 1 in 1000.\" Ask, follow up (aka ask again), and follow through. http://t.co/Wug1iMW4 /by @sarakpeck",
  "id" : 257993067846578177,
  "created_at" : "2012-10-15 23:55:15 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martin.P",
      "screen_name" : "MPREV",
      "indices" : [ 0, 6 ],
      "id_str" : "1599582248",
      "id" : 1599582248
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "257969821143142400",
  "geo" : { },
  "id_str" : "257975533848125441",
  "in_reply_to_user_id" : 1475531,
  "text" : "@mprev I've tried it with previous Fitbits but it never quite worked until the Zip came out just recently.",
  "id" : 257975533848125441,
  "in_reply_to_status_id" : 257969821143142400,
  "created_at" : "2012-10-15 22:45:34 +0000",
  "in_reply_to_screen_name" : "mikeprevette",
  "in_reply_to_user_id_str" : "1475531",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carl Nelson",
      "screen_name" : "CarlNelson",
      "indices" : [ 1, 12 ],
      "id_str" : "13951122",
      "id" : 13951122
    }, {
      "name" : "Fitbit",
      "screen_name" : "fitbit",
      "indices" : [ 42, 49 ],
      "id_str" : "17424053",
      "id" : 17424053
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "257975282181480449",
  "text" : ".@CarlNelson Value comes from me, not the @fitbit. I'm beginning to train for a marathon, so visualizing progress is meaningful to me.",
  "id" : 257975282181480449,
  "created_at" : "2012-10-15 22:44:34 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://bufferapp.com\" rel=\"nofollow\">Buffer</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fitbit",
      "screen_name" : "fitbit",
      "indices" : [ 64, 71 ],
      "id_str" : "17424053",
      "id" : 17424053
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http://t.co/bYz5zeRe",
      "expanded_url" : "http://bit.ly/PyiLsa",
      "display_url" : "bit.ly/PyiLsa"
    } ]
  },
  "geo" : { },
  "id_str" : "257972284206239744",
  "text" : "\"The best pedometer\" - Way of the Duck http://t.co/bYz5zeRe /cc @fitbit",
  "id" : 257972284206239744,
  "created_at" : "2012-10-15 22:32:40 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"https://findings.com\" rel=\"nofollow\">Findings</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 35, 43 ],
      "id_str" : "783214",
      "id" : 783214
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "meta",
      "indices" : [ 114, 119 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 113 ],
      "url" : "http://t.co/2JJSvBDF",
      "expanded_url" : "http://fnd.gs/XfnUFe",
      "display_url" : "fnd.gs/XfnUFe"
    } ]
  },
  "geo" : { },
  "id_str" : "257968146613415937",
  "text" : "This is the team I'm working on at @twitter. See the cool photo card attached to this tweet. http://t.co/2JJSvBDF #meta",
  "id" : 257968146613415937,
  "created_at" : "2012-10-15 22:16:13 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fitbit",
      "screen_name" : "fitbit",
      "indices" : [ 23, 30 ],
      "id_str" : "17424053",
      "id" : 17424053
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 51 ],
      "url" : "http://t.co/TanWHtlu",
      "expanded_url" : "http://instagr.am/p/Q0QU3SI0CF/",
      "display_url" : "instagr.am/p/Q0QU3SI0CF/"
    } ]
  },
  "geo" : { },
  "id_str" : "257942195162714113",
  "text" : "Best keychain ever /cc @fitbit http://t.co/TanWHtlu",
  "id" : 257942195162714113,
  "created_at" : "2012-10-15 20:33:06 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Breadcrumbs",
      "screen_name" : "BreadCrumbsTeam",
      "indices" : [ 0, 16 ],
      "id_str" : "611040436",
      "id" : 611040436
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "257935872433991680",
  "geo" : { },
  "id_str" : "257937344873762816",
  "in_reply_to_user_id" : 611040436,
  "text" : "@BreadCrumbsTeam Sign me up!",
  "id" : 257937344873762816,
  "in_reply_to_status_id" : 257935872433991680,
  "created_at" : "2012-10-15 20:13:49 +0000",
  "in_reply_to_screen_name" : "BreadCrumbsTeam",
  "in_reply_to_user_id_str" : "611040436",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Wang",
      "screen_name" : "brianmwang",
      "indices" : [ 0, 11 ],
      "id_str" : "93478440",
      "id" : 93478440
    }, {
      "name" : "Aaron Coleman",
      "screen_name" : "aarondcoleman",
      "indices" : [ 12, 26 ],
      "id_str" : "1379965428",
      "id" : 1379965428
    }, {
      "name" : "Chris Hogg",
      "screen_name" : "cwhogg",
      "indices" : [ 27, 34 ],
      "id_str" : "15727738",
      "id" : 15727738
    }, {
      "name" : "Emilio Ramirez",
      "screen_name" : "e_ramirez",
      "indices" : [ 35, 45 ],
      "id_str" : "1273564632",
      "id" : 1273564632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 135 ],
      "url" : "http://t.co/D3T2nec8",
      "expanded_url" : "http://branch.com/b/if-behavior-change-is-belief-change",
      "display_url" : "branch.com/b/if-behavior-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "257932398711422976",
  "in_reply_to_user_id" : 93478440,
  "text" : "@brianmwang @aarondcoleman @cwhogg @e_ramirez Started a branch around this... I'd love to keep talking it through: http://t.co/D3T2nec8",
  "id" : 257932398711422976,
  "created_at" : "2012-10-15 19:54:10 +0000",
  "in_reply_to_screen_name" : "brianmwang",
  "in_reply_to_user_id_str" : "93478440",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Findings",
      "screen_name" : "findings",
      "indices" : [ 0, 9 ],
      "id_str" : "208197274",
      "id" : 208197274
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "257908996596436994",
  "geo" : { },
  "id_str" : "257909750577119232",
  "in_reply_to_user_id" : 208197274,
  "text" : "@findings Looks great! Quick question though: what's the best way to save things to findings from my phone?",
  "id" : 257909750577119232,
  "in_reply_to_status_id" : 257908996596436994,
  "created_at" : "2012-10-15 18:24:10 +0000",
  "in_reply_to_screen_name" : "findings",
  "in_reply_to_user_id_str" : "208197274",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cap Watkins",
      "screen_name" : "cap",
      "indices" : [ 0, 4 ],
      "id_str" : "2182141",
      "id" : 2182141
    }, {
      "name" : "Etsy",
      "screen_name" : "Etsy",
      "indices" : [ 15, 20 ],
      "id_str" : "11522502",
      "id" : 11522502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "257860820166385664",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6087094471, -122.3059492094 ]
  },
  "id_str" : "257884653237710849",
  "in_reply_to_user_id" : 2182141,
  "text" : "@cap Congrats! @etsy is awesome and filled with great people building great things.",
  "id" : 257884653237710849,
  "in_reply_to_status_id" : 257860820166385664,
  "created_at" : "2012-10-15 16:44:27 +0000",
  "in_reply_to_screen_name" : "cap",
  "in_reply_to_user_id_str" : "2182141",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 44 ],
      "url" : "http://t.co/GoWcra4u",
      "expanded_url" : "http://instagr.am/p/QzDoGsI0E2/",
      "display_url" : "instagr.am/p/QzDoGsI0E2/"
    } ]
  },
  "geo" : { },
  "id_str" : "257773577489768448",
  "text" : "Kellianne holding court http://t.co/GoWcra4u",
  "id" : 257773577489768448,
  "created_at" : "2012-10-15 09:23:04 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 0, 10 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 50 ],
      "url" : "http://t.co/ETjz3u7X",
      "expanded_url" : "http://instagr.am/p/Qy4uMUI0Az/",
      "display_url" : "instagr.am/p/Qy4uMUI0Az/"
    } ]
  },
  "geo" : { },
  "id_str" : "257749521549893632",
  "in_reply_to_user_id" : 7362142,
  "text" : "@kellianne is Bad to the Bone http://t.co/ETjz3u7X",
  "id" : 257749521549893632,
  "created_at" : "2012-10-15 07:47:29 +0000",
  "in_reply_to_screen_name" : "kellianne",
  "in_reply_to_user_id_str" : "7362142",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6154072784, -122.3199667841 ]
  },
  "id_str" : "257740206617264128",
  "text" : "OH \"Let you balalaika sing.\"",
  "id" : 257740206617264128,
  "created_at" : "2012-10-15 07:10:28 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"https://path.com/\" rel=\"nofollow\">Path</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rock Box",
      "screen_name" : "RockBoxSeattle",
      "indices" : [ 46, 61 ],
      "id_str" : "100551591",
      "id" : 100551591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 91 ],
      "url" : "http://t.co/MCUA27cF",
      "expanded_url" : "http://path.com/p/4ezm4P",
      "display_url" : "path.com/p/4ezm4P"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6154791264, -122.320146561 ]
  },
  "id_str" : "257727987900878849",
  "text" : "Birthday karaoke (with Kellianne and April at @RockBoxSeattle) [pic] \u2014 http://t.co/MCUA27cF",
  "id" : 257727987900878849,
  "created_at" : "2012-10-15 06:21:55 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 23, 33 ],
      "id_str" : "7362142",
      "id" : 7362142
    }, {
      "name" : "Pickle and Jam",
      "screen_name" : "pickleandjam",
      "indices" : [ 47, 60 ],
      "id_str" : "599601895",
      "id" : 599601895
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 125 ],
      "url" : "http://t.co/I5il1NIL",
      "expanded_url" : "http://instagr.am/p/Qycdwbo0Ea/",
      "display_url" : "instagr.am/p/Qycdwbo0Ea/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.595253, -122.306605 ]
  },
  "id_str" : "257687885732532224",
  "text" : "8:36pm Happy birthday, @kellianne! Dinner with @pickleandjam and friends!  @ How Pickle Got Out Of A Jam http://t.co/I5il1NIL",
  "id" : 257687885732532224,
  "created_at" : "2012-10-15 03:42:34 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 44 ],
      "url" : "http://t.co/sFxIwaQz",
      "expanded_url" : "http://instagr.am/p/QyLPxAI0Gc/",
      "display_url" : "instagr.am/p/QyLPxAI0Gc/"
    } ]
  },
  "geo" : { },
  "id_str" : "257649548095262720",
  "text" : "Master of puddle riding http://t.co/sFxIwaQz",
  "id" : 257649548095262720,
  "created_at" : "2012-10-15 01:10:13 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jack",
      "screen_name" : "yeahforthewin",
      "indices" : [ 0, 14 ],
      "id_str" : "218588618",
      "id" : 218588618
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "257618383665766400",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6086413861, -122.306238385 ]
  },
  "id_str" : "257620482340311041",
  "in_reply_to_user_id" : 218588618,
  "text" : "@yeahforthewin Nice catch. :)",
  "id" : 257620482340311041,
  "in_reply_to_status_id" : 257618383665766400,
  "created_at" : "2012-10-14 23:14:44 +0000",
  "in_reply_to_screen_name" : "yeahforthewin",
  "in_reply_to_user_id_str" : "218588618",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jack",
      "screen_name" : "yeahforthewin",
      "indices" : [ 4, 18 ],
      "id_str" : "218588618",
      "id" : 218588618
    }, {
      "name" : "Felix Baumgartner",
      "screen_name" : "FelixBaumgartn",
      "indices" : [ 43, 58 ],
      "id_str" : "728271384",
      "id" : 728271384
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "257618383665766400",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6086690883, -122.3061991577 ]
  },
  "id_str" : "257620367751921665",
  "in_reply_to_user_id" : 218588618,
  "text" : "Pay @yeahforthewin $1 for complaining that @felixbaumgartn wasn't tweeting as much as the Mars Rover did. (At least they were real though.)",
  "id" : 257620367751921665,
  "in_reply_to_status_id" : 257618383665766400,
  "created_at" : "2012-10-14 23:14:16 +0000",
  "in_reply_to_screen_name" : "yeahforthewin",
  "in_reply_to_user_id_str" : "218588618",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 42 ],
      "url" : "http://t.co/qr2x2ot7",
      "expanded_url" : "http://instagr.am/p/Qx4wyuI0Fr/",
      "display_url" : "instagr.am/p/Qx4wyuI0Fr/"
    } ]
  },
  "geo" : { },
  "id_str" : "257608819729903616",
  "text" : "Sunday Funny Face Day http://t.co/qr2x2ot7",
  "id" : 257608819729903616,
  "created_at" : "2012-10-14 22:28:23 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jack Cheng",
      "screen_name" : "jackcheng",
      "indices" : [ 0, 10 ],
      "id_str" : "146703",
      "id" : 146703
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "257573221602316288",
  "geo" : { },
  "id_str" : "257583541372727296",
  "in_reply_to_user_id" : 146703,
  "text" : "@jackcheng Hmm... yeah, interesting.",
  "id" : 257583541372727296,
  "in_reply_to_status_id" : 257573221602316288,
  "created_at" : "2012-10-14 20:47:56 +0000",
  "in_reply_to_screen_name" : "jackcheng",
  "in_reply_to_user_id_str" : "146703",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Douglas Dollars",
      "screen_name" : "theDoug",
      "indices" : [ 0, 8 ],
      "id_str" : "36043",
      "id" : 36043
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "257558116818886657",
  "geo" : { },
  "id_str" : "257560415549140992",
  "in_reply_to_user_id" : 36043,
  "text" : "@theDoug True, I think there would have to be some third party scoring system based on data over opinion.",
  "id" : 257560415549140992,
  "in_reply_to_status_id" : 257558116818886657,
  "created_at" : "2012-10-14 19:16:02 +0000",
  "in_reply_to_screen_name" : "theDoug",
  "in_reply_to_user_id_str" : "36043",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://bufferapp.com\" rel=\"nofollow\">Buffer</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Bittman",
      "screen_name" : "bittman",
      "indices" : [ 82, 90 ],
      "id_str" : "20778387",
      "id" : 20778387
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 133 ],
      "url" : "http://t.co/OMddKpsG",
      "expanded_url" : "http://www.nytimes.com/2012/10/14/opinion/sunday/bittman-my-dream-food-label.html?hp",
      "display_url" : "nytimes.com/2012/10/14/opi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "257557708356583426",
  "text" : "All food rated by Nutrition, Foodness, and Welfare. Would make an awesome app! RT @bittman: My ideal food label: http://t.co/OMddKpsG",
  "id" : 257557708356583426,
  "created_at" : "2012-10-14 19:05:17 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.apple.com\" rel=\"nofollow\">Safari on iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "spacejump",
      "indices" : [ 34, 44 ]
    } ],
    "urls" : [ {
      "indices" : [ 65, 85 ],
      "url" : "http://t.co/kuVRzU4q",
      "expanded_url" : "http://photoset.com/sskoyxan",
      "display_url" : "photoset.com/sskoyxan"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.608667, -122.306241 ]
  },
  "id_str" : "257551440871047169",
  "text" : "I felt like I was actually at the #spacejump, so I took pictures http://t.co/kuVRzU4q",
  "id" : 257551440871047169,
  "created_at" : "2012-10-14 18:40:23 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Stephens",
      "screen_name" : "rstephens",
      "indices" : [ 3, 13 ],
      "id_str" : "804376",
      "id" : 804376
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "257542391278477312",
  "text" : "RT @rstephens: Quick! Let\u2019s all hide before Felix gets here. And somebody bury the Statue of Liberty half in beach sand.",
  "retweeted_status" : {
    "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "257540892397826049",
    "text" : "Quick! Let\u2019s all hide before Felix gets here. And somebody bury the Statue of Liberty half in beach sand.",
    "id" : 257540892397826049,
    "created_at" : "2012-10-14 17:58:28 +0000",
    "user" : {
      "name" : "Robert Stephens",
      "screen_name" : "rstephens",
      "protected" : false,
      "id_str" : "804376",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3289376045/49f17b7cf63da3351c55aa05dbee9b8c_normal.jpeg",
      "id" : 804376,
      "verified" : false
    }
  },
  "id" : 257542391278477312,
  "created_at" : "2012-10-14 18:04:25 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Felix Baumgartner",
      "screen_name" : "BaumgartnFelix",
      "indices" : [ 14, 29 ],
      "id_str" : "72636009",
      "id" : 72636009
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6086151507, -122.3061385566 ]
  },
  "id_str" : "257541540736540673",
  "text" : "Please do. RT @BaumgartnFelix: Do you think I will survive this? :)",
  "id" : 257541540736540673,
  "created_at" : "2012-10-14 18:01:02 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Pell",
      "screen_name" : "davepell",
      "indices" : [ 3, 12 ],
      "id_str" : "224",
      "id" : 224
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "257538966977388544",
  "text" : "RT @davepell: Five million people watching the Red Bull live feed on YouTube.\n\nA few years ago, that alone would've been unthinkable.",
  "retweeted_status" : {
    "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "257535159056859136",
    "text" : "Five million people watching the Red Bull live feed on YouTube.\n\nA few years ago, that alone would've been unthinkable.",
    "id" : 257535159056859136,
    "created_at" : "2012-10-14 17:35:41 +0000",
    "user" : {
      "name" : "Dave Pell",
      "screen_name" : "davepell",
      "protected" : false,
      "id_str" : "224",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1131225374/twTitle-1_normal.jpg",
      "id" : 224,
      "verified" : false
    }
  },
  "id" : 257538966977388544,
  "created_at" : "2012-10-14 17:50:49 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robyn Peel",
      "screen_name" : "robynpeel",
      "indices" : [ 50, 60 ],
      "id_str" : "244983340",
      "id" : 244983340
    }, {
      "name" : "Anti-Buster",
      "screen_name" : "busterbenson",
      "indices" : [ 62, 75 ],
      "id_str" : "1024917050",
      "id" : 1024917050
    }, {
      "name" : "Felix Baumgartner",
      "screen_name" : "FelixBaumgart",
      "indices" : [ 118, 132 ],
      "id_str" : "1450433700",
      "id" : 1450433700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6086610722, -122.306249629 ]
  },
  "id_str" : "257535257484595200",
  "text" : "Oh he is tweeting. Though he seems distracted. RT @robynpeel: @busterbenson He is (unless it was all pre-done). Check @FelixBaumgart",
  "id" : 257535257484595200,
  "created_at" : "2012-10-14 17:36:04 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.apple.com\" rel=\"nofollow\">Safari on iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nomarsrover",
      "indices" : [ 40, 52 ]
    } ],
    "urls" : [ {
      "indices" : [ 53, 73 ],
      "url" : "http://t.co/BrdoRIwC",
      "expanded_url" : "http://m.youtube.com/?reload=3&rdm=m97jn44cc#/redbull?utm_campaign=Stratos-National-B-Mobile-Exact&uid=blfuW_4rakIf2h6aqANefA&utm_term=stratos+live&utm_group=Events-Stratos&utm_source=google&utm_medium=cpc&desktop_uri=%2Fredbull%3Futm_source%3Dgoogle%26utm_medium%3Dcpc%26utm_campaign%3DStratos-National-B-Mobile-Exact%26utm_group%3DEvents-Stratos%26utm_term%3Dstratos%2Blive",
      "display_url" : "m.youtube.com/?reload=3&rdm=\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "257531188107956224",
  "text" : "Why isn't he tweeting from the balloon? #nomarsrover http://t.co/BrdoRIwC",
  "id" : 257531188107956224,
  "created_at" : "2012-10-14 17:19:54 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Wallin",
      "screen_name" : "joewallin",
      "indices" : [ 0, 10 ],
      "id_str" : "14857106",
      "id" : 14857106
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "257509583541641216",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6086364599, -122.3063004836 ]
  },
  "id_str" : "257509932037980160",
  "in_reply_to_user_id" : 14857106,
  "text" : "@joewallin Yeah, I loved War of Art. And check in on his blog occasionally. What are your favorites?",
  "id" : 257509932037980160,
  "in_reply_to_status_id" : 257509583541641216,
  "created_at" : "2012-10-14 15:55:26 +0000",
  "in_reply_to_screen_name" : "joewallin",
  "in_reply_to_user_id_str" : "14857106",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://bufferapp.com\" rel=\"nofollow\">Buffer</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Wallin",
      "screen_name" : "joewallin",
      "indices" : [ 59, 69 ],
      "id_str" : "14857106",
      "id" : 14857106
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 53 ],
      "url" : "http://t.co/PBHzB138",
      "expanded_url" : "http://bit.ly/TpXMTP",
      "display_url" : "bit.ly/TpXMTP"
    } ]
  },
  "geo" : { },
  "id_str" : "257508831452610560",
  "text" : "\"More people should write.\" YES. http://t.co/PBHzB138 /via @joewallin",
  "id" : 257508831452610560,
  "created_at" : "2012-10-14 15:51:04 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kellan",
      "screen_name" : "kellan",
      "indices" : [ 0, 7 ],
      "id_str" : "47",
      "id" : 47
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "257496541156233216",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6086571441, -122.3061815557 ]
  },
  "id_str" : "257508060405317632",
  "in_reply_to_user_id" : 47,
  "text" : "@kellan Unfortunately there's no way to do that, and apparently no plans to open an API. It's a bummer since they have the best device.",
  "id" : 257508060405317632,
  "in_reply_to_status_id" : 257496541156233216,
  "created_at" : "2012-10-14 15:48:00 +0000",
  "in_reply_to_screen_name" : "kellan",
  "in_reply_to_user_id_str" : "47",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Wallin",
      "screen_name" : "joewallin",
      "indices" : [ 0, 10 ],
      "id_str" : "14857106",
      "id" : 14857106
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 106 ],
      "url" : "http://t.co/LOtCchD3",
      "expanded_url" : "http://fnd.gs/Rny3vE",
      "display_url" : "fnd.gs/Rny3vE"
    } ]
  },
  "in_reply_to_status_id_str" : "257345704685625345",
  "geo" : { },
  "id_str" : "257346699067023361",
  "in_reply_to_user_id" : 14857106,
  "text" : "@joewallin Yes, thank you for the link! I loved that paragraph too, captured it here: http://t.co/LOtCchD3",
  "id" : 257346699067023361,
  "in_reply_to_status_id" : 257345704685625345,
  "created_at" : "2012-10-14 05:06:48 +0000",
  "in_reply_to_screen_name" : "joewallin",
  "in_reply_to_user_id_str" : "14857106",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"https://findings.com\" rel=\"nofollow\">Findings</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 113 ],
      "url" : "http://t.co/hxpyRh5X",
      "expanded_url" : "http://findings.com",
      "display_url" : "findings.com"
    }, {
      "indices" : [ 116, 136 ],
      "url" : "http://t.co/C2S51ouI",
      "expanded_url" : "http://fnd.gs/P1F8GF",
      "display_url" : "fnd.gs/P1F8GF"
    } ]
  },
  "geo" : { },
  "id_str" : "257345567020154883",
  "text" : "\"You'll live more curiously if you write. A scientist of whatever world you care about.\" via http://t.co/hxpyRh5X - http://t.co/C2S51ouI",
  "id" : 257345567020154883,
  "created_at" : "2012-10-14 05:02:19 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"https://findings.com\" rel=\"nofollow\">Findings</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 109 ],
      "url" : "http://t.co/hxpyRh5X",
      "expanded_url" : "http://findings.com",
      "display_url" : "findings.com"
    }, {
      "indices" : [ 112, 132 ],
      "url" : "http://t.co/6NhUCrNw",
      "expanded_url" : "http://fnd.gs/P1F2yF",
      "display_url" : "fnd.gs/P1F2yF"
    } ]
  },
  "geo" : { },
  "id_str" : "257345128014958592",
  "text" : "\"I have a lot of friends who are thoughtful, but keep their thoughts to themselves.\" via http://t.co/hxpyRh5X - http://t.co/6NhUCrNw",
  "id" : 257345128014958592,
  "created_at" : "2012-10-14 05:00:34 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 81 ],
      "url" : "http://t.co/RDdsaAcq",
      "expanded_url" : "http://flic.kr/p/djrvhE",
      "display_url" : "flic.kr/p/djrvhE"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.608666, -122.306334 ]
  },
  "id_str" : "257330896988954624",
  "text" : "8:36pm Fell asleep with Niko. My Fitbit thinks that's funny. http://t.co/RDdsaAcq",
  "id" : 257330896988954624,
  "created_at" : "2012-10-14 04:04:01 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 46 ],
      "url" : "http://t.co/nOR067ky",
      "expanded_url" : "http://instagr.am/p/QvV_umo0Bl/",
      "display_url" : "instagr.am/p/QvV_umo0Bl/"
    } ]
  },
  "geo" : { },
  "id_str" : "257251216466268161",
  "text" : "Preview of Niko's costume http://t.co/nOR067ky",
  "id" : 257251216466268161,
  "created_at" : "2012-10-13 22:47:24 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shari VanderWerf",
      "screen_name" : "shariv67",
      "indices" : [ 3, 12 ],
      "id_str" : "19242665",
      "id" : 19242665
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "257237073491279872",
  "text" : "RT @shariv67: The five stages of waking up:\n1. Denial\n2. Bargaining\n3. Anger\n4. Depression\n5. Coffee",
  "retweeted_status" : {
    "source" : "<a href=\"http://favstar.fm\" rel=\"nofollow\">Favstar.FM</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "256767898226421761",
    "text" : "The five stages of waking up:\n1. Denial\n2. Bargaining\n3. Anger\n4. Depression\n5. Coffee",
    "id" : 256767898226421761,
    "created_at" : "2012-10-12 14:46:52 +0000",
    "user" : {
      "name" : "Shari VanderWerf",
      "screen_name" : "shariv67",
      "protected" : false,
      "id_str" : "19242665",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000410172337/811c0866c7e640f89b9d523792ceaa55_normal.jpeg",
      "id" : 19242665,
      "verified" : false
    }
  },
  "id" : 257237073491279872,
  "created_at" : "2012-10-13 21:51:12 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Judi",
      "screen_name" : "judidec",
      "indices" : [ 0, 8 ],
      "id_str" : "29344406",
      "id" : 29344406
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "257229654128209920",
  "geo" : { },
  "id_str" : "257236801817804800",
  "in_reply_to_user_id" : 29344406,
  "text" : "@judidec The Zip is the tiny one that you don't recharge. But no alarm...",
  "id" : 257236801817804800,
  "in_reply_to_status_id" : 257229654128209920,
  "created_at" : "2012-10-13 21:50:07 +0000",
  "in_reply_to_screen_name" : "judidec",
  "in_reply_to_user_id_str" : "29344406",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "allgadgetedup",
      "indices" : [ 72, 86 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "257207089963876352",
  "text" : "New iPhone 5, new Fitbit Zip, new Fitbit Aria scale, new running shoes. #allgadgetedup",
  "id" : 257207089963876352,
  "created_at" : "2012-10-13 19:52:03 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 57 ],
      "url" : "http://t.co/0QY7e6WJ",
      "expanded_url" : "http://instagr.am/p/QvBJ8Go0MC/",
      "display_url" : "instagr.am/p/QvBJ8Go0MC/"
    } ]
  },
  "geo" : { },
  "id_str" : "257206073080037377",
  "text" : "Close your eyes and open your hands  http://t.co/0QY7e6WJ",
  "id" : 257206073080037377,
  "created_at" : "2012-10-13 19:48:01 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "lia bulaong",
      "screen_name" : "lia",
      "indices" : [ 1, 5 ],
      "id_str" : "15484730",
      "id" : 15484730
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "257166198804987904",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6086444036, -122.3060595152 ]
  },
  "id_str" : "257172624730382337",
  "in_reply_to_user_id" : 15484730,
  "text" : ".@lia Who will speak for the trolls?",
  "id" : 257172624730382337,
  "in_reply_to_status_id" : 257166198804987904,
  "created_at" : "2012-10-13 17:35:06 +0000",
  "in_reply_to_screen_name" : "lia",
  "in_reply_to_user_id_str" : "15484730",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://bufferapp.com\" rel=\"nofollow\">Buffer</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 130 ],
      "url" : "http://t.co/ktTEJ3Vk",
      "expanded_url" : "http://read.bi/Pt4a1l",
      "display_url" : "read.bi/Pt4a1l"
    } ]
  },
  "geo" : { },
  "id_str" : "257146458476777473",
  "text" : "\"Total searches declined 4% y/y, the first decline in total search volume since we started tracking in 2006.\" http://t.co/ktTEJ3Vk",
  "id" : 257146458476777473,
  "created_at" : "2012-10-13 15:51:07 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.apple.com\" rel=\"nofollow\">iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mixel",
      "screen_name" : "mixel",
      "indices" : [ 27, 33 ],
      "id_str" : "9076822",
      "id" : 9076822
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/buster/status/256985071020552192/photo/1",
      "indices" : [ 66, 86 ],
      "url" : "http://t.co/mEsIGHAS",
      "media_url" : "http://pbs.twimg.com/media/A5D-j39CMAAQyPM.jpg",
      "id_str" : "256985071028940800",
      "id" : 256985071028940800,
      "media_url_https" : "https://pbs.twimg.com/media/A5D-j39CMAAQyPM.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com/mEsIGHAS"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 65 ],
      "url" : "http://t.co/djJo1Zl3",
      "expanded_url" : "http://mixel.by/busterbenson/2012/10/13/1",
      "display_url" : "mixel.by/busterbenson/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "256985071020552192",
  "text" : "Check out what I made with @Mixel - This guy http://t.co/djJo1Zl3 http://t.co/mEsIGHAS",
  "id" : 256985071020552192,
  "created_at" : "2012-10-13 05:09:50 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 70 ],
      "url" : "http://t.co/Byt6Ksbo",
      "expanded_url" : "http://flic.kr/p/djaftp",
      "display_url" : "flic.kr/p/djaftp"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.439333, -122.314667 ]
  },
  "id_str" : "256981882271576064",
  "text" : "8:36pm Just landed back in Seattle, tweeter heads http://t.co/Byt6Ksbo",
  "id" : 256981882271576064,
  "created_at" : "2012-10-13 04:57:09 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Hopper",
      "screen_name" : "chrishopper2",
      "indices" : [ 0, 13 ],
      "id_str" : "21379129",
      "id" : 21379129
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "256939064610148352",
  "geo" : { },
  "id_str" : "256958508669476864",
  "in_reply_to_user_id" : 21379129,
  "text" : "@chrishopper2 Why thank you! I'm glad you like it.",
  "id" : 256958508669476864,
  "in_reply_to_status_id" : 256939064610148352,
  "created_at" : "2012-10-13 03:24:17 +0000",
  "in_reply_to_screen_name" : "chrishopper2",
  "in_reply_to_user_id_str" : "21379129",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.apple.com\" rel=\"nofollow\">Safari on iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 135 ],
      "url" : "http://t.co/XBlLSO5Z",
      "expanded_url" : "http://www.huffingtonpost.com/mobileweb/andrew-weil-md/carbohydrates-weight-loss_b_1937312.html",
      "display_url" : "huffingtonpost.com/mobileweb/andr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "256947667832283136",
  "text" : "I like the simplicity of seeking out foods with low carbohydrate density. Just another way of saying whole foods.  http://t.co/XBlLSO5Z",
  "id" : 256947667832283136,
  "created_at" : "2012-10-13 02:41:12 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kristin Kelly",
      "screen_name" : "heyKK",
      "indices" : [ 0, 6 ],
      "id_str" : "19930596",
      "id" : 19930596
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "256932775289057280",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.6162188804, -122.3822840921 ]
  },
  "id_str" : "256946584447750144",
  "in_reply_to_user_id" : 19930596,
  "text" : "@heyKK I loved the story.",
  "id" : 256946584447750144,
  "in_reply_to_status_id" : 256932775289057280,
  "created_at" : "2012-10-13 02:36:54 +0000",
  "in_reply_to_screen_name" : "heyKK",
  "in_reply_to_user_id_str" : "19930596",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kristin Kelly",
      "screen_name" : "heyKK",
      "indices" : [ 0, 6 ],
      "id_str" : "19930596",
      "id" : 19930596
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "256932775289057280",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.6162284999, -122.3825752793 ]
  },
  "id_str" : "256945955256012800",
  "in_reply_to_user_id" : 19930596,
  "text" : "@heyKK Cool serendipity from asking questions on Twitter. Maybe \"all the time\" was a bit of an exaggeration... :)",
  "id" : 256945955256012800,
  "in_reply_to_status_id" : 256932775289057280,
  "created_at" : "2012-10-13 02:34:24 +0000",
  "in_reply_to_screen_name" : "heyKK",
  "in_reply_to_user_id_str" : "19930596",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 0, 10 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "256903063661600769",
  "geo" : { },
  "id_str" : "256909882031239168",
  "in_reply_to_user_id" : 7362142,
  "text" : "@kellianne Which drug?",
  "id" : 256909882031239168,
  "in_reply_to_status_id" : 256903063661600769,
  "created_at" : "2012-10-13 00:11:03 +0000",
  "in_reply_to_screen_name" : "kellianne",
  "in_reply_to_user_id_str" : "7362142",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://bufferapp.com\" rel=\"nofollow\">Buffer</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kristin Kelly",
      "screen_name" : "heyKK",
      "indices" : [ 98, 104 ],
      "id_str" : "19930596",
      "id" : 19930596
    }, {
      "name" : "Medium",
      "screen_name" : "Medium",
      "indices" : [ 108, 115 ],
      "id_str" : "571202103",
      "id" : 571202103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 93 ],
      "url" : "http://t.co/pFKW0kvR",
      "expanded_url" : "http://bit.ly/PsKP0d",
      "display_url" : "bit.ly/PsKP0d"
    } ]
  },
  "geo" : { },
  "id_str" : "256905931177197568",
  "text" : "This happens to me all the time in small ways. \"140 Character Hitchhike\" http://t.co/pFKW0kvR /by @heyKK on @medium",
  "id" : 256905931177197568,
  "created_at" : "2012-10-12 23:55:21 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Wang",
      "screen_name" : "brianmwang",
      "indices" : [ 0, 11 ],
      "id_str" : "93478440",
      "id" : 93478440
    }, {
      "name" : "Aaron Coleman",
      "screen_name" : "aarondcoleman",
      "indices" : [ 12, 26 ],
      "id_str" : "1379965428",
      "id" : 1379965428
    }, {
      "name" : "Chris Hogg",
      "screen_name" : "cwhogg",
      "indices" : [ 27, 34 ],
      "id_str" : "15727738",
      "id" : 15727738
    }, {
      "name" : "Emilio Ramirez",
      "screen_name" : "e_ramirez",
      "indices" : [ 35, 45 ],
      "id_str" : "1273564632",
      "id" : 1273564632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "256862273413476352",
  "geo" : { },
  "id_str" : "256881622337605632",
  "in_reply_to_user_id" : 93478440,
  "text" : "@brianmwang @aarondcoleman @cwhogg @e_ramirez Awesome. I was def. influenced by your thoughts on the necessity of a \"conversion moment\".",
  "id" : 256881622337605632,
  "in_reply_to_status_id" : 256862273413476352,
  "created_at" : "2012-10-12 22:18:46 +0000",
  "in_reply_to_screen_name" : "brianmwang",
  "in_reply_to_user_id_str" : "93478440",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Smith",
      "screen_name" : "BuzzFeedBen",
      "indices" : [ 46, 58 ],
      "id_str" : "9532402",
      "id" : 9532402
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 40 ],
      "url" : "http://t.co/2AJyj7xx",
      "expanded_url" : "http://www.buzzfeed.com/jwherrman/why-is-this-man-running-for-president-of-the-inter",
      "display_url" : "buzzfeed.com/jwherrman/why-\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7763796991, -122.4167806302 ]
  },
  "id_str" : "256787453053124608",
  "text" : "The Internet Party: http://t.co/2AJyj7xx /via @BuzzFeedBen",
  "id" : 256787453053124608,
  "created_at" : "2012-10-12 16:04:34 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard's Old A/c",
      "screen_name" : "ricmacnz",
      "indices" : [ 0, 9 ],
      "id_str" : "588669460",
      "id" : 588669460
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "256565200449327106",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7783604126, -122.4151652081 ]
  },
  "id_str" : "256607768264441856",
  "in_reply_to_user_id" : 105895323,
  "text" : "@ricmacnz Super impressed and inspired by everything you've done. Excited to hear more about the book too... now enjoy the break!",
  "id" : 256607768264441856,
  "in_reply_to_status_id" : 256565200449327106,
  "created_at" : "2012-10-12 04:10:34 +0000",
  "in_reply_to_screen_name" : "ricmac",
  "in_reply_to_user_id_str" : "105895323",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sharon",
      "screen_name" : "sharon",
      "indices" : [ 0, 7 ],
      "id_str" : "260",
      "id" : 260
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "crossingfingers",
      "indices" : [ 62, 78 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "256599750009303040",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7782091706, -122.4153429094 ]
  },
  "id_str" : "256602778061914112",
  "in_reply_to_user_id" : 260,
  "text" : "@sharon I think you just found a front runner for first name. #crossingfingers",
  "id" : 256602778061914112,
  "in_reply_to_status_id" : 256599750009303040,
  "created_at" : "2012-10-12 03:50:44 +0000",
  "in_reply_to_screen_name" : "sharon",
  "in_reply_to_user_id_str" : "260",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 67 ],
      "url" : "http://t.co/ChUoMyoJ",
      "expanded_url" : "http://instagr.am/p/QquWcro0Ge/",
      "display_url" : "instagr.am/p/QquWcro0Ge/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.77826, -122.415083035 ]
  },
  "id_str" : "256600701466193921",
  "text" : "8:36pm Hangin' with my peeps  @ Hotel Whitcomb http://t.co/ChUoMyoJ",
  "id" : 256600701466193921,
  "created_at" : "2012-10-12 03:42:29 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BuzzFeed",
      "screen_name" : "BuzzFeed",
      "indices" : [ 30, 39 ],
      "id_str" : "5695632",
      "id" : 5695632
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/BuzzFeedAndrew/status/256595373651546112/photo/1",
      "indices" : [ 82, 102 ],
      "url" : "http://t.co/YD6EXSrx",
      "media_url" : "http://pbs.twimg.com/media/A4-cIgHCUAEtkTA.jpg",
      "id_str" : "256595373655740417",
      "id" : 256595373655740417,
      "media_url_https" : "https://pbs.twimg.com/media/A4-cIgHCUAEtkTA.jpg",
      "sizes" : [ {
        "h" : 350,
        "resize" : "fit",
        "w" : 625
      }, {
        "h" : 190,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 336,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 350,
        "resize" : "fit",
        "w" : 625
      } ],
      "display_url" : "pic.twitter.com/YD6EXSrx"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.778316062, -122.415279782 ]
  },
  "id_str" : "256598128982106112",
  "text" : "Everyone let's switch hair RT @BuzzFeed: If Joe Biden and Paul Ryan switched hair http://t.co/YD6EXSrx",
  "id" : 256598128982106112,
  "created_at" : "2012-10-12 03:32:15 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "debates",
      "indices" : [ 42, 50 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "256566918507556865",
  "text" : "You go, Joe! Paul Ryan is getting killed. #debates",
  "id" : 256566918507556865,
  "created_at" : "2012-10-12 01:28:14 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emilio Ramirez",
      "screen_name" : "e_ramirez",
      "indices" : [ 0, 10 ],
      "id_str" : "1273564632",
      "id" : 1273564632
    }, {
      "name" : "Chris Hogg",
      "screen_name" : "cwhogg",
      "indices" : [ 28, 35 ],
      "id_str" : "15727738",
      "id" : 15727738
    }, {
      "name" : "Aaron Coleman",
      "screen_name" : "aarondcoleman",
      "indices" : [ 36, 50 ],
      "id_str" : "1379965428",
      "id" : 1379965428
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "256549258763833344",
  "geo" : { },
  "id_str" : "256555595631566848",
  "in_reply_to_user_id" : 21135674,
  "text" : "@e_ramirez Yeah you do! /cc @cwhogg @aarondcoleman",
  "id" : 256555595631566848,
  "in_reply_to_status_id" : 256549258763833344,
  "created_at" : "2012-10-12 00:43:15 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Coleman",
      "screen_name" : "aarondcoleman",
      "indices" : [ 3, 17 ],
      "id_str" : "1379965428",
      "id" : 1379965428
    }, {
      "name" : "Anti-Buster",
      "screen_name" : "busterbenson",
      "indices" : [ 116, 129 ],
      "id_str" : "1024917050",
      "id" : 1024917050
    }, {
      "name" : "Craig Warren",
      "screen_name" : "cwhog",
      "indices" : [ 130, 136 ],
      "id_str" : "65631051",
      "id" : 65631051
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 110 ],
      "url" : "http://t.co/GaOKEK0J",
      "expanded_url" : "http://www.smallstepslabs.com/post/2012/10/11/If-Behavior-Change-is-Belief-Change-Whos-Building-an-App-for-That.aspx",
      "display_url" : "smallstepslabs.com/post/2012/10/1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "256552429259223040",
  "text" : "RT @aarondcoleman: \"If Behavior Change is Belief Change, Who's Building an App for That?\" http://t.co/GaOKEK0J /cc: @busterbenson @cwhog ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Anti-Buster",
        "screen_name" : "busterbenson",
        "indices" : [ 97, 110 ],
        "id_str" : "1024917050",
        "id" : 1024917050
      }, {
        "name" : "Chris Hogg",
        "screen_name" : "cwhogg",
        "indices" : [ 111, 118 ],
        "id_str" : "15727738",
        "id" : 15727738
      }, {
        "name" : "Emilio Ramirez",
        "screen_name" : "e_ramirez",
        "indices" : [ 119, 129 ],
        "id_str" : "1273564632",
        "id" : 1273564632
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 71, 91 ],
        "url" : "http://t.co/GaOKEK0J",
        "expanded_url" : "http://www.smallstepslabs.com/post/2012/10/11/If-Behavior-Change-is-Belief-Change-Whos-Building-an-App-for-That.aspx",
        "display_url" : "smallstepslabs.com/post/2012/10/1\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "256547583051309057",
    "text" : "\"If Behavior Change is Belief Change, Who's Building an App for That?\" http://t.co/GaOKEK0J /cc: @busterbenson @cwhogg @e_ramirez",
    "id" : 256547583051309057,
    "created_at" : "2012-10-12 00:11:24 +0000",
    "user" : {
      "name" : "Aaron Coleman",
      "screen_name" : "aaronc",
      "protected" : false,
      "id_str" : "9609062",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3573843877/74c1279703598a2ca18ba0ef8df74e4c_normal.jpeg",
      "id" : 9609062,
      "verified" : false
    }
  },
  "id" : 256552429259223040,
  "created_at" : "2012-10-12 00:30:40 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.apple.com\" rel=\"nofollow\">iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 78 ],
      "url" : "http://t.co/AxRbVUOs",
      "expanded_url" : "http://www.polarb.com/polls/767-which-pet-will-you-take-home",
      "display_url" : "polarb.com/polls/767-whic\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "256533496850436096",
  "text" : "Poll: Which Pet Will You Take Home? Wallaby or Red Fox... http://t.co/AxRbVUOs",
  "id" : 256533496850436096,
  "created_at" : "2012-10-11 23:15:26 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Superhuman\u2122",
      "screen_name" : "superhuman",
      "indices" : [ 13, 24 ],
      "id_str" : "456821922",
      "id" : 456821922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 69 ],
      "url" : "http://t.co/7qCuwcGn",
      "expanded_url" : "http://superhuman.io",
      "display_url" : "superhuman.io"
    } ]
  },
  "geo" : { },
  "id_str" : "256517475276029953",
  "text" : "I want to be @Superhuman. Anyone have an invite? http://t.co/7qCuwcGn",
  "id" : 256517475276029953,
  "created_at" : "2012-10-11 22:11:46 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Greg Linden",
      "screen_name" : "greglinden",
      "indices" : [ 0, 11 ],
      "id_str" : "87719108",
      "id" : 87719108
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "256433446182854656",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7771542921, -122.4158671845 ]
  },
  "id_str" : "256482774951788544",
  "in_reply_to_user_id" : 87719108,
  "text" : "@greglinden Interesting but the experiment and experimenter both don't seem very scientific to me.",
  "id" : 256482774951788544,
  "in_reply_to_status_id" : 256433446182854656,
  "created_at" : "2012-10-11 19:53:53 +0000",
  "in_reply_to_screen_name" : "greglinden",
  "in_reply_to_user_id_str" : "87719108",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://bufferapp.com\" rel=\"nofollow\">Buffer</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Craig Mod",
      "screen_name" : "craigmod",
      "indices" : [ 122, 131 ],
      "id_str" : "1835951",
      "id" : 1835951
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "quantifiedself",
      "indices" : [ 34, 49 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 117 ],
      "url" : "http://t.co/eTj0cT6y",
      "expanded_url" : "http://bit.ly/PqeAPe",
      "display_url" : "bit.ly/PqeAPe"
    } ]
  },
  "geo" : { },
  "id_str" : "256470510819504128",
  "text" : "Beautifully written meditation on #quantifiedself and self-tracking '\u2605 Paris and the Data Mind': http://t.co/eTj0cT6y /by @craigmod",
  "id" : 256470510819504128,
  "created_at" : "2012-10-11 19:05:09 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"https://findings.com\" rel=\"nofollow\">Findings</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 117 ],
      "url" : "http://t.co/hxpyRh5X",
      "expanded_url" : "http://findings.com",
      "display_url" : "findings.com"
    }, {
      "indices" : [ 120, 140 ],
      "url" : "http://t.co/0qJr5IJ3",
      "expanded_url" : "http://fnd.gs/STOJ3c",
      "display_url" : "fnd.gs/STOJ3c"
    } ]
  },
  "geo" : { },
  "id_str" : "256455253543755776",
  "text" : "\"I think of our check-ins, our food photos, our tagged friends, our steps, our Fuel points.\" via http://t.co/hxpyRh5X - http://t.co/0qJr5IJ3",
  "id" : 256455253543755776,
  "created_at" : "2012-10-11 18:04:31 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andres Moran",
      "screen_name" : "DreMoran",
      "indices" : [ 0, 9 ],
      "id_str" : "8461972",
      "id" : 8461972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "256447139440386048",
  "geo" : { },
  "id_str" : "256447393904590848",
  "in_reply_to_user_id" : 8461972,
  "text" : "@DreMoran Thank you! And of course.",
  "id" : 256447393904590848,
  "in_reply_to_status_id" : 256447139440386048,
  "created_at" : "2012-10-11 17:33:17 +0000",
  "in_reply_to_screen_name" : "DreMoran",
  "in_reply_to_user_id_str" : "8461972",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emilio Ramirez",
      "screen_name" : "e_ramirez",
      "indices" : [ 0, 10 ],
      "id_str" : "1273564632",
      "id" : 1273564632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "256442718652354560",
  "geo" : { },
  "id_str" : "256443387689959425",
  "in_reply_to_user_id" : 21135674,
  "text" : "@e_ramirez Ha, I'll let you know when I figure it out. Marrying the right person is the best way to be a great husband.",
  "id" : 256443387689959425,
  "in_reply_to_status_id" : 256442718652354560,
  "created_at" : "2012-10-11 17:17:22 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emilio Ramirez",
      "screen_name" : "e_ramirez",
      "indices" : [ 0, 10 ],
      "id_str" : "1273564632",
      "id" : 1273564632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "256441913580863488",
  "geo" : { },
  "id_str" : "256442240946294784",
  "in_reply_to_user_id" : 21135674,
  "text" : "@e_ramirez Wow, nice choice! And I didn't realize it was so soon. Awesome!",
  "id" : 256442240946294784,
  "in_reply_to_status_id" : 256441913580863488,
  "created_at" : "2012-10-11 17:12:49 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "256439111961939968",
  "text" : "Happy 10.11.12, tweeter heads in America. The rest of the world will have to wait til next month, sorry.",
  "id" : 256439111961939968,
  "created_at" : "2012-10-11 17:00:23 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 81 ],
      "url" : "http://t.co/VPC71MR7",
      "expanded_url" : "http://silo.mediasilo.com/quicklink/42D7D85007AF6F30B99D113D235F010E/#",
      "display_url" : "silo.mediasilo.com/quicklink/42D7\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.777592635, -122.4145215176 ]
  },
  "id_str" : "256425778932248581",
  "text" : "A new way to frame your addiction to your phone and Twitter: http://t.co/VPC71MR7",
  "id" : 256425778932248581,
  "created_at" : "2012-10-11 16:07:24 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diana Kimball",
      "screen_name" : "dianakimball",
      "indices" : [ 0, 13 ],
      "id_str" : "14471007",
      "id" : 14471007
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "256415749424439297",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7776224321, -122.4145064065 ]
  },
  "id_str" : "256421361726132224",
  "in_reply_to_user_id" : 14471007,
  "text" : "@dianakimball /mentoring!",
  "id" : 256421361726132224,
  "in_reply_to_status_id" : 256415749424439297,
  "created_at" : "2012-10-11 15:49:51 +0000",
  "in_reply_to_screen_name" : "dianakimball",
  "in_reply_to_user_id_str" : "14471007",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.apple.com\" rel=\"nofollow\">iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 85 ],
      "url" : "http://t.co/KRXY0vCb",
      "expanded_url" : "http://itun.es/us/98imG.i",
      "display_url" : "itun.es/us/98imG.i"
    } ]
  },
  "geo" : { },
  "id_str" : "256416338875150336",
  "text" : "Photoset, a new photo-centric app from Tumblr. Iiiiinteresting.  http://t.co/KRXY0vCb",
  "id" : 256416338875150336,
  "created_at" : "2012-10-11 15:29:53 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://bufferapp.com\" rel=\"nofollow\">Buffer</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "256260114636488704",
  "text" : "You are who you follow.",
  "id" : 256260114636488704,
  "created_at" : "2012-10-11 05:09:07 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 74 ],
      "url" : "http://t.co/KaorgGmt",
      "expanded_url" : "http://instagr.am/p/QoLgIUI0Co/",
      "display_url" : "instagr.am/p/QoLgIUI0Co/"
    } ]
  },
  "geo" : { },
  "id_str" : "256242951519363072",
  "text" : "8:36pm Something creepy about the Holiday Inn tonight http://t.co/KaorgGmt",
  "id" : 256242951519363072,
  "created_at" : "2012-10-11 04:00:55 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joost Plattel",
      "screen_name" : "jplattel",
      "indices" : [ 4, 13 ],
      "id_str" : "16376925",
      "id" : 16376925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "256153807606648832",
  "geo" : { },
  "id_str" : "256155953655840768",
  "in_reply_to_user_id" : 16376925,
  "text" : "Pay @jplattel $1 for complaining about the curse of the Twitter salad bar. Ha.",
  "id" : 256155953655840768,
  "in_reply_to_status_id" : 256153807606648832,
  "created_at" : "2012-10-10 22:15:13 +0000",
  "in_reply_to_screen_name" : "jplattel",
  "in_reply_to_user_id_str" : "16376925",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://bufferapp.com\" rel=\"nofollow\">Buffer</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "256149049764372480",
  "text" : "My Twitter salad bar curse: I want ALL the ingredients. Still pretty delicious as curses go though.",
  "id" : 256149049764372480,
  "created_at" : "2012-10-10 21:47:47 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carolyn Thomas",
      "screen_name" : "HeartSisters",
      "indices" : [ 0, 13 ],
      "id_str" : "41013626",
      "id" : 41013626
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "256117598071173120",
  "geo" : { },
  "id_str" : "256121918720204800",
  "in_reply_to_user_id" : 41013626,
  "text" : "@HeartSisters That was my point. It's really difficult and people don't give it (and all behav change) enough credit for being difficult.",
  "id" : 256121918720204800,
  "in_reply_to_status_id" : 256117598071173120,
  "created_at" : "2012-10-10 19:59:58 +0000",
  "in_reply_to_screen_name" : "HeartSisters",
  "in_reply_to_user_id_str" : "41013626",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carolyn Thomas",
      "screen_name" : "HeartSisters",
      "indices" : [ 0, 13 ],
      "id_str" : "41013626",
      "id" : 41013626
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "256103410468786176",
  "geo" : { },
  "id_str" : "256108022412238848",
  "in_reply_to_user_id" : 41013626,
  "text" : "@HeartSisters Thanks! How do you think behavior change is different for sick people? Isn't it important to first believe in a healthy you?",
  "id" : 256108022412238848,
  "in_reply_to_status_id" : 256103410468786176,
  "created_at" : "2012-10-10 19:04:45 +0000",
  "in_reply_to_screen_name" : "HeartSisters",
  "in_reply_to_user_id_str" : "41013626",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Hall",
      "screen_name" : "Hallicious",
      "indices" : [ 0, 11 ],
      "id_str" : "16233090",
      "id" : 16233090
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "256083375952105472",
  "geo" : { },
  "id_str" : "256084262539898881",
  "in_reply_to_user_id" : 16233090,
  "text" : "@Hallicious Definitely. Identity is a big ball of wax with lots of other people in it.",
  "id" : 256084262539898881,
  "in_reply_to_status_id" : 256083375952105472,
  "created_at" : "2012-10-10 17:30:20 +0000",
  "in_reply_to_screen_name" : "Hallicious",
  "in_reply_to_user_id_str" : "16233090",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Willo O'Brien",
      "screen_name" : "WilloToons",
      "indices" : [ 0, 11 ],
      "id_str" : "1099629326",
      "id" : 1099629326
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "256081754060906497",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7764079176, -122.416745384 ]
  },
  "id_str" : "256082936464560128",
  "in_reply_to_user_id" : 772386,
  "text" : "@WilloToons It's super rad.",
  "id" : 256082936464560128,
  "in_reply_to_status_id" : 256081754060906497,
  "created_at" : "2012-10-10 17:25:04 +0000",
  "in_reply_to_screen_name" : "WilloLovesYou",
  "in_reply_to_user_id_str" : "772386",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Findings",
      "screen_name" : "findings",
      "indices" : [ 130, 139 ],
      "id_str" : "208197274",
      "id" : 208197274
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 20 ],
      "url" : "http://t.co/dRZed8CE",
      "expanded_url" : "http://Findings.com",
      "display_url" : "Findings.com"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7763958811, -122.4167582912 ]
  },
  "id_str" : "256081135493320704",
  "text" : "http://t.co/dRZed8CE is my new favorite website. Killer feature is Chrome ext + turning any text into pretty images to share. Thx @findings!",
  "id" : 256081135493320704,
  "created_at" : "2012-10-10 17:17:55 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Susannah Fox",
      "screen_name" : "SusannahFox",
      "indices" : [ 0, 12 ],
      "id_str" : "17843236",
      "id" : 17843236
    }, {
      "name" : "Emilio Ramirez",
      "screen_name" : "e_ramirez",
      "indices" : [ 72, 82 ],
      "id_str" : "1273564632",
      "id" : 1273564632
    }, {
      "name" : "Carolyn Thomas",
      "screen_name" : "HeartSisters",
      "indices" : [ 83, 96 ],
      "id_str" : "41013626",
      "id" : 41013626
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "256069588817674240",
  "geo" : { },
  "id_str" : "256072989060255744",
  "in_reply_to_user_id" : 17843236,
  "text" : "@SusannahFox Which perspective in the article are you referring to? /cc @e_ramirez @HeartSisters",
  "id" : 256072989060255744,
  "in_reply_to_status_id" : 256069588817674240,
  "created_at" : "2012-10-10 16:45:32 +0000",
  "in_reply_to_screen_name" : "SusannahFox",
  "in_reply_to_user_id_str" : "17843236",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://bufferapp.com\" rel=\"nofollow\">Buffer</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emilio Ramirez",
      "screen_name" : "e_ramirez",
      "indices" : [ 79, 89 ],
      "id_str" : "1273564632",
      "id" : 1273564632
    }, {
      "name" : "Chris Hogg",
      "screen_name" : "cwhogg",
      "indices" : [ 90, 97 ],
      "id_str" : "15727738",
      "id" : 15727738
    }, {
      "name" : "Aaron Coleman",
      "screen_name" : "aarondcoleman",
      "indices" : [ 98, 112 ],
      "id_str" : "1379965428",
      "id" : 1379965428
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 73 ],
      "url" : "http://t.co/5wMs8CYa",
      "expanded_url" : "http://bit.ly/TgLAVv",
      "display_url" : "bit.ly/TgLAVv"
    } ]
  },
  "geo" : { },
  "id_str" : "256067589627867137",
  "text" : "'Behavior change is belief change' - Way of the Duck http://t.co/5wMs8CYa  /cc @e_ramirez @cwhogg @aarondcoleman",
  "id" : 256067589627867137,
  "created_at" : "2012-10-10 16:24:05 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lisa Phillips",
      "screen_name" : "lisaphillips",
      "indices" : [ 3, 16 ],
      "id_str" : "733383",
      "id" : 733383
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 79 ],
      "url" : "http://t.co/013HvdGZ",
      "expanded_url" : "http://www.reddit.com/r/IAmA/comments/1197d7/iam_ira_glass_creator_of_this_american_life_ama/",
      "display_url" : "reddit.com/r/IAmA/comment\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "256060851897909250",
  "text" : "RT @lisaphillips: IAm Ira Glass starting in a few minutes! http://t.co/013HvdGZ",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 41, 61 ],
        "url" : "http://t.co/013HvdGZ",
        "expanded_url" : "http://www.reddit.com/r/IAmA/comments/1197d7/iam_ira_glass_creator_of_this_american_life_ama/",
        "display_url" : "reddit.com/r/IAmA/comment\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "256060744494379008",
    "text" : "IAm Ira Glass starting in a few minutes! http://t.co/013HvdGZ",
    "id" : 256060744494379008,
    "created_at" : "2012-10-10 15:56:53 +0000",
    "user" : {
      "name" : "Lisa Phillips",
      "screen_name" : "lisaphillips",
      "protected" : false,
      "id_str" : "733383",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000008510132/5fff65395076b6dc6149c1f31961b9fa_normal.jpeg",
      "id" : 733383,
      "verified" : false
    }
  },
  "id" : 256060851897909250,
  "created_at" : "2012-10-10 15:57:19 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emilio Ramirez",
      "screen_name" : "e_ramirez",
      "indices" : [ 0, 10 ],
      "id_str" : "1273564632",
      "id" : 1273564632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "255925998288265216",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7774658784, -122.4144258685 ]
  },
  "id_str" : "255927178829635584",
  "in_reply_to_user_id" : 21135674,
  "text" : "@e_ramirez How many miles is 27k steps anyway? I guess I shouldn't be picking the nearby hotels if I wanna break 10% of that.",
  "id" : 255927178829635584,
  "in_reply_to_status_id" : 255925998288265216,
  "created_at" : "2012-10-10 07:06:08 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emilio Ramirez",
      "screen_name" : "e_ramirez",
      "indices" : [ 0, 10 ],
      "id_str" : "1273564632",
      "id" : 1273564632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "255925129811468288",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7775021014, -122.4143840627 ]
  },
  "id_str" : "255925708520574976",
  "in_reply_to_user_id" : 21135674,
  "text" : "@e_ramirez Holy guacamole.",
  "id" : 255925708520574976,
  "in_reply_to_status_id" : 255925129811468288,
  "created_at" : "2012-10-10 07:00:18 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "quantifiedself",
      "indices" : [ 26, 41 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 106 ],
      "url" : "http://t.co/TGaymYgx",
      "expanded_url" : "http://instagr.am/p/Qlj3xwI0EV/",
      "display_url" : "instagr.am/p/Qlj3xwI0EV/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.777089, -122.421494 ]
  },
  "id_str" : "255874362555633664",
  "text" : "8:36pm Talking shit about #quantifiedself with Ernesto, Chris, and Aaron  @ The Grove http://t.co/TGaymYgx",
  "id" : 255874362555633664,
  "created_at" : "2012-10-10 03:36:16 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lift",
      "screen_name" : "liftapp",
      "indices" : [ 3, 11 ],
      "id_str" : "353195232",
      "id" : 353195232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "255843673823141889",
  "text" : "RT @liftapp: Join the flossing revolution!  Be our millionth tooth flosser and win a T-shirt and a year's worth of floss http://t.co/60p ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 108, 128 ],
        "url" : "http://t.co/60p9zb5y",
        "expanded_url" : "http://lift.do/p/million-teeth-challenge",
        "display_url" : "lift.do/p/million-teet\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "255842008852230145",
    "text" : "Join the flossing revolution!  Be our millionth tooth flosser and win a T-shirt and a year's worth of floss http://t.co/60p9zb5y",
    "id" : 255842008852230145,
    "created_at" : "2012-10-10 01:27:42 +0000",
    "user" : {
      "name" : "Lift",
      "screen_name" : "liftapp",
      "protected" : false,
      "id_str" : "353195232",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2553948018/m4bp61wehttc623ie6c7_normal.png",
      "id" : 353195232,
      "verified" : false
    }
  },
  "id" : 255843673823141889,
  "created_at" : "2012-10-10 01:34:19 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "geoffclapp",
      "screen_name" : "geoffclapp",
      "indices" : [ 0, 11 ],
      "id_str" : "12118392",
      "id" : 12118392
    }, {
      "name" : "Aaron Coleman",
      "screen_name" : "aarondcoleman",
      "indices" : [ 12, 26 ],
      "id_str" : "1379965428",
      "id" : 1379965428
    }, {
      "name" : "Chris Hogg",
      "screen_name" : "cwhogg",
      "indices" : [ 27, 34 ],
      "id_str" : "15727738",
      "id" : 15727738
    }, {
      "name" : "Emilio Ramirez",
      "screen_name" : "e_ramirez",
      "indices" : [ 35, 45 ],
      "id_str" : "1273564632",
      "id" : 1273564632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "255799637175316481",
  "geo" : { },
  "id_str" : "255801919061250048",
  "in_reply_to_user_id" : 12118392,
  "text" : "@geoffclapp @aarondcoleman @cwhogg @e_ramirez Awesome. You should come too, Geoff!",
  "id" : 255801919061250048,
  "in_reply_to_status_id" : 255799637175316481,
  "created_at" : "2012-10-09 22:48:24 +0000",
  "in_reply_to_screen_name" : "geoffclapp",
  "in_reply_to_user_id_str" : "12118392",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Coleman",
      "screen_name" : "aarondcoleman",
      "indices" : [ 0, 14 ],
      "id_str" : "1379965428",
      "id" : 1379965428
    }, {
      "name" : "Chris Hogg",
      "screen_name" : "cwhogg",
      "indices" : [ 15, 22 ],
      "id_str" : "15727738",
      "id" : 15727738
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "255516938699157505",
  "geo" : { },
  "id_str" : "255791686930792448",
  "in_reply_to_user_id" : 9609062,
  "text" : "@aarondcoleman @cwhogg How about The Grove in Hayes? I like that place. I'm free after about 7 or so.",
  "id" : 255791686930792448,
  "in_reply_to_status_id" : 255516938699157505,
  "created_at" : "2012-10-09 22:07:45 +0000",
  "in_reply_to_screen_name" : "aaronc",
  "in_reply_to_user_id_str" : "9609062",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Frank Jania",
      "screen_name" : "fjania",
      "indices" : [ 0, 7 ],
      "id_str" : "797383",
      "id" : 797383
    }, {
      "name" : "Findings",
      "screen_name" : "findings",
      "indices" : [ 85, 94 ],
      "id_str" : "208197274",
      "id" : 208197274
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "255741571725676544",
  "geo" : { },
  "id_str" : "255758966083170304",
  "in_reply_to_user_id" : 797383,
  "text" : "@fjania Ooh, I hadn't heard of that. I'll check it out... looks awesome. Thanks! /cc @findings",
  "id" : 255758966083170304,
  "in_reply_to_status_id" : 255741571725676544,
  "created_at" : "2012-10-09 19:57:43 +0000",
  "in_reply_to_screen_name" : "fjania",
  "in_reply_to_user_id_str" : "797383",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Findings",
      "screen_name" : "findings",
      "indices" : [ 0, 9 ],
      "id_str" : "208197274",
      "id" : 208197274
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "255400033191591937",
  "geo" : { },
  "id_str" : "255707362478919680",
  "in_reply_to_user_id" : 208197274,
  "text" : "@findings If I may ask, what tools/tech are you using to generate the quoted text images that go to Facebook and Twitter Cards?",
  "id" : 255707362478919680,
  "in_reply_to_status_id" : 255400033191591937,
  "created_at" : "2012-10-09 16:32:40 +0000",
  "in_reply_to_screen_name" : "findings",
  "in_reply_to_user_id_str" : "208197274",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charlie Park",
      "screen_name" : "charliepark",
      "indices" : [ 0, 12 ],
      "id_str" : "3225381",
      "id" : 3225381
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "255688505030750208",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7776390144, -122.4143947138 ]
  },
  "id_str" : "255689520689864704",
  "in_reply_to_user_id" : 3225381,
  "text" : "@charliepark Thanks, definitely on the right track...",
  "id" : 255689520689864704,
  "in_reply_to_status_id" : 255688505030750208,
  "created_at" : "2012-10-09 15:21:46 +0000",
  "in_reply_to_screen_name" : "charliepark",
  "in_reply_to_user_id_str" : "3225381",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charlie Park",
      "screen_name" : "charliepark",
      "indices" : [ 84, 96 ],
      "id_str" : "3225381",
      "id" : 3225381
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 78 ],
      "url" : "http://t.co/9eW0wcg3",
      "expanded_url" : "http://www.plannedobsolescence.net/blog/out-of-the-habit/",
      "display_url" : "plannedobsolescence.net/blog/out-of-th\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7776244779, -122.4144098974 ]
  },
  "id_str" : "255689429295972352",
  "text" : "What can you do to make habits that are disruption-proof? http://t.co/9eW0wcg3 /via @charliepark",
  "id" : 255689429295972352,
  "created_at" : "2012-10-09 15:21:25 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 112 ],
      "url" : "http://t.co/Av15gdwl",
      "expanded_url" : "http://m.youtube.com/#/watch?v=bZxs09eV-Vc&desktop_uri=%2Fwatch%3Fv%3DbZxs09eV-Vc",
      "display_url" : "m.youtube.com/#/watch?v=bZxs\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7774278759, -122.4144692134 ]
  },
  "id_str" : "255682280943661056",
  "text" : "\"Mitt Romney: taking on our enemies no matter where they nest\" (weirdest campaign ad ever?) http://t.co/Av15gdwl",
  "id" : 255682280943661056,
  "created_at" : "2012-10-09 14:53:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 96 ],
      "url" : "http://t.co/vLbp0zc7",
      "expanded_url" : "http://flic.kr/p/di5utb",
      "display_url" : "flic.kr/p/di5utb"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7775, -122.4145 ]
  },
  "id_str" : "255517210943045632",
  "text" : "8:36pm Niko puking all night + 4am flight + full day of work = tired Buster http://t.co/vLbp0zc7",
  "id" : 255517210943045632,
  "created_at" : "2012-10-09 03:57:05 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Hogg",
      "screen_name" : "cwhogg",
      "indices" : [ 0, 7 ],
      "id_str" : "15727738",
      "id" : 15727738
    }, {
      "name" : "Aaron Coleman",
      "screen_name" : "aarondcoleman",
      "indices" : [ 8, 22 ],
      "id_str" : "1379965428",
      "id" : 1379965428
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "255516262652850176",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7774238183, -122.4144130564 ]
  },
  "id_str" : "255516527351193600",
  "in_reply_to_user_id" : 15727738,
  "text" : "@cwhogg @aarondcoleman I'm free tomorrow evening... staying near Civic Center... where should we meet?",
  "id" : 255516527351193600,
  "in_reply_to_status_id" : 255516262652850176,
  "created_at" : "2012-10-09 03:54:22 +0000",
  "in_reply_to_screen_name" : "cwhogg",
  "in_reply_to_user_id_str" : "15727738",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "josh",
      "screen_name" : "joshc",
      "indices" : [ 0, 6 ],
      "id_str" : "2015",
      "id" : 2015
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "255483048831885313",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7770395744, -122.4214132102 ]
  },
  "id_str" : "255486109398745089",
  "in_reply_to_user_id" : 2015,
  "text" : "@joshc Was wondering how it's possible to read all tweets when I checked your follow count. Can't believe you broke the 50 follow rule!",
  "id" : 255486109398745089,
  "in_reply_to_status_id" : 255483048831885313,
  "created_at" : "2012-10-09 01:53:29 +0000",
  "in_reply_to_screen_name" : "joshc",
  "in_reply_to_user_id_str" : "2015",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Coleman",
      "screen_name" : "aarondcoleman",
      "indices" : [ 0, 14 ],
      "id_str" : "1379965428",
      "id" : 1379965428
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "255476978575085569",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7770448352, -122.4214354535 ]
  },
  "id_str" : "255484755397730305",
  "in_reply_to_user_id" : 9609062,
  "text" : "@aarondcoleman I am but I'm dead after a night of sick baby and 4am flight. Here all week though... will another night work?",
  "id" : 255484755397730305,
  "in_reply_to_status_id" : 255476978575085569,
  "created_at" : "2012-10-09 01:48:07 +0000",
  "in_reply_to_screen_name" : "aaronc",
  "in_reply_to_user_id_str" : "9609062",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Findings",
      "screen_name" : "findings",
      "indices" : [ 0, 9 ],
      "id_str" : "208197274",
      "id" : 208197274
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "255382148507389952",
  "geo" : { },
  "id_str" : "255392412560666624",
  "in_reply_to_user_id" : 208197274,
  "text" : "@findings Thank you! PS. I'm a big fan of the way you've integrated Twitter Cards. Best use of it I've seen so far. (I'm on that team.)",
  "id" : 255392412560666624,
  "in_reply_to_status_id" : 255382148507389952,
  "created_at" : "2012-10-08 19:41:10 +0000",
  "in_reply_to_screen_name" : "findings",
  "in_reply_to_user_id_str" : "208197274",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"https://findings.com\" rel=\"nofollow\">Findings</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 117 ],
      "url" : "http://t.co/hxpyRh5X",
      "expanded_url" : "http://findings.com",
      "display_url" : "findings.com"
    }, {
      "indices" : [ 120, 140 ],
      "url" : "http://t.co/Wln8tD5V",
      "expanded_url" : "http://fnd.gs/RLJqjE",
      "display_url" : "fnd.gs/RLJqjE"
    } ]
  },
  "geo" : { },
  "id_str" : "255380260328177666",
  "text" : "\"Think about some of the problems of our daily lives, and how many of them would be ease...\" via http://t.co/hxpyRh5X - http://t.co/Wln8tD5V",
  "id" : 255380260328177666,
  "created_at" : "2012-10-08 18:52:53 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mari Sheibley",
      "screen_name" : "Mari18",
      "indices" : [ 45, 52 ],
      "id_str" : "9270952",
      "id" : 9270952
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 91 ],
      "url" : "http://t.co/NUQp2nFL",
      "expanded_url" : "http://www.mobile-patterns.com",
      "display_url" : "mobile-patterns.com"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7769156125, -122.4160657213 ]
  },
  "id_str" : "255343343679205376",
  "text" : "I love this catalog of mobile UI patterns RT @Mari18: Weekend Project: http://t.co/NUQp2nFL v2.0",
  "id" : 255343343679205376,
  "created_at" : "2012-10-08 16:26:11 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leo Babauta",
      "screen_name" : "zen_habits",
      "indices" : [ 26, 37 ],
      "id_str" : "15859268",
      "id" : 15859268
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 104 ],
      "url" : "http://t.co/MXfIcZcl",
      "expanded_url" : "http://zenhabits.net/alone/",
      "display_url" : "zenhabits.net/alone/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7769519693, -122.4160584742 ]
  },
  "id_str" : "255342844175347712",
  "text" : "A well-worded reminder RT @zen_habits: Learning to Sit Alone, in a Quiet Empty Room http://t.co/MXfIcZcl",
  "id" : 255342844175347712,
  "created_at" : "2012-10-08 16:24:12 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tumblr.com/\" rel=\"nofollow\">Tumblr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 28 ],
      "url" : "http://t.co/41sXgcD5",
      "expanded_url" : "http://tmblr.co/ZQJvayUuGeXi",
      "display_url" : "tmblr.co/ZQJvayUuGeXi"
    } ]
  },
  "geo" : { },
  "id_str" : "255288833485201409",
  "text" : "Photo:  http://t.co/41sXgcD5",
  "id" : 255288833485201409,
  "created_at" : "2012-10-08 12:49:35 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 125 ],
      "url" : "http://t.co/jHb2AZCU",
      "expanded_url" : "http://4sq.com/VEsEWQ",
      "display_url" : "4sq.com/VEsEWQ"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.4436465828, -122.3025941849 ]
  },
  "id_str" : "255275459942694912",
  "text" : "Seattle -&gt; SF for the week. Good morning! (@ Seattle-Tacoma International Airport (SEA) w/ 15 others) http://t.co/jHb2AZCU",
  "id" : 255275459942694912,
  "created_at" : "2012-10-08 11:56:27 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Kathleen Peck",
      "screen_name" : "sarahkpeck",
      "indices" : [ 3, 14 ],
      "id_str" : "196745496",
      "id" : 196745496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 78 ],
      "url" : "http://t.co/T8EPEIR6",
      "expanded_url" : "http://bakadesuyo.com/2012/10/07/how-much-happiness-does-it-take-to-make-up-for-the-sadness-in-life/",
      "display_url" : "bakadesuyo.com/2012/10/07/how\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "255271803625291778",
  "text" : "RT @sarahkpeck: 3:1 and 5:1 ratios for happiness, health  http://t.co/T8EPEIR6",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.apple.com\" rel=\"nofollow\">Safari on iOS</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 42, 62 ],
        "url" : "http://t.co/T8EPEIR6",
        "expanded_url" : "http://bakadesuyo.com/2012/10/07/how-much-happiness-does-it-take-to-make-up-for-the-sadness-in-life/",
        "display_url" : "bakadesuyo.com/2012/10/07/how\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "255256694815346688",
    "text" : "3:1 and 5:1 ratios for happiness, health  http://t.co/T8EPEIR6",
    "id" : 255256694815346688,
    "created_at" : "2012-10-08 10:41:53 +0000",
    "user" : {
      "name" : "Sarah Kathleen Peck",
      "screen_name" : "sarahkpeck",
      "protected" : false,
      "id_str" : "196745496",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3459962896/4d0b50de5c22e42a4113858dfeef8814_normal.jpeg",
      "id" : 196745496,
      "verified" : false
    }
  },
  "id" : 255271803625291778,
  "created_at" : "2012-10-08 11:41:55 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "girl jo",
      "screen_name" : "octavekitten",
      "indices" : [ 0, 13 ],
      "id_str" : "16366882",
      "id" : 16366882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "255149838897917952",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6086431044, -122.306428319 ]
  },
  "id_str" : "255158082026491904",
  "in_reply_to_user_id" : 16366882,
  "text" : "@octavekitten Mine's for 4am. Enjoy sleeping in!",
  "id" : 255158082026491904,
  "in_reply_to_status_id" : 255149838897917952,
  "created_at" : "2012-10-08 04:10:02 +0000",
  "in_reply_to_screen_name" : "octavekitten",
  "in_reply_to_user_id_str" : "16366882",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Britt Selvitelle",
      "screen_name" : "bs",
      "indices" : [ 23, 26 ],
      "id_str" : "309073",
      "id" : 309073
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6085773195, -122.3059120283 ]
  },
  "id_str" : "255157371096150016",
  "text" : "Awesome. Good luck! RT @bs: Tonight I'm performing an experiment. No backlit technology after 10:30; In bed by 11:30. 23 minutes left...",
  "id" : 255157371096150016,
  "created_at" : "2012-10-08 04:07:12 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 91 ],
      "url" : "http://t.co/VTKC3N4U",
      "expanded_url" : "http://flic.kr/p/dhHXF3",
      "display_url" : "flic.kr/p/dhHXF3"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.608666, -122.306167 ]
  },
  "id_str" : "255150278268051458",
  "text" : "8:36pm Reviewing the Little Engine's strategy for going up steep hills http://t.co/VTKC3N4U",
  "id" : 255150278268051458,
  "created_at" : "2012-10-08 03:39:01 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.apple.com\" rel=\"nofollow\">Safari on iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http://t.co/QTTaR5Yi",
      "expanded_url" : "http://ceklog.kindel.com/2012/09/26/paying-developers-is-a-bad-idea/",
      "display_url" : "ceklog.kindel.com/2012/09/26/pay\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "255077821435752448",
  "text" : "Interesting notes on platforms \"A platform provides the means for a multi-sided market to operate in a virtuous cycle.\" http://t.co/QTTaR5Yi",
  "id" : 255077821435752448,
  "created_at" : "2012-10-07 22:51:06 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Megan Welling",
      "screen_name" : "MeganWelling",
      "indices" : [ 0, 13 ],
      "id_str" : "26166039",
      "id" : 26166039
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "255050471864156161",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6086928929, -122.3061256484 ]
  },
  "id_str" : "255065772525776896",
  "in_reply_to_user_id" : 26166039,
  "text" : "@MeganWelling Do you have another one in mind? I'm gonna need some serious training time... 6 months?",
  "id" : 255065772525776896,
  "in_reply_to_status_id" : 255050471864156161,
  "created_at" : "2012-10-07 22:03:13 +0000",
  "in_reply_to_screen_name" : "MeganWelling",
  "in_reply_to_user_id_str" : "26166039",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Megan Welling",
      "screen_name" : "MeganWelling",
      "indices" : [ 0, 13 ],
      "id_str" : "26166039",
      "id" : 26166039
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "255039814204809216",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6164280484, -122.3189798837 ]
  },
  "id_str" : "255042993965387777",
  "in_reply_to_user_id" : 26166039,
  "text" : "@MeganWelling You're awesome! I am newly inspired to run a marathon again...",
  "id" : 255042993965387777,
  "in_reply_to_status_id" : 255039814204809216,
  "created_at" : "2012-10-07 20:32:42 +0000",
  "in_reply_to_screen_name" : "MeganWelling",
  "in_reply_to_user_id_str" : "26166039",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 95 ],
      "url" : "http://t.co/zFXSutGt",
      "expanded_url" : "http://4sq.com/TimWci",
      "display_url" : "4sq.com/TimWci"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6170123598, -122.3191165924 ]
  },
  "id_str" : "255038936160825344",
  "text" : "Ryan + Carla post-wedding brunch! (@ Cal Anderson Park w/ 3 others) [pic]: http://t.co/zFXSutGt",
  "id" : 255038936160825344,
  "created_at" : "2012-10-07 20:16:35 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Megan Welling",
      "screen_name" : "MeganWelling",
      "indices" : [ 0, 13 ],
      "id_str" : "26166039",
      "id" : 26166039
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "254943381745172480",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6087403775, -122.2999425273 ]
  },
  "id_str" : "254989839982804992",
  "in_reply_to_user_id" : 26166039,
  "text" : "@MeganWelling Run run run! Are you in Chicago?",
  "id" : 254989839982804992,
  "in_reply_to_status_id" : 254943381745172480,
  "created_at" : "2012-10-07 17:01:29 +0000",
  "in_reply_to_screen_name" : "MeganWelling",
  "in_reply_to_user_id_str" : "26166039",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 46 ],
      "url" : "http://t.co/FwRDdOlt",
      "expanded_url" : "http://instagr.am/p/Qd2Jm7I0Iy/",
      "display_url" : "instagr.am/p/Qd2Jm7I0Iy/"
    } ]
  },
  "geo" : { },
  "id_str" : "254788340807774208",
  "text" : "8:36pm Just cut the cake! http://t.co/FwRDdOlt",
  "id" : 254788340807774208,
  "created_at" : "2012-10-07 03:40:48 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 77 ],
      "url" : "http://t.co/ut9smL9Z",
      "expanded_url" : "http://instagr.am/p/Qd1EyxI0H5/",
      "display_url" : "instagr.am/p/Qd1EyxI0H5/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6137433362, -122.319288254 ]
  },
  "id_str" : "254786014659371008",
  "text" : "Congrats to the beautiful Ryan and Carla!  @ Sole Repair http://t.co/ut9smL9Z",
  "id" : 254786014659371008,
  "created_at" : "2012-10-07 03:31:34 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 53 ],
      "url" : "http://t.co/ufOpUdji",
      "expanded_url" : "http://instagr.am/p/Qdx8Qlo0FG/",
      "display_url" : "instagr.am/p/Qdx8Qlo0FG/"
    } ]
  },
  "geo" : { },
  "id_str" : "254785584579637248",
  "text" : "The photo booth gets projected!  http://t.co/ufOpUdji",
  "id" : 254785584579637248,
  "created_at" : "2012-10-07 03:29:51 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TED News",
      "screen_name" : "TEDNews",
      "indices" : [ 3, 11 ],
      "id_str" : "36843988",
      "id" : 36843988
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "254774366762594306",
  "text" : "RT @TEDNews: \u201CSelf-study, self-exploration, self-empowerment \u2014 these are the virtues of a great education.\u201D \u2014 Shimon Schocken http://t.c ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TED",
        "indices" : [ 134, 138 ]
      } ],
      "urls" : [ {
        "indices" : [ 113, 133 ],
        "url" : "http://t.co/KQihRlIn",
        "expanded_url" : "http://on.ted.com/oAma",
        "display_url" : "on.ted.com/oAma"
      } ]
    },
    "geo" : { },
    "id_str" : "254773942751985664",
    "text" : "\u201CSelf-study, self-exploration, self-empowerment \u2014 these are the virtues of a great education.\u201D \u2014 Shimon Schocken http://t.co/KQihRlIn #TED",
    "id" : 254773942751985664,
    "created_at" : "2012-10-07 02:43:36 +0000",
    "user" : {
      "name" : "TED News",
      "screen_name" : "TEDNews",
      "protected" : false,
      "id_str" : "36843988",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3279174286/5de7d7794205fc0ba09bdf54e6c16707_normal.png",
      "id" : 36843988,
      "verified" : true
    }
  },
  "id" : 254774366762594306,
  "created_at" : "2012-10-07 02:45:17 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 33 ],
      "url" : "http://t.co/Jv58NHyh",
      "expanded_url" : "http://instagr.am/p/Qdk_H8I0Iu/",
      "display_url" : "instagr.am/p/Qdk_H8I0Iu/"
    } ]
  },
  "geo" : { },
  "id_str" : "254750642516672512",
  "text" : "A manly wine http://t.co/Jv58NHyh",
  "id" : 254750642516672512,
  "created_at" : "2012-10-07 01:11:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 10, 20 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 122 ],
      "url" : "http://t.co/bZtdbV6F",
      "expanded_url" : "http://instagr.am/p/QdgUvwo0EE/",
      "display_url" : "instagr.am/p/QdgUvwo0EE/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6146947833, -122.328347 ]
  },
  "id_str" : "254741409389756416",
  "text" : "Beautiful @Kellianne waves to the camera on our pre-wedding post-anniversary date  @ Sitka and Spruce http://t.co/bZtdbV6F",
  "id" : 254741409389756416,
  "created_at" : "2012-10-07 00:34:19 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Level Up",
      "screen_name" : "Levelup",
      "indices" : [ 73, 81 ],
      "id_str" : "154443548",
      "id" : 154443548
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6084989356, -122.3061129079 ]
  },
  "id_str" : "254683464123707393",
  "text" : "Left my wallet at home accidentally but luckily the coffee shop accepted @levelup. Small step towards leaving my wallet home all the time.",
  "id" : 254683464123707393,
  "created_at" : "2012-10-06 20:44:04 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Rainert",
      "screen_name" : "arainert",
      "indices" : [ 6, 15 ],
      "id_str" : "7482",
      "id" : 7482
    }, {
      "name" : "Noah Mittman",
      "screen_name" : "noahmittman",
      "indices" : [ 23, 35 ],
      "id_str" : "11382",
      "id" : 11382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6086911746, -122.3058498838 ]
  },
  "id_str" : "254654218621841408",
  "text" : "+1 RT @arainert: +1 RT @noahmittman: My rec. to Twitter would be to get Lists out of its current pit and integrate it into Discover.",
  "id" : 254654218621841408,
  "created_at" : "2012-10-06 18:47:51 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Stubblefield",
      "screen_name" : "jameswilliamiii",
      "indices" : [ 0, 16 ],
      "id_str" : "14057849",
      "id" : 14057849
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "254653496018735104",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6086845529, -122.3058705033 ]
  },
  "id_str" : "254653777469140992",
  "in_reply_to_user_id" : 14057849,
  "text" : "@jameswilliamiii You're welcome!",
  "id" : 254653777469140992,
  "in_reply_to_status_id" : 254653496018735104,
  "created_at" : "2012-10-06 18:46:06 +0000",
  "in_reply_to_screen_name" : "jameswilliamiii",
  "in_reply_to_user_id_str" : "14057849",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.apple.com\" rel=\"nofollow\">iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 127 ],
      "url" : "http://t.co/nZ6gnhp5",
      "expanded_url" : "http://itun.es/us/73sAH.i",
      "display_url" : "itun.es/us/73sAH.i"
    } ]
  },
  "geo" : { },
  "id_str" : "254652100758360064",
  "text" : "Really liking this new meal-tracking app so far: Thryve. Tracking *kinds* of food &gt; tracking calories.  http://t.co/nZ6gnhp5",
  "id" : 254652100758360064,
  "created_at" : "2012-10-06 18:39:26 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://bufferapp.com\" rel=\"nofollow\">Buffer</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 74 ],
      "url" : "http://t.co/QChRoup9",
      "expanded_url" : "http://bit.ly/T7XSPH",
      "display_url" : "bit.ly/T7XSPH"
    } ]
  },
  "geo" : { },
  "id_str" : "254643044001935360",
  "text" : "'Who you are VS who you want to be' - Way of the Duck http://t.co/QChRoup9",
  "id" : 254643044001935360,
  "created_at" : "2012-10-06 18:03:27 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Logan Bowers",
      "screen_name" : "loganb",
      "indices" : [ 0, 7 ],
      "id_str" : "6072622",
      "id" : 6072622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "254625404915154945",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6086767996, -122.3060009257 ]
  },
  "id_str" : "254635652044435456",
  "in_reply_to_user_id" : 6072622,
  "text" : "@loganb Early adopters always have to deal with a couple bugs.",
  "id" : 254635652044435456,
  "in_reply_to_status_id" : 254625404915154945,
  "created_at" : "2012-10-06 17:34:05 +0000",
  "in_reply_to_screen_name" : "loganb",
  "in_reply_to_user_id_str" : "6072622",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Cottrell",
      "screen_name" : "rgcottrell",
      "indices" : [ 0, 11 ],
      "id_str" : "752553",
      "id" : 752553
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "254453222629064704",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6086385781, -122.3059578427 ]
  },
  "id_str" : "254454362884145152",
  "in_reply_to_user_id" : 752553,
  "text" : "@rgcottrell See, it's fun!",
  "id" : 254454362884145152,
  "in_reply_to_status_id" : 254453222629064704,
  "created_at" : "2012-10-06 05:33:42 +0000",
  "in_reply_to_screen_name" : "rgcottrell",
  "in_reply_to_user_id_str" : "752553",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Cottrell",
      "screen_name" : "rgcottrell",
      "indices" : [ 0, 11 ],
      "id_str" : "752553",
      "id" : 752553
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "254449693843681280",
  "geo" : { },
  "id_str" : "254450150343311360",
  "in_reply_to_user_id" : 752553,
  "text" : "@rgcottrell What, you haven't been downloading your tweets since 2006 like I have? :)",
  "id" : 254450150343311360,
  "in_reply_to_status_id" : 254449693843681280,
  "created_at" : "2012-10-06 05:16:57 +0000",
  "in_reply_to_screen_name" : "rgcottrell",
  "in_reply_to_user_id_str" : "752553",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Assink",
      "screen_name" : "jonassink",
      "indices" : [ 0, 10 ],
      "id_str" : "6604252",
      "id" : 6604252
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 67 ],
      "url" : "http://t.co/d4uyNcrn",
      "expanded_url" : "http://busterbenson.com",
      "display_url" : "busterbenson.com"
    } ]
  },
  "in_reply_to_status_id_str" : "254445378307518465",
  "geo" : { },
  "id_str" : "254447141324476416",
  "in_reply_to_user_id" : 6604252,
  "text" : "@jonassink I have a local copy of my tweets on http://t.co/d4uyNcrn, but yeah, I heard that the download thing should be available soon too.",
  "id" : 254447141324476416,
  "in_reply_to_status_id" : 254445378307518465,
  "created_at" : "2012-10-06 05:05:00 +0000",
  "in_reply_to_screen_name" : "jonassink",
  "in_reply_to_user_id_str" : "6604252",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://bufferapp.com\" rel=\"nofollow\">Buffer</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "254445155208294401",
  "text" : "I read through all 10,650ish of my tweets over the last week, picking out the ones I had written about important things in life. Try it!",
  "id" : 254445155208294401,
  "created_at" : "2012-10-06 04:57:07 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris DeVore",
      "screen_name" : "crashdev",
      "indices" : [ 0, 9 ],
      "id_str" : "14763501",
      "id" : 14763501
    }, {
      "name" : "Haiku Deck",
      "screen_name" : "HaikuDeck",
      "indices" : [ 89, 99 ],
      "id_str" : "352538333",
      "id" : 352538333
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 84 ],
      "url" : "http://t.co/TCNXAm2G",
      "expanded_url" : "http://wayoftheduck.com/look-look-look",
      "display_url" : "wayoftheduck.com/look-look-look"
    } ]
  },
  "in_reply_to_status_id_str" : "254436606650503168",
  "geo" : { },
  "id_str" : "254436897454186496",
  "in_reply_to_user_id" : 14763501,
  "text" : "@crashdev Ha, yeah, it's a bit of an obscure reference to this: http://t.co/TCNXAm2G /cc @HaikuDeck",
  "id" : 254436897454186496,
  "in_reply_to_status_id" : 254436606650503168,
  "created_at" : "2012-10-06 04:24:18 +0000",
  "in_reply_to_screen_name" : "crashdev",
  "in_reply_to_user_id_str" : "14763501",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Haiku Deck",
      "screen_name" : "HaikuDeck",
      "indices" : [ 86, 96 ],
      "id_str" : "352538333",
      "id" : 352538333
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 80 ],
      "url" : "http://t.co/XvG2sU9h",
      "expanded_url" : "http://www.haikudeck.com/p/u9qVHcR7Ts/look-look-look",
      "display_url" : "haikudeck.com/p/u9qVHcR7Ts/l\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "254435641184632832",
  "text" : "My attempt at creating words I'd want to look at every day. http://t.co/XvG2sU9h /via @haikudeck",
  "id" : 254435641184632832,
  "created_at" : "2012-10-06 04:19:18 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 92 ],
      "url" : "http://t.co/pbwARzPA",
      "expanded_url" : "http://instagr.am/p/QbRCJ6I0Lq/",
      "display_url" : "instagr.am/p/QbRCJ6I0Lq/"
    } ]
  },
  "geo" : { },
  "id_str" : "254425341861453826",
  "text" : "8:36pm \"So one day her mother brought her a real lion from downtown...\" http://t.co/pbwARzPA",
  "id" : 254425341861453826,
  "created_at" : "2012-10-06 03:38:23 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://bufferapp.com\" rel=\"nofollow\">Buffer</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 58 ],
      "url" : "http://t.co/DSvmqXTT",
      "expanded_url" : "http://bit.ly/PYM82A",
      "display_url" : "bit.ly/PYM82A"
    } ]
  },
  "geo" : { },
  "id_str" : "254416709971243008",
  "text" : "'Look, look, look' - Way of the Duck \nhttp://t.co/DSvmqXTT",
  "id" : 254416709971243008,
  "created_at" : "2012-10-06 03:04:05 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stat Fact",
      "screen_name" : "StatFact",
      "indices" : [ 3, 12 ],
      "id_str" : "220139885",
      "id" : 220139885
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "254405057360035843",
  "text" : "RT @StatFact: 'A Bayesian is one who, vaguely expecting a horse, and catching a glimpse of a donkey, strongly believes he has seen a mule.'",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.hootsuite.com\" rel=\"nofollow\">HootSuite</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "254285273272307712",
    "text" : "'A Bayesian is one who, vaguely expecting a horse, and catching a glimpse of a donkey, strongly believes he has seen a mule.'",
    "id" : 254285273272307712,
    "created_at" : "2012-10-05 18:21:48 +0000",
    "user" : {
      "name" : "Stat Fact",
      "screen_name" : "StatFact",
      "protected" : false,
      "id_str" : "220139885",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1176432323/Product_normal.png",
      "id" : 220139885,
      "verified" : false
    }
  },
  "id" : 254405057360035843,
  "created_at" : "2012-10-06 02:17:46 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6085887477, -122.3059661408 ]
  },
  "id_str" : "254403011747659776",
  "text" : "Dyson spheres are theoretical structures built by intelligent beings that encompass a star and harness its energy. That's a good idea.",
  "id" : 254403011747659776,
  "created_at" : "2012-10-06 02:09:39 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "VentureBeat",
      "screen_name" : "VentureBeat",
      "indices" : [ 3, 15 ],
      "id_str" : "60642052",
      "id" : 60642052
    }, {
      "name" : "Tom Cheredar",
      "screen_name" : "TChed",
      "indices" : [ 112, 118 ],
      "id_str" : "14511908",
      "id" : 14511908
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 108 ],
      "url" : "http://t.co/HmuAjlEf",
      "expanded_url" : "http://tinyurl.com/8rkkm4w",
      "display_url" : "tinyurl.com/8rkkm4w"
    } ]
  },
  "geo" : { },
  "id_str" : "254401914823913472",
  "text" : "RT @VentureBeat: First warp drives, and now we're searching for Dyson Spheres. Awesome. http://t.co/HmuAjlEf by @tched",
  "retweeted_status" : {
    "source" : "<a href=\"http://vip.wordpress.com/hosting\" rel=\"nofollow\">WordPress.com VIP</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Tom Cheredar",
        "screen_name" : "TChed",
        "indices" : [ 95, 101 ],
        "id_str" : "14511908",
        "id" : 14511908
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 71, 91 ],
        "url" : "http://t.co/HmuAjlEf",
        "expanded_url" : "http://tinyurl.com/8rkkm4w",
        "display_url" : "tinyurl.com/8rkkm4w"
      } ]
    },
    "geo" : { },
    "id_str" : "254398346071011330",
    "text" : "First warp drives, and now we're searching for Dyson Spheres. Awesome. http://t.co/HmuAjlEf by @tched",
    "id" : 254398346071011330,
    "created_at" : "2012-10-06 01:51:06 +0000",
    "user" : {
      "name" : "VentureBeat",
      "screen_name" : "VentureBeat",
      "protected" : false,
      "id_str" : "60642052",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1818169678/VB_twitter_logo_normal.jpg",
      "id" : 60642052,
      "verified" : true
    }
  },
  "id" : 254401914823913472,
  "created_at" : "2012-10-06 02:05:17 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6089171507, -122.3061797955 ]
  },
  "id_str" : "254398743917514752",
  "text" : "I wish Johnny Cash had covered The Impossible Dream.",
  "id" : 254398743917514752,
  "created_at" : "2012-10-06 01:52:41 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shane Mac",
      "screen_name" : "ShaneMac",
      "indices" : [ 0, 9 ],
      "id_str" : "44378228",
      "id" : 44378228
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "254369840301760513",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6131916699, -122.3467637972 ]
  },
  "id_str" : "254389023240507392",
  "in_reply_to_user_id" : 44378228,
  "text" : "@ShaneMac Yeah next week. Wanna get a drink?",
  "id" : 254389023240507392,
  "in_reply_to_status_id" : 254369840301760513,
  "created_at" : "2012-10-06 01:14:04 +0000",
  "in_reply_to_screen_name" : "ShaneMac",
  "in_reply_to_user_id_str" : "44378228",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://bufferapp.com\" rel=\"nofollow\">Buffer</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 46 ],
      "url" : "http://t.co/M0TNWnF2",
      "expanded_url" : "http://bit.ly/QYNQEi",
      "display_url" : "bit.ly/QYNQEi"
    } ]
  },
  "geo" : { },
  "id_str" : "254369160614776832",
  "text" : "Look at your fish (again) http://t.co/M0TNWnF2",
  "id" : 254369160614776832,
  "created_at" : "2012-10-05 23:55:08 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Smith",
      "screen_name" : "BuzzFeedBen",
      "indices" : [ 3, 15 ],
      "id_str" : "9532402",
      "id" : 9532402
    }, {
      "name" : "BuzzFeed",
      "screen_name" : "BuzzFeed",
      "indices" : [ 90, 99 ],
      "id_str" : "5695632",
      "id" : 5695632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 85 ],
      "url" : "http://t.co/nzLy3BPM",
      "expanded_url" : "http://www.buzzfeed.com/tommywilhelm/14-things-besides-facebook-with-a-billion-users",
      "display_url" : "buzzfeed.com/tommywilhelm/1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "254340677528326144",
  "text" : "RT @BuzzFeedBen: 14 Things Besides Facebook With A Billion Users http://t.co/nzLy3BPM via @buzzfeed",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "BuzzFeed",
        "screen_name" : "BuzzFeed",
        "indices" : [ 73, 82 ],
        "id_str" : "5695632",
        "id" : 5695632
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 48, 68 ],
        "url" : "http://t.co/nzLy3BPM",
        "expanded_url" : "http://www.buzzfeed.com/tommywilhelm/14-things-besides-facebook-with-a-billion-users",
        "display_url" : "buzzfeed.com/tommywilhelm/1\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "254335930419257344",
    "text" : "14 Things Besides Facebook With A Billion Users http://t.co/nzLy3BPM via @buzzfeed",
    "id" : 254335930419257344,
    "created_at" : "2012-10-05 21:43:05 +0000",
    "user" : {
      "name" : "Ben Smith",
      "screen_name" : "BuzzFeedBen",
      "protected" : false,
      "id_str" : "9532402",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3308219203/61a1772ff3467946cb616997933100d5_normal.jpeg",
      "id" : 9532402,
      "verified" : true
    }
  },
  "id" : 254340677528326144,
  "created_at" : "2012-10-05 22:01:57 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Presentate",
      "screen_name" : "Presentate",
      "indices" : [ 0, 11 ],
      "id_str" : "519044335",
      "id" : 519044335
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "254310358112690177",
  "in_reply_to_user_id" : 519044335,
  "text" : "@Presentate Giving out any more invites soon? I've got a burning need to use this at the moment, would love to beta test it.",
  "id" : 254310358112690177,
  "created_at" : "2012-10-05 20:01:28 +0000",
  "in_reply_to_screen_name" : "Presentate",
  "in_reply_to_user_id_str" : "519044335",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "254287698569871361",
  "text" : "Stay hungry. Stay foolish.",
  "id" : 254287698569871361,
  "created_at" : "2012-10-05 18:31:26 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jad Abumrad",
      "screen_name" : "JadAbumrad",
      "indices" : [ 3, 14 ],
      "id_str" : "135316691",
      "id" : 135316691
    }, {
      "name" : "Ezra Klein",
      "screen_name" : "ezraklein",
      "indices" : [ 28, 38 ],
      "id_str" : "18622869",
      "id" : 18622869
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 93 ],
      "url" : "http://t.co/VCOuM5a7",
      "expanded_url" : "http://wapo.st/PXiWsM",
      "display_url" : "wapo.st/PXiWsM"
    } ]
  },
  "geo" : { },
  "id_str" : "254248162036948993",
  "text" : "RT @JadAbumrad: Interesting @ezraklein post on the latest jobs numbers - http://t.co/VCOuM5a7",
  "retweeted_status" : {
    "source" : "<a href=\"http://bitly.com\" rel=\"nofollow\">bitly</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ezra Klein",
        "screen_name" : "ezraklein",
        "indices" : [ 12, 22 ],
        "id_str" : "18622869",
        "id" : 18622869
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 57, 77 ],
        "url" : "http://t.co/VCOuM5a7",
        "expanded_url" : "http://wapo.st/PXiWsM",
        "display_url" : "wapo.st/PXiWsM"
      } ]
    },
    "geo" : { },
    "id_str" : "254247115977551872",
    "text" : "Interesting @ezraklein post on the latest jobs numbers - http://t.co/VCOuM5a7",
    "id" : 254247115977551872,
    "created_at" : "2012-10-05 15:50:10 +0000",
    "user" : {
      "name" : "Jad Abumrad",
      "screen_name" : "JadAbumrad",
      "protected" : false,
      "id_str" : "135316691",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1529014082/Jad-Pic2_normal.jpg",
      "id" : 135316691,
      "verified" : true
    }
  },
  "id" : 254248162036948993,
  "created_at" : "2012-10-05 15:54:20 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave McClure",
      "screen_name" : "davemcclure",
      "indices" : [ 34, 46 ],
      "id_str" : "1081",
      "id" : 1081
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "false",
      "indices" : [ 24, 30 ]
    }, {
      "text" : "truth",
      "indices" : [ 134, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6087048371, -122.3059487903 ]
  },
  "id_str" : "254109014647005184",
  "text" : "Actually, surprisingly, #false RT @davemcclure: OH: \"being a startup founder ruins u... can't have a real job ever again in ur life.\" #truth",
  "id" : 254109014647005184,
  "created_at" : "2012-10-05 06:41:24 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tumblr.com/\" rel=\"nofollow\">Tumblr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 128 ],
      "url" : "http://t.co/9PacTgnQ",
      "expanded_url" : "http://tmblr.co/ZQJvayUgbDaP",
      "display_url" : "tmblr.co/ZQJvayUgbDaP"
    } ]
  },
  "geo" : { },
  "id_str" : "254104213485916160",
  "text" : "\"Every good story writes its own rules and solves problems of its own devising.\" - From the introduction... http://t.co/9PacTgnQ",
  "id" : 254104213485916160,
  "created_at" : "2012-10-05 06:22:20 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6086957593, -122.3061889829 ]
  },
  "id_str" : "254087586577010688",
  "text" : "OH \"I googled 'I bit my baby' and nothing came up. Nobody admits to that on the internet.\"",
  "id" : 254087586577010688,
  "created_at" : "2012-10-05 05:16:16 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 68 ],
      "url" : "http://t.co/Xw9rYdxm",
      "expanded_url" : "http://instagr.am/p/QYuUz4o0GI/",
      "display_url" : "instagr.am/p/QYuUz4o0GI/"
    } ]
  },
  "geo" : { },
  "id_str" : "254068355621867521",
  "text" : "8:36pm So happy I married this lady 4 years ago http://t.co/Xw9rYdxm",
  "id" : 254068355621867521,
  "created_at" : "2012-10-05 03:59:51 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mr. Marlin",
      "screen_name" : "TheShaggyMarlin",
      "indices" : [ 3, 19 ],
      "id_str" : "132583388",
      "id" : 132583388
    }, {
      "name" : "Chris Savage",
      "screen_name" : "Eclectablog",
      "indices" : [ 45, 57 ],
      "id_str" : "23761008",
      "id" : 23761008
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "254034885294043138",
  "text" : "RT @TheShaggyMarlin: This is a MUST read. RT @Eclectablog President Obama's take on last night's debate (you're going to LOVE this) http ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Chris Savage",
        "screen_name" : "Eclectablog",
        "indices" : [ 24, 36 ],
        "id_str" : "23761008",
        "id" : 23761008
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 111, 131 ],
        "url" : "http://t.co/epeP4oAV",
        "expanded_url" : "http://fb.me/1U4llyBcf",
        "display_url" : "fb.me/1U4llyBcf"
      } ]
    },
    "geo" : { },
    "id_str" : "253960453095583744",
    "text" : "This is a MUST read. RT @Eclectablog President Obama's take on last night's debate (you're going to LOVE this) http://t.co/epeP4oAV",
    "id" : 253960453095583744,
    "created_at" : "2012-10-04 20:51:05 +0000",
    "user" : {
      "name" : "Mr. Marlin",
      "screen_name" : "TheShaggyMarlin",
      "protected" : true,
      "id_str" : "132583388",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2927293143/63c1c75efad4f1f624e1840d2363acf6_normal.jpeg",
      "id" : 132583388,
      "verified" : false
    }
  },
  "id" : 254034885294043138,
  "created_at" : "2012-10-05 01:46:51 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 87, 97 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 130 ],
      "url" : "http://t.co/8t9wBa9s",
      "expanded_url" : "http://bustr.me/kellianne-4",
      "display_url" : "bustr.me/kellianne-4"
    } ]
  },
  "geo" : { },
  "id_str" : "254020260510961665",
  "text" : "4 years ago today I married my beauteous maximum forevercore universalis. My life with @kellianne, in tweets: http://t.co/8t9wBa9s",
  "id" : 254020260510961665,
  "created_at" : "2012-10-05 00:48:44 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ArielMeadowStallings",
      "screen_name" : "OffbeatAriel",
      "indices" : [ 0, 13 ],
      "id_str" : "14095370",
      "id" : 14095370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "253925200721240064",
  "geo" : { },
  "id_str" : "253948895053361152",
  "in_reply_to_user_id" : 14095370,
  "text" : "@OffbeatAriel Ooh, cool! I'm still reading it cause I'm slow like that.",
  "id" : 253948895053361152,
  "in_reply_to_status_id" : 253925200721240064,
  "created_at" : "2012-10-04 20:05:09 +0000",
  "in_reply_to_screen_name" : "OffbeatAriel",
  "in_reply_to_user_id_str" : "14095370",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "253924670942875648",
  "text" : "1,000,000,000 use Facebook every month. That's 1 in every 7 people on the planet. Definitely worthy of a moment of appreciation.",
  "id" : 253924670942875648,
  "created_at" : "2012-10-04 18:28:53 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twitter Government",
      "screen_name" : "gov",
      "indices" : [ 14, 18 ],
      "id_str" : "222953824",
      "id" : 222953824
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/gov/status/253755175460827138/photo/1",
      "indices" : [ 119, 139 ],
      "url" : "http://t.co/iQGRmXcd",
      "media_url" : "http://pbs.twimg.com/media/A4WE_NXCcAA5VCA.jpg",
      "id_str" : "253755175469215744",
      "id" : 253755175469215744,
      "media_url_https" : "https://pbs.twimg.com/media/A4WE_NXCcAA5VCA.jpg",
      "sizes" : [ {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com/iQGRmXcd"
    } ],
    "hashtags" : [ {
      "text" : "debates",
      "indices" : [ 33, 41 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6086554646, -122.305966883 ]
  },
  "id_str" : "253870523166097408",
  "text" : "Cool chart RT @gov: First of the #debates generated 10.3M Tweets in 90 min \u2014 a political-event record. Chart of peaks: http://t.co/iQGRmXcd",
  "id" : 253870523166097408,
  "created_at" : "2012-10-04 14:53:44 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 70 ],
      "url" : "http://t.co/quv7fI1r",
      "expanded_url" : "http://instagr.am/p/QWHfcuI0Cc/",
      "display_url" : "instagr.am/p/QWHfcuI0Cc/"
    } ]
  },
  "geo" : { },
  "id_str" : "253700930451697664",
  "text" : "8:36pm Me: \"Who won the debates?\" Niko: this face http://t.co/quv7fI1r",
  "id" : 253700930451697664,
  "created_at" : "2012-10-04 03:39:50 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "&y",
      "screen_name" : "andypixel",
      "indices" : [ 51, 61 ],
      "id_str" : "10015122",
      "id" : 10015122
    }, {
      "name" : "ingopixel",
      "screen_name" : "ingopixel",
      "indices" : [ 62, 72 ],
      "id_str" : "7943892",
      "id" : 7943892
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "debates",
      "indices" : [ 0, 8 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 101 ],
      "url" : "http://t.co/AW4s7ITE",
      "expanded_url" : "http://4sq.com/Srt4ze",
      "display_url" : "4sq.com/Srt4ze"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6044919218, -122.3099753868 ]
  },
  "id_str" : "253679531800547328",
  "text" : "#debates (@ Pixel Palace Hostel and Petting Zoo w/ @andypixel @ingopixel) [pic]: http://t.co/AW4s7ITE",
  "id" : 253679531800547328,
  "created_at" : "2012-10-04 02:14:48 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian McAllister",
      "screen_name" : "ianmcall",
      "indices" : [ 0, 9 ],
      "id_str" : "2035631",
      "id" : 2035631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "253649187839827972",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6108555496, -122.3051649147 ]
  },
  "id_str" : "253652870350655489",
  "in_reply_to_user_id" : 2035631,
  "text" : "@ianmcall Them's bold words.",
  "id" : 253652870350655489,
  "in_reply_to_status_id" : 253649187839827972,
  "created_at" : "2012-10-04 00:28:51 +0000",
  "in_reply_to_screen_name" : "ianmcall",
  "in_reply_to_user_id_str" : "2035631",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Neilson",
      "screen_name" : "TheCulprit",
      "indices" : [ 0, 11 ],
      "id_str" : "6726182",
      "id" : 6726182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "253629321560858626",
  "geo" : { },
  "id_str" : "253633535599079425",
  "in_reply_to_user_id" : 6726182,
  "text" : "@TheCulprit It's called \"When\". Sort of like if Clear and Lift had a baby.",
  "id" : 253633535599079425,
  "in_reply_to_status_id" : 253629321560858626,
  "created_at" : "2012-10-03 23:12:01 +0000",
  "in_reply_to_screen_name" : "TheCulprit",
  "in_reply_to_user_id_str" : "6726182",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "orta",
      "screen_name" : "orta",
      "indices" : [ 0, 5 ],
      "id_str" : "2569881",
      "id" : 2569881
    }, {
      "name" : "waze",
      "screen_name" : "waze",
      "indices" : [ 6, 11 ],
      "id_str" : "31171669",
      "id" : 31171669
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "253631981160644609",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6142213447, -122.3190419098 ]
  },
  "id_str" : "253632278700380162",
  "in_reply_to_user_id" : 2569881,
  "text" : "@orta @waze Yup. That sucks.",
  "id" : 253632278700380162,
  "in_reply_to_status_id" : 253631981160644609,
  "created_at" : "2012-10-03 23:07:02 +0000",
  "in_reply_to_screen_name" : "orta",
  "in_reply_to_user_id_str" : "2569881",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6141073928, -122.3269246706 ]
  },
  "id_str" : "253629043478519808",
  "text" : "Just had to make a super tough call. Which todo list app will I delete to make room in the folder for the new one I really want?",
  "id" : 253629043478519808,
  "created_at" : "2012-10-03 22:54:10 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ingopixel",
      "screen_name" : "ingopixel",
      "indices" : [ 0, 10 ],
      "id_str" : "7943892",
      "id" : 7943892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "253620946848583681",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6086964133, -122.3375469727 ]
  },
  "id_str" : "253623379972726784",
  "in_reply_to_user_id" : 7943892,
  "text" : "@ingopixel Niko and I might drop by! Gotta feed his face first though.",
  "id" : 253623379972726784,
  "in_reply_to_status_id" : 253620946848583681,
  "created_at" : "2012-10-03 22:31:40 +0000",
  "in_reply_to_screen_name" : "ingopixel",
  "in_reply_to_user_id_str" : "7943892",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cap Watkins",
      "screen_name" : "cap",
      "indices" : [ 0, 4 ],
      "id_str" : "2182141",
      "id" : 2182141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "253600079926136832",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6118653031, -122.3479772876 ]
  },
  "id_str" : "253603414628503552",
  "in_reply_to_user_id" : 2182141,
  "text" : "@cap Let me know if you need a pep talk over beers. I know you have ideas.",
  "id" : 253603414628503552,
  "in_reply_to_status_id" : 253600079926136832,
  "created_at" : "2012-10-03 21:12:20 +0000",
  "in_reply_to_screen_name" : "cap",
  "in_reply_to_user_id_str" : "2182141",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shane Mac",
      "screen_name" : "ShaneMac",
      "indices" : [ 0, 9 ],
      "id_str" : "44378228",
      "id" : 44378228
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "253583003547217920",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6118647769, -122.3479897758 ]
  },
  "id_str" : "253592561208414209",
  "in_reply_to_user_id" : 44378228,
  "text" : "@ShaneMac Impressive.",
  "id" : 253592561208414209,
  "in_reply_to_status_id" : 253583003547217920,
  "created_at" : "2012-10-03 20:29:12 +0000",
  "in_reply_to_screen_name" : "ShaneMac",
  "in_reply_to_user_id_str" : "44378228",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twitter for News",
      "screen_name" : "TwitterForNews",
      "indices" : [ 3, 18 ],
      "id_str" : "372575989",
      "id" : 372575989
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "debates",
      "indices" : [ 50, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 62, 82 ],
      "url" : "http://t.co/qTT0u2cs",
      "expanded_url" : "http://twitter.com/#debates",
      "display_url" : "twitter.com/#debates"
    }, {
      "indices" : [ 117, 137 ],
      "url" : "http://t.co/eWQqM4iR",
      "expanded_url" : "http://blog.twitter.com/2012/10/debate-night-in-america.html",
      "display_url" : "blog.twitter.com/2012/10/debate\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "253592325438193664",
  "text" : "RT @TwitterForNews: Follow tonight's presidential #debates at http://t.co/qTT0u2cs and see what the world is saying: http://t.co/eWQqM4iR",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "debates",
        "indices" : [ 30, 38 ]
      } ],
      "urls" : [ {
        "indices" : [ 42, 62 ],
        "url" : "http://t.co/qTT0u2cs",
        "expanded_url" : "http://twitter.com/#debates",
        "display_url" : "twitter.com/#debates"
      }, {
        "indices" : [ 97, 117 ],
        "url" : "http://t.co/eWQqM4iR",
        "expanded_url" : "http://blog.twitter.com/2012/10/debate-night-in-america.html",
        "display_url" : "blog.twitter.com/2012/10/debate\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "253548398895050752",
    "text" : "Follow tonight's presidential #debates at http://t.co/qTT0u2cs and see what the world is saying: http://t.co/eWQqM4iR",
    "id" : 253548398895050752,
    "created_at" : "2012-10-03 17:33:43 +0000",
    "user" : {
      "name" : "Twitter for News",
      "screen_name" : "TwitterForNews",
      "protected" : false,
      "id_str" : "372575989",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3756363930/c96b2ab95a4149493229210abaf1f1fa_normal.png",
      "id" : 372575989,
      "verified" : true
    }
  },
  "id" : 253592325438193664,
  "created_at" : "2012-10-03 20:28:16 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Megan Casey",
      "screen_name" : "megancasey",
      "indices" : [ 0, 11 ],
      "id_str" : "5562742",
      "id" : 5562742
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "253582065210109952",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.61183985, -122.3479482139 ]
  },
  "id_str" : "253592164439838720",
  "in_reply_to_user_id" : 5562742,
  "text" : "@megancasey Congrats! Exciting...",
  "id" : 253592164439838720,
  "in_reply_to_status_id" : 253582065210109952,
  "created_at" : "2012-10-03 20:27:38 +0000",
  "in_reply_to_screen_name" : "megancasey",
  "in_reply_to_user_id_str" : "5562742",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cap Watkins",
      "screen_name" : "cap",
      "indices" : [ 0, 4 ],
      "id_str" : "2182141",
      "id" : 2182141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "253580985071964162",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6118476876, -122.3479824778 ]
  },
  "id_str" : "253591843927900160",
  "in_reply_to_user_id" : 2182141,
  "text" : "@cap Awesome! You should start your own thing.",
  "id" : 253591843927900160,
  "in_reply_to_status_id" : 253580985071964162,
  "created_at" : "2012-10-03 20:26:21 +0000",
  "in_reply_to_screen_name" : "cap",
  "in_reply_to_user_id_str" : "2182141",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Lacy",
      "screen_name" : "sarahcuda",
      "indices" : [ 3, 13 ],
      "id_str" : "5668942",
      "id" : 5668942
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 79 ],
      "url" : "http://t.co/ANembywc",
      "expanded_url" : "http://pandodaily.com/2012/10/03/native-advertising-will-save-us-all-maybe/",
      "display_url" : "pandodaily.com/2012/10/03/nat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "253591501077110784",
  "text" : "RT @sarahcuda: Native Advertising Will Save Us All. Maybe. http://t.co/ANembywc &lt;- love the article and illo",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 44, 64 ],
        "url" : "http://t.co/ANembywc",
        "expanded_url" : "http://pandodaily.com/2012/10/03/native-advertising-will-save-us-all-maybe/",
        "display_url" : "pandodaily.com/2012/10/03/nat\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "253579465345601537",
    "text" : "Native Advertising Will Save Us All. Maybe. http://t.co/ANembywc &lt;- love the article and illo",
    "id" : 253579465345601537,
    "created_at" : "2012-10-03 19:37:10 +0000",
    "user" : {
      "name" : "Sarah Lacy",
      "screen_name" : "sarahcuda",
      "protected" : false,
      "id_str" : "5668942",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1763460129/lacy_normal.jpg",
      "id" : 5668942,
      "verified" : false
    }
  },
  "id" : 253591501077110784,
  "created_at" : "2012-10-03 20:25:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Child's Play Charity",
      "screen_name" : "CPCharity",
      "indices" : [ 0, 10 ],
      "id_str" : "55656369",
      "id" : 55656369
    }, {
      "name" : "Chirpify",
      "screen_name" : "Chirpify",
      "indices" : [ 39, 48 ],
      "id_str" : "526548703",
      "id" : 526548703
    }, {
      "name" : "Katelyn Reilly",
      "screen_name" : "k_hack",
      "indices" : [ 53, 60 ],
      "id_str" : "17739927",
      "id" : 17739927
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "253543066638630913",
  "geo" : { },
  "id_str" : "253547917938409472",
  "in_reply_to_user_id" : 17739927,
  "text" : "@CPCharity Do you accept donations via @Chirpify /cc @k_hack",
  "id" : 253547917938409472,
  "in_reply_to_status_id" : 253543066638630913,
  "created_at" : "2012-10-03 17:31:48 +0000",
  "in_reply_to_screen_name" : "k_hack",
  "in_reply_to_user_id_str" : "17739927",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OneWorld Now!",
      "screen_name" : "OneWorldNow",
      "indices" : [ 0, 12 ],
      "id_str" : "23861595",
      "id" : 23861595
    }, {
      "name" : "Chirpify",
      "screen_name" : "Chirpify",
      "indices" : [ 41, 50 ],
      "id_str" : "526548703",
      "id" : 526548703
    }, {
      "name" : "Jill S.",
      "screen_name" : "outseide",
      "indices" : [ 56, 65 ],
      "id_str" : "143694663",
      "id" : 143694663
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "253545913082068992",
  "geo" : { },
  "id_str" : "253547774287699968",
  "in_reply_to_user_id" : 23861595,
  "text" : "@OneWorldNow Do you accept donations via @Chirpify  /cc @outseide",
  "id" : 253547774287699968,
  "in_reply_to_status_id" : 253545913082068992,
  "created_at" : "2012-10-03 17:31:14 +0000",
  "in_reply_to_screen_name" : "OneWorldNow",
  "in_reply_to_user_id_str" : "23861595",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "253539546032136192",
  "text" : "What are the best / your favorite charities that have Twitter accounts?",
  "id" : 253539546032136192,
  "created_at" : "2012-10-03 16:58:32 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "noah kagan",
      "screen_name" : "noahkagan",
      "indices" : [ 0, 10 ],
      "id_str" : "13737",
      "id" : 13737
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "253530807329775616",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6122849981, -122.3443394829 ]
  },
  "id_str" : "253531311912931328",
  "in_reply_to_user_id" : 13737,
  "text" : "@noahkagan That would be awesome. Also, I'm moving to SF soon... which might be a more convenient rendezvous.",
  "id" : 253531311912931328,
  "in_reply_to_status_id" : 253530807329775616,
  "created_at" : "2012-10-03 16:25:49 +0000",
  "in_reply_to_screen_name" : "noahkagan",
  "in_reply_to_user_id_str" : "13737",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Fanning",
      "screen_name" : "kfan",
      "indices" : [ 0, 5 ],
      "id_str" : "2011461",
      "id" : 2011461
    }, {
      "name" : "Avery Edison",
      "screen_name" : "aedison",
      "indices" : [ 44, 52 ],
      "id_str" : "1471021",
      "id" : 1471021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "253529035974533120",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6124223748, -122.3445070462 ]
  },
  "id_str" : "253530754364088320",
  "in_reply_to_user_id" : 2011461,
  "text" : "@kfan I don't know but I'll ask around! /cc @aedison",
  "id" : 253530754364088320,
  "in_reply_to_status_id" : 253529035974533120,
  "created_at" : "2012-10-03 16:23:36 +0000",
  "in_reply_to_screen_name" : "kfan",
  "in_reply_to_user_id_str" : "2011461",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "noah kagan",
      "screen_name" : "noahkagan",
      "indices" : [ 64, 74 ],
      "id_str" : "13737",
      "id" : 13737
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 104 ],
      "url" : "http://t.co/pS7rRUjx",
      "expanded_url" : "http://AppSumo.com",
      "display_url" : "AppSumo.com"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6123675574, -122.3442120258 ]
  },
  "id_str" : "253529758439182336",
  "text" : "Something about Noah makes me want to give him all my money. MT @noahkagan: The NEW http://t.co/pS7rRUjx site is live. Thoughts?",
  "id" : 253529758439182336,
  "created_at" : "2012-10-03 16:19:39 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Hagel",
      "screen_name" : "jhagel",
      "indices" : [ 3, 10 ],
      "id_str" : "14076943",
      "id" : 14076943
    }, {
      "name" : "Tim O'Reilly",
      "screen_name" : "timoreilly",
      "indices" : [ 113, 124 ],
      "id_str" : "2384071",
      "id" : 2384071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "253504132537782272",
  "text" : "RT @jhagel: The secret of promotion in age of social media isn't to promote yourself.  It's to promote others by @timoreilly http://t.co ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Tim O'Reilly",
        "screen_name" : "timoreilly",
        "indices" : [ 101, 112 ],
        "id_str" : "2384071",
        "id" : 2384071
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 133 ],
        "url" : "http://t.co/sIi7CEEv",
        "expanded_url" : "http://linkd.in/SCEv0S",
        "display_url" : "linkd.in/SCEv0S"
      } ]
    },
    "geo" : { },
    "id_str" : "253502078046052353",
    "text" : "The secret of promotion in age of social media isn't to promote yourself.  It's to promote others by @timoreilly http://t.co/sIi7CEEv",
    "id" : 253502078046052353,
    "created_at" : "2012-10-03 14:29:39 +0000",
    "user" : {
      "name" : "John Hagel",
      "screen_name" : "jhagel",
      "protected" : false,
      "id_str" : "14076943",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/60658775/Photos_John1_normal.jpg",
      "id" : 14076943,
      "verified" : false
    }
  },
  "id" : 253504132537782272,
  "created_at" : "2012-10-03 14:37:49 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ali.",
      "screen_name" : "knockedup",
      "indices" : [ 0, 10 ],
      "id_str" : "518079559",
      "id" : 518079559
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "253394434752913408",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6087379875, -122.3059409113 ]
  },
  "id_str" : "253400593228500992",
  "in_reply_to_user_id" : 518079559,
  "text" : "@knockedup 1st place in cute baby show! How are you feeling? You have a baby!!!",
  "id" : 253400593228500992,
  "in_reply_to_status_id" : 253394434752913408,
  "created_at" : "2012-10-03 07:46:24 +0000",
  "in_reply_to_screen_name" : "knockedup",
  "in_reply_to_user_id_str" : "518079559",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Cottrell",
      "screen_name" : "rgcottrell",
      "indices" : [ 4, 15 ],
      "id_str" : "752553",
      "id" : 752553
    }, {
      "name" : "Glitch, the game",
      "screen_name" : "playglitch",
      "indices" : [ 122, 133 ],
      "id_str" : "103943240",
      "id" : 103943240
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 117 ],
      "url" : "http://t.co/alwAoJis",
      "expanded_url" : "http://glitch.com",
      "display_url" : "glitch.com"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6086653583, -122.3060810567 ]
  },
  "id_str" : "253398443505106946",
  "text" : "Pay @rgcottrell $1 for complaining that I don't have enough time to play the awesomeness that is http://t.co/alwAoJis /cc @playglitch",
  "id" : 253398443505106946,
  "created_at" : "2012-10-03 07:37:51 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Cottrell",
      "screen_name" : "rgcottrell",
      "indices" : [ 0, 11 ],
      "id_str" : "752553",
      "id" : 752553
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "253396862483177472",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6086653583, -122.3060810567 ]
  },
  "id_str" : "253398159559118848",
  "in_reply_to_user_id" : 752553,
  "text" : "@rgcottrell oh shit, okay...",
  "id" : 253398159559118848,
  "in_reply_to_status_id" : 253396862483177472,
  "created_at" : "2012-10-03 07:36:43 +0000",
  "in_reply_to_screen_name" : "rgcottrell",
  "in_reply_to_user_id_str" : "752553",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 69 ],
      "url" : "http://t.co/6qUG8oGA",
      "expanded_url" : "http://flic.kr/p/dgiVHo",
      "display_url" : "flic.kr/p/dgiVHo"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.447333, -122.301834 ]
  },
  "id_str" : "253365984822435840",
  "text" : "8:36pm Still headache-ing as we land in Seattle. http://t.co/6qUG8oGA",
  "id" : 253365984822435840,
  "created_at" : "2012-10-03 05:28:52 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 82 ],
      "url" : "http://t.co/G5VA1xnc",
      "expanded_url" : "http://opinionator.blogs.nytimes.com/2012/10/01/its-my-birthday-too-yeah/",
      "display_url" : "opinionator.blogs.nytimes.com/2012/10/01/its\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.6134836078, -122.3852177442 ]
  },
  "id_str" : "253332724641837057",
  "text" : "Remember these magic birthday in a crowd numbers: 23 and 253. http://t.co/G5VA1xnc",
  "id" : 253332724641837057,
  "created_at" : "2012-10-03 03:16:42 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://bufferapp.com\" rel=\"nofollow\">Buffer</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "glitchsnap",
      "indices" : [ 59, 70 ]
    } ],
    "urls" : [ {
      "indices" : [ 31, 51 ],
      "url" : "http://t.co/alwAoJis",
      "expanded_url" : "http://glitch.com",
      "display_url" : "glitch.com"
    }, {
      "indices" : [ 93, 113 ],
      "url" : "http://t.co/nnxYBV2v",
      "expanded_url" : "http://bit.ly/PMI6u4",
      "display_url" : "bit.ly/PMI6u4"
    } ]
  },
  "geo" : { },
  "id_str" : "253329590464942080",
  "text" : "I wish I had more time to play http://t.co/alwAoJis! These #glitchsnap tweets are beautiful: http://t.co/nnxYBV2v",
  "id" : 253329590464942080,
  "created_at" : "2012-10-03 03:04:15 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Cook",
      "screen_name" : "johnhcook",
      "indices" : [ 3, 13 ],
      "id_str" : "14326765",
      "id" : 14326765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 123, 136 ],
      "url" : "http://t.co/m",
      "expanded_url" : "https://twitter.com/download",
      "display_url" : "twitter.com/download"
    } ]
  },
  "geo" : { },
  "id_str" : "253323789956419584",
  "text" : "RT @johnhcook: Greg Linden's cool Code Monster project teaches kids to crunch Javascript, builds appetite for programming: http://t.co/m ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 108, 128 ],
        "url" : "http://t.co/m3IGlMQX",
        "expanded_url" : "http://www.geekwire.com/2012/code-monster-teaches-kids-crunch-javascript-whets-appetite/",
        "display_url" : "geekwire.com/2012/code-mons\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "253323398929866752",
    "text" : "Greg Linden's cool Code Monster project teaches kids to crunch Javascript, builds appetite for programming: http://t.co/m3IGlMQX",
    "id" : 253323398929866752,
    "created_at" : "2012-10-03 02:39:39 +0000",
    "user" : {
      "name" : "John Cook",
      "screen_name" : "johnhcook",
      "protected" : false,
      "id_str" : "14326765",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/403089484/john-headshot_normal.jpg",
      "id" : 14326765,
      "verified" : false
    }
  },
  "id" : 253323789956419584,
  "created_at" : "2012-10-03 02:41:12 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Judi",
      "screen_name" : "judidec",
      "indices" : [ 0, 8 ],
      "id_str" : "29344406",
      "id" : 29344406
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "253320158377037824",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.6132005736, -122.3849657687 ]
  },
  "id_str" : "253321404127268865",
  "in_reply_to_user_id" : 29344406,
  "text" : "@judidec You got me there. :)",
  "id" : 253321404127268865,
  "in_reply_to_status_id" : 253320158377037824,
  "created_at" : "2012-10-03 02:31:43 +0000",
  "in_reply_to_screen_name" : "judidec",
  "in_reply_to_user_id_str" : "29344406",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Judi",
      "screen_name" : "judidec",
      "indices" : [ 4, 12 ],
      "id_str" : "29344406",
      "id" : 29344406
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "253320158377037824",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.6130148063, -122.3848529241 ]
  },
  "id_str" : "253321348397559809",
  "in_reply_to_user_id" : 29344406,
  "text" : "Pay @judidec $1 for complaining about the SFO Alaska terminal.",
  "id" : 253321348397559809,
  "in_reply_to_status_id" : 253320158377037824,
  "created_at" : "2012-10-03 02:31:30 +0000",
  "in_reply_to_screen_name" : "judidec",
  "in_reply_to_user_id_str" : "29344406",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Miller",
      "screen_name" : "alexlmiller",
      "indices" : [ 3, 15 ],
      "id_str" : "16205746",
      "id" : 16205746
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "253320905453867011",
  "text" : "RT @alexlmiller: Took less than 12 hours after launch for someone to find a pretty incontrovertible piece of prior art on a MSFT patent  ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 119, 139 ],
        "url" : "http://t.co/Ame72zCS",
        "expanded_url" : "http://patents.stackexchange.com/a/199/15?stw=2",
        "display_url" : "patents.stackexchange.com/a/199/15?stw=2"
      } ]
    },
    "geo" : { },
    "id_str" : "249337740276142080",
    "text" : "Took less than 12 hours after launch for someone to find a pretty incontrovertible piece of prior art on a MSFT patent http://t.co/Ame72zCS",
    "id" : 249337740276142080,
    "created_at" : "2012-09-22 02:42:04 +0000",
    "user" : {
      "name" : "Alex Miller",
      "screen_name" : "alexlmiller",
      "protected" : false,
      "id_str" : "16205746",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1759276068/weemee_normal.jpg",
      "id" : 16205746,
      "verified" : false
    }
  },
  "id" : 253320905453867011,
  "created_at" : "2012-10-03 02:29:44 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anil Dash",
      "screen_name" : "anildash",
      "indices" : [ 99, 108 ],
      "id_str" : "36823",
      "id" : 36823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 93 ],
      "url" : "http://t.co/BLCByWO8",
      "expanded_url" : "http://m.digitaltrends.com/cool-tech/can-crowdsourcing-save-the-patent-system/",
      "display_url" : "m.digitaltrends.com/cool-tech/can-\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.6130168484, -122.3847588727 ]
  },
  "id_str" : "253320376233377792",
  "text" : "Help fight patents by crowdsourcing the discovery of prior art. Awesome! http://t.co/BLCByWO8 /via @anildash",
  "id" : 253320376233377792,
  "created_at" : "2012-10-03 02:27:38 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Jacobs",
      "screen_name" : "djacobs",
      "indices" : [ 10, 18 ],
      "id_str" : "774842",
      "id" : 774842
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "253308235598143488",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.615124793, -122.3849935456 ]
  },
  "id_str" : "253308753477242880",
  "in_reply_to_user_id" : 774842,
  "text" : "Pay $1 to @djacobs for complaining about \"stupid headaches\" (quotes prevent recursion of complaints payments)",
  "id" : 253308753477242880,
  "in_reply_to_status_id" : 253308235598143488,
  "created_at" : "2012-10-03 01:41:27 +0000",
  "in_reply_to_screen_name" : "djacobs",
  "in_reply_to_user_id_str" : "774842",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.6150762187, -122.3852238579 ]
  },
  "id_str" : "253307999186210816",
  "text" : "I am not enjoying this stupid headache. Who wants a dollar?",
  "id" : 253307999186210816,
  "created_at" : "2012-10-03 01:38:27 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Sippey",
      "screen_name" : "sippey",
      "indices" : [ 102, 109 ],
      "id_str" : "4711",
      "id" : 4711
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 96 ],
      "url" : "http://t.co/W4dm5ilq",
      "expanded_url" : "http://counternotions.com/2012/10/02/next-turn/",
      "display_url" : "counternotions.com/2012/10/02/nex\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.6175377379, -122.3866630812 ]
  },
  "id_str" : "253307062593925120",
  "text" : "And we expect our map-related blog posts to be poetic and slightly dizzying http://t.co/W4dm5ilq /via @sippey",
  "id" : 253307062593925120,
  "created_at" : "2012-10-03 01:34:44 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://bufferapp.com\" rel=\"nofollow\">Buffer</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tapessaysareawesome",
      "indices" : [ 101, 121 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 100 ],
      "url" : "http://t.co/woOSxCiu",
      "expanded_url" : "http://bit.ly/PMKUYr",
      "display_url" : "bit.ly/PMKUYr"
    } ]
  },
  "geo" : { },
  "id_str" : "253291110699524096",
  "text" : "Judging A Book By Its Lover, an inspring tap-essay for writers, by @laurentleto http://t.co/woOSxCiu #tapessaysareawesome",
  "id" : 253291110699524096,
  "created_at" : "2012-10-03 00:31:21 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robin Sloan",
      "screen_name" : "robinsloan",
      "indices" : [ 0, 11 ],
      "id_str" : "13919072",
      "id" : 13919072
    }, {
      "name" : "Lauren Leto",
      "screen_name" : "laurenleto",
      "indices" : [ 25, 36 ],
      "id_str" : "15510569",
      "id" : 15510569
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "253286670143717376",
  "geo" : { },
  "id_str" : "253289720954634240",
  "in_reply_to_user_id" : 13919072,
  "text" : "@robinsloan Love it. Hey @laurenleto Did you hand-code that or is there a cool way of making these that I don't know about?",
  "id" : 253289720954634240,
  "in_reply_to_status_id" : 253286670143717376,
  "created_at" : "2012-10-03 00:25:50 +0000",
  "in_reply_to_screen_name" : "robinsloan",
  "in_reply_to_user_id_str" : "13919072",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://bufferapp.com\" rel=\"nofollow\">Buffer</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rdio",
      "screen_name" : "Rdio",
      "indices" : [ 26, 31 ],
      "id_str" : "54205414",
      "id" : 54205414
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 120 ],
      "url" : "http://t.co/PzZN0u4d",
      "expanded_url" : "http://bit.ly/PMCxMr",
      "display_url" : "bit.ly/PMCxMr"
    } ]
  },
  "geo" : { },
  "id_str" : "253282024226426880",
  "text" : "Woah, this is pretty rad. @Rdio pays musicians $10 when they get fans to sign up for their service: http://t.co/PzZN0u4d",
  "id" : 253282024226426880,
  "created_at" : "2012-10-02 23:55:14 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Ellin",
      "screen_name" : "brianellin",
      "indices" : [ 4, 15 ],
      "id_str" : "26123649",
      "id" : 26123649
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 121 ],
      "url" : "http://t.co/2SpTmrpp",
      "expanded_url" : "http://4sq.com/Vda1cm",
      "display_url" : "4sq.com/Vda1cm"
    } ]
  },
  "geo" : { },
  "id_str" : "253257245574459392",
  "text" : "Pay @brianellin $7.50 for two days of delicious New Orleans style iced coffee (@ Blue Bottle Coffee) http://t.co/2SpTmrpp",
  "id" : 253257245574459392,
  "created_at" : "2012-10-02 22:16:47 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ali Berman",
      "screen_name" : "spangley",
      "indices" : [ 0, 9 ],
      "id_str" : "776429",
      "id" : 776429
    }, {
      "name" : "Niko Benson",
      "screen_name" : "nikobenson",
      "indices" : [ 15, 26 ],
      "id_str" : "142467448",
      "id" : 142467448
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "253225153515880448",
  "geo" : { },
  "id_str" : "253248096740442113",
  "in_reply_to_user_id" : 776429,
  "text" : "@spangley Woah @nikobenson didn't have that much hair til he was 18 months old! PS where is Henry's Twitter account???",
  "id" : 253248096740442113,
  "in_reply_to_status_id" : 253225153515880448,
  "created_at" : "2012-10-02 21:40:26 +0000",
  "in_reply_to_screen_name" : "spangley",
  "in_reply_to_user_id_str" : "776429",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Samuel Fine",
      "screen_name" : "samuelfine",
      "indices" : [ 0, 11 ],
      "id_str" : "200236063",
      "id" : 200236063
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "253165467911467010",
  "geo" : { },
  "id_str" : "253167273651609602",
  "in_reply_to_user_id" : 200236063,
  "text" : "@samuelfine I was told I couldn't say much about it other than what was already obvious from the videos sent out... but it was cool.",
  "id" : 253167273651609602,
  "in_reply_to_status_id" : 253165467911467010,
  "created_at" : "2012-10-02 16:19:16 +0000",
  "in_reply_to_screen_name" : "samuelfine",
  "in_reply_to_user_id_str" : "200236063",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "notveryhumblebrag",
      "indices" : [ 69, 87 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "253165265783754754",
  "text" : "I totally got to try out a Google Glasses prototype. It was awesome. #notveryhumblebrag",
  "id" : 253165265783754754,
  "created_at" : "2012-10-02 16:11:17 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7587849382, -122.2328904689 ]
  },
  "id_str" : "253138299164717057",
  "text" : "I could live in Alameda.",
  "id" : 253138299164717057,
  "created_at" : "2012-10-02 14:24:08 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ali Berman",
      "screen_name" : "spangley",
      "indices" : [ 0, 9 ],
      "id_str" : "776429",
      "id" : 776429
    }, {
      "name" : "Todd Berman",
      "screen_name" : "tberman",
      "indices" : [ 14, 22 ],
      "id_str" : "15275073",
      "id" : 15275073
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "253115301376438274",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7587878681, -122.2331816563 ]
  },
  "id_str" : "253132784837730304",
  "in_reply_to_user_id" : 776429,
  "text" : "@spangley and @tberman so excited for you guys and can't wait to meet Henry!",
  "id" : 253132784837730304,
  "in_reply_to_status_id" : 253115301376438274,
  "created_at" : "2012-10-02 14:02:13 +0000",
  "in_reply_to_screen_name" : "spangley",
  "in_reply_to_user_id_str" : "776429",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Cook",
      "screen_name" : "johnhcook",
      "indices" : [ 16, 26 ],
      "id_str" : "14326765",
      "id" : 14326765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 133 ],
      "url" : "http://t.co/LyCehhEQ",
      "expanded_url" : "http://www.geekwire.com/2012/police-scanner-twitter-generation-seattle-pd-intros-tweets-beat/",
      "display_url" : "geekwire.com/2012/police-sc\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.758774705, -122.2331682329 ]
  },
  "id_str" : "253009237804998657",
  "text" : "That's cool! RT @johnhcook: A police scanner for the Twitter generation: Seattle PD introduces 'Tweets by Beat': http://t.co/LyCehhEQ",
  "id" : 253009237804998657,
  "created_at" : "2012-10-02 05:51:17 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dog Solution",
      "screen_name" : "DogSolutions",
      "indices" : [ 3, 16 ],
      "id_str" : "40343143",
      "id" : 40343143
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "252996744613330944",
  "text" : "RT @DogSolutions: is say, art imimtate the life. but, does it imitate the doeg? or is dog the art? is theory for you to think. than kyou ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http://twitter.com/DogSolutions/status/252899955751124992/photo/1",
        "indices" : [ 119, 139 ],
        "url" : "http://t.co/zHWnbzHC",
        "media_url" : "http://pbs.twimg.com/media/A4J7K3rCAAAGl5g.jpg",
        "id_str" : "252899955759513600",
        "id" : 252899955759513600,
        "media_url_https" : "https://pbs.twimg.com/media/A4J7K3rCAAAGl5g.jpg",
        "sizes" : [ {
          "h" : 667,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 454,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 667,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 667,
          "resize" : "fit",
          "w" : 500
        } ],
        "display_url" : "pic.twitter.com/zHWnbzHC"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "252899955751124992",
    "text" : "is say, art imimtate the life. but, does it imitate the doeg? or is dog the art? is theory for you to think. than kyou http://t.co/zHWnbzHC",
    "id" : 252899955751124992,
    "created_at" : "2012-10-01 22:37:03 +0000",
    "user" : {
      "name" : "Dog Solution",
      "screen_name" : "DogSolutions",
      "protected" : false,
      "id_str" : "40343143",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2695779271/cc80ac251d84a5e9ef35a5e31020e31c_normal.png",
      "id" : 40343143,
      "verified" : false
    }
  },
  "id" : 252996744613330944,
  "created_at" : "2012-10-02 05:01:39 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glitch, the game",
      "screen_name" : "playglitch",
      "indices" : [ 0, 11 ],
      "id_str" : "103943240",
      "id" : 103943240
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "252949284851425281",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7587198327, -122.2331685574 ]
  },
  "id_str" : "252989574555516928",
  "in_reply_to_user_id" : 103943240,
  "text" : "@playglitch Awesome! Looks great!",
  "id" : 252989574555516928,
  "in_reply_to_status_id" : 252949284851425281,
  "created_at" : "2012-10-02 04:33:09 +0000",
  "in_reply_to_screen_name" : "playglitch",
  "in_reply_to_user_id_str" : "103943240",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Foursquare",
      "screen_name" : "foursquare",
      "indices" : [ 52, 63 ],
      "id_str" : "14120151",
      "id" : 14120151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http://t.co/7ZqlnqfD",
      "expanded_url" : "http://4sq.com/UD2b7d",
      "display_url" : "4sq.com/UD2b7d"
    } ]
  },
  "geo" : { },
  "id_str" : "252975825417285632",
  "text" : "I just reached Level 7 of the \"Hot Tamale\" badge on @foursquare. I\u2019ve checked in at 30 different Mexican Restaurants! http://t.co/7ZqlnqfD",
  "id" : 252975825417285632,
  "created_at" : "2012-10-02 03:38:31 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 77 ],
      "url" : "http://t.co/tOQ3B4j7",
      "expanded_url" : "http://instagr.am/p/QQ930Do0Ea/",
      "display_url" : "instagr.am/p/QQ930Do0Ea/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7651301793, -122.241805332 ]
  },
  "id_str" : "252975822045077504",
  "text" : "8:36pm Sharon and Ian! Lovely peoples.   @ La Penca Azul http://t.co/tOQ3B4j7",
  "id" : 252975822045077504,
  "created_at" : "2012-10-02 03:38:30 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glitch, the game",
      "screen_name" : "playglitch",
      "indices" : [ 0, 11 ],
      "id_str" : "103943240",
      "id" : 103943240
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "252919974522417152",
  "geo" : { },
  "id_str" : "252922511426207744",
  "in_reply_to_user_id" : 103943240,
  "text" : "@playglitch If it doesn't start working soon let me know... I sit close to a guy.",
  "id" : 252922511426207744,
  "in_reply_to_status_id" : 252919974522417152,
  "created_at" : "2012-10-02 00:06:40 +0000",
  "in_reply_to_screen_name" : "playglitch",
  "in_reply_to_user_id_str" : "103943240",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ali.",
      "screen_name" : "knockedup",
      "indices" : [ 0, 10 ],
      "id_str" : "518079559",
      "id" : 518079559
    }, {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 11, 21 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "252891419306508288",
  "geo" : { },
  "id_str" : "252896754792554496",
  "in_reply_to_user_id" : 518079559,
  "text" : "@knockedup @kellianne's water broke something like 15 hours before labor started. We watched a ton of Friday Night Lights in the meantime.",
  "id" : 252896754792554496,
  "in_reply_to_status_id" : 252891419306508288,
  "created_at" : "2012-10-01 22:24:19 +0000",
  "in_reply_to_screen_name" : "knockedup",
  "in_reply_to_user_id_str" : "518079559",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ali.",
      "screen_name" : "knockedup",
      "indices" : [ 0, 10 ],
      "id_str" : "518079559",
      "id" : 518079559
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "252891419306508288",
  "geo" : { },
  "id_str" : "252896168374317058",
  "in_reply_to_user_id" : 518079559,
  "text" : "@knockedup Exciting!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!",
  "id" : 252896168374317058,
  "in_reply_to_status_id" : 252891419306508288,
  "created_at" : "2012-10-01 22:21:59 +0000",
  "in_reply_to_screen_name" : "knockedup",
  "in_reply_to_user_id_str" : "518079559",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://bufferapp.com\" rel=\"nofollow\">Buffer</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chirpify",
      "screen_name" : "Chirpify",
      "indices" : [ 61, 70 ],
      "id_str" : "526548703",
      "id" : 526548703
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "252797933106368513",
  "text" : "Are there any charities on Twitter that accept donations via @chirpify? I need a way to pay when I'm complaining by myself. Which is often.",
  "id" : 252797933106368513,
  "created_at" : "2012-10-01 15:51:38 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "252792970988888064",
  "text" : "Wouldn't it be neat if when a plane landed there was a 30 second break for everyone without bags to make a mad dash off the plane?",
  "id" : 252792970988888064,
  "created_at" : "2012-10-01 15:31:55 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://bufferapp.com\" rel=\"nofollow\">Buffer</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "252783934084100097",
  "text" : "I've never really thought much about the ad biz but watching Twitter, Facebook, Tumblr, &amp; Foursquare all enter at once is kind of exciting.",
  "id" : 252783934084100097,
  "created_at" : "2012-10-01 14:56:01 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 37 ],
      "url" : "http://t.co/UK7v14EG",
      "expanded_url" : "http://instagr.am/p/QPeBUlo0AH/",
      "display_url" : "instagr.am/p/QPeBUlo0AH/"
    } ]
  },
  "geo" : { },
  "id_str" : "252765021879300096",
  "text" : "Mountain sunrise http://t.co/UK7v14EG",
  "id" : 252765021879300096,
  "created_at" : "2012-10-01 13:40:52 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Samuel Fine",
      "screen_name" : "samuelfine",
      "indices" : [ 0, 11 ],
      "id_str" : "200236063",
      "id" : 200236063
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "252741142708375552",
  "geo" : { },
  "id_str" : "252744026661474304",
  "in_reply_to_user_id" : 200236063,
  "text" : "@samuelfine Ha! Love that line! What a surreal show.",
  "id" : 252744026661474304,
  "in_reply_to_status_id" : 252741142708375552,
  "created_at" : "2012-10-01 12:17:26 +0000",
  "in_reply_to_screen_name" : "samuelfine",
  "in_reply_to_user_id_str" : "200236063",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "252740145118339072",
  "text" : "Rushing to the airport with the Wonder Pets theme song stuck in your head is hilarious. \"There's an animal in trouble... somewhere.\"",
  "id" : 252740145118339072,
  "created_at" : "2012-10-01 12:02:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "252732897872719873",
  "text" : "Good morning tweeter heads.",
  "id" : 252732897872719873,
  "created_at" : "2012-10-01 11:33:13 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
} ]