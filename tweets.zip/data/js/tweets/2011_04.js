Grailbird.data.tweets_2011_04 = 
 [ {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.772833, -122.435167 ]
  },
  "id_str" : "64545937602772992",
  "text" : "Ali&Todd wedding eve reunion http://flic.kr/p/9DsAKo",
  "id" : 64545937602772992,
  "created_at" : "Sun May 01 04:25:25 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Langley",
      "screen_name" : "splangley",
      "indices" : [ 11, 21 ],
      "id_str" : "226508839",
      "id" : 226508839
    }, {
      "name" : "Todd Berman",
      "screen_name" : "tberman",
      "indices" : [ 23, 31 ],
      "id_str" : "15275073",
      "id" : 15275073
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7917576551, -122.4105518582 ]
  },
  "id_str" : "64500555548065793",
  "text" : "Friends of @splangley, @tberman, and friends of friends all meeting at the Page at 8pm. Join us!",
  "id" : 64500555548065793,
  "created_at" : "Sun May 01 01:25:05 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan King",
      "screen_name" : "rk",
      "indices" : [ 0, 3 ],
      "id_str" : "19853",
      "id" : 19853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "64429715875831808",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.79010874, -122.40772098 ]
  },
  "id_str" : "64489133925609472",
  "in_reply_to_user_id" : 19853,
  "text" : "@rk Kellianne and I are in! Excited to see everyone! (Niko has a sitter...)",
  "id" : 64489133925609472,
  "in_reply_to_status_id" : 64429715875831808,
  "created_at" : "Sun May 01 00:39:42 +0000 2011",
  "in_reply_to_screen_name" : "rk",
  "in_reply_to_user_id_str" : "19853",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan McMinn",
      "screen_name" : "ryanmcminn",
      "indices" : [ 0, 11 ],
      "id_str" : "12061042",
      "id" : 12061042
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "64387219250626560",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.4420828282, -122.3002303355 ]
  },
  "id_str" : "64388927053770752",
  "in_reply_to_user_id" : 12061042,
  "text" : "@ryanmcminn Yes! You too?",
  "id" : 64388927053770752,
  "in_reply_to_status_id" : 64387219250626560,
  "created_at" : "Sat Apr 30 18:01:31 +0000 2011",
  "in_reply_to_screen_name" : "ryanmcminn",
  "in_reply_to_user_id_str" : "12061042",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.4439149, -122.3020195 ]
  },
  "id_str" : "64379198537596929",
  "text" : "SEA -&gt; SFO for Ali's wedding! &kb,nb,20:traveling (@ Seattle-Tacoma International Airport (SEA) w/ 31 others) http://4sq.com/jmDBcJ",
  "id" : 64379198537596929,
  "created_at" : "Sat Apr 30 17:22:51 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.605166, -122.322667 ]
  },
  "id_str" : "64172201947045888",
  "text" : "8:36pm Bed time walking test failed http://flic.kr/p/9D8qe6",
  "id" : 64172201947045888,
  "created_at" : "Sat Apr 30 03:40:19 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Wright",
      "screen_name" : "webwright",
      "indices" : [ 0, 10 ],
      "id_str" : "786818",
      "id" : 786818
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "64019141660647426",
  "geo" : {
  },
  "id_str" : "64019359152082944",
  "in_reply_to_user_id" : 786818,
  "text" : "@webwright You walked right into that one.",
  "id" : 64019359152082944,
  "in_reply_to_status_id" : 64019141660647426,
  "created_at" : "Fri Apr 29 17:32:59 +0000 2011",
  "in_reply_to_screen_name" : "webwright",
  "in_reply_to_user_id_str" : "786818",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ingopixel",
      "screen_name" : "ingopixel",
      "indices" : [ 53, 63 ],
      "id_str" : "7943892",
      "id" : 7943892
    }, {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 68, 78 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.615, -122.327834 ]
  },
  "id_str" : "63809651745112066",
  "text" : "8:36pm Hanging out at Macchiavelli's bar waiting for @ingopixel and @kellianne http://flic.kr/p/9CSNZw",
  "id" : 63809651745112066,
  "created_at" : "Fri Apr 29 03:39:41 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nerdgames",
      "indices" : [ 118, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6149556321, -122.3284505518 ]
  },
  "id_str" : "63808594071662592",
  "text" : "What's the shortest period of time that you can reload the Twitter iPhone app and get the jagged cut off chasm thing? #nerdgames",
  "id" : 63808594071662592,
  "created_at" : "Fri Apr 29 03:35:28 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Loving",
      "screen_name" : "adamloving",
      "indices" : [ 0, 11 ],
      "id_str" : "809641",
      "id" : 809641
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "63627232760954881",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6151652064, -122.3233776945 ]
  },
  "id_str" : "63772498629627904",
  "in_reply_to_user_id" : 809641,
  "text" : "@adamloving That sounds cool! Let me know how I can help.",
  "id" : 63772498629627904,
  "in_reply_to_status_id" : 63627232760954881,
  "created_at" : "Fri Apr 29 01:12:03 +0000 2011",
  "in_reply_to_screen_name" : "adamloving",
  "in_reply_to_user_id_str" : "809641",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keith Pickholz",
      "screen_name" : "keithpi",
      "indices" : [ 0, 8 ],
      "id_str" : "18089120",
      "id" : 18089120
    }, {
      "name" : "david reeves",
      "screen_name" : "dreeves",
      "indices" : [ 9, 17 ],
      "id_str" : "947851",
      "id" : 947851
    }, {
      "name" : "Marcelo Calbucci",
      "screen_name" : "calbucci",
      "indices" : [ 18, 27 ],
      "id_str" : "14232711",
      "id" : 14232711
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "63716218103799809",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6151791889, -122.3233587533 ]
  },
  "id_str" : "63772311123275776",
  "in_reply_to_user_id" : 18089120,
  "text" : "@keithpi @dreeves @calbucci Very cool! I'm a little doubtful that they'd actually do this though.",
  "id" : 63772311123275776,
  "in_reply_to_status_id" : 63716218103799809,
  "created_at" : "Fri Apr 29 01:11:18 +0000 2011",
  "in_reply_to_screen_name" : "keithpi",
  "in_reply_to_user_id_str" : "18089120",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martin Zych",
      "screen_name" : "martinzych",
      "indices" : [ 0, 11 ],
      "id_str" : "50417067",
      "id" : 50417067
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "63690363185004544",
  "geo" : {
  },
  "id_str" : "63731241219928064",
  "in_reply_to_user_id" : 50417067,
  "text" : "@martinzych You too, Martin! Thanks for coming out. Hope to see you at the next one?",
  "id" : 63731241219928064,
  "in_reply_to_status_id" : 63690363185004544,
  "created_at" : "Thu Apr 28 22:28:06 +0000 2011",
  "in_reply_to_screen_name" : "martinzych",
  "in_reply_to_user_id_str" : "50417067",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 3, 13 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "63483842190778368",
  "text" : "RT @kellianne: Hot walker action. http://flic.kr/p/9CqGJU",
  "retweeted_status" : {
    "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "63401748534005760",
    "text" : "Hot walker action. http://flic.kr/p/9CqGJU",
    "id" : 63401748534005760,
    "created_at" : "Thu Apr 28 00:38:49 +0000 2011",
    "user" : {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "protected" : false,
      "id_str" : "7362142",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3058433557/056b99ecb9df9b6b9b382b2470b6ee82_normal.jpeg",
      "id" : 7362142,
      "verified" : false
    }
  },
  "id" : 63483842190778368,
  "created_at" : "Thu Apr 28 06:05:02 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcelo Calbucci",
      "screen_name" : "calbucci",
      "indices" : [ 0, 9 ],
      "id_str" : "14232711",
      "id" : 14232711
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "63460944776400896",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6051773224, -122.3223498465 ]
  },
  "id_str" : "63482784437649408",
  "in_reply_to_user_id" : 14232711,
  "text" : "@calbucci Great finally meeting you. Thanks for speaking too!",
  "id" : 63482784437649408,
  "in_reply_to_status_id" : 63460944776400896,
  "created_at" : "Thu Apr 28 06:00:49 +0000 2011",
  "in_reply_to_screen_name" : "calbucci",
  "in_reply_to_user_id_str" : "14232711",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "QuantifiedSelf",
      "indices" : [ 7, 22 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.614666, -122.343834 ]
  },
  "id_str" : "63460728253841408",
  "text" : "8:36pm #QuantifiedSelf meetup in the house http://flic.kr/p/9CqqJc",
  "id" : 63460728253841408,
  "created_at" : "Thu Apr 28 04:33:11 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "quantifiedself",
      "screen_name" : "quantifiedself",
      "indices" : [ 26, 41 ],
      "id_str" : "35056570",
      "id" : 35056570
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "quantifieddrinks",
      "indices" : [ 111, 128 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 110 ],
      "url" : "http://t.co/z464HE0",
      "expanded_url" : "http://www.meetup.com/Quantified-Self-Seattle/events/17112808/",
      "display_url" : "meetup.com/Quantified-Sel\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "63381481183129600",
  "text" : "Come thirsty to tonight's @QuantifiedSelf meetup... we have double the drink tab to cover! http://t.co/z464HE0 #quantifieddrinks",
  "id" : 63381481183129600,
  "created_at" : "Wed Apr 27 23:18:17 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6051666177, -122.3224586068 ]
  },
  "id_str" : "63098480310226944",
  "text" : "The fatal flaw of intelligence is that no matter how smart you are you can rationalize why everyone else is stupider than you.",
  "id" : 63098480310226944,
  "created_at" : "Wed Apr 27 04:33:44 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.605, -122.322834 ]
  },
  "id_str" : "63095208996372480",
  "text" : "8:36pm More bathtime hide and seek http://flic.kr/p/9C8Szk",
  "id" : 63095208996372480,
  "created_at" : "Wed Apr 27 04:20:44 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "foursquare API",
      "screen_name" : "foursquareAPI",
      "indices" : [ 0, 14 ],
      "id_str" : "45598477",
      "id" : 45598477
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "63015678352961536",
  "geo" : {
  },
  "id_str" : "63017655954714624",
  "in_reply_to_user_id" : 45598477,
  "text" : "@foursquareapi That's awesome! Any idea on how often the category tree changes/gets updated?",
  "id" : 63017655954714624,
  "in_reply_to_status_id" : 63015678352961536,
  "created_at" : "Tue Apr 26 23:12:34 +0000 2011",
  "in_reply_to_screen_name" : "foursquareAPI",
  "in_reply_to_user_id_str" : "45598477",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "quantifiedself",
      "screen_name" : "quantifiedself",
      "indices" : [ 29, 44 ],
      "id_str" : "35056570",
      "id" : 35056570
    }, {
      "name" : "david reeves",
      "screen_name" : "dreeves",
      "indices" : [ 117, 125 ],
      "id_str" : "947851",
      "id" : 947851
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 112 ],
      "url" : "http://t.co/z464HE0",
      "expanded_url" : "http://www.meetup.com/Quantified-Self-Seattle/events/17112808/",
      "display_url" : "meetup.com/Quantified-Sel\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "62960187635548160",
  "text" : "Come to our 2nd ever Seattle @QuantifiedSelf meetup tomorrow at Spitfire at 6pm. Learn more! http://t.co/z464HE0 /cc @dreeves",
  "id" : 62960187635548160,
  "created_at" : "Tue Apr 26 19:24:13 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Wright",
      "screen_name" : "webwright",
      "indices" : [ 0, 10 ],
      "id_str" : "786818",
      "id" : 786818
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "62940243808100354",
  "geo" : {
  },
  "id_str" : "62940900426387456",
  "in_reply_to_user_id" : 786818,
  "text" : "@webwright I'm in too! Now, how do you retrain an old brain that is addicted to pattern recognition?",
  "id" : 62940900426387456,
  "in_reply_to_status_id" : 62940243808100354,
  "created_at" : "Tue Apr 26 18:07:34 +0000 2011",
  "in_reply_to_screen_name" : "webwright",
  "in_reply_to_user_id_str" : "786818",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Visnu Pitiyanuvath",
      "screen_name" : "visnup",
      "indices" : [ 0, 7 ],
      "id_str" : "6121912",
      "id" : 6121912
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "62931697318117376",
  "geo" : {
  },
  "id_str" : "62935627888472064",
  "in_reply_to_user_id" : 6121912,
  "text" : "@visnup And on the other hand, the edge moves so quickly that by the time you build for your time it's day is over. :)",
  "id" : 62935627888472064,
  "in_reply_to_status_id" : 62931697318117376,
  "created_at" : "Tue Apr 26 17:46:37 +0000 2011",
  "in_reply_to_screen_name" : "visnup",
  "in_reply_to_user_id_str" : "6121912",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Wright",
      "screen_name" : "webwright",
      "indices" : [ 0, 10 ],
      "id_str" : "786818",
      "id" : 786818
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "62922328731947009",
  "geo" : {
  },
  "id_str" : "62934405731201024",
  "in_reply_to_user_id" : 786818,
  "text" : "@webwright We don't buy based on actual value but on how far the price is from what we are used to for paying for similar things.",
  "id" : 62934405731201024,
  "in_reply_to_status_id" : 62922328731947009,
  "created_at" : "Tue Apr 26 17:41:46 +0000 2011",
  "in_reply_to_screen_name" : "webwright",
  "in_reply_to_user_id_str" : "786818",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Wright",
      "screen_name" : "webwright",
      "indices" : [ 0, 10 ],
      "id_str" : "786818",
      "id" : 786818
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "62929885714329601",
  "geo" : {
  },
  "id_str" : "62932074373464065",
  "in_reply_to_user_id" : 786818,
  "text" : "@webwright Well I definitely don't want to be behind the times. :) So maybe I should aim for ahead of time with the goal of being with it?",
  "id" : 62932074373464065,
  "in_reply_to_status_id" : 62929885714329601,
  "created_at" : "Tue Apr 26 17:32:30 +0000 2011",
  "in_reply_to_screen_name" : "webwright",
  "in_reply_to_user_id_str" : "786818",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://timely.is\" rel=\"nofollow\">Timely by Demandforce</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "62929483384107008",
  "text" : "I'd rather be with my time than ahead of my time.",
  "id" : 62929483384107008,
  "created_at" : "Tue Apr 26 17:22:12 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://fivethings.me\" rel=\"nofollow\">Fivethings.Me</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thor Muller",
      "screen_name" : "tempo",
      "indices" : [ 13, 19 ],
      "id_str" : "5814",
      "id" : 5814
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "62752836198473728",
  "text" : "Recruited by @tempo to join Thor's Entourage! (Real life BFF). Sad to miss his bday extravaganza... have fun! http://5ts.me/hR5eg3",
  "id" : 62752836198473728,
  "created_at" : "Tue Apr 26 05:40:16 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.605333, -122.3225 ]
  },
  "id_str" : "62729595283181568",
  "text" : "8:36pm We opened the expensive bottle for no reason. Well there's always a reason. http://flic.kr/p/9BRnv7",
  "id" : 62729595283181568,
  "created_at" : "Tue Apr 26 04:07:55 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joel Longtine",
      "screen_name" : "jlongtine",
      "indices" : [ 0, 10 ],
      "id_str" : "722793",
      "id" : 722793
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "62710447337517056",
  "geo" : {
  },
  "id_str" : "62710877631168512",
  "in_reply_to_user_id" : 722793,
  "text" : "@jlongtine Ha. That's what I thought... but yes the data vis and ZQ sleep score are worth it if you like that kinda thing.",
  "id" : 62710877631168512,
  "in_reply_to_status_id" : 62710447337517056,
  "created_at" : "Tue Apr 26 02:53:32 +0000 2011",
  "in_reply_to_screen_name" : "jlongtine",
  "in_reply_to_user_id_str" : "722793",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joel Longtine",
      "screen_name" : "jlongtine",
      "indices" : [ 0, 10 ],
      "id_str" : "722793",
      "id" : 722793
    }, {
      "name" : "Zeo",
      "screen_name" : "Zeo",
      "indices" : [ 22, 26 ],
      "id_str" : "43127252",
      "id" : 43127252
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "62709516671778816",
  "geo" : {
  },
  "id_str" : "62709687728087040",
  "in_reply_to_user_id" : 722793,
  "text" : "@jlongtine I love the @zeo! Had some connectivity issues but was pushing the 30-ft limit...",
  "id" : 62709687728087040,
  "in_reply_to_status_id" : 62709516671778816,
  "created_at" : "Tue Apr 26 02:48:49 +0000 2011",
  "in_reply_to_screen_name" : "jlongtine",
  "in_reply_to_user_id_str" : "722793",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "harryh",
      "screen_name" : "harryh",
      "indices" : [ 0, 7 ],
      "id_str" : "4558",
      "id" : 4558
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "62693992923529217",
  "geo" : {
  },
  "id_str" : "62694137840943104",
  "in_reply_to_user_id" : 4558,
  "text" : "@harryh I'd rather say quarter to B.  :)",
  "id" : 62694137840943104,
  "in_reply_to_status_id" : 62693992923529217,
  "created_at" : "Tue Apr 26 01:47:01 +0000 2011",
  "in_reply_to_screen_name" : "harryh",
  "in_reply_to_user_id_str" : "4558",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "harryh",
      "screen_name" : "harryh",
      "indices" : [ 0, 7 ],
      "id_str" : "4558",
      "id" : 4558
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "62693157170712576",
  "geo" : {
  },
  "id_str" : "62693732901855232",
  "in_reply_to_user_id" : 4558,
  "text" : "@harryh Seems like a harder sell since we'll then have to ask \"with or without time zones?\" which is what we're trying to avoid.",
  "id" : 62693732901855232,
  "in_reply_to_status_id" : 62693157170712576,
  "created_at" : "Tue Apr 26 01:45:25 +0000 2011",
  "in_reply_to_screen_name" : "harryh",
  "in_reply_to_user_id_str" : "4558",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "harryh",
      "screen_name" : "harryh",
      "indices" : [ 0, 7 ],
      "id_str" : "4558",
      "id" : 4558
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "62691232001953792",
  "geo" : {
  },
  "id_str" : "62692855096942592",
  "in_reply_to_user_id" : 4558,
  "text" : "@harryh I like the idea. What can we do to start? Invent a new clock (A-X?) and start making watches that you can't change?",
  "id" : 62692855096942592,
  "in_reply_to_status_id" : 62691232001953792,
  "created_at" : "Tue Apr 26 01:41:56 +0000 2011",
  "in_reply_to_screen_name" : "harryh",
  "in_reply_to_user_id_str" : "4558",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benny Wong",
      "screen_name" : "bdotdub",
      "indices" : [ 0, 8 ],
      "id_str" : "3032241",
      "id" : 3032241
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "62559072750272512",
  "geo" : {
  },
  "id_str" : "62590504210145280",
  "in_reply_to_user_id" : 3032241,
  "text" : "@bdotdub I did, but I was on my phone. I'll try again soon! Looks very cool.",
  "id" : 62590504210145280,
  "in_reply_to_status_id" : 62559072750272512,
  "created_at" : "Mon Apr 25 18:55:13 +0000 2011",
  "in_reply_to_screen_name" : "bdotdub",
  "in_reply_to_user_id_str" : "3032241",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ArielMeadowStallings",
      "screen_name" : "OffbeatAriel",
      "indices" : [ 0, 13 ],
      "id_str" : "14095370",
      "id" : 14095370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "62554607800426498",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6050462971, -122.3223851143 ]
  },
  "id_str" : "62556299191263234",
  "in_reply_to_user_id" : 14095370,
  "text" : "@OffbeatAriel So that's how the fashion industry stays in business!",
  "id" : 62556299191263234,
  "in_reply_to_status_id" : 62554607800426498,
  "created_at" : "Mon Apr 25 16:39:18 +0000 2011",
  "in_reply_to_screen_name" : "OffbeatAriel",
  "in_reply_to_user_id_str" : "14095370",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Rainert",
      "screen_name" : "arainert",
      "indices" : [ 0, 9 ],
      "id_str" : "7482",
      "id" : 7482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "62301239173595136",
  "geo" : {
  },
  "id_str" : "62303583265234945",
  "in_reply_to_user_id" : 7482,
  "text" : "@arainert Sweet! So I'll build around it and turn it on as soon as it's available!",
  "id" : 62303583265234945,
  "in_reply_to_status_id" : 62301239173595136,
  "created_at" : "Sun Apr 24 23:55:06 +0000 2011",
  "in_reply_to_screen_name" : "arainert",
  "in_reply_to_user_id_str" : "7482",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dennis Crowley",
      "screen_name" : "dens",
      "indices" : [ 0, 5 ],
      "id_str" : "418",
      "id" : 418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "62272934328270848",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6146371241, -122.3199595336 ]
  },
  "id_str" : "62273645711605761",
  "in_reply_to_user_id" : 418,
  "text" : "@dens I'd like to include 4sq in the sentence: \"Share this w/ your Facebook, Twitter, and Foursquare friends.\" Esp when location's involved.",
  "id" : 62273645711605761,
  "in_reply_to_status_id" : 62272934328270848,
  "created_at" : "Sun Apr 24 21:56:08 +0000 2011",
  "in_reply_to_screen_name" : "dens",
  "in_reply_to_user_id_str" : "418",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Foursquare",
      "screen_name" : "foursquare",
      "indices" : [ 3, 14 ],
      "id_str" : "14120151",
      "id" : 14120151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "62269674007695362",
  "text" : "My @Foursquare wish of the day: urls in checkins were clickable http://flic.kr/p/9Bkace",
  "id" : 62269674007695362,
  "created_at" : "Sun Apr 24 21:40:21 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Todd Berman",
      "screen_name" : "tberman",
      "indices" : [ 0, 8 ],
      "id_str" : "15275073",
      "id" : 15275073
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "61998570701733888",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6140397333, -122.3191544258 ]
  },
  "id_str" : "61998722074157056",
  "in_reply_to_user_id" : 15275073,
  "text" : "@tberman For suuuuuure!",
  "id" : 61998722074157056,
  "in_reply_to_status_id" : 61998570701733888,
  "created_at" : "Sun Apr 24 03:43:41 +0000 2011",
  "in_reply_to_screen_name" : "tberman",
  "in_reply_to_user_id_str" : "15275073",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.614, -122.319167 ]
  },
  "id_str" : "61997782533283840",
  "text" : "8:36pm Out and about with a happy wife and a whining baby http://flic.kr/p/9B65MK",
  "id" : 61997782533283840,
  "created_at" : "Sun Apr 24 03:39:57 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Support",
      "screen_name" : "Support",
      "indices" : [ 53, 61 ],
      "id_str" : "17874544",
      "id" : 17874544
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.605166, -122.322667 ]
  },
  "id_str" : "61635335985176576",
  "text" : "8:36pm Waiting anxiously on the results of a Twitter @Support ticket http://flic.kr/p/9AP3p2",
  "id" : 61635335985176576,
  "created_at" : "Sat Apr 23 03:39:43 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Durand",
      "screen_name" : "everydaydude",
      "indices" : [ 0, 13 ],
      "id_str" : "14715999",
      "id" : 14715999
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "61560614182596608",
  "in_reply_to_user_id" : 14715999,
  "text" : "@everydaydude I got an email from you/Twitter Support regarding ticket #1720751 but the link is broken. Replied by email... hope that works!",
  "id" : 61560614182596608,
  "created_at" : "Fri Apr 22 22:42:48 +0000 2011",
  "in_reply_to_screen_name" : "everydaydude",
  "in_reply_to_user_id_str" : "14715999",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alex van buren",
      "screen_name" : "alexvanburen",
      "indices" : [ 29, 42 ],
      "id_str" : "137168767",
      "id" : 137168767
    }, {
      "name" : "micah craig",
      "screen_name" : "micahcraig",
      "indices" : [ 53, 64 ],
      "id_str" : "6462772",
      "id" : 6462772
    }, {
      "name" : "socialworkout",
      "screen_name" : "socialworkout",
      "indices" : [ 68, 82 ],
      "id_str" : "17006221",
      "id" : 17006221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 137 ],
      "url" : "http://t.co/elFVaTa",
      "expanded_url" : "http://bit.ly/h5pEc5",
      "display_url" : "bit.ly/h5pEc5"
    } ]
  },
  "geo" : {
  },
  "id_str" : "61469184751706112",
  "text" : "Awesome! Good work, guys! RT @alexvanburen: Congrats @micahcraig RT @socialworkout Big news! We've got a mobile site! http://t.co/elFVaTa",
  "id" : 61469184751706112,
  "created_at" : "Fri Apr 22 16:39:30 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Foursquare",
      "screen_name" : "foursquare",
      "indices" : [ 4, 15 ],
      "id_str" : "14120151",
      "id" : 14120151
    }, {
      "name" : "Alex Rainert",
      "screen_name" : "arainert",
      "indices" : [ 92, 101 ],
      "id_str" : "7482",
      "id" : 7482
    }, {
      "name" : "harryh",
      "screen_name" : "harryh",
      "indices" : [ 102, 109 ],
      "id_str" : "4558",
      "id" : 4558
    }, {
      "name" : "Dennis Crowley",
      "screen_name" : "dens",
      "indices" : [ 110, 115 ],
      "id_str" : "418",
      "id" : 418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "61464999146688514",
  "text" : "Hey @foursquare, any plans to offer ways to subscribe to a user's checkins via the API? /cc @arainert @harryh @dens",
  "id" : 61464999146688514,
  "created_at" : "Fri Apr 22 16:22:52 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.605166, -122.3225 ]
  },
  "id_str" : "61272653897539584",
  "text" : "8:36pm Old new rug didn't work. New new rug does! http://flic.kr/p/9AB9d3",
  "id" : 61272653897539584,
  "created_at" : "Fri Apr 22 03:38:33 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Sharpe",
      "screen_name" : "bsharpe",
      "indices" : [ 3, 11 ],
      "id_str" : "4041701",
      "id" : 4041701
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "61122326699319296",
  "text" : "RT @bsharpe: 4/21/2011 - EC2 becomes sentient, takes down human sites...    Join the resistance!",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "61121770920480768",
    "text" : "4/21/2011 - EC2 becomes sentient, takes down human sites...    Join the resistance!",
    "id" : 61121770920480768,
    "created_at" : "Thu Apr 21 17:39:00 +0000 2011",
    "user" : {
      "name" : "Ben Sharpe",
      "screen_name" : "bsharpe",
      "protected" : false,
      "id_str" : "4041701",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2606225905/lg28h4orn8pu7bzlm3g4_normal.jpeg",
      "id" : 4041701,
      "verified" : false
    }
  },
  "id" : 61122326699319296,
  "created_at" : "Thu Apr 21 17:41:12 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay Rishel",
      "screen_name" : "jrishel",
      "indices" : [ 0, 8 ],
      "id_str" : "2849211",
      "id" : 2849211
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "61091411394695168",
  "geo" : {
  },
  "id_str" : "61093141855477760",
  "in_reply_to_user_id" : 2849211,
  "text" : "@jrishel Still investigating the slowness. Amazon's servers are down today, might be related.",
  "id" : 61093141855477760,
  "in_reply_to_status_id" : 61091411394695168,
  "created_at" : "Thu Apr 21 15:45:14 +0000 2011",
  "in_reply_to_screen_name" : "jrishel",
  "in_reply_to_user_id_str" : "2849211",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Haughey",
      "screen_name" : "mathowie",
      "indices" : [ 37, 46 ],
      "id_str" : "761975",
      "id" : 761975
    }, {
      "name" : "Evan Williams",
      "screen_name" : "ev",
      "indices" : [ 52, 55 ],
      "id_str" : "20",
      "id" : 20
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 121 ],
      "url" : "http://t.co/2PXd6zh",
      "expanded_url" : "http://goo.gl/Hqdvp",
      "display_url" : "goo.gl/Hqdvp"
    } ]
  },
  "geo" : {
  },
  "id_str" : "60917434604990464",
  "text" : "Thanks for the balanced perspective, @mathowie, re: @ev not necessarily being some sort of mega-jerk: http://t.co/2PXd6zh I believe you.",
  "id" : 60917434604990464,
  "created_at" : "Thu Apr 21 04:07:02 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.605, -122.322834 ]
  },
  "id_str" : "60910708405186560",
  "text" : "8:36pm Wrangling pjs on a crazy wiggler http://flic.kr/p/9Aj9jH",
  "id" : 60910708405186560,
  "created_at" : "Thu Apr 21 03:40:19 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kris Howard",
      "screen_name" : "web_goddess",
      "indices" : [ 0, 12 ],
      "id_str" : "1391351",
      "id" : 1391351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "60819766503415809",
  "geo" : {
  },
  "id_str" : "60826548688789504",
  "in_reply_to_user_id" : 1391351,
  "text" : "@web_goddess Still happening? Send me your username and the url that is crashing and I'll look into it!",
  "id" : 60826548688789504,
  "in_reply_to_status_id" : 60819766503415809,
  "created_at" : "Wed Apr 20 22:05:53 +0000 2011",
  "in_reply_to_screen_name" : "web_goddess",
  "in_reply_to_user_id_str" : "1391351",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Manoogian III",
      "screen_name" : "jm3",
      "indices" : [ 0, 4 ],
      "id_str" : "59593",
      "id" : 59593
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "60602794176032768",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6050753035, -122.3225937705 ]
  },
  "id_str" : "60603059105042432",
  "in_reply_to_user_id" : 59593,
  "text" : "@jm3 did you do the trustee service thing? How quickly did it go through?",
  "id" : 60603059105042432,
  "in_reply_to_status_id" : 60602794176032768,
  "created_at" : "Wed Apr 20 07:17:49 +0000 2011",
  "in_reply_to_screen_name" : "jm3",
  "in_reply_to_user_id_str" : "59593",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dustin curtis",
      "screen_name" : "dcurtis",
      "indices" : [ 3, 11 ],
      "id_str" : "9395832",
      "id" : 9395832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "60569036542574592",
  "text" : "RT @dcurtis: Apple has $60,000,000,000 in cash.\n\nThat's 4.7 Netflixes, 1.5 News Corps, 1,463 Colors, or 45.5 NYTs. Or 2 Lattes for every ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "60467483433373696",
    "text" : "Apple has $60,000,000,000 in cash.\n\nThat's 4.7 Netflixes, 1.5 News Corps, 1,463 Colors, or 45.5 NYTs. Or 2 Lattes for every person on Earth.",
    "id" : 60467483433373696,
    "created_at" : "Tue Apr 19 22:19:06 +0000 2011",
    "user" : {
      "name" : "dustin curtis",
      "screen_name" : "dcurtis",
      "protected" : false,
      "id_str" : "9395832",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3586312198/4f90d52a9416842731420c9e3cb1ec9f_normal.png",
      "id" : 9395832,
      "verified" : false
    }
  },
  "id" : 60569036542574592,
  "created_at" : "Wed Apr 20 05:02:38 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ali Berman",
      "screen_name" : "spangley",
      "indices" : [ 0, 9 ],
      "id_str" : "776429",
      "id" : 776429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "60564303610249218",
  "geo" : {
  },
  "id_str" : "60564400066662400",
  "in_reply_to_user_id" : 776429,
  "text" : "@spangley Good to know! I just did the Trustee service thing too... crossing my fingers!",
  "id" : 60564400066662400,
  "in_reply_to_status_id" : 60564303610249218,
  "created_at" : "Wed Apr 20 04:44:12 +0000 2011",
  "in_reply_to_screen_name" : "spangley",
  "in_reply_to_user_id_str" : "776429",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ali Berman",
      "screen_name" : "spangley",
      "indices" : [ 0, 9 ],
      "id_str" : "776429",
      "id" : 776429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "60563480809455616",
  "geo" : {
  },
  "id_str" : "60563905935704065",
  "in_reply_to_user_id" : 776429,
  "text" : "@spangley Awesome, so that worked? How long did it take to go through?",
  "id" : 60563905935704065,
  "in_reply_to_status_id" : 60563480809455616,
  "created_at" : "Wed Apr 20 04:42:15 +0000 2011",
  "in_reply_to_screen_name" : "spangley",
  "in_reply_to_user_id_str" : "776429",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Bragger",
      "screen_name" : "kylebragger",
      "indices" : [ 0, 12 ],
      "id_str" : "2039761",
      "id" : 2039761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "60555116050264066",
  "geo" : {
  },
  "id_str" : "60555445101801472",
  "in_reply_to_user_id" : 2039761,
  "text" : "@kylebragger Did you ever use their Trustee service? I tried contacting them once with questions and they never got back.",
  "id" : 60555445101801472,
  "in_reply_to_status_id" : 60555116050264066,
  "created_at" : "Wed Apr 20 04:08:37 +0000 2011",
  "in_reply_to_screen_name" : "kylebragger",
  "in_reply_to_user_id_str" : "2039761",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "60553439461117952",
  "text" : "What's the best way to buy domains from other countries that require residence? Anyone have success with 101domain.com?",
  "id" : 60553439461117952,
  "created_at" : "Wed Apr 20 04:00:39 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u026F\u0250\u0265\u0183u\u0131uun\u0254 uo\u026F\u0131s",
      "screen_name" : "simoncunningham",
      "indices" : [ 0, 16 ],
      "id_str" : "40052194",
      "id" : 40052194
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "60531193921282049",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6049939179, -122.3229426143 ]
  },
  "id_str" : "60551623512043521",
  "in_reply_to_user_id" : 40052194,
  "text" : "@simoncunningham That was awesome! Thanks for saying hi. How did you find 750?",
  "id" : 60551623512043521,
  "in_reply_to_status_id" : 60531193921282049,
  "created_at" : "Wed Apr 20 03:53:26 +0000 2011",
  "in_reply_to_screen_name" : "simoncunningham",
  "in_reply_to_user_id_str" : "40052194",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.605, -122.322834 ]
  },
  "id_str" : "60551378489184256",
  "text" : "Hide and seek http://flic.kr/p/9A7wH7",
  "id" : 60551378489184256,
  "created_at" : "Wed Apr 20 03:52:28 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.605, -122.322834 ]
  },
  "id_str" : "60551355303067648",
  "text" : "Hide and seek http://flic.kr/p/9A4yjX",
  "id" : 60551355303067648,
  "created_at" : "Wed Apr 20 03:52:22 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.605, -122.322834 ]
  },
  "id_str" : "60551332054056961",
  "text" : "Hide and seek http://flic.kr/p/9A7wA5",
  "id" : 60551332054056961,
  "created_at" : "Wed Apr 20 03:52:17 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "girl jo",
      "screen_name" : "octavekitten",
      "indices" : [ 0, 13 ],
      "id_str" : "16366882",
      "id" : 16366882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "60549333250084864",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6050717507, -122.322850986 ]
  },
  "id_str" : "60551331164864512",
  "in_reply_to_user_id" : 16366882,
  "text" : "@octavekitten Thank you! I almost broke my neck taking it!",
  "id" : 60551331164864512,
  "in_reply_to_status_id" : 60549333250084864,
  "created_at" : "Wed Apr 20 03:52:16 +0000 2011",
  "in_reply_to_screen_name" : "octavekitten",
  "in_reply_to_user_id_str" : "16366882",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.605, -122.323 ]
  },
  "id_str" : "60551308515614720",
  "text" : "Hide and seek http://flic.kr/p/9A7wx1",
  "id" : 60551308515614720,
  "created_at" : "Wed Apr 20 03:52:11 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.605, -122.323 ]
  },
  "id_str" : "60548560327933953",
  "text" : "8:36pm Bathtime with the hide-and-seek master http://flic.kr/p/9A4rxi",
  "id" : 60548560327933953,
  "created_at" : "Wed Apr 20 03:41:16 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OkCupid",
      "screen_name" : "okcupid",
      "indices" : [ 66, 74 ],
      "id_str" : "53543144",
      "id" : 53543144
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 95 ],
      "url" : "http://t.co/Ivakhi2",
      "expanded_url" : "http://blog.okcupid.com/index.php/10-charts-about-sex/",
      "display_url" : "blog.okcupid.com/index.php/10-c\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6158682357, -122.3239268867 ]
  },
  "id_str" : "60401271630331904",
  "text" : "Another awesome post full of charts and funny/informative data by @okcupid: http://t.co/Ivakhi2",
  "id" : 60401271630331904,
  "created_at" : "Tue Apr 19 17:56:00 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "60391905388797952",
  "text" : "I can't believe Groupon bought Whrrl.",
  "id" : 60391905388797952,
  "created_at" : "Tue Apr 19 17:18:46 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u24D5\u24E3",
      "screen_name" : "folktrash",
      "indices" : [ 0, 10 ],
      "id_str" : "15265271",
      "id" : 15265271
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "60390119382851584",
  "geo" : {
  },
  "id_str" : "60390378662133760",
  "in_reply_to_user_id" : 15265271,
  "text" : "@folktrash I'm in First Hill. Myself or Kellianne will be here all day tomorrow. I'll dm you my number.",
  "id" : 60390378662133760,
  "in_reply_to_status_id" : 60390119382851584,
  "created_at" : "Tue Apr 19 17:12:42 +0000 2011",
  "in_reply_to_screen_name" : "folktrash",
  "in_reply_to_user_id_str" : "15265271",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u24D5\u24E3",
      "screen_name" : "folktrash",
      "indices" : [ 0, 10 ],
      "id_str" : "15265271",
      "id" : 15265271
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "60389447765729280",
  "geo" : {
  },
  "id_str" : "60389854407700480",
  "in_reply_to_user_id" : 15265271,
  "text" : "@folktrash Can you come pick it up and can we maybe have it back in 5 years? If so, it's yours!",
  "id" : 60389854407700480,
  "in_reply_to_status_id" : 60389447765729280,
  "created_at" : "Tue Apr 19 17:10:37 +0000 2011",
  "in_reply_to_screen_name" : "folktrash",
  "in_reply_to_user_id_str" : "15265271",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 88, 91 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.605166, -122.3225 ]
  },
  "id_str" : "60389122937864192",
  "text" : "Anyone in Seattle want to buy/borrow this table, recently nicknamed baby brain smasher? #fb http://flic.kr/p/9zVBWa",
  "id" : 60389122937864192,
  "created_at" : "Tue Apr 19 17:07:43 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "harryh",
      "screen_name" : "harryh",
      "indices" : [ 3, 10 ],
      "id_str" : "4558",
      "id" : 4558
    }, {
      "name" : "DHH",
      "screen_name" : "dhh",
      "indices" : [ 12, 16 ],
      "id_str" : "14561327",
      "id" : 14561327
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "60388879122956289",
  "text" : "RT @harryh: @dhh In fact, no one really aims for FB level success.  Those that get there just keep succeeding over and over.",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "DHH",
        "screen_name" : "dhh",
        "indices" : [ 0, 4 ],
        "id_str" : "14561327",
        "id" : 14561327
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "60277465947443200",
    "geo" : {
    },
    "id_str" : "60387693720379393",
    "in_reply_to_user_id" : 14561327,
    "text" : "@dhh In fact, no one really aims for FB level success.  Those that get there just keep succeeding over and over.",
    "id" : 60387693720379393,
    "in_reply_to_status_id" : 60277465947443200,
    "created_at" : "Tue Apr 19 17:02:02 +0000 2011",
    "in_reply_to_screen_name" : "dhh",
    "in_reply_to_user_id_str" : "14561327",
    "user" : {
      "name" : "harryh",
      "screen_name" : "harryh",
      "protected" : false,
      "id_str" : "4558",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2858286887/7b1324d71f9c442118cbc4b731c8c3f3_normal.png",
      "id" : 4558,
      "verified" : false
    }
  },
  "id" : 60388879122956289,
  "created_at" : "Tue Apr 19 17:06:45 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan King",
      "screen_name" : "rk",
      "indices" : [ 0, 3 ],
      "id_str" : "19853",
      "id" : 19853
    }, {
      "name" : "kellan",
      "screen_name" : "kellan",
      "indices" : [ 4, 11 ],
      "id_str" : "47",
      "id" : 47
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "60380337850695680",
  "geo" : {
  },
  "id_str" : "60380578184310784",
  "in_reply_to_user_id" : 19853,
  "text" : "@rk @kellan This makes sense. Thanks for the enlightenment.",
  "id" : 60380578184310784,
  "in_reply_to_status_id" : 60380337850695680,
  "created_at" : "Tue Apr 19 16:33:46 +0000 2011",
  "in_reply_to_screen_name" : "rk",
  "in_reply_to_user_id_str" : "19853",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wedgwood",
      "screen_name" : "jwedgwood",
      "indices" : [ 0, 10 ],
      "id_str" : "5921812",
      "id" : 5921812
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "60191143756959744",
  "geo" : {
  },
  "id_str" : "60191987843874816",
  "in_reply_to_user_id" : 5921812,
  "text" : "@jwedgwood Hm... I might actually be able to use that.  Thanks!  No base-62, though?",
  "id" : 60191987843874816,
  "in_reply_to_status_id" : 60191143756959744,
  "created_at" : "Tue Apr 19 04:04:22 +0000 2011",
  "in_reply_to_screen_name" : "jwedgwood",
  "in_reply_to_user_id_str" : "5921812",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryce Roberts",
      "screen_name" : "bryce",
      "indices" : [ 0, 6 ],
      "id_str" : "6160742",
      "id" : 6160742
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "60187870752808960",
  "geo" : {
  },
  "id_str" : "60189014526935041",
  "in_reply_to_user_id" : 6160742,
  "text" : "@bryce I totally would for actual url-shortening, but right now just trying to figure it out for something else (click-tracking).",
  "id" : 60189014526935041,
  "in_reply_to_status_id" : 60187870752808960,
  "created_at" : "Tue Apr 19 03:52:33 +0000 2011",
  "in_reply_to_screen_name" : "bryce",
  "in_reply_to_user_id_str" : "6160742",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.605166, -122.322667 ]
  },
  "id_str" : "60185904786055168",
  "text" : "8:36pm Trying to figure out how URL-shorteners work (in the dark). Anyone know the hashing algorithm? http://flic.kr/p/9zMj3n",
  "id" : 60185904786055168,
  "created_at" : "Tue Apr 19 03:40:12 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Schappell",
      "screen_name" : "daveschappell",
      "indices" : [ 0, 14 ],
      "id_str" : "820661",
      "id" : 820661
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "60125448050446336",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6049594655, -122.322877337 ]
  },
  "id_str" : "60158372699324416",
  "in_reply_to_user_id" : 820661,
  "text" : "@daveschappell That's really awesome. Great work!",
  "id" : 60158372699324416,
  "in_reply_to_status_id" : 60125448050446336,
  "created_at" : "Tue Apr 19 01:50:48 +0000 2011",
  "in_reply_to_screen_name" : "daveschappell",
  "in_reply_to_user_id_str" : "820661",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.fitbit.com\" rel=\"nofollow\">Fitbit</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fitstats",
      "indices" : [ 21, 30 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "60116215934353410",
  "text" : "My avg. daily fitbit #fitstats for last week: 5,791 steps and 2.8 miles traveled. http://www.fitbit.com/user/229KX2",
  "id" : 60116215934353410,
  "created_at" : "Mon Apr 18 23:03:17 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amber Rae",
      "screen_name" : "heyamberrae",
      "indices" : [ 0, 12 ],
      "id_str" : "15019184",
      "id" : 15019184
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "60095210130128897",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6050262655, -122.3227171745 ]
  },
  "id_str" : "60097376978862081",
  "in_reply_to_user_id" : 15019184,
  "text" : "@heyamberrae I have. Was pretty straightforward. Wouldn't do it for a startup but worked great for freelancing stuff.",
  "id" : 60097376978862081,
  "in_reply_to_status_id" : 60095210130128897,
  "created_at" : "Mon Apr 18 21:48:25 +0000 2011",
  "in_reply_to_screen_name" : "heyamberrae",
  "in_reply_to_user_id_str" : "15019184",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Wright",
      "screen_name" : "webwright",
      "indices" : [ 0, 10 ],
      "id_str" : "786818",
      "id" : 786818
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "60060040891088896",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6050128447, -122.3229364313 ]
  },
  "id_str" : "60062489718689792",
  "in_reply_to_user_id" : 786818,
  "text" : "@webwright True. I'm definitely practicing. But there's a trade-off. Improve weaknesses or focus on strengths when one has limited runway?",
  "id" : 60062489718689792,
  "in_reply_to_status_id" : 60060040891088896,
  "created_at" : "Mon Apr 18 19:29:48 +0000 2011",
  "in_reply_to_screen_name" : "webwright",
  "in_reply_to_user_id_str" : "786818",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "showdonttell",
      "indices" : [ 94, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6087298965, -122.3243052819 ]
  },
  "id_str" : "60057272780464128",
  "text" : "I sorta suck at communicating my \"vision\". Which only leaves me with one option. Building it. #showdonttell",
  "id" : 60057272780464128,
  "created_at" : "Mon Apr 18 19:09:04 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Health Month",
      "screen_name" : "healthmonth",
      "indices" : [ 3, 15 ],
      "id_str" : "154236895",
      "id" : 154236895
    }, {
      "name" : "Foursquare",
      "screen_name" : "foursquare",
      "indices" : [ 24, 35 ],
      "id_str" : "14120151",
      "id" : 14120151
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "healthmonth",
      "indices" : [ 46, 58 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "60055400564789248",
  "text" : "RT @healthmonth: Should @foursquare badges on #healthmonth stay or should they go? Interesting discussion and chance to vote here: http: ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://timely.is\" rel=\"nofollow\">Timely by Demandforce</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Foursquare",
        "screen_name" : "foursquare",
        "indices" : [ 7, 18 ],
        "id_str" : "14120151",
        "id" : 14120151
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "healthmonth",
        "indices" : [ 29, 41 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "60048794405974016",
    "text" : "Should @foursquare badges on #healthmonth stay or should they go? Interesting discussion and chance to vote here: http://bit.ly/fMXODA",
    "id" : 60048794405974016,
    "created_at" : "Mon Apr 18 18:35:22 +0000 2011",
    "user" : {
      "name" : "Health Month",
      "screen_name" : "healthmonth",
      "protected" : false,
      "id_str" : "154236895",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1136999397/track_meals.400_normal.png",
      "id" : 154236895,
      "verified" : false
    }
  },
  "id" : 60055400564789248,
  "created_at" : "Mon Apr 18 19:01:37 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Baio",
      "screen_name" : "waxpancake",
      "indices" : [ 3, 14 ],
      "id_str" : "13461",
      "id" : 13461
    }, {
      "name" : "Matt Haughey",
      "screen_name" : "mathowie",
      "indices" : [ 90, 99 ],
      "id_str" : "761975",
      "id" : 761975
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "60022761963274240",
  "text" : "RT @waxpancake: OMG, Scott Adams is horrible. He defends his behavior, while ripping into @mathowie and Metafilter in the comments: http ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Matt Haughey",
        "screen_name" : "mathowie",
        "indices" : [ 74, 83 ],
        "id_str" : "761975",
        "id" : 761975
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "60021029954789376",
    "text" : "OMG, Scott Adams is horrible. He defends his behavior, while ripping into @mathowie and Metafilter in the comments: http://bit.ly/gCpJqP",
    "id" : 60021029954789376,
    "created_at" : "Mon Apr 18 16:45:03 +0000 2011",
    "user" : {
      "name" : "Andy Baio",
      "screen_name" : "waxpancake",
      "protected" : false,
      "id_str" : "13461",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2722964270/4abc9d219d7bab89df50106c26e3a812_normal.png",
      "id" : 13461,
      "verified" : false
    }
  },
  "id" : 60022761963274240,
  "created_at" : "Mon Apr 18 16:51:56 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aldy Garcia",
      "screen_name" : "aldypacino",
      "indices" : [ 0, 11 ],
      "id_str" : "58465087",
      "id" : 58465087
    }, {
      "name" : "Abdi Perdana",
      "screen_name" : "abdie",
      "indices" : [ 12, 18 ],
      "id_str" : "71459911",
      "id" : 71459911
    }, {
      "name" : "Eko Puji Siswanto",
      "screen_name" : "ECOCOWS",
      "indices" : [ 19, 27 ],
      "id_str" : "92474514",
      "id" : 92474514
    }, {
      "name" : "Puspita Anggraini",
      "screen_name" : "NamaSayaPuspita",
      "indices" : [ 28, 44 ],
      "id_str" : "423394333",
      "id" : 423394333
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 112 ],
      "url" : "http://t.co/eN9Vul5",
      "expanded_url" : "http://healthmonth.com/n/166331/10",
      "display_url" : "healthmonth.com/n/166331/10"
    } ]
  },
  "in_reply_to_status_id_str" : "59999698601254912",
  "geo" : {
  },
  "id_str" : "60019796883939328",
  "in_reply_to_user_id" : 58465087,
  "text" : "@aldypacino @abdie @ecocows @namasayapuspita No, just turning off 4sq badges. See more here: http://t.co/eN9Vul5",
  "id" : 60019796883939328,
  "in_reply_to_status_id" : 59999698601254912,
  "created_at" : "Mon Apr 18 16:40:09 +0000 2011",
  "in_reply_to_screen_name" : "aldypacino",
  "in_reply_to_user_id_str" : "58465087",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.605166, -122.3225 ]
  },
  "id_str" : "59823120948793344",
  "text" : "8:36pm I'm putting on shoes for my daily pilgrimage to El Mestizo's deliciousness http://flic.kr/p/9zwfmJ",
  "id" : 59823120948793344,
  "created_at" : "Mon Apr 18 03:38:38 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dennis Crowley",
      "screen_name" : "dens",
      "indices" : [ 0, 5 ],
      "id_str" : "418",
      "id" : 418
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "queuemadesensetoo",
      "indices" : [ 48, 66 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "59814476379193344",
  "geo" : {
  },
  "id_str" : "59815266686734336",
  "in_reply_to_user_id" : 418,
  "text" : "@dens - cue 1,000 \"well MY baby...\" replies. :) #queuemadesensetoo",
  "id" : 59815266686734336,
  "in_reply_to_status_id" : 59814476379193344,
  "created_at" : "Mon Apr 18 03:07:25 +0000 2011",
  "in_reply_to_screen_name" : "dens",
  "in_reply_to_user_id_str" : "418",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Foursquare",
      "screen_name" : "foursquare",
      "indices" : [ 40, 51 ],
      "id_str" : "14120151",
      "id" : 14120151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "59706752173752320",
  "text" : "I just unlocked the \"Bookworm\" badge on @foursquare! http://4sq.com/eBBAzU",
  "id" : 59706752173752320,
  "created_at" : "Sun Apr 17 19:56:13 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "rands",
      "screen_name" : "rands",
      "indices" : [ 50, 56 ],
      "id_str" : "30923",
      "id" : 30923
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 122 ],
      "url" : "http://t.co/YkYRXws",
      "expanded_url" : "http://j.mp/gnDgCf",
      "display_url" : "j.mp/gnDgCf"
    } ]
  },
  "geo" : {
  },
  "id_str" : "59693362294435841",
  "text" : "Wow. Quantum computing is gonna really happen? RT @rands: Researchers bring Star Trek a little closer: http://t.co/YkYRXws",
  "id" : 59693362294435841,
  "created_at" : "Sun Apr 17 19:03:01 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dennis Crowley",
      "screen_name" : "dens",
      "indices" : [ 0, 5 ],
      "id_str" : "418",
      "id" : 418
    }, {
      "name" : "harryh",
      "screen_name" : "harryh",
      "indices" : [ 6, 13 ],
      "id_str" : "4558",
      "id" : 4558
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "59650471098458112",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6051276667, -122.3225519078 ]
  },
  "id_str" : "59651952782487553",
  "in_reply_to_user_id" : 418,
  "text" : "@dens @harryh Awesome! I contributed my 2 or 3 to the noble cause.",
  "id" : 59651952782487553,
  "in_reply_to_status_id" : 59650471098458112,
  "created_at" : "Sun Apr 17 16:18:28 +0000 2011",
  "in_reply_to_screen_name" : "dens",
  "in_reply_to_user_id_str" : "418",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martin Black",
      "screen_name" : "martinxo",
      "indices" : [ 0, 9 ],
      "id_str" : "8836612",
      "id" : 8836612
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "59635688240455680",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6052084383, -122.3224518939 ]
  },
  "id_str" : "59640650806726656",
  "in_reply_to_user_id" : 8836612,
  "text" : "@martinxo I don't think so, but if you put an underscore between the words that would work.",
  "id" : 59640650806726656,
  "in_reply_to_status_id" : 59635688240455680,
  "created_at" : "Sun Apr 17 15:33:33 +0000 2011",
  "in_reply_to_screen_name" : "martinxo",
  "in_reply_to_user_id_str" : "8836612",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 40, 50 ],
      "id_str" : "7362142",
      "id" : 7362142
    }, {
      "name" : "OkCupid",
      "screen_name" : "okcupid",
      "indices" : [ 53, 61 ],
      "id_str" : "53543144",
      "id" : 53543144
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "59512856961499136",
  "text" : "It's definitely more fun to make fun of @Kellianne's @okcupid matches than mine. Why is that?",
  "id" : 59512856961499136,
  "created_at" : "Sun Apr 17 07:05:45 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "59487728735236097",
  "text" : "New nerd game called Twitter Chicken! 2 people load tweet streams. Person to reload and get a new tweet first wins. No new tweets = yr dead.",
  "id" : 59487728735236097,
  "created_at" : "Sun Apr 17 05:25:54 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carinna Tarvin",
      "screen_name" : "carinnatarvin",
      "indices" : [ 0, 14 ],
      "id_str" : "20833838",
      "id" : 20833838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "59460815669039105",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6047355545, -122.3222221117 ]
  },
  "id_str" : "59462818814107648",
  "in_reply_to_user_id" : 20833838,
  "text" : "@carinnatarvin Congrats on 10 years here! I missed this one but will make the 20-year one for sure!",
  "id" : 59462818814107648,
  "in_reply_to_status_id" : 59460815669039105,
  "created_at" : "Sun Apr 17 03:46:55 +0000 2011",
  "in_reply_to_screen_name" : "carinnatarvin",
  "in_reply_to_user_id_str" : "20833838",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.605166, -122.3225 ]
  },
  "id_str" : "59462245926715393",
  "text" : "8:36pm More brainstorm doodling http://flic.kr/p/9z9p8p",
  "id" : 59462245926715393,
  "created_at" : "Sun Apr 17 03:44:38 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "danariely",
      "screen_name" : "danariely",
      "indices" : [ 3, 13 ],
      "id_str" : "17997789",
      "id" : 17997789
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "59422019300753408",
  "text" : "RT @danariely: Is 'Nudging' Really Enough? http://on.wsj.com/hpogs8 -- It is not, but behavioral economics is not only about Nudges.",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "59418868153724930",
    "text" : "Is 'Nudging' Really Enough? http://on.wsj.com/hpogs8 -- It is not, but behavioral economics is not only about Nudges.",
    "id" : 59418868153724930,
    "created_at" : "Sun Apr 17 00:52:16 +0000 2011",
    "user" : {
      "name" : "danariely",
      "screen_name" : "danariely",
      "protected" : false,
      "id_str" : "17997789",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3079991122/885ba5efe97fcfd916001b8374d0d75c_normal.jpeg",
      "id" : 17997789,
      "verified" : false
    }
  },
  "id" : 59422019300753408,
  "created_at" : "Sun Apr 17 01:04:48 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jane McGonigal",
      "screen_name" : "avantgame",
      "indices" : [ 0, 10 ],
      "id_str" : "681813",
      "id" : 681813
    }, {
      "name" : "Thor Muller",
      "screen_name" : "tempo",
      "indices" : [ 11, 17 ],
      "id_str" : "5814",
      "id" : 5814
    }, {
      "name" : "Tom Coates",
      "screen_name" : "tomcoates",
      "indices" : [ 18, 28 ],
      "id_str" : "12514",
      "id" : 12514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "59373771492044800",
  "geo" : {
  },
  "id_str" : "59374254378070016",
  "in_reply_to_user_id" : 681813,
  "text" : "@avantgame @tempo @tomcoates Yup, sick as a dog yesterday, feeling 50% today. Sick = best time to make headway on shows I'm way behind on!",
  "id" : 59374254378070016,
  "in_reply_to_status_id" : 59373771492044800,
  "created_at" : "Sat Apr 16 21:55:00 +0000 2011",
  "in_reply_to_screen_name" : "avantgame",
  "in_reply_to_user_id_str" : "681813",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thor Muller",
      "screen_name" : "tempo",
      "indices" : [ 0, 6 ],
      "id_str" : "5814",
      "id" : 5814
    }, {
      "name" : "Jane McGonigal",
      "screen_name" : "avantgame",
      "indices" : [ 7, 17 ],
      "id_str" : "681813",
      "id" : 681813
    }, {
      "name" : "Tom Coates",
      "screen_name" : "tomcoates",
      "indices" : [ 18, 28 ],
      "id_str" : "12514",
      "id" : 12514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "59372995889737728",
  "geo" : {
  },
  "id_str" : "59373596514070528",
  "in_reply_to_user_id" : 5814,
  "text" : "@tempo @avantgame @tomcoates Y'all have convinced me to watch this show now! Just finished Avatar: The Last Airbender while sick in bed. :)",
  "id" : 59373596514070528,
  "in_reply_to_status_id" : 59372995889737728,
  "created_at" : "Sat Apr 16 21:52:23 +0000 2011",
  "in_reply_to_screen_name" : "tempo",
  "in_reply_to_user_id_str" : "5814",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim O'Reilly",
      "screen_name" : "timoreilly",
      "indices" : [ 3, 14 ],
      "id_str" : "2384071",
      "id" : 2384071
    }, {
      "name" : "Slashdot",
      "screen_name" : "slashdot",
      "indices" : [ 96, 105 ],
      "id_str" : "1068831",
      "id" : 1068831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "59359563572453376",
  "text" : "RT @timoreilly: Love it: why Google should just buy the music industry http://bit.ly/dYImlJ via @slashdot",
  "retweeted_status" : {
    "source" : "<a href=\"http://seesmic.com/seesmic_desktop/sd2\" rel=\"nofollow\">Seesmic Desktop</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Slashdot",
        "screen_name" : "slashdot",
        "indices" : [ 80, 89 ],
        "id_str" : "1068831",
        "id" : 1068831
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "59043298416926720",
    "text" : "Love it: why Google should just buy the music industry http://bit.ly/dYImlJ via @slashdot",
    "id" : 59043298416926720,
    "created_at" : "Fri Apr 15 23:59:53 +0000 2011",
    "user" : {
      "name" : "Tim O'Reilly",
      "screen_name" : "timoreilly",
      "protected" : false,
      "id_str" : "2384071",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2823681988/f4f6f2bed8ab4d5a48dea4b9ea85d5f1_normal.jpeg",
      "id" : 2384071,
      "verified" : true
    }
  },
  "id" : 59359563572453376,
  "created_at" : "Sat Apr 16 20:56:37 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Gravante",
      "screen_name" : "joegravante",
      "indices" : [ 0, 12 ],
      "id_str" : "210131643",
      "id" : 210131643
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "59349080844939264",
  "geo" : {
  },
  "id_str" : "59354929059467264",
  "in_reply_to_user_id" : 210131643,
  "text" : "@joegravante Not by nature, unless people strive to win for the sake of winning rather than learning. It's tricky!",
  "id" : 59354929059467264,
  "in_reply_to_status_id" : 59349080844939264,
  "created_at" : "Sat Apr 16 20:38:12 +0000 2011",
  "in_reply_to_screen_name" : "joegravante",
  "in_reply_to_user_id_str" : "210131643",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Gravante",
      "screen_name" : "joegravante",
      "indices" : [ 0, 12 ],
      "id_str" : "210131643",
      "id" : 210131643
    }, {
      "name" : "Khan Academy",
      "screen_name" : "khanacademy",
      "indices" : [ 103, 115 ],
      "id_str" : "16689804",
      "id" : 16689804
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "59346499569598465",
  "geo" : {
  },
  "id_str" : "59346964810182656",
  "in_reply_to_user_id" : 210131643,
  "text" : "@joegravante Yes, the quality of game will decay if you give students a reason to game the system. /cc @khanacademy",
  "id" : 59346964810182656,
  "in_reply_to_status_id" : 59346499569598465,
  "created_at" : "Sat Apr 16 20:06:33 +0000 2011",
  "in_reply_to_screen_name" : "joegravante",
  "in_reply_to_user_id_str" : "210131643",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Gravante",
      "screen_name" : "joegravante",
      "indices" : [ 0, 12 ],
      "id_str" : "210131643",
      "id" : 210131643
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "59343034118184960",
  "geo" : {
  },
  "id_str" : "59343640681656320",
  "in_reply_to_user_id" : 210131643,
  "text" : "@joegravante Thanks, I'm glad you liked it! If you have any questions about the slides that might not have been obvious, let me know.",
  "id" : 59343640681656320,
  "in_reply_to_status_id" : 59343034118184960,
  "created_at" : "Sat Apr 16 19:53:21 +0000 2011",
  "in_reply_to_screen_name" : "joegravante",
  "in_reply_to_user_id_str" : "210131643",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "59302020523364352",
  "text" : "I feel like about ten thousand bucks (out of a million).",
  "id" : 59302020523364352,
  "created_at" : "Sat Apr 16 17:07:58 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Foursquare",
      "screen_name" : "foursquare",
      "indices" : [ 43, 54 ],
      "id_str" : "14120151",
      "id" : 14120151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "59295611878506496",
  "text" : "I just unlocked the \"4sqDay 2011\" badge on @foursquare! http://4sq.com/gS3W6L",
  "id" : 59295611878506496,
  "created_at" : "Sat Apr 16 16:42:30 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Neil Patel",
      "screen_name" : "neilpatel",
      "indices" : [ 3, 13 ],
      "id_str" : "1322691",
      "id" : 1322691
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "59104469438308352",
  "text" : "RT @neilpatel: You've reached middle age when all you exercise is caution.",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "58566617650573312",
    "text" : "You've reached middle age when all you exercise is caution.",
    "id" : 58566617650573312,
    "created_at" : "Thu Apr 14 16:25:44 +0000 2011",
    "user" : {
      "name" : "Neil Patel",
      "screen_name" : "neilpatel",
      "protected" : false,
      "id_str" : "1322691",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1827701922/twit-5_normal.jpg",
      "id" : 1322691,
      "verified" : false
    }
  },
  "id" : 59104469438308352,
  "created_at" : "Sat Apr 16 04:02:58 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.604666, -122.323 ]
  },
  "id_str" : "59103992654991361",
  "text" : "8:36pm I'm sick! Boo. http://flic.kr/p/9yWNp3",
  "id" : 59103992654991361,
  "created_at" : "Sat Apr 16 04:01:04 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jody Wright",
      "screen_name" : "jodyjwright",
      "indices" : [ 0, 12 ],
      "id_str" : "67177223",
      "id" : 67177223
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "58925585543593984",
  "geo" : {
  },
  "id_str" : "58925962875777025",
  "in_reply_to_user_id" : 67177223,
  "text" : "@jodyjwright Awesome, Jody! Good luck on those last couple days! Don't let the bedbugs bite. :)",
  "id" : 58925962875777025,
  "in_reply_to_status_id" : 58925585543593984,
  "created_at" : "Fri Apr 15 16:13:38 +0000 2011",
  "in_reply_to_screen_name" : "jodyjwright",
  "in_reply_to_user_id_str" : "67177223",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u028E\u01DD\u029E\u0254\u0131\u0265 \u0287\u0287\u0250\u026F",
      "screen_name" : "matthickey",
      "indices" : [ 0, 11 ],
      "id_str" : "8710082",
      "id" : 8710082
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "58781642797490176",
  "geo" : {
  },
  "id_str" : "58782266721177600",
  "in_reply_to_user_id" : 8710082,
  "text" : "@matthickey Or maybe the best minds are using double reverse psychology and putting bad ads in plain sight! Tricksters.",
  "id" : 58782266721177600,
  "in_reply_to_status_id" : 58781642797490176,
  "created_at" : "Fri Apr 15 06:42:39 +0000 2011",
  "in_reply_to_screen_name" : "matthickey",
  "in_reply_to_user_id_str" : "8710082",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Payne",
      "screen_name" : "al3x",
      "indices" : [ 24, 29 ],
      "id_str" : "18713",
      "id" : 18713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 133 ],
      "url" : "http://t.co/V0ix1UC",
      "expanded_url" : "http://buswk.co/hIaxfa",
      "display_url" : "buswk.co/hIaxfa"
    } ]
  },
  "geo" : {
  },
  "id_str" : "58778383512907776",
  "text" : "15 ads on page 1 of 5. \u201C@al3x: \"The best minds of my generation are thinking about how to make people click ads\". http://t.co/V0ix1UC\u201D",
  "id" : 58778383512907776,
  "created_at" : "Fri Apr 15 06:27:13 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Koloskov",
      "screen_name" : "xenocid",
      "indices" : [ 0, 8 ],
      "id_str" : "7777252",
      "id" : 7777252
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "58764217091751936",
  "geo" : {
  },
  "id_str" : "58764382905180161",
  "in_reply_to_user_id" : 7777252,
  "text" : "@xenocid I consider it app research. Write it off!",
  "id" : 58764382905180161,
  "in_reply_to_status_id" : 58764217091751936,
  "created_at" : "Fri Apr 15 05:31:35 +0000 2011",
  "in_reply_to_screen_name" : "xenocid",
  "in_reply_to_user_id_str" : "7777252",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Garry Tan",
      "screen_name" : "garrytan",
      "indices" : [ 3, 12 ],
      "id_str" : "11768582",
      "id" : 11768582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "58759790020657152",
  "text" : "RT @garrytan: Want to hire and recruit and run a startup? Study how to start and run a cult.",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "58757758039756800",
    "text" : "Want to hire and recruit and run a startup? Study how to start and run a cult.",
    "id" : 58757758039756800,
    "created_at" : "Fri Apr 15 05:05:15 +0000 2011",
    "user" : {
      "name" : "Garry Tan",
      "screen_name" : "garrytan",
      "protected" : false,
      "id_str" : "11768582",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2673975033/965a165a093e7c0921b9d69d5d99bc41_normal.jpeg",
      "id" : 11768582,
      "verified" : false
    }
  },
  "id" : 58759790020657152,
  "created_at" : "Fri Apr 15 05:13:20 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.605166, -122.322667 ]
  },
  "id_str" : "58737091508568064",
  "text" : "8:36pm Working on data models. Now with new rugs! http://flic.kr/p/9yHxss",
  "id" : 58737091508568064,
  "created_at" : "Fri Apr 15 03:43:08 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Pink",
      "screen_name" : "DanielPink",
      "indices" : [ 1, 12 ],
      "id_str" : "14378113",
      "id" : 14378113
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 139 ],
      "url" : "http://t.co/JXCYT37",
      "expanded_url" : "http://uxmag.com/strategy/why-we-need-storytellers-at-the-heart-of-product-development#",
      "display_url" : "uxmag.com/strategy/why-w\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "58691769537273857",
  "text" : "\"@DanielPink has identified six aptitudes for the Conceptual Age: design, story, symphony, empathy, play, and meaning.\" http://t.co/JXCYT37",
  "id" : 58691769537273857,
  "created_at" : "Fri Apr 15 00:43:02 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diana Kimball",
      "screen_name" : "dianakimball",
      "indices" : [ 0, 13 ],
      "id_str" : "14471007",
      "id" : 14471007
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "58624150595571712",
  "geo" : {
  },
  "id_str" : "58683231993733121",
  "in_reply_to_user_id" : 14471007,
  "text" : "@dianakimball I'm glad you like it! Thanks for the nice post... that's the only way the words spreads. :)",
  "id" : 58683231993733121,
  "in_reply_to_status_id" : 58624150595571712,
  "created_at" : "Fri Apr 15 00:09:07 +0000 2011",
  "in_reply_to_screen_name" : "dianakimball",
  "in_reply_to_user_id_str" : "14471007",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fitocracy",
      "screen_name" : "fitocracy",
      "indices" : [ 87, 97 ],
      "id_str" : "188011291",
      "id" : 188011291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "58392411726028800",
  "geo" : {
  },
  "id_str" : "58392796377251841",
  "in_reply_to_user_id" : 21515310,
  "text" : "@richardtalens Awesome! Looking forward to it. I'd love to help get the word out about @fitocracy once it's ready.",
  "id" : 58392796377251841,
  "in_reply_to_status_id" : 58392411726028800,
  "created_at" : "Thu Apr 14 04:55:02 +0000 2011",
  "in_reply_to_screen_name" : "DickTalens",
  "in_reply_to_user_id_str" : "21515310",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fitocracy",
      "screen_name" : "fitocracy",
      "indices" : [ 0, 10 ],
      "id_str" : "188011291",
      "id" : 188011291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "58389500111499264",
  "geo" : {
  },
  "id_str" : "58390352536670208",
  "in_reply_to_user_id" : 188011291,
  "text" : "@fitocracy When are you gonna let in more people? I'd love to check it out, I'm working on similar things with healthmonth.com...",
  "id" : 58390352536670208,
  "in_reply_to_status_id" : 58389500111499264,
  "created_at" : "Thu Apr 14 04:45:19 +0000 2011",
  "in_reply_to_screen_name" : "fitocracy",
  "in_reply_to_user_id_str" : "188011291",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Galen Ward",
      "screen_name" : "galenward",
      "indices" : [ 0, 10 ],
      "id_str" : "2854761",
      "id" : 2854761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "58382980325965824",
  "geo" : {
  },
  "id_str" : "58383278616485888",
  "in_reply_to_user_id" : 2854761,
  "text" : "@galenward Jealous! :)",
  "id" : 58383278616485888,
  "in_reply_to_status_id" : 58382980325965824,
  "created_at" : "Thu Apr 14 04:17:12 +0000 2011",
  "in_reply_to_screen_name" : "galenward",
  "in_reply_to_user_id_str" : "2854761",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6065, -122.322834 ]
  },
  "id_str" : "58376234261954560",
  "text" : "OH: \"I used to take a lot of drugs to this song when I was young.\" re: How Does It Feel by Spaceman 3 http://flic.kr/p/9yqvMP",
  "id" : 58376234261954560,
  "created_at" : "Thu Apr 14 03:49:13 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "noah glass",
      "screen_name" : "noah",
      "indices" : [ 13, 18 ],
      "id_str" : "14",
      "id" : 14
    }, {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 23, 31 ],
      "id_str" : "783214",
      "id" : 783214
    }, {
      "name" : "Fred Oliveira",
      "screen_name" : "f",
      "indices" : [ 108, 110 ],
      "id_str" : "5511",
      "id" : 5511
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 102 ],
      "url" : "http://t.co/aImTcOO",
      "expanded_url" : "http://www.businessinsider.com/twitter-cofounder-noah-glass-2011-4",
      "display_url" : "businessinsider.com/twitter-cofoun\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.60654723, -122.32287579 ]
  },
  "id_str" : "58357882151903232",
  "text" : "The story of @Noah and @Twitter. Very interesting, and many sides to it, I'm sure. http://t.co/aImTcOO /via @f",
  "id" : 58357882151903232,
  "created_at" : "Thu Apr 14 02:36:18 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "the piXel Mind",
      "screen_name" : "mayavenkatraman",
      "indices" : [ 0, 16 ],
      "id_str" : "12658052",
      "id" : 12658052
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "58344504956166145",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.61575061, -122.32012915 ]
  },
  "id_str" : "58345251412250624",
  "in_reply_to_user_id" : 12658052,
  "text" : "@mayavenkatraman People talk about how they wish their life was easier/simpler/free of problems all the time.",
  "id" : 58345251412250624,
  "in_reply_to_status_id" : 58344504956166145,
  "created_at" : "Thu Apr 14 01:46:06 +0000 2011",
  "in_reply_to_screen_name" : "mayavenkatraman",
  "in_reply_to_user_id_str" : "12658052",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Rainert",
      "screen_name" : "arainert",
      "indices" : [ 0, 9 ],
      "id_str" : "7482",
      "id" : 7482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "58344226890588160",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.61575061, -122.32012915 ]
  },
  "id_str" : "58344960629555200",
  "in_reply_to_user_id" : 7482,
  "text" : "@arainert Yeah, but a little counter-intuitive to our cultural instinct. We are problem-solvers by nature and we could not thrive w/o them.",
  "id" : 58344960629555200,
  "in_reply_to_status_id" : 58344226890588160,
  "created_at" : "Thu Apr 14 01:44:57 +0000 2011",
  "in_reply_to_screen_name" : "arainert",
  "in_reply_to_user_id_str" : "7482",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Oberholtzer",
      "screen_name" : "ilovecharts",
      "indices" : [ 58, 70 ],
      "id_str" : "116498184",
      "id" : 116498184
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.615, -122.322667 ]
  },
  "id_str" : "58341520260083712",
  "text" : "The best life requires difficulty. Agree or disagree? /cc @ilovecharts http://flic.kr/p/9yp64z",
  "id" : 58341520260083712,
  "created_at" : "Thu Apr 14 01:31:17 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Payne",
      "screen_name" : "al3x",
      "indices" : [ 3, 8 ],
      "id_str" : "18713",
      "id" : 18713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "58044871847575552",
  "text" : "RT @al3x: \"Having empathy for people doing what you are doing is as important as having empathy for your own users.\" http://j.mp/fSQIx7",
  "retweeted_status" : {
    "source" : "<a href=\"http://reederapp.com\" rel=\"nofollow\">Reeder</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "58036091621617664",
    "text" : "\"Having empathy for people doing what you are doing is as important as having empathy for your own users.\" http://j.mp/fSQIx7",
    "id" : 58036091621617664,
    "created_at" : "Wed Apr 13 05:17:37 +0000 2011",
    "user" : {
      "name" : "Alex Payne",
      "screen_name" : "al3x",
      "protected" : false,
      "id_str" : "18713",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3352529876/8cd9c8492c2a8aad6036dce1041c5c90_normal.jpeg",
      "id" : 18713,
      "verified" : false
    }
  },
  "id" : 58044871847575552,
  "created_at" : "Wed Apr 13 05:52:30 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arielis Talavera",
      "screen_name" : "ArielisT",
      "indices" : [ 0, 9 ],
      "id_str" : "1163522401",
      "id" : 1163522401
    }, {
      "name" : "Jesse Dawson",
      "screen_name" : "jeffybrite",
      "indices" : [ 95, 106 ],
      "id_str" : "35402650",
      "id" : 35402650
    }, {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 107, 117 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "57914981445935104",
  "text" : "@arielist Definitely relevant, since he is one of the few great modern artist/marketer combos. @jeffybrite @kellianne",
  "id" : 57914981445935104,
  "created_at" : "Tue Apr 12 21:16:22 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "chris jones",
      "screen_name" : "cjlikearockstar",
      "indices" : [ 0, 16 ],
      "id_str" : "34383091",
      "id" : 34383091
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 97 ],
      "url" : "http://t.co/gPzI866",
      "expanded_url" : "http://www.flickr.com/photos/thejedi/5604362941/in/set-72157626337134859",
      "display_url" : "flickr.com/photos/thejedi\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "57652113651679232",
  "geo" : {
  },
  "id_str" : "57654506942504960",
  "in_reply_to_user_id" : 34383091,
  "text" : "@cjlikearockstar I'm so bummed I had to miss it. This picture alone... wow... http://t.co/gPzI866",
  "id" : 57654506942504960,
  "in_reply_to_status_id" : 57652113651679232,
  "created_at" : "Tue Apr 12 04:01:20 +0000 2011",
  "in_reply_to_screen_name" : "cjlikearockstar",
  "in_reply_to_user_id_str" : "34383091",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helen Jane",
      "screen_name" : "helenjane",
      "indices" : [ 0, 10 ],
      "id_str" : "798542",
      "id" : 798542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "57649999609200640",
  "geo" : {
  },
  "id_str" : "57650395312435201",
  "in_reply_to_user_id" : 798542,
  "text" : "@helenjane Yeah, I think I clicked through a good hundred of my fake tweets. And babies!",
  "id" : 57650395312435201,
  "in_reply_to_status_id" : 57649999609200640,
  "created_at" : "Tue Apr 12 03:44:59 +0000 2011",
  "in_reply_to_screen_name" : "helenjane",
  "in_reply_to_user_id_str" : "798542",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.605, -122.322667 ]
  },
  "id_str" : "57650281676161024",
  "text" : "8:36pm Deep in APIs and data models http://flic.kr/p/9xTndT",
  "id" : 57650281676161024,
  "created_at" : "Tue Apr 12 03:44:32 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lauren Leto",
      "screen_name" : "laurenleto",
      "indices" : [ 129, 140 ],
      "id_str" : "15510569",
      "id" : 15510569
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "57645810204160000",
  "text" : "I've fallen behind the $14 to the true goal, believe me, I might be very creepy fake smile. http://thatcan.be/my/next/tweet /via @laurenleto",
  "id" : 57645810204160000,
  "created_at" : "Tue Apr 12 03:26:46 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Triplett",
      "screen_name" : "webology",
      "indices" : [ 0, 9 ],
      "id_str" : "12583982",
      "id" : 12583982
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "57642634981818368",
  "geo" : {
  },
  "id_str" : "57642968689025024",
  "in_reply_to_user_id" : 12583982,
  "text" : "@webology Yeah, Google Docs allows that. But I'm trying to find somewhere that allows me to send text emails from a server...",
  "id" : 57642968689025024,
  "in_reply_to_status_id" : 57642634981818368,
  "created_at" : "Tue Apr 12 03:15:29 +0000 2011",
  "in_reply_to_screen_name" : "webology",
  "in_reply_to_user_id_str" : "12583982",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Dawson",
      "screen_name" : "jeffybrite",
      "indices" : [ 0, 11 ],
      "id_str" : "35402650",
      "id" : 35402650
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "57640560512610305",
  "geo" : {
  },
  "id_str" : "57641902736015360",
  "in_reply_to_user_id" : 35402650,
  "text" : "@jeffybrite Okay, yeah. The need to market IS the constraint. You have to try to reach your audience. You can't make art in a vacuum.",
  "id" : 57641902736015360,
  "in_reply_to_status_id" : 57640560512610305,
  "created_at" : "Tue Apr 12 03:11:15 +0000 2011",
  "in_reply_to_screen_name" : "jeffybrite",
  "in_reply_to_user_id_str" : "35402650",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "57639390159192064",
  "text" : "Anyone know of a way to email something with specific formatting into a database/spreadsheet that I can also get data out of?",
  "id" : 57639390159192064,
  "created_at" : "Tue Apr 12 03:01:16 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carinna Tarvin",
      "screen_name" : "carinnatarvin",
      "indices" : [ 0, 14 ],
      "id_str" : "20833838",
      "id" : 20833838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "57635340114075648",
  "geo" : {
  },
  "id_str" : "57638986537111552",
  "in_reply_to_user_id" : 20833838,
  "text" : "@carinnatarvin Awesome! I wish you could tell how many generations ago we had a common relative.",
  "id" : 57638986537111552,
  "in_reply_to_status_id" : 57635340114075648,
  "created_at" : "Tue Apr 12 02:59:39 +0000 2011",
  "in_reply_to_screen_name" : "carinnatarvin",
  "in_reply_to_user_id_str" : "20833838",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Dawson",
      "screen_name" : "jeffybrite",
      "indices" : [ 0, 11 ],
      "id_str" : "35402650",
      "id" : 35402650
    }, {
      "name" : "Arielis Talavera",
      "screen_name" : "ArielisT",
      "indices" : [ 76, 85 ],
      "id_str" : "1163522401",
      "id" : 1163522401
    }, {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 86, 96 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "liveanddiebythemarket",
      "indices" : [ 97, 119 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "57625434254348289",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6049487124, -122.3229917865 ]
  },
  "id_str" : "57635713306460160",
  "in_reply_to_user_id" : 35402650,
  "text" : "@jeffybrite Maybe if you need to convince someone, then it's not vital? /cc @arielist @kellianne #liveanddiebythemarket",
  "id" : 57635713306460160,
  "in_reply_to_status_id" : 57625434254348289,
  "created_at" : "Tue Apr 12 02:46:39 +0000 2011",
  "in_reply_to_screen_name" : "jeffybrite",
  "in_reply_to_user_id_str" : "35402650",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6069055156, -122.3208279233 ]
  },
  "id_str" : "57620857756975104",
  "text" : "Nothing worse than art born without constraint.",
  "id" : 57620857756975104,
  "created_at" : "Tue Apr 12 01:47:37 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arielis Talavera",
      "screen_name" : "ArielisT",
      "indices" : [ 0, 9 ],
      "id_str" : "1163522401",
      "id" : 1163522401
    }, {
      "name" : "Jesse Dawson",
      "screen_name" : "jeffybrite",
      "indices" : [ 10, 21 ],
      "id_str" : "35402650",
      "id" : 35402650
    }, {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 22, 32 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "57620565468528640",
  "text" : "@arielist @jeffybrite @kellianne I strongly believe art *should* be difficult. If it gets out, it's vital. If it doesn't, maybe it wasn't.",
  "id" : 57620565468528640,
  "created_at" : "Tue Apr 12 01:46:28 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.fitbit.com\" rel=\"nofollow\">Fitbit</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fitstats",
      "indices" : [ 21, 30 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "57579768610168832",
  "text" : "My avg. daily fitbit #fitstats for last week: 6,877 steps and 3.3 miles traveled. http://www.fitbit.com/user/229KX2",
  "id" : 57579768610168832,
  "created_at" : "Mon Apr 11 23:04:21 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael S Galpert",
      "screen_name" : "msg",
      "indices" : [ 0, 4 ],
      "id_str" : "937961",
      "id" : 937961
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "57578863420637185",
  "geo" : {
  },
  "id_str" : "57579131839328257",
  "in_reply_to_user_id" : 937961,
  "text" : "@msg No idea. I definitely didn't sign into a phishing site. But it was a password I've used elsewhere...",
  "id" : 57579131839328257,
  "in_reply_to_status_id" : 57578863420637185,
  "created_at" : "Mon Apr 11 23:01:49 +0000 2011",
  "in_reply_to_screen_name" : "msg",
  "in_reply_to_user_id_str" : "937961",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "57578009057689600",
  "text" : "Crap, my gmail got hacked. Sorry if you got a spam from me. Just changed my password. :(",
  "id" : 57578009057689600,
  "created_at" : "Mon Apr 11 22:57:21 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josef Dietl",
      "screen_name" : "JDietl",
      "indices" : [ 0, 7 ],
      "id_str" : "134691780",
      "id" : 134691780
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "57535325865648128",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6141164922, -122.3224779222 ]
  },
  "id_str" : "57546313138581504",
  "in_reply_to_user_id" : 134691780,
  "text" : "@JDietl Aka paying for exclusivity, filtering, and status?",
  "id" : 57546313138581504,
  "in_reply_to_status_id" : 57535325865648128,
  "created_at" : "Mon Apr 11 20:51:24 +0000 2011",
  "in_reply_to_screen_name" : "JDietl",
  "in_reply_to_user_id_str" : "134691780",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zaarly Seattle ",
      "screen_name" : "zaarly_seattle",
      "indices" : [ 0, 15 ],
      "id_str" : "282136991",
      "id" : 282136991
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "57523720176144385",
  "geo" : {
  },
  "id_str" : "57523944927936512",
  "in_reply_to_user_id" : 257153137,
  "text" : "@zaarly_seattle You're welcome! I've been meaning to try it out for a while... missed their last special so hopped on this one.",
  "id" : 57523944927936512,
  "in_reply_to_status_id" : 57523720176144385,
  "created_at" : "Mon Apr 11 19:22:31 +0000 2011",
  "in_reply_to_screen_name" : "zaarlyseattle",
  "in_reply_to_user_id_str" : "257153137",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 20, 30 ],
      "id_str" : "7362142",
      "id" : 7362142
    }, {
      "name" : "Niko Benson",
      "screen_name" : "nikobenson",
      "indices" : [ 36, 47 ],
      "id_str" : "142467448",
      "id" : 142467448
    }, {
      "name" : "23andMe",
      "screen_name" : "23andMe",
      "indices" : [ 55, 63 ],
      "id_str" : "14738561",
      "id" : 14738561
    }, {
      "name" : "kimberley",
      "screen_name" : "xaotica",
      "indices" : [ 121, 129 ],
      "id_str" : "13983",
      "id" : 13983
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 115 ],
      "url" : "http://t.co/GRS9nYJ",
      "expanded_url" : "http://spittoon.23andme.com/2011/04/11/23andme-is-celebrating-dna-day-a-little-early-with-a-sale/",
      "display_url" : "spittoon.23andme.com/2011/04/11/23a\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "57523485890715650",
  "text" : "Just signed myself, @kellianne, and @nikobenson up for @23andme, thanks to their 1-day special: http://t.co/GRS9nYJ /thx @xaotica",
  "id" : 57523485890715650,
  "created_at" : "Mon Apr 11 19:20:42 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 132 ],
      "url" : "http://t.co/qx8QMov",
      "expanded_url" : "http://blog.jayparkinsonmd.com",
      "display_url" : "blog.jayparkinsonmd.com"
    } ]
  },
  "geo" : {
  },
  "id_str" : "57509739352948737",
  "text" : "\"My def. of health is optimizing 7 areas: body, mind, relationships, money, work, environment, and serendipity.\" http://t.co/qx8QMov",
  "id" : 57509739352948737,
  "created_at" : "Mon Apr 11 18:26:04 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 138 ],
      "url" : "http://t.co/PLEiiBd",
      "expanded_url" : "http://techcrunch.com/2011/04/10/peter-thiel-were-in-a-bubble-and-its-not-the-internet-its-higher-education/",
      "display_url" : "techcrunch.com/2011/04/10/pet\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "57498999330050048",
  "text" : "Q: \"If Harvard makes that much of a difference, why not franchise it so more people can attend?\" A: Scarcity & status. http://t.co/PLEiiBd",
  "id" : 57498999330050048,
  "created_at" : "Mon Apr 11 17:43:24 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Britt Crawford",
      "screen_name" : "britt",
      "indices" : [ 0, 6 ],
      "id_str" : "5362",
      "id" : 5362
    }, {
      "name" : "DailyBurn",
      "screen_name" : "dailyburn",
      "indices" : [ 120, 130 ],
      "id_str" : "14575477",
      "id" : 14575477
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "57486997715025920",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6050630955, -122.3225020795 ]
  },
  "id_str" : "57487865675915264",
  "in_reply_to_user_id" : 5362,
  "text" : "@britt Agreed. I'm okay with photos of food being imprisoned, but definitely need the data. Hoping it gets added to the @dailyburn API.",
  "id" : 57487865675915264,
  "in_reply_to_status_id" : 57486997715025920,
  "created_at" : "Mon Apr 11 16:59:09 +0000 2011",
  "in_reply_to_screen_name" : "britt",
  "in_reply_to_user_id_str" : "5362",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dennis Crowley",
      "screen_name" : "dens",
      "indices" : [ 0, 5 ],
      "id_str" : "418",
      "id" : 418
    }, {
      "name" : "Withings",
      "screen_name" : "Withings",
      "indices" : [ 29, 38 ],
      "id_str" : "35432131",
      "id" : 35432131
    }, {
      "name" : "Foursquare",
      "screen_name" : "foursquare",
      "indices" : [ 41, 52 ],
      "id_str" : "14120151",
      "id" : 14120151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "57439898256416768",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6050126511, -122.3228308767 ]
  },
  "id_str" : "57441174465687552",
  "in_reply_to_user_id" : 418,
  "text" : "@dens No, I haven't seen the @Withings + @Foursquare one! And... looking for a MealSnap API now... is there one yet?",
  "id" : 57441174465687552,
  "in_reply_to_status_id" : 57439898256416768,
  "created_at" : "Mon Apr 11 13:53:37 +0000 2011",
  "in_reply_to_screen_name" : "dens",
  "in_reply_to_user_id_str" : "418",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bastian Beyer",
      "screen_name" : "BastianBeyer",
      "indices" : [ 49, 62 ],
      "id_str" : "881068292",
      "id" : 881068292
    }, {
      "name" : "Dennis Crowley",
      "screen_name" : "dens",
      "indices" : [ 108, 113 ],
      "id_str" : "418",
      "id" : 418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 102 ],
      "url" : "http://t.co/8Jv2r5V",
      "expanded_url" : "http://dashdingo.org/post/4391031302/how-mealsnap-works",
      "display_url" : "dashdingo.org/post/439103130\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.604976918, -122.322851914 ]
  },
  "id_str" : "57439321006948352",
  "text" : "I kinda love MealSnap. It's surprisingly fun. RT @bastianbeyer: How MealSnap Works http://t.co/8Jv2r5V /via @dens",
  "id" : 57439321006948352,
  "created_at" : "Mon Apr 11 13:46:15 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "57327262462251008",
  "text" : "Having a 10-month old makes me realize how much of our communication, sense of surroundings, and mood are pre-language. Almost 100%.",
  "id" : 57327262462251008,
  "created_at" : "Mon Apr 11 06:20:59 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard's Old A/c",
      "screen_name" : "ricmacnz",
      "indices" : [ 0, 9 ],
      "id_str" : "588669460",
      "id" : 588669460
    }, {
      "name" : "ReadWrite",
      "screen_name" : "RWW",
      "indices" : [ 66, 70 ],
      "id_str" : "4641021",
      "id" : 4641021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "57318031520563200",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.60507997, -122.3224289219 ]
  },
  "id_str" : "57326123931009024",
  "in_reply_to_user_id" : 105895323,
  "text" : "@ricmacnz Yes, absolutely! The Technium = chances and choices /cc @rww",
  "id" : 57326123931009024,
  "in_reply_to_status_id" : 57318031520563200,
  "created_at" : "Mon Apr 11 06:16:27 +0000 2011",
  "in_reply_to_screen_name" : "ricmac",
  "in_reply_to_user_id_str" : "105895323",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.605, -122.322834 ]
  },
  "id_str" : "57287867612938241",
  "text" : "8:36pm Sick wife, baby who wants to talk instead of sleep, and I think I earned a glass of wine http://flic.kr/p/9xzK2Z",
  "id" : 57287867612938241,
  "created_at" : "Mon Apr 11 03:44:26 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Dole",
      "screen_name" : "adamdole",
      "indices" : [ 39, 48 ],
      "id_str" : "14789168",
      "id" : 14789168
    }, {
      "name" : "Jen S. McCabe",
      "screen_name" : "jensmccabe",
      "indices" : [ 122, 133 ],
      "id_str" : "14258044",
      "id" : 14258044
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 116 ],
      "url" : "http://t.co/fR8FPtj",
      "expanded_url" : "http://lat.ms/hOt2fG",
      "display_url" : "lat.ms/hOt2fG"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6050051158, -122.3230098133 ]
  },
  "id_str" : "57229016603705344",
  "text" : "Unfortunately, I bet it won't work. RT @adamdole: Medicaid to offer rewards for healthy behavior http://t.co/fR8FPtj /via @jensmccabe",
  "id" : 57229016603705344,
  "created_at" : "Sun Apr 10 23:50:35 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Lyons",
      "screen_name" : "thlyons",
      "indices" : [ 0, 8 ],
      "id_str" : "22122104",
      "id" : 22122104
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "57136972749209600",
  "geo" : {
  },
  "id_str" : "57147423629385728",
  "in_reply_to_user_id" : 22122104,
  "text" : "@thlyons Oops, it moved. Try the Settings -&gt; Search and Export page.",
  "id" : 57147423629385728,
  "in_reply_to_status_id" : 57136972749209600,
  "created_at" : "Sun Apr 10 18:26:22 +0000 2011",
  "in_reply_to_screen_name" : "thlyons",
  "in_reply_to_user_id_str" : "22122104",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "savagegus",
      "screen_name" : "savagegus",
      "indices" : [ 0, 10 ],
      "id_str" : "14705570",
      "id" : 14705570
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "57146693887598593",
  "geo" : {
  },
  "id_str" : "57147144934658048",
  "in_reply_to_user_id" : 14705570,
  "text" : "@savagegus Just happened to watch that one! Amazing.",
  "id" : 57147144934658048,
  "in_reply_to_status_id" : 57146693887598593,
  "created_at" : "Sun Apr 10 18:25:15 +0000 2011",
  "in_reply_to_screen_name" : "savagegus",
  "in_reply_to_user_id_str" : "14705570",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Quinn",
      "screen_name" : "quantafire",
      "indices" : [ 72, 83 ],
      "id_str" : "8449382",
      "id" : 8449382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 66 ],
      "url" : "http://t.co/VTsIZC4",
      "expanded_url" : "http://blog.ted.com/2008/05/13/joshua_klein/",
      "display_url" : "blog.ted.com/2008/05/13/jos\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "57128713199943680",
  "text" : "This crow vending machine TED talk is awesome! http://t.co/VTsIZC4 /thx @quantafire",
  "id" : 57128713199943680,
  "created_at" : "Sun Apr 10 17:12:01 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TED",
      "screen_name" : "ted_com",
      "indices" : [ 94, 102 ],
      "id_str" : "42633651",
      "id" : 42633651
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "57119365191041024",
  "text" : "It's TED talk Sunday morning. What are your favorite TED talks that you can recommend for me? @ted_com",
  "id" : 57119365191041024,
  "created_at" : "Sun Apr 10 16:34:52 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lynn Collette",
      "screen_name" : "sfposhy",
      "indices" : [ 0, 8 ],
      "id_str" : "268453413",
      "id" : 268453413
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "56926780593930240",
  "geo" : {
  },
  "id_str" : "56933846389755905",
  "in_reply_to_user_id" : 268453413,
  "text" : "@sfposhy Oh my. We've been there. Hope everything's okay... luckily baby heads are pretty resilient... still scary though! :(",
  "id" : 56933846389755905,
  "in_reply_to_status_id" : 56926780593930240,
  "created_at" : "Sun Apr 10 04:17:41 +0000 2011",
  "in_reply_to_screen_name" : "sfposhy",
  "in_reply_to_user_id_str" : "268453413",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.605, -122.322834 ]
  },
  "id_str" : "56924104569274368",
  "text" : "8:36pm Pre-bath play time http://flic.kr/p/9xfMt4",
  "id" : 56924104569274368,
  "created_at" : "Sun Apr 10 03:38:58 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "56580956185825280",
  "text" : "People who talk about minimum viable products tend to focus more on the minimum and less on the viable.",
  "id" : 56580956185825280,
  "created_at" : "Sat Apr 09 04:55:25 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.605166, -122.322834 ]
  },
  "id_str" : "56562661797801984",
  "text" : "Niko climbed 3 flights of stairs today and tried to figure out the elevator. Now he's zonked. http://flic.kr/p/9x1iWv",
  "id" : 56562661797801984,
  "created_at" : "Sat Apr 09 03:42:44 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.605166, -122.3225 ]
  },
  "id_str" : "56561688077545472",
  "text" : "8:36pm Working on new ideas but I lost my magic pen! http://flic.kr/p/9x1hii",
  "id" : 56561688077545472,
  "created_at" : "Sat Apr 09 03:38:51 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Schappell",
      "screen_name" : "daveschappell",
      "indices" : [ 14, 28 ],
      "id_str" : "820661",
      "id" : 820661
    }, {
      "name" : "500 Startups",
      "screen_name" : "500Startups",
      "indices" : [ 45, 57 ],
      "id_str" : "168857946",
      "id" : 168857946
    }, {
      "name" : "Niko Benson",
      "screen_name" : "nikobenson",
      "indices" : [ 76, 87 ],
      "id_str" : "142467448",
      "id" : 142467448
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "56266221049479168",
  "text" : "Loved reading @daveschappell's review of the @500startups Demo Day. Signing @nikobenson up for SocialStork now...",
  "id" : 56266221049479168,
  "created_at" : "Fri Apr 08 08:04:47 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luke Barbara",
      "screen_name" : "LukeBarbara",
      "indices" : [ 0, 12 ],
      "id_str" : "15792561",
      "id" : 15792561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "56218553262669824",
  "geo" : {
  },
  "id_str" : "56245860996091904",
  "in_reply_to_user_id" : 15792561,
  "text" : "@lukebarbara Thanks! No reason, it's just a time of day that is somewhat unpredictable. I borrowed the minute from another person's project.",
  "id" : 56245860996091904,
  "in_reply_to_status_id" : 56218553262669824,
  "created_at" : "Fri Apr 08 06:43:52 +0000 2011",
  "in_reply_to_screen_name" : "LukeBarbara",
  "in_reply_to_user_id_str" : "15792561",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ron Diver",
      "screen_name" : "rondiver",
      "indices" : [ 0, 9 ],
      "id_str" : "12661782",
      "id" : 12661782
    }, {
      "name" : "Amit superamit Gupta",
      "screen_name" : "superamit",
      "indices" : [ 113, 123 ],
      "id_str" : "10609",
      "id" : 10609
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "56221210454921216",
  "geo" : {
  },
  "id_str" : "56222156908019712",
  "in_reply_to_user_id" : 12661782,
  "text" : "@rondiver I re-visited Latitude the other day in the hopes of this coming to iPhone or an API sometime soon! /cc @superamit",
  "id" : 56222156908019712,
  "in_reply_to_status_id" : 56221210454921216,
  "created_at" : "Fri Apr 08 05:09:41 +0000 2011",
  "in_reply_to_screen_name" : "rondiver",
  "in_reply_to_user_id_str" : "12661782",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jen S. McCabe",
      "screen_name" : "jensmccabe",
      "indices" : [ 41, 52 ],
      "id_str" : "14258044",
      "id" : 14258044
    }, {
      "name" : "Amber Rae",
      "screen_name" : "heyamberrae",
      "indices" : [ 54, 66 ],
      "id_str" : "15019184",
      "id" : 15019184
    }, {
      "name" : "Galen Ward",
      "screen_name" : "galenward",
      "indices" : [ 72, 82 ],
      "id_str" : "2854761",
      "id" : 2854761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.605, -122.322667 ]
  },
  "id_str" : "56201273195761664",
  "text" : "8:36pm Great conversations today. Thanks @jensmccabe, @heyamberrae, and @galenward! http://flic.kr/p/9wQjuw",
  "id" : 56201273195761664,
  "created_at" : "Fri Apr 08 03:46:42 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "56060376416129024",
  "text" : "The domain has been registered since 1997 and doesn't expire til 2020. It's the registrant's last name. Hmm...",
  "id" : 56060376416129024,
  "created_at" : "Thu Apr 07 18:26:49 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 3, 13 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "56057512507617280",
  "text" : "RT @kellianne: Niko is so into dancing right now that he bobs his head to the lullaby I hum while nursing him down.",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "56057217387999232",
    "text" : "Niko is so into dancing right now that he bobs his head to the lullaby I hum while nursing him down.",
    "id" : 56057217387999232,
    "created_at" : "Thu Apr 07 18:14:16 +0000 2011",
    "user" : {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "protected" : false,
      "id_str" : "7362142",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3058433557/056b99ecb9df9b6b9b382b2470b6ee82_normal.jpeg",
      "id" : 7362142,
      "verified" : false
    }
  },
  "id" : 56057512507617280,
  "created_at" : "Thu Apr 07 18:15:27 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "56055089516912640",
  "text" : "Someone's squatting on a domain that I *really* want. It's just the default server page. Advice on the best way to contact/make an offer?",
  "id" : 56055089516912640,
  "created_at" : "Thu Apr 07 18:05:49 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.605166, -122.3225 ]
  },
  "id_str" : "55836893128040448",
  "text" : "8:36pm Walking home from baby and dinner Mecca, Vios http://flic.kr/p/9wy29a",
  "id" : 55836893128040448,
  "created_at" : "Thu Apr 07 03:38:47 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gwen Bell",
      "screen_name" : "gwenbell",
      "indices" : [ 0, 9 ],
      "id_str" : "1250104952",
      "id" : 1250104952
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.627041128, -122.3077339713 ]
  },
  "id_str" : "55818795155070978",
  "text" : "@gwenbell I'm surprised at the numbers a bit myself. I might have to unsubscribe from a few things.",
  "id" : 55818795155070978,
  "created_at" : "Thu Apr 07 02:26:52 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Strand McCutchen",
      "screen_name" : "Strabd",
      "indices" : [ 0, 7 ],
      "id_str" : "18032208",
      "id" : 18032208
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "55793696091815936",
  "geo" : {
  },
  "id_str" : "55793817592397824",
  "in_reply_to_user_id" : 18032208,
  "text" : "@Strabd If you use ruby, check out the ruby-gmail gem. Makes it insanely easy to get those stats.",
  "id" : 55793817592397824,
  "in_reply_to_status_id" : 55793696091815936,
  "created_at" : "Thu Apr 07 00:47:37 +0000 2011",
  "in_reply_to_screen_name" : "Strabd",
  "in_reply_to_user_id_str" : "18032208",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Strand McCutchen",
      "screen_name" : "Strabd",
      "indices" : [ 0, 7 ],
      "id_str" : "18032208",
      "id" : 18032208
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "55789889995800576",
  "geo" : {
  },
  "id_str" : "55790968670134272",
  "in_reply_to_user_id" : 18032208,
  "text" : "@Strabd Unfortunately not. I wanted to record the audio but I forgot to turn it on at the last minute. :(",
  "id" : 55790968670134272,
  "in_reply_to_status_id" : 55789889995800576,
  "created_at" : "Thu Apr 07 00:36:18 +0000 2011",
  "in_reply_to_screen_name" : "Strabd",
  "in_reply_to_user_id_str" : "18032208",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jen S. McCabe",
      "screen_name" : "jensmccabe",
      "indices" : [ 3, 14 ],
      "id_str" : "14258044",
      "id" : 14258044
    }, {
      "name" : "Anti-Buster",
      "screen_name" : "busterbenson",
      "indices" : [ 21, 34 ],
      "id_str" : "1024917050",
      "id" : 1024917050
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 77 ],
      "url" : "http://t.co/rzcIfhB",
      "expanded_url" : "http://www.bradenton.com/2011/04/05/3089865/fitbit-announces-first-wave-of.html?storylink=addthis",
      "display_url" : "bradenton.com/2011/04/05/308\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "55771215096332288",
  "text" : "RT @jensmccabe: Yeah @busterbenson! Rock on Health Month! http://t.co/rzcIfhB",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Anti-Buster",
        "screen_name" : "busterbenson",
        "indices" : [ 5, 18 ],
        "id_str" : "1024917050",
        "id" : 1024917050
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 42, 61 ],
        "url" : "http://t.co/rzcIfhB",
        "expanded_url" : "http://www.bradenton.com/2011/04/05/3089865/fitbit-announces-first-wave-of.html?storylink=addthis",
        "display_url" : "bradenton.com/2011/04/05/308\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "55770525192044544",
    "text" : "Yeah @busterbenson! Rock on Health Month! http://t.co/rzcIfhB",
    "id" : 55770525192044544,
    "created_at" : "Wed Apr 06 23:15:04 +0000 2011",
    "user" : {
      "name" : "Jen S. McCabe",
      "screen_name" : "jensmccabe",
      "protected" : false,
      "id_str" : "14258044",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1664728420/IMG_4878_normal.JPG",
      "id" : 14258044,
      "verified" : false
    }
  },
  "id" : 55771215096332288,
  "created_at" : "Wed Apr 06 23:17:48 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian Sefferman",
      "screen_name" : "iseff",
      "indices" : [ 0, 6 ],
      "id_str" : "5500",
      "id" : 5500
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "55757246675681280",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6140297187, -122.323208957 ]
  },
  "id_str" : "55760488499392512",
  "in_reply_to_user_id" : 5500,
  "text" : "@iseff Thank you! And yeah, I'm due for a visit sometime soon. Email me.",
  "id" : 55760488499392512,
  "in_reply_to_status_id" : 55757246675681280,
  "created_at" : "Wed Apr 06 22:35:11 +0000 2011",
  "in_reply_to_screen_name" : "iseff",
  "in_reply_to_user_id_str" : "5500",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://timely.is\" rel=\"nofollow\">Timely by Demandforce</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "55736855471202304",
  "text" : "An hour of fiddling. Now tracking # emails received/day, sent/day, and current # unread. And making it public! http://bit.ly/hIBwKD",
  "id" : 55736855471202304,
  "created_at" : "Wed Apr 06 21:01:16 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "55703562747002880",
  "text" : "\"THIS IS HUGE!\"",
  "id" : 55703562747002880,
  "created_at" : "Wed Apr 06 18:48:58 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jenny bento",
      "screen_name" : "jennybento",
      "indices" : [ 0, 11 ],
      "id_str" : "871991",
      "id" : 871991
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "55637323366404097",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6047153767, -122.3345378635 ]
  },
  "id_str" : "55638063229059073",
  "in_reply_to_user_id" : 871991,
  "text" : "@jennybento Try editing the turn, and resubmitting that item in particular. If that doesn't work, send me a link to your report page. Sorry!",
  "id" : 55638063229059073,
  "in_reply_to_status_id" : 55637323366404097,
  "created_at" : "Wed Apr 06 14:28:42 +0000 2011",
  "in_reply_to_screen_name" : "jennybento",
  "in_reply_to_user_id_str" : "871991",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u24D5\u24E3",
      "screen_name" : "folktrash",
      "indices" : [ 0, 10 ],
      "id_str" : "15265271",
      "id" : 15265271
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "55635378815770625",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6054616702, -122.3342364591 ]
  },
  "id_str" : "55635544570462208",
  "in_reply_to_user_id" : 15265271,
  "text" : "@folktrash Thanks, I'll fix it soon!",
  "id" : 55635544570462208,
  "in_reply_to_status_id" : 55635378815770625,
  "created_at" : "Wed Apr 06 14:18:42 +0000 2011",
  "in_reply_to_screen_name" : "folktrash",
  "in_reply_to_user_id_str" : "15265271",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u24D5\u24E3",
      "screen_name" : "folktrash",
      "indices" : [ 0, 10 ],
      "id_str" : "15265271",
      "id" : 15265271
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "55629798738898944",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6048632813, -122.334936173 ]
  },
  "id_str" : "55633966002221057",
  "in_reply_to_user_id" : 15265271,
  "text" : "@folktrash Uh oh. On my site or on slideshare's?",
  "id" : 55633966002221057,
  "in_reply_to_status_id" : 55629798738898944,
  "created_at" : "Wed Apr 06 14:12:25 +0000 2011",
  "in_reply_to_screen_name" : "folktrash",
  "in_reply_to_user_id_str" : "15265271",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ross Hill",
      "screen_name" : "rosshill",
      "indices" : [ 0, 9 ],
      "id_str" : "7092172",
      "id" : 7092172
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "55478563574513664",
  "geo" : {
  },
  "id_str" : "55481018592935936",
  "in_reply_to_user_id" : 7092172,
  "text" : "@rosshill I'm checking it out now. Haven't been checking in. What's the easiest way? Mobile?",
  "id" : 55481018592935936,
  "in_reply_to_status_id" : 55478563574513664,
  "created_at" : "Wed Apr 06 04:04:40 +0000 2011",
  "in_reply_to_screen_name" : "rosshill",
  "in_reply_to_user_id_str" : "7092172",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ross Hill",
      "screen_name" : "rosshill",
      "indices" : [ 0, 9 ],
      "id_str" : "7092172",
      "id" : 7092172
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "55478563574513664",
  "geo" : {
  },
  "id_str" : "55479962500743168",
  "in_reply_to_user_id" : 7092172,
  "text" : "@rosshill Oh yeah? How do you feed it more data? And how do you get to the fascinating info?",
  "id" : 55479962500743168,
  "in_reply_to_status_id" : 55478563574513664,
  "created_at" : "Wed Apr 06 04:00:28 +0000 2011",
  "in_reply_to_screen_name" : "rosshill",
  "in_reply_to_user_id_str" : "7092172",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ross Hill",
      "screen_name" : "rosshill",
      "indices" : [ 0, 9 ],
      "id_str" : "7092172",
      "id" : 7092172
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "55436874830987264",
  "geo" : {
  },
  "id_str" : "55477194239123456",
  "in_reply_to_user_id" : 7092172,
  "text" : "@rosshill A bigger picture that I couldn't see at the time. Friend-patterns, lifestyle-shifts, patterns of long-term emotional drift, etc.",
  "id" : 55477194239123456,
  "in_reply_to_status_id" : 55436874830987264,
  "created_at" : "Wed Apr 06 03:49:28 +0000 2011",
  "in_reply_to_screen_name" : "rosshill",
  "in_reply_to_user_id_str" : "7092172",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.605, -122.322834 ]
  },
  "id_str" : "55475288800366593",
  "text" : "8:36pm Playing with ruby-gmail to see if email stats are difficult to calculate http://flic.kr/p/9wivzK",
  "id" : 55475288800366593,
  "created_at" : "Wed Apr 06 03:41:54 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ross Hill",
      "screen_name" : "rosshill",
      "indices" : [ 0, 9 ],
      "id_str" : "7092172",
      "id" : 7092172
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "55436874830987264",
  "geo" : {
  },
  "id_str" : "55472038235734016",
  "in_reply_to_user_id" : 7092172,
  "text" : "@rosshill That's a tough one. 8:36pm photos is a long-term favorite, but the general goal is to have a bigger picture emerge from the data.",
  "id" : 55472038235734016,
  "in_reply_to_status_id" : 55436874830987264,
  "created_at" : "Wed Apr 06 03:28:59 +0000 2011",
  "in_reply_to_screen_name" : "rosshill",
  "in_reply_to_user_id_str" : "7092172",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.fitbit.com\" rel=\"nofollow\">Fitbit</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fitstats",
      "indices" : [ 21, 30 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "55404891895631872",
  "text" : "My avg. daily fitbit #fitstats for last week: 7,225 steps and 3.6 miles traveled. http://www.fitbit.com/user/229KX2",
  "id" : 55404891895631872,
  "created_at" : "Tue Apr 05 23:02:10 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "55396169672691712",
  "text" : "Holy moley. Just cranked through 410 emails! Had to turn off my phone and drink a lot of coffee. Now I just have my list of issues to fix.",
  "id" : 55396169672691712,
  "created_at" : "Tue Apr 05 22:27:30 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 139 ],
      "url" : "http://t.co/eXl3Pml",
      "expanded_url" : "http://750words.com/patrons/note/1128",
      "display_url" : "750words.com/patrons/note/1\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "55374197156880384",
  "text" : "People on 750words.com never cease to amaze me with their persistence and dedication to a simple task. Congrats, Vicky! http://t.co/eXl3Pml",
  "id" : 55374197156880384,
  "created_at" : "Tue Apr 05 21:00:12 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sebastian Deterding",
      "screen_name" : "dingstweets",
      "indices" : [ 0, 12 ],
      "id_str" : "14435477",
      "id" : 14435477
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "55363172214898689",
  "geo" : {
  },
  "id_str" : "55364681606496256",
  "in_reply_to_user_id" : 14435477,
  "text" : "@dingstweets Thanks for the retweet. :) Still recovering from the talk... that's a lot of work!",
  "id" : 55364681606496256,
  "in_reply_to_status_id" : 55363172214898689,
  "created_at" : "Tue Apr 05 20:22:23 +0000 2011",
  "in_reply_to_screen_name" : "dingstweets",
  "in_reply_to_user_id_str" : "14435477",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hans Gerwitz",
      "screen_name" : "gerwitz",
      "indices" : [ 0, 8 ],
      "id_str" : "521",
      "id" : 521
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "55360515060408320",
  "geo" : {
  },
  "id_str" : "55360702432559104",
  "in_reply_to_user_id" : 521,
  "text" : "@gerwitz Yup. Though there are quite a few ways around it (like google reader folders) if you want an easier way to do it.",
  "id" : 55360702432559104,
  "in_reply_to_status_id" : 55360515060408320,
  "created_at" : "Tue Apr 05 20:06:34 +0000 2011",
  "in_reply_to_screen_name" : "gerwitz",
  "in_reply_to_user_id_str" : "521",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hans Gerwitz",
      "screen_name" : "gerwitz",
      "indices" : [ 0, 8 ],
      "id_str" : "521",
      "id" : 521
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "55348746317336576",
  "geo" : {
  },
  "id_str" : "55349434321604608",
  "in_reply_to_user_id" : 521,
  "text" : "@gerwitz No, that's pretty automatic. It's linguistic analysis on RSS feed content. No discipline required. Gmail has an API to look into...",
  "id" : 55349434321604608,
  "in_reply_to_status_id" : 55348746317336576,
  "created_at" : "Tue Apr 05 19:21:48 +0000 2011",
  "in_reply_to_screen_name" : "gerwitz",
  "in_reply_to_user_id_str" : "521",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hans Gerwitz",
      "screen_name" : "gerwitz",
      "indices" : [ 0, 8 ],
      "id_str" : "521",
      "id" : 521
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "healthmonth",
      "indices" : [ 103, 115 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "55347860920741888",
  "geo" : {
  },
  "id_str" : "55348331634896896",
  "in_reply_to_user_id" : 521,
  "text" : "@gerwitz Write now it's just manual. I do a daily checkin email to my team. Soon, it will become a new #healthmonth rule.",
  "id" : 55348331634896896,
  "in_reply_to_status_id" : 55347860920741888,
  "created_at" : "Tue Apr 05 19:17:25 +0000 2011",
  "in_reply_to_screen_name" : "gerwitz",
  "in_reply_to_user_id_str" : "521",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hans Gerwitz",
      "screen_name" : "gerwitz",
      "indices" : [ 0, 8 ],
      "id_str" : "521",
      "id" : 521
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "55347183230271488",
  "geo" : {
  },
  "id_str" : "55347449136562176",
  "in_reply_to_user_id" : 521,
  "text" : "@gerwitz I've been logging it for a while now and I've found it to be very insightful. Let me know how it goes!",
  "id" : 55347449136562176,
  "in_reply_to_status_id" : 55347183230271488,
  "created_at" : "Tue Apr 05 19:13:54 +0000 2011",
  "in_reply_to_screen_name" : "gerwitz",
  "in_reply_to_user_id_str" : "521",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Ball",
      "screen_name" : "kbal11",
      "indices" : [ 0, 7 ],
      "id_str" : "16795825",
      "id" : 16795825
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "55346885619236866",
  "geo" : {
  },
  "id_str" : "55346962999934976",
  "in_reply_to_user_id" : 16795825,
  "text" : "@kbal11 They are like yin and yang. :)",
  "id" : 55346962999934976,
  "in_reply_to_status_id" : 55346885619236866,
  "created_at" : "Tue Apr 05 19:11:58 +0000 2011",
  "in_reply_to_screen_name" : "kbal11",
  "in_reply_to_user_id_str" : "16795825",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "55346475068166146",
  "text" : "I think you can tell more about my current mental state from my unread email count than pretty much any other auto-generated number.",
  "id" : 55346475068166146,
  "created_at" : "Tue Apr 05 19:10:02 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "josh",
      "screen_name" : "joshc",
      "indices" : [ 0, 6 ],
      "id_str" : "2015",
      "id" : 2015
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "55337025150259201",
  "geo" : {
  },
  "id_str" : "55337383373193216",
  "in_reply_to_user_id" : 2015,
  "text" : "@joshc I tried that. It only gives you stats for a particular search. And is a bit buggy and didn't work most of the time... :(",
  "id" : 55337383373193216,
  "in_reply_to_status_id" : 55337025150259201,
  "created_at" : "Tue Apr 05 18:33:54 +0000 2011",
  "in_reply_to_screen_name" : "joshc",
  "in_reply_to_user_id_str" : "2015",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Damon Cortesi",
      "screen_name" : "dacort",
      "indices" : [ 0, 7 ],
      "id_str" : "99723",
      "id" : 99723
    }, {
      "name" : "David Aronchick",
      "screen_name" : "aronchick",
      "indices" : [ 100, 110 ],
      "id_str" : "15024407",
      "id" : 15024407
    }, {
      "name" : "Galen Ward",
      "screen_name" : "galenward",
      "indices" : [ 111, 121 ],
      "id_str" : "2854761",
      "id" : 2854761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "55331471296180224",
  "geo" : {
  },
  "id_str" : "55335865781723136",
  "in_reply_to_user_id" : 99723,
  "text" : "@dacort Looks great. I wish I could try it out without paying $25 first. Which APIs do you use? /cc @aronchick @galenward",
  "id" : 55335865781723136,
  "in_reply_to_status_id" : 55331471296180224,
  "created_at" : "Tue Apr 05 18:27:53 +0000 2011",
  "in_reply_to_screen_name" : "dacort",
  "in_reply_to_user_id_str" : "99723",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://export.ly\" rel=\"nofollow\">Export.ly</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Simply Measured",
      "screen_name" : "simplymeasured",
      "indices" : [ 32, 47 ],
      "id_str" : "92162698",
      "id" : 92162698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "55335452550508544",
  "text" : "I just used http://export.ly by @simplymeasured to analyze my Twitter audience in Excel.",
  "id" : 55335452550508544,
  "created_at" : "Tue Apr 05 18:26:14 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tanner C",
      "screen_name" : "tannerc",
      "indices" : [ 0, 8 ],
      "id_str" : "9161482",
      "id" : 9161482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "55333506984853504",
  "geo" : {
  },
  "id_str" : "55335177504821249",
  "in_reply_to_user_id" : 9161482,
  "text" : "@tannerc Yeah, must not be a highly requested feature. It would be a good 20% project for anyone working there though.",
  "id" : 55335177504821249,
  "in_reply_to_status_id" : 55333506984853504,
  "created_at" : "Tue Apr 05 18:25:09 +0000 2011",
  "in_reply_to_screen_name" : "tannerc",
  "in_reply_to_user_id_str" : "9161482",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Xobni and Smartr",
      "screen_name" : "xobni",
      "indices" : [ 0, 6 ],
      "id_str" : "9804222",
      "id" : 9804222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "55330811234365440",
  "geo" : {
  },
  "id_str" : "55332287709061120",
  "in_reply_to_user_id" : 9804222,
  "text" : "@xobni Thank you! Checking it out now. Can you point me to how I get stats on my email usage?",
  "id" : 55332287709061120,
  "in_reply_to_status_id" : 55330811234365440,
  "created_at" : "Tue Apr 05 18:13:40 +0000 2011",
  "in_reply_to_screen_name" : "xobni",
  "in_reply_to_user_id_str" : "9804222",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Neilson",
      "screen_name" : "TheCulprit",
      "indices" : [ 0, 11 ],
      "id_str" : "6726182",
      "id" : 6726182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "55330548566081536",
  "geo" : {
  },
  "id_str" : "55330759128530944",
  "in_reply_to_user_id" : 6726182,
  "text" : "@TheCulprit Do I get a prize for finding the last feature not built by Gist?  :)",
  "id" : 55330759128530944,
  "in_reply_to_status_id" : 55330548566081536,
  "created_at" : "Tue Apr 05 18:07:35 +0000 2011",
  "in_reply_to_screen_name" : "TheCulprit",
  "in_reply_to_user_id_str" : "6726182",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Colin Loretz",
      "screen_name" : "colinloretz",
      "indices" : [ 0, 12 ],
      "id_str" : "2803511",
      "id" : 2803511
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "55329429093752832",
  "geo" : {
  },
  "id_str" : "55330379170721792",
  "in_reply_to_user_id" : 2803511,
  "text" : "@colinloretz Neat! Tried to sign up but the link to the Firefox AddOn is a 404. I've also tried emailga.me which is sorta neat.",
  "id" : 55330379170721792,
  "in_reply_to_status_id" : 55329429093752832,
  "created_at" : "Tue Apr 05 18:06:05 +0000 2011",
  "in_reply_to_screen_name" : "colinloretz",
  "in_reply_to_user_id_str" : "2803511",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Neilson",
      "screen_name" : "TheCulprit",
      "indices" : [ 0, 11 ],
      "id_str" : "6726182",
      "id" : 6726182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "55328711481884672",
  "geo" : {
  },
  "id_str" : "55329372843933696",
  "in_reply_to_user_id" : 6726182,
  "text" : "@TheCulprit Ooh, good! Can you point me to the right area to get email stats?",
  "id" : 55329372843933696,
  "in_reply_to_status_id" : 55328711481884672,
  "created_at" : "Tue Apr 05 18:02:05 +0000 2011",
  "in_reply_to_screen_name" : "TheCulprit",
  "in_reply_to_user_id_str" : "6726182",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Smartr Xobni Support",
      "screen_name" : "xobni_support",
      "indices" : [ 0, 14 ],
      "id_str" : "25153491",
      "id" : 25153491
    }, {
      "name" : "Xobni and Smartr",
      "screen_name" : "xobni",
      "indices" : [ 91, 97 ],
      "id_str" : "9804222",
      "id" : 9804222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "55327892137189376",
  "geo" : {
  },
  "id_str" : "55328712262025216",
  "in_reply_to_user_id" : 25153491,
  "text" : "@xobni_support I filled that out a couple minutes ago... any tips on hopping the line? /cc @xobni",
  "id" : 55328712262025216,
  "in_reply_to_status_id" : 55327892137189376,
  "created_at" : "Tue Apr 05 17:59:27 +0000 2011",
  "in_reply_to_screen_name" : "xobni_support",
  "in_reply_to_user_id_str" : "25153491",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Aronchick",
      "screen_name" : "aronchick",
      "indices" : [ 0, 10 ],
      "id_str" : "15024407",
      "id" : 15024407
    }, {
      "name" : "Galen Ward",
      "screen_name" : "galenward",
      "indices" : [ 55, 65 ],
      "id_str" : "2854761",
      "id" : 2854761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 50 ],
      "url" : "http://t.co/Sl9wzoN",
      "expanded_url" : "http://code.google.com/apis/gmail/docs/",
      "display_url" : "code.google.com/apis/gmail/doc\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "55327639187103745",
  "geo" : {
  },
  "id_str" : "55328523786784768",
  "in_reply_to_user_id" : 15024407,
  "text" : "@aronchick They have a couple: http://t.co/Sl9wzoN /cc @galenward",
  "id" : 55328523786784768,
  "in_reply_to_status_id" : 55327639187103745,
  "created_at" : "Tue Apr 05 17:58:42 +0000 2011",
  "in_reply_to_screen_name" : "aronchick",
  "in_reply_to_user_id_str" : "15024407",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Xobni and Smartr",
      "screen_name" : "xobni",
      "indices" : [ 40, 46 ],
      "id_str" : "9804222",
      "id" : 9804222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "55327692538642432",
  "text" : "Does anyone know how I can get into the @xobni beta for Gmail? Looks like the only thing doing what I'm looking for.",
  "id" : 55327692538642432,
  "created_at" : "Tue Apr 05 17:55:24 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eli Horne",
      "screen_name" : "elihorne",
      "indices" : [ 0, 9 ],
      "id_str" : "798952",
      "id" : 798952
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "55327053842616321",
  "geo" : {
  },
  "id_str" : "55327225200902144",
  "in_reply_to_user_id" : 798952,
  "text" : "@elihorne Which API? The IMAP one? Is it Google Apps only?",
  "id" : 55327225200902144,
  "in_reply_to_status_id" : 55327053842616321,
  "created_at" : "Tue Apr 05 17:53:33 +0000 2011",
  "in_reply_to_screen_name" : "elihorne",
  "in_reply_to_user_id_str" : "798952",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "55326520671092736",
  "text" : "Is there a site that tracks, over time, how many emails I get, how many I send, how many get replied to, and how quickly? There should be.",
  "id" : 55326520671092736,
  "created_at" : "Tue Apr 05 17:50:45 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joey Feith",
      "screen_name" : "JoeyFeith",
      "indices" : [ 0, 10 ],
      "id_str" : "23084800",
      "id" : 23084800
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "55281482465423360",
  "geo" : {
  },
  "id_str" : "55299514688475136",
  "in_reply_to_user_id" : 23084800,
  "text" : "@JoeyFeith Okay, I'm gonna dig in today and fix this for you for reals. Sorry for the trouble.",
  "id" : 55299514688475136,
  "in_reply_to_status_id" : 55281482465423360,
  "created_at" : "Tue Apr 05 16:03:26 +0000 2011",
  "in_reply_to_screen_name" : "JoeyFeith",
  "in_reply_to_user_id_str" : "23084800",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "watchoutinbox",
      "indices" : [ 79, 93 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6049455565, -122.3229679988 ]
  },
  "id_str" : "55298470793322496",
  "text" : "I've fallen behind the curve this last month. Dedicating today to catching up. #watchoutinbox",
  "id" : 55298470793322496,
  "created_at" : "Tue Apr 05 15:59:17 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://timely.is\" rel=\"nofollow\">Timely by Demandforce</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "w2e",
      "indices" : [ 15, 19 ]
    }, {
      "text" : "gamification",
      "indices" : [ 79, 92 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "55210362332651520",
  "text" : "Slides from my #w2e talk! AKA the 1 thing I would like to add to the polarized #gamification conversation: http://bit.ly/e9mE6x",
  "id" : 55210362332651520,
  "created_at" : "Tue Apr 05 10:09:10 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jane McGonigal",
      "screen_name" : "avantgame",
      "indices" : [ 48, 58 ],
      "id_str" : "681813",
      "id" : 681813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.605, -122.322667 ]
  },
  "id_str" : "55114393586896898",
  "text" : "8:36pm Playspent.org is awesome--check it! /via @avantgame http://flic.kr/p/9w5HQ3",
  "id" : 55114393586896898,
  "created_at" : "Tue Apr 05 03:47:50 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ron Diver",
      "screen_name" : "rondiver",
      "indices" : [ 0, 9 ],
      "id_str" : "12661782",
      "id" : 12661782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "55106524003049473",
  "geo" : {
  },
  "id_str" : "55106907974811648",
  "in_reply_to_user_id" : 12661782,
  "text" : "@rondiver I got it at the grocery store, which is far away. Probably not worth the $14 to explain everything.",
  "id" : 55106907974811648,
  "in_reply_to_status_id" : 55106524003049473,
  "created_at" : "Tue Apr 05 03:18:05 +0000 2011",
  "in_reply_to_screen_name" : "rondiver",
  "in_reply_to_user_id_str" : "12661782",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "55106185505939456",
  "text" : "Can a wine get corked if it has one of those weird rubber corks? This wine definitely has something wrong with it. It's usually my fave.",
  "id" : 55106185505939456,
  "created_at" : "Tue Apr 05 03:15:13 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michelle Broderick",
      "screen_name" : "MichelleBee",
      "indices" : [ 0, 12 ],
      "id_str" : "1059951",
      "id" : 1059951
    }, {
      "name" : "VeeV Spirits",
      "screen_name" : "VEEV",
      "indices" : [ 30, 35 ],
      "id_str" : "38618529",
      "id" : 38618529
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "54999990560497664",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6049909347, -122.322908306 ]
  },
  "id_str" : "55007179270402048",
  "in_reply_to_user_id" : 1059951,
  "text" : "@MichelleBee What is this? Is @veev good? Interesting marketing strategy. :)",
  "id" : 55007179270402048,
  "in_reply_to_status_id" : 54999990560497664,
  "created_at" : "Mon Apr 04 20:41:48 +0000 2011",
  "in_reply_to_screen_name" : "MichelleBee",
  "in_reply_to_user_id_str" : "1059951",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian McKellar",
      "screen_name" : "ian",
      "indices" : [ 0, 4 ],
      "id_str" : "259",
      "id" : 259
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "54779025310224384",
  "geo" : {
  },
  "id_str" : "54781905052246016",
  "in_reply_to_user_id" : 259,
  "text" : "@ian What is it?!?!",
  "id" : 54781905052246016,
  "in_reply_to_status_id" : 54779025310224384,
  "created_at" : "Mon Apr 04 05:46:38 +0000 2011",
  "in_reply_to_screen_name" : "ian",
  "in_reply_to_user_id_str" : "259",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.605, -122.322667 ]
  },
  "id_str" : "54752461176578048",
  "text" : "8:36pm Watching Avatar, the cartoon about airbending not the other one. Pretty good! http://flic.kr/p/9vMiCd",
  "id" : 54752461176578048,
  "created_at" : "Mon Apr 04 03:49:38 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tara Tiger Brown",
      "screen_name" : "tara",
      "indices" : [ 20, 25 ],
      "id_str" : "10959642",
      "id" : 10959642
    }, {
      "name" : "TEDTalks Updates",
      "screen_name" : "tedtalks",
      "indices" : [ 88, 97 ],
      "id_str" : "15492359",
      "id" : 15492359
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 117 ],
      "url" : "http://t.co/n2QbEZ9",
      "expanded_url" : "http://bit.ly/fxAM6u",
      "display_url" : "bit.ly/fxAM6u"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6049663829, -122.3229168264 ]
  },
  "id_str" : "54735382599835648",
  "text" : "I love the idea! RT @tara: Secret Goals: inspired by the work of Alcoholics Anonymous & @tedtalks http://t.co/n2QbEZ9",
  "id" : 54735382599835648,
  "created_at" : "Mon Apr 04 02:41:46 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard's Old A/c",
      "screen_name" : "ricmacnz",
      "indices" : [ 0, 9 ],
      "id_str" : "588669460",
      "id" : 588669460
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "54418469919277057",
  "geo" : {
  },
  "id_str" : "54433784413696000",
  "in_reply_to_user_id" : 105895323,
  "text" : "@ricmacnz That's a GREAT book!",
  "id" : 54433784413696000,
  "in_reply_to_status_id" : 54418469919277057,
  "created_at" : "Sun Apr 03 06:43:20 +0000 2011",
  "in_reply_to_screen_name" : "ricmac",
  "in_reply_to_user_id_str" : "105895323",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.605, -122.322667 ]
  },
  "id_str" : "54389195820630016",
  "text" : "8:36pm Looking at pictures of snail shells and generally bouncing around Wikipedia http://flic.kr/p/9vpt2R",
  "id" : 54389195820630016,
  "created_at" : "Sun Apr 03 03:46:09 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Fairbairn",
      "screen_name" : "jfairbairn",
      "indices" : [ 0, 11 ],
      "id_str" : "14250702",
      "id" : 14250702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "54332579146502144",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6148065067, -122.3200835772 ]
  },
  "id_str" : "54343280019767296",
  "in_reply_to_user_id" : 14250702,
  "text" : "@jfairbairn That sounds more like consciousness than life. Can you explain a bit more?",
  "id" : 54343280019767296,
  "in_reply_to_status_id" : 54332579146502144,
  "created_at" : "Sun Apr 03 00:43:42 +0000 2011",
  "in_reply_to_screen_name" : "jfairbairn",
  "in_reply_to_user_id_str" : "14250702",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "girl jo",
      "screen_name" : "octavekitten",
      "indices" : [ 0, 13 ],
      "id_str" : "16366882",
      "id" : 16366882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "54308253928144896",
  "geo" : {
  },
  "id_str" : "54308498548334592",
  "in_reply_to_user_id" : 16366882,
  "text" : "@octavekitten Yes, as smart as the smartest human.",
  "id" : 54308498548334592,
  "in_reply_to_status_id" : 54308253928144896,
  "created_at" : "Sat Apr 02 22:25:29 +0000 2011",
  "in_reply_to_screen_name" : "octavekitten",
  "in_reply_to_user_id_str" : "16366882",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "54304341082914816",
  "text" : "If cells could think, do you think they would think that the body/network of cells is alive?",
  "id" : 54304341082914816,
  "created_at" : "Sat Apr 02 22:08:58 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joey Feith",
      "screen_name" : "JoeyFeith",
      "indices" : [ 0, 10 ],
      "id_str" : "23084800",
      "id" : 23084800
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 67 ],
      "url" : "http://t.co/2LoDZl5",
      "expanded_url" : "http://healthmonth.com/users/logout",
      "display_url" : "healthmonth.com/users/logout"
    } ]
  },
  "in_reply_to_status_id_str" : "54283385476091904",
  "geo" : {
  },
  "id_str" : "54283836397330433",
  "in_reply_to_user_id" : 23084800,
  "text" : "@JoeyFeith I can't reproduce... by try going to http://t.co/2LoDZl5 and let me know what happens.",
  "id" : 54283836397330433,
  "in_reply_to_status_id" : 54283385476091904,
  "created_at" : "Sat Apr 02 20:47:29 +0000 2011",
  "in_reply_to_screen_name" : "JoeyFeith",
  "in_reply_to_user_id_str" : "23084800",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joey Feith",
      "screen_name" : "JoeyFeith",
      "indices" : [ 0, 10 ],
      "id_str" : "23084800",
      "id" : 23084800
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "54281303813652480",
  "geo" : {
  },
  "id_str" : "54282974232969216",
  "in_reply_to_user_id" : 23084800,
  "text" : "@JoeyFeith And you're able to get to other sites on the internet? What's your username?",
  "id" : 54282974232969216,
  "in_reply_to_status_id" : 54281303813652480,
  "created_at" : "Sat Apr 02 20:44:04 +0000 2011",
  "in_reply_to_screen_name" : "JoeyFeith",
  "in_reply_to_user_id_str" : "23084800",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "elise o",
      "screen_name" : "elise81",
      "indices" : [ 0, 8 ],
      "id_str" : "14229651",
      "id" : 14229651
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 89 ],
      "url" : "http://t.co/0FN3dUW",
      "expanded_url" : "http://healthmonth.com/users/edit",
      "display_url" : "healthmonth.com/users/edit"
    } ]
  },
  "in_reply_to_status_id_str" : "54076328877629440",
  "geo" : {
  },
  "id_str" : "54076785800908800",
  "in_reply_to_user_id" : 14229651,
  "text" : "@elise81 Okay, fixed the rule. You can change the daily nudge hour at http://t.co/0FN3dUW",
  "id" : 54076785800908800,
  "in_reply_to_status_id" : 54076328877629440,
  "created_at" : "Sat Apr 02 07:04:45 +0000 2011",
  "in_reply_to_screen_name" : "elise81",
  "in_reply_to_user_id_str" : "14229651",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "elise o",
      "screen_name" : "elise81",
      "indices" : [ 0, 8 ],
      "id_str" : "14229651",
      "id" : 14229651
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "54075827113033728",
  "geo" : {
  },
  "id_str" : "54075970767958016",
  "in_reply_to_user_id" : 14229651,
  "text" : "@elise81 Did it just change, or was it like that all month?",
  "id" : 54075970767958016,
  "in_reply_to_status_id" : 54075827113033728,
  "created_at" : "Sat Apr 02 07:01:30 +0000 2011",
  "in_reply_to_screen_name" : "elise81",
  "in_reply_to_user_id_str" : "14229651",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "elise o",
      "screen_name" : "elise81",
      "indices" : [ 0, 8 ],
      "id_str" : "14229651",
      "id" : 14229651
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "54074540967477248",
  "geo" : {
  },
  "id_str" : "54074776829956097",
  "in_reply_to_user_id" : 14229651,
  "text" : "@elise81 Definitely in the plan... but might be a month or two to get it done right.",
  "id" : 54074776829956097,
  "in_reply_to_status_id" : 54074540967477248,
  "created_at" : "Sat Apr 02 06:56:46 +0000 2011",
  "in_reply_to_screen_name" : "elise81",
  "in_reply_to_user_id_str" : "14229651",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "elise o",
      "screen_name" : "elise81",
      "indices" : [ 0, 8 ],
      "id_str" : "14229651",
      "id" : 14229651
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "54073875297861633",
  "geo" : {
  },
  "id_str" : "54074086258786304",
  "in_reply_to_user_id" : 14229651,
  "text" : "@elise81 Have you been tracking drinks? It might be a bug...",
  "id" : 54074086258786304,
  "in_reply_to_status_id" : 54073875297861633,
  "created_at" : "Sat Apr 02 06:54:01 +0000 2011",
  "in_reply_to_screen_name" : "elise81",
  "in_reply_to_user_id_str" : "14229651",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "elise o",
      "screen_name" : "elise81",
      "indices" : [ 0, 8 ],
      "id_str" : "14229651",
      "id" : 14229651
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "54060580226596864",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6049791608, -122.3227203262 ]
  },
  "id_str" : "54072270913667072",
  "in_reply_to_user_id" : 14229651,
  "text" : "@elise81 Ha, nothing wrong with 11.8! But I hear ya on allowing some preferences to make things private.",
  "id" : 54072270913667072,
  "in_reply_to_status_id" : 54060580226596864,
  "created_at" : "Sat Apr 02 06:46:48 +0000 2011",
  "in_reply_to_screen_name" : "elise81",
  "in_reply_to_user_id_str" : "14229651",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arielis Talavera",
      "screen_name" : "ArielisT",
      "indices" : [ 0, 9 ],
      "id_str" : "1163522401",
      "id" : 1163522401
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "54029413502828544",
  "text" : "@arielist We were just saying the same thing. The whole family is stipey today too! :)",
  "id" : 54029413502828544,
  "created_at" : "Sat Apr 02 03:56:30 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.605, -122.322834 ]
  },
  "id_str" : "54025038835355648",
  "text" : "8:36pm Niko story bedtime http://flic.kr/p/9vcPtG",
  "id" : 54025038835355648,
  "created_at" : "Sat Apr 02 03:39:07 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jordan Dailey",
      "screen_name" : "jordychristine",
      "indices" : [ 0, 15 ],
      "id_str" : "5624752",
      "id" : 5624752
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "54004741939802112",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6051043571, -122.3226278688 ]
  },
  "id_str" : "54009285725786112",
  "in_reply_to_user_id" : 5624752,
  "text" : "@jordychristine What's your username?",
  "id" : 54009285725786112,
  "in_reply_to_status_id" : 54004741939802112,
  "created_at" : "Sat Apr 02 02:36:31 +0000 2011",
  "in_reply_to_screen_name" : "jordychristine",
  "in_reply_to_user_id_str" : "5624752",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Cheng",
      "screen_name" : "k",
      "indices" : [ 0, 2 ],
      "id_str" : "11222",
      "id" : 11222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "53928498078814208",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6049645542, -122.3229333508 ]
  },
  "id_str" : "53983363039633409",
  "in_reply_to_user_id" : 11222,
  "text" : "@k Cool! Gets a mention where?",
  "id" : 53983363039633409,
  "in_reply_to_status_id" : 53928498078814208,
  "created_at" : "Sat Apr 02 00:53:31 +0000 2011",
  "in_reply_to_screen_name" : "k",
  "in_reply_to_user_id_str" : "11222",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
} ]