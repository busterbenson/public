Grailbird.data.tweets_2011_11 = 
 [ {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gregory Heller",
      "screen_name" : "gregoryheller",
      "indices" : [ 0, 14 ],
      "id_str" : "9973542",
      "id" : 9973542
    }, {
      "name" : "Jawbone",
      "screen_name" : "Jawbone",
      "indices" : [ 20, 28 ],
      "id_str" : "26276396",
      "id" : 26276396
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "142131772770103296",
  "geo" : {
  },
  "id_str" : "142132115763494912",
  "in_reply_to_user_id" : 9973542,
  "text" : "@gregoryheller Once @jawbone UP has an API, I'm sure places like the Health Graph API will aggregate them all together, right?",
  "id" : 142132115763494912,
  "in_reply_to_status_id" : 142131772770103296,
  "created_at" : "Thu Dec 01 06:45:11 +0000 2011",
  "in_reply_to_screen_name" : "gregoryheller",
  "in_reply_to_user_id_str" : "9973542",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jawbone",
      "screen_name" : "Jawbone",
      "indices" : [ 19, 27 ],
      "id_str" : "26276396",
      "id" : 26276396
    }, {
      "name" : "Path",
      "screen_name" : "path",
      "indices" : [ 41, 46 ],
      "id_str" : "106333951",
      "id" : 106333951
    }, {
      "name" : "Alexia Tsotsis",
      "screen_name" : "alexia",
      "indices" : [ 104, 111 ],
      "id_str" : "18327902",
      "id" : 18327902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 99 ],
      "url" : "http://t.co/VKRi2OtZ",
      "expanded_url" : "http://techcrunch.com/2011/11/30/path-and-jawbone-up-should-band-together/",
      "display_url" : "techcrunch.com/2011/11/30/pat…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "142131528930050048",
  "text" : "Totally agree that @jawbone UP + the new @path 2.0 would be pretty dang nifty. http://t.co/VKRi2OtZ /by @alexia",
  "id" : 142131528930050048,
  "created_at" : "Thu Dec 01 06:42:51 +0000 2011",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 72 ],
      "url" : "http://t.co/jBUQHTC1",
      "expanded_url" : "http://flic.kr/p/aNBvbH",
      "display_url" : "flic.kr/p/aNBvbH"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.613, -122.316667 ]
  },
  "id_str" : "142104566291369984",
  "text" : "8:36pm Walking home, found the mayor of this corner http://t.co/jBUQHTC1",
  "id" : 142104566291369984,
  "created_at" : "Thu Dec 01 04:55:43 +0000 2011",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 0, 9 ],
      "id_str" : "761628",
      "id" : 761628
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "141728227881267201",
  "geo" : {
  },
  "id_str" : "141946678121988096",
  "in_reply_to_user_id" : 761628,
  "text" : "@RickWebb Yes, I believe so.",
  "id" : 141946678121988096,
  "in_reply_to_status_id" : 141728227881267201,
  "created_at" : "Wed Nov 30 18:28:19 +0000 2011",
  "in_reply_to_screen_name" : "RickWebb",
  "in_reply_to_user_id_str" : "761628",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://path.com/\" rel=\"nofollow\">Path 2.0</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 90 ],
      "url" : "http://t.co/TNSxkeeM",
      "expanded_url" : "http://path.com/p/46Zl6M",
      "display_url" : "path.com/p/46Zl6M"
    } ]
  },
  "geo" : {
  },
  "id_str" : "141925408382795776",
  "text" : "Testing photos. They really did crib every top app out at the moment. http://t.co/TNSxkeeM",
  "id" : 141925408382795776,
  "created_at" : "Wed Nov 30 17:03:48 +0000 2011",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://path.com/\" rel=\"nofollow\">Path 2.0</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 38 ],
      "url" : "http://t.co/n5soOio3",
      "expanded_url" : "http://path.com/p/1JGBno",
      "display_url" : "path.com/p/1JGBno"
    } ]
  },
  "geo" : {
  },
  "id_str" : "141906117553958912",
  "text" : "New morning song. http://t.co/n5soOio3",
  "id" : 141906117553958912,
  "created_at" : "Wed Nov 30 15:47:09 +0000 2011",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://path.com/\" rel=\"nofollow\">Path 2.0</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 104 ],
      "url" : "http://t.co/ckC6GEvq",
      "expanded_url" : "http://path.com/p/2Tfk6E",
      "display_url" : "path.com/p/2Tfk6E"
    } ]
  },
  "geo" : {
  },
  "id_str" : "141905476098064384",
  "text" : "I'm gonna hit my Path friend wall pretty soon here. Then things are gonna get ugly! http://t.co/ckC6GEvq",
  "id" : 141905476098064384,
  "created_at" : "Wed Nov 30 15:44:36 +0000 2011",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Foursquare",
      "screen_name" : "foursquare",
      "indices" : [ 37, 48 ],
      "id_str" : "14120151",
      "id" : 14120151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 84 ],
      "url" : "http://t.co/yfaLZv6z",
      "expanded_url" : "http://4sq.com/tL5N1d",
      "display_url" : "4sq.com/tL5N1d"
    } ]
  },
  "geo" : {
  },
  "id_str" : "141726443817279488",
  "text" : "I just unlocked the \"Bento\" badge on @foursquare! Irasshaimase! http://t.co/yfaLZv6z",
  "id" : 141726443817279488,
  "created_at" : "Wed Nov 30 03:53:12 +0000 2011",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "matt binkowski",
      "screen_name" : "mattbinkowski",
      "indices" : [ 3, 17 ],
      "id_str" : "10250742",
      "id" : 10250742
    }, {
      "name" : "Buster Benson",
      "screen_name" : "busterbenson",
      "indices" : [ 19, 32 ],
      "id_str" : "2185",
      "id" : 2185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "141676055818805248",
  "text" : "RT @mattbinkowski: @busterbenson Nice personal site! Funny how your Google Map in street view has pins scattered all over your yard. :-) ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Buster Benson",
        "screen_name" : "busterbenson",
        "indices" : [ 0, 13 ],
        "id_str" : "2185",
        "id" : 2185
      } ],
      "media" : [ {
        "expanded_url" : "http://twitter.com/mattbinkowski/status/141639779602280448/photo/1",
        "indices" : [ 118, 138 ],
        "url" : "http://t.co/pLpVoOh4",
        "media_url" : "http://pbs.twimg.com/media/Afc0oQ2CMAESskc.jpg",
        "id_str" : "141639779606474753",
        "id" : 141639779606474753,
        "media_url_https" : "https://pbs.twimg.com/media/Afc0oQ2CMAESskc.jpg",
        "sizes" : [ {
          "h" : 407,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 752
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 752
        }, {
          "h" : 231,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com/pLpVoOh4"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "141639779602280448",
    "in_reply_to_user_id" : 2185,
    "text" : "@busterbenson Nice personal site! Funny how your Google Map in street view has pins scattered all over your yard. :-) http://t.co/pLpVoOh4",
    "id" : 141639779602280448,
    "created_at" : "Tue Nov 29 22:08:50 +0000 2011",
    "in_reply_to_screen_name" : "busterbenson",
    "in_reply_to_user_id_str" : "2185",
    "user" : {
      "name" : "matt binkowski",
      "screen_name" : "mattbinkowski",
      "protected" : false,
      "id_str" : "10250742",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2461251424/image_normal.jpg",
      "id" : 10250742,
      "verified" : false
    }
  },
  "id" : 141676055818805248,
  "created_at" : "Wed Nov 30 00:32:58 +0000 2011",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "matt binkowski",
      "screen_name" : "mattbinkowski",
      "indices" : [ 0, 14 ],
      "id_str" : "10250742",
      "id" : 10250742
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "141639779602280448",
  "geo" : {
  },
  "id_str" : "141655128120893440",
  "in_reply_to_user_id" : 10250742,
  "text" : "@mattbinkowski That's really funny.  Makes it seem like I pace around a lot, tweeting, doesn't it?",
  "id" : 141655128120893440,
  "in_reply_to_status_id" : 141639779602280448,
  "created_at" : "Tue Nov 29 23:09:49 +0000 2011",
  "in_reply_to_screen_name" : "mattbinkowski",
  "in_reply_to_user_id_str" : "10250742",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kottke.org",
      "screen_name" : "kottke",
      "indices" : [ 57, 64 ],
      "id_str" : "14120215",
      "id" : 14120215
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http://t.co/nbGAfcwV",
      "expanded_url" : "http://kottke.org/x/4q75",
      "display_url" : "kottke.org/x/4q75"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6085241234, -122.3059776526 ]
  },
  "id_str" : "141543273587159040",
  "text" : "Little Printer is meant to be loved. Watch the video! RT @kottke: Little Printer publishes tiny personal newspapers http://t.co/nbGAfcwV",
  "id" : 141543273587159040,
  "created_at" : "Tue Nov 29 15:45:20 +0000 2011",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "141392547686793216",
  "text" : "For the record, I follow 1100 and probably only read 5-10% of my tweets. Interesting to think about different breeds of completionists.",
  "id" : 141392547686793216,
  "created_at" : "Tue Nov 29 05:46:24 +0000 2011",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ali Berman",
      "screen_name" : "spangley",
      "indices" : [ 0, 9 ],
      "id_str" : "776429",
      "id" : 776429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "141391498552950784",
  "geo" : {
  },
  "id_str" : "141392290362036224",
  "in_reply_to_user_id" : 776429,
  "text" : "@spangley I do the same thing!",
  "id" : 141392290362036224,
  "in_reply_to_status_id" : 141391498552950784,
  "created_at" : "Tue Nov 29 05:45:23 +0000 2011",
  "in_reply_to_screen_name" : "spangley",
  "in_reply_to_user_id_str" : "776429",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "141390877993074688",
  "text" : "Then again, there's a bias in the answers. People who don't read all their tweets wouldn't have seen the question.",
  "id" : 141390877993074688,
  "created_at" : "Tue Nov 29 05:39:46 +0000 2011",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 53 ],
      "url" : "http://t.co/XzMzvAxs",
      "expanded_url" : "https://twitter.com/busterbenson/statuses/141218522490601473",
      "display_url" : "twitter.com/busterbenson/s…"
    }, {
      "indices" : [ 115, 135 ],
      "url" : "http://t.co/JVFc5I9y",
      "expanded_url" : "http://busterbenson.com/thinkup/post/?t=141218522490601473&n=twitter",
      "display_url" : "busterbenson.com/thinkup/post/?…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "141390747202105345",
  "text" : "Out of 36 replies to this tweet (http://t.co/XzMzvAxs), I'm surprised by how many people read all of their tweets: http://t.co/JVFc5I9y",
  "id" : 141390747202105345,
  "created_at" : "Tue Nov 29 05:39:15 +0000 2011",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 110 ],
      "url" : "http://t.co/kI2qGj8Y",
      "expanded_url" : "http://flic.kr/p/aMzR4x",
      "display_url" : "flic.kr/p/aMzR4x"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.608666, -122.306167 ]
  },
  "id_str" : "141379360899866624",
  "text" : "8:36pm I wish I had the energy to clean up toys but all I can do is drink a glass of wine http://t.co/kI2qGj8Y",
  "id" : 141379360899866624,
  "created_at" : "Tue Nov 29 04:54:00 +0000 2011",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aimee",
      "screen_name" : "LilHossler",
      "indices" : [ 0, 11 ],
      "id_str" : "123116307",
      "id" : 123116307
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "141245412047716352",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.608384579, -122.3061034443 ]
  },
  "id_str" : "141279889964793857",
  "in_reply_to_user_id" : 123116307,
  "text" : "@LilHossler Yup! He opens it for kids Mon and Thurs mornings.",
  "id" : 141279889964793857,
  "in_reply_to_status_id" : 141245412047716352,
  "created_at" : "Mon Nov 28 22:18:45 +0000 2011",
  "in_reply_to_screen_name" : "LilHossler",
  "in_reply_to_user_id_str" : "123116307",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HSofia",
      "screen_name" : "hsofia",
      "indices" : [ 0, 7 ],
      "id_str" : "14372614",
      "id" : 14372614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "141239770876624897",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6085725963, -122.3060019755 ]
  },
  "id_str" : "141279717432111104",
  "in_reply_to_user_id" : 14372614,
  "text" : "@hsofia It's at this new indoor volleyball court in Georgetown. Mon and Thurs mornings. Is awesome for the kidlets!",
  "id" : 141279717432111104,
  "in_reply_to_status_id" : 141239770876624897,
  "created_at" : "Mon Nov 28 22:18:04 +0000 2011",
  "in_reply_to_screen_name" : "hsofia",
  "in_reply_to_user_id_str" : "14372614",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagr.am\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 118 ],
      "url" : "http://t.co/VSVidMGv",
      "expanded_url" : "http://instagr.am/p/WXWC2/",
      "display_url" : "instagr.am/p/WXWC2/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.549356, -122.317439 ]
  },
  "id_str" : "141239330512437248",
  "text" : "Seattle beaches are indoors and are turtleneck and overalls appropriate  @ The Sandbox Georgetown http://t.co/VSVidMGv",
  "id" : 141239330512437248,
  "created_at" : "Mon Nov 28 19:37:35 +0000 2011",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Dean",
      "screen_name" : "dandean",
      "indices" : [ 0, 8 ],
      "id_str" : "9525212",
      "id" : 9525212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "141220539694977024",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6086315146, -122.3060860382 ]
  },
  "id_str" : "141221698279190528",
  "in_reply_to_user_id" : 9525212,
  "text" : "@dandean Do you just eat them instead?",
  "id" : 141221698279190528,
  "in_reply_to_status_id" : 141220539694977024,
  "created_at" : "Mon Nov 28 18:27:31 +0000 2011",
  "in_reply_to_screen_name" : "dandean",
  "in_reply_to_user_id_str" : "9525212",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Meredith Modzelewski",
      "screen_name" : "meredithmo",
      "indices" : [ 0, 11 ],
      "id_str" : "17069950",
      "id" : 17069950
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "141218452923887617",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6085224076, -122.3059652981 ]
  },
  "id_str" : "141220009958584321",
  "in_reply_to_user_id" : 17069950,
  "text" : "@meredithmo Funny. I had the same question about Black Friday! And call me old fashioned but I like the word cyber. :)",
  "id" : 141220009958584321,
  "in_reply_to_status_id" : 141218452923887617,
  "created_at" : "Mon Nov 28 18:20:48 +0000 2011",
  "in_reply_to_screen_name" : "meredithmo",
  "in_reply_to_user_id_str" : "17069950",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.608572945, -122.305959148 ]
  },
  "id_str" : "141218522490601473",
  "text" : "What percentage of tweets in your stream do you think you read? And how many people do you follow?",
  "id" : 141218522490601473,
  "created_at" : "Mon Nov 28 18:14:54 +0000 2011",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael McDaniel",
      "screen_name" : "michaelmcdaniel",
      "indices" : [ 0, 16 ],
      "id_str" : "7565162",
      "id" : 7565162
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "141205440204771328",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6086387282, -122.3060447152 ]
  },
  "id_str" : "141217625328979968",
  "in_reply_to_user_id" : 7565162,
  "text" : "@michaelmcdaniel Then why focus on electronics but not books, magazines, sleeping, etc?",
  "id" : 141217625328979968,
  "in_reply_to_status_id" : 141205440204771328,
  "created_at" : "Mon Nov 28 18:11:20 +0000 2011",
  "in_reply_to_screen_name" : "michaelmcdaniel",
  "in_reply_to_user_id_str" : "7565162",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Bilton",
      "screen_name" : "nickbilton",
      "indices" : [ 18, 29 ],
      "id_str" : "1586501",
      "id" : 1586501
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 139 ],
      "url" : "http://t.co/gHxZ5k5W",
      "expanded_url" : "http://nyti.ms/tZSDYN",
      "display_url" : "nyti.ms/tZSDYN"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6084590957, -122.3058641214 ]
  },
  "id_str" : "141192504400809984",
  "text" : "I don't do it. RT @nickbilton: Disruptions: Fliers still must turn off devices before flights, but It's not clear why. http://t.co/gHxZ5k5W",
  "id" : 141192504400809984,
  "created_at" : "Mon Nov 28 16:31:30 +0000 2011",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 73 ],
      "url" : "http://t.co/CoyD0Lkd",
      "expanded_url" : "http://flic.kr/p/aM33u4",
      "display_url" : "flic.kr/p/aM33u4"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.608666, -122.306 ]
  },
  "id_str" : "141038924662456320",
  "text" : "8:36pm Trying not to eat all of this truffle popcorn http://t.co/CoyD0Lkd",
  "id" : 141038924662456320,
  "created_at" : "Mon Nov 28 06:21:14 +0000 2011",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chaim Krause",
      "screen_name" : "tinjaw",
      "indices" : [ 0, 7 ],
      "id_str" : "9732022",
      "id" : 9732022
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "140778866653401088",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6085961793, -122.3062764734 ]
  },
  "id_str" : "140855469823635456",
  "in_reply_to_user_id" : 9732022,
  "text" : "@tinjaw Thank you! And please do steal it. :)",
  "id" : 140855469823635456,
  "in_reply_to_status_id" : 140778866653401088,
  "created_at" : "Sun Nov 27 18:12:15 +0000 2011",
  "in_reply_to_screen_name" : "tinjaw",
  "in_reply_to_user_id_str" : "9732022",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 62 ],
      "url" : "http://t.co/bOgB6u4u",
      "expanded_url" : "http://flic.kr/p/aLnzcv",
      "display_url" : "flic.kr/p/aLnzcv"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.614, -122.316 ]
  },
  "id_str" : "140651157231124480",
  "text" : "8:36pm Walking home. Excited about stuff. http://t.co/bOgB6u4u",
  "id" : 140651157231124480,
  "created_at" : "Sun Nov 27 04:40:23 +0000 2011",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.apple.com\" rel=\"nofollow\">Safari on iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 81 ],
      "url" : "http://t.co/BSW4LVRz",
      "expanded_url" : "http://m.wired.com/magazine/2011/11/mf_bitcoin/all/1",
      "display_url" : "m.wired.com/magazine/2011/…"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.608629, -122.306165 ]
  },
  "id_str" : "140496527268392961",
  "text" : "The rise and fall (or rather dip, in my opinion) of bitcoin: http://t.co/BSW4LVRz",
  "id" : 140496527268392961,
  "created_at" : "Sat Nov 26 18:25:57 +0000 2011",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 62 ],
      "url" : "http://t.co/R91AGnGm",
      "expanded_url" : "http://flic.kr/p/aKS6v8",
      "display_url" : "flic.kr/p/aKS6v8"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.608666, -122.306 ]
  },
  "id_str" : "140301188829683713",
  "text" : "8:36pm Reading Redirect in bed with Sopor http://t.co/R91AGnGm",
  "id" : 140301188829683713,
  "created_at" : "Sat Nov 26 05:29:44 +0000 2011",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Foursquare",
      "screen_name" : "foursquare",
      "indices" : [ 51, 62 ],
      "id_str" : "14120151",
      "id" : 14120151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 101 ],
      "url" : "http://t.co/4ibibCuR",
      "expanded_url" : "http://4sq.com/uUAtuL",
      "display_url" : "4sq.com/uUAtuL"
    } ]
  },
  "geo" : {
  },
  "id_str" : "140235087710126080",
  "text" : "I just unlocked the Level 2 \"Monkey Bars\" badge on @foursquare! In it to win it! http://t.co/4ibibCuR",
  "id" : 140235087710126080,
  "created_at" : "Sat Nov 26 01:07:05 +0000 2011",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 78 ],
      "url" : "http://t.co/wpSTPtJg",
      "expanded_url" : "http://flic.kr/p/aKo9Xe",
      "display_url" : "flic.kr/p/aKo9Xe"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.608666, -122.306 ]
  },
  "id_str" : "139927830422233088",
  "text" : "8:36pm Talking about contagious diseases post dinner coma http://t.co/wpSTPtJg",
  "id" : 139927830422233088,
  "created_at" : "Fri Nov 25 04:46:09 +0000 2011",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagr.am\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 56 ],
      "url" : "http://t.co/6jhdnZId",
      "expanded_url" : "http://instagr.am/p/VsMnL/",
      "display_url" : "instagr.am/p/VsMnL/"
    } ]
  },
  "geo" : {
  },
  "id_str" : "139866755177775104",
  "text" : "Turkeygram with guilty-looking dude http://t.co/6jhdnZId",
  "id" : 139866755177775104,
  "created_at" : "Fri Nov 25 00:43:27 +0000 2011",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "139797104838184961",
  "text" : "Everyone! Mad Men marathon! It's on Netflix Instant. Starting from the beginning…",
  "id" : 139797104838184961,
  "created_at" : "Thu Nov 24 20:06:41 +0000 2011",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Health Month",
      "screen_name" : "healthmonth",
      "indices" : [ 3, 15 ],
      "id_str" : "154236895",
      "id" : 154236895
    }, {
      "name" : "Habit Labs",
      "screen_name" : "habitlabs",
      "indices" : [ 41, 51 ],
      "id_str" : "250986038",
      "id" : 250986038
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 73 ],
      "url" : "http://t.co/OVY5im8h",
      "expanded_url" : "http://healthmonth.tumblr.com/post/13264785569/happy-thanksgiving-from-habit-labs",
      "display_url" : "healthmonth.tumblr.com/post/132647855…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "139796079351840768",
  "text" : "RT @healthmonth: Happy Thanksgiving from @habitlabs! http://t.co/OVY5im8h",
  "retweeted_status" : {
    "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Habit Labs",
        "screen_name" : "habitlabs",
        "indices" : [ 24, 34 ],
        "id_str" : "250986038",
        "id" : 250986038
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 36, 56 ],
        "url" : "http://t.co/OVY5im8h",
        "expanded_url" : "http://healthmonth.tumblr.com/post/13264785569/happy-thanksgiving-from-habit-labs",
        "display_url" : "healthmonth.tumblr.com/post/132647855…"
      } ]
    },
    "geo" : {
    },
    "id_str" : "139795913634873344",
    "text" : "Happy Thanksgiving from @habitlabs! http://t.co/OVY5im8h",
    "id" : 139795913634873344,
    "created_at" : "Thu Nov 24 20:01:57 +0000 2011",
    "user" : {
      "name" : "Health Month",
      "screen_name" : "healthmonth",
      "protected" : false,
      "id_str" : "154236895",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1136999397/track_meals.400_normal.png",
      "id" : 154236895,
      "verified" : false
    }
  },
  "id" : 139796079351840768,
  "created_at" : "Thu Nov 24 20:02:37 +0000 2011",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "139757584650469376",
  "text" : "Does anyone else associate Thanksgiving with Twilight Zone marathons? What's the equivalent in this Hulu age? Flipper?",
  "id" : 139757584650469376,
  "created_at" : "Thu Nov 24 17:29:39 +0000 2011",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 103 ],
      "url" : "http://t.co/W80adgCt",
      "expanded_url" : "http://flic.kr/p/aJVjKn",
      "display_url" : "flic.kr/p/aJVjKn"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.608666, -122.306167 ]
  },
  "id_str" : "139563924252139521",
  "text" : "8:36pm Mom taught us how to make sushi for the Nth time. Might remember this time! http://t.co/W80adgCt",
  "id" : 139563924252139521,
  "created_at" : "Thu Nov 24 04:40:07 +0000 2011",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagr.am\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 96 ],
      "url" : "http://t.co/92VDT4j8",
      "expanded_url" : "http://instagr.am/p/VgCMh/",
      "display_url" : "instagr.am/p/VgCMh/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.619087, -122.350713015 ]
  },
  "id_str" : "139502821342064641",
  "text" : "Remind me to come here more often during winter  @ Tropical Butterfly House http://t.co/92VDT4j8",
  "id" : 139502821342064641,
  "created_at" : "Thu Nov 24 00:37:19 +0000 2011",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ted Roden",
      "screen_name" : "tedroden",
      "indices" : [ 0, 9 ],
      "id_str" : "822858",
      "id" : 822858
    }, {
      "name" : "Alex Rainert",
      "screen_name" : "arainert",
      "indices" : [ 10, 19 ],
      "id_str" : "7482",
      "id" : 7482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "139352278074277888",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6086216056, -122.3060966124 ]
  },
  "id_str" : "139387848540438529",
  "in_reply_to_user_id" : 822858,
  "text" : "@tedroden @arainert Busted! I was sort of reveling in the fact that nobody could know it was me.",
  "id" : 139387848540438529,
  "in_reply_to_status_id" : 139352278074277888,
  "created_at" : "Wed Nov 23 17:00:27 +0000 2011",
  "in_reply_to_screen_name" : "tedroden",
  "in_reply_to_user_id_str" : "822858",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Hagel",
      "screen_name" : "jhagel",
      "indices" : [ 3, 10 ],
      "id_str" : "14076943",
      "id" : 14076943
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 91 ],
      "url" : "http://t.co/NmgGoQMO",
      "expanded_url" : "http://nyr.kr/utTnjW",
      "display_url" : "nyr.kr/utTnjW"
    } ]
  },
  "geo" : {
  },
  "id_str" : "139323107478478848",
  "text" : "RT @jhagel: In a more rapidly changing world, we will all need coaches http://t.co/NmgGoQMO",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 59, 79 ],
        "url" : "http://t.co/NmgGoQMO",
        "expanded_url" : "http://nyr.kr/utTnjW",
        "display_url" : "nyr.kr/utTnjW"
      } ]
    },
    "geo" : {
    },
    "id_str" : "139312937004314624",
    "text" : "In a more rapidly changing world, we will all need coaches http://t.co/NmgGoQMO",
    "id" : 139312937004314624,
    "created_at" : "Wed Nov 23 12:02:47 +0000 2011",
    "user" : {
      "name" : "John Hagel",
      "screen_name" : "jhagel",
      "protected" : false,
      "id_str" : "14076943",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/60658775/Photos_John1_normal.jpg",
      "id" : 14076943,
      "verified" : false
    }
  },
  "id" : 139323107478478848,
  "created_at" : "Wed Nov 23 12:43:11 +0000 2011",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Doerr",
      "screen_name" : "johndoerr",
      "indices" : [ 3, 13 ],
      "id_str" : "22255654",
      "id" : 22255654
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 84 ],
      "url" : "http://t.co/3gIpZDZy",
      "expanded_url" : "http://nyti.ms/u3W9CO",
      "display_url" : "nyti.ms/u3W9CO"
    } ]
  },
  "geo" : {
  },
  "id_str" : "139319278846488577",
  "text" : "RT @johndoerr: A Serving of Gratitude Brings Healthy Dividends: http://t.co/3gIpZDZy",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 49, 69 ],
        "url" : "http://t.co/3gIpZDZy",
        "expanded_url" : "http://nyti.ms/u3W9CO",
        "display_url" : "nyti.ms/u3W9CO"
      } ]
    },
    "geo" : {
    },
    "id_str" : "139302212466786304",
    "text" : "A Serving of Gratitude Brings Healthy Dividends: http://t.co/3gIpZDZy",
    "id" : 139302212466786304,
    "created_at" : "Wed Nov 23 11:20:10 +0000 2011",
    "user" : {
      "name" : "John Doerr",
      "screen_name" : "johndoerr",
      "protected" : false,
      "id_str" : "22255654",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/893560287/John_Doerr_normal.jpg",
      "id" : 22255654,
      "verified" : false
    }
  },
  "id" : 139319278846488577,
  "created_at" : "Wed Nov 23 12:27:59 +0000 2011",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flout.heroku.com\" rel=\"nofollow\">My Flout</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Flout",
      "screen_name" : "floutdotme",
      "indices" : [ 28, 39 ],
      "id_str" : "418441310",
      "id" : 418441310
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 74 ],
      "url" : "http://t.co/hpG7xmYl",
      "expanded_url" : "http://flout.me",
      "display_url" : "flout.me"
    } ]
  },
  "geo" : {
  },
  "id_str" : "139317965924466688",
  "text" : "Wow, My Flout score is 3 on @floutdotme! Get yours at http://t.co/hpG7xmYl",
  "id" : 139317965924466688,
  "created_at" : "Wed Nov 23 12:22:46 +0000 2011",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.apple.com\" rel=\"nofollow\">Safari on iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 75 ],
      "url" : "http://t.co/Hv92WU29",
      "expanded_url" : "http://knowyourmeme.com/memes/pepper-spray-cop-casually-pepper-spray-everything-cop",
      "display_url" : "knowyourmeme.com/memes/pepper-s…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "139299559741468672",
  "text" : "Know your meme: Casually Pepper Spray Everything Cop.  http://t.co/Hv92WU29",
  "id" : 139299559741468672,
  "created_at" : "Wed Nov 23 11:09:37 +0000 2011",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 7, 17 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 97 ],
      "url" : "http://t.co/13y9SpsT",
      "expanded_url" : "http://flic.kr/p/aJqnyX",
      "display_url" : "flic.kr/p/aJqnyX"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.615166, -122.320167 ]
  },
  "id_str" : "139204256799522817",
  "text" : "8:36pm @kellianne teaching my mom, sister, and niece the infamous cork trick http://t.co/13y9SpsT",
  "id" : 139204256799522817,
  "created_at" : "Wed Nov 23 04:50:55 +0000 2011",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Snyder",
      "screen_name" : "smoochbelly",
      "indices" : [ 0, 12 ],
      "id_str" : "17288565",
      "id" : 17288565
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "139082595760738305",
  "geo" : {
  },
  "id_str" : "139082774370975744",
  "in_reply_to_user_id" : 17288565,
  "text" : "@smoochbelly You're very welcome! How did you find it, if I may ask?",
  "id" : 139082774370975744,
  "in_reply_to_status_id" : 139082595760738305,
  "created_at" : "Tue Nov 22 20:48:12 +0000 2011",
  "in_reply_to_screen_name" : "smoochbelly",
  "in_reply_to_user_id_str" : "17288565",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Estelle Weyl",
      "screen_name" : "estellevw",
      "indices" : [ 3, 13 ],
      "id_str" : "6320592",
      "id" : 6320592
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "138886519082598401",
  "text" : "RT @estellevw: For those of you visiting relatives for Thanksgiving, can you do all us web developers a favor? Please update their brows ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "138789476259463168",
    "text" : "For those of you visiting relatives for Thanksgiving, can you do all us web developers a favor? Please update their browsers. Thanks!",
    "id" : 138789476259463168,
    "created_at" : "Tue Nov 22 01:22:44 +0000 2011",
    "user" : {
      "name" : "Estelle Weyl",
      "screen_name" : "estellevw",
      "protected" : false,
      "id_str" : "6320592",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1811754324/estelle_normal.jpg",
      "id" : 6320592,
      "verified" : false
    }
  },
  "id" : 138886519082598401,
  "created_at" : "Tue Nov 22 07:48:21 +0000 2011",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amelia Greenhall",
      "screen_name" : "ameliagreenhall",
      "indices" : [ 48, 64 ],
      "id_str" : "246531241",
      "id" : 246531241
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 85 ],
      "url" : "http://t.co/yxld6icE",
      "expanded_url" : "http://flic.kr/p/aHT638",
      "display_url" : "flic.kr/p/aHT638"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6085, -122.305834 ]
  },
  "id_str" : "138839558648365056",
  "text" : "8:36pm Coming for seconds of Mexican dinner /cc @ameliagreenhall http://t.co/yxld6icE",
  "id" : 138839558648365056,
  "created_at" : "Tue Nov 22 04:41:44 +0000 2011",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "josh",
      "screen_name" : "joshc",
      "indices" : [ 0, 6 ],
      "id_str" : "2015",
      "id" : 2015
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "138769663151718400",
  "geo" : {
  },
  "id_str" : "138770325084176384",
  "in_reply_to_user_id" : 2015,
  "text" : "@joshc And that is why I like it. Especially the iPhone 5 bit.",
  "id" : 138770325084176384,
  "in_reply_to_status_id" : 138769663151718400,
  "created_at" : "Tue Nov 22 00:06:38 +0000 2011",
  "in_reply_to_screen_name" : "joshc",
  "in_reply_to_user_id_str" : "2015",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian G. Fay",
      "screen_name" : "brianfay",
      "indices" : [ 0, 9 ],
      "id_str" : "15257124",
      "id" : 15257124
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "138746452695457794",
  "geo" : {
  },
  "id_str" : "138746765536010242",
  "in_reply_to_user_id" : 15257124,
  "text" : "@brianfay Without a ton of exceptions, it would be impossible for me too. If you wanna be more hardcore though, go for it!  :)",
  "id" : 138746765536010242,
  "in_reply_to_status_id" : 138746452695457794,
  "created_at" : "Mon Nov 21 22:33:01 +0000 2011",
  "in_reply_to_screen_name" : "brianfay",
  "in_reply_to_user_id_str" : "15257124",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Bonner",
      "screen_name" : "seanbonner",
      "indices" : [ 43, 54 ],
      "id_str" : "765",
      "id" : 765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 111 ],
      "url" : "http://t.co/TpgxDL7i",
      "expanded_url" : "http://blog.seanbonner.com/2011/11/21/progression-through-unowning/",
      "display_url" : "blog.seanbonner.com/2011/11/21/pro…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "138741141263761409",
  "text" : "This sounds awesome. I might do it too! RT @seanbonner: I'm not buying any stuff in 2012 - http://t.co/TpgxDL7i",
  "id" : 138741141263761409,
  "created_at" : "Mon Nov 21 22:10:40 +0000 2011",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "maggim",
      "screen_name" : "maggim",
      "indices" : [ 0, 7 ],
      "id_str" : "14290242",
      "id" : 14290242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "138685357511278593",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6086967267, -122.305990942 ]
  },
  "id_str" : "138693209936240641",
  "in_reply_to_user_id" : 14290242,
  "text" : "@maggim Same formula. Or maybe it would be better to think of it on a per-meal basis.",
  "id" : 138693209936240641,
  "in_reply_to_status_id" : 138685357511278593,
  "created_at" : "Mon Nov 21 19:00:12 +0000 2011",
  "in_reply_to_screen_name" : "maggim",
  "in_reply_to_user_id_str" : "14290242",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "maggim",
      "screen_name" : "maggim",
      "indices" : [ 0, 7 ],
      "id_str" : "14290242",
      "id" : 14290242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "138684231642644481",
  "geo" : {
  },
  "id_str" : "138684538409857025",
  "in_reply_to_user_id" : 14290242,
  "text" : "@maggim That means you'll get most of your food for free! :)",
  "id" : 138684538409857025,
  "in_reply_to_status_id" : 138684231642644481,
  "created_at" : "Mon Nov 21 18:25:45 +0000 2011",
  "in_reply_to_screen_name" : "maggim",
  "in_reply_to_user_id_str" : "14290242",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jayne rowney",
      "screen_name" : "haikugirl",
      "indices" : [ 0, 10 ],
      "id_str" : "580262124",
      "id" : 580262124
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "138678183733116928",
  "geo" : {
  },
  "id_str" : "138680757823614978",
  "in_reply_to_user_id" : 12761252,
  "text" : "@haikugirl What costs a lot but has no calories?",
  "id" : 138680757823614978,
  "in_reply_to_status_id" : 138678183733116928,
  "created_at" : "Mon Nov 21 18:10:43 +0000 2011",
  "in_reply_to_screen_name" : "heatherquintal",
  "in_reply_to_user_id_str" : "12761252",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "maggim",
      "screen_name" : "maggim",
      "indices" : [ 0, 7 ],
      "id_str" : "14290242",
      "id" : 14290242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "138680400431165440",
  "geo" : {
  },
  "id_str" : "138680633315692545",
  "in_reply_to_user_id" : 14290242,
  "text" : "@maggim I mean that whatever you buy, the price is determined by sugar and bad fat content. To help show what's healthy/not.",
  "id" : 138680633315692545,
  "in_reply_to_status_id" : 138680400431165440,
  "created_at" : "Mon Nov 21 18:10:14 +0000 2011",
  "in_reply_to_screen_name" : "maggim",
  "in_reply_to_user_id_str" : "14290242",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "138673266545012737",
  "text" : "What if food cost $.01/g of sugar, $.04/g of saturated fat, and $1.00/g of trans fat regardless of weight/calories/etc?",
  "id" : 138673266545012737,
  "created_at" : "Mon Nov 21 17:40:57 +0000 2011",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elizabeth Grigg",
      "screen_name" : "egrigg9000",
      "indices" : [ 0, 11 ],
      "id_str" : "820129",
      "id" : 820129
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "138641227678629891",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6085052335, -122.3058723351 ]
  },
  "id_str" : "138643148485304320",
  "in_reply_to_user_id" : 820129,
  "text" : "@egrigg9000 This is true!",
  "id" : 138643148485304320,
  "in_reply_to_status_id" : 138641227678629891,
  "created_at" : "Mon Nov 21 15:41:17 +0000 2011",
  "in_reply_to_screen_name" : "egrigg9000",
  "in_reply_to_user_id_str" : "820129",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Gibbons",
      "screen_name" : "JulieGibbons",
      "indices" : [ 0, 13 ],
      "id_str" : "4324361",
      "id" : 4324361
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "138538705316102144",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6084572986, -122.3057720552 ]
  },
  "id_str" : "138635855769243648",
  "in_reply_to_user_id" : 4324361,
  "text" : "@JulieGibbons Thank you! It's due for an update actually.",
  "id" : 138635855769243648,
  "in_reply_to_status_id" : 138538705316102144,
  "created_at" : "Mon Nov 21 15:12:18 +0000 2011",
  "in_reply_to_screen_name" : "JulieGibbons",
  "in_reply_to_user_id_str" : "4324361",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Carr",
      "screen_name" : "paulcarr",
      "indices" : [ 0, 9 ],
      "id_str" : "277245800",
      "id" : 277245800
    }, {
      "name" : "Jen S. McCabe",
      "screen_name" : "jensmccabe",
      "indices" : [ 47, 58 ],
      "id_str" : "14258044",
      "id" : 14258044
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "138513242350829569",
  "geo" : {
  },
  "id_str" : "138513444566597632",
  "in_reply_to_user_id" : 277245800,
  "text" : "@paulcarr If you're there now, you should meet @jensmccabe and give her some inside scoop.",
  "id" : 138513444566597632,
  "in_reply_to_status_id" : 138513242350829569,
  "created_at" : "Mon Nov 21 07:05:53 +0000 2011",
  "in_reply_to_screen_name" : "paulcarr",
  "in_reply_to_user_id_str" : "277245800",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Carr",
      "screen_name" : "paulcarr",
      "indices" : [ 0, 9 ],
      "id_str" : "277245800",
      "id" : 277245800
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "138512286804488192",
  "geo" : {
  },
  "id_str" : "138513116806922240",
  "in_reply_to_user_id" : 277245800,
  "text" : "@paulcarr Still loving Vegas? I might be joining you over there…",
  "id" : 138513116806922240,
  "in_reply_to_status_id" : 138512286804488192,
  "created_at" : "Mon Nov 21 07:04:35 +0000 2011",
  "in_reply_to_screen_name" : "paulcarr",
  "in_reply_to_user_id_str" : "277245800",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "138511807039025152",
  "text" : "Where can I sign up to talk about the guilt I have about not being able to answer all of my email?",
  "id" : 138511807039025152,
  "created_at" : "Mon Nov 21 06:59:22 +0000 2011",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 116 ],
      "url" : "http://t.co/9H6hJMxV",
      "expanded_url" : "http://flic.kr/p/aHi4NK",
      "display_url" : "flic.kr/p/aHi4NK"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6085, -122.306 ]
  },
  "id_str" : "138482471200243712",
  "text" : "8:36pm Researching things on the Internet that may or may not change a lot of things eventually http://t.co/9H6hJMxV",
  "id" : 138482471200243712,
  "created_at" : "Mon Nov 21 05:02:48 +0000 2011",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "138371631868416000",
  "text" : "Time for me to re-read \"What We Say Matters\". HIGHLY recommended for anyone that gets emotionally triggered by words.",
  "id" : 138371631868416000,
  "created_at" : "Sun Nov 20 21:42:22 +0000 2011",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "138367939211563009",
  "geo" : {
  },
  "id_str" : "138368257890586624",
  "in_reply_to_user_id" : 12961492,
  "text" : "@lesliedf Great! Let me know what you think of it. We've had a tough couple nights with Niko, but the article you sent is just what we need.",
  "id" : 138368257890586624,
  "in_reply_to_status_id" : 138367939211563009,
  "created_at" : "Sun Nov 20 21:28:58 +0000 2011",
  "in_reply_to_screen_name" : "lesliefandrich",
  "in_reply_to_user_id_str" : "12961492",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "138344973941751808",
  "geo" : {
  },
  "id_str" : "138367036312129537",
  "in_reply_to_user_id" : 12961492,
  "text" : "@lesliedf That's the one!",
  "id" : 138367036312129537,
  "in_reply_to_status_id" : 138344973941751808,
  "created_at" : "Sun Nov 20 21:24:06 +0000 2011",
  "in_reply_to_screen_name" : "lesliefandrich",
  "in_reply_to_user_id_str" : "12961492",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://timely.is\" rel=\"nofollow\">Timely by Demandforce</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "138261842735796224",
  "text" : "The Black Swam Test: if a tragic accident wiped out half of your friends and family tomorrow, which people/things would still matter to you?",
  "id" : 138261842735796224,
  "created_at" : "Sun Nov 20 14:26:06 +0000 2011",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 60 ],
      "url" : "http://t.co/u0yvzwrV",
      "expanded_url" : "http://flic.kr/p/aGFsA2",
      "display_url" : "flic.kr/p/aGFsA2"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.608666, -122.306167 ]
  },
  "id_str" : "138145848306573313",
  "text" : "8:36pm In the dark with a very sad baby http://t.co/u0yvzwrV",
  "id" : 138145848306573313,
  "created_at" : "Sun Nov 20 06:45:11 +0000 2011",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Ries",
      "screen_name" : "ericries",
      "indices" : [ 76, 85 ],
      "id_str" : "14278978",
      "id" : 14278978
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 107 ],
      "url" : "http://t.co/dgRzHkFE",
      "expanded_url" : "http://techcrunch.com/2011/11/19/racism-and-meritocracy/",
      "display_url" : "techcrunch.com/2011/11/19/rac…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "138074631365070848",
  "text" : "Best post about racism in the tech world that I've read in a while. Thanks, @ericries! http://t.co/dgRzHkFE \n\nQuick pattern-matching = bias.",
  "id" : 138074631365070848,
  "created_at" : "Sun Nov 20 02:02:12 +0000 2011",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Cottrell",
      "screen_name" : "rgcottrell",
      "indices" : [ 0, 11 ],
      "id_str" : "752553",
      "id" : 752553
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "137775080930418688",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6085044482, -122.3063735264 ]
  },
  "id_str" : "137781464908578816",
  "in_reply_to_user_id" : 752553,
  "text" : "@rgcottrell Awesome. I'm at 9th and Lenora. I'll check in next week!",
  "id" : 137781464908578816,
  "in_reply_to_status_id" : 137775080930418688,
  "created_at" : "Sat Nov 19 06:37:15 +0000 2011",
  "in_reply_to_screen_name" : "rgcottrell",
  "in_reply_to_user_id_str" : "752553",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Cottrell",
      "screen_name" : "rgcottrell",
      "indices" : [ 0, 11 ],
      "id_str" : "752553",
      "id" : 752553
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "137773326885076993",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6084799532, -122.3063643568 ]
  },
  "id_str" : "137773989538963456",
  "in_reply_to_user_id" : 752553,
  "text" : "@rgcottrell Are you in the SLU Amazon buildings? I can come visit next week. And buy you a drink?",
  "id" : 137773989538963456,
  "in_reply_to_status_id" : 137773326885076993,
  "created_at" : "Sat Nov 19 06:07:33 +0000 2011",
  "in_reply_to_screen_name" : "rgcottrell",
  "in_reply_to_user_id_str" : "752553",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Cottrell",
      "screen_name" : "rgcottrell",
      "indices" : [ 0, 11 ],
      "id_str" : "752553",
      "id" : 752553
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "137771302030286849",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6085502678, -122.3061817533 ]
  },
  "id_str" : "137771777622425600",
  "in_reply_to_user_id" : 752553,
  "text" : "@rgcottrell Awesome! My first Kindle! Find it! I will read scrappy self-help books and bad vampire romance on it!",
  "id" : 137771777622425600,
  "in_reply_to_status_id" : 137771302030286849,
  "created_at" : "Sat Nov 19 05:58:46 +0000 2011",
  "in_reply_to_screen_name" : "rgcottrell",
  "in_reply_to_user_id_str" : "752553",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Cottrell",
      "screen_name" : "rgcottrell",
      "indices" : [ 0, 11 ],
      "id_str" : "752553",
      "id" : 752553
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "137768058725998592",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6086956491, -122.3059105751 ]
  },
  "id_str" : "137769709415309313",
  "in_reply_to_user_id" : 752553,
  "text" : "@rgcottrell I do! Are you donating to a good cause (like poor startuppers) or asking money?",
  "id" : 137769709415309313,
  "in_reply_to_status_id" : 137768058725998592,
  "created_at" : "Sat Nov 19 05:50:33 +0000 2011",
  "in_reply_to_screen_name" : "rgcottrell",
  "in_reply_to_user_id_str" : "752553",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 89 ],
      "url" : "http://t.co/ORZNaPBp",
      "expanded_url" : "http://flic.kr/p/aG9hrr",
      "display_url" : "flic.kr/p/aG9hrr"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.608333, -122.306 ]
  },
  "id_str" : "137762261023465472",
  "text" : "8:36pm Feeling a bit exhausted. Comfort food and Hulu to the rescue. http://t.co/ORZNaPBp",
  "id" : 137762261023465472,
  "created_at" : "Sat Nov 19 05:20:57 +0000 2011",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jayne rowney",
      "screen_name" : "haikugirl",
      "indices" : [ 0, 10 ],
      "id_str" : "580262124",
      "id" : 580262124
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "137664278437183490",
  "geo" : {
  },
  "id_str" : "137664596747104256",
  "in_reply_to_user_id" : 12761252,
  "text" : "@haikugirl Exciting! Definitely tell me more!",
  "id" : 137664596747104256,
  "in_reply_to_status_id" : 137664278437183490,
  "created_at" : "Fri Nov 18 22:52:52 +0000 2011",
  "in_reply_to_screen_name" : "heatherquintal",
  "in_reply_to_user_id_str" : "12761252",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Neville",
      "screen_name" : "thinksomandy",
      "indices" : [ 0, 13 ],
      "id_str" : "453577645",
      "id" : 453577645
    }, {
      "name" : "Maggie Mason",
      "screen_name" : "Maggie",
      "indices" : [ 70, 77 ],
      "id_str" : "448",
      "id" : 448
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "137661457201508352",
  "geo" : {
  },
  "id_str" : "137664146081726465",
  "in_reply_to_user_id" : 16572103,
  "text" : "@thinksomandy Agreed. I needed it too, and am happy to pass it along! @maggie is full of many such magical tidbits.",
  "id" : 137664146081726465,
  "in_reply_to_status_id" : 137661457201508352,
  "created_at" : "Fri Nov 18 22:51:04 +0000 2011",
  "in_reply_to_screen_name" : "furiouslymandy",
  "in_reply_to_user_id_str" : "16572103",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jayne rowney",
      "screen_name" : "haikugirl",
      "indices" : [ 0, 10 ],
      "id_str" : "580262124",
      "id" : 580262124
    }, {
      "name" : "Maggie Mason",
      "screen_name" : "Maggie",
      "indices" : [ 108, 115 ],
      "id_str" : "448",
      "id" : 448
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "137659834840530944",
  "geo" : {
  },
  "id_str" : "137663958969626624",
  "in_reply_to_user_id" : 12761252,
  "text" : "@haikugirl I love it too. I haven't heard of circular motivation, but it seems like a good thing to me! /cc @maggie",
  "id" : 137663958969626624,
  "in_reply_to_status_id" : 137659834840530944,
  "created_at" : "Fri Nov 18 22:50:20 +0000 2011",
  "in_reply_to_screen_name" : "heatherquintal",
  "in_reply_to_user_id_str" : "12761252",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Maggie Mason",
      "screen_name" : "Maggie",
      "indices" : [ 105, 112 ],
      "id_str" : "448",
      "id" : 448
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 100 ],
      "url" : "http://t.co/O9NYG1dK",
      "expanded_url" : "http://mightygirl.com/2011/02/28/life-list-how-to-one-way-to-start/",
      "display_url" : "mightygirl.com/2011/02/28/lif…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "137656235599212546",
  "text" : "One way to start a life list: by listing emotions you'd like to feel right now. http://t.co/O9NYG1dK /by @maggie",
  "id" : 137656235599212546,
  "created_at" : "Fri Nov 18 22:19:38 +0000 2011",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jill Vaughn",
      "screen_name" : "TerraSavvy",
      "indices" : [ 0, 11 ],
      "id_str" : "38674907",
      "id" : 38674907
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "137557030301990913",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6085872878, -122.3062903337 ]
  },
  "id_str" : "137562687247892480",
  "in_reply_to_user_id" : 38674907,
  "text" : "@TerraSavvy I haven't heard of him before but will be reading up on his stuff too. I like what I've seen so far a lot!",
  "id" : 137562687247892480,
  "in_reply_to_status_id" : 137557030301990913,
  "created_at" : "Fri Nov 18 16:07:55 +0000 2011",
  "in_reply_to_screen_name" : "TerraSavvy",
  "in_reply_to_user_id_str" : "38674907",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 45 ],
      "url" : "http://t.co/Yv9PGC8T",
      "expanded_url" : "http://flic.kr/p/aFJQjn",
      "display_url" : "flic.kr/p/aFJQjn"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.617833, -122.337167 ]
  },
  "id_str" : "137402058293776384",
  "text" : "8:36pm Just leaving work http://t.co/Yv9PGC8T",
  "id" : 137402058293776384,
  "created_at" : "Fri Nov 18 05:29:38 +0000 2011",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jill Vaughn",
      "screen_name" : "TerraSavvy",
      "indices" : [ 0, 11 ],
      "id_str" : "38674907",
      "id" : 38674907
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 120 ],
      "url" : "http://t.co/fwbWHzf9",
      "expanded_url" : "http://www.brainpickings.org/index.php/2011/09/09/redirect-timothy-wilson/",
      "display_url" : "brainpickings.org/index.php/2011…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "137267546746404866",
  "in_reply_to_user_id" : 38674907,
  "text" : "@TerraSavvy Hi! I found this article and it made me think of the conversation we had the other day: http://t.co/fwbWHzf9",
  "id" : 137267546746404866,
  "created_at" : "Thu Nov 17 20:35:08 +0000 2011",
  "in_reply_to_screen_name" : "TerraSavvy",
  "in_reply_to_user_id_str" : "38674907",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "geester",
      "screen_name" : "geester",
      "indices" : [ 0, 8 ],
      "id_str" : "15415722",
      "id" : 15415722
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "136996774018678785",
  "geo" : {
  },
  "id_str" : "137251455651426304",
  "in_reply_to_user_id" : 15415722,
  "text" : "@geester Awesome. Thank you. A lot of the ideas are still rough in my head, and need more processing. Send your dad my way if you want!",
  "id" : 137251455651426304,
  "in_reply_to_status_id" : 136996774018678785,
  "created_at" : "Thu Nov 17 19:31:11 +0000 2011",
  "in_reply_to_screen_name" : "geester",
  "in_reply_to_user_id_str" : "15415722",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Hill",
      "screen_name" : "Amniote",
      "indices" : [ 0, 8 ],
      "id_str" : "35152749",
      "id" : 35152749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "137189348478164992",
  "geo" : {
  },
  "id_str" : "137251052167757825",
  "in_reply_to_user_id" : 35152749,
  "text" : "@Amniote Thank you! As for iPad... not at the moment, but 750words.com has been optimized for iPad if you open it in Safari.",
  "id" : 137251052167757825,
  "in_reply_to_status_id" : 137189348478164992,
  "created_at" : "Thu Nov 17 19:29:35 +0000 2011",
  "in_reply_to_screen_name" : "Amniote",
  "in_reply_to_user_id_str" : "35152749",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 51 ],
      "url" : "http://t.co/uWlBgfRX",
      "expanded_url" : "http://jquerymobile.com/blog/2011/11/16/announcing-jquery-mobile-1-0/",
      "display_url" : "jquerymobile.com/blog/2011/11/1…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "137250519050764288",
  "text" : "jQuery Mobile 1.0 is released! http://t.co/uWlBgfRX By far my favorite way to build mobile web apps.",
  "id" : 137250519050764288,
  "created_at" : "Thu Nov 17 19:27:28 +0000 2011",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.apple.com\" rel=\"nofollow\">Safari on iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryce Roberts",
      "screen_name" : "bryce",
      "indices" : [ 89, 95 ],
      "id_str" : "6160742",
      "id" : 6160742
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 117 ],
      "url" : "http://t.co/hx0rDNqX",
      "expanded_url" : "http://bradburnham.tumblr.com/post/12739727902/i-believe-in-the-internet-the-content-industry",
      "display_url" : "bradburnham.tumblr.com/post/127397279…"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.606639, -122.316583 ]
  },
  "id_str" : "137035363821686784",
  "text" : "The Internet encapsulates a belief system: that there are more good people than bad /via @bryce  http://t.co/hx0rDNqX",
  "id" : 137035363821686784,
  "created_at" : "Thu Nov 17 05:12:31 +0000 2011",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 99 ],
      "url" : "http://t.co/9xCrM2N6",
      "expanded_url" : "http://flic.kr/p/aFhGGp",
      "display_url" : "flic.kr/p/aFhGGp"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.607, -122.3165 ]
  },
  "id_str" : "137029477178945536",
  "text" : "8:36pm Tryied to convince a friend to join Twitter, and now this is on my mind http://t.co/9xCrM2N6",
  "id" : 137029477178945536,
  "created_at" : "Thu Nov 17 04:49:07 +0000 2011",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BrokeAssBride / Dana",
      "screen_name" : "BrokeAssBride",
      "indices" : [ 0, 14 ],
      "id_str" : "17822186",
      "id" : 17822186
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "136925954873368576",
  "geo" : {
  },
  "id_str" : "136935083587280896",
  "in_reply_to_user_id" : 17822186,
  "text" : "@BrokeAssBride You are too kind! I will keep an eye out, and again, let me know if I can help in any way!",
  "id" : 136935083587280896,
  "in_reply_to_status_id" : 136925954873368576,
  "created_at" : "Wed Nov 16 22:34:02 +0000 2011",
  "in_reply_to_screen_name" : "BrokeAssBride",
  "in_reply_to_user_id_str" : "17822186",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BrokeAssBride / Dana",
      "screen_name" : "BrokeAssBride",
      "indices" : [ 0, 14 ],
      "id_str" : "17822186",
      "id" : 17822186
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "136924914610487297",
  "geo" : {
  },
  "id_str" : "136925342353981440",
  "in_reply_to_user_id" : 17822186,
  "text" : "@BrokeAssBride Awesome! Thanks for helping spread the word... and let me know if I can help get you started on either of those sites.",
  "id" : 136925342353981440,
  "in_reply_to_status_id" : 136924914610487297,
  "created_at" : "Wed Nov 16 21:55:20 +0000 2011",
  "in_reply_to_screen_name" : "BrokeAssBride",
  "in_reply_to_user_id_str" : "17822186",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Wolf",
      "screen_name" : "agaricus",
      "indices" : [ 22, 31 ],
      "id_str" : "21678279",
      "id" : 21678279
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "quantifiedself",
      "indices" : [ 93, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 131 ],
      "url" : "http://t.co/b2EoRWzG",
      "expanded_url" : "http://venturebeat.com/2011/11/16/will-wright-hivemind/",
      "display_url" : "venturebeat.com/2011/11/16/wil…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "136909676066512896",
  "text" : "Looks interesting! RT @agaricus: Will Wright explains why his new game is partly inspired by #quantifiedself - http://t.co/b2EoRWzG",
  "id" : 136909676066512896,
  "created_at" : "Wed Nov 16 20:53:05 +0000 2011",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SlideShare",
      "screen_name" : "slideshare",
      "indices" : [ 71, 82 ],
      "id_str" : "9676152",
      "id" : 9676152
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 134 ],
      "url" : "http://t.co/ruedd7nG",
      "expanded_url" : "http://www.slideshare.net/BusterBenson/dopamine-the-devil-on-our-shoulder",
      "display_url" : "slideshare.net/BusterBenson/d…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "136893606291181568",
  "text" : "My slides on Dopamine and behavior change are getting a lot of love on @slideshare... but do they make any sense? http://t.co/ruedd7nG",
  "id" : 136893606291181568,
  "created_at" : "Wed Nov 16 19:49:13 +0000 2011",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ThinkUp App",
      "screen_name" : "thinkupapp",
      "indices" : [ 24, 35 ],
      "id_str" : "625101655",
      "id" : 625101655
    }, {
      "name" : "Expert Labs",
      "screen_name" : "expertlabs",
      "indices" : [ 82, 93 ],
      "id_str" : "82788404",
      "id" : 82788404
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 115 ],
      "url" : "http://t.co/xnDcOviD",
      "expanded_url" : "http://busterbenson.com/thinkup/",
      "display_url" : "busterbenson.com/thinkup/"
    } ]
  },
  "geo" : {
  },
  "id_str" : "136877811842547712",
  "text" : "Just upgraded to 1.0 of @thinkupapp, and it's looking better than ever! Congrats  @expertlabs! http://t.co/xnDcOviD",
  "id" : 136877811842547712,
  "created_at" : "Wed Nov 16 18:46:28 +0000 2011",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rob Roy",
      "screen_name" : "RobRoySeattle",
      "indices" : [ 8, 22 ],
      "id_str" : "69808987",
      "id" : 69808987
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 115 ],
      "url" : "http://t.co/x1601Li9",
      "expanded_url" : "http://www.facebook.com/event.php?eid=174595119298897",
      "display_url" : "facebook.com/event.php?eid=…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "136618230142869504",
  "text" : "Come to @robroyseattle between now and 10pm for a free drink, a sticker, and a free good deed: http://t.co/x1601Li9 See you there!",
  "id" : 136618230142869504,
  "created_at" : "Wed Nov 16 01:34:58 +0000 2011",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Deval Delivala",
      "screen_name" : "devalad",
      "indices" : [ 3, 11 ],
      "id_str" : "57700233",
      "id" : 57700233
    }, {
      "name" : "Rob Roy",
      "screen_name" : "RobRoySeattle",
      "indices" : [ 57, 71 ],
      "id_str" : "69808987",
      "id" : 69808987
    }, {
      "name" : "Amit superamit Gupta",
      "screen_name" : "superamit",
      "indices" : [ 100, 110 ],
      "id_str" : "10609",
      "id" : 10609
    }, {
      "name" : "Buster Benson",
      "screen_name" : "busterbenson",
      "indices" : [ 116, 129 ],
      "id_str" : "2185",
      "id" : 2185
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Seattle",
      "indices" : [ 13, 21 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "136595059196952576",
  "text" : "RT @devalad: #Seattle get your I SWABBED badge today 6pm @robroyseattle. Bone Marrow Swab Party for @superamit  cc/ @busterbenson http:/ ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Rob Roy",
        "screen_name" : "RobRoySeattle",
        "indices" : [ 44, 58 ],
        "id_str" : "69808987",
        "id" : 69808987
      }, {
        "name" : "Amit superamit Gupta",
        "screen_name" : "superamit",
        "indices" : [ 87, 97 ],
        "id_str" : "10609",
        "id" : 10609
      }, {
        "name" : "Buster Benson",
        "screen_name" : "busterbenson",
        "indices" : [ 103, 116 ],
        "id_str" : "2185",
        "id" : 2185
      } ],
      "media" : [ {
        "expanded_url" : "http://twitter.com/devalad/status/136594840229134338/photo/1",
        "indices" : [ 117, 137 ],
        "url" : "http://t.co/SfIXVS2B",
        "media_url" : "http://pbs.twimg.com/media/AeVISJJCQAEImHR.jpg",
        "id_str" : "136594840233328641",
        "id" : 136594840233328641,
        "media_url_https" : "https://pbs.twimg.com/media/AeVISJJCQAEImHR.jpg",
        "sizes" : [ {
          "h" : 240,
          "resize" : "fit",
          "w" : 320
        }, {
          "h" : 240,
          "resize" : "fit",
          "w" : 320
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 240,
          "resize" : "fit",
          "w" : 320
        }, {
          "h" : 240,
          "resize" : "fit",
          "w" : 320
        } ],
        "display_url" : "pic.twitter.com/SfIXVS2B"
      } ],
      "hashtags" : [ {
        "text" : "Seattle",
        "indices" : [ 0, 8 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "136594840229134338",
    "text" : "#Seattle get your I SWABBED badge today 6pm @robroyseattle. Bone Marrow Swab Party for @superamit  cc/ @busterbenson http://t.co/SfIXVS2B",
    "id" : 136594840229134338,
    "created_at" : "Wed Nov 16 00:02:02 +0000 2011",
    "user" : {
      "name" : "Deval Delivala",
      "screen_name" : "devalad",
      "protected" : false,
      "id_str" : "57700233",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1587334656/IMG_0322_normal.JPG",
      "id" : 57700233,
      "verified" : false
    }
  },
  "id" : 136595059196952576,
  "created_at" : "Wed Nov 16 00:02:54 +0000 2011",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Deval Delivala",
      "screen_name" : "devalad",
      "indices" : [ 0, 8 ],
      "id_str" : "57700233",
      "id" : 57700233
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "136344119374118912",
  "geo" : {
  },
  "id_str" : "136344936315498496",
  "in_reply_to_user_id" : 57700233,
  "text" : "@devalad Video was taken, but not sure when it will be available.  I'll definitely post it when it is...",
  "id" : 136344936315498496,
  "in_reply_to_status_id" : 136344119374118912,
  "created_at" : "Tue Nov 15 07:29:00 +0000 2011",
  "in_reply_to_screen_name" : "devalad",
  "in_reply_to_user_id_str" : "57700233",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://timely.is\" rel=\"nofollow\">Timely by Demandforce</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "campmighty",
      "indices" : [ 88, 99 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 128 ],
      "url" : "http://t.co/XuSrkzJm",
      "expanded_url" : "http://slidesha.re/rven5S",
      "display_url" : "slidesha.re/rven5S"
    } ]
  },
  "geo" : {
  },
  "id_str" : "136342950128001024",
  "text" : "Here's my recent train of thought about how dopamine relates to behavior change, via my #campmighty slides: http://t.co/XuSrkzJm",
  "id" : 136342950128001024,
  "created_at" : "Tue Nov 15 07:21:07 +0000 2011",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Shapiro",
      "screen_name" : "danshapiro",
      "indices" : [ 0, 11 ],
      "id_str" : "8070502",
      "id" : 8070502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 139 ],
      "url" : "http://t.co/x1601Li9",
      "expanded_url" : "http://www.facebook.com/event.php?eid=174595119298897",
      "display_url" : "facebook.com/event.php?eid=…"
    } ]
  },
  "in_reply_to_status_id_str" : "136328719064252416",
  "geo" : {
  },
  "id_str" : "136335338112155649",
  "in_reply_to_user_id" : 8070502,
  "text" : "@danshapiro Powerful story. Can you help spread the word about a bone marrow swabbing party tomorrow night? Info here: http://t.co/x1601Li9",
  "id" : 136335338112155649,
  "in_reply_to_status_id" : 136328719064252416,
  "created_at" : "Tue Nov 15 06:50:52 +0000 2011",
  "in_reply_to_screen_name" : "danshapiro",
  "in_reply_to_user_id_str" : "8070502",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Bonner",
      "screen_name" : "seanbonner",
      "indices" : [ 0, 11 ],
      "id_str" : "765",
      "id" : 765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "136318604877643776",
  "geo" : {
  },
  "id_str" : "136318809031180289",
  "in_reply_to_user_id" : 765,
  "text" : "@seanbonner Not for me. I think they're still fiddling. But, I wouldn't be sad if it went away… sorta pointless.",
  "id" : 136318809031180289,
  "in_reply_to_status_id" : 136318604877643776,
  "created_at" : "Tue Nov 15 05:45:11 +0000 2011",
  "in_reply_to_screen_name" : "seanbonner",
  "in_reply_to_user_id_str" : "765",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carrie Peters",
      "screen_name" : "Carriepeters",
      "indices" : [ 0, 13 ],
      "id_str" : "15349922",
      "id" : 15349922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "136305653877702657",
  "geo" : {
  },
  "id_str" : "136306501257142272",
  "in_reply_to_user_id" : 15349922,
  "text" : "@Carriepeters The newest. I've decided I like it. Especially the first song.",
  "id" : 136306501257142272,
  "in_reply_to_status_id" : 136305653877702657,
  "created_at" : "Tue Nov 15 04:56:17 +0000 2011",
  "in_reply_to_screen_name" : "Carriepeters",
  "in_reply_to_user_id_str" : "15349922",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 96 ],
      "url" : "http://t.co/KNRrYZ08",
      "expanded_url" : "http://flic.kr/p/aEQvnJ",
      "display_url" : "flic.kr/p/aEQvnJ"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6085, -122.306334 ]
  },
  "id_str" : "136304049153785857",
  "text" : "8:36pm Eating leftover leftovers, listening to Wilco, starting a work shift http://t.co/KNRrYZ08",
  "id" : 136304049153785857,
  "created_at" : "Tue Nov 15 04:46:32 +0000 2011",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kate nicholson",
      "screen_name" : "modhomemodbaby",
      "indices" : [ 0, 15 ],
      "id_str" : "283695263",
      "id" : 283695263
    }, {
      "name" : "elizabeth hagopian",
      "screen_name" : "elizhagopian",
      "indices" : [ 16, 29 ],
      "id_str" : "31553033",
      "id" : 31553033
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "136290950233329664",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6084920849, -122.3060338632 ]
  },
  "id_str" : "136295953169780736",
  "in_reply_to_user_id" : 283695263,
  "text" : "@modhomemodbaby @elizhagopian You may eat them if that's one of your 5 goals for the year. Or if you just want to. :)",
  "id" : 136295953169780736,
  "in_reply_to_status_id" : 136290950233329664,
  "created_at" : "Tue Nov 15 04:14:22 +0000 2011",
  "in_reply_to_screen_name" : "modhomemodbaby",
  "in_reply_to_user_id_str" : "283695263",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Schappell",
      "screen_name" : "daveschappell",
      "indices" : [ 3, 17 ],
      "id_str" : "820661",
      "id" : 820661
    }, {
      "name" : "Simply Measured",
      "screen_name" : "simplymeasured",
      "indices" : [ 121, 136 ],
      "id_str" : "92162698",
      "id" : 92162698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 116 ],
      "url" : "http://t.co/bWgtATV1",
      "expanded_url" : "http://simplymeasured.com/blog/2011/11/simply-measured-2-0-analyze-in-excel-share-online-publish-to-powerpoint/",
      "display_url" : "simplymeasured.com/blog/2011/11/s…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "136225829565902848",
  "text" : "RT @daveschappell: Simply Measured 2.0: Analyze in Excel, Share Online, & Publish to PowerPoint http://t.co/bWgtATV1 via @simplymeasured",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Simply Measured",
        "screen_name" : "simplymeasured",
        "indices" : [ 102, 117 ],
        "id_str" : "92162698",
        "id" : 92162698
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 77, 97 ],
        "url" : "http://t.co/bWgtATV1",
        "expanded_url" : "http://simplymeasured.com/blog/2011/11/simply-measured-2-0-analyze-in-excel-share-online-publish-to-powerpoint/",
        "display_url" : "simplymeasured.com/blog/2011/11/s…"
      } ]
    },
    "geo" : {
    },
    "id_str" : "136225667988717570",
    "text" : "Simply Measured 2.0: Analyze in Excel, Share Online, & Publish to PowerPoint http://t.co/bWgtATV1 via @simplymeasured",
    "id" : 136225667988717570,
    "created_at" : "Mon Nov 14 23:35:04 +0000 2011",
    "user" : {
      "name" : "Dave Schappell",
      "screen_name" : "daveschappell",
      "protected" : false,
      "id_str" : "820661",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1847687555/Dave_Schappell_200px_normal.jpg",
      "id" : 820661,
      "verified" : false
    }
  },
  "id" : 136225829565902848,
  "created_at" : "Mon Nov 14 23:35:43 +0000 2011",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 139 ],
      "url" : "http://t.co/x1601Li9",
      "expanded_url" : "http://www.facebook.com/event.php?eid=174595119298897",
      "display_url" : "facebook.com/event.php?eid=…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "136221697643778048",
  "text" : "Hello Seattle-ites! Please consider coming and/or passing along this bone marrow swap party info. It's tomorrow night! http://t.co/x1601Li9",
  "id" : 136221697643778048,
  "created_at" : "Mon Nov 14 23:19:18 +0000 2011",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Megan Reardon",
      "screen_name" : "notmartha",
      "indices" : [ 0, 10 ],
      "id_str" : "11491312",
      "id" : 11491312
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "campmighty",
      "indices" : [ 125, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 124 ],
      "url" : "http://t.co/x1601Li9",
      "expanded_url" : "http://www.facebook.com/event.php?eid=174595119298897",
      "display_url" : "facebook.com/event.php?eid=…"
    } ]
  },
  "in_reply_to_status_id_str" : "136186255892426752",
  "geo" : {
  },
  "id_str" : "136217559564431360",
  "in_reply_to_user_id" : 11491312,
  "text" : "@notmartha Yes, you too! If you're around tomorrow night, I'm hosting a bone marrow drive for a friend: http://t.co/x1601Li9 #campmighty",
  "id" : 136217559564431360,
  "in_reply_to_status_id" : 136186255892426752,
  "created_at" : "Mon Nov 14 23:02:51 +0000 2011",
  "in_reply_to_screen_name" : "notmartha",
  "in_reply_to_user_id_str" : "11491312",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "e_ramirez",
      "indices" : [ 0, 10 ],
      "id_str" : "21135674",
      "id" : 21135674
    }, {
      "name" : "Weavrs",
      "screen_name" : "weavrs",
      "indices" : [ 11, 18 ],
      "id_str" : "201264434",
      "id" : 201264434
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "135950287897759745",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6089064581, -122.3061101952 ]
  },
  "id_str" : "135953550370017280",
  "in_reply_to_user_id" : 21135674,
  "text" : "@e_ramirez @weavrs looks really interesting! Definitely gonna look into that.",
  "id" : 135953550370017280,
  "in_reply_to_status_id" : 135950287897759745,
  "created_at" : "Mon Nov 14 05:33:46 +0000 2011",
  "in_reply_to_screen_name" : "e_ramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 123 ],
      "url" : "http://t.co/c58MI22E",
      "expanded_url" : "http://flic.kr/p/aEwRmY",
      "display_url" : "flic.kr/p/aEwRmY"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6085, -122.306167 ]
  },
  "id_str" : "135940642063925248",
  "text" : "8:36pm Just finished dinner, listening to Radiolab on machines thinking about interactive journal bots http://t.co/c58MI22E",
  "id" : 135940642063925248,
  "created_at" : "Mon Nov 14 04:42:29 +0000 2011",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mena Trott",
      "screen_name" : "dollarshort",
      "indices" : [ 0, 12 ],
      "id_str" : "14127387",
      "id" : 14127387
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.608659758, -122.3060881699 ]
  },
  "id_str" : "135924990133551105",
  "in_reply_to_user_id" : 14127387,
  "text" : "@dollarshort Thanks for the Backyardigans tip. They're a hit! Love the wikipedia page about them too.",
  "id" : 135924990133551105,
  "created_at" : "Mon Nov 14 03:40:17 +0000 2011",
  "in_reply_to_screen_name" : "dollarshort",
  "in_reply_to_user_id_str" : "14127387",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrea Howe",
      "screen_name" : "fourflights",
      "indices" : [ 0, 12 ],
      "id_str" : "128672136",
      "id" : 128672136
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "135873327427366912",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6169232326, -122.3185507084 ]
  },
  "id_str" : "135879495663108096",
  "in_reply_to_user_id" : 128672136,
  "text" : "@fourflights Thank you! He had a good time as the center of attention for sure.",
  "id" : 135879495663108096,
  "in_reply_to_status_id" : 135873327427366912,
  "created_at" : "Mon Nov 14 00:39:30 +0000 2011",
  "in_reply_to_screen_name" : "fourflights",
  "in_reply_to_user_id_str" : "128672136",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagr.am\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 32 ],
      "url" : "http://t.co/sZ5xxb22",
      "expanded_url" : "http://instagr.am/p/UEc5Q/",
      "display_url" : "instagr.am/p/UEc5Q/"
    } ]
  },
  "geo" : {
  },
  "id_str" : "135872608884371456",
  "text" : "Off-roading http://t.co/sZ5xxb22",
  "id" : 135872608884371456,
  "created_at" : "Mon Nov 14 00:12:09 +0000 2011",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Wolf",
      "screen_name" : "agaricus",
      "indices" : [ 3, 12 ],
      "id_str" : "21678279",
      "id" : 21678279
    }, {
      "name" : "Buster Benson",
      "screen_name" : "busterbenson",
      "indices" : [ 14, 27 ],
      "id_str" : "2185",
      "id" : 2185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "135821586614849536",
  "text" : "RT @agaricus: @busterbenson - perhaps not age, but unreflective projection; he is \"selling\" the next cheap generational epithet.",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Buster Benson",
        "screen_name" : "busterbenson",
        "indices" : [ 0, 13 ],
        "id_str" : "2185",
        "id" : 2185
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "135815381066596352",
    "geo" : {
    },
    "id_str" : "135820919775043585",
    "in_reply_to_user_id" : 2185,
    "text" : "@busterbenson - perhaps not age, but unreflective projection; he is \"selling\" the next cheap generational epithet.",
    "id" : 135820919775043585,
    "in_reply_to_status_id" : 135815381066596352,
    "created_at" : "Sun Nov 13 20:46:45 +0000 2011",
    "in_reply_to_screen_name" : "busterbenson",
    "in_reply_to_user_id_str" : "2185",
    "user" : {
      "name" : "Gary Wolf",
      "screen_name" : "agaricus",
      "protected" : false,
      "id_str" : "21678279",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/105835994/agaricus_normal.jpg",
      "id" : 21678279,
      "verified" : false
    }
  },
  "id" : 135821586614849536,
  "created_at" : "Sun Nov 13 20:49:24 +0000 2011",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Wolf",
      "screen_name" : "agaricus",
      "indices" : [ 0, 9 ],
      "id_str" : "21678279",
      "id" : 21678279
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "135820919775043585",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6086170241, -122.3062027391 ]
  },
  "id_str" : "135821516590952448",
  "in_reply_to_user_id" : 21678279,
  "text" : "@agaricus Ha, true. He's critiquing his own issues by projecting them onto others.",
  "id" : 135821516590952448,
  "in_reply_to_status_id" : 135820919775043585,
  "created_at" : "Sun Nov 13 20:49:07 +0000 2011",
  "in_reply_to_screen_name" : "agaricus",
  "in_reply_to_user_id_str" : "21678279",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "harryh",
      "screen_name" : "harryh",
      "indices" : [ 0, 7 ],
      "id_str" : "4558",
      "id" : 4558
    }, {
      "name" : "Ryan Freitas",
      "screen_name" : "ryanchris",
      "indices" : [ 8, 18 ],
      "id_str" : "13349",
      "id" : 13349
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "135817033928548352",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6086215346, -122.3059892039 ]
  },
  "id_str" : "135817803834994688",
  "in_reply_to_user_id" : 4558,
  "text" : "@harryh @ryanchris Difficult to say that for sure, given that this is the first generation where everyone can broadcast their every thought.",
  "id" : 135817803834994688,
  "in_reply_to_status_id" : 135817033928548352,
  "created_at" : "Sun Nov 13 20:34:22 +0000 2011",
  "in_reply_to_screen_name" : "harryh",
  "in_reply_to_user_id_str" : "4558",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Freitas",
      "screen_name" : "ryanchris",
      "indices" : [ 0, 10 ],
      "id_str" : "13349",
      "id" : 13349
    }, {
      "name" : "harryh",
      "screen_name" : "harryh",
      "indices" : [ 11, 18 ],
      "id_str" : "4558",
      "id" : 4558
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "135815441577820160",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6085545255, -122.3059489864 ]
  },
  "id_str" : "135816588220829696",
  "in_reply_to_user_id" : 13349,
  "text" : "@ryanchris @harryh I think it's wrong. Self-censoring is a remnant of old generations, not a new thing. We're still moving away from it...",
  "id" : 135816588220829696,
  "in_reply_to_status_id" : 135815441577820160,
  "created_at" : "Sun Nov 13 20:29:32 +0000 2011",
  "in_reply_to_screen_name" : "ryanchris",
  "in_reply_to_user_id_str" : "13349",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 133 ],
      "url" : "http://t.co/mWPzL6Ir",
      "expanded_url" : "http://www.nytimes.com/2011/11/13/opinion/sunday/the-entrepreneurial-generation.html",
      "display_url" : "nytimes.com/2011/11/13/opi…"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6086704858, -122.3061552878 ]
  },
  "id_str" : "135815381066596352",
  "text" : "Generation Sell? That's how old people might see it, with old eyes. Selling is incidental, creation is central.  http://t.co/mWPzL6Ir",
  "id" : 135815381066596352,
  "created_at" : "Sun Nov 13 20:24:44 +0000 2011",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Writers' Bloc",
      "screen_name" : "_writersbloc",
      "indices" : [ 0, 13 ],
      "id_str" : "372602703",
      "id" : 372602703
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "135402736740073473",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.5868221357, -122.5930127317 ]
  },
  "id_str" : "135516058894352384",
  "in_reply_to_user_id" : 372602703,
  "text" : "@_writersbloc Can't wait to get back and check the video. Thank you!",
  "id" : 135516058894352384,
  "in_reply_to_status_id" : 135402736740073473,
  "created_at" : "Sun Nov 13 00:35:20 +0000 2011",
  "in_reply_to_screen_name" : "_writersbloc",
  "in_reply_to_user_id_str" : "372602703",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "stevie",
      "screen_name" : "imakeshinylove",
      "indices" : [ 0, 15 ],
      "id_str" : "17292155",
      "id" : 17292155
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "campmighty",
      "indices" : [ 33, 44 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "135507021175853056",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.5868070012, -122.5924757781 ]
  },
  "id_str" : "135515247514615808",
  "in_reply_to_user_id" : 17292155,
  "text" : "@imakeshinylove You too! Missing #campmighty already.",
  "id" : 135515247514615808,
  "in_reply_to_status_id" : 135507021175853056,
  "created_at" : "Sun Nov 13 00:32:07 +0000 2011",
  "in_reply_to_screen_name" : "imakeshinylove",
  "in_reply_to_user_id_str" : "17292155",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cassie Boorn",
      "screen_name" : "cassieboorn",
      "indices" : [ 0, 12 ],
      "id_str" : "17465839",
      "id" : 17465839
    }, {
      "name" : "Ashley Veselka",
      "screen_name" : "ashleyv",
      "indices" : [ 13, 21 ],
      "id_str" : "884911",
      "id" : 884911
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "135451929684881408",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.5870503319, -122.5929658045 ]
  },
  "id_str" : "135515069743239168",
  "in_reply_to_user_id" : 17465839,
  "text" : "@cassieboorn @ashleyv Thank you!",
  "id" : 135515069743239168,
  "in_reply_to_status_id" : 135451929684881408,
  "created_at" : "Sun Nov 13 00:31:25 +0000 2011",
  "in_reply_to_screen_name" : "cassieboorn",
  "in_reply_to_user_id_str" : "17465839",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ashley Veselka",
      "screen_name" : "ashleyv",
      "indices" : [ 0, 8 ],
      "id_str" : "884911",
      "id" : 884911
    }, {
      "name" : "Habit Labs",
      "screen_name" : "habitlabs",
      "indices" : [ 56, 66 ],
      "id_str" : "250986038",
      "id" : 250986038
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "campmighty",
      "indices" : [ 78, 89 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "135443358964400131",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.586785677, -122.592339941 ]
  },
  "id_str" : "135515006346334209",
  "in_reply_to_user_id" : 884911,
  "text" : "@ashleyv Thank you! Yes, something big to announce with @habitlabs very soon. #campmighty",
  "id" : 135515006346334209,
  "in_reply_to_status_id" : 135443358964400131,
  "created_at" : "Sun Nov 13 00:31:09 +0000 2011",
  "in_reply_to_screen_name" : "ashleyv",
  "in_reply_to_user_id_str" : "884911",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Staci Magnolia",
      "screen_name" : "StaciMagnolia",
      "indices" : [ 0, 14 ],
      "id_str" : "22061229",
      "id" : 22061229
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "135178165952851968",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.5864417822, -122.5930787038 ]
  },
  "id_str" : "135514691576410113",
  "in_reply_to_user_id" : 22061229,
  "text" : "@StaciMagnolia You'd be surprised how effective it is as a mood booster. :)",
  "id" : 135514691576410113,
  "in_reply_to_status_id" : 135178165952851968,
  "created_at" : "Sun Nov 13 00:29:54 +0000 2011",
  "in_reply_to_screen_name" : "StaciMagnolia",
  "in_reply_to_user_id_str" : "22061229",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Maira Holzmann",
      "screen_name" : "EmpowermentExp",
      "indices" : [ 0, 15 ],
      "id_str" : "285138006",
      "id" : 285138006
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "134803387270176768",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.586792054, -122.5924760302 ]
  },
  "id_str" : "135514413917679617",
  "in_reply_to_user_id" : 285138006,
  "text" : "@EmpowermentExp Thank you, Maira!",
  "id" : 135514413917679617,
  "in_reply_to_status_id" : 134803387270176768,
  "created_at" : "Sun Nov 13 00:28:48 +0000 2011",
  "in_reply_to_screen_name" : "EmpowermentExp",
  "in_reply_to_user_id_str" : "285138006",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kristen Howerton",
      "screen_name" : "kristenhowerton",
      "indices" : [ 0, 16 ],
      "id_str" : "19835106",
      "id" : 19835106
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "campmighty",
      "indices" : [ 48, 59 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "135092606240694272",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.5868482725, -122.5928260339 ]
  },
  "id_str" : "135514244211949568",
  "in_reply_to_user_id" : 19835106,
  "text" : "@kristenhowerton Thanks! I'm glad you liked it. #campmighty is awesome.",
  "id" : 135514244211949568,
  "in_reply_to_status_id" : 135092606240694272,
  "created_at" : "Sun Nov 13 00:28:08 +0000 2011",
  "in_reply_to_screen_name" : "kristenhowerton",
  "in_reply_to_user_id_str" : "19835106",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah James",
      "screen_name" : "whoorl",
      "indices" : [ 0, 7 ],
      "id_str" : "5810752",
      "id" : 5810752
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "135096375535861760",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.5868114702, -122.5926509427 ]
  },
  "id_str" : "135514091904172034",
  "in_reply_to_user_id" : 5810752,
  "text" : "@whoorl Thank you!",
  "id" : 135514091904172034,
  "in_reply_to_status_id" : 135096375535861760,
  "created_at" : "Sun Nov 13 00:27:31 +0000 2011",
  "in_reply_to_screen_name" : "whoorl",
  "in_reply_to_user_id_str" : "5810752",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alliance4Bike&Walk",
      "screen_name" : "BikeWalk",
      "indices" : [ 0, 9 ],
      "id_str" : "63302806",
      "id" : 63302806
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "135096828290019328",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.5869838586, -122.5923799023 ]
  },
  "id_str" : "135514042822438912",
  "in_reply_to_user_id" : 63302806,
  "text" : "@BikeWalk Great meeting you! Would love to talk more about thoughts on helping more people walk and bike around.",
  "id" : 135514042822438912,
  "in_reply_to_status_id" : 135096828290019328,
  "created_at" : "Sun Nov 13 00:27:20 +0000 2011",
  "in_reply_to_screen_name" : "BikeWalk",
  "in_reply_to_user_id_str" : "63302806",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrea Howe",
      "screen_name" : "fourflights",
      "indices" : [ 0, 12 ],
      "id_str" : "128672136",
      "id" : 128672136
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "135097492894261248",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.5864525602, -122.5942642639 ]
  },
  "id_str" : "135513814673272832",
  "in_reply_to_user_id" : 128672136,
  "text" : "@fourflights My life and business was changed by his books too!",
  "id" : 135513814673272832,
  "in_reply_to_status_id" : 135097492894261248,
  "created_at" : "Sun Nov 13 00:26:25 +0000 2011",
  "in_reply_to_screen_name" : "fourflights",
  "in_reply_to_user_id_str" : "128672136",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "What's Your System?",
      "screen_name" : "WhatsYourSystem",
      "indices" : [ 0, 16 ],
      "id_str" : "37806459",
      "id" : 37806459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "135097795794305024",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.586751625, -122.5925134793 ]
  },
  "id_str" : "135513701557088258",
  "in_reply_to_user_id" : 37806459,
  "text" : "@WhatsYourSystem Great meeting you! Looking forward to the interview.",
  "id" : 135513701557088258,
  "in_reply_to_status_id" : 135097795794305024,
  "created_at" : "Sun Nov 13 00:25:58 +0000 2011",
  "in_reply_to_screen_name" : "WhatsYourSystem",
  "in_reply_to_user_id_str" : "37806459",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Asha Dornfest",
      "screen_name" : "parenthacks",
      "indices" : [ 0, 12 ],
      "id_str" : "14645531",
      "id" : 14645531
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "135100069576847360",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.5866121086, -122.5926438039 ]
  },
  "id_str" : "135513279094194177",
  "in_reply_to_user_id" : 14645531,
  "text" : "@parenthacks Great meeting you, Asha!",
  "id" : 135513279094194177,
  "in_reply_to_status_id" : 135100069576847360,
  "created_at" : "Sun Nov 13 00:24:18 +0000 2011",
  "in_reply_to_screen_name" : "parenthacks",
  "in_reply_to_user_id_str" : "14645531",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leslie Callan",
      "screen_name" : "TheGreenVintage",
      "indices" : [ 0, 16 ],
      "id_str" : "410305005",
      "id" : 410305005
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "135136479683936257",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 45.5868125032, -122.5925711873 ]
  },
  "id_str" : "135513023396839424",
  "in_reply_to_user_id" : 410305005,
  "text" : "@TheGreenVintage Thank you for taking this picture! May I use it with attribution?",
  "id" : 135513023396839424,
  "in_reply_to_status_id" : 135136479683936257,
  "created_at" : "Sun Nov 13 00:23:17 +0000 2011",
  "in_reply_to_screen_name" : "TheGreenVintage",
  "in_reply_to_user_id_str" : "410305005",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "campmighty",
      "indices" : [ 29, 40 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 104 ],
      "url" : "http://t.co/Y22cowYh",
      "expanded_url" : "http://flic.kr/p/aE5RW3",
      "display_url" : "flic.kr/p/aE5RW3"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 33.800666, -116.54 ]
  },
  "id_str" : "135436883437158400",
  "text" : "Sad to be leaving early from #campmighty. Lots of great people met in a short time. http://t.co/Y22cowYh",
  "id" : 135436883437158400,
  "created_at" : "Sat Nov 12 19:20:43 +0000 2011",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laura Mayes",
      "screen_name" : "lmayes",
      "indices" : [ 3, 10 ],
      "id_str" : "7491582",
      "id" : 7491582
    }, {
      "name" : "charity: water",
      "screen_name" : "charitywater",
      "indices" : [ 116, 129 ],
      "id_str" : "26784273",
      "id" : 26784273
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "campmighty",
      "indices" : [ 37, 48 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "135187934574940161",
  "text" : "RT @lmayes: On 11/11/11 @ 11:11 a.m. #campmighty attendees had raised $ ($20K+) to provide water to 1,111 people w/ @charitywater. How c ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "charity: water",
        "screen_name" : "charitywater",
        "indices" : [ 104, 117 ],
        "id_str" : "26784273",
        "id" : 26784273
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "campmighty",
        "indices" : [ 25, 36 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "135179967171526657",
    "text" : "On 11/11/11 @ 11:11 a.m. #campmighty attendees had raised $ ($20K+) to provide water to 1,111 people w/ @charitywater. How cool is that?",
    "id" : 135179967171526657,
    "created_at" : "Sat Nov 12 02:19:50 +0000 2011",
    "user" : {
      "name" : "Laura Mayes",
      "screen_name" : "lmayes",
      "protected" : false,
      "id_str" : "7491582",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1485312753/Screen_shot_2011-08-08_at_6.07.57_PM_normal.png",
      "id" : 7491582,
      "verified" : false
    }
  },
  "id" : 135187934574940161,
  "created_at" : "Sat Nov 12 02:51:29 +0000 2011",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "campmighty",
      "indices" : [ 24, 35 ]
    }, {
      "text" : "giveahand",
      "indices" : [ 36, 46 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 116 ],
      "url" : "http://t.co/gVhmN8yI",
      "expanded_url" : "http://flic.kr/p/aDQE1a",
      "display_url" : "flic.kr/p/aDQE1a"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 33.800833, -116.5405 ]
  },
  "id_str" : "135158806018662400",
  "text" : "Got my hand painted for #campmighty #giveahand trying to convince Niko to do same. Didn't work. http://t.co/gVhmN8yI",
  "id" : 135158806018662400,
  "created_at" : "Sat Nov 12 00:55:45 +0000 2011",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "xobolaji",
      "screen_name" : "ithinkUshould",
      "indices" : [ 0, 14 ],
      "id_str" : "105907649",
      "id" : 105907649
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "135150350209519616",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 33.8006962711, -116.5402502033 ]
  },
  "id_str" : "135157076979748864",
  "in_reply_to_user_id" : 105907649,
  "text" : "@ithinkUshould Almost everything I track is automated, so doesn't take extra time at all.",
  "id" : 135157076979748864,
  "in_reply_to_status_id" : 135150350209519616,
  "created_at" : "Sat Nov 12 00:48:52 +0000 2011",
  "in_reply_to_screen_name" : "ithinkUshould",
  "in_reply_to_user_id_str" : "105907649",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcelo Calbucci",
      "screen_name" : "calbucci",
      "indices" : [ 3, 12 ],
      "id_str" : "14232711",
      "id" : 14232711
    }, {
      "name" : "John Ludwig",
      "screen_name" : "jhludwig",
      "indices" : [ 100, 109 ],
      "id_str" : "21768224",
      "id" : 21768224
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 96 ],
      "url" : "http://t.co/yvu2mU9u",
      "expanded_url" : "http://j.mp/sQaqNE",
      "display_url" : "j.mp/sQaqNE"
    } ]
  },
  "geo" : {
  },
  "id_str" : "135078036667244544",
  "text" : "RT @calbucci: Feels like the Seattle economy is on the cusp of an expansion http://t.co/yvu2mU9u by @jhludwig",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "John Ludwig",
        "screen_name" : "jhludwig",
        "indices" : [ 86, 95 ],
        "id_str" : "21768224",
        "id" : 21768224
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 62, 82 ],
        "url" : "http://t.co/yvu2mU9u",
        "expanded_url" : "http://j.mp/sQaqNE",
        "display_url" : "j.mp/sQaqNE"
      } ]
    },
    "geo" : {
    },
    "id_str" : "135073360366411776",
    "text" : "Feels like the Seattle economy is on the cusp of an expansion http://t.co/yvu2mU9u by @jhludwig",
    "id" : 135073360366411776,
    "created_at" : "Fri Nov 11 19:16:13 +0000 2011",
    "user" : {
      "name" : "Marcelo Calbucci",
      "screen_name" : "calbucci",
      "protected" : false,
      "id_str" : "14232711",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1468000962/seattle-rock-n-roll-2011-calbucci_normal.jpg",
      "id" : 14232711,
      "verified" : false
    }
  },
  "id" : 135078036667244544,
  "created_at" : "Fri Nov 11 19:34:48 +0000 2011",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "thetontons",
      "screen_name" : "thetontons",
      "indices" : [ 16, 27 ],
      "id_str" : "15235445",
      "id" : 15235445
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "campmighty",
      "indices" : [ 31, 42 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 97 ],
      "url" : "http://t.co/8N0uR46Z",
      "expanded_url" : "http://flic.kr/p/aDD8iv",
      "display_url" : "flic.kr/p/aDD8iv"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 33.800666, -116.5405 ]
  },
  "id_str" : "134856397753040896",
  "text" : "8:36pm Watching @thetontons at #campmighty! Check them out they are awesome! http://t.co/8N0uR46Z",
  "id" : 134856397753040896,
  "created_at" : "Fri Nov 11 04:54:05 +0000 2011",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/busterbenson/status/134761655384031232/photo/1",
      "indices" : [ 115, 135 ],
      "url" : "http://t.co/XGPJEE5J",
      "media_url" : "http://pbs.twimg.com/media/Ad7FAvbCQAIKqLS.png",
      "id_str" : "134761655388225538",
      "id" : 134761655388225538,
      "media_url_https" : "https://pbs.twimg.com/media/Ad7FAvbCQAIKqLS.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 560,
        "resize" : "fit",
        "w" : 809
      }, {
        "h" : 560,
        "resize" : "fit",
        "w" : 809
      }, {
        "h" : 235,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 415,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com/XGPJEE5J"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "134761655384031232",
  "text" : "Top answers for how to get out of a bad mood: going on a walk/run, going outside, loud music, taking a nap. Chart: http://t.co/XGPJEE5J",
  "id" : 134761655384031232,
  "created_at" : "Thu Nov 10 22:37:38 +0000 2011",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Megan Welling",
      "screen_name" : "MeganWelling",
      "indices" : [ 0, 13 ],
      "id_str" : "26166039",
      "id" : 26166039
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 84 ],
      "url" : "http://t.co/uZhuR8p6",
      "expanded_url" : "http://www.businessinsider.com/the-mcrib-could-prove-that-mcdonalds-is-more-a-massive-commidies-trader-than-a-restaurant-chain-2011-11",
      "display_url" : "businessinsider.com/the-mcrib-coul…"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 33.8007042601, -116.54024461 ]
  },
  "id_str" : "134700984680202241",
  "in_reply_to_user_id" : 26166039,
  "text" : "@MeganWelling Disturbing news about your car's secret identity: http://t.co/uZhuR8p6",
  "id" : 134700984680202241,
  "created_at" : "Thu Nov 10 18:36:32 +0000 2011",
  "in_reply_to_screen_name" : "MeganWelling",
  "in_reply_to_user_id_str" : "26166039",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Maggie Mason",
      "screen_name" : "Maggie",
      "indices" : [ 0, 7 ],
      "id_str" : "448",
      "id" : 448
    }, {
      "name" : "Helen Jane",
      "screen_name" : "helenjane",
      "indices" : [ 8, 18 ],
      "id_str" : "798542",
      "id" : 798542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "134453798058987520",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 33.8008589745, -116.5402655022 ]
  },
  "id_str" : "134698574922518529",
  "in_reply_to_user_id" : 448,
  "text" : "@Maggie @helenjane I just arrived at the Camp Mighty! HJ you better get moving!",
  "id" : 134698574922518529,
  "in_reply_to_status_id" : 134453798058987520,
  "created_at" : "Thu Nov 10 18:26:57 +0000 2011",
  "in_reply_to_screen_name" : "Maggie",
  "in_reply_to_user_id_str" : "448",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 44, 54 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 76 ],
      "url" : "http://t.co/Rauk5hxU",
      "expanded_url" : "http://4sq.com/vPrBdy",
      "display_url" : "4sq.com/vPrBdy"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 33.80067344, -116.540061 ]
  },
  "id_str" : "134697674262847488",
  "text" : "Can we move in? (@ Ace Hotel & Swim Club w/ @kellianne) http://t.co/Rauk5hxU",
  "id" : 134697674262847488,
  "created_at" : "Thu Nov 10 18:23:22 +0000 2011",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 94 ],
      "url" : "http://t.co/16cOW3Yr",
      "expanded_url" : "http://4sq.com/sIQ2oO",
      "display_url" : "4sq.com/sIQ2oO"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.4431604237, -122.3032486439 ]
  },
  "id_str" : "134631846490288129",
  "text" : "Heading to Palm Springs for Camp Mighty! &kb,nb:breakfast (@ Dish D'Lish) http://t.co/16cOW3Yr",
  "id" : 134631846490288129,
  "created_at" : "Thu Nov 10 14:01:48 +0000 2011",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 0, 9 ],
      "id_str" : "761628",
      "id" : 761628
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "134520305166188544",
  "geo" : {
  },
  "id_str" : "134521168647565312",
  "in_reply_to_user_id" : 761628,
  "text" : "@RickWebb Or rather, the old way they did it was just REALLY bad. Glad it's better now though.",
  "id" : 134521168647565312,
  "in_reply_to_status_id" : 134520305166188544,
  "created_at" : "Thu Nov 10 06:42:00 +0000 2011",
  "in_reply_to_screen_name" : "RickWebb",
  "in_reply_to_user_id_str" : "761628",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ciaran Lyons",
      "screen_name" : "crayonlions",
      "indices" : [ 0, 12 ],
      "id_str" : "231087644",
      "id" : 231087644
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 73 ],
      "url" : "http://t.co/nKp1Wz2t",
      "expanded_url" : "http://howsmyemail.com",
      "display_url" : "howsmyemail.com"
    } ]
  },
  "in_reply_to_status_id_str" : "134455437482393600",
  "geo" : {
  },
  "id_str" : "134462689085898753",
  "in_reply_to_user_id" : 231087644,
  "text" : "@crayonlions I didn't find one, but I did build one: http://t.co/nKp1Wz2t",
  "id" : 134462689085898753,
  "in_reply_to_status_id" : 134455437482393600,
  "created_at" : "Thu Nov 10 02:49:37 +0000 2011",
  "in_reply_to_screen_name" : "crayonlions",
  "in_reply_to_user_id_str" : "231087644",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jen S. McCabe",
      "screen_name" : "jensmccabe",
      "indices" : [ 0, 11 ],
      "id_str" : "14258044",
      "id" : 14258044
    }, {
      "name" : "Amelia Greenhall",
      "screen_name" : "ameliagreenhall",
      "indices" : [ 95, 111 ],
      "id_str" : "246531241",
      "id" : 246531241
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "134431749919866880",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6085176063, -122.3065045976 ]
  },
  "id_str" : "134433231352238082",
  "in_reply_to_user_id" : 14258044,
  "text" : "@jensmccabe Another great book but please don't become an Objectivist. :) Are you going off of @ameliagreenhall's read books list?",
  "id" : 134433231352238082,
  "in_reply_to_status_id" : 134431749919866880,
  "created_at" : "Thu Nov 10 00:52:34 +0000 2011",
  "in_reply_to_screen_name" : "jensmccabe",
  "in_reply_to_user_id_str" : "14258044",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jen S. McCabe",
      "screen_name" : "jensmccabe",
      "indices" : [ 0, 11 ],
      "id_str" : "14258044",
      "id" : 14258044
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "134429614574546944",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6085273089, -122.3063194846 ]
  },
  "id_str" : "134430362653827072",
  "in_reply_to_user_id" : 14258044,
  "text" : "@jensmccabe I loved that book! The next 2 get a lot weirder.",
  "id" : 134430362653827072,
  "in_reply_to_status_id" : 134429614574546944,
  "created_at" : "Thu Nov 10 00:41:10 +0000 2011",
  "in_reply_to_screen_name" : "jensmccabe",
  "in_reply_to_user_id_str" : "14258044",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "134392728896282624",
  "text" : "What do you do to help get yourself out of a bad mood? I'll include aggregate answers in a talk I'm giving on Friday.",
  "id" : 134392728896282624,
  "created_at" : "Wed Nov 09 22:11:38 +0000 2011",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 83 ],
      "url" : "http://t.co/ZimxjxYs",
      "expanded_url" : "http://campmighty.com",
      "display_url" : "campmighty.com"
    }, {
      "indices" : [ 89, 109 ],
      "url" : "http://t.co/3u8I1AMP",
      "expanded_url" : "http://flic.kr/p/aD8UAk",
      "display_url" : "flic.kr/p/aD8UAk"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.612166, -122.317167 ]
  },
  "id_str" : "134136198066221056",
  "text" : "8:36pm Got the slow chicken for date night while I rehearse my http://t.co/ZimxjxYs talk http://t.co/3u8I1AMP",
  "id" : 134136198066221056,
  "created_at" : "Wed Nov 09 05:12:16 +0000 2011",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joel Longtine",
      "screen_name" : "jlongtine",
      "indices" : [ 0, 10 ],
      "id_str" : "722793",
      "id" : 722793
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 43 ],
      "url" : "http://t.co/HxMMyhnY",
      "expanded_url" : "http://www.youtube.com/watch?feature=player_embedded&v=GnGI76__sSA",
      "display_url" : "youtube.com/watch?feature=…"
    } ]
  },
  "in_reply_to_status_id_str" : "133781816606851072",
  "geo" : {
  },
  "id_str" : "134003875358310401",
  "in_reply_to_user_id" : 722793,
  "text" : "@jlongtine Here ya go: http://t.co/HxMMyhnY",
  "id" : 134003875358310401,
  "in_reply_to_status_id" : 133781816606851072,
  "created_at" : "Tue Nov 08 20:26:28 +0000 2011",
  "in_reply_to_screen_name" : "jlongtine",
  "in_reply_to_user_id_str" : "722793",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amit superamit Gupta",
      "screen_name" : "superamit",
      "indices" : [ 10, 20 ],
      "id_str" : "10609",
      "id" : 10609
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http://t.co/x1601Li9",
      "expanded_url" : "http://www.facebook.com/event.php?eid=174595119298897",
      "display_url" : "facebook.com/event.php?eid=…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "134002673786695680",
  "text" : "My friend @superamit has leukemia, and needs to find a bone marrow match. Get swabbed for free next Tuesday at Rob Roy: http://t.co/x1601Li9",
  "id" : 134002673786695680,
  "created_at" : "Tue Nov 08 20:21:41 +0000 2011",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 122 ],
      "url" : "http://t.co/AYbwizJC",
      "expanded_url" : "http://flic.kr/p/aCVyf7",
      "display_url" : "flic.kr/p/aCVyf7"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.608333, -122.306167 ]
  },
  "id_str" : "133766945295171584",
  "text" : "8:36pm Watching Jony Ive talk about enjoying the defeat of cynicism, and the pursuit of giving a damn http://t.co/AYbwizJC",
  "id" : 133766945295171584,
  "created_at" : "Tue Nov 08 04:44:59 +0000 2011",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenny Mackintosh",
      "screen_name" : "JennyMack",
      "indices" : [ 0, 10 ],
      "id_str" : "11653972",
      "id" : 11653972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "133613964000104448",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6085984933, -122.3060010105 ]
  },
  "id_str" : "133677198493237249",
  "in_reply_to_user_id" : 11653972,
  "text" : "@JennyMack Yes! I'm just rather sick with a cold at the moment. Can we do it over email? My brain is fuzzy.",
  "id" : 133677198493237249,
  "in_reply_to_status_id" : 133613964000104448,
  "created_at" : "Mon Nov 07 22:48:22 +0000 2011",
  "in_reply_to_screen_name" : "JennyMack",
  "in_reply_to_user_id_str" : "11653972",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "rescuetime",
      "screen_name" : "rescuetime",
      "indices" : [ 3, 14 ],
      "id_str" : "10803182",
      "id" : 10803182
    }, {
      "name" : "david reeves",
      "screen_name" : "dreeves",
      "indices" : [ 69, 77 ],
      "id_str" : "947851",
      "id" : 947851
    }, {
      "name" : "Buster Benson",
      "screen_name" : "busterbenson",
      "indices" : [ 78, 91 ],
      "id_str" : "2185",
      "id" : 2185
    }, {
      "name" : "Habit Labs",
      "screen_name" : "habitlabs",
      "indices" : [ 92, 102 ],
      "id_str" : "250986038",
      "id" : 250986038
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 125 ],
      "url" : "http://t.co/ywfEEpr2",
      "expanded_url" : "http://bit.ly/szvqUl",
      "display_url" : "bit.ly/szvqUl"
    } ]
  },
  "geo" : {
  },
  "id_str" : "133676942313533440",
  "text" : "RT @rescuetime: A Quick Look at Seattle's Self Quantified Meetup cc/ @dreeves @busterbenson @habitlabs - http://t.co/ywfEEpr2",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.hootsuite.com\" rel=\"nofollow\">HootSuite</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "david reeves",
        "screen_name" : "dreeves",
        "indices" : [ 53, 61 ],
        "id_str" : "947851",
        "id" : 947851
      }, {
        "name" : "Buster Benson",
        "screen_name" : "busterbenson",
        "indices" : [ 62, 75 ],
        "id_str" : "2185",
        "id" : 2185
      }, {
        "name" : "Habit Labs",
        "screen_name" : "habitlabs",
        "indices" : [ 76, 86 ],
        "id_str" : "250986038",
        "id" : 250986038
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 89, 109 ],
        "url" : "http://t.co/ywfEEpr2",
        "expanded_url" : "http://bit.ly/szvqUl",
        "display_url" : "bit.ly/szvqUl"
      } ]
    },
    "geo" : {
    },
    "id_str" : "133676342708404225",
    "text" : "A Quick Look at Seattle's Self Quantified Meetup cc/ @dreeves @busterbenson @habitlabs - http://t.co/ywfEEpr2",
    "id" : 133676342708404225,
    "created_at" : "Mon Nov 07 22:44:58 +0000 2011",
    "user" : {
      "name" : "rescuetime",
      "screen_name" : "rescuetime",
      "protected" : false,
      "id_str" : "10803182",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/58196015/icon2_normal.jpg",
      "id" : 10803182,
      "verified" : false
    }
  },
  "id" : 133676942313533440,
  "created_at" : "Mon Nov 07 22:47:21 +0000 2011",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 99 ],
      "url" : "http://t.co/BEpXt6gv",
      "expanded_url" : "http://flic.kr/p/aCAhV8",
      "display_url" : "flic.kr/p/aCAhV8"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.608666, -122.306167 ]
  },
  "id_str" : "133461957968805888",
  "text" : "8:36pm Was in a late work zone, then ran home to stay warm. Now getting tired. http://t.co/BEpXt6gv",
  "id" : 133461957968805888,
  "created_at" : "Mon Nov 07 08:33:05 +0000 2011",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marina Martin",
      "screen_name" : "MarinaMartin",
      "indices" : [ 0, 13 ],
      "id_str" : "60663",
      "id" : 60663
    }, {
      "name" : "A Jolly",
      "screen_name" : "Jolly",
      "indices" : [ 14, 20 ],
      "id_str" : "13030262",
      "id" : 13030262
    }, {
      "name" : "Grant Goodale",
      "screen_name" : "ggoodale",
      "indices" : [ 21, 30 ],
      "id_str" : "4270261",
      "id" : 4270261
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "133336506365513728",
  "geo" : {
  },
  "id_str" : "133344943740686338",
  "in_reply_to_user_id" : 60663,
  "text" : "@MarinaMartin @jolly @ggoodale It's not that accurate (not that any calories burned counters are). It's more about relative change.",
  "id" : 133344943740686338,
  "in_reply_to_status_id" : 133336506365513728,
  "created_at" : "Mon Nov 07 00:48:06 +0000 2011",
  "in_reply_to_screen_name" : "MarinaMartin",
  "in_reply_to_user_id_str" : "60663",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marina Martin",
      "screen_name" : "MarinaMartin",
      "indices" : [ 0, 13 ],
      "id_str" : "60663",
      "id" : 60663
    }, {
      "name" : "Fitbit",
      "screen_name" : "fitbit",
      "indices" : [ 42, 49 ],
      "id_str" : "17424053",
      "id" : 17424053
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "133330494057230336",
  "geo" : {
  },
  "id_str" : "133331625294573568",
  "in_reply_to_user_id" : 60663,
  "text" : "@MarinaMartin Yes, I highly recommend the @fitbit. A perfect little gadget.",
  "id" : 133331625294573568,
  "in_reply_to_status_id" : 133330494057230336,
  "created_at" : "Sun Nov 06 23:55:11 +0000 2011",
  "in_reply_to_screen_name" : "MarinaMartin",
  "in_reply_to_user_id_str" : "60663",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagr.am\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 47 ],
      "url" : "http://t.co/jHhR2Vw0",
      "expanded_url" : "http://instagr.am/p/S8psG/",
      "display_url" : "instagr.am/p/S8psG/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6148716063, -122.328279018 ]
  },
  "id_str" : "133045955024011264",
  "text" : "Big Dinner!  @ Terra Plata http://t.co/jHhR2Vw0",
  "id" : 133045955024011264,
  "created_at" : "Sun Nov 06 05:00:02 +0000 2011",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 82 ],
      "url" : "http://t.co/mc8asAs9",
      "expanded_url" : "http://flic.kr/p/aCc25R",
      "display_url" : "flic.kr/p/aCc25R"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.604833, -122.326167 ]
  },
  "id_str" : "133025786646114304",
  "text" : "8:36pm Ubering it home to relieve Kellianne of our cranky son http://t.co/mc8asAs9",
  "id" : 133025786646114304,
  "created_at" : "Sun Nov 06 03:39:53 +0000 2011",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alfie Kohn",
      "screen_name" : "alfiekohn",
      "indices" : [ 9, 19 ],
      "id_str" : "48203749",
      "id" : 48203749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 110 ],
      "url" : "http://t.co/dSzmg5Ak",
      "expanded_url" : "http://www.alfiekohn.org/teaching/selfdiscipline.htm",
      "display_url" : "alfiekohn.org/teaching/selfd…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "132973661786341376",
  "text" : "In which @alfiekohn convinces me that all that talk about grit a while ago was misguided: http://t.co/dSzmg5Ak",
  "id" : 132973661786341376,
  "created_at" : "Sun Nov 06 00:12:46 +0000 2011",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 35, 44 ],
      "id_str" : "761628",
      "id" : 761628
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 66 ],
      "url" : "http://t.co/HiC6HKk8",
      "expanded_url" : "http://flic.kr/p/aBUUqF",
      "display_url" : "flic.kr/p/aBUUqF"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6085, -122.306334 ]
  },
  "id_str" : "132664406675963904",
  "text" : "8:36pm Susie and Cory finally meet @rickwebb! http://t.co/HiC6HKk8",
  "id" : 132664406675963904,
  "created_at" : "Sat Nov 05 03:43:53 +0000 2011",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 66 ],
      "url" : "http://t.co/xpvrRsZf",
      "expanded_url" : "http://flic.kr/p/aBHrwy",
      "display_url" : "flic.kr/p/aBHrwy"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.614, -122.317167 ]
  },
  "id_str" : "132312504763297792",
  "text" : "8:36pm With Rick Webb and Scottie and friends http://t.co/xpvrRsZf",
  "id" : 132312504763297792,
  "created_at" : "Fri Nov 04 04:25:34 +0000 2011",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "techstars",
      "screen_name" : "techstars",
      "indices" : [ 22, 32 ],
      "id_str" : "14277276",
      "id" : 14277276
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tsdday",
      "indices" : [ 96, 103 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 95 ],
      "url" : "http://t.co/OAyKF3me",
      "expanded_url" : "http://bit.ly/sDWdjZ",
      "display_url" : "bit.ly/sDWdjZ"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.5984411338, -122.3226212919 ]
  },
  "id_str" : "132245573305765888",
  "text" : "Follow all of today's @TechStars founders & companies from a single place: http://t.co/OAyKF3me #tsdday",
  "id" : 132245573305765888,
  "created_at" : "Thu Nov 03 23:59:36 +0000 2011",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "EveryMove",
      "screen_name" : "EveryMove",
      "indices" : [ 10, 20 ],
      "id_str" : "17598513",
      "id" : 17598513
    }, {
      "name" : "techstars",
      "screen_name" : "techstars",
      "indices" : [ 28, 38 ],
      "id_str" : "14277276",
      "id" : 14277276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.5878674529, -122.3339470738 ]
  },
  "id_str" : "132233017853870080",
  "text" : "We've got @everymove on the @techstars stage!",
  "id" : 132233017853870080,
  "created_at" : "Thu Nov 03 23:09:42 +0000 2011",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laura Gluhanich",
      "screen_name" : "LauraGlu",
      "indices" : [ 0, 9 ],
      "id_str" : "9428232",
      "id" : 9428232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "132202837231939585",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.587917475, -122.3338253262 ]
  },
  "id_str" : "132203366716669952",
  "in_reply_to_user_id" : 9428232,
  "text" : "@LauraGlu If you plea for fruit people will heal you! If only they could heal in real life though.",
  "id" : 132203366716669952,
  "in_reply_to_status_id" : 132202837231939585,
  "created_at" : "Thu Nov 03 21:11:53 +0000 2011",
  "in_reply_to_screen_name" : "LauraGlu",
  "in_reply_to_user_id_str" : "9428232",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katherine Smith",
      "screen_name" : "katherinesmith",
      "indices" : [ 0, 15 ],
      "id_str" : "8497382",
      "id" : 8497382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "132157326303035392",
  "geo" : {
  },
  "id_str" : "132157594935631872",
  "in_reply_to_user_id" : 8497382,
  "text" : "@katherinesmith Thank you! How did you find out about it?",
  "id" : 132157594935631872,
  "in_reply_to_status_id" : 132157326303035392,
  "created_at" : "Thu Nov 03 18:10:00 +0000 2011",
  "in_reply_to_screen_name" : "katherinesmith",
  "in_reply_to_user_id_str" : "8497382",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "132155748875644928",
  "geo" : {
  },
  "id_str" : "132156020964339712",
  "in_reply_to_user_id" : 50938549,
  "text" : "@mbjwork Not at all. What do you worry about?",
  "id" : 132156020964339712,
  "in_reply_to_status_id" : 132155748875644928,
  "created_at" : "Thu Nov 03 18:03:45 +0000 2011",
  "in_reply_to_screen_name" : "miltonbjones",
  "in_reply_to_user_id_str" : "50938549",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ario Jafarzadeh",
      "screen_name" : "ario",
      "indices" : [ 0, 5 ],
      "id_str" : "294",
      "id" : 294
    }, {
      "name" : "matt trent",
      "screen_name" : "squarewithin",
      "indices" : [ 22, 35 ],
      "id_str" : "243747766",
      "id" : 243747766
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "131988977392685057",
  "geo" : {
  },
  "id_str" : "132148333899821057",
  "in_reply_to_user_id" : 294,
  "text" : "@ario Absolutely! /cc @squarewithin",
  "id" : 132148333899821057,
  "in_reply_to_status_id" : 131988977392685057,
  "created_at" : "Thu Nov 03 17:33:12 +0000 2011",
  "in_reply_to_screen_name" : "ario",
  "in_reply_to_user_id_str" : "294",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian Sefferman",
      "screen_name" : "iseff",
      "indices" : [ 0, 6 ],
      "id_str" : "5500",
      "id" : 5500
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "132142638647361536",
  "geo" : {
  },
  "id_str" : "132148201833762818",
  "in_reply_to_user_id" : 5500,
  "text" : "@iseff I'm a big fan of Jawbone. Haven't seen actual app though... they seem to do great on hardware and not as great on software...",
  "id" : 132148201833762818,
  "in_reply_to_status_id" : 132142638647361536,
  "created_at" : "Thu Nov 03 17:32:41 +0000 2011",
  "in_reply_to_screen_name" : "iseff",
  "in_reply_to_user_id_str" : "5500",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http://t.co/cXIJjPSY",
      "expanded_url" : "http://mashable.com/2011/11/03/jawbone-up-99-wristband-rule-life/",
      "display_url" : "mashable.com/2011/11/03/jaw…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "132147929367588864",
  "text" : "Bunch of people asking if I'm gonna get a Jawbone UP. Answer: yes! I love Jawbone the company, they make great stuff. http://t.co/cXIJjPSY",
  "id" : 132147929367588864,
  "created_at" : "Thu Nov 03 17:31:36 +0000 2011",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 43 ],
      "url" : "http://t.co/mB1kQVO0",
      "expanded_url" : "http://flic.kr/p/aBrQ5L",
      "display_url" : "flic.kr/p/aBrQ5L"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.608666, -122.306 ]
  },
  "id_str" : "131954375164833792",
  "text" : "8:36pm Working at home http://t.co/mB1kQVO0",
  "id" : 131954375164833792,
  "created_at" : "Thu Nov 03 04:42:29 +0000 2011",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenny Mackintosh",
      "screen_name" : "JennyMack",
      "indices" : [ 0, 10 ],
      "id_str" : "11653972",
      "id" : 11653972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "131913931286515713",
  "geo" : {
  },
  "id_str" : "131916752211804160",
  "in_reply_to_user_id" : 11653972,
  "text" : "@JennyMack Of course! busterbenson at gmail...",
  "id" : 131916752211804160,
  "in_reply_to_status_id" : 131913931286515713,
  "created_at" : "Thu Nov 03 02:12:59 +0000 2011",
  "in_reply_to_screen_name" : "JennyMack",
  "in_reply_to_user_id_str" : "11653972",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenny Mackintosh",
      "screen_name" : "JennyMack",
      "indices" : [ 0, 10 ],
      "id_str" : "11653972",
      "id" : 11653972
    }, {
      "name" : "Maura McGovern",
      "screen_name" : "mmcgovern",
      "indices" : [ 11, 21 ],
      "id_str" : "15856582",
      "id" : 15856582
    }, {
      "name" : "Health Month",
      "screen_name" : "healthmonth",
      "indices" : [ 71, 83 ],
      "id_str" : "154236895",
      "id" : 154236895
    }, {
      "name" : "Habit Labs",
      "screen_name" : "habitlabs",
      "indices" : [ 88, 98 ],
      "id_str" : "250986038",
      "id" : 250986038
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "131904680518369282",
  "geo" : {
  },
  "id_str" : "131907676585213952",
  "in_reply_to_user_id" : 11653972,
  "text" : "@JennyMack @mmcgovern I'm glad you both like it! Yeah, I'm focusing on @healthmonth and @habitlabs, but always available for chatting.",
  "id" : 131907676585213952,
  "in_reply_to_status_id" : 131904680518369282,
  "created_at" : "Thu Nov 03 01:36:55 +0000 2011",
  "in_reply_to_screen_name" : "JennyMack",
  "in_reply_to_user_id_str" : "11653972",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amit superamit Gupta",
      "screen_name" : "superamit",
      "indices" : [ 3, 13 ],
      "id_str" : "10609",
      "id" : 10609
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 128 ],
      "url" : "http://t.co/GzYdNviB",
      "expanded_url" : "http://www.wired.com/epicenter/2011/11/amit-guptas-quest-social-media/2/",
      "display_url" : "wired.com/epicenter/2011…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "131897249297997824",
  "text" : "RT @superamit: Wired does an *excellent* job explaining the technical and legal aspects of marrow matching: http://t.co/GzYdNviB",
  "retweeted_status" : {
    "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 113 ],
        "url" : "http://t.co/GzYdNviB",
        "expanded_url" : "http://www.wired.com/epicenter/2011/11/amit-guptas-quest-social-media/2/",
        "display_url" : "wired.com/epicenter/2011…"
      } ]
    },
    "geo" : {
    },
    "id_str" : "131807219653152770",
    "text" : "Wired does an *excellent* job explaining the technical and legal aspects of marrow matching: http://t.co/GzYdNviB",
    "id" : 131807219653152770,
    "created_at" : "Wed Nov 02 18:57:44 +0000 2011",
    "user" : {
      "name" : "Amit superamit Gupta",
      "screen_name" : "superamit",
      "protected" : false,
      "id_str" : "10609",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2839151893/f62ce69123d744f68381edfda11ed942_normal.jpeg",
      "id" : 10609,
      "verified" : false
    }
  },
  "id" : 131897249297997824,
  "created_at" : "Thu Nov 03 00:55:29 +0000 2011",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagr.am\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 85 ],
      "url" : "http://t.co/l6PTFvnN",
      "expanded_url" : "http://Healthmonth.com",
      "display_url" : "Healthmonth.com"
    }, {
      "indices" : [ 87, 107 ],
      "url" : "http://t.co/I6HitCwP",
      "expanded_url" : "http://instagr.am/p/SgCJ7/",
      "display_url" : "instagr.am/p/SgCJ7/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.616957, -122.337396 ]
  },
  "id_str" : "131873457934835712",
  "text" : "Office plank contest and Jen wins with 3:15!!   @ Habit Labs HQ (http://t.co/l6PTFvnN) http://t.co/I6HitCwP",
  "id" : 131873457934835712,
  "created_at" : "Wed Nov 02 23:20:57 +0000 2011",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Uber Seattle",
      "screen_name" : "Uber_SEA",
      "indices" : [ 26, 35 ],
      "id_str" : "272162235",
      "id" : 272162235
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 105 ],
      "url" : "http://t.co/LqjnjUIa",
      "expanded_url" : "http://flic.kr/p/aB9Esf",
      "display_url" : "flic.kr/p/aB9Esf"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.617833, -122.336 ]
  },
  "id_str" : "131577197633871874",
  "text" : "8:36pm Treating myself to @uber_sea for date night since work is kicking so much ass http://t.co/LqjnjUIa",
  "id" : 131577197633871874,
  "created_at" : "Wed Nov 02 03:43:43 +0000 2011",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Coates",
      "screen_name" : "tomcoates",
      "indices" : [ 0, 10 ],
      "id_str" : "12514",
      "id" : 12514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "131562055525347329",
  "geo" : {
  },
  "id_str" : "131562362938466304",
  "in_reply_to_user_id" : 12514,
  "text" : "@tomcoates Those lucky ducks. I was using MealSnap before this... so this app definitely fulfills a need I have, and it's beautiful too!",
  "id" : 131562362938466304,
  "in_reply_to_status_id" : 131562055525347329,
  "created_at" : "Wed Nov 02 02:44:46 +0000 2011",
  "in_reply_to_screen_name" : "tomcoates",
  "in_reply_to_user_id_str" : "12514",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Coates",
      "screen_name" : "tomcoates",
      "indices" : [ 0, 10 ],
      "id_str" : "12514",
      "id" : 12514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "131559291504177152",
  "geo" : {
  },
  "id_str" : "131560075214073856",
  "in_reply_to_user_id" : 12514,
  "text" : "@tomcoates Ooh, I didn't know you helped with it. Well done! Loving it so far.",
  "id" : 131560075214073856,
  "in_reply_to_status_id" : 131559291504177152,
  "created_at" : "Wed Nov 02 02:35:40 +0000 2011",
  "in_reply_to_screen_name" : "tomcoates",
  "in_reply_to_user_id_str" : "12514",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Maura McGovern",
      "screen_name" : "mmcgovern",
      "indices" : [ 0, 10 ],
      "id_str" : "15856582",
      "id" : 15856582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "131452383384436736",
  "geo" : {
  },
  "id_str" : "131554099039715329",
  "in_reply_to_user_id" : 15856582,
  "text" : "@mmcgovern It should be possible to sign up until the end of the day!",
  "id" : 131554099039715329,
  "in_reply_to_status_id" : 131452383384436736,
  "created_at" : "Wed Nov 02 02:11:56 +0000 2011",
  "in_reply_to_screen_name" : "mmcgovern",
  "in_reply_to_user_id_str" : "15856582",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Owens",
      "screen_name" : "mko",
      "indices" : [ 0, 4 ],
      "id_str" : "11822502",
      "id" : 11822502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "131454450882715648",
  "geo" : {
  },
  "id_str" : "131553996593827840",
  "in_reply_to_user_id" : 11822502,
  "text" : "@mko Definitely do. I'm very interested in anything like that.",
  "id" : 131553996593827840,
  "in_reply_to_status_id" : 131454450882715648,
  "created_at" : "Wed Nov 02 02:11:31 +0000 2011",
  "in_reply_to_screen_name" : "mko",
  "in_reply_to_user_id_str" : "11822502",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 118 ],
      "url" : "http://t.co/UBj5bvZx",
      "expanded_url" : "http://blog.habitlabs.com/post/12224190963/week-4-went-really-well-i-weighed-in-at-170-3",
      "display_url" : "blog.habitlabs.com/post/122241909…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "131553321734512640",
  "text" : "After a rocky month, I'm back on track to hitting my reverse new year's goal of losing 15 pounds! http://t.co/UBj5bvZx",
  "id" : 131553321734512640,
  "created_at" : "Wed Nov 02 02:08:50 +0000 2011",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kate Miles",
      "screen_name" : "kateskee",
      "indices" : [ 0, 9 ],
      "id_str" : "20750132",
      "id" : 20750132
    }, {
      "name" : "NaNoWriMo",
      "screen_name" : "NaNoWriMo",
      "indices" : [ 95, 105 ],
      "id_str" : "8984102",
      "id" : 8984102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "131527631370850305",
  "geo" : {
  },
  "id_str" : "131536490915307520",
  "in_reply_to_user_id" : 20750132,
  "text" : "@kateskee Yes! If you write more than 50,000 words in November, you'll get the NaNo badge! /cc @nanowrimo",
  "id" : 131536490915307520,
  "in_reply_to_status_id" : 131527631370850305,
  "created_at" : "Wed Nov 02 01:01:57 +0000 2011",
  "in_reply_to_screen_name" : "kateskee",
  "in_reply_to_user_id_str" : "20750132",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Owens",
      "screen_name" : "mko",
      "indices" : [ 0, 4 ],
      "id_str" : "11822502",
      "id" : 11822502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "131440322680074240",
  "geo" : {
  },
  "id_str" : "131443273536516096",
  "in_reply_to_user_id" : 11822502,
  "text" : "@mko I'd love to hear more about the details.  Have you written or talked about this somewhere?",
  "id" : 131443273536516096,
  "in_reply_to_status_id" : 131440322680074240,
  "created_at" : "Tue Nov 01 18:51:33 +0000 2011",
  "in_reply_to_screen_name" : "mko",
  "in_reply_to_user_id_str" : "11822502",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Massive Health",
      "screen_name" : "massivehealth",
      "indices" : [ 3, 17 ],
      "id_str" : "224938017",
      "id" : 224938017
    }, {
      "name" : "that drew",
      "screen_name" : "thatdrew",
      "indices" : [ 22, 31 ],
      "id_str" : "1002913782",
      "id" : 1002913782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http://t.co/DHgc0mPq",
      "expanded_url" : "http://tnw.to/1Be4R",
      "display_url" : "tnw.to/1Be4R"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6085246144, -122.3059174233 ]
  },
  "id_str" : "131407059374714880",
  "text" : "Go @massivehealth! RT @thatdrew : The Eatery's 'Fit or Fat' is as addictive as 'Hot or Not'. AND you'll get healthy http://t.co/DHgc0mPq",
  "id" : 131407059374714880,
  "created_at" : "Tue Nov 01 16:27:39 +0000 2011",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Haugen",
      "screen_name" : "DanHaugen",
      "indices" : [ 0, 10 ],
      "id_str" : "15475130",
      "id" : 15475130
    }, {
      "name" : "Seth Miller",
      "screen_name" : "mostlymuppet",
      "indices" : [ 68, 81 ],
      "id_str" : "13740",
      "id" : 13740
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "131402801736724481",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6084623004, -122.3058192534 ]
  },
  "id_str" : "131404635511603200",
  "in_reply_to_user_id" : 13740,
  "text" : "@danhaugen Let me know if you have any questions I can answer! /thx @mostlymuppet",
  "id" : 131404635511603200,
  "in_reply_to_status_id" : 131402801736724481,
  "created_at" : "Tue Nov 01 16:18:01 +0000 2011",
  "in_reply_to_screen_name" : "mostlymuppet",
  "in_reply_to_user_id_str" : "13740",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
} ]