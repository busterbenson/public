Grailbird.data.tweets_2008_02 = 
 [ {
  "source" : "<a href=\"http://twitterrific.com\" rel=\"nofollow\">Twitterrific</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "761910022",
  "text" : "Updated my iPhone software but nothing new seems to be there yet.  Think there'll be an announcement later today?",
  "id" : 761910022,
  "created_at" : "2008-02-26 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "682519172",
  "text" : "New favorite soundbite: \"We are the ones we've been waiting for.\"",
  "id" : 682519172,
  "created_at" : "2008-02-06 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "679124402",
  "text" : "I just realized that health month officially ends right now. I made it! But I'm going one more day for kicks.",
  "id" : 679124402,
  "created_at" : "2008-02-05 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "668403232",
  "text" : "2.5 hours of holding, and .5 hours of talking... and now I have a bunch of numbers to consider.",
  "id" : 668403232,
  "created_at" : "2008-02-02 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "669227252",
  "text" : "I cheated on health month to eat a dog biscuit.",
  "id" : 669227252,
  "created_at" : "2008-02-02 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "670933502",
  "text" : "Taking class to get my class 12 bar permit!",
  "id" : 670933502,
  "created_at" : "2008-02-02 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
} ]