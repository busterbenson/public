Grailbird.data.tweets_2008_09 = 
 [ {
  "source" : "<a href=\"http://twitterrific.com\" rel=\"nofollow\">Twitterrific</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "941285634",
  "text" : "8:36pm KA was impressed with my yoga skills, now work on seating charts over DE sushi. http://tinyurl.com/3njkm2",
  "id" : 941285634,
  "created_at" : "2008-10-01 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "942058797",
  "text" : "Okay, I'm getting a little excited now.",
  "id" : 942058797,
  "created_at" : "2008-10-01 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "942176262",
  "text" : "Hit a snag! Missing crucial papers. May have to do a little gray lying!",
  "id" : 942176262,
  "created_at" : "2008-10-01 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "942208362",
  "text" : "Wearing my Phillies cap walking to the game, GO PHILLLLS!!!",
  "id" : 942208362,
  "created_at" : "2008-10-01 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitterrific.com\" rel=\"nofollow\">Twitterrific</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "939977047",
  "text" : "8:36pm Arrived in Wilmington, Samantha loves the iPhone games. http://tinyurl.com/5xpfry",
  "id" : 939977047,
  "created_at" : "2008-09-30 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitterrific.com\" rel=\"nofollow\">Twitterrific</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "938783610",
  "text" : "8:36pm Slowly packing, thinking and getting hungry. http://tinyurl.com/4gvwmw",
  "id" : 938783610,
  "created_at" : "2008-09-29 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "938843441",
  "text" : "-1 point from Tavolata for running out of sea bass, so we indulged in Pinot Grigio and delicious chocolate cake (+2 points).",
  "id" : 938843441,
  "created_at" : "2008-09-29 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitterrific.com\" rel=\"nofollow\">Twitterrific</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "939076693",
  "text" : "Up at four a.m. \nYesterday up til four. Go\ncoffee, booze, and planes.",
  "id" : 939076693,
  "created_at" : "2008-09-29 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitterrific.com\" rel=\"nofollow\">Twitterrific</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "939579520",
  "text" : "2.5 hour layover in NYC. I prefer to be in the air for earthquakes and economy-falling-aparts.",
  "id" : 939579520,
  "created_at" : "2008-09-29 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitterrific.com\" rel=\"nofollow\">Twitterrific</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "939662512",
  "text" : "Bill Murray just walked out of Delta gate 24 at JFK.",
  "id" : 939662512,
  "created_at" : "2008-09-29 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitterrific.com\" rel=\"nofollow\">Twitterrific</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan King",
      "screen_name" : "rk",
      "indices" : [ 0, 3 ],
      "id_str" : "19853",
      "id" : 19853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "939645694",
  "geo" : { },
  "id_str" : "939664432",
  "in_reply_to_user_id" : 19853,
  "text" : "@rk I'm at JFK too! And just said the same thing to Kellianne 14 minutes ago.",
  "id" : 939664432,
  "in_reply_to_status_id" : 939645694,
  "created_at" : "2008-09-29 00:00:00 +0000",
  "in_reply_to_screen_name" : "rk",
  "in_reply_to_user_id_str" : "19853",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitterrific.com\" rel=\"nofollow\">Twitterrific</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "939882751",
  "text" : "Ah the land of scrapple! Kellianne's brother says Biden's on his fantasy political team.",
  "id" : 939882751,
  "created_at" : "2008-09-29 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "937690716",
  "text" : "Eyeliner always turns me into a crybaby.",
  "id" : 937690716,
  "created_at" : "2008-09-28 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitterrific.com\" rel=\"nofollow\">Twitterrific</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "937772367",
  "text" : "8:36pm Getting ready for Elegantly Waisted \"back stage\". http://tinyurl.com/424zfu",
  "id" : 937772367,
  "created_at" : "2008-09-28 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "938465427",
  "text" : "Packing!  I think I take as much clothes for a 5 day trip as I do for a 30 day trip.",
  "id" : 938465427,
  "created_at" : "2008-09-28 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitterrific.com\" rel=\"nofollow\">Twitterrific</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "936744891",
  "text" : "8:36pm Dissecting the debates at Tom & Michele's. Obama won hands down. http://tinyurl.com/3rwlh5",
  "id" : 936744891,
  "created_at" : "2008-09-27 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "936772308",
  "text" : "Our cabbie thinks Obama looked green.",
  "id" : 936772308,
  "created_at" : "2008-09-27 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "935234414",
  "text" : "Shitballs.",
  "id" : 935234414,
  "created_at" : "2008-09-26 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "935241460",
  "text" : "Oh I get it, it's one of those \"how many things can go crazy at once\" situations...",
  "id" : 935241460,
  "created_at" : "2008-09-26 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitterrific.com\" rel=\"nofollow\">Twitterrific</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "935432211",
  "text" : "8:36pm The Madsens arrive with dinner and helpful hands! http://tinyurl.com/3nhd4d.",
  "id" : 935432211,
  "created_at" : "2008-09-26 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitterrific.com\" rel=\"nofollow\">Twitterrific</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "933914283",
  "text" : "8:36pm Eating green tea and sesame ice cream while eaves-dropping on a first date. http://tinyurl.com/3rpt7e",
  "id" : 933914283,
  "created_at" : "2008-09-25 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com/\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "934692986",
  "text" : "Does anyone in the Seattle area have a giant suitcase or two that they wouldn't mind lending to me for my honeymoon trip to Italy?",
  "id" : 934692986,
  "created_at" : "2008-09-25 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com/\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "934867311",
  "text" : "Muxtape's interesting story:  http://muxtape.com (I wonder what would've been different if he hadn't been on Amazon's servers)",
  "id" : 934867311,
  "created_at" : "2008-09-25 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com/\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "934882964",
  "text" : "When is me-trics.com gonna launch?!?  I'm seriously impatient about it.  I check their signup page like 3 times a day.  http://bit.ly/3I3wxr",
  "id" : 934882964,
  "created_at" : "2008-09-25 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "935047213",
  "text" : "Leaving the Robot Co-op offices. Will be back in a month!",
  "id" : 935047213,
  "created_at" : "2008-09-25 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitterrific.com\" rel=\"nofollow\">Twitterrific</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "932554558",
  "text" : "How to relax? Weird movie about a boy who blinds horses? Worth a try!",
  "id" : 932554558,
  "created_at" : "2008-09-24 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitterrific.com\" rel=\"nofollow\">Twitterrific</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "932560712",
  "text" : "8:36pm Watching Equus, sorta. http://tinyurl.com/4zasve",
  "id" : 932560712,
  "created_at" : "2008-09-24 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com/\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "senoraj",
      "screen_name" : "senoraj",
      "indices" : [ 0, 8 ],
      "id_str" : "13443292",
      "id" : 13443292
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "933310161",
  "geo" : { },
  "id_str" : "933314556",
  "in_reply_to_user_id" : 13443292,
  "text" : "@senoraj  Kellianne and I are SO using sidetaker.com the next time we have a fight.  It's awesome.",
  "id" : 933314556,
  "in_reply_to_status_id" : 933310161,
  "created_at" : "2008-09-24 00:00:00 +0000",
  "in_reply_to_screen_name" : "senoraj",
  "in_reply_to_user_id_str" : "13443292",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrej Gregov",
      "screen_name" : "agregov",
      "indices" : [ 0, 8 ],
      "id_str" : "752413",
      "id" : 752413
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "933328843",
  "geo" : { },
  "id_str" : "933360416",
  "in_reply_to_user_id" : 752413,
  "text" : "@agregov Why use the web client? Link it to gmail or the Mail app... I've had no problems at all.",
  "id" : 933360416,
  "in_reply_to_status_id" : 933328843,
  "created_at" : "2008-09-24 00:00:00 +0000",
  "in_reply_to_screen_name" : "agregov",
  "in_reply_to_user_id_str" : "752413",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "931048448",
  "text" : "After a brief infatuation with them, I now think that Brian Eno and Peter Schmidt's Oblique Strategies are actually bad strategies.",
  "id" : 931048448,
  "created_at" : "2008-09-23 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitterrific.com\" rel=\"nofollow\">Twitterrific</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "931234631",
  "text" : "8:36pm Dress rehearsal for the Elegantly Waisted fashion show this Saturday. Awesome! http://tinyurl.com/4m6mjw",
  "id" : 931234631,
  "created_at" : "2008-09-23 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitterrific.com\" rel=\"nofollow\">Twitterrific</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angela Baxley Glass",
      "screen_name" : "spunkygidget",
      "indices" : [ 0, 13 ],
      "id_str" : "17401816",
      "id" : 17401816
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "931259273",
  "geo" : { },
  "id_str" : "931303385",
  "in_reply_to_user_id" : 5667292,
  "text" : "@spunkygidget Yes, at McLeod, Sat, 9pm. Though come early cause it's going to sell out quick.",
  "id" : 931303385,
  "in_reply_to_status_id" : 931259273,
  "created_at" : "2008-09-23 00:00:00 +0000",
  "in_reply_to_screen_name" : "Baxley",
  "in_reply_to_user_id_str" : "5667292",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitterrific.com\" rel=\"nofollow\">Twitterrific</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "930002253",
  "text" : "8:36pm Talking group and singleton dynamics at Union, where we should come more often! http://tinyurl.com/3vq2ro",
  "id" : 930002253,
  "created_at" : "2008-09-22 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitterrific.com\" rel=\"nofollow\">Twitterrific</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "929009776",
  "text" : "8:36pm Staying in tonight watching Kellianne get ready to go out and have fun. http://tinyurl.com/5yrums",
  "id" : 929009776,
  "created_at" : "2008-09-21 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitterrific.com\" rel=\"nofollow\">Twitterrific</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "929041809",
  "text" : "I've never seen Blade Runner, apparently.",
  "id" : 929041809,
  "created_at" : "2008-09-21 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitterrific.com\" rel=\"nofollow\">Twitterrific</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "929118641",
  "text" : "From Zizek: We make things popular in order to avoid taking them seriously.",
  "id" : 929118641,
  "created_at" : "2008-09-21 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Harrison",
      "screen_name" : "sourjayne",
      "indices" : [ 0, 10 ],
      "id_str" : "4981271",
      "id" : 4981271
    }, {
      "name" : "D. Keith Robinson",
      "screen_name" : "dkr",
      "indices" : [ 15, 19 ],
      "id_str" : "10877",
      "id" : 10877
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "929145328",
  "geo" : { },
  "id_str" : "929145874",
  "in_reply_to_user_id" : 4981271,
  "text" : "@sourjayne and @dkr I see you on the photobooth!  Hi!  I would join you but I'm eating this bag of almonds.",
  "id" : 929145874,
  "in_reply_to_status_id" : 929145328,
  "created_at" : "2008-09-21 00:00:00 +0000",
  "in_reply_to_screen_name" : "sourjayne",
  "in_reply_to_user_id_str" : "4981271",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ingopixel",
      "screen_name" : "ingopixel",
      "indices" : [ 0, 10 ],
      "id_str" : "7943892",
      "id" : 7943892
    }, {
      "name" : "&y",
      "screen_name" : "andypixel",
      "indices" : [ 15, 25 ],
      "id_str" : "10015122",
      "id" : 10015122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "929153025",
  "geo" : { },
  "id_str" : "929154966",
  "in_reply_to_user_id" : 7943892,
  "text" : "@ingopixel and @andypixel Holy moley. Never suggest this to me when I'm drunk please.",
  "id" : 929154966,
  "in_reply_to_status_id" : 929153025,
  "created_at" : "2008-09-21 00:00:00 +0000",
  "in_reply_to_screen_name" : "ingopixel",
  "in_reply_to_user_id_str" : "7943892",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitterrific.com\" rel=\"nofollow\">Twitterrific</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "928071915",
  "text" : "8:36pm At our local, working on vow stuff. I love this woman! http://tinyurl.com/4bj6er",
  "id" : 928071915,
  "created_at" : "2008-09-20 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "928849400",
  "text" : "My Holmes and Rahe stress score is 187: \"mild risk of illness.\"  It needs to allow for anti-stressors too. http://tinyurl.com/45q9pc",
  "id" : 928849400,
  "created_at" : "2008-09-20 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitterrific.com\" rel=\"nofollow\">Twitterrific</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "926792249",
  "text" : "8:36pm Watching Mad Men in the dark with Kellianne's cold feet. http://tinyurl.com/3z5ql8",
  "id" : 926792249,
  "created_at" : "2008-09-19 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "927755824",
  "text" : "Where do text messages go when they are deleted?",
  "id" : 927755824,
  "created_at" : "2008-09-19 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitterrific.com\" rel=\"nofollow\">Twitterrific</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "925484210",
  "text" : "8:36pm Finishing up a delicious meal at the new Kushibar. http://tinyurl.com/4yo8ko",
  "id" : 925484210,
  "created_at" : "2008-09-18 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com/\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "926437360",
  "text" : "Mixing MobileMe, Address Book, merging duplicates, and the new sync software equals losing most of my contacts on 3 computers at once.",
  "id" : 926437360,
  "created_at" : "2008-09-18 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "924064006",
  "text" : "Taking a break from slow weights til after the wedding.  Resuming week three of the 100 pushup challenge... http://hundredpushups.com",
  "id" : 924064006,
  "created_at" : "2008-09-17 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitterrific.com\" rel=\"nofollow\">Twitterrific</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "924194741",
  "text" : "8:36pm Difficult conversations at our local spot.  http://tinyurl.com/5d2y6m",
  "id" : 924194741,
  "created_at" : "2008-09-17 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "925102337",
  "text" : "I want a service of some kind that you tell to alert you randomly N number of times between X and Y hours, daily.  Does it exist?",
  "id" : 925102337,
  "created_at" : "2008-09-17 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "925268831",
  "text" : "How would your online writing and presence change if you wrote exclusively for people who would read it 100 years from now?",
  "id" : 925268831,
  "created_at" : "2008-09-17 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com/\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helen Jane",
      "screen_name" : "helenjane",
      "indices" : [ 0, 10 ],
      "id_str" : "798542",
      "id" : 798542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "925273711",
  "geo" : { },
  "id_str" : "925285237",
  "in_reply_to_user_id" : 798542,
  "text" : "@helenjane  Your blog could be renamed \"100 year old lunch\"",
  "id" : 925285237,
  "in_reply_to_status_id" : 925273711,
  "created_at" : "2008-09-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "helenjane",
  "in_reply_to_user_id_str" : "798542",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitterrific.com\" rel=\"nofollow\">Twitterrific</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "922922973",
  "text" : "8:36pm Prepping Russell for his MC duties at Tilth qhttp://tinyurl.com/6btzyg",
  "id" : 922922973,
  "created_at" : "2008-09-16 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitterrific.com\" rel=\"nofollow\">Twitterrific</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Cottrell",
      "screen_name" : "rgcottrell",
      "indices" : [ 0, 11 ],
      "id_str" : "752553",
      "id" : 752553
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "923042344",
  "geo" : { },
  "id_str" : "923469441",
  "in_reply_to_user_id" : 752553,
  "text" : "@rgcottrell Which app? And yes, you should still finish!",
  "id" : 923469441,
  "in_reply_to_status_id" : 923042344,
  "created_at" : "2008-09-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "rgcottrell",
  "in_reply_to_user_id_str" : "752553",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "923580033",
  "text" : "OH: \"Information on how to become a millionaire if you've got some change for me.\"",
  "id" : 923580033,
  "created_at" : "2008-09-16 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com/\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Cottrell",
      "screen_name" : "rgcottrell",
      "indices" : [ 0, 11 ],
      "id_str" : "752553",
      "id" : 752553
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "923627452",
  "geo" : { },
  "id_str" : "923634170",
  "in_reply_to_user_id" : 752553,
  "text" : "@rgcottrell  Why do you need stepping stones??  Get to the real app!  :)",
  "id" : 923634170,
  "in_reply_to_status_id" : 923627452,
  "created_at" : "2008-09-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "rgcottrell",
  "in_reply_to_user_id_str" : "752553",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitterrific.com\" rel=\"nofollow\">Twitterrific</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "921672914",
  "text" : "8:36pm Trying to rally for round two of cleaning before Kellianne gets home. http://tinyurl.com/5wqah7",
  "id" : 921672914,
  "created_at" : "2008-09-15 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "920614911",
  "text" : "Headed to Kristen and Kyle's wedding solo.",
  "id" : 920614911,
  "created_at" : "2008-09-14 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitterrific.com\" rel=\"nofollow\">Twitterrific</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "920728291",
  "text" : "8:36pm Kristen and Kyle are married and my table is cracking me up. Yay marrieds! http://tinyurl.com/569ehe",
  "id" : 920728291,
  "created_at" : "2008-09-14 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "920898886",
  "text" : "Where's Andy and Ingo?",
  "id" : 920898886,
  "created_at" : "2008-09-14 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitterrific.com\" rel=\"nofollow\">Twitterrific</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "919754188",
  "text" : "8:36pm Dinner with Ario at Saito's... my first excursion of the day! http://tinyurl.com/3ud3d3",
  "id" : 919754188,
  "created_at" : "2008-09-13 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "920409909",
  "text" : "My six identical bowties scheme has hit a roadbump. Now I need to go buy some silk!",
  "id" : 920409909,
  "created_at" : "2008-09-13 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitterrific.com\" rel=\"nofollow\">Twitterrific</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "920467304",
  "text" : "All of my emotional triggers are re-routing through anger today.",
  "id" : 920467304,
  "created_at" : "2008-09-13 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitterrific.com\" rel=\"nofollow\">Twitterrific</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "918494550",
  "text" : "8:36pm Dinner with the Pixels, talking about Burning Man and things. http://tinyurl.com/47dk4h",
  "id" : 918494550,
  "created_at" : "2008-09-12 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "918572111",
  "text" : "We seem to be doing pretty good on our change quota even without Obama.",
  "id" : 918572111,
  "created_at" : "2008-09-12 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "919506131",
  "text" : "Insomnia made me come up with a way to view your LiveJournal friends page in a prettier, iPhone-friendly way.  http://tinyurl.com/5yxvxs",
  "id" : 919506131,
  "created_at" : "2008-09-12 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "917102103",
  "text" : "Cleaning this store out!",
  "id" : 917102103,
  "created_at" : "2008-09-11 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitterrific.com\" rel=\"nofollow\">Twitterrific</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "917280576",
  "text" : "8:36pm Drunk of the week comes home from the gym, stone cold sobertime. http://tinyurl.com/5e8tre",
  "id" : 917280576,
  "created_at" : "2008-09-11 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "917902885",
  "text" : "Day 3 of my grumpy mood.  At least I have an opportunity to seek some perspective on it all.",
  "id" : 917902885,
  "created_at" : "2008-09-11 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitterrific.com\" rel=\"nofollow\">Twitterrific</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "915934441",
  "text" : "Found a collapsed and sobbing girl in Pike Place... her fianc\u00E9 dumped her and ditched her in a miserable drugged state. Super sad.",
  "id" : 915934441,
  "created_at" : "2008-09-10 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "916108983",
  "text" : "Ten reasons why Obama is the candidate for us internet nerds, by hilarious lolz, llc: http://lolzllc.com/obama/",
  "id" : 916108983,
  "created_at" : "2008-09-10 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com/\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "916704519",
  "text" : "Well, I'm not gonna be rich, but I seem to be selling about 60 of my Credit Card Roulette apps a week.",
  "id" : 916704519,
  "created_at" : "2008-09-10 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com/\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan King",
      "screen_name" : "rk",
      "indices" : [ 8, 11 ],
      "id_str" : "19853",
      "id" : 19853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "916713347",
  "text" : "Retweet @rk: http://hasthelargehadroncolliderdestroyedtheworldyet.com/",
  "id" : 916713347,
  "created_at" : "2008-09-10 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com/\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Merlin Mann",
      "screen_name" : "hotdogsladies",
      "indices" : [ 13, 27 ],
      "id_str" : "749863",
      "id" : 749863
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "916776740",
  "text" : "Merlin Mann (@hotdogsladies) is on a roll lately with his posts.  I am curious to see where his latest move leads.  http://43folders.com",
  "id" : 916776740,
  "created_at" : "2008-09-10 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com/\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kris Kr\u00FCg",
      "screen_name" : "kk",
      "indices" : [ 0, 3 ],
      "id_str" : "13669",
      "id" : 13669
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "916782166",
  "geo" : { },
  "id_str" : "916786857",
  "in_reply_to_user_id" : 13669,
  "text" : "@kk  No, they're technology, and they're rendering evolution obsolete.  Survival of the fittest.",
  "id" : 916786857,
  "in_reply_to_status_id" : 916782166,
  "created_at" : "2008-09-10 00:00:00 +0000",
  "in_reply_to_screen_name" : "kk",
  "in_reply_to_user_id_str" : "13669",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitterrific.com\" rel=\"nofollow\">Twitterrific</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "914663744",
  "text" : "8:36pm On the last page of Bonk. Good book! http://tinyurl.com/5cjx8l",
  "id" : 914663744,
  "created_at" : "2008-09-09 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com/\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 0, 9 ],
      "id_str" : "761628",
      "id" : 761628
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "915298368",
  "geo" : { },
  "id_str" : "915300214",
  "in_reply_to_user_id" : 761628,
  "text" : "@RickWebb  Go Barbarians!",
  "id" : 915300214,
  "in_reply_to_status_id" : 915298368,
  "created_at" : "2008-09-09 00:00:00 +0000",
  "in_reply_to_screen_name" : "RickWebb",
  "in_reply_to_user_id_str" : "761628",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com/\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "brady forrest",
      "screen_name" : "brady",
      "indices" : [ 0, 6 ],
      "id_str" : "6140",
      "id" : 6140
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "915663630",
  "geo" : { },
  "id_str" : "915675860",
  "in_reply_to_user_id" : 6140,
  "text" : "@brady  Where does one order fitbit?  It's right up my alley... especially after being teased about the Nike+ thing.",
  "id" : 915675860,
  "in_reply_to_status_id" : 915663630,
  "created_at" : "2008-09-09 00:00:00 +0000",
  "in_reply_to_screen_name" : "brady",
  "in_reply_to_user_id_str" : "6140",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com/\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "brady forrest",
      "screen_name" : "brady",
      "indices" : [ 0, 6 ],
      "id_str" : "6140",
      "id" : 6140
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "915677325",
  "geo" : { },
  "id_str" : "915694608",
  "in_reply_to_user_id" : 6140,
  "text" : "@brady  Found the stealth page (that was easy) and ordered.  I hate waiting.  Are there any pictures of this thing anywhere?",
  "id" : 915694608,
  "in_reply_to_status_id" : 915677325,
  "created_at" : "2008-09-09 00:00:00 +0000",
  "in_reply_to_screen_name" : "brady",
  "in_reply_to_user_id_str" : "6140",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com/\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "915705819",
  "text" : "Just launched a redesigned 43 Things goal page, with a new feature called How I Did It.  Example: http://bit.ly/2ygtOq",
  "id" : 915705819,
  "created_at" : "2008-09-09 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitterrific.com\" rel=\"nofollow\">Twitterrific</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "913274600",
  "text" : "Final fitting for my bespoke suit from Kuhlman went great and I got to take it home. Very exciting!",
  "id" : 913274600,
  "created_at" : "2008-09-08 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitterrific.com\" rel=\"nofollow\">Twitterrific</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "913430370",
  "text" : "8:36pm It's just Sopor, me, wedding spreadsheets, and apple juice now. http://tinyurl.com/56x7fw",
  "id" : 913430370,
  "created_at" : "2008-09-08 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com/\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "914097518",
  "text" : "Our Robot Co-op offices landlord got caught in store this weekend doing up-skirts with a cardboard tube and a camera!  http://bit.ly/P5hp8",
  "id" : 914097518,
  "created_at" : "2008-09-08 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitterrific.com\" rel=\"nofollow\">Twitterrific</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "912458447",
  "text" : "8:36pm Day 4 of fast, watching There Will Be Blood as substitute for food and energy. http://tinyurl.com/6344gt",
  "id" : 912458447,
  "created_at" : "2008-09-07 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitterrific.com\" rel=\"nofollow\">Twitterrific</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "912927710",
  "text" : "My fasting cleanse is a hoax! I'm on day 5, should I complete it or abandon ship?",
  "id" : 912927710,
  "created_at" : "2008-09-07 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitterrific.com\" rel=\"nofollow\">Twitterrific</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Rainert",
      "screen_name" : "arainert",
      "indices" : [ 0, 9 ],
      "id_str" : "7482",
      "id" : 7482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "912938102",
  "geo" : { },
  "id_str" : "912948855",
  "in_reply_to_user_id" : 7482,
  "text" : "@arainert Researching detox fasts, and mucoid plaque in particular. Drinking juice is fine and good but the supplements are useless.",
  "id" : 912948855,
  "in_reply_to_status_id" : 912938102,
  "created_at" : "2008-09-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "arainert",
  "in_reply_to_user_id_str" : "7482",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitterrific.com\" rel=\"nofollow\">Twitterrific</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "912981689",
  "text" : "Decided to continue with the hoax to prove the birthday book wrong. Facts and whimsey hold equal influence in my life.",
  "id" : 912981689,
  "created_at" : "2008-09-07 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitterrific.com\" rel=\"nofollow\">Twitterrific</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "911512200",
  "text" : "8:36pm Day 3 of the cleansing fast is exhausting. Can only watch Peter & The Wolf. http://tinyurl.com/5z96ae",
  "id" : 911512200,
  "created_at" : "2008-09-06 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitterrific.com\" rel=\"nofollow\">Twitterrific</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russell Dicker",
      "screen_name" : "rdicker",
      "indices" : [ 0, 8 ],
      "id_str" : "958581",
      "id" : 958581
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "911510243",
  "geo" : { },
  "id_str" : "911512904",
  "in_reply_to_user_id" : 958581,
  "text" : "@rdicker Report back on that strange place please.",
  "id" : 911512904,
  "in_reply_to_status_id" : 911510243,
  "created_at" : "2008-09-06 00:00:00 +0000",
  "in_reply_to_screen_name" : "rdicker",
  "in_reply_to_user_id_str" : "958581",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "910140214",
  "text" : "My mood is too precarious to watch the RNC right now... I'll watch the highlights later.",
  "id" : 910140214,
  "created_at" : "2008-09-05 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "910254852",
  "text" : "That was mediocre!",
  "id" : 910254852,
  "created_at" : "2008-09-05 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitterrific.com\" rel=\"nofollow\">Twitterrific</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "910295511",
  "text" : "8:36pm Salad, salmon burgers, cous cous, McCain analysis, and bad rock music. http://tinyurl.com/5rdrh5",
  "id" : 910295511,
  "created_at" : "2008-09-05 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 63, 73 ],
      "id_str" : "7362142",
      "id" : 7362142
    }, {
      "name" : "Ali Berman",
      "screen_name" : "spangley",
      "indices" : [ 78, 87 ],
      "id_str" : "776429",
      "id" : 776429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "911142657",
  "text" : "Heart got angry for the RNC's use of their song, \"Barracuda\".  @kellianne and @spangley are vindicated. http://tinyurl.com/5g7c6g",
  "id" : 911142657,
  "created_at" : "2008-09-05 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitterrific.com\" rel=\"nofollow\">Twitterrific</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "908976838",
  "text" : "8:36pm Watching Reggie Watts and Mike Daisy answer questions about the meaning of life. http://tinyurl.com/6fk3jv",
  "id" : 908976838,
  "created_at" : "2008-09-04 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitterrific.com\" rel=\"nofollow\">Twitterrific</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "909847322",
  "text" : "I'm getting married one month from today! Juice fasting this week for a clear head.",
  "id" : 909847322,
  "created_at" : "2008-09-04 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitterrific.com\" rel=\"nofollow\">Twitterrific</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "907796785",
  "text" : "Our little cat, Sopor, was uncharacteristically outside when I closed the door this morning. We want her to come back to us now!",
  "id" : 907796785,
  "created_at" : "2008-09-03 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "908461887",
  "text" : "For the most bizarre set of reasons, I can't seem to keep an acupuncture appointment on my calendar.  Third missed in a row.  Lame.",
  "id" : 908461887,
  "created_at" : "2008-09-03 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitterrific.com\" rel=\"nofollow\">Twitterrific</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "907665756",
  "text" : "8:36pm Watching analysis of the Republican National Convention. Fred Thompson wins. http://tinyurl.com/6jy4xw",
  "id" : 907665756,
  "created_at" : "2008-09-03 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katie P",
      "screen_name" : "capitol_trouble",
      "indices" : [ 0, 16 ],
      "id_str" : "16063333",
      "id" : 16063333
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "906336590",
  "geo" : { },
  "id_str" : "906344313",
  "in_reply_to_user_id" : 16063333,
  "text" : "@capitol_trouble We miss you already! Come back. Real world schmreal world.",
  "id" : 906344313,
  "in_reply_to_status_id" : 906336590,
  "created_at" : "2008-09-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "capitol_trouble",
  "in_reply_to_user_id_str" : "16063333",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
} ]