Grailbird.data.tweets_2011_02 = 
 [ {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marina Martin",
      "screen_name" : "MarinaMartin",
      "indices" : [ 0, 13 ],
      "id_str" : "60663",
      "id" : 60663
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "42447874642034688",
  "geo" : {
  },
  "id_str" : "42448504144150528",
  "in_reply_to_user_id" : 60663,
  "text" : "@MarinaMartin Please copy!  There are 20+ people doing their own versions of it here and there.",
  "id" : 42448504144150528,
  "in_reply_to_status_id" : 42447874642034688,
  "created_at" : "Tue Mar 01 04:58:06 +0000 2011",
  "in_reply_to_screen_name" : "MarinaMartin",
  "in_reply_to_user_id_str" : "60663",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gwen Bell",
      "screen_name" : "gwenbell",
      "indices" : [ 0, 9 ],
      "id_str" : "1250104952",
      "id" : 1250104952
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "42448315291410432",
  "text" : "@gwenbell Just read Frederick, all about the role of the artist. Very relevant to your recent evolutions...",
  "id" : 42448315291410432,
  "created_at" : "Tue Mar 01 04:57:21 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.604833, -122.322834 ]
  },
  "id_str" : "42447452711829504",
  "text" : "8:36pm Reading bedtime books and sharing stories of the day http://flic.kr/p/9mXXvh",
  "id" : 42447452711829504,
  "created_at" : "Tue Mar 01 04:53:56 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "brynn evans",
      "screen_name" : "brynn",
      "indices" : [ 0, 6 ],
      "id_str" : "8708232",
      "id" : 8708232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "42431691368841217",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6049559875, -122.3225749675 ]
  },
  "id_str" : "42431960924168192",
  "in_reply_to_user_id" : 8708232,
  "text" : "@brynn Okay, thanks! Will let you know when it's safe to try again.",
  "id" : 42431960924168192,
  "in_reply_to_status_id" : 42431691368841217,
  "created_at" : "Tue Mar 01 03:52:22 +0000 2011",
  "in_reply_to_screen_name" : "brynn",
  "in_reply_to_user_id_str" : "8708232",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "brynn evans",
      "screen_name" : "brynn",
      "indices" : [ 0, 6 ],
      "id_str" : "8708232",
      "id" : 8708232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "42422570984816640",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6049203956, -122.3227288122 ]
  },
  "id_str" : "42430440681910273",
  "in_reply_to_user_id" : 8708232,
  "text" : "@brynn Uh oh, what's happening? Which step errors? I'll look into it!",
  "id" : 42430440681910273,
  "in_reply_to_status_id" : 42422570984816640,
  "created_at" : "Tue Mar 01 03:46:20 +0000 2011",
  "in_reply_to_screen_name" : "brynn",
  "in_reply_to_user_id_str" : "8708232",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "D. Keith Robinson",
      "screen_name" : "dkr",
      "indices" : [ 0, 4 ],
      "id_str" : "10877",
      "id" : 10877
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "42417708825980928",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6049203956, -122.3227288122 ]
  },
  "id_str" : "42429875365220352",
  "in_reply_to_user_id" : 10877,
  "text" : "@dkr Just joined your team. What's this all about?",
  "id" : 42429875365220352,
  "in_reply_to_status_id" : 42417708825980928,
  "created_at" : "Tue Mar 01 03:44:05 +0000 2011",
  "in_reply_to_screen_name" : "dkr",
  "in_reply_to_user_id_str" : "10877",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.fitbit.com\" rel=\"nofollow\">Fitbit</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fitstats",
      "indices" : [ 14, 23 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "42359301322457088",
  "text" : "My avg. daily #fitstats for last week: 4,078 steps, 2 miles, 2,544 calories burned via my fitbit http://www.fitbit.com/user/229KX2",
  "id" : 42359301322457088,
  "created_at" : "Mon Feb 28 23:03:39 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ArielMeadowStallings",
      "screen_name" : "OffbeatAriel",
      "indices" : [ 12, 25 ],
      "id_str" : "14095370",
      "id" : 14095370
    }, {
      "name" : "Offbeat Home",
      "screen_name" : "offbeathome",
      "indices" : [ 72, 84 ],
      "id_str" : "246411965",
      "id" : 246411965
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 119 ],
      "url" : "http://t.co/IPQ8FYX",
      "expanded_url" : "http://offbeathome.com/",
      "display_url" : "offbeathome.com"
    } ]
  },
  "geo" : {
  },
  "id_str" : "42297229419085824",
  "text" : "Congrats to @offbeatariel on the launch of her 3rd offbeat empire site, @offbeathome! Check it out! http://t.co/IPQ8FYX",
  "id" : 42297229419085824,
  "created_at" : "Mon Feb 28 18:56:59 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "olga kreimer",
      "screen_name" : "kreimero",
      "indices" : [ 3, 12 ],
      "id_str" : "16346294",
      "id" : 16346294
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "oscars",
      "indices" : [ 88, 95 ]
    }, {
      "text" : "everything",
      "indices" : [ 96, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "42110193785376768",
  "text" : "RT @kreimero: Twitter is the angry CliffsNotes of everything that happens in the world. #oscars #everything",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "oscars",
        "indices" : [ 74, 81 ]
      }, {
        "text" : "everything",
        "indices" : [ 82, 93 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "42095711390674944",
    "text" : "Twitter is the angry CliffsNotes of everything that happens in the world. #oscars #everything",
    "id" : 42095711390674944,
    "created_at" : "Mon Feb 28 05:36:14 +0000 2011",
    "user" : {
      "name" : "olga kreimer",
      "screen_name" : "kreimero",
      "protected" : false,
      "id_str" : "16346294",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1702789320/084.1__2__normal.JPG",
      "id" : 16346294,
      "verified" : false
    }
  },
  "id" : 42110193785376768,
  "created_at" : "Mon Feb 28 06:33:47 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marshall Haas",
      "screen_name" : "MarshallHaas",
      "indices" : [ 0, 13 ],
      "id_str" : "1268491417",
      "id" : 1268491417
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "42083194433961984",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6049362015, -122.3224692062 ]
  },
  "id_str" : "42086355370651648",
  "in_reply_to_user_id" : 19028099,
  "text" : "@marshallhaas Thanks! And thank you for the invite. It's a fun little service.",
  "id" : 42086355370651648,
  "in_reply_to_status_id" : 42083194433961984,
  "created_at" : "Mon Feb 28 04:59:03 +0000 2011",
  "in_reply_to_screen_name" : "marshal",
  "in_reply_to_user_id_str" : "19028099",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christoph Hewett",
      "screen_name" : "ChristophHewett",
      "indices" : [ 0, 16 ],
      "id_str" : "17005510",
      "id" : 17005510
    }, {
      "name" : "Health Month",
      "screen_name" : "healthmonth",
      "indices" : [ 87, 99 ],
      "id_str" : "154236895",
      "id" : 154236895
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "42077582660870146",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6049362015, -122.3224692062 ]
  },
  "id_str" : "42086173325135872",
  "in_reply_to_user_id" : 17005510,
  "text" : "@ChristophHewett Would love to hear more thought on what worked/didn't work for you on @healthmonth. I'm still learning!",
  "id" : 42086173325135872,
  "in_reply_to_status_id" : 42077582660870146,
  "created_at" : "Mon Feb 28 04:58:20 +0000 2011",
  "in_reply_to_screen_name" : "ChristophHewett",
  "in_reply_to_user_id_str" : "17005510",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.605, -122.322667 ]
  },
  "id_str" : "42082109489299456",
  "text" : "8:36pm Working on email from the couch. Way behind but ready to jump back in after this hectic weekend http://flic.kr/p/9mEW9d",
  "id" : 42082109489299456,
  "created_at" : "Mon Feb 28 04:42:11 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thor Muller",
      "screen_name" : "tempo",
      "indices" : [ 38, 44 ],
      "id_str" : "5814",
      "id" : 5814
    }, {
      "name" : "Get Satisfaction",
      "screen_name" : "getsatisfaction",
      "indices" : [ 46, 62 ],
      "id_str" : "622543",
      "id" : 622543
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 123, 142 ],
      "url" : "http://t.co/Dxe63zl",
      "expanded_url" : "http://thormuller.com/2011/02/whos-got-your-back-an-investor-story/",
      "display_url" : "thormuller.com/2011/02/whos-g\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "42010192593952768",
  "text" : "Need more founder posts like -&gt; RT @tempo: @GetSatisfaction's darkest hours & how we were saved by our early investors: http://t.co/Dxe63zl",
  "id" : 42010192593952768,
  "created_at" : "Sun Feb 27 23:56:25 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Few",
      "screen_name" : "jfew",
      "indices" : [ 0, 5 ],
      "id_str" : "2067141",
      "id" : 2067141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "41969907541356544",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6050165256, -122.3225019711 ]
  },
  "id_str" : "41973980856451072",
  "in_reply_to_user_id" : 2067141,
  "text" : "@jfew We made our movers 1+ hours late to their next job... I bet they'll show up soon. Still, sucks. Hope the rest of the move goes well.",
  "id" : 41973980856451072,
  "in_reply_to_status_id" : 41969907541356544,
  "created_at" : "Sun Feb 27 21:32:31 +0000 2011",
  "in_reply_to_screen_name" : "jfew",
  "in_reply_to_user_id_str" : "2067141",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Galen Ward",
      "screen_name" : "galenward",
      "indices" : [ 0, 10 ],
      "id_str" : "2854761",
      "id" : 2854761
    }, {
      "name" : "EightBit",
      "screen_name" : "eightbit",
      "indices" : [ 14, 23 ],
      "id_str" : "200215023",
      "id" : 200215023
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 53 ],
      "url" : "http://t.co/znMCbSY",
      "expanded_url" : "http://eightbit.me",
      "display_url" : "eightbit.me"
    } ]
  },
  "geo" : {
  },
  "id_str" : "41898642637983744",
  "in_reply_to_user_id" : 2854761,
  "text" : "@galenward go @EightBit yourself! http://t.co/znMCbSY",
  "id" : 41898642637983744,
  "created_at" : "Sun Feb 27 16:33:09 +0000 2011",
  "in_reply_to_screen_name" : "galenward",
  "in_reply_to_user_id_str" : "2854761",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.609166, -122.299167 ]
  },
  "id_str" : "41719918063927296",
  "text" : "8:36pm Done moving, now warming the house of Tyler and Loren aka the cutest house ever http://flic.kr/p/9mm5Cy",
  "id" : 41719918063927296,
  "created_at" : "Sun Feb 27 04:42:58 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jill Corral",
      "screen_name" : "jillcorral",
      "indices" : [ 0, 11 ],
      "id_str" : "64623504",
      "id" : 64623504
    }, {
      "name" : "Jill S.",
      "screen_name" : "outseide",
      "indices" : [ 12, 21 ],
      "id_str" : "143694663",
      "id" : 143694663
    }, {
      "name" : "Jane McGonigal",
      "screen_name" : "avantgame",
      "indices" : [ 29, 39 ],
      "id_str" : "681813",
      "id" : 681813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "41652182851911681",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6049972592, -122.3223513131 ]
  },
  "id_str" : "41658648576925696",
  "in_reply_to_user_id" : 64623504,
  "text" : "@jillcorral @outseide I LOVE @avantgame's new book, and try to put some of the ideas to use on healthmonth.com. Let me know what you think!",
  "id" : 41658648576925696,
  "in_reply_to_status_id" : 41652182851911681,
  "created_at" : "Sun Feb 27 00:39:30 +0000 2011",
  "in_reply_to_screen_name" : "jillcorral",
  "in_reply_to_user_id_str" : "64623504",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BJ Fogg",
      "screen_name" : "bjfogg",
      "indices" : [ 0, 7 ],
      "id_str" : "1118691",
      "id" : 1118691
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "41633604245274624",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6050087125, -122.3225046413 ]
  },
  "id_str" : "41649938463072256",
  "in_reply_to_user_id" : 1118691,
  "text" : "@bjfogg Worked great on my end. Slides, audio, and video all came through no problem. Enjoyed the discussion too. Video Q&A with group chat!",
  "id" : 41649938463072256,
  "in_reply_to_status_id" : 41633604245274624,
  "created_at" : "Sun Feb 27 00:04:53 +0000 2011",
  "in_reply_to_screen_name" : "bjfogg",
  "in_reply_to_user_id_str" : "1118691",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6125, -122.3475 ]
  },
  "id_str" : "41561049153015808",
  "text" : "Leave the campsite in the same or better condition that when you arrived http://flic.kr/p/9majCD",
  "id" : 41561049153015808,
  "created_at" : "Sat Feb 26 18:11:40 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirk Longhofer",
      "screen_name" : "kirklonghofer",
      "indices" : [ 0, 14 ],
      "id_str" : "15651426",
      "id" : 15651426
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "41547213108805632",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6140362089, -122.3453393389 ]
  },
  "id_str" : "41550005479149568",
  "in_reply_to_user_id" : 15651426,
  "text" : "@kirklonghofer You can email me at buster@750words.com or here on Twitter. What's up?",
  "id" : 41550005479149568,
  "in_reply_to_status_id" : 41547213108805632,
  "created_at" : "Sat Feb 26 17:27:47 +0000 2011",
  "in_reply_to_screen_name" : "kirklonghofer",
  "in_reply_to_user_id_str" : "15651426",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rodney Mitchell",
      "screen_name" : "rodmitch",
      "indices" : [ 0, 9 ],
      "id_str" : "2082491",
      "id" : 2082491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "41350908851785728",
  "geo" : {
  },
  "id_str" : "41383772725325824",
  "in_reply_to_user_id" : 2082491,
  "text" : "@rodmitch You're welcome. Let me know if there's anything more I can do!",
  "id" : 41383772725325824,
  "in_reply_to_status_id" : 41350908851785728,
  "created_at" : "Sat Feb 26 06:27:14 +0000 2011",
  "in_reply_to_screen_name" : "rodmitch",
  "in_reply_to_user_id_str" : "2082491",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daryn Nakhuda",
      "screen_name" : "daryn",
      "indices" : [ 0, 6 ],
      "id_str" : "804808",
      "id" : 804808
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "41359070891868160",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6070524723, -122.32033409 ]
  },
  "id_str" : "41383646661181440",
  "in_reply_to_user_id" : 804808,
  "text" : "@daryn Terry and Jefferson! Near Harborview. Where are you?",
  "id" : 41383646661181440,
  "in_reply_to_status_id" : 41359070891868160,
  "created_at" : "Sat Feb 26 06:26:44 +0000 2011",
  "in_reply_to_screen_name" : "daryn",
  "in_reply_to_user_id_str" : "804808",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.612666, -122.347667 ]
  },
  "id_str" : "41359403785535488",
  "text" : "8:36pm Done for today. More tomorrow! http://flic.kr/p/9m6sS9",
  "id" : 41359403785535488,
  "created_at" : "Sat Feb 26 04:50:24 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.605, -122.322667 ]
  },
  "id_str" : "41294386033737728",
  "text" : "I know you're all in suspence about this... but the table fit through the door! http://flic.kr/p/9m4hZ3",
  "id" : 41294386033737728,
  "created_at" : "Sat Feb 26 00:32:03 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Galen Ward",
      "screen_name" : "galenward",
      "indices" : [ 0, 10 ],
      "id_str" : "2854761",
      "id" : 2854761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "41281909988401153",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.61220711, -122.3173908933 ]
  },
  "id_str" : "41283350002020352",
  "in_reply_to_user_id" : 2854761,
  "text" : "@galenward Having trouble with doing it from my phone. Will try again once I've got Internet set up at the new place!",
  "id" : 41283350002020352,
  "in_reply_to_status_id" : 41281909988401153,
  "created_at" : "Fri Feb 25 23:48:12 +0000 2011",
  "in_reply_to_screen_name" : "galenward",
  "in_reply_to_user_id_str" : "2854761",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Galen Ward",
      "screen_name" : "galenward",
      "indices" : [ 0, 10 ],
      "id_str" : "2854761",
      "id" : 2854761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "41275430489178112",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.61207717, -122.31682562 ]
  },
  "id_str" : "41281765700145152",
  "in_reply_to_user_id" : 2854761,
  "text" : "@galenward eightbit.me -- want an invite?",
  "id" : 41281765700145152,
  "in_reply_to_status_id" : 41275430489178112,
  "created_at" : "Fri Feb 25 23:41:54 +0000 2011",
  "in_reply_to_screen_name" : "galenward",
  "in_reply_to_user_id_str" : "2854761",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "41271774104649729",
  "text" : "Note to self: on moving day don't wait til 3pm for first real meal. (@ Cafe Presse) http://4sq.com/eLbAFt",
  "id" : 41271774104649729,
  "created_at" : "Fri Feb 25 23:02:12 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.605166, -122.3225 ]
  },
  "id_str" : "41246407226703872",
  "text" : "Moment of truth. Will this table fit into our new apartment? http://flic.kr/p/9kYnik",
  "id" : 41246407226703872,
  "created_at" : "Fri Feb 25 21:21:24 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arielis Talavera",
      "screen_name" : "ArielisT",
      "indices" : [ 0, 9 ],
      "id_str" : "1163522401",
      "id" : 1163522401
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6060675989, -122.3372133294 ]
  },
  "id_str" : "41225734437474304",
  "text" : "@arielist Tonight! Or tomorrow morningish? We are now much more flexible, yay!",
  "id" : 41225734437474304,
  "created_at" : "Fri Feb 25 19:59:15 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "fran melmed",
      "screen_name" : "femelmed",
      "indices" : [ 0, 9 ],
      "id_str" : "15149425",
      "id" : 15149425
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "41206360079216641",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6060675989, -122.3372133294 ]
  },
  "id_str" : "41225530267148288",
  "in_reply_to_user_id" : 15149425,
  "text" : "@femelmed Sounds great! My panel is at 2pm on cooperative games. When/what is yours?",
  "id" : 41225530267148288,
  "in_reply_to_status_id" : 41206360079216641,
  "created_at" : "Fri Feb 25 19:58:27 +0000 2011",
  "in_reply_to_screen_name" : "femelmed",
  "in_reply_to_user_id_str" : "15149425",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.604666, -122.322834 ]
  },
  "id_str" : "41223766109458432",
  "text" : "Riding in style in the back of our movers' truck http://flic.kr/p/9kXkKV",
  "id" : 41223766109458432,
  "created_at" : "Fri Feb 25 19:51:26 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Manoogian III",
      "screen_name" : "jm3",
      "indices" : [ 0, 4 ],
      "id_str" : "59593",
      "id" : 59593
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "41181945576689664",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6123753473, -122.3475672718 ]
  },
  "id_str" : "41182481809940480",
  "in_reply_to_user_id" : 59593,
  "text" : "@jm3 Yes, you're not entirely off base. Who knows where we'll be in a year. :)",
  "id" : 41182481809940480,
  "in_reply_to_status_id" : 41181945576689664,
  "created_at" : "Fri Feb 25 17:07:23 +0000 2011",
  "in_reply_to_screen_name" : "jm3",
  "in_reply_to_user_id_str" : "59593",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Manoogian III",
      "screen_name" : "jm3",
      "indices" : [ 0, 4 ],
      "id_str" : "59593",
      "id" : 59593
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "41180819871498240",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6125430036, -122.3475768418 ]
  },
  "id_str" : "41181158804963328",
  "in_reply_to_user_id" : 59593,
  "text" : "@jm3 No just a couple miles away so we can sell my condo. Need to be flexible!",
  "id" : 41181158804963328,
  "in_reply_to_status_id" : 41180819871498240,
  "created_at" : "Fri Feb 25 17:02:08 +0000 2011",
  "in_reply_to_screen_name" : "jm3",
  "in_reply_to_user_id_str" : "59593",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://eightbit.me\" rel=\"nofollow\">EightBit</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "EightBit",
      "screen_name" : "eightbit",
      "indices" : [ 13, 22 ],
      "id_str" : "200215023",
      "id" : 200215023
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "41057609209348096",
  "text" : "Just made an @EightBit character. Check out my profile http://eightbit.me/busterbenson",
  "id" : 41057609209348096,
  "created_at" : "Fri Feb 25 08:51:11 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6125262133, -122.3476552567 ]
  },
  "id_str" : "41030753978425344",
  "text" : "Nirvana genius playlist, incense burning, no baby, everything's in boxes = serious college flashback! Where's the Mt Dew??",
  "id" : 41030753978425344,
  "created_at" : "Fri Feb 25 07:04:28 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.614, -122.334167 ]
  },
  "id_str" : "41007949535129600",
  "text" : "8:36pm Dropping Niko off at our doula for moving day http://flic.kr/p/9kPXxe",
  "id" : 41007949535129600,
  "created_at" : "Fri Feb 25 05:33:51 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.612333, -122.347667 ]
  },
  "id_str" : "40988896200372224",
  "text" : "Niko's last moment at the loft. Started as a bachelor pad with no furniture. Now this guy is king of the hill. http://flic.kr/p/9kSpaA",
  "id" : 40988896200372224,
  "created_at" : "Fri Feb 25 04:18:09 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marshall Haas",
      "screen_name" : "MarshallHaas",
      "indices" : [ 0, 13 ],
      "id_str" : "1268491417",
      "id" : 1268491417
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "40969996091785216",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6124945833, -122.3475731044 ]
  },
  "id_str" : "40972569842679810",
  "in_reply_to_user_id" : 19028099,
  "text" : "@MarshallHaas Me me me! :)",
  "id" : 40972569842679810,
  "in_reply_to_status_id" : 40969996091785216,
  "created_at" : "Fri Feb 25 03:13:16 +0000 2011",
  "in_reply_to_screen_name" : "marshal",
  "in_reply_to_user_id_str" : "19028099",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Forslund",
      "screen_name" : "adamforslund",
      "indices" : [ 0, 13 ],
      "id_str" : "17352252",
      "id" : 17352252
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "40968081840934912",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6124252675, -122.3473776542 ]
  },
  "id_str" : "40968242759606272",
  "in_reply_to_user_id" : 17352252,
  "text" : "@adamforslund Okay you first.",
  "id" : 40968242759606272,
  "in_reply_to_status_id" : 40968081840934912,
  "created_at" : "Fri Feb 25 02:56:04 +0000 2011",
  "in_reply_to_screen_name" : "adamforslund",
  "in_reply_to_user_id_str" : "17352252",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Forslund",
      "screen_name" : "adamforslund",
      "indices" : [ 0, 13 ],
      "id_str" : "17352252",
      "id" : 17352252
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "40962208586407936",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.61440377, -122.3464573486 ]
  },
  "id_str" : "40962582739156992",
  "in_reply_to_user_id" : 17352252,
  "text" : "@adamforslund Really? Wow. But can men lactate without being sent to the circus?",
  "id" : 40962582739156992,
  "in_reply_to_status_id" : 40962208586407936,
  "created_at" : "Fri Feb 25 02:33:35 +0000 2011",
  "in_reply_to_screen_name" : "adamforslund",
  "in_reply_to_user_id_str" : "17352252",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Offbeat Mama",
      "screen_name" : "OffbeatMama",
      "indices" : [ 50, 62 ],
      "id_str" : "1093560211",
      "id" : 1093560211
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "40961872240979968",
  "text" : "If only dads could do this too! Is that weird? RT @offbeatmama: How two lesbian mamas share breastfeeding duties http://bit.ly/eEImWv",
  "id" : 40961872240979968,
  "created_at" : "Fri Feb 25 02:30:46 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jean",
      "screen_name" : "PolarBear60",
      "indices" : [ 0, 12 ],
      "id_str" : "16573363",
      "id" : 16573363
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "40955962055606272",
  "geo" : {
  },
  "id_str" : "40956188703195136",
  "in_reply_to_user_id" : 16573363,
  "text" : "@PolarBear60 Interesting idea. Will definitely play with the pricing, once I want to really start growing. :)",
  "id" : 40956188703195136,
  "in_reply_to_status_id" : 40955962055606272,
  "created_at" : "Fri Feb 25 02:08:10 +0000 2011",
  "in_reply_to_screen_name" : "PolarBear60",
  "in_reply_to_user_id_str" : "16573363",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jean",
      "screen_name" : "PolarBear60",
      "indices" : [ 0, 12 ],
      "id_str" : "16573363",
      "id" : 16573363
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "40954954587832320",
  "geo" : {
  },
  "id_str" : "40955482638266369",
  "in_reply_to_user_id" : 16573363,
  "text" : "@PolarBear60 I haven't really checked very thoroughly, but % of players who pay does go up every month is seems.",
  "id" : 40955482638266369,
  "in_reply_to_status_id" : 40954954587832320,
  "created_at" : "Fri Feb 25 02:05:22 +0000 2011",
  "in_reply_to_screen_name" : "PolarBear60",
  "in_reply_to_user_id_str" : "16573363",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "40952149085143040",
  "text" : "I wish I could forecast via spreadsheet more kinds of future beyond new user growth and revenue. Those even those are quite fun.",
  "id" : 40952149085143040,
  "created_at" : "Fri Feb 25 01:52:07 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 99 ],
      "url" : "http://t.co/h0jgCSB",
      "expanded_url" : "http://arstechnica.com/tech-policy/news/2011/02/anonymous-speaks-the-inside-story-of-the-hbgary-hack.ars",
      "display_url" : "arstechnica.com/tech-policy/ne\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "40937659404783616",
  "text" : "Fascinating story with specific details about how Anonymous hacked into HBGary. http://t.co/h0jgCSB",
  "id" : 40937659404783616,
  "created_at" : "Fri Feb 25 00:54:33 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Roberts",
      "screen_name" : "timroberts",
      "indices" : [ 0, 11 ],
      "id_str" : "23",
      "id" : 23
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "40919503894220800",
  "geo" : {
  },
  "id_str" : "40919778893758464",
  "in_reply_to_user_id" : 23,
  "text" : "@timroberts I definitely will! Also, I am launching first Fitbit integration with a new rule in March. I'll email you info.",
  "id" : 40919778893758464,
  "in_reply_to_status_id" : 40919503894220800,
  "created_at" : "Thu Feb 24 23:43:30 +0000 2011",
  "in_reply_to_screen_name" : "timroberts",
  "in_reply_to_user_id_str" : "23",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Roberts",
      "screen_name" : "timroberts",
      "indices" : [ 0, 11 ],
      "id_str" : "23",
      "id" : 23
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "40275548395671552",
  "geo" : {
  },
  "id_str" : "40919334264111104",
  "in_reply_to_user_id" : 23,
  "text" : "@timroberts I was just there for 12 hours. I definitely want to come down and visit the Fitbit offices soon though. Maybe next Tues?",
  "id" : 40919334264111104,
  "in_reply_to_status_id" : 40275548395671552,
  "created_at" : "Thu Feb 24 23:41:44 +0000 2011",
  "in_reply_to_screen_name" : "timroberts",
  "in_reply_to_user_id_str" : "23",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Health Month",
      "screen_name" : "healthmonth",
      "indices" : [ 56, 68 ],
      "id_str" : "154236895",
      "id" : 154236895
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "4hb",
      "indices" : [ 9, 13 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 109 ],
      "url" : "http://t.co/gJMDU0c",
      "expanded_url" : "http://healthmonth.tumblr.com/post/3490405739/woah-11-new-rules",
      "display_url" : "healthmonth.tumblr.com/post/349040573\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "40906563501690881",
  "text" : "Now more #4hb and \"No S Diet\" compliant... check it: RT @healthmonth: Woah! 11 new rules! http://t.co/gJMDU0c",
  "id" : 40906563501690881,
  "created_at" : "Thu Feb 24 22:50:59 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Health Month",
      "screen_name" : "healthmonth",
      "indices" : [ 3, 15 ],
      "id_str" : "154236895",
      "id" : 154236895
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "healthmonth",
      "indices" : [ 44, 56 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "40875275977760768",
  "text" : "RT @healthmonth: I'm gonna add a couple new #healthmonth rules for March. Send me your suggestions!",
  "retweeted_status" : {
    "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "healthmonth",
        "indices" : [ 27, 39 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "40875232369573888",
    "text" : "I'm gonna add a couple new #healthmonth rules for March. Send me your suggestions!",
    "id" : 40875232369573888,
    "created_at" : "Thu Feb 24 20:46:29 +0000 2011",
    "user" : {
      "name" : "Health Month",
      "screen_name" : "healthmonth",
      "protected" : false,
      "id_str" : "154236895",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1136999397/track_meals.400_normal.png",
      "id" : 154236895,
      "verified" : false
    }
  },
  "id" : 40875275977760768,
  "created_at" : "Thu Feb 24 20:46:39 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chrissie Brodigan",
      "screen_name" : "tenaciouscb",
      "indices" : [ 0, 12 ],
      "id_str" : "56831057",
      "id" : 56831057
    }, {
      "name" : "greengoose",
      "screen_name" : "greengoose",
      "indices" : [ 101, 112 ],
      "id_str" : "16862175",
      "id" : 16862175
    }, {
      "name" : "brynn evans",
      "screen_name" : "brynn",
      "indices" : [ 113, 119 ],
      "id_str" : "8708232",
      "id" : 8708232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "40820837946753024",
  "geo" : {
  },
  "id_str" : "40828206437236736",
  "in_reply_to_user_id" : 56831057,
  "text" : "@tenaciouscb Yes, Brian's work is awesome! We've met and have big plans for working together! :) /cc @greengoose @brynn",
  "id" : 40828206437236736,
  "in_reply_to_status_id" : 40820837946753024,
  "created_at" : "Thu Feb 24 17:39:37 +0000 2011",
  "in_reply_to_screen_name" : "tenaciouscb",
  "in_reply_to_user_id_str" : "56831057",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.612666, -122.347834 ]
  },
  "id_str" : "40632929373786112",
  "text" : "8:36pm Baby bathtime preview http://flic.kr/p/9kD675",
  "id" : 40632929373786112,
  "created_at" : "Thu Feb 24 04:43:39 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Martell",
      "screen_name" : "danmartell",
      "indices" : [ 0, 11 ],
      "id_str" : "10638782",
      "id" : 10638782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "40595090044878848",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6134655392, -122.3461627958 ]
  },
  "id_str" : "40615447267119105",
  "in_reply_to_user_id" : 10638782,
  "text" : "@danmartell Love that article! Well done and thanks for sharing.",
  "id" : 40615447267119105,
  "in_reply_to_status_id" : 40595090044878848,
  "created_at" : "Thu Feb 24 03:34:11 +0000 2011",
  "in_reply_to_screen_name" : "danmartell",
  "in_reply_to_user_id_str" : "10638782",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ReadWrite",
      "screen_name" : "RWW",
      "indices" : [ 57, 61 ],
      "id_str" : "4641021",
      "id" : 4641021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6134661763, -122.3457985825 ]
  },
  "id_str" : "40614608020439041",
  "text" : "Super excited to see this get such a great reception. RT @RWW: Green Goose Wows the Crowd & Raises $100K At Launch Conf http://rww.to/eW4wNl",
  "id" : 40614608020439041,
  "created_at" : "Thu Feb 24 03:30:51 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Franklin",
      "screen_name" : "AaronSeattle",
      "indices" : [ 0, 13 ],
      "id_str" : "15358390",
      "id" : 15358390
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "40582778978308096",
  "geo" : {
  },
  "id_str" : "40584603311931392",
  "in_reply_to_user_id" : 15358390,
  "text" : "@AaronSeattle Cool. Can't wait!",
  "id" : 40584603311931392,
  "in_reply_to_status_id" : 40582778978308096,
  "created_at" : "Thu Feb 24 01:31:38 +0000 2011",
  "in_reply_to_screen_name" : "AaronSeattle",
  "in_reply_to_user_id_str" : "15358390",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Giant Thinkwell",
      "screen_name" : "giantthinkwell",
      "indices" : [ 109, 124 ],
      "id_str" : "76997445",
      "id" : 76997445
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 94 ],
      "url" : "http://t.co/KiDuKEd",
      "expanded_url" : "http://www.seattlemet.com/arts-and-entertainment/articles/techstars-seattle-giant-thinkwell-raising-uncle-jesse-0311/1/",
      "display_url" : "seattlemet.com/arts-and-enter\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "40580392754872320",
  "text" : "A virtual pet game with baby celebrities instead of pets? Awesome & crazy. http://t.co/KiDuKEd Nice profile, @giantthinkwell!",
  "id" : 40580392754872320,
  "created_at" : "Thu Feb 24 01:14:54 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LazyMeter",
      "screen_name" : "LazyMeter",
      "indices" : [ 0, 10 ],
      "id_str" : "106868038",
      "id" : 106868038
    }, {
      "name" : "Aaron Franklin",
      "screen_name" : "AaronSeattle",
      "indices" : [ 78, 91 ],
      "id_str" : "15358390",
      "id" : 15358390
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "40570258301390848",
  "geo" : {
  },
  "id_str" : "40570621205155841",
  "in_reply_to_user_id" : 15358390,
  "text" : "@LazyMeter How do I get to be one of these illustrious \"beta testers\"? :) /cc @AaronSeattle",
  "id" : 40570621205155841,
  "in_reply_to_status_id" : 40570258301390848,
  "created_at" : "Thu Feb 24 00:36:04 +0000 2011",
  "in_reply_to_screen_name" : "AaronSeattle",
  "in_reply_to_user_id_str" : "15358390",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "40536160207896576",
  "text" : "Checking out BJ Fogg's Zipcast: 'Top 10 mistakes in behavior change' at http://www.slideshare.net/bjfogg/meeting. Pretty neat!",
  "id" : 40536160207896576,
  "created_at" : "Wed Feb 23 22:19:08 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "josh",
      "screen_name" : "joshc",
      "indices" : [ 0, 6 ],
      "id_str" : "2015",
      "id" : 2015
    }, {
      "name" : "ingopixel",
      "screen_name" : "ingopixel",
      "indices" : [ 7, 17 ],
      "id_str" : "7943892",
      "id" : 7943892
    }, {
      "name" : "Carinna Tarvin",
      "screen_name" : "carinnatarvin",
      "indices" : [ 18, 32 ],
      "id_str" : "20833838",
      "id" : 20833838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "40310704795942913",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.5605012589, -122.2930156023 ]
  },
  "id_str" : "40311091774885888",
  "in_reply_to_user_id" : 2015,
  "text" : "@joshc @ingopixel @carinnatarvin In general, I agree. But not for friends we have convinced to watch the show on high recommendation.",
  "id" : 40311091774885888,
  "in_reply_to_status_id" : 40310704795942913,
  "created_at" : "Wed Feb 23 07:24:47 +0000 2011",
  "in_reply_to_screen_name" : "joshc",
  "in_reply_to_user_id_str" : "2015",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ingopixel",
      "screen_name" : "ingopixel",
      "indices" : [ 0, 10 ],
      "id_str" : "7943892",
      "id" : 7943892
    }, {
      "name" : "Carinna Tarvin",
      "screen_name" : "carinnatarvin",
      "indices" : [ 25, 39 ],
      "id_str" : "20833838",
      "id" : 20833838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "40309153968820224",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.527608935, -122.27963448 ]
  },
  "id_str" : "40309525160398848",
  "in_reply_to_user_id" : 7943892,
  "text" : "@ingopixel Shush it! /cc @carinnatarvin",
  "id" : 40309525160398848,
  "in_reply_to_status_id" : 40309153968820224,
  "created_at" : "Wed Feb 23 07:18:34 +0000 2011",
  "in_reply_to_screen_name" : "ingopixel",
  "in_reply_to_user_id_str" : "7943892",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.613666, -122.394167 ]
  },
  "id_str" : "40270160011067392",
  "text" : "8:36pm Boarding the party plane, sitting in the fancy seats because I made a mistake when booking. Ce la vie! http://flic.kr/p/9km2Wr",
  "id" : 40270160011067392,
  "created_at" : "Wed Feb 23 04:42:08 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 3, 13 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "40086474267295744",
  "text" : "RT @kellianne: Cuddly morning baby does his newest trick. http://flic.kr/p/9kfwoG",
  "retweeted_status" : {
    "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "40085445291425792",
    "text" : "Cuddly morning baby does his newest trick. http://flic.kr/p/9kfwoG",
    "id" : 40085445291425792,
    "created_at" : "Tue Feb 22 16:28:09 +0000 2011",
    "user" : {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "protected" : false,
      "id_str" : "7362142",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3058433557/056b99ecb9df9b6b9b382b2470b6ee82_normal.jpeg",
      "id" : 7362142,
      "verified" : false
    }
  },
  "id" : 40086474267295744,
  "created_at" : "Tue Feb 22 16:32:14 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/#!/download/ipad\" rel=\"nofollow\">Twitter for iPad</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TripIt",
      "screen_name" : "TripIt",
      "indices" : [ 20, 27 ],
      "id_str" : "10751252",
      "id" : 10751252
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "40074169601236992",
  "text" : "It would be cool if @TripIt told me when my friends were going to be on my flight. SEA-&gt;SFO almost always has someone I know. 2 today!",
  "id" : 40074169601236992,
  "created_at" : "Tue Feb 22 15:43:21 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/#!/download/ipad\" rel=\"nofollow\">Twitter for iPad</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cameron Walters",
      "screen_name" : "ceedub",
      "indices" : [ 0, 7 ],
      "id_str" : "3922",
      "id" : 3922
    }, {
      "name" : "Ali Berman",
      "screen_name" : "spangley",
      "indices" : [ 8, 17 ],
      "id_str" : "776429",
      "id" : 776429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "40068178025529344",
  "geo" : {
  },
  "id_str" : "40069667892494336",
  "in_reply_to_user_id" : 3922,
  "text" : "@ceedub @spangley I would love to! This is just a 12hr visit full of meetings but let's make sure to hang out next time. I visit often now.",
  "id" : 40069667892494336,
  "in_reply_to_status_id" : 40068178025529344,
  "created_at" : "Tue Feb 22 15:25:27 +0000 2011",
  "in_reply_to_screen_name" : "ceedub",
  "in_reply_to_user_id_str" : "3922",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/#!/download/ipad\" rel=\"nofollow\">Twitter for iPad</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Rainert",
      "screen_name" : "arainert",
      "indices" : [ 0, 9 ],
      "id_str" : "7482",
      "id" : 7482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "40035113832030208",
  "geo" : {
  },
  "id_str" : "40041739704082432",
  "in_reply_to_user_id" : 7482,
  "text" : "@arainert Nothing too surprising: Evernote, Google Docs, Keynote. Trying to find a good drawing app: sorta like Adobe Ideas. You?",
  "id" : 40041739704082432,
  "in_reply_to_status_id" : 40035113832030208,
  "created_at" : "Tue Feb 22 13:34:29 +0000 2011",
  "in_reply_to_screen_name" : "arainert",
  "in_reply_to_user_id_str" : "7482",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "newhobo",
      "indices" : [ 79, 87 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.4439149, -122.3020195 ]
  },
  "id_str" : "40033267201605632",
  "text" : "Traveling with no luggage or computer except an iPad is sorta fun! SEA-&gt;SFO #newhobo http://4sq.com/egVAba",
  "id" : 40033267201605632,
  "created_at" : "Tue Feb 22 13:00:49 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fitbit",
      "screen_name" : "fitbit",
      "indices" : [ 33, 40 ],
      "id_str" : "17424053",
      "id" : 17424053
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "39891723253587968",
  "geo" : {
  },
  "id_str" : "39891987024842752",
  "in_reply_to_user_id" : 1475531,
  "text" : "@mprev Get one! Be my east coast @fitbit pal. Plus, integrating the API into healthmonth.com soon.",
  "id" : 39891987024842752,
  "in_reply_to_status_id" : 39891723253587968,
  "created_at" : "Tue Feb 22 03:39:25 +0000 2011",
  "in_reply_to_screen_name" : "mikeprevette",
  "in_reply_to_user_id_str" : "1475531",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Natalya",
      "screen_name" : "talof2cities",
      "indices" : [ 0, 13 ],
      "id_str" : "62600226",
      "id" : 62600226
    }, {
      "name" : "Fitbit",
      "screen_name" : "fitbit",
      "indices" : [ 69, 76 ],
      "id_str" : "17424053",
      "id" : 17424053
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "healthmonth",
      "indices" : [ 39, 51 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "39852416962662400",
  "geo" : {
  },
  "id_str" : "39858528797732865",
  "in_reply_to_user_id" : 62600226,
  "text" : "@talof2cities I love it! There will be #healthmonth integration with @fitbit soon too. Get one and be a beta tester! :)",
  "id" : 39858528797732865,
  "in_reply_to_status_id" : 39852416962662400,
  "created_at" : "Tue Feb 22 01:26:28 +0000 2011",
  "in_reply_to_screen_name" : "talof2cities",
  "in_reply_to_user_id_str" : "62600226",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "39829803209207808",
  "text" : "\"Hate me or like me, just don't misunderstand me.\" - Joaquin Phoenix",
  "id" : 39829803209207808,
  "created_at" : "Mon Feb 21 23:32:19 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Susan McCabe",
      "screen_name" : "susanlindsey",
      "indices" : [ 0, 13 ],
      "id_str" : "24047916",
      "id" : 24047916
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "39822493522857984",
  "geo" : {
  },
  "id_str" : "39822848893779968",
  "in_reply_to_user_id" : 24047916,
  "text" : "@susanlindsey It's a tricky question, for sure. :)",
  "id" : 39822848893779968,
  "in_reply_to_status_id" : 39822493522857984,
  "created_at" : "Mon Feb 21 23:04:41 +0000 2011",
  "in_reply_to_screen_name" : "susanlindsey",
  "in_reply_to_user_id_str" : "24047916",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.fitbit.com\" rel=\"nofollow\">Fitbit</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fitstats",
      "indices" : [ 14, 23 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "39822532391477248",
  "text" : "My avg. daily #fitstats for last week: 7,081 steps, 3.4 miles, 2,528 calories burned via my fitbit http://www.fitbit.com/user/229KX2",
  "id" : 39822532391477248,
  "created_at" : "Mon Feb 21 23:03:26 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6134222529, -122.3457525386 ]
  },
  "id_str" : "39817851753873408",
  "text" : "Is there an easy way to find the number of people that follow the people that follow someone?",
  "id" : 39817851753873408,
  "created_at" : "Mon Feb 21 22:44:50 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tanner C",
      "screen_name" : "tannerc",
      "indices" : [ 0, 8 ],
      "id_str" : "9161482",
      "id" : 9161482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "39808489182330880",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6136192643, -122.3462521579 ]
  },
  "id_str" : "39809382640402432",
  "in_reply_to_user_id" : 9161482,
  "text" : "@tannerc Yes, full time deal. No lines between work, family, and play.",
  "id" : 39809382640402432,
  "in_reply_to_status_id" : 39808489182330880,
  "created_at" : "Mon Feb 21 22:11:11 +0000 2011",
  "in_reply_to_screen_name" : "tannerc",
  "in_reply_to_user_id_str" : "9161482",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tanner C",
      "screen_name" : "tannerc",
      "indices" : [ 0, 8 ],
      "id_str" : "9161482",
      "id" : 9161482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "39807265816969216",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6137124067, -122.3462740522 ]
  },
  "id_str" : "39808144997752833",
  "in_reply_to_user_id" : 9161482,
  "text" : "@tannerc A social life provides rejuvenation! Without that, doubt I'd be able to be as productive. Add a baby for extra perspective pts! :)",
  "id" : 39808144997752833,
  "in_reply_to_status_id" : 39807265816969216,
  "created_at" : "Mon Feb 21 22:06:16 +0000 2011",
  "in_reply_to_screen_name" : "tannerc",
  "in_reply_to_user_id_str" : "9161482",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Bonner",
      "screen_name" : "seanbonner",
      "indices" : [ 0, 11 ],
      "id_str" : "765",
      "id" : 765
    }, {
      "name" : "IFTTT",
      "screen_name" : "IFTTT",
      "indices" : [ 99, 105 ],
      "id_str" : "75079616",
      "id" : 75079616
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "39781670123094016",
  "geo" : {
  },
  "id_str" : "39782188845240320",
  "in_reply_to_user_id" : 765,
  "text" : "@seanbonner Looking at it again now, just setting up all my channels is pretty fun in itself!  /cc @ifttt",
  "id" : 39782188845240320,
  "in_reply_to_status_id" : 39781670123094016,
  "created_at" : "Mon Feb 21 20:23:07 +0000 2011",
  "in_reply_to_screen_name" : "seanbonner",
  "in_reply_to_user_id_str" : "765",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Bonner",
      "screen_name" : "seanbonner",
      "indices" : [ 0, 11 ],
      "id_str" : "765",
      "id" : 765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "39780324485365760",
  "geo" : {
  },
  "id_str" : "39780675624116224",
  "in_reply_to_user_id" : 765,
  "text" : "@seanbonner What are you using it for?",
  "id" : 39780675624116224,
  "in_reply_to_status_id" : 39780324485365760,
  "created_at" : "Mon Feb 21 20:17:06 +0000 2011",
  "in_reply_to_screen_name" : "seanbonner",
  "in_reply_to_user_id_str" : "765",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Foursquare",
      "screen_name" : "foursquare",
      "indices" : [ 75, 86 ],
      "id_str" : "14120151",
      "id" : 14120151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 68 ],
      "url" : "http://t.co/jJ1MC4l",
      "expanded_url" : "http://www.stormpixel.com/infographr/infographr.php?code=FL4ZGFCOPHVKAH1XLA2NGIBJM3SR3W1TOQNRUSOWFXIZQCWC",
      "display_url" : "stormpixel.com/infographr/inf\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "39741584669028353",
  "text" : "Yup, I drink a lot of coffee and check-in a lot. http://t.co/jJ1MC4l (cool @foursquare Hack Day toy)",
  "id" : 39741584669028353,
  "created_at" : "Mon Feb 21 17:41:46 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Behance's 99U",
      "screen_name" : "the99percent",
      "indices" : [ 3, 16 ],
      "id_str" : "716292679",
      "id" : 716292679
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "39733039009509376",
  "text" : "RT @the99percent: Imagining a World of Total Connectedness, and Its Consequences: http://cot.ag/e1Gi4S",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.exacttarget.com/social\" rel=\"nofollow\">SocialEngage</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "39687284810985472",
    "text" : "Imagining a World of Total Connectedness, and Its Consequences: http://cot.ag/e1Gi4S",
    "id" : 39687284810985472,
    "created_at" : "Mon Feb 21 14:06:00 +0000 2011",
    "user" : {
      "name" : "99U",
      "screen_name" : "99u",
      "protected" : false,
      "id_str" : "17636894",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2995676123/fa7645dcc7f6d69b442bbcbd0950a0ef_normal.png",
      "id" : 17636894,
      "verified" : true
    }
  },
  "id" : 39733039009509376,
  "created_at" : "Mon Feb 21 17:07:49 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ron Diver",
      "screen_name" : "rondiver",
      "indices" : [ 3, 12 ],
      "id_str" : "12661782",
      "id" : 12661782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "39726730167975936",
  "text" : "RT @rondiver: It's not a bubble, \"the fundamental reality is that there is a massive shortage of web software in the world.\" http://bit. ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "39726086598307840",
    "text" : "It's not a bubble, \"the fundamental reality is that there is a massive shortage of web software in the world.\" http://bit.ly/gVDX7v",
    "id" : 39726086598307840,
    "created_at" : "Mon Feb 21 16:40:11 +0000 2011",
    "user" : {
      "name" : "Ron Diver",
      "screen_name" : "rondiver",
      "protected" : false,
      "id_str" : "12661782",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3448537776/dcadec7f09cc309390b95bb2fd82aa89_normal.jpeg",
      "id" : 12661782,
      "verified" : false
    }
  },
  "id" : 39726730167975936,
  "created_at" : "Mon Feb 21 16:42:45 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://timely.is\" rel=\"nofollow\">Timely by Demandforce</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "39635981594263552",
  "text" : "I would like an app that honestly and objectively makes visible the subtext in any conversation. So many cheap shots go unaddressed.",
  "id" : 39635981594263552,
  "created_at" : "Mon Feb 21 10:42:09 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6125, -122.347667 ]
  },
  "id_str" : "39545039063359488",
  "text" : "8:36pm Watching Nova show on human evolution while eating burgers http://flic.kr/p/9jR1AY",
  "id" : 39545039063359488,
  "created_at" : "Mon Feb 21 04:40:46 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Few",
      "screen_name" : "jfew",
      "indices" : [ 0, 5 ],
      "id_str" : "2067141",
      "id" : 2067141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "39422034815488000",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6146086342, -122.3486851211 ]
  },
  "id_str" : "39422462705930240",
  "in_reply_to_user_id" : 2067141,
  "text" : "@jfew Thanks! I actually found another Goodwiller to piggyback with. Won't be the last trip though!",
  "id" : 39422462705930240,
  "in_reply_to_status_id" : 39422034815488000,
  "created_at" : "Sun Feb 20 20:33:42 +0000 2011",
  "in_reply_to_screen_name" : "jfew",
  "in_reply_to_user_id_str" : "2067141",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6146086342, -122.3486851211 ]
  },
  "id_str" : "39416892397584384",
  "text" : "Someone should do a study on how much better worrying has made the world.",
  "id" : 39416892397584384,
  "created_at" : "Sun Feb 20 20:11:34 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Natalya",
      "screen_name" : "talof2cities",
      "indices" : [ 0, 13 ],
      "id_str" : "62600226",
      "id" : 62600226
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "39394618177097728",
  "geo" : {
  },
  "id_str" : "39395335923171328",
  "in_reply_to_user_id" : 62600226,
  "text" : "@talof2cities Yes, we'll totally take you up on that offer! I'm home most of today... what time works for you? Thank you!",
  "id" : 39395335923171328,
  "in_reply_to_status_id" : 39394618177097728,
  "created_at" : "Sun Feb 20 18:45:54 +0000 2011",
  "in_reply_to_screen_name" : "talof2cities",
  "in_reply_to_user_id_str" : "62600226",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TaskRabbit",
      "screen_name" : "TaskRabbit",
      "indices" : [ 23, 34 ],
      "id_str" : "21883399",
      "id" : 21883399
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "39393707983781888",
  "text" : "I was all ready to use @taskrabbit to help take some clothes to Goodwill, but they're not in Seattle yet! What are my other options?",
  "id" : 39393707983781888,
  "created_at" : "Sun Feb 20 18:39:26 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.614166, -122.334 ]
  },
  "id_str" : "39189396326596608",
  "text" : "8:36pm Dinner with our doula and friends http://flic.kr/p/9judvZ",
  "id" : 39189396326596608,
  "created_at" : "Sun Feb 20 05:07:34 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chrissie Brodigan",
      "screen_name" : "tenaciouscb",
      "indices" : [ 0, 12 ],
      "id_str" : "56831057",
      "id" : 56831057
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "39097932959596544",
  "geo" : {
  },
  "id_str" : "39098220575461376",
  "in_reply_to_user_id" : 56831057,
  "text" : "@tenaciouscb Oh my! If only I could be a fly on the wall... :)",
  "id" : 39098220575461376,
  "in_reply_to_status_id" : 39097932959596544,
  "created_at" : "Sat Feb 19 23:05:16 +0000 2011",
  "in_reply_to_screen_name" : "tenaciouscb",
  "in_reply_to_user_id_str" : "56831057",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Margaret Field",
      "screen_name" : "MWField",
      "indices" : [ 0, 8 ],
      "id_str" : "15326867",
      "id" : 15326867
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "39032749167747072",
  "geo" : {
  },
  "id_str" : "39034362704048128",
  "in_reply_to_user_id" : 15326867,
  "text" : "@MWField Thank you! I used Ruby and a few linguistic analysis tools like Regressive Imagery Dictionary and LIWC to parse words.",
  "id" : 39034362704048128,
  "in_reply_to_status_id" : 39032749167747072,
  "created_at" : "Sat Feb 19 18:51:31 +0000 2011",
  "in_reply_to_screen_name" : "MWField",
  "in_reply_to_user_id_str" : "15326867",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6125, -122.3475 ]
  },
  "id_str" : "38822280482004992",
  "text" : "8:36pm Watching Untitled. Super excited about new apartment. Let's move already! http://flic.kr/p/9jhLHq",
  "id" : 38822280482004992,
  "created_at" : "Sat Feb 19 04:48:47 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ken Jennings",
      "screen_name" : "KenJennings",
      "indices" : [ 3, 15 ],
      "id_str" : "234270825",
      "id" : 234270825
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "38807410227421184",
  "text" : "RT @KenJennings: Just got back home to Seattle.  Plan to take out some anti-Watson frustration on my waffle iron.  Quit grinning fax mac ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "38473769139830784",
    "text" : "Just got back home to Seattle.  Plan to take out some anti-Watson frustration on my waffle iron.  Quit grinning fax machine you're next.",
    "id" : 38473769139830784,
    "created_at" : "Fri Feb 18 05:43:56 +0000 2011",
    "user" : {
      "name" : "Ken Jennings",
      "screen_name" : "KenJennings",
      "protected" : false,
      "id_str" : "234270825",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3629282425/67a3eee1e7ad3187f29e2d041dfac415_normal.jpeg",
      "id" : 234270825,
      "verified" : false
    }
  },
  "id" : 38807410227421184,
  "created_at" : "Sat Feb 19 03:49:42 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "38654716086976512",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6125109042, -122.34748909 ]
  },
  "id_str" : "38669314332557312",
  "in_reply_to_user_id" : 12363302,
  "text" : "@bobocopy Email me and we'll work something out! busterbenson@gmail.com",
  "id" : 38669314332557312,
  "in_reply_to_status_id" : 38654716086976512,
  "created_at" : "Fri Feb 18 18:40:57 +0000 2011",
  "in_reply_to_screen_name" : "andrewmkasper",
  "in_reply_to_user_id_str" : "12363302",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Health Games",
      "screen_name" : "HealthGaming",
      "indices" : [ 0, 13 ],
      "id_str" : "69068084",
      "id" : 69068084
    }, {
      "name" : "Gary Wolf",
      "screen_name" : "agaricus",
      "indices" : [ 128, 137 ],
      "id_str" : "21678279",
      "id" : 21678279
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "38599672494952450",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6125109042, -122.34748909 ]
  },
  "id_str" : "38632425705836545",
  "in_reply_to_user_id" : 69068084,
  "text" : "@HealthGaming Depends on how much money you want. People are not adverse to spending money on their own health, I've found. /cc @agaricus",
  "id" : 38632425705836545,
  "in_reply_to_status_id" : 38599672494952450,
  "created_at" : "Fri Feb 18 16:14:22 +0000 2011",
  "in_reply_to_screen_name" : "HealthGaming",
  "in_reply_to_user_id_str" : "69068084",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gordon Werner",
      "screen_name" : "GordonWerner",
      "indices" : [ 0, 13 ],
      "id_str" : "97830944",
      "id" : 97830944
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "38423450909417472",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6125109042, -122.34748909 ]
  },
  "id_str" : "38531890566664192",
  "in_reply_to_user_id" : 97830944,
  "text" : "@GordonWerner Yes, the current rule for you was set at 70 miles a week.",
  "id" : 38531890566664192,
  "in_reply_to_status_id" : 38423450909417472,
  "created_at" : "Fri Feb 18 09:34:53 +0000 2011",
  "in_reply_to_screen_name" : "GordonWerner",
  "in_reply_to_user_id_str" : "97830944",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.613833, -122.347167 ]
  },
  "id_str" : "38457275655913472",
  "text" : "8:36pm Drink with Ingo night! http://flic.kr/p/9j5h4L",
  "id" : 38457275655913472,
  "created_at" : "Fri Feb 18 04:38:23 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Britt Crawford",
      "screen_name" : "britt",
      "indices" : [ 0, 6 ],
      "id_str" : "5362",
      "id" : 5362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "38289922460749824",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6125118962, -122.3474888485 ]
  },
  "id_str" : "38290105034747904",
  "in_reply_to_user_id" : 5362,
  "text" : "@britt Still working on it! Should be on your profile page within a couple days.",
  "id" : 38290105034747904,
  "in_reply_to_status_id" : 38289922460749824,
  "created_at" : "Thu Feb 17 17:34:07 +0000 2011",
  "in_reply_to_screen_name" : "britt",
  "in_reply_to_user_id_str" : "5362",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6125591544, -122.3475304533 ]
  },
  "id_str" : "38281555826704384",
  "text" : "@Iceworth Yes: busterbenson@gmail.com",
  "id" : 38281555826704384,
  "created_at" : "Thu Feb 17 17:00:08 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.612666, -122.3475 ]
  },
  "id_str" : "38103068323086336",
  "text" : "8:36pm This half-packed house is a shambles, I'm nap poor, and we ran out of Damages episodes. Early night! http://flic.kr/p/9iRt53",
  "id" : 38103068323086336,
  "created_at" : "Thu Feb 17 05:10:54 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Wolf",
      "screen_name" : "agaricus",
      "indices" : [ 12, 21 ],
      "id_str" : "21678279",
      "id" : 21678279
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6124005875, -122.3474909917 ]
  },
  "id_str" : "37784247271956480",
  "text" : "I agree. RT @agaricus: I think the pharma, advertising, social game nexus will prove toxic. (For context: http://bit.ly/h1lEpC)",
  "id" : 37784247271956480,
  "created_at" : "Wed Feb 16 08:04:01 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "healthmonth",
      "indices" : [ 26, 38 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.612666, -122.3475 ]
  },
  "id_str" : "37747746479808512",
  "text" : "8:36pm Was working on new #healthmonth charts, but always confused by this page. So ominous! http://flic.kr/p/9iyURv",
  "id" : 37747746479808512,
  "created_at" : "Wed Feb 16 05:38:58 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Behance's 99U",
      "screen_name" : "the99percent",
      "indices" : [ 3, 16 ],
      "id_str" : "716292679",
      "id" : 716292679
    }, {
      "name" : "Longform.org",
      "screen_name" : "longformorg",
      "indices" : [ 120, 132 ],
      "id_str" : "454253408",
      "id" : 454253408
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "37646513110777856",
  "text" : "RT @the99percent: Ray Kurzweil and the Singularity; when will our minds meld with the machine? http://cot.ag/ewrU0y via @longformorg",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.exacttarget.com/social\" rel=\"nofollow\">SocialEngage</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Longform.org",
        "screen_name" : "longformorg",
        "indices" : [ 102, 114 ],
        "id_str" : "454253408",
        "id" : 454253408
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "37639037502234624",
    "text" : "Ray Kurzweil and the Singularity; when will our minds meld with the machine? http://cot.ag/ewrU0y via @longformorg",
    "id" : 37639037502234624,
    "created_at" : "Tue Feb 15 22:27:00 +0000 2011",
    "user" : {
      "name" : "99U",
      "screen_name" : "99u",
      "protected" : false,
      "id_str" : "17636894",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2995676123/fa7645dcc7f6d69b442bbcbd0950a0ef_normal.png",
      "id" : 17636894,
      "verified" : true
    }
  },
  "id" : 37646513110777856,
  "created_at" : "Tue Feb 15 22:56:42 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason O. Black",
      "screen_name" : "JahsonBlack",
      "indices" : [ 0, 12 ],
      "id_str" : "15586505",
      "id" : 15586505
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "37541386290987009",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6124725933, -122.3475487392 ]
  },
  "id_str" : "37542574625538048",
  "in_reply_to_user_id" : 15586505,
  "text" : "@JahsonBlack Yes, definitely in the plans!",
  "id" : 37542574625538048,
  "in_reply_to_status_id" : 37541386290987009,
  "created_at" : "Tue Feb 15 16:03:41 +0000 2011",
  "in_reply_to_screen_name" : "JahsonBlack",
  "in_reply_to_user_id_str" : "15586505",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.612666, -122.3475 ]
  },
  "id_str" : "37372463859900416",
  "text" : "8:36pm We do Valentine's Day right in the Benson house http://flic.kr/p/9in2GL",
  "id" : 37372463859900416,
  "created_at" : "Tue Feb 15 04:47:44 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Merlin Mann",
      "screen_name" : "hotdogsladies",
      "indices" : [ 3, 17 ],
      "id_str" : "749863",
      "id" : 749863
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "37355726422671361",
  "text" : "RT @hotdogsladies: \"How many things do I need to shed, cancel, defer, drop, shank, or shit-can\u2026to focus on this one thing that I love?\"\n ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "37344490096304128",
    "text" : "\"How many things do I need to shed, cancel, defer, drop, shank, or shit-can\u2026to focus on this one thing that I love?\"\n\nhttp://bit.ly/1st-care",
    "id" : 37344490096304128,
    "created_at" : "Tue Feb 15 02:56:34 +0000 2011",
    "user" : {
      "name" : "Merlin Mann",
      "screen_name" : "hotdogsladies",
      "protected" : false,
      "id_str" : "749863",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/51857279/merlin_icon_184-1_normal.png",
      "id" : 749863,
      "verified" : true
    }
  },
  "id" : 37355726422671361,
  "created_at" : "Tue Feb 15 03:41:13 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.fitbit.com\" rel=\"nofollow\">Fitbit</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fitstats",
      "indices" : [ 14, 23 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "37285648486375424",
  "text" : "My avg. daily #fitstats for last week: 7,149 steps, 3.4 miles, 2,549 calories burned via my fitbit http://www.fitbit.com/user/229KX2",
  "id" : 37285648486375424,
  "created_at" : "Mon Feb 14 23:02:45 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "meta",
      "indices" : [ 126, 131 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 125 ],
      "url" : "http://t.co/gpXo4y2",
      "expanded_url" : "http://lean.st/busterbenson",
      "display_url" : "lean.st/busterbenson"
    } ]
  },
  "geo" : {
  },
  "id_str" : "37271869841215488",
  "text" : "Just pre-ordered my Lean Startup book. I love how you get access to their trends & experiments by buying: http://t.co/gpXo4y2 #meta",
  "id" : 37271869841215488,
  "created_at" : "Mon Feb 14 22:08:00 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tanner C",
      "screen_name" : "tannerc",
      "indices" : [ 0, 8 ],
      "id_str" : "9161482",
      "id" : 9161482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 92 ],
      "url" : "http://t.co/wahl4Vo",
      "expanded_url" : "http://trackyourhappiness.org",
      "display_url" : "trackyourhappiness.org"
    } ]
  },
  "in_reply_to_status_id_str" : "37264467616075776",
  "geo" : {
  },
  "id_str" : "37267868299042816",
  "in_reply_to_user_id" : 9161482,
  "text" : "@tannerc Nothing at the moment, but every 6 months or so I do a month of http://t.co/wahl4Vo",
  "id" : 37267868299042816,
  "in_reply_to_status_id" : 37264467616075776,
  "created_at" : "Mon Feb 14 21:52:06 +0000 2011",
  "in_reply_to_screen_name" : "tannerc",
  "in_reply_to_user_id_str" : "9161482",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gretchen Rubin",
      "screen_name" : "gretchenrubin",
      "indices" : [ 119, 133 ],
      "id_str" : "14289835",
      "id" : 14289835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 115 ],
      "url" : "http://t.co/fFKAYMY",
      "expanded_url" : "http://www.happiness-project.com/happiness_project/2007/04/the_importance_.html",
      "display_url" : "happiness-project.com/happiness_proj\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "37263598182998016",
  "text" : "Nice articulation of how difficult it is for us to know what activities actually make us happy: http://t.co/fFKAYMY by @gretchenrubin",
  "id" : 37263598182998016,
  "created_at" : "Mon Feb 14 21:35:08 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Enjoymentland",
      "screen_name" : "enjoymentland",
      "indices" : [ 35, 49 ],
      "id_str" : "19808652",
      "id" : 19808652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 116 ],
      "url" : "http://t.co/iZTYHFW",
      "expanded_url" : "http://goo.gl/fb/MP4Qb",
      "display_url" : "goo.gl/fb/MP4Qb"
    } ]
  },
  "geo" : {
  },
  "id_str" : "37252858202038272",
  "text" : "Super excited about this --&gt; RT @enjoymentland: Health Month Recommended Behaviors, version 1 http://t.co/iZTYHFW",
  "id" : 37252858202038272,
  "created_at" : "Mon Feb 14 20:52:28 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "josh",
      "screen_name" : "joshc",
      "indices" : [ 3, 9 ],
      "id_str" : "2015",
      "id" : 2015
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "brilliantinstatumblrsdotcom",
      "indices" : [ 73, 101 ]
    } ],
    "urls" : [ {
      "indices" : [ 53, 72 ],
      "url" : "http://t.co/BiHVK6O",
      "expanded_url" : "http://whoisarcadefire.tumblr.com/",
      "display_url" : "whoisarcadefire.tumblr.com"
    } ]
  },
  "geo" : {
  },
  "id_str" : "37228950207860736",
  "text" : "RT @joshc: so maybe arcade fire isn't so mainstream? http://t.co/BiHVK6O #brilliantinstatumblrsdotcom",
  "retweeted_status" : {
    "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "brilliantinstatumblrsdotcom",
        "indices" : [ 62, 90 ]
      } ],
      "urls" : [ {
        "indices" : [ 42, 61 ],
        "url" : "http://t.co/BiHVK6O",
        "expanded_url" : "http://whoisarcadefire.tumblr.com/",
        "display_url" : "whoisarcadefire.tumblr.com"
      } ]
    },
    "geo" : {
    },
    "id_str" : "37202181513814016",
    "text" : "so maybe arcade fire isn't so mainstream? http://t.co/BiHVK6O #brilliantinstatumblrsdotcom",
    "id" : 37202181513814016,
    "created_at" : "Mon Feb 14 17:31:05 +0000 2011",
    "user" : {
      "name" : "josh",
      "screen_name" : "joshc",
      "protected" : false,
      "id_str" : "2015",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1177804504/5175158325_b941153f5b_b_normal.jpg",
      "id" : 2015,
      "verified" : false
    }
  },
  "id" : 37228950207860736,
  "created_at" : "Mon Feb 14 19:17:28 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amy Jo Kim",
      "screen_name" : "amyjokim",
      "indices" : [ 3, 12 ],
      "id_str" : "780991",
      "id" : 780991
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "37226519323480064",
  "text" : "RT @amyjokim: Data shows that the idea of cooperation is much more effective in social networking games (Bing Gordon) http://bit.ly/gzmAfb",
  "retweeted_status" : {
    "source" : "<a href=\"http://bitly.com\" rel=\"nofollow\">bitly</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "37217249970364416",
    "text" : "Data shows that the idea of cooperation is much more effective in social networking games (Bing Gordon) http://bit.ly/gzmAfb",
    "id" : 37217249970364416,
    "created_at" : "Mon Feb 14 18:30:58 +0000 2011",
    "user" : {
      "name" : "Amy Jo Kim",
      "screen_name" : "amyjokim",
      "protected" : false,
      "id_str" : "780991",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1789001732/ajk-headshot2_normal.jpg",
      "id" : 780991,
      "verified" : false
    }
  },
  "id" : 37226519323480064,
  "created_at" : "Mon Feb 14 19:07:48 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jen Joyce",
      "screen_name" : "knitpurl",
      "indices" : [ 0, 9 ],
      "id_str" : "17655771",
      "id" : 17655771
    }, {
      "name" : "Aimee",
      "screen_name" : "LilHossler",
      "indices" : [ 90, 101 ],
      "id_str" : "123116307",
      "id" : 123116307
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "37042672967356417",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6126714578, -122.3474720222 ]
  },
  "id_str" : "37058196388454400",
  "in_reply_to_user_id" : 123116307,
  "text" : "@knitpurl Welcome to 8:36pm! I love when it spreads. Just checked and I'm on day 998! /cc @lilhossler",
  "id" : 37058196388454400,
  "in_reply_to_status_id" : 37042672967356417,
  "created_at" : "Mon Feb 14 07:58:57 +0000 2011",
  "in_reply_to_screen_name" : "LilHossler",
  "in_reply_to_user_id_str" : "123116307",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TechCrunch",
      "screen_name" : "TechCrunch",
      "indices" : [ 43, 54 ],
      "id_str" : "816653",
      "id" : 816653
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6126714578, -122.3474720222 ]
  },
  "id_str" : "37056373300662272",
  "text" : "I'm in love with this story. Well told! RT @TechCrunch: Inside the DNA of the Facebook Mafia http://j.mp/dK32CV",
  "id" : 37056373300662272,
  "created_at" : "Mon Feb 14 07:51:42 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "david reeves",
      "screen_name" : "dreeves",
      "indices" : [ 0, 8 ],
      "id_str" : "947851",
      "id" : 947851
    }, {
      "name" : "FROGBOX",
      "screen_name" : "FROGBOX",
      "indices" : [ 28, 36 ],
      "id_str" : "17663309",
      "id" : 17663309
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "37055375039660032",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6126714578, -122.3474720222 ]
  },
  "id_str" : "37055812241199104",
  "in_reply_to_user_id" : 947851,
  "text" : "@dreeves Thanks! Going with @frogbox, they deliver and pick up boxes when you're done!",
  "id" : 37055812241199104,
  "in_reply_to_status_id" : 37055375039660032,
  "created_at" : "Mon Feb 14 07:49:28 +0000 2011",
  "in_reply_to_screen_name" : "dreeves",
  "in_reply_to_user_id_str" : "947851",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6125, -122.3475 ]
  },
  "id_str" : "37008265510391808",
  "text" : "8:36pm Our new favorite post-work activity: Damages and take-out http://flic.kr/p/9i6iru",
  "id" : 37008265510391808,
  "created_at" : "Mon Feb 14 04:40:32 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://timely.is\" rel=\"nofollow\">Timely by Demandforce</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bijan Sabet",
      "screen_name" : "bijan",
      "indices" : [ 96, 102 ],
      "id_str" : "3713811",
      "id" : 3713811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "36992312462548992",
  "text" : "The internet made two-way group action easier, and that's a big deal: http://bit.ly/eQOouq /via @bijan",
  "id" : 36992312462548992,
  "created_at" : "Mon Feb 14 03:37:09 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6636529, -122.373675 ]
  },
  "id_str" : "36937220149485568",
  "text" : "Niko and Vivienne  @ Ballard http://instagr.am/p/BlgQW/",
  "id" : 36937220149485568,
  "created_at" : "Sun Feb 13 23:58:14 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FROGBOX",
      "screen_name" : "FROGBOX",
      "indices" : [ 70, 78 ],
      "id_str" : "17663309",
      "id" : 17663309
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6125431489, -122.34755723 ]
  },
  "id_str" : "36934235004608512",
  "text" : "Nevermind about those boxes (thank to those who offered!). Going with @frogbox which looks pretty great. Has anyone used them?",
  "id" : 36934235004608512,
  "created_at" : "Sun Feb 13 23:46:22 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "&y",
      "screen_name" : "andypixel",
      "indices" : [ 0, 10 ],
      "id_str" : "10015122",
      "id" : 10015122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "36923077669421056",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6125431489, -122.34755723 ]
  },
  "id_str" : "36927225156603905",
  "in_reply_to_user_id" : 10015122,
  "text" : "@andypixel Just packing for now. Movers come the 25th! Then: neighbortownsville!",
  "id" : 36927225156603905,
  "in_reply_to_status_id" : 36923077669421056,
  "created_at" : "Sun Feb 13 23:18:31 +0000 2011",
  "in_reply_to_screen_name" : "andypixel",
  "in_reply_to_user_id_str" : "10015122",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 91, 94 ]
    }, {
      "text" : "hugefavor",
      "indices" : [ 95, 105 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "36916837421817856",
  "text" : "Seattle friends! Do any of you have time to bring me 10-15 moving boxes today or tomorrow? #fb #hugefavor",
  "id" : 36916837421817856,
  "created_at" : "Sun Feb 13 22:37:14 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.674833, -122.363334 ]
  },
  "id_str" : "36646023044530177",
  "text" : "8:36pm Hanging out with our funny Ballard friends http://flic.kr/p/9hMdW1",
  "id" : 36646023044530177,
  "created_at" : "Sun Feb 13 04:41:07 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://timely.is\" rel=\"nofollow\">Timely by Demandforce</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Health Month",
      "screen_name" : "healthmonth",
      "indices" : [ 10, 22 ],
      "id_str" : "154236895",
      "id" : 154236895
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "36629933367230464",
  "text" : "Brand new @healthmonth feature! The Rule Wizard. http://bit.ly/hQsJDK",
  "id" : 36629933367230464,
  "created_at" : "Sun Feb 13 03:37:11 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Natalya",
      "screen_name" : "talof2cities",
      "indices" : [ 0, 13 ],
      "id_str" : "62600226",
      "id" : 62600226
    }, {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 14, 24 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "35935075593887745",
  "geo" : {
  },
  "id_str" : "36553286043566080",
  "in_reply_to_user_id" : 62600226,
  "text" : "@talof2cities @kellianne Hey, just saw this! For what it's worth, I DO usually do the dishes. I just like doing them by hand. It's relaxing!",
  "id" : 36553286043566080,
  "in_reply_to_status_id" : 35935075593887745,
  "created_at" : "Sat Feb 12 22:32:37 +0000 2011",
  "in_reply_to_screen_name" : "talof2cities",
  "in_reply_to_user_id_str" : "62600226",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amber Rae",
      "screen_name" : "heyamberrae",
      "indices" : [ 0, 12 ],
      "id_str" : "15019184",
      "id" : 15019184
    }, {
      "name" : "Micah Baldwin",
      "screen_name" : "micah",
      "indices" : [ 13, 19 ],
      "id_str" : "5469512",
      "id" : 5469512
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "36545912356478976",
  "geo" : {
  },
  "id_str" : "36546162022547456",
  "in_reply_to_user_id" : 15019184,
  "text" : "@heyamberrae @micah 5 extra points if you change your first name to Hey.",
  "id" : 36546162022547456,
  "in_reply_to_status_id" : 36545912356478976,
  "created_at" : "Sat Feb 12 22:04:18 +0000 2011",
  "in_reply_to_screen_name" : "heyamberrae",
  "in_reply_to_user_id_str" : "15019184",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amber Rae",
      "screen_name" : "heyamberrae",
      "indices" : [ 0, 12 ],
      "id_str" : "15019184",
      "id" : 15019184
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "36543047239991299",
  "geo" : {
  },
  "id_str" : "36543552410484736",
  "in_reply_to_user_id" : 15019184,
  "text" : "@heyamberrae First, middle, second middle, suffix, etc. :)\n\nPS. I'm a name-changing evangelist.",
  "id" : 36543552410484736,
  "in_reply_to_status_id" : 36543047239991299,
  "created_at" : "Sat Feb 12 21:53:56 +0000 2011",
  "in_reply_to_screen_name" : "heyamberrae",
  "in_reply_to_user_id_str" : "15019184",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amber Rae",
      "screen_name" : "heyamberrae",
      "indices" : [ 0, 12 ],
      "id_str" : "15019184",
      "id" : 15019184
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "36542137218637825",
  "geo" : {
  },
  "id_str" : "36542557068464128",
  "in_reply_to_user_id" : 15019184,
  "text" : "@heyamberrae Not even to save a few bucks? :) Oh, and you can also change all of your other names at the same time for no extra charge.",
  "id" : 36542557068464128,
  "in_reply_to_status_id" : 36542137218637825,
  "created_at" : "Sat Feb 12 21:49:59 +0000 2011",
  "in_reply_to_screen_name" : "heyamberrae",
  "in_reply_to_user_id_str" : "15019184",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amber Rae",
      "screen_name" : "heyamberrae",
      "indices" : [ 0, 12 ],
      "id_str" : "15019184",
      "id" : 15019184
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "36541551274369025",
  "geo" : {
  },
  "id_str" : "36541799388418048",
  "in_reply_to_user_id" : 15019184,
  "text" : "@heyamberrae It depends state by state, but in Washington State it's about $130. Less if you also get married.",
  "id" : 36541799388418048,
  "in_reply_to_status_id" : 36541551274369025,
  "created_at" : "Sat Feb 12 21:46:58 +0000 2011",
  "in_reply_to_screen_name" : "heyamberrae",
  "in_reply_to_user_id_str" : "15019184",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Maria",
      "screen_name" : "MuseKitsch",
      "indices" : [ 0, 11 ],
      "id_str" : "14329453",
      "id" : 14329453
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "36302270140395520",
  "geo" : {
  },
  "id_str" : "36309976976723968",
  "in_reply_to_user_id" : 14329453,
  "text" : "@musekitsch What's your name/email on 750words? I can fix your streak for you if you want...",
  "id" : 36309976976723968,
  "in_reply_to_status_id" : 36302270140395520,
  "created_at" : "Sat Feb 12 06:25:47 +0000 2011",
  "in_reply_to_screen_name" : "MuseKitsch",
  "in_reply_to_user_id_str" : "14329453",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Schappell",
      "screen_name" : "daveschappell",
      "indices" : [ 3, 17 ],
      "id_str" : "820661",
      "id" : 820661
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "36288208497147904",
  "text" : "RT @daveschappell: Habits are hard to break. Or, why it\u2019s so difficult to lose weight, stop smoking or exercise more http://bit.ly/f2K3WR",
  "retweeted_status" : {
    "source" : "<a href=\"http://bitly.com\" rel=\"nofollow\">bitly</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "35888279408607233",
    "text" : "Habits are hard to break. Or, why it\u2019s so difficult to lose weight, stop smoking or exercise more http://bit.ly/f2K3WR",
    "id" : 35888279408607233,
    "created_at" : "Fri Feb 11 02:30:07 +0000 2011",
    "user" : {
      "name" : "Dave Schappell",
      "screen_name" : "daveschappell",
      "protected" : false,
      "id_str" : "820661",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3160071838/28c085d5177f98840fb6b6b0a82203a1_normal.jpeg",
      "id" : 820661,
      "verified" : false
    }
  },
  "id" : 36288208497147904,
  "created_at" : "Sat Feb 12 04:59:17 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fitbit",
      "screen_name" : "fitbit",
      "indices" : [ 39, 46 ],
      "id_str" : "17424053",
      "id" : 17424053
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 99 ],
      "url" : "http://t.co/glNCYQB",
      "expanded_url" : "http://blog.fitbit.com/?p=325",
      "display_url" : "blog.fitbit.com/?p=325"
    } ]
  },
  "geo" : {
  },
  "id_str" : "36160712950685696",
  "text" : "Congrats! Super stoked to use this. RT @fitbit: Announcing the Fitbit Beta API! http://t.co/glNCYQB",
  "id" : 36160712950685696,
  "created_at" : "Fri Feb 11 20:32:40 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ReadWrite",
      "screen_name" : "RWW",
      "indices" : [ 3, 7 ],
      "id_str" : "4641021",
      "id" : 4641021
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "egypt",
      "indices" : [ 45, 51 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "36105620788613120",
  "text" : "RT @RWW: http://ismubarakstillpresident.com/ #egypt",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "egypt",
        "indices" : [ 36, 42 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "36105018725629953",
    "text" : "http://ismubarakstillpresident.com/ #egypt",
    "id" : 36105018725629953,
    "created_at" : "Fri Feb 11 16:51:21 +0000 2011",
    "user" : {
      "name" : "ReadWrite",
      "screen_name" : "RWW",
      "protected" : false,
      "id_str" : "4641021",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2750899250/294d9c7b13ba263c7c3f634a487d468d_normal.jpeg",
      "id" : 4641021,
      "verified" : true
    }
  },
  "id" : 36105620788613120,
  "created_at" : "Fri Feb 11 16:53:45 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tara Tiger Brown",
      "screen_name" : "tara",
      "indices" : [ 0, 5 ],
      "id_str" : "10959642",
      "id" : 10959642
    }, {
      "name" : "Lynn",
      "screen_name" : "Poshy",
      "indices" : [ 6, 12 ],
      "id_str" : "4708351",
      "id" : 4708351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "35947887548436480",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.612537834, -122.347543301 ]
  },
  "id_str" : "35961211682172928",
  "in_reply_to_user_id" : 10959642,
  "text" : "@tara @poshy We're packing up 7yrs of crap right now too! We put Niko in a box surrounded by packed boxes and he seems to love it.",
  "id" : 35961211682172928,
  "in_reply_to_status_id" : 35947887548436480,
  "created_at" : "Fri Feb 11 07:19:55 +0000 2011",
  "in_reply_to_screen_name" : "tara",
  "in_reply_to_user_id_str" : "10959642",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "brynn evans",
      "screen_name" : "brynn",
      "indices" : [ 0, 6 ],
      "id_str" : "8708232",
      "id" : 8708232
    }, {
      "name" : "Gwen Bell",
      "screen_name" : "gwenbell",
      "indices" : [ 7, 16 ],
      "id_str" : "1250104952",
      "id" : 1250104952
    }, {
      "name" : "Helen Jane",
      "screen_name" : "helenjane",
      "indices" : [ 17, 27 ],
      "id_str" : "798542",
      "id" : 798542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "35775700111720448",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6126306727, -122.3475036645 ]
  },
  "id_str" : "35929928230768640",
  "in_reply_to_user_id" : 8708232,
  "text" : "@brynn @gwenbell @helenjane That would be so awesome if the stars aligned!",
  "id" : 35929928230768640,
  "in_reply_to_status_id" : 35775700111720448,
  "created_at" : "Fri Feb 11 05:15:37 +0000 2011",
  "in_reply_to_screen_name" : "brynn",
  "in_reply_to_user_id_str" : "8708232",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lynn",
      "screen_name" : "Poshy",
      "indices" : [ 0, 6 ],
      "id_str" : "4708351",
      "id" : 4708351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "35922998791770112",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6126346471, -122.3474971543 ]
  },
  "id_str" : "35929025687855104",
  "in_reply_to_user_id" : 4708351,
  "text" : "@Poshy Someone's gotta keep the cute babies on Twitter quotient up there, right?",
  "id" : 35929025687855104,
  "in_reply_to_status_id" : 35922998791770112,
  "created_at" : "Fri Feb 11 05:12:01 +0000 2011",
  "in_reply_to_screen_name" : "Poshy",
  "in_reply_to_user_id_str" : "4708351",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.612666, -122.347667 ]
  },
  "id_str" : "35922836052774912",
  "text" : "8:36pm Niko bathtimes! Found the shower knob! http://flic.kr/p/9hjsJU",
  "id" : 35922836052774912,
  "created_at" : "Fri Feb 11 04:47:26 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "35840536824782848",
  "geo" : {
  },
  "id_str" : "35840789649162240",
  "in_reply_to_user_id" : 12363302,
  "text" : "@bobocopy She only has 3 rules, therefore it's free to play. No sponsorship needed!",
  "id" : 35840789649162240,
  "in_reply_to_status_id" : 35840536824782848,
  "created_at" : "Thu Feb 10 23:21:24 +0000 2011",
  "in_reply_to_screen_name" : "andrewmkasper",
  "in_reply_to_user_id_str" : "12363302",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "35820584600481792",
  "geo" : {
  },
  "id_str" : "35820935651000321",
  "in_reply_to_user_id" : 12363302,
  "text" : "@bobocopy What's her username?",
  "id" : 35820935651000321,
  "in_reply_to_status_id" : 35820584600481792,
  "created_at" : "Thu Feb 10 22:02:31 +0000 2011",
  "in_reply_to_screen_name" : "andrewmkasper",
  "in_reply_to_user_id_str" : "12363302",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "35810870927818752",
  "geo" : {
  },
  "id_str" : "35811070606180352",
  "in_reply_to_user_id" : 12363302,
  "text" : "@bobocopy Have your friend apply for sponsorship when they choose their rules, and a \"sponsor me!\" link WILL appear on their profile.",
  "id" : 35811070606180352,
  "in_reply_to_status_id" : 35810870927818752,
  "created_at" : "Thu Feb 10 21:23:19 +0000 2011",
  "in_reply_to_screen_name" : "andrewmkasper",
  "in_reply_to_user_id_str" : "12363302",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christine Brumback",
      "screen_name" : "Boomer",
      "indices" : [ 0, 7 ],
      "id_str" : "30693",
      "id" : 30693
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "35599135197368320",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.5678316791, -122.2969492171 ]
  },
  "id_str" : "35600409129127936",
  "in_reply_to_user_id" : 30693,
  "text" : "@Boomer Thank you! Looks brilliant at first glance.",
  "id" : 35600409129127936,
  "in_reply_to_status_id" : 35599135197368320,
  "created_at" : "Thu Feb 10 07:26:13 +0000 2011",
  "in_reply_to_screen_name" : "Boomer",
  "in_reply_to_user_id_str" : "30693",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christine Brumback",
      "screen_name" : "Boomer",
      "indices" : [ 0, 7 ],
      "id_str" : "30693",
      "id" : 30693
    }, {
      "name" : "Honestly Now",
      "screen_name" : "HonestlyNowInc",
      "indices" : [ 22, 37 ],
      "id_str" : "84414843",
      "id" : 84414843
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "35577580472123392",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.44535976, -122.303595895 ]
  },
  "id_str" : "35595488405225472",
  "in_reply_to_user_id" : 30693,
  "text" : "@Boomer Ooh what that @honestlynowinc all about? Got any extra invites?",
  "id" : 35595488405225472,
  "in_reply_to_status_id" : 35577580472123392,
  "created_at" : "Thu Feb 10 07:06:40 +0000 2011",
  "in_reply_to_screen_name" : "Boomer",
  "in_reply_to_user_id_str" : "30693",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.611833, -122.390334 ]
  },
  "id_str" : "35558513602203648",
  "text" : "8:36pm About to take off from SFO in the partyplanemobile. Which romcom should I watch? http://flic.kr/p/9h64wC",
  "id" : 35558513602203648,
  "created_at" : "Thu Feb 10 04:39:44 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jimmy James Hall",
      "screen_name" : "JimmyJameson",
      "indices" : [ 0, 13 ],
      "id_str" : "35141809",
      "id" : 35141809
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "35557439663243264",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.6117915789, -122.3903617733 ]
  },
  "id_str" : "35557737916141568",
  "in_reply_to_user_id" : 35141809,
  "text" : "@JimmyJameson Departing... :( Another short but productive visit. Next one in 2 weeks!",
  "id" : 35557737916141568,
  "in_reply_to_status_id" : 35557439663243264,
  "created_at" : "Thu Feb 10 04:36:40 +0000 2011",
  "in_reply_to_screen_name" : "JimmyJameson",
  "in_reply_to_user_id_str" : "35141809",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Messina\u2122",
      "screen_name" : "chrismessina",
      "indices" : [ 0, 13 ],
      "id_str" : "1186",
      "id" : 1186
    }, {
      "name" : "Brynn Evans",
      "screen_name" : "BrynnEvans",
      "indices" : [ 38, 49 ],
      "id_str" : "66780377",
      "id" : 66780377
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "35548787342704640",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.6117915789, -122.3903617733 ]
  },
  "id_str" : "35555924353482752",
  "in_reply_to_user_id" : 1186,
  "text" : "@chrismessina Awesome meeting you and @brynnevans as well. Good things will come of this night, I am sure of it!",
  "id" : 35555924353482752,
  "in_reply_to_status_id" : 35548787342704640,
  "created_at" : "Thu Feb 10 04:29:27 +0000 2011",
  "in_reply_to_screen_name" : "chrismessina",
  "in_reply_to_user_id_str" : "1186",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 0, 10 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "35555135174213632",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.6117915789, -122.3903617733 ]
  },
  "id_str" : "35555585537609728",
  "in_reply_to_user_id" : 7362142,
  "text" : "@kellianne So great, right? But what did you watch without me???",
  "id" : 35555585537609728,
  "in_reply_to_status_id" : 35555135174213632,
  "created_at" : "Thu Feb 10 04:28:06 +0000 2011",
  "in_reply_to_screen_name" : "kellianne",
  "in_reply_to_user_id_str" : "7362142",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "brynn evans",
      "screen_name" : "brynn",
      "indices" : [ 0, 6 ],
      "id_str" : "8708232",
      "id" : 8708232
    }, {
      "name" : "Gwen Bell",
      "screen_name" : "gwenbell",
      "indices" : [ 7, 16 ],
      "id_str" : "1250104952",
      "id" : 1250104952
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "35536918020104192",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.6340563535, -122.4039643951 ]
  },
  "id_str" : "35547302764482560",
  "in_reply_to_user_id" : 8708232,
  "text" : "@brynn @gwenbell You two should definitely talk and/or meet up. Kindred spirits!",
  "id" : 35547302764482560,
  "in_reply_to_status_id" : 35536918020104192,
  "created_at" : "Thu Feb 10 03:55:12 +0000 2011",
  "in_reply_to_screen_name" : "brynn",
  "in_reply_to_user_id_str" : "8708232",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mari Sheibley",
      "screen_name" : "Mari18",
      "indices" : [ 3, 10 ],
      "id_str" : "9270952",
      "id" : 9270952
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "35493919705800704",
  "text" : "RT @Mari18: The good thing about having too much on your plate is that if you get stuck on something, you can go eat something else for  ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "35492532326502401",
    "text" : "The good thing about having too much on your plate is that if you get stuck on something, you can go eat something else for awhile...",
    "id" : 35492532326502401,
    "created_at" : "Thu Feb 10 00:17:33 +0000 2011",
    "user" : {
      "name" : "Mari Sheibley",
      "screen_name" : "Mari18",
      "protected" : false,
      "id_str" : "9270952",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1668412512/photo_normal.jpeg",
      "id" : 9270952,
      "verified" : false
    }
  },
  "id" : 35493919705800704,
  "created_at" : "Thu Feb 10 00:23:04 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Foursquare",
      "screen_name" : "foursquare",
      "indices" : [ 42, 53 ],
      "id_str" : "14120151",
      "id" : 14120151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "35391643624415232",
  "text" : "I just unlocked the \"Fresh Brew\" badge on @foursquare! http://4sq.com/fd5ADh",
  "id" : 35391643624415232,
  "created_at" : "Wed Feb 09 17:36:40 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.776333, -122.408334 ]
  },
  "id_str" : "35197746726047744",
  "text" : "8:36pm Arguing about genomics at Radius with Jen and Brian http://flic.kr/p/9gRjcy",
  "id" : 35197746726047744,
  "created_at" : "Wed Feb 09 04:46:11 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Foursquare",
      "screen_name" : "foursquare",
      "indices" : [ 41, 52 ],
      "id_str" : "14120151",
      "id" : 14120151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "35067720689000448",
  "text" : "I just unlocked the \"Mile High\" badge on @foursquare! http://4sq.com/ftzJc0",
  "id" : 35067720689000448,
  "created_at" : "Tue Feb 08 20:09:30 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6125, -122.3475 ]
  },
  "id_str" : "34835616722059264",
  "text" : "8:36pm Totaling up 2010 deductions using mint.com and a spreadsheet. Bleeding from eyes. http://flic.kr/p/9gAz9A",
  "id" : 34835616722059264,
  "created_at" : "Tue Feb 08 04:47:12 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gwen Bell",
      "screen_name" : "gwenbell",
      "indices" : [ 0, 9 ],
      "id_str" : "1250104952",
      "id" : 1250104952
    }, {
      "name" : "letter.ly",
      "screen_name" : "letter_ly",
      "indices" : [ 98, 108 ],
      "id_str" : "168478186",
      "id" : 168478186
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "34776166246260736",
  "text" : "@gwenbell Yeah, the article is all over the place - my favorite kind. I'm very curious about this @letter_ly project... tell me more!",
  "id" : 34776166246260736,
  "created_at" : "Tue Feb 08 00:50:58 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 93 ],
      "url" : "http://t.co/4VLYu9y",
      "expanded_url" : "http://www.newyorker.com/reporting/2011/01/17/110117fa_fact_brooks#ixzz1DK6yBOWz",
      "display_url" : "newyorker.com/reporting/2011\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "34773377008799745",
  "text" : "\"Our perceptions are fantasies we construct that correlate with reality.\" http://t.co/4VLYu9y",
  "id" : 34773377008799745,
  "created_at" : "Tue Feb 08 00:39:53 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rand Fitzpatrick",
      "screen_name" : "sixwing",
      "indices" : [ 0, 8 ],
      "id_str" : "903011",
      "id" : 903011
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "34770540648468482",
  "geo" : {
  },
  "id_str" : "34772658453217280",
  "in_reply_to_user_id" : 903011,
  "text" : "@sixwing I'll let you know in a couple years.  :)  For the record, I also *changed* my name... might skew the experiment a bit.",
  "id" : 34772658453217280,
  "in_reply_to_status_id" : 34770540648468482,
  "created_at" : "Tue Feb 08 00:37:02 +0000 2011",
  "in_reply_to_screen_name" : "sixwing",
  "in_reply_to_user_id_str" : "903011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.fitbit.com\" rel=\"nofollow\">Fitbit</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fitstats",
      "indices" : [ 14, 23 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "34749071293939712",
  "text" : "My avg. daily #fitstats for last week: 2,228 steps, 1.1 miles, 2,528 calories burned via my fitbit http://www.fitbit.com/user/229KX2",
  "id" : 34749071293939712,
  "created_at" : "Mon Feb 07 23:03:18 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://wellbeingtracker.meyouhealth.com\" rel=\"nofollow\">MeYou Health Well-Being Tracker</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "34727222527004672",
  "text" : "I scored 81 out of 100 on this Well-Being Tracker. Try it out! http://bit.ly/e9iWO1",
  "id" : 34727222527004672,
  "created_at" : "Mon Feb 07 21:36:29 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Megan Welling",
      "screen_name" : "MeganWelling",
      "indices" : [ 86, 99 ],
      "id_str" : "26166039",
      "id" : 26166039
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "34505309632335872",
  "text" : "8:36pm I was playing my new fave game Peggle while waiting for take out after a brief @meganwelling bday drive-by. http://flic.kr/p/9ghA4n",
  "id" : 34505309632335872,
  "created_at" : "Mon Feb 07 06:54:41 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "34435624861700096",
  "text" : "Is there `any way to get a report from Paypal for transaction totals broken down by item using their Website Payments program?",
  "id" : 34435624861700096,
  "created_at" : "Mon Feb 07 02:17:47 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.514333, -122.174667 ]
  },
  "id_str" : "34150969948241920",
  "text" : "8:36pm Buying plane tickets in the dark. This picture is from earlier today: a baby class reunion http://flic.kr/p/9fYMNM",
  "id" : 34150969948241920,
  "created_at" : "Sun Feb 06 07:26:40 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "i.am.donte",
      "screen_name" : "iamdonte",
      "indices" : [ 0, 9 ],
      "id_str" : "17977759",
      "id" : 17977759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "34118289282039808",
  "geo" : {
  },
  "id_str" : "34124817498112000",
  "in_reply_to_user_id" : 17977759,
  "text" : "@iamdonte Crap, no rooms are available anymore. :/",
  "id" : 34124817498112000,
  "in_reply_to_status_id" : 34118289282039808,
  "created_at" : "Sun Feb 06 05:42:45 +0000 2011",
  "in_reply_to_screen_name" : "iamdonte",
  "in_reply_to_user_id_str" : "17977759",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "i.am.donte",
      "screen_name" : "iamdonte",
      "indices" : [ 0, 9 ],
      "id_str" : "17977759",
      "id" : 17977759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "34118289282039808",
  "geo" : {
  },
  "id_str" : "34124055569240064",
  "in_reply_to_user_id" : 17977759,
  "text" : "@iamdonte Awesome, thanks for the tip. I'll check it out.",
  "id" : 34124055569240064,
  "in_reply_to_status_id" : 34118289282039808,
  "created_at" : "Sun Feb 06 05:39:43 +0000 2011",
  "in_reply_to_screen_name" : "iamdonte",
  "in_reply_to_user_id_str" : "17977759",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "josh",
      "screen_name" : "joshc",
      "indices" : [ 0, 6 ],
      "id_str" : "2015",
      "id" : 2015
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "34117472009330688",
  "geo" : {
  },
  "id_str" : "34123977056059392",
  "in_reply_to_user_id" : 2015,
  "text" : "@joshc Ooh, hadn't thought of that. Did you post, or just search listings?",
  "id" : 34123977056059392,
  "in_reply_to_status_id" : 34117472009330688,
  "created_at" : "Sun Feb 06 05:39:24 +0000 2011",
  "in_reply_to_screen_name" : "joshc",
  "in_reply_to_user_id_str" : "2015",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Rainert",
      "screen_name" : "arainert",
      "indices" : [ 0, 9 ],
      "id_str" : "7482",
      "id" : 7482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "34114703806566400",
  "geo" : {
  },
  "id_str" : "34123843987578880",
  "in_reply_to_user_id" : 7482,
  "text" : "@arainert Attempting to. Procrastination may get the better of us though. What about you?",
  "id" : 34123843987578880,
  "in_reply_to_status_id" : 34114703806566400,
  "created_at" : "Sun Feb 06 05:38:53 +0000 2011",
  "in_reply_to_screen_name" : "arainert",
  "in_reply_to_user_id_str" : "7482",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "elise o",
      "screen_name" : "elise81",
      "indices" : [ 0, 8 ],
      "id_str" : "14229651",
      "id" : 14229651
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "34113701745270784",
  "geo" : {
  },
  "id_str" : "34123742410055680",
  "in_reply_to_user_id" : 14229651,
  "text" : "@elise81 That's what I was hoping too. But it's pretty dismal even there too. Most of the remaining listings are already booked.",
  "id" : 34123742410055680,
  "in_reply_to_status_id" : 34113701745270784,
  "created_at" : "Sun Feb 06 05:38:28 +0000 2011",
  "in_reply_to_screen_name" : "elise81",
  "in_reply_to_user_id_str" : "14229651",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "34112302202486784",
  "text" : "I'm going to SXSW Interactive this year w/ family, but haven't booked a room yet. We are going to need a miracle here. Help?",
  "id" : 34112302202486784,
  "created_at" : "Sun Feb 06 04:53:01 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeffrey Keefer, PhD",
      "screen_name" : "JeffreyKeefer",
      "indices" : [ 0, 14 ],
      "id_str" : "815875",
      "id" : 815875
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "33983432329535488",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.61289232, -122.34792256 ]
  },
  "id_str" : "34068023979544576",
  "in_reply_to_user_id" : 815875,
  "text" : "@JeffreyKeefer That's Bree! One of my favorites.",
  "id" : 34068023979544576,
  "in_reply_to_status_id" : 33983432329535488,
  "created_at" : "Sun Feb 06 01:57:04 +0000 2011",
  "in_reply_to_screen_name" : "JeffreyKeefer",
  "in_reply_to_user_id_str" : "815875",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gwen Bell",
      "screen_name" : "gwenbell",
      "indices" : [ 0, 9 ],
      "id_str" : "1250104952",
      "id" : 1250104952
    }, {
      "name" : "Tanya Quick",
      "screen_name" : "aquicky",
      "indices" : [ 10, 18 ],
      "id_str" : "56687868",
      "id" : 56687868
    }, {
      "name" : "jenn cash",
      "screen_name" : "jenncash",
      "indices" : [ 19, 28 ],
      "id_str" : "21270963",
      "id" : 21270963
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.61290496, -122.3487702 ]
  },
  "id_str" : "33785849497788416",
  "text" : "@gwenbell @aquicky @jenncash Would love to hear more about this magical conversation!",
  "id" : 33785849497788416,
  "created_at" : "Sat Feb 05 07:15:48 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan McMinn",
      "screen_name" : "ryanmcminn",
      "indices" : [ 21, 32 ],
      "id_str" : "12061042",
      "id" : 12061042
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.615166, -122.315167 ]
  },
  "id_str" : "33764876643995648",
  "text" : "8:36pm Fun dinner at @ryanmcminn's with Carla http://flic.kr/p/9fH6bi",
  "id" : 33764876643995648,
  "created_at" : "Sat Feb 05 05:52:28 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "girl jo",
      "screen_name" : "octavekitten",
      "indices" : [ 0, 13 ],
      "id_str" : "16366882",
      "id" : 16366882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "33592929675120640",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.61431437, -122.34843242 ]
  },
  "id_str" : "33691532427005952",
  "in_reply_to_user_id" : 16366882,
  "text" : "@octavekitten Not too late at all!",
  "id" : 33691532427005952,
  "in_reply_to_status_id" : 33592929675120640,
  "created_at" : "Sat Feb 05 01:01:01 +0000 2011",
  "in_reply_to_screen_name" : "octavekitten",
  "in_reply_to_user_id_str" : "16366882",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ignite Seattle",
      "screen_name" : "ignitesea",
      "indices" : [ 12, 22 ],
      "id_str" : "3567281",
      "id" : 3567281
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gamification",
      "indices" : [ 35, 48 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 129 ],
      "url" : "http://t.co/PrnmCAj",
      "expanded_url" : "http://www.igniteseattle.com/2011/02/buster-benson-virtual-goods-can-improve-the-quality-of-your-real-life-experiences/",
      "display_url" : "igniteseattle.com/2011/02/buster\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "33672823624962049",
  "text" : "Video of my @ignitesea talk on how #gamification & badges can improve the quality of your life is now online! http://t.co/PrnmCAj",
  "id" : 33672823624962049,
  "created_at" : "Fri Feb 04 23:46:41 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 105 ],
      "url" : "http://t.co/f7ElU9n",
      "expanded_url" : "http://www.businessweek.com/magazine/content/11_07/b4215072350752.htm",
      "display_url" : "businessweek.com/magazine/conte\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "33669010767740928",
  "text" : "I admire Peter Theil's ability to take unpopular stances on technology and education: http://t.co/f7ElU9n",
  "id" : 33669010767740928,
  "created_at" : "Fri Feb 04 23:31:32 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BA Matthews (Fey)",
      "screen_name" : "BA_Matthews",
      "indices" : [ 0, 12 ],
      "id_str" : "176632772",
      "id" : 176632772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "33407408625684480",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6127333116, -122.347537231 ]
  },
  "id_str" : "33428365830529026",
  "in_reply_to_user_id" : 176632772,
  "text" : "@BA_Matthews I'm sorry! Can you explain the order of events? The site shouldn't have had any problems like this today.",
  "id" : 33428365830529026,
  "in_reply_to_status_id" : 33407408625684480,
  "created_at" : "Fri Feb 04 07:35:18 +0000 2011",
  "in_reply_to_screen_name" : "BA_Matthews",
  "in_reply_to_user_id_str" : "176632772",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "david reeves",
      "screen_name" : "dreeves",
      "indices" : [ 0, 8 ],
      "id_str" : "947851",
      "id" : 947851
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "33418680209506305",
  "geo" : {
  },
  "id_str" : "33426808678531072",
  "in_reply_to_user_id" : 947851,
  "text" : "@dreeves Got one, thanks!",
  "id" : 33426808678531072,
  "in_reply_to_status_id" : 33418680209506305,
  "created_at" : "Fri Feb 04 07:29:06 +0000 2011",
  "in_reply_to_screen_name" : "dreeves",
  "in_reply_to_user_id_str" : "947851",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Dean",
      "screen_name" : "sgdean",
      "indices" : [ 0, 7 ],
      "id_str" : "12065472",
      "id" : 12065472
    }, {
      "name" : "BJ Fogg",
      "screen_name" : "bjfogg",
      "indices" : [ 8, 15 ],
      "id_str" : "1118691",
      "id" : 1118691
    }, {
      "name" : "IFTTT",
      "screen_name" : "IFTTT",
      "indices" : [ 16, 22 ],
      "id_str" : "75079616",
      "id" : 75079616
    }, {
      "name" : "david reeves",
      "screen_name" : "dreeves",
      "indices" : [ 23, 31 ],
      "id_str" : "947851",
      "id" : 947851
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "32982428544929793",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6128284954, -122.3487335451 ]
  },
  "id_str" : "33417693096845312",
  "in_reply_to_user_id" : 12065472,
  "text" : "@sgdean @bjfogg @ifttt @dreeves Holy macaroni, I need an invite to this! How do I solve the if X then get an invite equation?",
  "id" : 33417693096845312,
  "in_reply_to_status_id" : 32982428544929793,
  "created_at" : "Fri Feb 04 06:52:53 +0000 2011",
  "in_reply_to_screen_name" : "sgdean",
  "in_reply_to_user_id_str" : "12065472",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jane McGonigal",
      "screen_name" : "avantgame",
      "indices" : [ 0, 10 ],
      "id_str" : "681813",
      "id" : 681813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "33388803183878144",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.614579545, -122.3467219633 ]
  },
  "id_str" : "33390017732677632",
  "in_reply_to_user_id" : 681813,
  "text" : "@avantgame And what was the other thing?",
  "id" : 33390017732677632,
  "in_reply_to_status_id" : 33388803183878144,
  "created_at" : "Fri Feb 04 05:02:55 +0000 2011",
  "in_reply_to_screen_name" : "avantgame",
  "in_reply_to_user_id_str" : "681813",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wedgwood",
      "screen_name" : "jwedgwood",
      "indices" : [ 0, 10 ],
      "id_str" : "5921812",
      "id" : 5921812
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "33387562907205632",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.61444864, -122.3466135 ]
  },
  "id_str" : "33389544128651264",
  "in_reply_to_user_id" : 5921812,
  "text" : "@jwedgwood I like that approach. Heroes in some way despite themselves, maybe? More interesting, in many respects.",
  "id" : 33389544128651264,
  "in_reply_to_status_id" : 33387562907205632,
  "created_at" : "Fri Feb 04 05:01:02 +0000 2011",
  "in_reply_to_screen_name" : "jwedgwood",
  "in_reply_to_user_id_str" : "5921812",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "33386673328889856",
  "text" : "Strange question: can heroes exist in a world with 100% transparency? How \"knowable\" are/were your heroes?",
  "id" : 33386673328889856,
  "created_at" : "Fri Feb 04 04:49:37 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6145, -122.346334 ]
  },
  "id_str" : "33383882267037696",
  "text" : "8:36pm Getting sick, sort of grumpy, trying to rally with some alone time at Tavolata http://flic.kr/p/9ftcGg",
  "id" : 33383882267037696,
  "created_at" : "Fri Feb 04 04:38:32 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "33292720004927488",
  "text" : "Twitter is great for offering the first clever thought in a long subtle debate over and over and over again.",
  "id" : 33292720004927488,
  "created_at" : "Thu Feb 03 22:36:17 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 0, 10 ],
      "id_str" : "7362142",
      "id" : 7362142
    }, {
      "name" : "Offbeat Mama",
      "screen_name" : "OffbeatMama",
      "indices" : [ 95, 107 ],
      "id_str" : "1093560211",
      "id" : 1093560211
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "33290120585019392",
  "geo" : {
  },
  "id_str" : "33292057892093952",
  "in_reply_to_user_id" : 7362142,
  "text" : "@kellianne Of course you like it. Nice inconspicuous pen name you chose for yourself, too! /cc @offbeatmama",
  "id" : 33292057892093952,
  "in_reply_to_status_id" : 33290120585019392,
  "created_at" : "Thu Feb 03 22:33:39 +0000 2011",
  "in_reply_to_screen_name" : "kellianne",
  "in_reply_to_user_id_str" : "7362142",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christine Brumback",
      "screen_name" : "Boomer",
      "indices" : [ 0, 7 ],
      "id_str" : "30693",
      "id" : 30693
    }, {
      "name" : "Tim Roberts",
      "screen_name" : "timroberts",
      "indices" : [ 8, 19 ],
      "id_str" : "23",
      "id" : 23
    }, {
      "name" : "Fitbit",
      "screen_name" : "fitbit",
      "indices" : [ 44, 51 ],
      "id_str" : "17424053",
      "id" : 17424053
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "33272332562726912",
  "in_reply_to_user_id" : 30693,
  "text" : "@Boomer @TimRoberts Congrats on getting the @fitbit mobile site out there. Looks great!",
  "id" : 33272332562726912,
  "created_at" : "Thu Feb 03 21:15:16 +0000 2011",
  "in_reply_to_screen_name" : "Boomer",
  "in_reply_to_user_id_str" : "30693",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt",
      "screen_name" : "theartar",
      "indices" : [ 0, 9 ],
      "id_str" : "16475119",
      "id" : 16475119
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "33245075924328448",
  "geo" : {
  },
  "id_str" : "33248488754126848",
  "in_reply_to_user_id" : 16475119,
  "text" : "@theartar Yes, a big update is coming soon!",
  "id" : 33248488754126848,
  "in_reply_to_status_id" : 33245075924328448,
  "created_at" : "Thu Feb 03 19:40:32 +0000 2011",
  "in_reply_to_screen_name" : "theartar",
  "in_reply_to_user_id_str" : "16475119",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Health Month",
      "screen_name" : "healthmonth",
      "indices" : [ 3, 15 ],
      "id_str" : "154236895",
      "id" : 154236895
    }, {
      "name" : "kottke.org",
      "screen_name" : "kottke",
      "indices" : [ 96, 103 ],
      "id_str" : "14120215",
      "id" : 14120215
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 90 ],
      "url" : "http://t.co/qLBC1ov",
      "expanded_url" : "http://thefuturewell.com/2011/02/02/most-health-solutions-arent-medical-theyre-social/",
      "display_url" : "thefuturewell.com/2011/02/02/mos\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "33233422763692032",
  "text" : "RT @healthmonth: Most health solutions aren't medical, they're social: http://t.co/qLBC1ov /thx @kottke",
  "retweeted_status" : {
    "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "kottke.org",
        "screen_name" : "kottke",
        "indices" : [ 79, 86 ],
        "id_str" : "14120215",
        "id" : 14120215
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 54, 73 ],
        "url" : "http://t.co/qLBC1ov",
        "expanded_url" : "http://thefuturewell.com/2011/02/02/most-health-solutions-arent-medical-theyre-social/",
        "display_url" : "thefuturewell.com/2011/02/02/mos\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "33233381114249216",
    "text" : "Most health solutions aren't medical, they're social: http://t.co/qLBC1ov /thx @kottke",
    "id" : 33233381114249216,
    "created_at" : "Thu Feb 03 18:40:30 +0000 2011",
    "user" : {
      "name" : "Health Month",
      "screen_name" : "healthmonth",
      "protected" : false,
      "id_str" : "154236895",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1136999397/track_meals.400_normal.png",
      "id" : 154236895,
      "verified" : false
    }
  },
  "id" : 33233422763692032,
  "created_at" : "Thu Feb 03 18:40:40 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sharon",
      "screen_name" : "sharon",
      "indices" : [ 0, 7 ],
      "id_str" : "260",
      "id" : 260
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "33215923016044544",
  "geo" : {
  },
  "id_str" : "33216234061299713",
  "in_reply_to_user_id" : 260,
  "text" : "@sharon Woah, thank you! I started looking online but saw lots of scams. I like the first one you sent, thank you!",
  "id" : 33216234061299713,
  "in_reply_to_status_id" : 33215923016044544,
  "created_at" : "Thu Feb 03 17:32:21 +0000 2011",
  "in_reply_to_screen_name" : "sharon",
  "in_reply_to_user_id_str" : "260",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "33205731104657408",
  "text" : "Does anyone have tips or suggestions for putting together a *very simple* month-to-month rental lease?",
  "id" : 33205731104657408,
  "created_at" : "Thu Feb 03 16:50:37 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.612612142, -122.347523996 ]
  },
  "id_str" : "33024702427435008",
  "text" : "@Iceworth Should be back now but we are working on performance issues for next week or so. Sorry for the slowness!",
  "id" : 33024702427435008,
  "created_at" : "Thu Feb 03 04:51:17 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.612666, -122.3475 ]
  },
  "id_str" : "33021746013536256",
  "text" : "8:36pm Just got home from dinner on the hill and some nice long walks http://flic.kr/p/9feLQ6",
  "id" : 33021746013536256,
  "created_at" : "Thu Feb 03 04:39:32 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryce Roberts",
      "screen_name" : "bryce",
      "indices" : [ 0, 6 ],
      "id_str" : "6160742",
      "id" : 6160742
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "32949237226409986",
  "geo" : {
  },
  "id_str" : "32951303730634754",
  "in_reply_to_user_id" : 6160742,
  "text" : "@bryce Game dynamics are tools, just like APIs, tags, app platforms, jQuery, etc. When used correctly, they shine. When not... not as much.",
  "id" : 32951303730634754,
  "in_reply_to_status_id" : 32949237226409986,
  "created_at" : "Wed Feb 02 23:59:37 +0000 2011",
  "in_reply_to_screen_name" : "bryce",
  "in_reply_to_user_id_str" : "6160742",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "32918579158458368",
  "text" : "The Game Always Wins.",
  "id" : 32918579158458368,
  "created_at" : "Wed Feb 02 21:49:35 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael McDaniel",
      "screen_name" : "michaelmcdaniel",
      "indices" : [ 0, 16 ],
      "id_str" : "7565162",
      "id" : 7565162
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "32661042223906817",
  "geo" : {
  },
  "id_str" : "32675224394661889",
  "in_reply_to_user_id" : 7565162,
  "text" : "@michaelmcdaniel Okay, try it again now... should let you edit again.",
  "id" : 32675224394661889,
  "in_reply_to_status_id" : 32661042223906817,
  "created_at" : "Wed Feb 02 05:42:35 +0000 2011",
  "in_reply_to_screen_name" : "michaelmcdaniel",
  "in_reply_to_user_id_str" : "7565162",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chrissie Brodigan",
      "screen_name" : "tenaciouscb",
      "indices" : [ 0, 12 ],
      "id_str" : "56831057",
      "id" : 56831057
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "32625506826326016",
  "geo" : {
  },
  "id_str" : "32625604952064000",
  "in_reply_to_user_id" : 56831057,
  "text" : "@tenaciouscb Ha. Best answer yet. :)",
  "id" : 32625604952064000,
  "in_reply_to_status_id" : 32625506826326016,
  "created_at" : "Wed Feb 02 02:25:25 +0000 2011",
  "in_reply_to_screen_name" : "tenaciouscb",
  "in_reply_to_user_id_str" : "56831057",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Vogel",
      "screen_name" : "dmv",
      "indices" : [ 0, 4 ],
      "id_str" : "6995452",
      "id" : 6995452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 81 ],
      "url" : "http://t.co/IIMJ91t",
      "expanded_url" : "http://healthmonth.com/teams/game/8",
      "display_url" : "healthmonth.com/teams/game/8"
    } ]
  },
  "geo" : {
  },
  "id_str" : "32624405829914626",
  "in_reply_to_user_id" : 6995452,
  "text" : "@dmv Did you figure it out yet? You can do it from this page: http://t.co/IIMJ91t",
  "id" : 32624405829914626,
  "created_at" : "Wed Feb 02 02:20:39 +0000 2011",
  "in_reply_to_screen_name" : "dmv",
  "in_reply_to_user_id_str" : "6995452",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "32621076852776960",
  "text" : "If someone stole all your passwords and you only had time to protect 1 account before the rest were stolen, which would you save?",
  "id" : 32621076852776960,
  "created_at" : "Wed Feb 02 02:07:25 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Forslund",
      "screen_name" : "adamforslund",
      "indices" : [ 0, 13 ],
      "id_str" : "17352252",
      "id" : 17352252
    }, {
      "name" : "Scott Neilson",
      "screen_name" : "TheCulprit",
      "indices" : [ 55, 66 ],
      "id_str" : "6726182",
      "id" : 6726182
    }, {
      "name" : "Chris Deal",
      "screen_name" : "crisdeal",
      "indices" : [ 67, 76 ],
      "id_str" : "135010674",
      "id" : 135010674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "32599030915665921",
  "geo" : {
  },
  "id_str" : "32616524850143233",
  "in_reply_to_user_id" : 17352252,
  "text" : "@adamforslund Fun is 90% toxing, and 10% detoxing. /cc @theculprit @crisdeal",
  "id" : 32616524850143233,
  "in_reply_to_status_id" : 32599030915665921,
  "created_at" : "Wed Feb 02 01:49:20 +0000 2011",
  "in_reply_to_screen_name" : "adamforslund",
  "in_reply_to_user_id_str" : "17352252",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BJ Fogg",
      "screen_name" : "bjfogg",
      "indices" : [ 0, 7 ],
      "id_str" : "1118691",
      "id" : 1118691
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "32607941211197440",
  "geo" : {
  },
  "id_str" : "32616319350214656",
  "in_reply_to_user_id" : 1118691,
  "text" : "@bjfogg Woah, just had a minor epiphany thanks to that tweet. Thank you!",
  "id" : 32616319350214656,
  "in_reply_to_status_id" : 32607941211197440,
  "created_at" : "Wed Feb 02 01:48:31 +0000 2011",
  "in_reply_to_screen_name" : "bjfogg",
  "in_reply_to_user_id_str" : "1118691",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Neilson",
      "screen_name" : "TheCulprit",
      "indices" : [ 0, 11 ],
      "id_str" : "6726182",
      "id" : 6726182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "32574216427540481",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6126229825, -122.3448305258 ]
  },
  "id_str" : "32578981312077824",
  "in_reply_to_user_id" : 6726182,
  "text" : "@TheCulprit Wow! Can health month buy some ad space on your back? :)",
  "id" : 32578981312077824,
  "in_reply_to_status_id" : 32574216427540481,
  "created_at" : "Tue Feb 01 23:20:09 +0000 2011",
  "in_reply_to_screen_name" : "TheCulprit",
  "in_reply_to_user_id_str" : "6726182",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Foursquare",
      "screen_name" : "foursquare",
      "indices" : [ 50, 61 ],
      "id_str" : "14120151",
      "id" : 14120151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "32535098670718976",
  "text" : "I just unlocked the \"Healthy Polar Bear\" badge on @foursquare! http://4sq.com/eUweBt",
  "id" : 32535098670718976,
  "created_at" : "Tue Feb 01 20:25:46 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lauren0",
      "screen_name" : "Lauren0",
      "indices" : [ 0, 8 ],
      "id_str" : "17688265",
      "id" : 17688265
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "32509589798785024",
  "geo" : {
  },
  "id_str" : "32509753716383744",
  "in_reply_to_user_id" : 17688265,
  "text" : "@Lauren0 Yes, go to Settings -&gt; Search and export and click on previous months to your heart's delight!",
  "id" : 32509753716383744,
  "in_reply_to_status_id" : 32509589798785024,
  "created_at" : "Tue Feb 01 18:45:03 +0000 2011",
  "in_reply_to_screen_name" : "Lauren0",
  "in_reply_to_user_id_str" : "17688265",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://cutcopy.heroku.com\" rel=\"nofollow\">Zonoscope</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "cut copy",
      "screen_name" : "cutcopy",
      "indices" : [ 59, 67 ],
      "id_str" : "52810109",
      "id" : 52810109
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Zonoscope",
      "indices" : [ 81, 91 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "32491539842211840",
  "text" : "Visit http://bit.ly/zonoscope to unlock the full stream of @CutCopy's new record #Zonoscope.",
  "id" : 32491539842211840,
  "created_at" : "Tue Feb 01 17:32:41 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Hagel",
      "screen_name" : "jhagel",
      "indices" : [ 3, 10 ],
      "id_str" : "14076943",
      "id" : 14076943
    }, {
      "name" : "David Weinberger",
      "screen_name" : "dweinberger",
      "indices" : [ 32, 44 ],
      "id_str" : "1285451",
      "id" : 1285451
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "32459217545723904",
  "text" : "RT @jhagel: Great reflection by @dweinberger - \"we are the medium\" http://bit.ly/fmFr5v",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "David Weinberger",
        "screen_name" : "dweinberger",
        "indices" : [ 20, 32 ],
        "id_str" : "1285451",
        "id" : 1285451
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "32393535718162432",
    "text" : "Great reflection by @dweinberger - \"we are the medium\" http://bit.ly/fmFr5v",
    "id" : 32393535718162432,
    "created_at" : "Tue Feb 01 11:03:15 +0000 2011",
    "user" : {
      "name" : "John Hagel",
      "screen_name" : "jhagel",
      "protected" : false,
      "id_str" : "14076943",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/60658775/Photos_John1_normal.jpg",
      "id" : 14076943,
      "verified" : false
    }
  },
  "id" : 32459217545723904,
  "created_at" : "Tue Feb 01 15:24:15 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
} ]