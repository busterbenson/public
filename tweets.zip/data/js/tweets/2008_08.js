Grailbird.data.tweets_2008_08 = 
 [ {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "905097273",
  "text" : "I am a dumbass.",
  "id" : 905097273,
  "created_at" : "Sun Aug 31 20:58:06 +0000 2008",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitterrific.com\" rel=\"nofollow\">Twitterrific</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "904562288",
  "text" : "8:36pm Katie and Rick bring a halo of awesomeness to my life. http://tinyurl.com/6xlo29",
  "id" : 904562288,
  "created_at" : "Sun Aug 31 04:37:06 +0000 2008",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "904243479",
  "text" : "Looking through pictures on Katie's camera realizing that it has been a drunken amazing week.",
  "id" : 904243479,
  "created_at" : "Sat Aug 30 20:12:37 +0000 2008",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "903714681",
  "text" : "How do you choose a favorite? Actually, my friends are my favorite. I",
  "id" : 903714681,
  "created_at" : "Sat Aug 30 04:55:51 +0000 2008",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitterrific.com\" rel=\"nofollow\">Twitterrific</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "903666726",
  "text" : "8:36pm People are arriving at Lucky Devil. It's gonna be a good night. http://tinyurl.com/5gp8ow",
  "id" : 903666726,
  "created_at" : "Sat Aug 30 03:39:47 +0000 2008",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitterrific.com\" rel=\"nofollow\">Twitterrific</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "903525283",
  "text" : "Deducted five points from my bachelor party crew for walking into Ross.  They have many ways to male points back tonight though.",
  "id" : 903525283,
  "created_at" : "Sat Aug 30 00:25:14 +0000 2008",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitterrific.com\" rel=\"nofollow\">Twitterrific</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "902621066",
  "text" : "8:36pm Late cause I was driving to Portland. Drinks at the Ace then ??? http://tinyurl.com/5myu9b",
  "id" : 902621066,
  "created_at" : "Fri Aug 29 06:46:46 +0000 2008",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitterrific.com\" rel=\"nofollow\">Twitterrific</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "901278172",
  "text" : "8:36pm Getting ready to head out for deliciousness at Elemental. http://tinyurl.com/6oercr",
  "id" : 901278172,
  "created_at" : "Thu Aug 28 03:41:44 +0000 2008",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitterrific.com\" rel=\"nofollow\">Twitterrific</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "900136176",
  "text" : "8:36pm Impromptu fancy night at Crow. http://tinyurl.com/6qkz8w",
  "id" : 900136176,
  "created_at" : "Wed Aug 27 04:25:31 +0000 2008",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.airme.com\" rel=\"nofollow\">AirMe</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "898947899",
  "text" : "8:36pm Catching up on speeches from the first day of the DNC. , http://airme.us/a6d509cc",
  "id" : 898947899,
  "created_at" : "Tue Aug 26 03:39:36 +0000 2008",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com/\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "898420058",
  "text" : "Holy mackerel, my iPhone app is in the iTunes store!  http://tinyurl.com/5f2klf",
  "id" : 898420058,
  "created_at" : "Mon Aug 25 17:30:02 +0000 2008",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "897915767",
  "text" : "Kellianne speaks only truth.",
  "id" : 897915767,
  "created_at" : "Mon Aug 25 05:30:22 +0000 2008",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "897915057",
  "text" : "I bow to all things Kellianne related. Seriously.",
  "id" : 897915057,
  "created_at" : "Mon Aug 25 05:29:08 +0000 2008",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitterrific.com\" rel=\"nofollow\">Twitterrific</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "897854666",
  "text" : "8:36pm British tea party plus fake mustaches plus lovely people. http://tinyurl.com/5hq77g",
  "id" : 897854666,
  "created_at" : "Mon Aug 25 03:46:02 +0000 2008",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitterrific.com\" rel=\"nofollow\">Twitterrific</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "897194294",
  "text" : "Somebody's drunk.",
  "id" : 897194294,
  "created_at" : "Sun Aug 24 09:27:23 +0000 2008",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitterrific.com\" rel=\"nofollow\">Twitterrific</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "897034320",
  "text" : "8:36pm Katie's apparently my secret groomsman.  Secret even from me. http://tinyurl.com/6zo6g8",
  "id" : 897034320,
  "created_at" : "Sun Aug 24 03:40:28 +0000 2008",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitterrific.com\" rel=\"nofollow\">Twitterrific</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "&y",
      "screen_name" : "andypixel",
      "indices" : [ 0, 10 ],
      "id_str" : "10015122",
      "id" : 10015122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "896200337",
  "geo" : {
  },
  "id_str" : "896215265",
  "in_reply_to_user_id" : 10015122,
  "text" : "@andypixel Go crazy at Burning Man first!",
  "id" : 896215265,
  "in_reply_to_status_id" : 896200337,
  "created_at" : "Sat Aug 23 04:00:20 +0000 2008",
  "in_reply_to_screen_name" : "andypixel",
  "in_reply_to_user_id_str" : "10015122",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitterrific.com\" rel=\"nofollow\">Twitterrific</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mario San Miguel",
      "screen_name" : "Mariosm",
      "indices" : [ 0, 8 ],
      "id_str" : "5800702",
      "id" : 5800702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "896204846",
  "geo" : {
  },
  "id_str" : "896214560",
  "in_reply_to_user_id" : 5800702,
  "text" : "@Mariosm Awesome! It's pretty amazing what you can do in the future, isn't it?",
  "id" : 896214560,
  "in_reply_to_status_id" : 896204846,
  "created_at" : "Sat Aug 23 03:59:23 +0000 2008",
  "in_reply_to_screen_name" : "Mariosm",
  "in_reply_to_user_id_str" : "5800702",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitterrific.com\" rel=\"nofollow\">Twitterrific</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "896213913",
  "text" : "8:36pm Cleaning the house and getting ready for Katie's 10-day visit!  http://tinyurl.com/6j65gq",
  "id" : 896213913,
  "created_at" : "Sat Aug 23 03:58:16 +0000 2008",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "896183971",
  "text" : "Do you use Simplify Media?  It's totally awesome and we should share music.  My username is bustermcleod.",
  "id" : 896183971,
  "created_at" : "Sat Aug 23 03:10:57 +0000 2008",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitterrific.com\" rel=\"nofollow\">Twitterrific</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "896067661",
  "text" : "The concept of a day off seems to have lost its meaning.",
  "id" : 896067661,
  "created_at" : "Sat Aug 23 00:18:45 +0000 2008",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitterrific.com\" rel=\"nofollow\">Twitterrific</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "894006960",
  "text" : "8:36pm Playing with Sopor til Kellianne comes home. http://tinyurl.com/5vecz6",
  "id" : 894006960,
  "created_at" : "Thu Aug 21 03:38:07 +0000 2008",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitterrific.com\" rel=\"nofollow\">Twitterrific</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "892878453",
  "text" : "8:36pm Talking lighting and conquering the world with fisticuffs at Tavolata. http://tinyurl.com/5p3ahq",
  "id" : 892878453,
  "created_at" : "Wed Aug 20 03:40:02 +0000 2008",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitterrific.com\" rel=\"nofollow\">Twitterrific</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "891772077",
  "text" : "8:36pm At a fashion show photo shoot for Chris and Ade http://tinyurl.com/6yhoas",
  "id" : 891772077,
  "created_at" : "Tue Aug 19 03:46:23 +0000 2008",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitterrific.com\" rel=\"nofollow\">Twitterrific</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "890711098",
  "text" : "8:36pm Kellianne looks out the window cause there was a loud noise. http://tinyurl.com/6ydeg4",
  "id" : 890711098,
  "created_at" : "Mon Aug 18 03:40:41 +0000 2008",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "890405684",
  "text" : "Kellianne's on the front page of the Sunday Seattle Times Arts section with an article about McLeod. Awesome!",
  "id" : 890405684,
  "created_at" : "Sun Aug 17 19:29:01 +0000 2008",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "889977841",
  "text" : "My first attempt at being a Seahawks fan went well! We won a dramatic game in overtime.  Might try again.",
  "id" : 889977841,
  "created_at" : "Sun Aug 17 05:11:09 +0000 2008",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitterrific.com\" rel=\"nofollow\">Twitterrific</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "889941500",
  "text" : "8:36pm Seahawks losing my first football game. But at least they're trying. http://tinyurl.com/5wzb3h",
  "id" : 889941500,
  "created_at" : "Sun Aug 17 04:03:15 +0000 2008",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitterrific.com\" rel=\"nofollow\">Twitterrific</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "889131362",
  "text" : "8:36pm Lazy BBQ sunset on the roof. http://tinyurl.com/6c49f8",
  "id" : 889131362,
  "created_at" : "Sat Aug 16 03:41:16 +0000 2008",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitterrific.com\" rel=\"nofollow\">Twitterrific</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "888115248",
  "text" : "8:36pm Generic aspirin for generic unwellness. I'm getting pissed. http://tinyurl.com/5db2l2",
  "id" : 888115248,
  "created_at" : "Fri Aug 15 03:42:12 +0000 2008",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com/\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "887987794",
  "text" : "I called \"Eric Benson\" on a phone left in our bathroom. It wasn't me, strangely, but he's helping return phone.  Should I mention anything?",
  "id" : 887987794,
  "created_at" : "Fri Aug 15 00:57:16 +0000 2008",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com/\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Croft",
      "screen_name" : "jcroft",
      "indices" : [ 0, 7 ],
      "id_str" : "25993",
      "id" : 25993
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "887946689",
  "geo" : {
  },
  "id_str" : "887950349",
  "in_reply_to_user_id" : 25993,
  "text" : "@jcroft It's the pool.  It's  2' deeper and wider than any other olympic pool.  And has magic drains on the side.",
  "id" : 887950349,
  "in_reply_to_status_id" : 887946689,
  "created_at" : "Fri Aug 15 00:06:49 +0000 2008",
  "in_reply_to_screen_name" : "jcroft",
  "in_reply_to_user_id_str" : "25993",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Cottrell",
      "screen_name" : "rgcottrell",
      "indices" : [ 0, 11 ],
      "id_str" : "752553",
      "id" : 752553
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "887679652",
  "geo" : {
  },
  "id_str" : "887682139",
  "in_reply_to_user_id" : 752553,
  "text" : "@rgcottrell Work is just to get you warmed up.  Twitter your progress throughout the day please.",
  "id" : 887682139,
  "in_reply_to_status_id" : 887679652,
  "created_at" : "Thu Aug 14 18:45:06 +0000 2008",
  "in_reply_to_screen_name" : "rgcottrell",
  "in_reply_to_user_id_str" : "752553",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com/\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrej Gregov",
      "screen_name" : "agregov",
      "indices" : [ 0, 8 ],
      "id_str" : "752413",
      "id" : 752413
    }, {
      "name" : "Robert Cottrell",
      "screen_name" : "rgcottrell",
      "indices" : [ 13, 24 ],
      "id_str" : "752553",
      "id" : 752553
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "887091405",
  "geo" : {
  },
  "id_str" : "887648276",
  "in_reply_to_user_id" : 752413,
  "text" : "@agregov and @rgcottrell Good luck with Hack Day today!",
  "id" : 887648276,
  "in_reply_to_status_id" : 887091405,
  "created_at" : "Thu Aug 14 18:07:46 +0000 2008",
  "in_reply_to_screen_name" : "agregov",
  "in_reply_to_user_id_str" : "752413",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitterrific.com\" rel=\"nofollow\">Twitterrific</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "887029033",
  "text" : "8:36pm Serious eaves-dropping and people-watching session at Wasabi just ended. http://tinyurl.com/5aneb7",
  "id" : 887029033,
  "created_at" : "Thu Aug 14 03:43:01 +0000 2008",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.airme.com\" rel=\"nofollow\">AirMe</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "885931488",
  "text" : "8:36pm Just got back from a date with KA at Tavolata. Now back home where I always am!, http://airme.us/a4745d62",
  "id" : 885931488,
  "created_at" : "Wed Aug 13 03:40:53 +0000 2008",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "885800076",
  "text" : "Just watched a seagull kill a pigeon then drop it in the middle of the street to be promptly run over by a bus. Not that pigeon's day I  ...",
  "id" : 885800076,
  "created_at" : "Wed Aug 13 01:08:58 +0000 2008",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "885799964",
  "text" : "Just watched a seagull kill a pigeon then drop it in the middle of the street to be promptly run over by a bus. Not that pigeon's day I  ...",
  "id" : 885799964,
  "created_at" : "Wed Aug 13 01:08:48 +0000 2008",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "884844758",
  "text" : "PS. Day old fresh rolls are grody to the max.",
  "id" : 884844758,
  "created_at" : "Tue Aug 12 03:45:26 +0000 2008",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.airme.com\" rel=\"nofollow\">AirMe</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "884843677",
  "text" : "8:36pm Eating the rest of the food delivered yesterday. Feeling 50% better finally. , http://airme.us/a443b5f2",
  "id" : 884843677,
  "created_at" : "Tue Aug 12 03:43:58 +0000 2008",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Petersen",
      "screen_name" : "joshp100",
      "indices" : [ 26, 35 ],
      "id_str" : "6299162",
      "id" : 6299162
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "884640885",
  "text" : "I offered Twitter-skeptic @joshp100 $10 off his $140 debt to me for every tweet he makes.  Could be the flu-medicine speaking.",
  "id" : 884640885,
  "created_at" : "Mon Aug 11 23:14:10 +0000 2008",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitterrific.com\" rel=\"nofollow\">Twitterrific</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "883789708",
  "text" : "8:36pm So sick I haven't been able to stand up other than to get water, answer door for delivery, or start new movie all day.",
  "id" : 883789708,
  "created_at" : "Mon Aug 11 03:45:29 +0000 2008",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitterrific.com\" rel=\"nofollow\">Twitterrific</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "883637118",
  "text" : "Apparently Barack's announcing his VP choice via text message. Text \"VP\" to 62262 to get added to the recipients.",
  "id" : 883637118,
  "created_at" : "Sun Aug 10 23:59:26 +0000 2008",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitterrific.com\" rel=\"nofollow\">Twitterrific</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "883512802",
  "text" : "Can you please recommend me a movie that's on iTunes rental or Hulu. If you don't stop me I'm gonna watch The Hottie and the Nottie.",
  "id" : 883512802,
  "created_at" : "Sun Aug 10 20:34:50 +0000 2008",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "883507254",
  "text" : "24 hour migraine and body aches starting to get old. NPR is repeating itself.",
  "id" : 883507254,
  "created_at" : "Sun Aug 10 20:25:39 +0000 2008",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitterrific.com\" rel=\"nofollow\">Twitterrific</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael McDaniel",
      "screen_name" : "michaelmcdaniel",
      "indices" : [ 0, 16 ],
      "id_str" : "7565162",
      "id" : 7565162
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "883328950",
  "geo" : {
  },
  "id_str" : "883401614",
  "in_reply_to_user_id" : 7565162,
  "text" : "@michaelmcdaniel But I just upgraded to the new iPhone after 1 year and got the discounted rate. Is it cause the first wasn't subsidized?",
  "id" : 883401614,
  "in_reply_to_status_id" : 883328950,
  "created_at" : "Sun Aug 10 17:32:16 +0000 2008",
  "in_reply_to_screen_name" : "michaelmcdaniel",
  "in_reply_to_user_id_str" : "7565162",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "882993685",
  "text" : "P.S. The new AirMe has replaced Mobile Fotos for the 8:36pm-compliant iPhone app of choice.",
  "id" : 882993685,
  "created_at" : "Sun Aug 10 03:43:02 +0000 2008",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.airme.com\" rel=\"nofollow\">AirMe</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "882992882",
  "text" : "8:36pm At Wasabi on a self-date trying to stave off flu symptoms with ankimo and sake. , http://airme.us/a3ca7273",
  "id" : 882992882,
  "created_at" : "Sun Aug 10 03:41:32 +0000 2008",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com/\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 0, 9 ],
      "id_str" : "761628",
      "id" : 761628
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "882813708",
  "geo" : {
  },
  "id_str" : "882814765",
  "in_reply_to_user_id" : 761628,
  "text" : "@RickWebb They just give you the whole thing each time.  But it is slowly growing.  Not that there's anything worth it in this update...",
  "id" : 882814765,
  "in_reply_to_status_id" : 882813708,
  "created_at" : "Sat Aug 09 22:33:27 +0000 2008",
  "in_reply_to_screen_name" : "RickWebb",
  "in_reply_to_user_id_str" : "761628",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com/\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "882781965",
  "text" : "Just submitted my Credit Card Roulette iPhone app to Apple.  Exciting!  Next app: a new more customizeable version of Morale-O-Meter.",
  "id" : 882781965,
  "created_at" : "Sat Aug 09 21:35:17 +0000 2008",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com/\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "882685525",
  "text" : "Can anyone find an illustration of one of those guns with a little surrender flag coming out of it?  Know what I'm talking about?",
  "id" : 882685525,
  "created_at" : "Sat Aug 09 18:48:42 +0000 2008",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.airme.com\" rel=\"nofollow\">AirMe</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "882212237",
  "text" : "8:36pm Ordering in some Bell Thai, working, and hanging with Sopor while KA's in Vegas, http://airme.us/a39f26b9",
  "id" : 882212237,
  "created_at" : "Sat Aug 09 03:41:13 +0000 2008",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Cottrell",
      "screen_name" : "rgcottrell",
      "indices" : [ 0, 11 ],
      "id_str" : "752553",
      "id" : 752553
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "882080119",
  "geo" : {
  },
  "id_str" : "882081418",
  "in_reply_to_user_id" : 752553,
  "text" : "@rgcottrell Yeah, I think that'll be a lot easier.  I'll submit it after I fix a couple bugs that seem to be crashing the app.  How's yours?",
  "id" : 882081418,
  "in_reply_to_status_id" : 882080119,
  "created_at" : "Sat Aug 09 00:32:50 +0000 2008",
  "in_reply_to_screen_name" : "rgcottrell",
  "in_reply_to_user_id_str" : "752553",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "882078630",
  "text" : "Holy shit, my iPhone app is actually on my phone and (mostly) working.  That was way too frustrating to figure out though.",
  "id" : 882078630,
  "created_at" : "Sat Aug 09 00:28:47 +0000 2008",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "881831949",
  "text" : "I just a free coffee for being Buddy, the guy that works at McLeod House. Awesome.",
  "id" : 881831949,
  "created_at" : "Fri Aug 08 19:11:56 +0000 2008",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitabit.com/\" rel=\"nofollow\">twitabit</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "881248661",
  "text" : "8:36pm Late because my phone broke. Unexpectedly at Triple Door with the Pixels for can can. http://bit.ly/4x5g1S",
  "id" : 881248661,
  "created_at" : "Fri Aug 08 07:21:05 +0000 2008",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "881044901",
  "text" : "Has anyone built a service that sends out Twitter direct messages to my Twitter friends who are within a certain geographic region?",
  "id" : 881044901,
  "created_at" : "Fri Aug 08 02:08:09 +0000 2008",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "881017199",
  "text" : "Also, I like that Marc Johns says this on his bio page: \"Finding the humor in things often leads to finding the truth.\"",
  "id" : 881017199,
  "created_at" : "Fri Aug 08 01:32:42 +0000 2008",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "881016909",
  "text" : "Just bought a watercolor painting by Marc John.  Guess which one!",
  "id" : 881016909,
  "created_at" : "Fri Aug 08 01:32:19 +0000 2008",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "880937936",
  "text" : "They gave me a new iPhone. Now on my 5th.",
  "id" : 880937936,
  "created_at" : "Thu Aug 07 23:47:38 +0000 2008",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "880875335",
  "text" : "Crap... I broke my iPhone again.  Not physically this time, just emotionally.  Guess I gotta go to the Apple Store!",
  "id" : 880875335,
  "created_at" : "Thu Aug 07 22:25:47 +0000 2008",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitabit.com/\" rel=\"nofollow\">twitabit</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "880029248",
  "text" : "8:36pm At Virginia Inn with Andrew! http://bit.ly/12AwLZ",
  "id" : 880029248,
  "created_at" : "Thu Aug 07 03:50:28 +0000 2008",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "879535019",
  "text" : "Take three on trying to get my iPhone app to build on my phone using the difficult to understand developer program certificates.",
  "id" : 879535019,
  "created_at" : "Wed Aug 06 17:33:33 +0000 2008",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitabit.com/\" rel=\"nofollow\">twitabit</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "878979639",
  "text" : "8:36pm Reading the first few pages of Murakami's memoir before sushi at Saito's with Chris, his friend, and KA http://bit.ly/19R5RB",
  "id" : 878979639,
  "created_at" : "Wed Aug 06 04:06:36 +0000 2008",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitabit.com/\" rel=\"nofollow\">twitabit</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "877911394",
  "text" : "8:36pm With Chris at The Saint http://bit.ly/321ggl",
  "id" : 877911394,
  "created_at" : "Tue Aug 05 04:02:36 +0000 2008",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitabit.com/\" rel=\"nofollow\">twitabit</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "876886712",
  "text" : "8:36pm About to watch an outdoor movie for Movie Club at Jana's house http://bit.ly/36FkPQ",
  "id" : 876886712,
  "created_at" : "Mon Aug 04 03:55:55 +0000 2008",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitterrific.com\" rel=\"nofollow\">Twitterrific</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrej Gregov",
      "screen_name" : "agregov",
      "indices" : [ 0, 8 ],
      "id_str" : "752413",
      "id" : 752413
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "876491723",
  "geo" : {
  },
  "id_str" : "876535745",
  "in_reply_to_user_id" : 752413,
  "text" : "@agregov The mobile duo is spinning up? Maybe we should collaborate! I'm about halfway done with a practice app myself.",
  "id" : 876535745,
  "in_reply_to_status_id" : 876491723,
  "created_at" : "Sun Aug 03 18:14:27 +0000 2008",
  "in_reply_to_screen_name" : "agregov",
  "in_reply_to_user_id_str" : "752413",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitterrific.com\" rel=\"nofollow\">Twitterrific</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "876219971",
  "text" : "Where am I, Twitter? (reverse Dodgeball)",
  "id" : 876219971,
  "created_at" : "Sun Aug 03 07:25:53 +0000 2008",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitabit.com/\" rel=\"nofollow\">twitabit</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "876120056",
  "text" : "8:36pm Talking about houseboats with the Madsens with lovely food and wine http://bit.ly/9pfyC",
  "id" : 876120056,
  "created_at" : "Sun Aug 03 03:48:01 +0000 2008",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitterrific.com\" rel=\"nofollow\">Twitterrific</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Cottrell",
      "screen_name" : "rgcottrell",
      "indices" : [ 0, 11 ],
      "id_str" : "752553",
      "id" : 752553
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "875849202",
  "geo" : {
  },
  "id_str" : "875851197",
  "in_reply_to_user_id" : 752553,
  "text" : "@rgcottrell Are yoy building a paypal iPhone app? And have you seen entropydb?",
  "id" : 875851197,
  "in_reply_to_status_id" : 875849202,
  "created_at" : "Sat Aug 02 19:54:28 +0000 2008",
  "in_reply_to_screen_name" : "rgcottrell",
  "in_reply_to_user_id_str" : "752553",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitabit.com/\" rel=\"nofollow\">twitabit</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "875355886",
  "text" : "8:36pm Just finished a photo shoot for the Seattle Times, now I need a drink! http://bit.ly/3VCLXR",
  "id" : 875355886,
  "created_at" : "Sat Aug 02 03:46:01 +0000 2008",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "875295140",
  "text" : "I love finding a bottle of Prosecco in the fridge when you aren't expecting it to be there.  It's the new dollar in washed pants!",
  "id" : 875295140,
  "created_at" : "Sat Aug 02 02:07:44 +0000 2008",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "874941255",
  "text" : "Just got mistaken for a cute girl's potential online date, who seems to be standing her up. Come on guys!",
  "id" : 874941255,
  "created_at" : "Fri Aug 01 18:01:28 +0000 2008",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
} ]