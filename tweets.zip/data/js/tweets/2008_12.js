Grailbird.data.tweets_2008_12 = 
 [ {
  "source" : "<a href=\"http://twitter.com/tweetsville\" rel=\"nofollow\">Tweetsville</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Harrison",
      "screen_name" : "sourjayne",
      "indices" : [ 0, 10 ],
      "id_str" : "4981271",
      "id" : 4981271
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1089363803",
  "geo" : { },
  "id_str" : "1089402658",
  "in_reply_to_user_id" : 4981271,
  "text" : "@sourjayne The red one!",
  "id" : 1089402658,
  "in_reply_to_status_id" : 1089363803,
  "created_at" : "2009-01-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "sourjayne",
  "in_reply_to_user_id_str" : "4981271",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://m.twitter.com/\" rel=\"nofollow\">mobile web</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1089420539",
  "text" : "8:36pm Just got to Erin's for pre-funk before Lo-Fi NYE!!!: http://tinyurl.com/9wdfbw",
  "id" : 1089420539,
  "created_at" : "2009-01-01 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1089708504",
  "text" : "I definitely grabbed this bottle of champagne within legality. Haappiieesstt and nneewweesstt of all years friends!",
  "id" : 1089708504,
  "created_at" : "2009-01-01 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetsville\" rel=\"nofollow\">Tweetsville</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1089723060",
  "text" : "My wife disappeared. But I have a full bottle of champagne. Net negative but optimistic. http://twitpic.com/ymsn",
  "id" : 1089723060,
  "created_at" : "2009-01-01 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetsville\" rel=\"nofollow\">Tweetsville</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 0, 10 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1089724357",
  "geo" : { },
  "id_str" : "1089725235",
  "in_reply_to_user_id" : 7362142,
  "text" : "@kellianne Eddie Belle???????????????",
  "id" : 1089725235,
  "in_reply_to_status_id" : 1089724357,
  "created_at" : "2009-01-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "kellianne",
  "in_reply_to_user_id_str" : "7362142",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetsville\" rel=\"nofollow\">Tweetsville</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sugar la Vie",
      "screen_name" : "bornbombshell",
      "indices" : [ 0, 14 ],
      "id_str" : "88142758",
      "id" : 88142758
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1089729676",
  "geo" : { },
  "id_str" : "1089734834",
  "in_reply_to_user_id" : 18446581,
  "text" : "@bornbombshell I would rather hit on twins named Monologue and Peripatetica.",
  "id" : 1089734834,
  "in_reply_to_status_id" : 1089729676,
  "created_at" : "2009-01-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "sugarlavie",
  "in_reply_to_user_id_str" : "18446581",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1089769591",
  "text" : "Where are you? Twitter your location!",
  "id" : 1089769591,
  "created_at" : "2009-01-01 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetsville\" rel=\"nofollow\">Tweetsville</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1089809786",
  "text" : "Suddenly I'm home. Howd that happen! Merry birthday to y'all and your brethren and your sistren!",
  "id" : 1089809786,
  "created_at" : "2009-01-01 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetsville\" rel=\"nofollow\">Tweetsville</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russell Dicker",
      "screen_name" : "rdicker",
      "indices" : [ 0, 8 ],
      "id_str" : "958581",
      "id" : 958581
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1089762350",
  "geo" : { },
  "id_str" : "1089814273",
  "in_reply_to_user_id" : 958581,
  "text" : "@rdicker merry newest of all years to you and Leafy!",
  "id" : 1089814273,
  "in_reply_to_status_id" : 1089762350,
  "created_at" : "2009-01-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "rdicker",
  "in_reply_to_user_id_str" : "958581",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://m.twitter.com/\" rel=\"nofollow\">mobile web</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1087363729",
  "text" : "8:36pm My grumpy wife is cheering up at the Black Bottle: http://tinyurl.com/97qmhf",
  "id" : 1087363729,
  "created_at" : "2008-12-31 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetsville\" rel=\"nofollow\">Tweetsville</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1087440494",
  "text" : "Just bought my first order using Amazon's iPhone app. Way cool!",
  "id" : 1087440494,
  "created_at" : "2008-12-31 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetsville\" rel=\"nofollow\">Tweetsville</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1088453557",
  "text" : "Last eggnog latte of the season. :( :( :(",
  "id" : 1088453557,
  "created_at" : "2008-12-31 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://m.twitter.com/\" rel=\"nofollow\">mobile web</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1085329611",
  "text" : "Apple bread pudding: before: http://tinyurl.com/7ckhnh",
  "id" : 1085329611,
  "created_at" : "2008-12-30 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kindrameyer",
      "screen_name" : "kindrameyer",
      "indices" : [ 0, 12 ],
      "id_str" : "16400277",
      "id" : 16400277
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1085219195",
  "geo" : { },
  "id_str" : "1085337127",
  "in_reply_to_user_id" : 16400277,
  "text" : "@kindrameyer Let's see those lists and manifestos already!",
  "id" : 1085337127,
  "in_reply_to_status_id" : 1085219195,
  "created_at" : "2008-12-30 00:00:00 +0000",
  "in_reply_to_screen_name" : "kindrameyer",
  "in_reply_to_user_id_str" : "16400277",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Tomorrow",
      "screen_name" : "ryantomorrow",
      "indices" : [ 126, 139 ],
      "id_str" : "14679007",
      "id" : 14679007
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1085381226",
  "text" : "In all my twitters, I've only used 1996 unique words, none of which are that interesting. http://mytwitterweighsaton.com (via @ryantomorrow)",
  "id" : 1085381226,
  "created_at" : "2008-12-30 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 16, 26 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1085553709",
  "text" : "I can't believe @Kellianne can't stay awake during The Usual Suspects, which she has never seen!",
  "id" : 1085553709,
  "created_at" : "2008-12-30 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetsville\" rel=\"nofollow\">Tweetsville</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Fried",
      "screen_name" : "jasonfried",
      "indices" : [ 3, 14 ],
      "id_str" : "14372143",
      "id" : 14372143
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1086167496",
  "text" : "RT @jasonfried: Ebert isn't optimistic: http://bit.ly/BQ01",
  "id" : 1086167496,
  "created_at" : "2008-12-30 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com/\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1086532309",
  "text" : "Blagojevich is cracking me up.",
  "id" : 1086532309,
  "created_at" : "2008-12-30 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com/\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kindrameyer",
      "screen_name" : "kindrameyer",
      "indices" : [ 0, 12 ],
      "id_str" : "16400277",
      "id" : 16400277
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1086833376",
  "geo" : { },
  "id_str" : "1086838536",
  "in_reply_to_user_id" : 16400277,
  "text" : "@kindrameyer I've actually been to that.  In costume.",
  "id" : 1086838536,
  "in_reply_to_status_id" : 1086833376,
  "created_at" : "2008-12-30 00:00:00 +0000",
  "in_reply_to_screen_name" : "kindrameyer",
  "in_reply_to_user_id_str" : "16400277",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://m.twitter.com/\" rel=\"nofollow\">mobile web</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1083410530",
  "text" : "8:36pm This Christmas-ish gl\u00F6gg is strong, and friends are great!: http://tinyurl.com/8ayx94",
  "id" : 1083410530,
  "created_at" : "2008-12-29 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com/\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1084658148",
  "text" : "Bacon makes everything better. http://bit.ly/T0SH",
  "id" : 1084658148,
  "created_at" : "2008-12-29 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1084760607",
  "text" : "Opening a new project up in Xcode for a new iPhone app project at work.",
  "id" : 1084760607,
  "created_at" : "2008-12-29 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitterrific.com\" rel=\"nofollow\">Twitterrific</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1081840785",
  "text" : "8:36pm Talk about American Cultural Rebels at the Jewelbox: http://tinyurl.com/7ml5er",
  "id" : 1081840785,
  "created_at" : "2008-12-28 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1081999974",
  "text" : "Is there any proof or disagreement that, in general, the third track on an album is the best one?  Best in terms of biggest hit, perhaps.",
  "id" : 1081999974,
  "created_at" : "2008-12-28 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1082964785",
  "text" : "Christmas-ish party at our place starting around 5 or 6 tonight.  Come by if you are lolly-gaggin' about. Delicious spiced gl\u00F6gg awaits.",
  "id" : 1082964785,
  "created_at" : "2008-12-28 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitterrific.com\" rel=\"nofollow\">Twitterrific</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1080367638",
  "text" : "8:36pm Wine, m&ms, and reverse holiday programming with Doubt at the Big Picture: http://tinyurl.com/9gotms",
  "id" : 1080367638,
  "created_at" : "2008-12-27 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetsville\" rel=\"nofollow\">Tweetsville</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alicetiara",
      "screen_name" : "alicetiara",
      "indices" : [ 0, 11 ],
      "id_str" : "784078",
      "id" : 784078
    }, {
      "name" : "&y",
      "screen_name" : "andypixel",
      "indices" : [ 27, 37 ],
      "id_str" : "10015122",
      "id" : 10015122
    }, {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 57, 67 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1080375686",
  "geo" : { },
  "id_str" : "1080532240",
  "in_reply_to_user_id" : 784078,
  "text" : "@alicetiara I've only beat @andypixel twice but can beat @kellianne 2/3 times. Middle of the road!",
  "id" : 1080532240,
  "in_reply_to_status_id" : 1080375686,
  "created_at" : "2008-12-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "alicetiara",
  "in_reply_to_user_id_str" : "784078",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetsville\" rel=\"nofollow\">Tweetsville</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 0, 10 ],
      "id_str" : "7362142",
      "id" : 7362142
    }, {
      "name" : "&y",
      "screen_name" : "andypixel",
      "indices" : [ 26, 36 ],
      "id_str" : "10015122",
      "id" : 10015122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1080533295",
  "geo" : { },
  "id_str" : "1080543426",
  "in_reply_to_user_id" : 7362142,
  "text" : "@kellianne Okay just beat @andypixel again. A Christmas miracle!",
  "id" : 1080543426,
  "in_reply_to_status_id" : 1080533295,
  "created_at" : "2008-12-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "kellianne",
  "in_reply_to_user_id_str" : "7362142",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1081425077",
  "text" : "Made my 2009 resolutions: http://bustermcleod.livejournal.com/225739.html",
  "id" : 1081425077,
  "created_at" : "2008-12-27 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://m.twitter.com/\" rel=\"nofollow\">mobile web</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1077492188",
  "text" : "8:36pm Advertisements for procreation at the Wurl house.: http://tinyurl.com/9ppouf",
  "id" : 1077492188,
  "created_at" : "2008-12-25 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kindrameyer",
      "screen_name" : "kindrameyer",
      "indices" : [ 0, 12 ],
      "id_str" : "16400277",
      "id" : 16400277
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1075503218",
  "geo" : { },
  "id_str" : "1075505770",
  "in_reply_to_user_id" : 16400277,
  "text" : "@kindrameyer I know my limits! And I have no problem passing them. I love you too and happy travels!",
  "id" : 1075505770,
  "in_reply_to_status_id" : 1075503218,
  "created_at" : "2008-12-24 00:00:00 +0000",
  "in_reply_to_screen_name" : "kindrameyer",
  "in_reply_to_user_id_str" : "16400277",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://m.twitter.com/\" rel=\"nofollow\">mobile web</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1075715182",
  "text" : "8:36pm Hour 3.5 at Triple Door before burlesque nutcracker in 1.5 hours.: http://tinyurl.com/8vetew",
  "id" : 1075715182,
  "created_at" : "2008-12-24 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1077120107",
  "text" : "The tip of Kellianne's plane just crossed into Google Oregon.",
  "id" : 1077120107,
  "created_at" : "2008-12-24 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kindrameyer",
      "screen_name" : "kindrameyer",
      "indices" : [ 10, 22 ],
      "id_str" : "16400277",
      "id" : 16400277
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1075477034",
  "text" : "Thank you @KindraMeyer for the thoughtful gift of burlesque nutcracker! I'm here 4 hours early in anticipation!!!",
  "id" : 1075477034,
  "created_at" : "2008-12-24 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1075482153",
  "text" : "Okay, maybe it's cause I got the time wrong, but I AM very excited. And rallied some troops to join!",
  "id" : 1075482153,
  "created_at" : "2008-12-24 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1073482522",
  "text" : "Falling on the ice holding grocery bags, wrapping paper and a giant coffee totally cheered me up!",
  "id" : 1073482522,
  "created_at" : "2008-12-23 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1073605343",
  "text" : "Gonna try walking to Capitol Hill for drinks with Carinba. Anyone else wanna join?",
  "id" : 1073605343,
  "created_at" : "2008-12-23 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1073645894",
  "text" : "That was easy. (hits the button)",
  "id" : 1073645894,
  "created_at" : "2008-12-23 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://m.twitter.com/\" rel=\"nofollow\">mobile web</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1073711770",
  "text" : "8:36pm At Linda's with Carinna!: http://tinyurl.com/6w7mxt",
  "id" : 1073711770,
  "created_at" : "2008-12-23 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetsville\" rel=\"nofollow\">Tweetsville</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 0, 9 ],
      "id_str" : "761628",
      "id" : 761628
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1074039114",
  "geo" : { },
  "id_str" : "1074529474",
  "in_reply_to_user_id" : 761628,
  "text" : "@RickWebb Yeah but they're all dumbasses!",
  "id" : 1074529474,
  "in_reply_to_status_id" : 1074039114,
  "created_at" : "2008-12-23 00:00:00 +0000",
  "in_reply_to_screen_name" : "RickWebb",
  "in_reply_to_user_id_str" : "761628",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1071515973",
  "text" : "I love our yearly tradition of arguing about what's healthy for a month.",
  "id" : 1071515973,
  "created_at" : "2008-12-22 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://m.twitter.com/\" rel=\"nofollow\">mobile web</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1071690447",
  "text" : "8:36pm It's friends in Belltown snowy dinner part 2! With autumn backdrop. http://tinyurl.com/866zrv",
  "id" : 1071690447,
  "created_at" : "2008-12-22 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ali Berman",
      "screen_name" : "spangley",
      "indices" : [ 0, 9 ],
      "id_str" : "776429",
      "id" : 776429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1069721620",
  "geo" : { },
  "id_str" : "1069736730",
  "in_reply_to_user_id" : 776429,
  "text" : "@spangley Of course you're in it.  Actually, I gotta add your hobo Chris Jones to the best memories too.  Now I'm tagging LJ posts...",
  "id" : 1069736730,
  "in_reply_to_status_id" : 1069721620,
  "created_at" : "2008-12-21 00:00:00 +0000",
  "in_reply_to_screen_name" : "spangley",
  "in_reply_to_user_id_str" : "776429",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 0, 10 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1069782078",
  "geo" : { },
  "id_str" : "1069786838",
  "in_reply_to_user_id" : 7362142,
  "text" : "@kellianne That sounds like just the thing.",
  "id" : 1069786838,
  "in_reply_to_status_id" : 1069782078,
  "created_at" : "2008-12-21 00:00:00 +0000",
  "in_reply_to_screen_name" : "kellianne",
  "in_reply_to_user_id_str" : "7362142",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1069895299",
  "text" : "Snowed in activities part 2: A few blog posts from the last year that I can bear re-reading: http://bit.ly/faveentries2008",
  "id" : 1069895299,
  "created_at" : "2008-12-21 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://m.twitter.com/\" rel=\"nofollow\">mobile web</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1070066575",
  "text" : "8:36pm Snow day at the Dickers playing wii bowling. http://tinyurl.com/8dhzzm",
  "id" : 1070066575,
  "created_at" : "2008-12-21 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1070117276",
  "text" : "This beginner just beat the Dickers at bowling. And I'm even past my drinking/bowling optimum ratio. Bitches.",
  "id" : 1070117276,
  "created_at" : "2008-12-21 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1070172466",
  "text" : "People are snowboarding down Cedar outside Russell and Lia's window. I town him to run. We're impatient.",
  "id" : 1070172466,
  "created_at" : "2008-12-21 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "senoraj",
      "screen_name" : "senoraj",
      "indices" : [ 0, 8 ],
      "id_str" : "13443292",
      "id" : 13443292
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1070248294",
  "geo" : { },
  "id_str" : "1070249587",
  "in_reply_to_user_id" : 13443292,
  "text" : "@senoraj Yes, Lia is trying to make us drunkdial old managers. Were you an old manager???",
  "id" : 1070249587,
  "in_reply_to_status_id" : 1070248294,
  "created_at" : "2008-12-21 00:00:00 +0000",
  "in_reply_to_screen_name" : "senoraj",
  "in_reply_to_user_id_str" : "13443292",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "senoraj",
      "screen_name" : "senoraj",
      "indices" : [ 0, 8 ],
      "id_str" : "13443292",
      "id" : 13443292
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1070252445",
  "geo" : { },
  "id_str" : "1070263597",
  "in_reply_to_user_id" : 13443292,
  "text" : "@senoraj Russell says no dice if consequences exist.",
  "id" : 1070263597,
  "in_reply_to_status_id" : 1070252445,
  "created_at" : "2008-12-21 00:00:00 +0000",
  "in_reply_to_screen_name" : "senoraj",
  "in_reply_to_user_id_str" : "13443292",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetsville\" rel=\"nofollow\">Tweetsville</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1070355019",
  "text" : "I made it home! But not without a wrong turn and a couple drunkles dials.",
  "id" : 1070355019,
  "created_at" : "2008-12-21 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1071293695",
  "text" : "Starting to think about Health Month 2009: http://bustermcleod.livejournal.com/224322.html",
  "id" : 1071293695,
  "created_at" : "2008-12-21 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitterrific.com\" rel=\"nofollow\">Twitterrific</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1068521254",
  "text" : "8:36pm Watching Idiocracy, feeling a little idiotic myself... http://tinyurl.com/7beh3c",
  "id" : 1068521254,
  "created_at" : "2008-12-20 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetsville\" rel=\"nofollow\">Tweetsville</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1068560533",
  "text" : "The plum-colored possum fur nipple warmers that we ordered the other night (because they exist) arrived. Soft! http://twitpic.com/uh3u",
  "id" : 1068560533,
  "created_at" : "2008-12-20 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ingopixel",
      "screen_name" : "ingopixel",
      "indices" : [ 0, 10 ],
      "id_str" : "7943892",
      "id" : 7943892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1068561866",
  "geo" : { },
  "id_str" : "1068563676",
  "in_reply_to_user_id" : 7943892,
  "text" : "@ingopixel The cheery holiday font on the label calls them nipple warmers. Case closed.",
  "id" : 1068563676,
  "in_reply_to_status_id" : 1068561866,
  "created_at" : "2008-12-20 00:00:00 +0000",
  "in_reply_to_screen_name" : "ingopixel",
  "in_reply_to_user_id_str" : "7943892",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ingopixel",
      "screen_name" : "ingopixel",
      "indices" : [ 0, 10 ],
      "id_str" : "7943892",
      "id" : 7943892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1068564188",
  "geo" : { },
  "id_str" : "1068565971",
  "in_reply_to_user_id" : 7943892,
  "text" : "@ingopixel So of all places, this is where you draw the line? :) Blame Andreas, it's all his fault.",
  "id" : 1068565971,
  "in_reply_to_status_id" : 1068564188,
  "created_at" : "2008-12-20 00:00:00 +0000",
  "in_reply_to_screen_name" : "ingopixel",
  "in_reply_to_user_id_str" : "7943892",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1068607217",
  "text" : "Nerdily excited about the new mint.com iPhone app.  Rather than go out, I'm going to make my first monthly budget since college.  Any tips?",
  "id" : 1068607217,
  "created_at" : "2008-12-20 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "&y",
      "screen_name" : "andypixel",
      "indices" : [ 0, 10 ],
      "id_str" : "10015122",
      "id" : 10015122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1068614113",
  "geo" : { },
  "id_str" : "1068616288",
  "in_reply_to_user_id" : 10015122,
  "text" : "@andypixel What constitutes entertainment to you?  Food and drink are my primary sources of entertainment. 22% of my money spent apparently.",
  "id" : 1068616288,
  "in_reply_to_status_id" : 1068614113,
  "created_at" : "2008-12-20 00:00:00 +0000",
  "in_reply_to_screen_name" : "andypixel",
  "in_reply_to_user_id_str" : "10015122",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1068624676",
  "text" : "Crap... once you see it broken down and everything, you realize where all the money goes.  $16 on Sopor this month?  We'll be homeless soon.",
  "id" : 1068624676,
  "created_at" : "2008-12-20 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chadwick Dahlquist",
      "screen_name" : "bugeats",
      "indices" : [ 0, 8 ],
      "id_str" : "9074342",
      "id" : 9074342
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1068636478",
  "geo" : { },
  "id_str" : "1068641481",
  "in_reply_to_user_id" : 9074342,
  "text" : "@bugeats Sopor's my cat.  I like her a lot, but *$16*?",
  "id" : 1068641481,
  "in_reply_to_status_id" : 1068636478,
  "created_at" : "2008-12-20 00:00:00 +0000",
  "in_reply_to_screen_name" : "bugeats",
  "in_reply_to_user_id_str" : "9074342",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1068647956",
  "text" : "First goal of the budget: spend less than I make.  A novel idea! I didn't do that a single month in 2008.",
  "id" : 1068647956,
  "created_at" : "2008-12-20 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1068706329",
  "text" : "Mint.com now has access to my 2 checking accts, 2 savings accts, 2 ccs, 1 mortgage, 1 equity loan, 401K, Roth IRA, and all stocks. Pretty!",
  "id" : 1068706329,
  "created_at" : "2008-12-20 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1069595750",
  "text" : "Just went shoe-ice-skating to the store.  Spaghetti, wine, cheese, and coffee should keep me fat through the storm.",
  "id" : 1069595750,
  "created_at" : "2008-12-20 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 0, 10 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1069597502",
  "geo" : { },
  "id_str" : "1069602186",
  "in_reply_to_user_id" : 7362142,
  "text" : "@kellianne Yeah, looks like 3-8\" tonight plus lots of wind.  I hope the planes will be fine by tomorrow night.  This tree depends on it!",
  "id" : 1069602186,
  "in_reply_to_status_id" : 1069597502,
  "created_at" : "2008-12-20 00:00:00 +0000",
  "in_reply_to_screen_name" : "kellianne",
  "in_reply_to_user_id_str" : "7362142",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "laurelfan",
      "screen_name" : "laurelfan",
      "indices" : [ 3, 13 ],
      "id_str" : "8046402",
      "id" : 8046402
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1069687803",
  "geo" : { },
  "id_str" : "1069688713",
  "in_reply_to_user_id" : 8046402,
  "text" : "RT @laurelfan * * * * * &lt;- snow",
  "id" : 1069688713,
  "in_reply_to_status_id" : 1069687803,
  "created_at" : "2008-12-20 00:00:00 +0000",
  "in_reply_to_screen_name" : "laurelfan",
  "in_reply_to_user_id_str" : "8046402",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1069709871",
  "text" : "I'm gonna use this inconvenient storm as an chance to think about 2008, starting with some favorite moments: http://bit.ly/bestof2008 Yours?",
  "id" : 1069709871,
  "created_at" : "2008-12-20 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://m.twitter.com/\" rel=\"nofollow\">mobile web</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1066544563",
  "text" : "8:36pm Not really doing anything, actually. And loving it. http://tinyurl.com/5yd633",
  "id" : 1066544563,
  "created_at" : "2008-12-19 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetsville\" rel=\"nofollow\">Tweetsville</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MEANING.a revolution",
      "screen_name" : "BeMeaningful",
      "indices" : [ 3, 16 ],
      "id_str" : "357764576",
      "id" : 357764576
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1067583703",
  "text" : "RT @BeMeaningful: \"A happy life consists not in the absence, but in the mastery of hardships.\" -Helen Keller",
  "id" : 1067583703,
  "created_at" : "2008-12-19 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetsville\" rel=\"nofollow\">Tweetsville</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1067590885",
  "text" : "And by hardships I mean staying up til 6am drawing and having to wake up before noon to have lunch with one of your local heroes.",
  "id" : 1067590885,
  "created_at" : "2008-12-19 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetsville\" rel=\"nofollow\">Tweetsville</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1067597634",
  "text" : "All while RT'ing philosophy from bed, and playing fave new game, Rolando. Consider hardships mastered. Brushing teeth soon too, bam!",
  "id" : 1067597634,
  "created_at" : "2008-12-19 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com/\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1063971310",
  "text" : "Know the difference between a ponzi scheme and a pyramid scheme?  How about a pump 'n dump?  A bubble?  Learn about scams! http://bit.ly ...",
  "id" : 1063971310,
  "created_at" : "2008-12-18 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com/\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1063972815",
  "text" : "Oops, here's the link: http://bit.ly/aB6S Also interesting: http://bit.ly/3Kyk",
  "id" : 1063972815,
  "created_at" : "2008-12-18 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1064026637",
  "text" : "I'm carrying a saw around with me tonight. One bartender is already scared. I love props.",
  "id" : 1064026637,
  "created_at" : "2008-12-18 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1064041257",
  "text" : "Number of large lit oil candles in Barrio according to bartender: 400+. I see 241 from where I sit. Lit every day, replaced every 4.",
  "id" : 1064041257,
  "created_at" : "2008-12-18 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetsville\" rel=\"nofollow\">Tweetsville</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "samantha",
      "screen_name" : "samantham",
      "indices" : [ 0, 10 ],
      "id_str" : "1771141",
      "id" : 1771141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1064038872",
  "geo" : { },
  "id_str" : "1064058061",
  "in_reply_to_user_id" : 1771141,
  "text" : "@samantham I'm attempting the same, with wine, dinner, and pet saw. Good luck to us both!",
  "id" : 1064058061,
  "in_reply_to_status_id" : 1064038872,
  "created_at" : "2008-12-18 00:00:00 +0000",
  "in_reply_to_screen_name" : "samantham",
  "in_reply_to_user_id_str" : "1771141",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetsville\" rel=\"nofollow\">Tweetsville</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amy Muller",
      "screen_name" : "amylola",
      "indices" : [ 0, 8 ],
      "id_str" : "6343",
      "id" : 6343
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1064054647",
  "geo" : { },
  "id_str" : "1064069835",
  "in_reply_to_user_id" : 6343,
  "text" : "@amylola That's better than a scam. Sounds more like a potential get rich quick scheme to me!",
  "id" : 1064069835,
  "in_reply_to_status_id" : 1064054647,
  "created_at" : "2008-12-18 00:00:00 +0000",
  "in_reply_to_screen_name" : "amylola",
  "in_reply_to_user_id_str" : "6343",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1064102000",
  "text" : "To all people who fetishisize a certain level of polish: I know what you're hiding.",
  "id" : 1064102000,
  "created_at" : "2008-12-18 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://m.twitter.com/\" rel=\"nofollow\">mobile web</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1064333693",
  "text" : "8:36pm Andy's birthday!: http://tinyurl.com/3vlod3",
  "id" : 1064333693,
  "created_at" : "2008-12-18 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetsville\" rel=\"nofollow\">Tweetsville</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1064508930",
  "text" : "2nd time using the amazing Taxi Magic iPhone app. 2nd time sitting here waiting too long. Should I get another drink?",
  "id" : 1064508930,
  "created_at" : "2008-12-18 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetsville\" rel=\"nofollow\">Tweetsville</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan King",
      "screen_name" : "rk",
      "indices" : [ 102, 105 ],
      "id_str" : "19853",
      "id" : 19853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1064512176",
  "text" : "Too late. If ordering a drink while waiting for a web 2.0 cab is wrong, I don't wanna be right. Right @rk?",
  "id" : 1064512176,
  "created_at" : "2008-12-18 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1065764007",
  "text" : "2008 in amazing photos, by Alan Taylor (part 1 of 3): http://tinyurl.com/5awa7v (WOAH)",
  "id" : 1065764007,
  "created_at" : "2008-12-18 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://m.twitter.com/\" rel=\"nofollow\">mobile web</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1062160056",
  "text" : "8:36pm Eating by myself at Boom Noodle, hoping to make it to the cat food store. http://tinyurl.com/6gh5a9",
  "id" : 1062160056,
  "created_at" : "2008-12-17 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetsville\" rel=\"nofollow\">Tweetsville</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1063651544",
  "text" : "I'm shaking. Not entirely sure if it's from cold, frustration, or fear.",
  "id" : 1063651544,
  "created_at" : "2008-12-17 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com/\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1061773645",
  "text" : "See also: dark energy, casimir effect, cosmological constant, lambdavacuum solution, vacuum energy, and zero-point field.",
  "id" : 1061773645,
  "created_at" : "2008-12-17 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com/\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "laurelfan",
      "screen_name" : "laurelfan",
      "indices" : [ 0, 10 ],
      "id_str" : "8046402",
      "id" : 8046402
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1061783978",
  "geo" : { },
  "id_str" : "1061796331",
  "in_reply_to_user_id" : 8046402,
  "text" : "@laurelfan They're everywhere.  But easy to lose.",
  "id" : 1061796331,
  "in_reply_to_status_id" : 1061783978,
  "created_at" : "2008-12-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "laurelfan",
  "in_reply_to_user_id_str" : "8046402",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetsville\" rel=\"nofollow\">Tweetsville</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1062115443",
  "text" : "I've gone to yoga 4 times in the last 8 days but still think buying a membership would jinx it. Advice?",
  "id" : 1062115443,
  "created_at" : "2008-12-17 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetsville\" rel=\"nofollow\">Tweetsville</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ali Berman",
      "screen_name" : "spangley",
      "indices" : [ 3, 12 ],
      "id_str" : "776429",
      "id" : 776429
    }, {
      "name" : "Ryan King",
      "screen_name" : "rk",
      "indices" : [ 95, 98 ],
      "id_str" : "19853",
      "id" : 19853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1062121097",
  "text" : "RT @spangley: OH: \"i realized in the midst of it that i treat twitter like performance art.\" - @rk. I think this is the best possible usage.",
  "id" : 1062121097,
  "created_at" : "2008-12-17 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitterrific.com\" rel=\"nofollow\">Twitterrific</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lane Collins",
      "screen_name" : "lane",
      "indices" : [ 0, 5 ],
      "id_str" : "541",
      "id" : 541
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1062121073",
  "geo" : { },
  "id_str" : "1062127388",
  "in_reply_to_user_id" : 541,
  "text" : "@lane It's a commitment to going to x number of classes. I've yet to buy a gym or yoga pack that didn't cost me in the end. I'm cursed!",
  "id" : 1062127388,
  "in_reply_to_status_id" : 1062121073,
  "created_at" : "2008-12-17 00:00:00 +0000",
  "in_reply_to_screen_name" : "lane",
  "in_reply_to_user_id_str" : "541",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com/\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "asa",
      "screen_name" : "asa",
      "indices" : [ 0, 4 ],
      "id_str" : "407",
      "id" : 407
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1059710482",
  "geo" : { },
  "id_str" : "1059712347",
  "in_reply_to_user_id" : 407,
  "text" : "@asa What's a Discman?  Is it that old iPod that only holds 14 songs?",
  "id" : 1059712347,
  "in_reply_to_status_id" : 1059710482,
  "created_at" : "2008-12-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "asa",
  "in_reply_to_user_id_str" : "407",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com/\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1059720577",
  "text" : "Movable Type's new Motion product has piqued my interest: http://www.movabletype.com/motion/ Anyone planning to try it out?",
  "id" : 1059720577,
  "created_at" : "2008-12-16 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitterrific.com\" rel=\"nofollow\">Twitterrific</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1060016811",
  "text" : "8:36pm Arts and crafts in my warm house make me sleepy. http://tinyurl.com/595xvd",
  "id" : 1060016811,
  "created_at" : "2008-12-16 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com/\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1061069843",
  "text" : "Feeling crushed for prolonged periods of time is useful in at least one way... for example the occassional bursts of pure inspiration.",
  "id" : 1061069843,
  "created_at" : "2008-12-16 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com/\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Tomorrow",
      "screen_name" : "ryantomorrow",
      "indices" : [ 9, 22 ],
      "id_str" : "14679007",
      "id" : 14679007
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1061111094",
  "text" : "Enjoying @ryantomorrow's How It Ends winter mix.",
  "id" : 1061111094,
  "created_at" : "2008-12-16 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 0, 9 ],
      "id_str" : "761628",
      "id" : 761628
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1061528347",
  "geo" : { },
  "id_str" : "1061540297",
  "in_reply_to_user_id" : 761628,
  "text" : "@rickwebb Not my favorite but my worst was when I put \"Babe, I'm Gonna Leave You\" on the jukebox at a bar before I broke up with someone.",
  "id" : 1061540297,
  "in_reply_to_status_id" : 1061528347,
  "created_at" : "2008-12-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "RickWebb",
  "in_reply_to_user_id_str" : "761628",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1057608606",
  "text" : "Making crafts at Kulman with Ingo and Stacy and champagne while fixing broken sweaters was the best way to spend today.",
  "id" : 1057608606,
  "created_at" : "2008-12-15 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitterrific.com\" rel=\"nofollow\">Twitterrific</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1057964743",
  "text" : "8:36pm Kindra just informed me she's a 34C and not a 36D at this holiday party. http://tinyurl.com/5w8osu",
  "id" : 1057964743,
  "created_at" : "2008-12-15 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "thebarbarianparty",
      "indices" : [ 16, 34 ]
    }, {
      "text" : "thebarbarianparty",
      "indices" : [ 35, 53 ]
    }, {
      "text" : "thebarbarianparty",
      "indices" : [ 54, 72 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1056116618",
  "text" : "I wish I was at #thebarbarianparty #thebarbarianparty #thebarbarianparty!",
  "id" : 1056116618,
  "created_at" : "2008-12-14 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitterrific.com\" rel=\"nofollow\">Twitterrific</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1056372486",
  "text" : "8:36pm Tom & Jerry rum & Secret History marathon interrupted by Xmas tree delivery.: http://tinyurl.com/6gf7w3",
  "id" : 1056372486,
  "created_at" : "2008-12-14 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetsville\" rel=\"nofollow\">Tweetsville</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1056549551",
  "text" : "What happens when you relax all day, finish a good book, fight with an Xmas tree, drink a pot of coffee at midnight, and start drawing?",
  "id" : 1056549551,
  "created_at" : "2008-12-14 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetsville\" rel=\"nofollow\">Tweetsville</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1054471202",
  "text" : "4th hr of waiting for the electrician to come fix heating, freezing, reading under covers with cat, listening to wind, storms inside & out.",
  "id" : 1054471202,
  "created_at" : "2008-12-13 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russell Dicker",
      "screen_name" : "rdicker",
      "indices" : [ 5, 13 ],
      "id_str" : "958581",
      "id" : 958581
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1054960118",
  "text" : "What @rdicker said.",
  "id" : 1054960118,
  "created_at" : "2008-12-13 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1055105207",
  "text" : "I was 0/3 in Indian leg wrestling tonight against a April at Todd's fun party even though it was in Ballard.  But I did learn the banjo.",
  "id" : 1055105207,
  "created_at" : "2008-12-13 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1055884144",
  "text" : "Isn't there some kinda Web 2.0 tool out there that will write your yearly reflections for you?",
  "id" : 1055884144,
  "created_at" : "2008-12-13 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1055894453",
  "text" : "Last year's reflections and resolutions: http://tinyurl.com/5g9ruo What were yours?",
  "id" : 1055894453,
  "created_at" : "2008-12-13 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitterrific.com\" rel=\"nofollow\">Twitterrific</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1052782679",
  "text" : "8:36pm Eating a quick bite before holiday partying at the Madsens's's. http://tinyurl.com/5d69ew",
  "id" : 1052782679,
  "created_at" : "2008-12-12 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitterrific.com\" rel=\"nofollow\">Twitterrific</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1050701043",
  "text" : "8:36pm Walking home after a good meeting. http://tinyurl.com/57kmbe",
  "id" : 1050701043,
  "created_at" : "2008-12-11 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com/\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1051866432",
  "text" : "I love it when messages of atheism, Santa Claus taking you to hell, Flying Spaghetti Monster, and Festivus come together: http://bit.ly/ZvGU",
  "id" : 1051866432,
  "created_at" : "2008-12-11 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com/\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1048241514",
  "text" : "Crap, BLVD is closing.  http://bit.ly/GWOq",
  "id" : 1048241514,
  "created_at" : "2008-12-10 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetsville\" rel=\"nofollow\">Tweetsville</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Santangelo",
      "screen_name" : "endquote",
      "indices" : [ 0, 9 ],
      "id_str" : "408",
      "id" : 408
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1048394734",
  "geo" : { },
  "id_str" : "1048506962",
  "in_reply_to_user_id" : 408,
  "text" : "@endquote Report back on Barrio, I've been watching them stain, sand, and build tables and doors for weeks. Is it as weird as it seems?",
  "id" : 1048506962,
  "in_reply_to_status_id" : 1048394734,
  "created_at" : "2008-12-10 00:00:00 +0000",
  "in_reply_to_screen_name" : "endquote",
  "in_reply_to_user_id_str" : "408",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitterrific.com\" rel=\"nofollow\">Twitterrific</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1048574100",
  "text" : "8:36pm Yoga makes me hungry! Deliciousness awaits. http://tinyurl.com/55ub5n",
  "id" : 1048574100,
  "created_at" : "2008-12-10 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com/\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1049877197",
  "text" : "Our 43 Things book is finally available on Amazon.  Check it. http://bit.ly/160x3",
  "id" : 1049877197,
  "created_at" : "2008-12-10 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1046384611",
  "text" : "I wish we were all still studying something.",
  "id" : 1046384611,
  "created_at" : "2008-12-09 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Tomorrow",
      "screen_name" : "ryantomorrow",
      "indices" : [ 0, 13 ],
      "id_str" : "14679007",
      "id" : 14679007
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1046392757",
  "geo" : { },
  "id_str" : "1046394151",
  "in_reply_to_user_id" : 14679007,
  "text" : "@ryantomorrow Don't forget about Shenanigansett!",
  "id" : 1046394151,
  "in_reply_to_status_id" : 1046392757,
  "created_at" : "2008-12-09 00:00:00 +0000",
  "in_reply_to_screen_name" : "ryantomorrow",
  "in_reply_to_user_id_str" : "14679007",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitterrific.com\" rel=\"nofollow\">Twitterrific</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1046477253",
  "text" : "8:36pm Eating left over Thai with Cait, good times! http://tinyurl.com/62tjzd",
  "id" : 1046477253,
  "created_at" : "2008-12-09 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetsville\" rel=\"nofollow\">Tweetsville</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 5, 14 ],
      "id_str" : "761628",
      "id" : 761628
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1046553593",
  "text" : "From @RickWebb: Uuqwertyiopllkjhggfdsazxcvbn'nbvm!v?c,c.x/d:e/e5h$&88899kl0lkjjhbb!???c(v(ddf",
  "id" : 1046553593,
  "created_at" : "2008-12-09 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1047556784",
  "text" : "I have to go to Tully's to get my eggnog latte crack now... I'm too embarrassed to go to my favorite local shop.",
  "id" : 1047556784,
  "created_at" : "2008-12-09 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitterrific.com\" rel=\"nofollow\">Twitterrific</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1044516820",
  "text" : "8:36pm Eating Thai, reading The Secret History and doing my 100-pushup challenge. http://tinyurl.com/57kh8u",
  "id" : 1044516820,
  "created_at" : "2008-12-08 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetsville\" rel=\"nofollow\">Tweetsville</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dennis Crowley",
      "screen_name" : "dens",
      "indices" : [ 0, 5 ],
      "id_str" : "418",
      "id" : 418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1044518342",
  "geo" : { },
  "id_str" : "1044730699",
  "in_reply_to_user_id" : 418,
  "text" : "@dens It's fun but takes longer than 6 weeks in my experience. Maybe you'll do better! http://hundredpushups.com",
  "id" : 1044730699,
  "in_reply_to_status_id" : 1044518342,
  "created_at" : "2008-12-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "dens",
  "in_reply_to_user_id_str" : "418",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com/\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shannon Sweetser",
      "screen_name" : "shaxxon",
      "indices" : [ 0, 8 ],
      "id_str" : "9499632",
      "id" : 9499632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1045479584",
  "geo" : { },
  "id_str" : "1045488492",
  "in_reply_to_user_id" : 9499632,
  "text" : "@shaxxon I think consensus is that blurb.com is the best option.  iPhoto has a really simple-to-use make-into-book feature too.",
  "id" : 1045488492,
  "in_reply_to_status_id" : 1045479584,
  "created_at" : "2008-12-08 00:00:00 +0000",
  "in_reply_to_screen_name" : "shaxxon",
  "in_reply_to_user_id_str" : "9499632",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1043985355",
  "text" : "I'm enjoying last.fm's best of 2008: http://www.last.fm/bestof/2008 Send me your best of lists too, please.",
  "id" : 1043985355,
  "created_at" : "2008-12-07 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetsville\" rel=\"nofollow\">Tweetsville</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Cottrell",
      "screen_name" : "rgcottrell",
      "indices" : [ 0, 11 ],
      "id_str" : "752553",
      "id" : 752553
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1044015094",
  "geo" : { },
  "id_str" : "1044079943",
  "in_reply_to_user_id" : 752553,
  "text" : "@rgcottrell I say, why pay attention all year when you can just catch up at the end with these best of lists?",
  "id" : 1044079943,
  "in_reply_to_status_id" : 1044015094,
  "created_at" : "2008-12-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "rgcottrell",
  "in_reply_to_user_id_str" : "752553",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1041440736",
  "text" : "I wish mint.com had a way to print out monthly overviews with smart info on it so you could take it to a new restaurant to work on budgets.",
  "id" : 1041440736,
  "created_at" : "2008-12-06 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1041442602",
  "text" : "In related financial feelings, I am happy that I talked the IRS down from $20,000 owed back taxes for 2005 to $160.39 today.",
  "id" : 1041442602,
  "created_at" : "2008-12-06 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitterrific.com\" rel=\"nofollow\">Twitterrific</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1041538084",
  "text" : "8:36pm Date night in Ballard at Volterra to talk about date-y things. http://tinyurl.com/65prow",
  "id" : 1041538084,
  "created_at" : "2008-12-06 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitterrific.com\" rel=\"nofollow\">Twitterrific</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1039592400",
  "text" : "8:36pm Just leaving 619 Western with some Jetpack and Cait Willis art. http://tinyurl.com/65fzte",
  "id" : 1039592400,
  "created_at" : "2008-12-05 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1040697661",
  "text" : "Today I'm the type of person who wakes up early and goes to power cycle and pilates classes at the gym with my wife.",
  "id" : 1040697661,
  "created_at" : "2008-12-05 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitterrific.com\" rel=\"nofollow\">Twitterrific</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1037589950",
  "text" : "8:36pm Reading about meditation and Dalai Lama's quote, \"My religion is kindness.\" http://tinyurl.com/6y699o",
  "id" : 1037589950,
  "created_at" : "2008-12-04 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com/\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "D. Keith Robinson",
      "screen_name" : "dkr",
      "indices" : [ 0, 4 ],
      "id_str" : "10877",
      "id" : 10877
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1038654337",
  "geo" : { },
  "id_str" : "1038656852",
  "in_reply_to_user_id" : 10877,
  "text" : "@dkr  I love daytum.com.  What exactly qualifies as a positive or negative karmic action?",
  "id" : 1038656852,
  "in_reply_to_status_id" : 1038654337,
  "created_at" : "2008-12-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "dkr",
  "in_reply_to_user_id_str" : "10877",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com/\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "D. Keith Robinson",
      "screen_name" : "dkr",
      "indices" : [ 0, 4 ],
      "id_str" : "10877",
      "id" : 10877
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1038662363",
  "geo" : { },
  "id_str" : "1038666865",
  "in_reply_to_user_id" : 10877,
  "text" : "@dkr  How to know if your being comprehensive?  Maybe you should let others also anonymously update your karma.  Sounds like wuffie then.",
  "id" : 1038666865,
  "in_reply_to_status_id" : 1038662363,
  "created_at" : "2008-12-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "dkr",
  "in_reply_to_user_id_str" : "10877",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com/\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "D. Keith Robinson",
      "screen_name" : "dkr",
      "indices" : [ 0, 4 ],
      "id_str" : "10877",
      "id" : 10877
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1038678789",
  "geo" : { },
  "id_str" : "1038683014",
  "in_reply_to_user_id" : 10877,
  "text" : "@dkr  Yes, we do need one!  If you build one, I'd like to help!",
  "id" : 1038683014,
  "in_reply_to_status_id" : 1038678789,
  "created_at" : "2008-12-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "dkr",
  "in_reply_to_user_id_str" : "10877",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com/\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1038856256",
  "text" : "Unit a couple doors down from me is being rented out if anyone's interested.  $2,300/mo includes parking and private roof deck!",
  "id" : 1038856256,
  "created_at" : "2008-12-04 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com/\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brightkite",
      "screen_name" : "brightkite",
      "indices" : [ 3, 14 ],
      "id_str" : "14391242",
      "id" : 14391242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1037011868",
  "text" : "RT @brightkite: Brightkite now in Public Beta! http://tinyurl.com/5ratyf (everyone sign up now, please)",
  "id" : 1037011868,
  "created_at" : "2008-12-03 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com/\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "senoraj",
      "screen_name" : "senoraj",
      "indices" : [ 0, 8 ],
      "id_str" : "13443292",
      "id" : 13443292
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1037073653",
  "geo" : { },
  "id_str" : "1037075199",
  "in_reply_to_user_id" : 13443292,
  "text" : "@senoraj  I would have to say \"YES!\"",
  "id" : 1037075199,
  "in_reply_to_status_id" : 1037073653,
  "created_at" : "2008-12-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "senoraj",
  "in_reply_to_user_id_str" : "13443292",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1035277959",
  "text" : "Christmas trees for sale at the entrance to Pike Place Market!",
  "id" : 1035277959,
  "created_at" : "2008-12-03 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetsville\" rel=\"nofollow\">Tweetsville</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael McDaniel",
      "screen_name" : "michaelmcdaniel",
      "indices" : [ 0, 16 ],
      "id_str" : "7565162",
      "id" : 7565162
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1035281961",
  "geo" : { },
  "id_str" : "1035430776",
  "in_reply_to_user_id" : 7565162,
  "text" : "@michaelmcdaniel Yes! In front of the pig. They'll be there a week or so they say.",
  "id" : 1035430776,
  "in_reply_to_status_id" : 1035281961,
  "created_at" : "2008-12-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "michaelmcdaniel",
  "in_reply_to_user_id_str" : "7565162",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitterrific.com\" rel=\"nofollow\">Twitterrific</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1035606319",
  "text" : "8:36pm Kellianne's cutting Jenny Zwick's hair while I eat apple crisp. http://tinyurl.com/5srs69",
  "id" : 1035606319,
  "created_at" : "2008-12-03 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetsville\" rel=\"nofollow\">Tweetsville</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1033614392",
  "text" : "The funny thing about most of our lives is: people are barely even paying attention. And that's not a bad thing.",
  "id" : 1033614392,
  "created_at" : "2008-12-02 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitterrific.com\" rel=\"nofollow\">Twitterrific</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1033627632",
  "text" : "8:36pm Victoria is Flip videoing people at her 12th Vainiversary party at McLeod. http://tinyurl.com/6medoo",
  "id" : 1033627632,
  "created_at" : "2008-12-02 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
} ]