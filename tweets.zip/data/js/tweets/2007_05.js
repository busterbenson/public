Grailbird.data.tweets_2007_05 = 
 [ {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "67895152",
  "text" : "Waiting in a giant line for a book reading (sure it's Miranda July) with bunny ears in my pocket.",
  "id" : 67895152,
  "created_at" : "Fri May 18 01:37:33 +0000 2007",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "54005262",
  "text" : "If you saw a dollar on the floor of a public bathroom would you pick it up? I passed. After looking for cameras.",
  "id" : 54005262,
  "created_at" : "Tue May 08 00:53:10 +0000 2007",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "im",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "52578822",
  "text" : "Okay, I agree, the new SAM is awesome!  And disorienting in how it connects to the old museum.  And, exhausting.  Naptime!",
  "id" : 52578822,
  "created_at" : "Mon May 07 01:45:50 +0000 2007",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "51606462",
  "text" : "Sorry that you're dead motherfucker.",
  "id" : 51606462,
  "created_at" : "Sun May 06 05:24:58 +0000 2007",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
} ]