Grailbird.data.tweets_2012_08 = 
 [ {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 61 ],
      "url" : "http://t.co/x1OKvfTv",
      "expanded_url" : "http://flic.kr/p/d3u5GG",
      "display_url" : "flic.kr/p/d3u5GG"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.616166, -122.3825 ]
  },
  "id_str" : "241768913812193280",
  "text" : "8:36pm Impatient on my late flight home. http://t.co/x1OKvfTv",
  "id" : 241768913812193280,
  "created_at" : "Sat Sep 01 05:26:15 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ʎǝʞɔıɥ ʇʇɐɯ",
      "screen_name" : "matthickey",
      "indices" : [ 0, 11 ],
      "id_str" : "8710082",
      "id" : 8710082
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "241719292431847424",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.6179289255, -122.385895042 ]
  },
  "id_str" : "241719897133023232",
  "in_reply_to_user_id" : 8710082,
  "text" : "@matthickey Get back on the case. Seems to be pretty wide open.",
  "id" : 241719897133023232,
  "in_reply_to_status_id" : 241719292431847424,
  "created_at" : "Sat Sep 01 02:11:29 +0000 2012",
  "in_reply_to_screen_name" : "matthickey",
  "in_reply_to_user_id_str" : "8710082",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kathleenicanrah",
      "screen_name" : "kathleenicanrah",
      "indices" : [ 3, 19 ],
      "id_str" : "15129907",
      "id" : 15129907
    }, {
      "name" : "Buster Benson",
      "screen_name" : "busterbenson",
      "indices" : [ 21, 34 ],
      "id_str" : "2185",
      "id" : 2185
    }, {
      "name" : "Erin Fa La La La La",
      "screen_name" : "erinscafe",
      "indices" : [ 39, 49 ],
      "id_str" : "19683903",
      "id" : 19683903
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "241719752815427584",
  "text" : "RT @kathleenicanrah: @busterbenson and @erinscafe is making a sweet documentary about it, with a fresh, funny perspective. check out htt ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Buster Benson",
        "screen_name" : "busterbenson",
        "indices" : [ 0, 13 ],
        "id_str" : "2185",
        "id" : 2185
      }, {
        "name" : "Erin Fa La La La La",
        "screen_name" : "erinscafe",
        "indices" : [ 18, 28 ],
        "id_str" : "19683903",
        "id" : 19683903
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 112, 132 ],
        "url" : "http://t.co/94GMrTlo",
        "expanded_url" : "http://followfridaythefilm.com",
        "display_url" : "followfridaythefilm.com"
      } ]
    },
    "in_reply_to_status_id_str" : "241717587061387266",
    "geo" : {
    },
    "id_str" : "241718745209397248",
    "in_reply_to_user_id" : 2185,
    "text" : "@busterbenson and @erinscafe is making a sweet documentary about it, with a fresh, funny perspective. check out http://t.co/94GMrTlo",
    "id" : 241718745209397248,
    "in_reply_to_status_id" : 241717587061387266,
    "created_at" : "Sat Sep 01 02:06:54 +0000 2012",
    "in_reply_to_screen_name" : "busterbenson",
    "in_reply_to_user_id_str" : "2185",
    "user" : {
      "name" : "kathleenicanrah",
      "screen_name" : "kathleenicanrah",
      "protected" : false,
      "id_str" : "15129907",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1899422369/kathleen_crown2_normal.jpg",
      "id" : 15129907,
      "verified" : false
    }
  },
  "id" : 241719752815427584,
  "created_at" : "Sat Sep 01 02:10:54 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anil Dash",
      "screen_name" : "anildash",
      "indices" : [ 85, 94 ],
      "id_str" : "36823",
      "id" : 36823
    }, {
      "name" : "Tom Coates",
      "screen_name" : "tomcoates",
      "indices" : [ 95, 105 ],
      "id_str" : "12514",
      "id" : 12514
    }, {
      "name" : "Ryan Sarver",
      "screen_name" : "rsarver",
      "indices" : [ 106, 114 ],
      "id_str" : "795649",
      "id" : 795649
    }, {
      "name" : "MG Siegler",
      "screen_name" : "parislemon",
      "indices" : [ 119, 130 ],
      "id_str" : "652193",
      "id" : 652193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.616765094, -122.3890873791 ]
  },
  "id_str" : "241717587061387266",
  "text" : "Who are the best tweeters/bloggers/journalists who write about Twitter? My faves are @anildash @tomcoates @rsarver and @parislemon...",
  "id" : 241717587061387266,
  "created_at" : "Sat Sep 01 02:02:18 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Raffi Krikorian",
      "screen_name" : "raffi",
      "indices" : [ 0, 6 ],
      "id_str" : "8285392",
      "id" : 8285392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "241616955021357057",
  "geo" : {
  },
  "id_str" : "241711935031214080",
  "in_reply_to_user_id" : 8285392,
  "text" : "@raffi I saw that yesterday for the first time and was equally impressed.",
  "id" : 241711935031214080,
  "in_reply_to_status_id" : 241616955021357057,
  "created_at" : "Sat Sep 01 01:39:50 +0000 2012",
  "in_reply_to_screen_name" : "raffi",
  "in_reply_to_user_id_str" : "8285392",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "William Morgan",
      "screen_name" : "wm",
      "indices" : [ 25, 28 ],
      "id_str" : "15504330",
      "id" : 15504330
    }, {
      "name" : "Cask Store",
      "screen_name" : "caskstore",
      "indices" : [ 65, 75 ],
      "id_str" : "23678022",
      "id" : 23678022
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/wm/status/241687953934516224/photo/1",
      "indices" : [ 120, 140 ],
      "url" : "http://t.co/P8XCthhd",
      "media_url" : "http://pbs.twimg.com/media/A1ql6eECAAAyMfy.jpg",
      "id_str" : "241687953938710528",
      "id" : 241687953938710528,
      "media_url_https" : "https://pbs.twimg.com/media/A1ql6eECAAAyMfy.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com/P8XCthhd"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "241711287468449793",
  "text" : "And it was delicious. RT @wm: Just ordered a bottle of this from @caskstore, delivered to the office via bike messenger http://t.co/P8XCthhd",
  "id" : 241711287468449793,
  "created_at" : "Sat Sep 01 01:37:16 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sunshine",
      "screen_name" : "nk",
      "indices" : [ 3, 6 ],
      "id_str" : "10583402",
      "id" : 10583402
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "241710816318074880",
  "text" : "RT @nk: What is the exchange rate between dollars and happiness?",
  "retweeted_status" : {
    "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "6642909591",
    "text" : "What is the exchange rate between dollars and happiness?",
    "id" : 6642909591,
    "created_at" : "Sun Dec 13 23:07:04 +0000 2009",
    "user" : {
      "name" : "sunshine",
      "screen_name" : "nk",
      "protected" : false,
      "id_str" : "10583402",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/597577189/53155843_normal.jpg",
      "id" : 10583402,
      "verified" : false
    }
  },
  "id" : 241710816318074880,
  "created_at" : "Sat Sep 01 01:35:24 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Reichhold",
      "screen_name" : "jreichhold",
      "indices" : [ 0, 11 ],
      "id_str" : "14934401",
      "id" : 14934401
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "241710317044920321",
  "geo" : {
  },
  "id_str" : "241710637061902337",
  "in_reply_to_user_id" : 14934401,
  "text" : "@jreichhold Awesome. I’ll come find you when I get through security.",
  "id" : 241710637061902337,
  "in_reply_to_status_id" : 241710317044920321,
  "created_at" : "Sat Sep 01 01:34:41 +0000 2012",
  "in_reply_to_screen_name" : "jreichhold",
  "in_reply_to_user_id_str" : "14934401",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Reichhold",
      "screen_name" : "jreichhold",
      "indices" : [ 0, 11 ],
      "id_str" : "14934401",
      "id" : 14934401
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "241709675010207744",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7663049913, -122.4201666826 ]
  },
  "id_str" : "241709876026437632",
  "in_reply_to_user_id" : 14934401,
  "text" : "@jreichhold The one that should leave at 7:50.",
  "id" : 241709876026437632,
  "in_reply_to_status_id" : 241709675010207744,
  "created_at" : "Sat Sep 01 01:31:39 +0000 2012",
  "in_reply_to_screen_name" : "jreichhold",
  "in_reply_to_user_id_str" : "14934401",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Reichhold",
      "screen_name" : "jreichhold",
      "indices" : [ 0, 11 ],
      "id_str" : "14934401",
      "id" : 14934401
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "241709285715881984",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7792689011, -122.4132882888 ]
  },
  "id_str" : "241709464338710528",
  "in_reply_to_user_id" : 14934401,
  "text" : "@jreichhold Catching Bart right now! See ya there?",
  "id" : 241709464338710528,
  "in_reply_to_status_id" : 241709285715881984,
  "created_at" : "Sat Sep 01 01:30:01 +0000 2012",
  "in_reply_to_screen_name" : "jreichhold",
  "in_reply_to_user_id_str" : "14934401",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Ward",
      "screen_name" : "BenWard",
      "indices" : [ 41, 49 ],
      "id_str" : "12249",
      "id" : 12249
    }, {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 86, 94 ],
      "id_str" : "783214",
      "id" : 783214
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7792303982, -122.4133958876 ]
  },
  "id_str" : "241708391901310977",
  "text" : "Day 10 at Twitter: Fun conversation with @BenWard and other teammates about people at @twitter who tweet about working here. Faves?",
  "id" : 241708391901310977,
  "created_at" : "Sat Sep 01 01:25:46 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Holly McNamara",
      "screen_name" : "HollyMac",
      "indices" : [ 0, 9 ],
      "id_str" : "7349222",
      "id" : 7349222
    }, {
      "name" : "Jonathan Lieberman",
      "screen_name" : "jonnyliebs",
      "indices" : [ 10, 21 ],
      "id_str" : "25574860",
      "id" : 25574860
    }, {
      "name" : "Camille Brenkwitz",
      "screen_name" : "CamilleBrittany",
      "indices" : [ 22, 38 ],
      "id_str" : "36090605",
      "id" : 36090605
    }, {
      "name" : "Willo O'Brien",
      "screen_name" : "WilloToons",
      "indices" : [ 77, 88 ],
      "id_str" : "772386",
      "id" : 772386
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "241562713048887297",
  "geo" : {
  },
  "id_str" : "241581884772077569",
  "in_reply_to_user_id" : 7349222,
  "text" : "@HollyMac @jonnyliebs @CamilleBrittany Great meeting you all last night! And @WilloToons, good luck today!",
  "id" : 241581884772077569,
  "in_reply_to_status_id" : 241562713048887297,
  "created_at" : "Fri Aug 31 17:03:04 +0000 2012",
  "in_reply_to_screen_name" : "HollyMac",
  "in_reply_to_user_id_str" : "7349222",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amy Jo Kim",
      "screen_name" : "amyjokim",
      "indices" : [ 52, 61 ],
      "id_str" : "780991",
      "id" : 780991
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 125 ],
      "url" : "http://t.co/xPmY91Po",
      "expanded_url" : "http://flic.kr/p/d2Wx1f",
      "display_url" : "flic.kr/p/d2Wx1f"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.774333, -122.397334 ]
  },
  "id_str" : "241389049695326208",
  "text" : "8:36pm Returning from visiting with the super smart @amyjokim in Burlingame (only missed my stops twice) http://t.co/xPmY91Po",
  "id" : 241389049695326208,
  "created_at" : "Fri Aug 31 04:16:48 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TechCrunch",
      "screen_name" : "TechCrunch",
      "indices" : [ 19, 30 ],
      "id_str" : "816653",
      "id" : 816653
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 115 ],
      "url" : "http://t.co/fwKjx9RM",
      "expanded_url" : "http://tcrn.ch/O6JOpm",
      "display_url" : "tcrn.ch/O6JOpm"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7800746941, -122.4150396449 ]
  },
  "id_str" : "241257596248547328",
  "text" : "This is awesome RT @TechCrunch: Wolfram Alpha Launches Personal Analytics Reports For Facebook http://t.co/fwKjx9RM",
  "id" : 241257596248547328,
  "created_at" : "Thu Aug 30 19:34:27 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jackie Shelley",
      "screen_name" : "jackinessity",
      "indices" : [ 0, 13 ],
      "id_str" : "180514789",
      "id" : 180514789
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "241223159653752833",
  "geo" : {
  },
  "id_str" : "241223422699520000",
  "in_reply_to_user_id" : 180514789,
  "text" : "@jackinessity I DO remember that! That was awesome.",
  "id" : 241223422699520000,
  "in_reply_to_status_id" : 241223159653752833,
  "created_at" : "Thu Aug 30 17:18:40 +0000 2012",
  "in_reply_to_screen_name" : "jackinessity",
  "in_reply_to_user_id_str" : "180514789",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Bronstein",
      "screen_name" : "sbb",
      "indices" : [ 0, 4 ],
      "id_str" : "1149",
      "id" : 1149
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "241220586750214144",
  "geo" : {
  },
  "id_str" : "241222667934507008",
  "in_reply_to_user_id" : 1149,
  "text" : "@sbb Great meeting you too! Let me know what you think of it… it’s still very early...",
  "id" : 241222667934507008,
  "in_reply_to_status_id" : 241220586750214144,
  "created_at" : "Thu Aug 30 17:15:40 +0000 2012",
  "in_reply_to_screen_name" : "sbb",
  "in_reply_to_user_id_str" : "1149",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jackie Shelley",
      "screen_name" : "jackinessity",
      "indices" : [ 0, 13 ],
      "id_str" : "180514789",
      "id" : 180514789
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "241217775312437248",
  "geo" : {
  },
  "id_str" : "241222497205383169",
  "in_reply_to_user_id" : 180514789,
  "text" : "@jackinessity Ha, resourceful! Yes, things are crazy as I get adjusted to new work but lets definitely meet up when things calm down a bit!",
  "id" : 241222497205383169,
  "in_reply_to_status_id" : 241217775312437248,
  "created_at" : "Thu Aug 30 17:14:59 +0000 2012",
  "in_reply_to_screen_name" : "jackinessity",
  "in_reply_to_user_id_str" : "180514789",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lane Collins",
      "screen_name" : "lane",
      "indices" : [ 0, 5 ],
      "id_str" : "541",
      "id" : 541
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "241214633669701632",
  "geo" : {
  },
  "id_str" : "241215567455989760",
  "in_reply_to_user_id" : 541,
  "text" : "@lane Ah, well let me know when the next one is!  I’m currently doing 2 days a week.",
  "id" : 241215567455989760,
  "in_reply_to_status_id" : 241214633669701632,
  "created_at" : "Thu Aug 30 16:47:27 +0000 2012",
  "in_reply_to_screen_name" : "lane",
  "in_reply_to_user_id_str" : "541",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lane Collins",
      "screen_name" : "lane",
      "indices" : [ 0, 5 ],
      "id_str" : "541",
      "id" : 541
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "241204391431000064",
  "geo" : {
  },
  "id_str" : "241214483463278592",
  "in_reply_to_user_id" : 541,
  "text" : "@lane When do you work in SF?",
  "id" : 241214483463278592,
  "in_reply_to_status_id" : 241204391431000064,
  "created_at" : "Thu Aug 30 16:43:09 +0000 2012",
  "in_reply_to_screen_name" : "lane",
  "in_reply_to_user_id_str" : "541",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7884999969, -122.4134747299 ]
  },
  "id_str" : "241203878773796865",
  "text" : "Good morning.",
  "id" : 241203878773796865,
  "created_at" : "Thu Aug 30 16:01:00 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Beau Gunderson",
      "screen_name" : "beaugunderson",
      "indices" : [ 0, 14 ],
      "id_str" : "5746882",
      "id" : 5746882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "241051373645467648",
  "geo" : {
  },
  "id_str" : "241054978230333440",
  "in_reply_to_user_id" : 5746882,
  "text" : "@beaugunderson Were you sitting right in front of me? Hi! Yeah, I work at Twitter now...",
  "id" : 241054978230333440,
  "in_reply_to_status_id" : 241051373645467648,
  "created_at" : "Thu Aug 30 06:09:20 +0000 2012",
  "in_reply_to_screen_name" : "beaugunderson",
  "in_reply_to_user_id_str" : "5746882",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diana Kimball",
      "screen_name" : "dianakimball",
      "indices" : [ 81, 94 ],
      "id_str" : "14471007",
      "id" : 14471007
    }, {
      "name" : "Alex Carmichael",
      "screen_name" : "accarmichael",
      "indices" : [ 95, 108 ],
      "id_str" : "15916492",
      "id" : 15916492
    }, {
      "name" : "Nancy Dougherty",
      "screen_name" : "nancyhd",
      "indices" : [ 113, 121 ],
      "id_str" : "19854731",
      "id" : 19854731
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7718030624, -122.4064095777 ]
  },
  "id_str" : "241044577514029056",
  "text" : "Today I met-in-person 3 awesome people that I've wanted to meet for a long time: @dianakimball @accarmichael and @nancyhd (follow them!)",
  "id" : 241044577514029056,
  "created_at" : "Thu Aug 30 05:28:00 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amy Jo Kim",
      "screen_name" : "amyjokim",
      "indices" : [ 0, 9 ],
      "id_str" : "780991",
      "id" : 780991
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "241017711839301632",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7710894746, -122.4051452721 ]
  },
  "id_str" : "241042941194424320",
  "in_reply_to_user_id" : 780991,
  "text" : "@amyjokim Not at all! Just showed up early with one of the hosts. :)",
  "id" : 241042941194424320,
  "in_reply_to_status_id" : 241017711839301632,
  "created_at" : "Thu Aug 30 05:21:30 +0000 2012",
  "in_reply_to_screen_name" : "amyjokim",
  "in_reply_to_user_id_str" : "780991",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "QuantifiedSelf",
      "indices" : [ 28, 43 ]
    } ],
    "urls" : [ {
      "indices" : [ 51, 71 ],
      "url" : "http://t.co/lkjB3fNs",
      "expanded_url" : "http://flic.kr/p/d2ngiy",
      "display_url" : "flic.kr/p/d2ngiy"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.775833, -122.413667 ]
  },
  "id_str" : "241017065971003392",
  "text" : "8:36pm Enjoying my first SF #QuantifiedSelf meetup http://t.co/lkjB3fNs",
  "id" : 241017065971003392,
  "created_at" : "Thu Aug 30 03:38:41 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Beau Gunderson",
      "screen_name" : "beaugunderson",
      "indices" : [ 40, 54 ],
      "id_str" : "5746882",
      "id" : 5746882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 76 ],
      "url" : "http://t.co/EN2qcdNj",
      "expanded_url" : "http://4sq.com/PwdjFA",
      "display_url" : "4sq.com/PwdjFA"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.77569862, -122.413593 ]
  },
  "id_str" : "240999798684151808",
  "text" : "Hello Quantified Self! (@ Storify HQ w/ @beaugunderson) http://t.co/EN2qcdNj",
  "id" : 240999798684151808,
  "created_at" : "Thu Aug 30 02:30:04 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Stubblebine",
      "screen_name" : "tonystubblebine",
      "indices" : [ 62, 78 ],
      "id_str" : "17",
      "id" : 17
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 134 ],
      "url" : "http://t.co/CtAa4KSf",
      "expanded_url" : "http://blog.lift.do/post/30458629307/theres-a-lift-for-that",
      "display_url" : "blog.lift.do/post/304586293…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "240882123937030144",
  "text" : "Congrats, Tony! Everyone, download this now! It’s awesome. MT @tonystubblebine: Super proud to launch Lift today. http://t.co/CtAa4KSf",
  "id" : 240882123937030144,
  "created_at" : "Wed Aug 29 18:42:28 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Jackson",
      "screen_name" : "ericjackson",
      "indices" : [ 3, 15 ],
      "id_str" : "818071",
      "id" : 818071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "240656760808038402",
  "text" : "RT @ericjackson: It's wild to think Twitter didn't exist when Katrina hit 7 years ago",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "240653583857618944",
    "text" : "It's wild to think Twitter didn't exist when Katrina hit 7 years ago",
    "id" : 240653583857618944,
    "created_at" : "Wed Aug 29 03:34:20 +0000 2012",
    "user" : {
      "name" : "Eric Jackson",
      "screen_name" : "ericjackson",
      "protected" : false,
      "id_str" : "818071",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/143130749/EricJackson_August2008_normal.jpg",
      "id" : 818071,
      "verified" : false
    }
  },
  "id" : 240656760808038402,
  "created_at" : "Wed Aug 29 03:46:57 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 90 ],
      "url" : "http://t.co/z2IJibdL",
      "expanded_url" : "http://flic.kr/p/d1LxV9",
      "display_url" : "flic.kr/p/d1LxV9"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7865, -122.411334 ]
  },
  "id_str" : "240655122697433090",
  "text" : "8:36pm Resting in the hotel bar, being watched by the video portraits http://t.co/z2IJibdL",
  "id" : 240655122697433090,
  "created_at" : "Wed Aug 29 03:40:27 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7866431475, -122.4112944562 ]
  },
  "id_str" : "240654199833108480",
  "text" : "Day 7 at Twitter: Starting to feel more at home, though still have a long way to go before I reach a rest stop on this learning curve.",
  "id" : 240654199833108480,
  "created_at" : "Wed Aug 29 03:36:47 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Cole",
      "screen_name" : "irondavy",
      "indices" : [ 3, 12 ],
      "id_str" : "14986129",
      "id" : 14986129
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "240497280510201858",
  "text" : "RT @irondavy: Ha! \"...every possible activity that people might do competes with every other possible activity that people might do.\" ht ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 120, 140 ],
        "url" : "http://t.co/ZhLWkine",
        "expanded_url" : "http://qr.ae/8UWsE",
        "display_url" : "qr.ae/8UWsE"
      } ]
    },
    "geo" : {
    },
    "id_str" : "240485405202456577",
    "text" : "Ha! \"...every possible activity that people might do competes with every other possible activity that people might do.\" http://t.co/ZhLWkine",
    "id" : 240485405202456577,
    "created_at" : "Tue Aug 28 16:26:03 +0000 2012",
    "user" : {
      "name" : "David Cole",
      "screen_name" : "irondavy",
      "protected" : false,
      "id_str" : "14986129",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2987653880/3e61a2ddbed0592614cecaa893d1f496_normal.png",
      "id" : 14986129,
      "verified" : false
    }
  },
  "id" : 240497280510201858,
  "created_at" : "Tue Aug 28 17:13:14 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carinna Tarvin",
      "screen_name" : "carinnatarvin",
      "indices" : [ 0, 14 ],
      "id_str" : "20833838",
      "id" : 20833838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "240313039931449344",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7863484628, -122.4122436827 ]
  },
  "id_str" : "240313987714134016",
  "in_reply_to_user_id" : 20833838,
  "text" : "@carinnatarvin Yes! Make them read it! I need to read it a few more times myself. I like thinking about listening as having \"moves\".",
  "id" : 240313987714134016,
  "in_reply_to_status_id" : 240313039931449344,
  "created_at" : "Tue Aug 28 05:04:54 +0000 2012",
  "in_reply_to_screen_name" : "carinnatarvin",
  "in_reply_to_user_id_str" : "20833838",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amy Jo Kim",
      "screen_name" : "amyjokim",
      "indices" : [ 0, 9 ],
      "id_str" : "780991",
      "id" : 780991
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "240296505876049921",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7865128825, -122.4146428017 ]
  },
  "id_str" : "240297086174760960",
  "in_reply_to_user_id" : 780991,
  "text" : "@amyjokim Agreed. I just have PTSD from too much of it in the past. Sorry for knee-jerk reaction. :)",
  "id" : 240297086174760960,
  "in_reply_to_status_id" : 240296505876049921,
  "created_at" : "Tue Aug 28 03:57:44 +0000 2012",
  "in_reply_to_screen_name" : "amyjokim",
  "in_reply_to_user_id_str" : "780991",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 67 ],
      "url" : "http://t.co/PWZAFhjr",
      "expanded_url" : "http://flic.kr/p/d18LmC",
      "display_url" : "flic.kr/p/d18LmC"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7865, -122.414667 ]
  },
  "id_str" : "240294456283254784",
  "text" : "8:36pm Taking some time to read in a dark bar. http://t.co/PWZAFhjr",
  "id" : 240294456283254784,
  "created_at" : "Tue Aug 28 03:47:17 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amy Jo Kim",
      "screen_name" : "amyjokim",
      "indices" : [ 0, 9 ],
      "id_str" : "780991",
      "id" : 780991
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "240288490233946113",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7864602647, -122.4147274848 ]
  },
  "id_str" : "240290359224188929",
  "in_reply_to_user_id" : 780991,
  "text" : "@amyjokim Ah, I see. The flaw is the assumption that people pay more for things they enjoy. But if it's just a safety net for instincts, ok.",
  "id" : 240290359224188929,
  "in_reply_to_status_id" : 240288490233946113,
  "created_at" : "Tue Aug 28 03:31:00 +0000 2012",
  "in_reply_to_screen_name" : "amyjokim",
  "in_reply_to_user_id_str" : "780991",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marshall Haas",
      "screen_name" : "MarshallHaas",
      "indices" : [ 0, 13 ],
      "id_str" : "19028099",
      "id" : 19028099
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "240285928390807552",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7864860772, -122.4145611078 ]
  },
  "id_str" : "240288200801800192",
  "in_reply_to_user_id" : 19028099,
  "text" : "@MarshallHaas Just last week!",
  "id" : 240288200801800192,
  "in_reply_to_status_id" : 240285928390807552,
  "created_at" : "Tue Aug 28 03:22:26 +0000 2012",
  "in_reply_to_screen_name" : "MarshallHaas",
  "in_reply_to_user_id_str" : "19028099",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "rands",
      "screen_name" : "rands",
      "indices" : [ 117, 123 ],
      "id_str" : "30923",
      "id" : 30923
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 112 ],
      "url" : "http://t.co/KryGZKps",
      "expanded_url" : "http://www.randsinrepose.com/archives/2012/08/28/youre_not_listening.html",
      "display_url" : "randsinrepose.com/archives/2012/…"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7864851872, -122.4145579192 ]
  },
  "id_str" : "240287999315816448",
  "text" : "\"The most basic rule of listening: If they don’t trust you, they aren’t going to say shit.\" http://t.co/KryGZKps /by @rands",
  "id" : 240287999315816448,
  "created_at" : "Tue Aug 28 03:21:38 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amy Jo Kim",
      "screen_name" : "amyjokim",
      "indices" : [ 0, 9 ],
      "id_str" : "780991",
      "id" : 780991
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "240278734043758592",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7864993259, -122.4146010534 ]
  },
  "id_str" : "240282485395705856",
  "in_reply_to_user_id" : 780991,
  "text" : "@amyjokim I disagree. A/B tests can only teach you about short term value. Taken to the extreme they create addictive, but ugly, games.",
  "id" : 240282485395705856,
  "in_reply_to_status_id" : 240278734043758592,
  "created_at" : "Tue Aug 28 02:59:43 +0000 2012",
  "in_reply_to_screen_name" : "amyjokim",
  "in_reply_to_user_id_str" : "780991",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7861449402, -122.4135519615 ]
  },
  "id_str" : "240276748602859522",
  "text" : "You have 1 new tweet.",
  "id" : 240276748602859522,
  "created_at" : "Tue Aug 28 02:36:55 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cap Watkins",
      "screen_name" : "cap",
      "indices" : [ 20, 24 ],
      "id_str" : "2182141",
      "id" : 2182141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 65 ],
      "url" : "http://t.co/YnTSBzo7",
      "expanded_url" : "http://blog.capwatkins.com/curiosity-required",
      "display_url" : "blog.capwatkins.com/curiosity-requ…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "240256629306695680",
  "text" : "Great post, Cap. RT @cap: Curiosity Required http://t.co/YnTSBzo7",
  "id" : 240256629306695680,
  "created_at" : "Tue Aug 28 01:16:58 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Klout",
      "screen_name" : "klout",
      "indices" : [ 21, 27 ],
      "id_str" : "15134782",
      "id" : 15134782
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/busterbenson/status/240229814995410945/photo/1",
      "indices" : [ 102, 122 ],
      "url" : "http://t.co/XomKjURO",
      "media_url" : "http://pbs.twimg.com/media/A1V3vnPCYAEU4yv.jpg",
      "id_str" : "240229815003799553",
      "id" : 240229815003799553,
      "media_url_https" : "https://pbs.twimg.com/media/A1V3vnPCYAEU4yv.jpg",
      "sizes" : [ {
        "h" : 1491,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1864,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 495,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 874,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com/XomKjURO"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "240229814995410945",
  "text" : "Oops, looks like the @klout preview of my profile page was inaccessible to most. Here’s a screenshot: http://t.co/XomKjURO",
  "id" : 240229814995410945,
  "created_at" : "Mon Aug 27 23:30:27 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Cottrell",
      "screen_name" : "rgcottrell",
      "indices" : [ 0, 11 ],
      "id_str" : "752553",
      "id" : 752553
    }, {
      "name" : "Klout",
      "screen_name" : "klout",
      "indices" : [ 122, 128 ],
      "id_str" : "15134782",
      "id" : 15134782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "240220299923177473",
  "geo" : {
  },
  "id_str" : "240222347829858304",
  "in_reply_to_user_id" : 752553,
  "text" : "@rgcottrell Oops, I thought I tested the logged out version of that page, but apparently it re-logged somehow. Sorry! /cc @klout",
  "id" : 240222347829858304,
  "in_reply_to_status_id" : 240220299923177473,
  "created_at" : "Mon Aug 27 23:00:45 +0000 2012",
  "in_reply_to_screen_name" : "rgcottrell",
  "in_reply_to_user_id_str" : "752553",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Klout",
      "screen_name" : "klout",
      "indices" : [ 38, 44 ],
      "id_str" : "15134782",
      "id" : 15134782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 128 ],
      "url" : "http://t.co/VSYKEZ2B",
      "expanded_url" : "http://preview.klout.com/#/busterbenson",
      "display_url" : "preview.klout.com/#/busterbenson"
    } ]
  },
  "geo" : {
  },
  "id_str" : "240212734468313088",
  "text" : "Woah, I actually sort of love the new @klout profile pages. It only shows best stuff from various accounts: http://t.co/VSYKEZ2B",
  "id" : 240212734468313088,
  "created_at" : "Mon Aug 27 22:22:33 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anil Dash",
      "screen_name" : "anildash",
      "indices" : [ 3, 12 ],
      "id_str" : "36823",
      "id" : 36823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "240209719443210241",
  "text" : "RT @anildash: Don't like the obsolescence of \"brontosaurus\" &amp; \"triceratops\"? Lament Pluto's demotion from planet? Perhaps religion i ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "240145334892908544",
    "text" : "Don't like the obsolescence of \"brontosaurus\" &amp; \"triceratops\"? Lament Pluto's demotion from planet? Perhaps religion is the science for you!",
    "id" : 240145334892908544,
    "created_at" : "Mon Aug 27 17:54:44 +0000 2012",
    "user" : {
      "name" : "Anil Dash",
      "screen_name" : "anildash",
      "protected" : false,
      "id_str" : "36823",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2819125443/08240a3283301594794bcf6333ce8e6f_normal.png",
      "id" : 36823,
      "verified" : true
    }
  },
  "id" : 240209719443210241,
  "created_at" : "Mon Aug 27 22:10:34 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Damon Cortesi",
      "screen_name" : "dacort",
      "indices" : [ 0, 7 ],
      "id_str" : "99723",
      "id" : 99723
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "240153327386652673",
  "geo" : {
  },
  "id_str" : "240156184844312577",
  "in_reply_to_user_id" : 99723,
  "text" : "@dacort Yeah, it seemed really fishy from the start and was surprised people took them at their words. You could do much better!",
  "id" : 240156184844312577,
  "in_reply_to_status_id" : 240153327386652673,
  "created_at" : "Mon Aug 27 18:37:51 +0000 2012",
  "in_reply_to_screen_name" : "dacort",
  "in_reply_to_user_id_str" : "99723",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Willo O'Brien",
      "screen_name" : "WilloToons",
      "indices" : [ 0, 11 ],
      "id_str" : "772386",
      "id" : 772386
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "240149941954158592",
  "geo" : {
  },
  "id_str" : "240150305419968514",
  "in_reply_to_user_id" : 772386,
  "text" : "@WilloToons That first picture is priceless! Well done.",
  "id" : 240150305419968514,
  "in_reply_to_status_id" : 240149941954158592,
  "created_at" : "Mon Aug 27 18:14:29 +0000 2012",
  "in_reply_to_screen_name" : "WilloToons",
  "in_reply_to_user_id_str" : "772386",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barack Obama",
      "screen_name" : "BarackObama",
      "indices" : [ 21, 33 ],
      "id_str" : "813286",
      "id" : 813286
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 139 ],
      "url" : "http://t.co/45hS4Oi2",
      "expanded_url" : "http://www.buzzfeed.com/jwherrman/your-twitter-followers-arent-fake-theyre-just-s",
      "display_url" : "buzzfeed.com/jwherrman/your…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "240150060342599681",
  "text" : "I had suspected that @BarackObama’s 70% “fake followers” number was wrong… I guess that means Mitt’s probably are too: http://t.co/45hS4Oi2",
  "id" : 240150060342599681,
  "created_at" : "Mon Aug 27 18:13:30 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ArielMeadowStallings",
      "screen_name" : "OffbeatAriel",
      "indices" : [ 0, 13 ],
      "id_str" : "14095370",
      "id" : 14095370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 88 ],
      "url" : "http://t.co/NIZNL64k",
      "expanded_url" : "http://mirrorproject.com/mirror/24940/",
      "display_url" : "mirrorproject.com/mirror/24940/"
    } ]
  },
  "in_reply_to_status_id_str" : "240112869360930816",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7133123391, -122.4515867886 ]
  },
  "id_str" : "240119676745695232",
  "in_reply_to_user_id" : 14095370,
  "text" : "@OffbeatAriel Just babies! I love this one of you, and the caption: http://t.co/NIZNL64k",
  "id" : 240119676745695232,
  "in_reply_to_status_id" : 240112869360930816,
  "created_at" : "Mon Aug 27 16:12:46 +0000 2012",
  "in_reply_to_screen_name" : "OffbeatAriel",
  "in_reply_to_user_id_str" : "14095370",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 75 ],
      "url" : "http://t.co/cyi83yiG",
      "expanded_url" : "http://4sq.com/TjcVa0",
      "display_url" : "4sq.com/TjcVa0"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.6170869303, -122.3825454712 ]
  },
  "id_str" : "240112322398543873",
  "text" : "Hello SF! Here til Fri. (@ SFO Terminal 2 w/ 4 others) http://t.co/cyi83yiG",
  "id" : 240112322398543873,
  "created_at" : "Mon Aug 27 15:43:33 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Heather Champ",
      "screen_name" : "hchamp",
      "indices" : [ 43, 50 ],
      "id_str" : "14701006",
      "id" : 14701006
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 114 ],
      "url" : "http://t.co/2vCHJ9NP",
      "expanded_url" : "http://mirrorproject.com/search/?q=Erik+Benson",
      "display_url" : "mirrorproject.com/search/?q=Erik…"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.6172716728, -122.3824568822 ]
  },
  "id_str" : "240110907370393600",
  "text" : "Just found my 2001, 2002, and 2003 self in @hchamp's relaunched Mirror Project. Welcome back!\nhttp://t.co/2vCHJ9NP",
  "id" : 240110907370393600,
  "created_at" : "Mon Aug 27 15:37:56 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Richards",
      "screen_name" : "loserboy",
      "indices" : [ 32, 41 ],
      "id_str" : "15703753",
      "id" : 15703753
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.6172427468, -122.3825092366 ]
  },
  "id_str" : "240110099715215360",
  "text" : "I hope it gets drunk tonight RT @loserboy: Pearl Jam's Ten was released 21 years ago today",
  "id" : 240110099715215360,
  "created_at" : "Mon Aug 27 15:34:43 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 92 ],
      "url" : "http://t.co/ew8TWsDD",
      "expanded_url" : "http://4sq.com/NRa1fQ",
      "display_url" : "4sq.com/NRa1fQ"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.4436465828, -122.3025941849 ]
  },
  "id_str" : "240051376917454848",
  "text" : "Sleeeeepy... (@ Seattle-Tacoma International Airport (SEA) w/ 6 others) http://t.co/ew8TWsDD",
  "id" : 240051376917454848,
  "created_at" : "Mon Aug 27 11:41:22 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ArielMeadowStallings",
      "screen_name" : "OffbeatAriel",
      "indices" : [ 0, 13 ],
      "id_str" : "14095370",
      "id" : 14095370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "239933513858707458",
  "geo" : {
  },
  "id_str" : "239937612842934272",
  "in_reply_to_user_id" : 14095370,
  "text" : "@OffbeatAriel I couldn't find anything in there that I don't think will happen.",
  "id" : 239937612842934272,
  "in_reply_to_status_id" : 239933513858707458,
  "created_at" : "Mon Aug 27 04:09:19 +0000 2012",
  "in_reply_to_screen_name" : "OffbeatAriel",
  "in_reply_to_user_id_str" : "14095370",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ArielMeadowStallings",
      "screen_name" : "OffbeatAriel",
      "indices" : [ 16, 29 ],
      "id_str" : "14095370",
      "id" : 14095370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 109 ],
      "url" : "https://t.co/hUOFqMbj",
      "expanded_url" : "https://vimeo.com/46304267",
      "display_url" : "vimeo.com/46304267"
    } ]
  },
  "geo" : {
  },
  "id_str" : "239937257254027264",
  "text" : "I'd buy one. MT @OffbeatAriel: HOLY FUCK THIS IS AMAZING AND JUST BLEW MY MIND: [video] https://t.co/hUOFqMbj",
  "id" : 239937257254027264,
  "created_at" : "Mon Aug 27 04:07:54 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagr.am\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 64 ],
      "url" : "http://t.co/A89Zoz7i",
      "expanded_url" : "http://instagr.am/p/O0ROjqI0AA/",
      "display_url" : "instagr.am/p/O0ROjqI0AA/"
    } ]
  },
  "geo" : {
  },
  "id_str" : "239929829401714688",
  "text" : "Niko, after reviewing the photo: \"Post it!\" http://t.co/A89Zoz7i",
  "id" : 239929829401714688,
  "created_at" : "Mon Aug 27 03:38:23 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Santangelo",
      "screen_name" : "endquote",
      "indices" : [ 0, 9 ],
      "id_str" : "408",
      "id" : 408
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "239837977386291200",
  "geo" : {
  },
  "id_str" : "239880277466431488",
  "in_reply_to_user_id" : 408,
  "text" : "@endquote Try to draw it in a way that you think seems most interesting. What's the data?",
  "id" : 239880277466431488,
  "in_reply_to_status_id" : 239837977386291200,
  "created_at" : "Mon Aug 27 00:21:29 +0000 2012",
  "in_reply_to_screen_name" : "endquote",
  "in_reply_to_user_id_str" : "408",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TomoGuides",
      "screen_name" : "TomoGuides",
      "indices" : [ 0, 11 ],
      "id_str" : "487717932",
      "id" : 487717932
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "239794608840769537",
  "geo" : {
  },
  "id_str" : "239796488832692224",
  "in_reply_to_user_id" : 487717932,
  "text" : "@TomoGuides A whole lamb brain cooked in butter, delivered in aluminum foil.",
  "id" : 239796488832692224,
  "in_reply_to_status_id" : 239794608840769537,
  "created_at" : "Sun Aug 26 18:48:32 +0000 2012",
  "in_reply_to_screen_name" : "TomoGuides",
  "in_reply_to_user_id_str" : "487717932",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joi Ito",
      "screen_name" : "Joi",
      "indices" : [ 23, 27 ],
      "id_str" : "691353",
      "id" : 691353
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http://t.co/zwmcXRrE",
      "expanded_url" : "http://www.theatlantic.com/international/archive/2012/08/gangnam-style-dissected-the-subversive-message-within-south-koreas-music-video-sensation/261462/#.UDosvs727iI.twitter",
      "display_url" : "theatlantic.com/international/…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "239780481460215808",
  "text" : "Catching up on this RT @Joi: Gangnam Style Dissected: The Subversive Message Within South Korea's Music Video Sensation http://t.co/zwmcXRrE",
  "id" : 239780481460215808,
  "created_at" : "Sun Aug 26 17:44:56 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TechCrunch",
      "screen_name" : "TechCrunch",
      "indices" : [ 3, 14 ],
      "id_str" : "816653",
      "id" : 816653
    }, {
      "name" : "Nir Eyal",
      "screen_name" : "nireyal",
      "indices" : [ 67, 75 ],
      "id_str" : "14097392",
      "id" : 14097392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 63 ],
      "url" : "http://t.co/acgTzWKR",
      "expanded_url" : "http://tcrn.ch/NTr6S8",
      "display_url" : "tcrn.ch/NTr6S8"
    } ]
  },
  "geo" : {
  },
  "id_str" : "239773248458473472",
  "text" : "RT @TechCrunch: Where Have The Users Gone? http://t.co/acgTzWKR by @nireyal",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nir Eyal",
        "screen_name" : "nireyal",
        "indices" : [ 51, 59 ],
        "id_str" : "14097392",
        "id" : 14097392
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 27, 47 ],
        "url" : "http://t.co/acgTzWKR",
        "expanded_url" : "http://tcrn.ch/NTr6S8",
        "display_url" : "tcrn.ch/NTr6S8"
      } ]
    },
    "geo" : {
    },
    "id_str" : "239765316601802752",
    "text" : "Where Have The Users Gone? http://t.co/acgTzWKR by @nireyal",
    "id" : 239765316601802752,
    "created_at" : "Sun Aug 26 16:44:40 +0000 2012",
    "user" : {
      "name" : "TechCrunch",
      "screen_name" : "TechCrunch",
      "protected" : false,
      "id_str" : "816653",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2176846885/-5-1_normal.jpeg",
      "id" : 816653,
      "verified" : true
    }
  },
  "id" : 239773248458473472,
  "created_at" : "Sun Aug 26 17:16:11 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Hogg",
      "screen_name" : "cwhogg",
      "indices" : [ 0, 7 ],
      "id_str" : "15727738",
      "id" : 15727738
    }, {
      "name" : "Nir Eyal",
      "screen_name" : "nireyal",
      "indices" : [ 8, 16 ],
      "id_str" : "14097392",
      "id" : 14097392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "239760852041998336",
  "geo" : {
  },
  "id_str" : "239772537859477504",
  "in_reply_to_user_id" : 15727738,
  "text" : "@cwhogg @nireyal I'll second that. Great writing recently, Nir.",
  "id" : 239772537859477504,
  "in_reply_to_status_id" : 239760852041998336,
  "created_at" : "Sun Aug 26 17:13:22 +0000 2012",
  "in_reply_to_screen_name" : "cwhogg",
  "in_reply_to_user_id_str" : "15727738",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Reichhold",
      "screen_name" : "jreichhold",
      "indices" : [ 0, 11 ],
      "id_str" : "14934401",
      "id" : 14934401
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "239737965511860226",
  "geo" : {
  },
  "id_str" : "239756023437602818",
  "in_reply_to_user_id" : 14934401,
  "text" : "@jreichhold Agreed. It had been many years since my last ride, but it was packed and enjoyable.",
  "id" : 239756023437602818,
  "in_reply_to_status_id" : 239737965511860226,
  "created_at" : "Sun Aug 26 16:07:45 +0000 2012",
  "in_reply_to_screen_name" : "jreichhold",
  "in_reply_to_user_id_str" : "14934401",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian Sefferman",
      "screen_name" : "iseff",
      "indices" : [ 3, 9 ],
      "id_str" : "5500",
      "id" : 5500
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 57 ],
      "url" : "http://t.co/13Jo1y1J",
      "expanded_url" : "http://www.treysmithblog.com/the-fall-of-angry-birds/",
      "display_url" : "treysmithblog.com/the-fall-of-an…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "239750797607460864",
  "text" : "RT @iseff: The fall of Angry Birds - http://t.co/13Jo1y1J great analysis of free to play vs freemium in the app store.",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 26, 46 ],
        "url" : "http://t.co/13Jo1y1J",
        "expanded_url" : "http://www.treysmithblog.com/the-fall-of-angry-birds/",
        "display_url" : "treysmithblog.com/the-fall-of-an…"
      } ]
    },
    "geo" : {
    },
    "id_str" : "239737469115985922",
    "text" : "The fall of Angry Birds - http://t.co/13Jo1y1J great analysis of free to play vs freemium in the app store.",
    "id" : 239737469115985922,
    "created_at" : "Sun Aug 26 14:54:01 +0000 2012",
    "user" : {
      "name" : "Ian Sefferman",
      "screen_name" : "iseff",
      "protected" : false,
      "id_str" : "5500",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2380049826/t07qklm724ma7698twqa_normal.jpeg",
      "id" : 5500,
      "verified" : false
    }
  },
  "id" : 239750797607460864,
  "created_at" : "Sun Aug 26 15:46:59 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 0, 9 ],
      "id_str" : "761628",
      "id" : 761628
    }, {
      "name" : "harryh",
      "screen_name" : "harryh",
      "indices" : [ 10, 17 ],
      "id_str" : "4558",
      "id" : 4558
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "239592098846875648",
  "geo" : {
  },
  "id_str" : "239593086815182848",
  "in_reply_to_user_id" : 761628,
  "text" : "@RickWebb @harryh The key thing being, Apple is in the moral wrong for exercising these patents, even if it's upheld by law.",
  "id" : 239593086815182848,
  "in_reply_to_status_id" : 239592098846875648,
  "created_at" : "Sun Aug 26 05:20:17 +0000 2012",
  "in_reply_to_screen_name" : "RickWebb",
  "in_reply_to_user_id_str" : "761628",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "harryh",
      "screen_name" : "harryh",
      "indices" : [ 0, 7 ],
      "id_str" : "4558",
      "id" : 4558
    }, {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 8, 17 ],
      "id_str" : "761628",
      "id" : 761628
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "239552240468242433",
  "geo" : {
  },
  "id_str" : "239591926368698368",
  "in_reply_to_user_id" : 4558,
  "text" : "@harryh @rickwebb My instinct was to be happy for Apple but after thinking about it I'm agreeing with Harry on this one. Screw patents.",
  "id" : 239591926368698368,
  "in_reply_to_status_id" : 239552240468242433,
  "created_at" : "Sun Aug 26 05:15:41 +0000 2012",
  "in_reply_to_screen_name" : "harryh",
  "in_reply_to_user_id_str" : "4558",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagr.am\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 129 ],
      "url" : "http://t.co/sfVBi7e9",
      "expanded_url" : "http://instagr.am/p/OxsyXPo0FR/",
      "display_url" : "instagr.am/p/OxsyXPo0FR/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6212357513, -122.349886894 ]
  },
  "id_str" : "239568311279554561",
  "text" : "8:36pm Taking the monorail to and from dinner blew this  @ Seattle Center Monorail  - Seattle Center Station http://t.co/sfVBi7e9",
  "id" : 239568311279554561,
  "created_at" : "Sun Aug 26 03:41:51 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "April Schiller",
      "screen_name" : "the_april",
      "indices" : [ 0, 10 ],
      "id_str" : "16644937",
      "id" : 16644937
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "239485395895717888",
  "geo" : {
  },
  "id_str" : "239486027788582912",
  "in_reply_to_user_id" : 16644937,
  "text" : "@the_april Serve 'em over easy with some toast?",
  "id" : 239486027788582912,
  "in_reply_to_status_id" : 239485395895717888,
  "created_at" : "Sat Aug 25 22:14:53 +0000 2012",
  "in_reply_to_screen_name" : "the_april",
  "in_reply_to_user_id_str" : "16644937",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "April Schiller",
      "screen_name" : "the_april",
      "indices" : [ 0, 10 ],
      "id_str" : "16644937",
      "id" : 16644937
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "239484119019569152",
  "geo" : {
  },
  "id_str" : "239484882538078208",
  "in_reply_to_user_id" : 16644937,
  "text" : "@the_april In a soup would definitely make it easier to disassociate. If you find it somewhere I’d be in for going.",
  "id" : 239484882538078208,
  "in_reply_to_status_id" : 239484119019569152,
  "created_at" : "Sat Aug 25 22:10:20 +0000 2012",
  "in_reply_to_screen_name" : "the_april",
  "in_reply_to_user_id_str" : "16644937",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "April Schiller",
      "screen_name" : "the_april",
      "indices" : [ 0, 10 ],
      "id_str" : "16644937",
      "id" : 16644937
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "239483016173457408",
  "geo" : {
  },
  "id_str" : "239483798667001856",
  "in_reply_to_user_id" : 16644937,
  "text" : "@the_april I’m sure they do. I generally think I could eat anything, but this would be difficult without a big pep talk.",
  "id" : 239483798667001856,
  "in_reply_to_status_id" : 239483016173457408,
  "created_at" : "Sat Aug 25 22:06:01 +0000 2012",
  "in_reply_to_screen_name" : "the_april",
  "in_reply_to_user_id_str" : "16644937",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/instagram/id389801252?mt=8&uo=4\" rel=\"nofollow\">Instagram on iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Karnjanaprakorn",
      "screen_name" : "mikekarnj",
      "indices" : [ 54, 64 ],
      "id_str" : "5901702",
      "id" : 5901702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http://t.co/pP0nQsl7",
      "expanded_url" : "http://instagr.am/p/Ow_LSak9uv/",
      "display_url" : "instagr.am/p/Ow_LSak9uv/"
    } ]
  },
  "geo" : {
  },
  "id_str" : "239479271356252160",
  "text" : "Not sure I could eat balut. http://t.co/pP0nQsl7 /via @mikekarnj",
  "id" : 239479271356252160,
  "created_at" : "Sat Aug 25 21:48:02 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lars Hinrichs",
      "screen_name" : "LarsHinrichs",
      "indices" : [ 3, 16 ],
      "id_str" : "4774421",
      "id" : 4774421
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "239476391035412480",
  "text" : "RT @LarsHinrichs: Q: How many geeks does it take to ruin a joke? A: You mean nerd, not geek. And not joke, but riddle. Proceed.",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "237610447375839233",
    "text" : "Q: How many geeks does it take to ruin a joke? A: You mean nerd, not geek. And not joke, but riddle. Proceed.",
    "id" : 237610447375839233,
    "created_at" : "Mon Aug 20 18:01:59 +0000 2012",
    "user" : {
      "name" : "Lars Hinrichs",
      "screen_name" : "LarsHinrichs",
      "protected" : false,
      "id_str" : "4774421",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1438399524/Lars_normal.jpg",
      "id" : 4774421,
      "verified" : false
    }
  },
  "id" : 239476391035412480,
  "created_at" : "Sat Aug 25 21:36:35 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Neil deGrasse Tyson",
      "screen_name" : "neiltyson",
      "indices" : [ 3, 13 ],
      "id_str" : "19725644",
      "id" : 19725644
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "239476183119568896",
  "text" : "RT @neiltyson: Apollo 11, July 1969.  No other act of human exploration ever laid a plaque saying \"We Come In Peace For All Mankind\"",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "239474562662793217",
    "text" : "Apollo 11, July 1969.  No other act of human exploration ever laid a plaque saying \"We Come In Peace For All Mankind\"",
    "id" : 239474562662793217,
    "created_at" : "Sat Aug 25 21:29:19 +0000 2012",
    "user" : {
      "name" : "Neil deGrasse Tyson",
      "screen_name" : "neiltyson",
      "protected" : false,
      "id_str" : "19725644",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/74188698/NeilTysonOriginsA-Crop_normal.jpg",
      "id" : 19725644,
      "verified" : true
    }
  },
  "id" : 239476183119568896,
  "created_at" : "Sat Aug 25 21:35:45 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "239437585867472896",
  "geo" : {
  },
  "id_str" : "239438791385939968",
  "in_reply_to_user_id" : 220226736,
  "text" : "@digitalmiss Okay that’s probably okay.",
  "id" : 239438791385939968,
  "in_reply_to_status_id" : 239437585867472896,
  "created_at" : "Sat Aug 25 19:07:11 +0000 2012",
  "in_reply_to_screen_name" : "KristyT",
  "in_reply_to_user_id_str" : "220226736",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "239431629188239360",
  "geo" : {
  },
  "id_str" : "239437501352263681",
  "in_reply_to_user_id" : 220226736,
  "text" : "@digitalmiss I don’t think so. :) Frying disqualifies the plant.",
  "id" : 239437501352263681,
  "in_reply_to_status_id" : 239431629188239360,
  "created_at" : "Sat Aug 25 19:02:03 +0000 2012",
  "in_reply_to_screen_name" : "KristyT",
  "in_reply_to_user_id_str" : "220226736",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Koloskov",
      "screen_name" : "xenocid",
      "indices" : [ 0, 8 ],
      "id_str" : "7777252",
      "id" : 7777252
    }, {
      "name" : "Alan Hogan",
      "screen_name" : "AlanHogan",
      "indices" : [ 9, 19 ],
      "id_str" : "13801912",
      "id" : 13801912
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "239409651358261249",
  "geo" : {
  },
  "id_str" : "239416687596818433",
  "in_reply_to_user_id" : 7777252,
  "text" : "@xenocid @AlanHogan I'm going to open source Budge, but that's about it. Any interest in taking a look and/or re-launching it?",
  "id" : 239416687596818433,
  "in_reply_to_status_id" : 239409651358261249,
  "created_at" : "Sat Aug 25 17:39:21 +0000 2012",
  "in_reply_to_screen_name" : "xenocid",
  "in_reply_to_user_id_str" : "7777252",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Foursquare",
      "screen_name" : "foursquare",
      "indices" : [ 54, 65 ],
      "id_str" : "14120151",
      "id" : 14120151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 128 ],
      "url" : "http://t.co/Zey1ujXo",
      "expanded_url" : "http://4sq.com/NrWXYG",
      "display_url" : "4sq.com/NrWXYG"
    } ]
  },
  "geo" : {
  },
  "id_str" : "239225845137412096",
  "text" : "I just reached Level 2 of the \"Trainspotter\" badge on @foursquare. I’ve checked in at 5 different stations! http://t.co/Zey1ujXo",
  "id" : 239225845137412096,
  "created_at" : "Sat Aug 25 05:01:00 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cory Campbell",
      "screen_name" : "coryjcampbell",
      "indices" : [ 0, 14 ],
      "id_str" : "54029411",
      "id" : 54029411
    }, {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 15, 25 ],
      "id_str" : "7362142",
      "id" : 7362142
    }, {
      "name" : "Radiolab",
      "screen_name" : "Radiolab",
      "indices" : [ 26, 35 ],
      "id_str" : "28583197",
      "id" : 28583197
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "239198861262999552",
  "geo" : {
  },
  "id_str" : "239220808667500544",
  "in_reply_to_user_id" : 54029411,
  "text" : "@coryjcampbell @kellianne @Radiolab Ooh, are there still tickets??",
  "id" : 239220808667500544,
  "in_reply_to_status_id" : 239198861262999552,
  "created_at" : "Sat Aug 25 04:40:59 +0000 2012",
  "in_reply_to_screen_name" : "coryjcampbell",
  "in_reply_to_user_id_str" : "54029411",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 89 ],
      "url" : "http://t.co/8NfIg9yY",
      "expanded_url" : "http://flic.kr/p/cY81DE",
      "display_url" : "flic.kr/p/cY81DE"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.441833, -122.309667 ]
  },
  "id_str" : "239220762668584961",
  "text" : "8:36pm Was in flight trolling myself by watching Sean Hannity on Fox http://t.co/8NfIg9yY",
  "id" : 239220762668584961,
  "created_at" : "Sat Aug 25 04:40:48 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Ward",
      "screen_name" : "BenWard",
      "indices" : [ 0, 8 ],
      "id_str" : "12249",
      "id" : 12249
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 94 ],
      "url" : "http://t.co/d4uyNcrn",
      "expanded_url" : "http://busterbenson.com",
      "display_url" : "busterbenson.com"
    } ]
  },
  "in_reply_to_status_id_str" : "239189545290186752",
  "geo" : {
  },
  "id_str" : "239190759692197888",
  "in_reply_to_user_id" : 12249,
  "text" : "@BenWard Ooh, yeah, that’s not gonna be fun at all. :) I did the same for http://t.co/d4uyNcrn a while ago.",
  "id" : 239190759692197888,
  "in_reply_to_status_id" : 239189545290186752,
  "created_at" : "Sat Aug 25 02:41:35 +0000 2012",
  "in_reply_to_screen_name" : "BenWard",
  "in_reply_to_user_id_str" : "12249",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 16, 26 ],
      "id_str" : "7362142",
      "id" : 7362142
    }, {
      "name" : "Radiolab",
      "screen_name" : "Radiolab",
      "indices" : [ 43, 52 ],
      "id_str" : "28583197",
      "id" : 28583197
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "239190241800507392",
  "text" : "Really sad that @kellianne is going to see @radiolab without me tonight (I land right as it’s ending).",
  "id" : 239190241800507392,
  "created_at" : "Sat Aug 25 02:39:32 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Ward",
      "screen_name" : "BenWard",
      "indices" : [ 0, 8 ],
      "id_str" : "12249",
      "id" : 12249
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "239187753261219840",
  "geo" : {
  },
  "id_str" : "239189002987634688",
  "in_reply_to_user_id" : 12249,
  "text" : "@BenWard Where are you exporting your blog from and to?",
  "id" : 239189002987634688,
  "in_reply_to_status_id" : 239187753261219840,
  "created_at" : "Sat Aug 25 02:34:36 +0000 2012",
  "in_reply_to_screen_name" : "BenWard",
  "in_reply_to_user_id_str" : "12249",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Allen M. Murray",
      "screen_name" : "allenmmurray",
      "indices" : [ 65, 78 ],
      "id_str" : "22118364",
      "id" : 22118364
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 118 ],
      "url" : "http://t.co/srRLArfx",
      "expanded_url" : "http://www.seattleweekly.com/1998-07-15/news/how-i-escaped-from-amazon-cult/",
      "display_url" : "seattleweekly.com/1998-07-15/new…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "239188307035176963",
  "text" : "Here’s the article about Amazon from 14 years ago, complete with @allenmmurray in a straitjacket: http://t.co/srRLArfx",
  "id" : 239188307035176963,
  "created_at" : "Sat Aug 25 02:31:50 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Allen M. Murray",
      "screen_name" : "allenmmurray",
      "indices" : [ 0, 13 ],
      "id_str" : "22118364",
      "id" : 22118364
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "239184999704850433",
  "geo" : {
  },
  "id_str" : "239185523481128960",
  "in_reply_to_user_id" : 22118364,
  "text" : "@allenmmurray That’s awesome! Which magazine was it? I can’t find the link anywhere.",
  "id" : 239185523481128960,
  "in_reply_to_status_id" : 239184999704850433,
  "created_at" : "Sat Aug 25 02:20:47 +0000 2012",
  "in_reply_to_screen_name" : "allenmmurray",
  "in_reply_to_user_id_str" : "22118364",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "239183996041437185",
  "text" : "This first week at Twitter reminded me of when I joined Amazon in 1998 and everyone was freaking out about the Amazon Dot Bomb article.",
  "id" : 239183996041437185,
  "created_at" : "Sat Aug 25 02:14:43 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http://t.co/d8mMALjJ",
      "expanded_url" : "http://4sq.com/PhSp8J",
      "display_url" : "4sq.com/PhSp8J"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.6164240527, -122.3862791061 ]
  },
  "id_str" : "239181260671561728",
  "text" : "Back to Seattle for the weekend. I think Niko is learning to drive now. (@ San Francisco International Airport (SFO)) http://t.co/d8mMALjJ",
  "id" : 239181260671561728,
  "created_at" : "Sat Aug 25 02:03:50 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "harryh",
      "screen_name" : "harryh",
      "indices" : [ 0, 7 ],
      "id_str" : "4558",
      "id" : 4558
    }, {
      "name" : "Camille Fournier",
      "screen_name" : "skamille",
      "indices" : [ 8, 17 ],
      "id_str" : "24257941",
      "id" : 24257941
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "239163926024187904",
  "geo" : {
  },
  "id_str" : "239173546235027457",
  "in_reply_to_user_id" : 4558,
  "text" : "@harryh @skamille Ha I read it as a parameter string too.",
  "id" : 239173546235027457,
  "in_reply_to_status_id" : 239163926024187904,
  "created_at" : "Sat Aug 25 01:33:11 +0000 2012",
  "in_reply_to_screen_name" : "harryh",
  "in_reply_to_user_id_str" : "4558",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tara Tiger Brown ",
      "screen_name" : "tara",
      "indices" : [ 0, 5 ],
      "id_str" : "10959642",
      "id" : 10959642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "239161012568342529",
  "geo" : {
  },
  "id_str" : "239162884083572736",
  "in_reply_to_user_id" : 10959642,
  "text" : "@tara Thanks! We are, but not immediately.",
  "id" : 239162884083572736,
  "in_reply_to_status_id" : 239161012568342529,
  "created_at" : "Sat Aug 25 00:50:49 +0000 2012",
  "in_reply_to_screen_name" : "tara",
  "in_reply_to_user_id_str" : "10959642",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Sippey",
      "screen_name" : "sippey",
      "indices" : [ 25, 32 ],
      "id_str" : "4711",
      "id" : 4711
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "239160368746860544",
  "text" : "Day 5 at Twitter: thanks @sippey for embarrassing me in front of the entire company. Fully expect “kick me” signs on my back next week.",
  "id" : 239160368746860544,
  "created_at" : "Sat Aug 25 00:40:49 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "238859557424726016",
  "text" : "Communicating truthfully won’t, by itself, build trust. You have to also show that you hear and care about the people you’re talking with.",
  "id" : 238859557424726016,
  "created_at" : "Fri Aug 24 04:45:30 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Dean",
      "screen_name" : "dandean",
      "indices" : [ 0, 8 ],
      "id_str" : "9525212",
      "id" : 9525212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "238851866920894464",
  "geo" : {
  },
  "id_str" : "238857885684224000",
  "in_reply_to_user_id" : 9525212,
  "text" : "@dandean I love the cuisine at the Spaghetti Factory. Especially the authentic “hearty potions” bonus sizing option.",
  "id" : 238857885684224000,
  "in_reply_to_status_id" : 238851866920894464,
  "created_at" : "Fri Aug 24 04:38:52 +0000 2012",
  "in_reply_to_screen_name" : "dandean",
  "in_reply_to_user_id_str" : "9525212",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 65 ],
      "url" : "http://t.co/9cYIvSIq",
      "expanded_url" : "http://flic.kr/p/cXyhsh",
      "display_url" : "flic.kr/p/cXyhsh"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.777166, -122.415834 ]
  },
  "id_str" : "238843294233276416",
  "text" : "8:36pm Bathroom before heading to my hometel http://t.co/9cYIvSIq",
  "id" : 238843294233276416,
  "created_at" : "Fri Aug 24 03:40:53 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katie Couric",
      "screen_name" : "katiecouric",
      "indices" : [ 18, 30 ],
      "id_str" : "18812301",
      "id" : 18812301
    }, {
      "name" : "Tiffany Shlain",
      "screen_name" : "tiffanyshlain",
      "indices" : [ 39, 53 ],
      "id_str" : "9590262",
      "id" : 9590262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 115 ],
      "url" : "http://t.co/NqYT1lwZ",
      "expanded_url" : "http://www.youtube.com/watch?v=fzZ1Gl5UfE0",
      "display_url" : "youtube.com/watch?v=fzZ1Gl…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "238840743702196224",
  "text" : "Day 4 at Twitter: @katiecouric visits, @tiffanyshlain convinces me to declare interdependence (http://t.co/NqYT1lwZ), and more code-sifting.",
  "id" : 238840743702196224,
  "created_at" : "Fri Aug 24 03:30:45 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://mobile.twitter.com\" rel=\"nofollow\">Mobile Web</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tiffany Shlain",
      "screen_name" : "tiffanyshlain",
      "indices" : [ 29, 43 ],
      "id_str" : "9590262",
      "id" : 9590262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 89 ],
      "url" : "http://t.co/Ouywa5br",
      "expanded_url" : "http://connectedthefilm.com",
      "display_url" : "connectedthefilm.com"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7763854495, -122.4167362644 ]
  },
  "id_str" : "238832183094177792",
  "text" : "\"Declare interdependence.\" - @tiffanyshlain in her great documentary http://t.co/Ouywa5br",
  "id" : 238832183094177792,
  "created_at" : "Fri Aug 24 02:56:44 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aubrey Sabala",
      "screen_name" : "Aubs",
      "indices" : [ 0, 5 ],
      "id_str" : "2781",
      "id" : 2781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "238800684630286336",
  "geo" : {
  },
  "id_str" : "238808975104155648",
  "in_reply_to_user_id" : 2781,
  "text" : "@Aubs I really liked that book!",
  "id" : 238808975104155648,
  "in_reply_to_status_id" : 238800684630286336,
  "created_at" : "Fri Aug 24 01:24:31 +0000 2012",
  "in_reply_to_screen_name" : "Aubs",
  "in_reply_to_user_id_str" : "2781",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew J. Rosenthal",
      "screen_name" : "rosenthal",
      "indices" : [ 0, 10 ],
      "id_str" : "15792969",
      "id" : 15792969
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "238775086180618240",
  "geo" : {
  },
  "id_str" : "238775534748831744",
  "in_reply_to_user_id" : 15792969,
  "text" : "@rosenthal Yup I’ll be here! I am pretty open today and tomorrow afternoon.",
  "id" : 238775534748831744,
  "in_reply_to_status_id" : 238775086180618240,
  "created_at" : "Thu Aug 23 23:11:38 +0000 2012",
  "in_reply_to_screen_name" : "rosenthal",
  "in_reply_to_user_id_str" : "15792969",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Gates",
      "screen_name" : "BillGates",
      "indices" : [ 40, 50 ],
      "id_str" : "50393960",
      "id" : 50393960
    }, {
      "name" : "Gates Foundation",
      "screen_name" : "gatesfoundation",
      "indices" : [ 81, 97 ],
      "id_str" : "17899109",
      "id" : 17899109
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "toiletfair",
      "indices" : [ 98, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 131 ],
      "url" : "http://t.co/wQCWLj24",
      "expanded_url" : "http://b-gat.es/Q5B0nN",
      "display_url" : "b-gat.es/Q5B0nN"
    } ]
  },
  "geo" : {
  },
  "id_str" : "238773791268958209",
  "text" : "Winning re-inventions of the toilet! MT @BillGates: Check out the winners of the @gatesfoundation #toiletfair: http://t.co/wQCWLj24",
  "id" : 238773791268958209,
  "created_at" : "Thu Aug 23 23:04:42 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "238672840436633600",
  "text" : "The new Prismatic iPhone has some really great interaction. My fave so far: flick up lightly to scroll and lock to next story.",
  "id" : 238672840436633600,
  "created_at" : "Thu Aug 23 16:23:34 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "boring",
      "indices" : [ 54, 61 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "238510395717996545",
  "text" : "The truth is out there but it probably has a low CTR. #boring",
  "id" : 238510395717996545,
  "created_at" : "Thu Aug 23 05:38:04 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "238507870558248960",
  "text" : "If you’re baffled by something keep searching for the answer, but be aware: the truth may not be as immediately gratifying as a dog pile.",
  "id" : 238507870558248960,
  "created_at" : "Thu Aug 23 05:28:02 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Cottrell",
      "screen_name" : "rgcottrell",
      "indices" : [ 0, 11 ],
      "id_str" : "752553",
      "id" : 752553
    }, {
      "name" : "Michael McDaniel",
      "screen_name" : "michaelmcdaniel",
      "indices" : [ 12, 28 ],
      "id_str" : "7565162",
      "id" : 7565162
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "238504475558555648",
  "geo" : {
  },
  "id_str" : "238505546179825664",
  "in_reply_to_user_id" : 752553,
  "text" : "@rgcottrell @michaelmcdaniel There are no Suits at Twitter that I’m aware of.",
  "id" : 238505546179825664,
  "in_reply_to_status_id" : 238504475558555648,
  "created_at" : "Thu Aug 23 05:18:48 +0000 2012",
  "in_reply_to_screen_name" : "rgcottrell",
  "in_reply_to_user_id_str" : "752553",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Cottrell",
      "screen_name" : "rgcottrell",
      "indices" : [ 0, 11 ],
      "id_str" : "752553",
      "id" : 752553
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "238503692406501376",
  "geo" : {
  },
  "id_str" : "238504279026061312",
  "in_reply_to_user_id" : 752553,
  "text" : "@rgcottrell The future of tech is anything but certain. Twitter is struggling just as hard for survival as the rest of these companies.",
  "id" : 238504279026061312,
  "in_reply_to_status_id" : 238503692406501376,
  "created_at" : "Thu Aug 23 05:13:45 +0000 2012",
  "in_reply_to_screen_name" : "rgcottrell",
  "in_reply_to_user_id_str" : "752553",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 116 ],
      "url" : "http://t.co/mcDqYMPI",
      "expanded_url" : "http://m.motherjones.com/media/2012/08/problem-men-explaining-things-rebecca-solnit",
      "display_url" : "m.motherjones.com/media/2012/08/…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "238503730981531649",
  "text" : "Men Who Have Answers, aka “the out-and-out confrontational confidence of the totally ignorant…” http://t.co/mcDqYMPI",
  "id" : 238503730981531649,
  "created_at" : "Thu Aug 23 05:11:35 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Cottrell",
      "screen_name" : "rgcottrell",
      "indices" : [ 0, 11 ],
      "id_str" : "752553",
      "id" : 752553
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "238492354523324416",
  "geo" : {
  },
  "id_str" : "238501933495758848",
  "in_reply_to_user_id" : 752553,
  "text" : "@rgcottrell Probably never. But they’re not just messing with devs for fun. There is a long term strategy that’s win-win for all.",
  "id" : 238501933495758848,
  "in_reply_to_status_id" : 238492354523324416,
  "created_at" : "Thu Aug 23 05:04:26 +0000 2012",
  "in_reply_to_screen_name" : "rgcottrell",
  "in_reply_to_user_id_str" : "752553",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael McDaniel",
      "screen_name" : "michaelmcdaniel",
      "indices" : [ 0, 16 ],
      "id_str" : "7565162",
      "id" : 7565162
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "238492917180801024",
  "geo" : {
  },
  "id_str" : "238501603643125760",
  "in_reply_to_user_id" : 7565162,
  "text" : "@michaelmcdaniel And I do trust the value system if the leadership. It’s why I chose this company in the first place.",
  "id" : 238501603643125760,
  "in_reply_to_status_id" : 238492917180801024,
  "created_at" : "Thu Aug 23 05:03:08 +0000 2012",
  "in_reply_to_screen_name" : "michaelmcdaniel",
  "in_reply_to_user_id_str" : "7565162",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael McDaniel",
      "screen_name" : "michaelmcdaniel",
      "indices" : [ 0, 16 ],
      "id_str" : "7565162",
      "id" : 7565162
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "238492917180801024",
  "geo" : {
  },
  "id_str" : "238501348491014144",
  "in_reply_to_user_id" : 7565162,
  "text" : "@michaelmcdaniel I love a good problem! I don’t know fully what’s happening but I do know that everyone here wants to do the right thing.",
  "id" : 238501348491014144,
  "in_reply_to_status_id" : 238492917180801024,
  "created_at" : "Thu Aug 23 05:02:07 +0000 2012",
  "in_reply_to_screen_name" : "michaelmcdaniel",
  "in_reply_to_user_id_str" : "7565162",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 122 ],
      "url" : "http://t.co/fF49Lxzi",
      "expanded_url" : "http://flic.kr/p/cX21Pf",
      "display_url" : "flic.kr/p/cX21Pf"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.777, -122.415667 ]
  },
  "id_str" : "238487240366510080",
  "text" : "8:36pm At work reading about what friends think of us. Wondering what I can add now that I work here. http://t.co/fF49Lxzi",
  "id" : 238487240366510080,
  "created_at" : "Thu Aug 23 04:06:03 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Santangelo",
      "screen_name" : "endquote",
      "indices" : [ 0, 9 ],
      "id_str" : "408",
      "id" : 408
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "238457731047116801",
  "geo" : {
  },
  "id_str" : "238458367230767104",
  "in_reply_to_user_id" : 408,
  "text" : "@endquote I like code.",
  "id" : 238458367230767104,
  "in_reply_to_status_id" : 238457731047116801,
  "created_at" : "Thu Aug 23 02:11:19 +0000 2012",
  "in_reply_to_screen_name" : "endquote",
  "in_reply_to_user_id_str" : "408",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Santangelo",
      "screen_name" : "endquote",
      "indices" : [ 0, 9 ],
      "id_str" : "408",
      "id" : 408
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "238457649212047360",
  "geo" : {
  },
  "id_str" : "238458191149674496",
  "in_reply_to_user_id" : 408,
  "text" : "@endquote I’ve mentioned it here a couple times, but never really did a big announcement. And yeah, probably moving down in a couple months.",
  "id" : 238458191149674496,
  "in_reply_to_status_id" : 238457649212047360,
  "created_at" : "Thu Aug 23 02:10:37 +0000 2012",
  "in_reply_to_screen_name" : "endquote",
  "in_reply_to_user_id_str" : "408",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "238457831186132992",
  "text" : "Rage rises up when something we care about is threatened. It can be lowered if/when both sides realize they care about the same core things.",
  "id" : 238457831186132992,
  "created_at" : "Thu Aug 23 02:09:11 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "238456238785056768",
  "text" : "Day 3 at Twitter: I started looking through the mountains of code. And it was daunting. My brain needs a hamburger.",
  "id" : 238456238785056768,
  "created_at" : "Thu Aug 23 02:02:52 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Colin Henry",
      "screen_name" : "jchenry",
      "indices" : [ 0, 8 ],
      "id_str" : "113988145",
      "id" : 113988145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "238446365506691073",
  "geo" : {
  },
  "id_str" : "238446691953553408",
  "in_reply_to_user_id" : 113988145,
  "text" : "@jchenry Possibly. I like that people are trying things… it helps find new problems, and gets the next person closer to a solution.",
  "id" : 238446691953553408,
  "in_reply_to_status_id" : 238446365506691073,
  "created_at" : "Thu Aug 23 01:24:56 +0000 2012",
  "in_reply_to_screen_name" : "jchenry",
  "in_reply_to_user_id_str" : "113988145",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Colin Henry",
      "screen_name" : "jchenry",
      "indices" : [ 0, 8 ],
      "id_str" : "113988145",
      "id" : 113988145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "238445466872860672",
  "geo" : {
  },
  "id_str" : "238445815104950273",
  "in_reply_to_user_id" : 113988145,
  "text" : "@jchenry I haven’t looked very closely at it yet, but I think it’s worth watching at least...",
  "id" : 238445815104950273,
  "in_reply_to_status_id" : 238445466872860672,
  "created_at" : "Thu Aug 23 01:21:27 +0000 2012",
  "in_reply_to_screen_name" : "jchenry",
  "in_reply_to_user_id_str" : "113988145",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daring Fireball",
      "screen_name" : "daringfireball",
      "indices" : [ 18, 33 ],
      "id_str" : "10760422",
      "id" : 10760422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 73 ],
      "url" : "http://t.co/KB1gQa9M",
      "expanded_url" : "http://df4.us/k6v",
      "display_url" : "df4.us/k6v"
    } ]
  },
  "geo" : {
  },
  "id_str" : "238441805409026048",
  "text" : "Iiinteresting… RT @daringfireball: Introducing Tent: http://t.co/KB1gQa9M",
  "id" : 238441805409026048,
  "created_at" : "Thu Aug 23 01:05:31 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "238167011388162049",
  "text" : "Just discovered that Moonrise Kingdom is on my hotel movie menu. Really tempted to start it right now…",
  "id" : 238167011388162049,
  "created_at" : "Wed Aug 22 06:53:35 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tanner C",
      "screen_name" : "tannerc",
      "indices" : [ 0, 8 ],
      "id_str" : "9161482",
      "id" : 9161482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "238142227233251328",
  "geo" : {
  },
  "id_str" : "238166376785793024",
  "in_reply_to_user_id" : 9161482,
  "text" : "@tannerc If you know what you want to do, you must do it immediately. Does that work?",
  "id" : 238166376785793024,
  "in_reply_to_status_id" : 238142227233251328,
  "created_at" : "Wed Aug 22 06:51:03 +0000 2012",
  "in_reply_to_screen_name" : "tannerc",
  "in_reply_to_user_id_str" : "9161482",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Miller",
      "screen_name" : "dealingwith",
      "indices" : [ 0, 12 ],
      "id_str" : "379983",
      "id" : 379983
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "238115057546977280",
  "geo" : {
  },
  "id_str" : "238128822766157826",
  "in_reply_to_user_id" : 379983,
  "text" : "@dealingwith Not at all. I have many of the same worries that others have. I just think they do want to do the right thing for devs.",
  "id" : 238128822766157826,
  "in_reply_to_status_id" : 238115057546977280,
  "created_at" : "Wed Aug 22 04:21:50 +0000 2012",
  "in_reply_to_screen_name" : "dealingwith",
  "in_reply_to_user_id_str" : "379983",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 57 ],
      "url" : "http://t.co/BOh4K22H",
      "expanded_url" : "http://flic.kr/p/cWqfxo",
      "display_url" : "flic.kr/p/cWqfxo"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.786166, -122.410834 ]
  },
  "id_str" : "238118661532045312",
  "text" : "8:36pm Feeling lazy in my hotel room http://t.co/BOh4K22H",
  "id" : 238118661532045312,
  "created_at" : "Wed Aug 22 03:41:27 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Bodge",
      "screen_name" : "mikebodge",
      "indices" : [ 0, 10 ],
      "id_str" : "19344531",
      "id" : 19344531
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "238082541582708739",
  "geo" : {
  },
  "id_str" : "238082689553555456",
  "in_reply_to_user_id" : 19344531,
  "text" : "@mikebodge Yes and yes!",
  "id" : 238082689553555456,
  "in_reply_to_status_id" : 238082541582708739,
  "created_at" : "Wed Aug 22 01:18:31 +0000 2012",
  "in_reply_to_screen_name" : "mikebodge",
  "in_reply_to_user_id_str" : "19344531",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Fuchs",
      "screen_name" : "jfuchs",
      "indices" : [ 0, 7 ],
      "id_str" : "1026",
      "id" : 1026
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "238078797528842241",
  "geo" : {
  },
  "id_str" : "238079096347844609",
  "in_reply_to_user_id" : 1026,
  "text" : "@jfuchs Hey! No, not yet. Moving in a few months. Where are you?",
  "id" : 238079096347844609,
  "in_reply_to_status_id" : 238078797528842241,
  "created_at" : "Wed Aug 22 01:04:14 +0000 2012",
  "in_reply_to_screen_name" : "jfuchs",
  "in_reply_to_user_id_str" : "1026",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Owens",
      "screen_name" : "mko",
      "indices" : [ 0, 4 ],
      "id_str" : "11822502",
      "id" : 11822502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "238077620460339200",
  "geo" : {
  },
  "id_str" : "238077886094012417",
  "in_reply_to_user_id" : 11822502,
  "text" : "@mko Thank you!",
  "id" : 238077886094012417,
  "in_reply_to_status_id" : 238077620460339200,
  "created_at" : "Wed Aug 22 00:59:25 +0000 2012",
  "in_reply_to_screen_name" : "mko",
  "in_reply_to_user_id_str" : "11822502",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan King",
      "screen_name" : "rk",
      "indices" : [ 0, 3 ],
      "id_str" : "19853",
      "id" : 19853
    }, {
      "name" : "Buzz Andersen",
      "screen_name" : "buzz",
      "indices" : [ 4, 9 ],
      "id_str" : "528",
      "id" : 528
    }, {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 54, 63 ],
      "id_str" : "761628",
      "id" : 761628
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "238075403825209346",
  "geo" : {
  },
  "id_str" : "238077763003760640",
  "in_reply_to_user_id" : 19853,
  "text" : "@rk @buzz I'm in, if there is something going on. /cc @RickWebb",
  "id" : 238077763003760640,
  "in_reply_to_status_id" : 238075403825209346,
  "created_at" : "Wed Aug 22 00:58:56 +0000 2012",
  "in_reply_to_screen_name" : "rk",
  "in_reply_to_user_id_str" : "19853",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "238077473798111232",
  "text" : "Day 2 at Twitter: I feel like I've been given a backstage pass to the Global Brain. And it involves a lot of bird references.",
  "id" : 238077473798111232,
  "created_at" : "Wed Aug 22 00:57:47 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Wright",
      "screen_name" : "webwright",
      "indices" : [ 3, 13 ],
      "id_str" : "786818",
      "id" : 786818
    }, {
      "name" : "Kevin Rose",
      "screen_name" : "kevinrose",
      "indices" : [ 22, 32 ],
      "id_str" : "657863",
      "id" : 657863
    }, {
      "name" : "Mikey Tom",
      "screen_name" : "mikeytom",
      "indices" : [ 119, 128 ],
      "id_str" : "125135097",
      "id" : 125135097
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 86 ],
      "url" : "http://t.co/vX1PXzNC",
      "expanded_url" : "http://kevinrose.com/y-combinator-demo-day",
      "display_url" : "kevinrose.com/y-combinator-d…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "238064370142281728",
  "text" : "RT @webwright: BOOM.  @kevinrose 's top 10 list from YC Demo Day: http://t.co/vX1PXzNC (We're on the list, peeps!) h/t @mikeytom",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kevin Rose",
        "screen_name" : "kevinrose",
        "indices" : [ 7, 17 ],
        "id_str" : "657863",
        "id" : 657863
      }, {
        "name" : "Mikey Tom",
        "screen_name" : "mikeytom",
        "indices" : [ 104, 113 ],
        "id_str" : "125135097",
        "id" : 125135097
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 51, 71 ],
        "url" : "http://t.co/vX1PXzNC",
        "expanded_url" : "http://kevinrose.com/y-combinator-demo-day",
        "display_url" : "kevinrose.com/y-combinator-d…"
      } ]
    },
    "geo" : {
    },
    "id_str" : "238049506967556096",
    "text" : "BOOM.  @kevinrose 's top 10 list from YC Demo Day: http://t.co/vX1PXzNC (We're on the list, peeps!) h/t @mikeytom",
    "id" : 238049506967556096,
    "created_at" : "Tue Aug 21 23:06:39 +0000 2012",
    "user" : {
      "name" : "Tony Wright",
      "screen_name" : "webwright",
      "protected" : false,
      "id_str" : "786818",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2397478920/eh2j0ftg0qd9bof9fh1g_normal.png",
      "id" : 786818,
      "verified" : false
    }
  },
  "id" : 238064370142281728,
  "created_at" : "Wed Aug 22 00:05:43 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ingopixel",
      "screen_name" : "ingopixel",
      "indices" : [ 80, 90 ],
      "id_str" : "7943892",
      "id" : 7943892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 74 ],
      "url" : "http://t.co/8kO5JyKE",
      "expanded_url" : "http://laughingsquid.com/brilliant-visualization-of-imaginative-games-we-often-play-while-alone/",
      "display_url" : "laughingsquid.com/brilliant-visu…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "237956427799461888",
  "text" : "I love these silly games we play in our heads [video] http://t.co/8kO5JyKE /thx @ingopixel",
  "id" : 237956427799461888,
  "created_at" : "Tue Aug 21 16:56:48 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Kurkov",
      "screen_name" : "davidkurkov",
      "indices" : [ 0, 12 ],
      "id_str" : "113292092",
      "id" : 113292092
    }, {
      "name" : "dustin curtis",
      "screen_name" : "dcurtis",
      "indices" : [ 13, 21 ],
      "id_str" : "9395832",
      "id" : 9395832
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "reason",
      "indices" : [ 61, 68 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "237749052664578048",
  "geo" : {
  },
  "id_str" : "237821763705245696",
  "in_reply_to_user_id" : 113292092,
  "text" : "@davidkurkov @dcurtis I’m a big fan of both services because #reason. I’ve been writing about both &amp; plan on continuing to do so hopefully.",
  "id" : 237821763705245696,
  "in_reply_to_status_id" : 237749052664578048,
  "created_at" : "Tue Aug 21 08:01:41 +0000 2012",
  "in_reply_to_screen_name" : "davidkurkov",
  "in_reply_to_user_id_str" : "113292092",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "harscoat",
      "screen_name" : "harscoat",
      "indices" : [ 0, 9 ],
      "id_str" : "18143096",
      "id" : 18143096
    }, {
      "name" : "susan wu",
      "screen_name" : "sw",
      "indices" : [ 10, 13 ],
      "id_str" : "893211",
      "id" : 893211
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "237819335366811649",
  "geo" : {
  },
  "id_str" : "237821314189115393",
  "in_reply_to_user_id" : 18143096,
  "text" : "@harscoat @sw Help make it all work, hopefully. In particular, cards.",
  "id" : 237821314189115393,
  "in_reply_to_status_id" : 237819335366811649,
  "created_at" : "Tue Aug 21 07:59:54 +0000 2012",
  "in_reply_to_screen_name" : "harscoat",
  "in_reply_to_user_id_str" : "18143096",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "fambai",
      "screen_name" : "fambai",
      "indices" : [ 0, 7 ],
      "id_str" : "12476332",
      "id" : 12476332
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "237743842948952064",
  "geo" : {
  },
  "id_str" : "237820948135440384",
  "in_reply_to_user_id" : 12476332,
  "text" : "@fambai Thank you! I just remembered getting a scooter ride from you in the neighborhood I’m in right now. Good times.",
  "id" : 237820948135440384,
  "in_reply_to_status_id" : 237743842948952064,
  "created_at" : "Tue Aug 21 07:58:27 +0000 2012",
  "in_reply_to_screen_name" : "fambai",
  "in_reply_to_user_id_str" : "12476332",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer Lum",
      "screen_name" : "jenniferlum",
      "indices" : [ 0, 12 ],
      "id_str" : "9891382",
      "id" : 9891382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "237749341094309888",
  "geo" : {
  },
  "id_str" : "237819592817397760",
  "in_reply_to_user_id" : 9891382,
  "text" : "@jenniferlum I would love to! Are you in SF for demo day?",
  "id" : 237819592817397760,
  "in_reply_to_status_id" : 237749341094309888,
  "created_at" : "Tue Aug 21 07:53:04 +0000 2012",
  "in_reply_to_screen_name" : "jenniferlum",
  "in_reply_to_user_id_str" : "9891382",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carl Nelson",
      "screen_name" : "CarlNelson",
      "indices" : [ 0, 11 ],
      "id_str" : "13951122",
      "id" : 13951122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "237759569097527297",
  "geo" : {
  },
  "id_str" : "237819469655855104",
  "in_reply_to_user_id" : 13951122,
  "text" : "@CarlNelson That’s one of my personal missions as well.",
  "id" : 237819469655855104,
  "in_reply_to_status_id" : 237759569097527297,
  "created_at" : "Tue Aug 21 07:52:34 +0000 2012",
  "in_reply_to_screen_name" : "CarlNelson",
  "in_reply_to_user_id_str" : "13951122",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Coates",
      "screen_name" : "tomcoates",
      "indices" : [ 0, 10 ],
      "id_str" : "12514",
      "id" : 12514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "237764306102530048",
  "geo" : {
  },
  "id_str" : "237819351921745920",
  "in_reply_to_user_id" : 12514,
  "text" : "@tomcoates I’m here next week too. Try again then?",
  "id" : 237819351921745920,
  "in_reply_to_status_id" : 237764306102530048,
  "created_at" : "Tue Aug 21 07:52:06 +0000 2012",
  "in_reply_to_screen_name" : "tomcoates",
  "in_reply_to_user_id_str" : "12514",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lindsay O'Leary",
      "screen_name" : "lindsayoleary",
      "indices" : [ 0, 14 ],
      "id_str" : "163966822",
      "id" : 163966822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "237765590566187009",
  "geo" : {
  },
  "id_str" : "237819257747030016",
  "in_reply_to_user_id" : 163966822,
  "text" : "@lindsayoleary So awesome that I hear from you every 5 years or so. I wonder what’s up with andrew@diaryland.com these days. And how’re you?",
  "id" : 237819257747030016,
  "in_reply_to_status_id" : 237765590566187009,
  "created_at" : "Tue Aug 21 07:51:44 +0000 2012",
  "in_reply_to_screen_name" : "lindsayoleary",
  "in_reply_to_user_id_str" : "163966822",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "susan wu",
      "screen_name" : "sw",
      "indices" : [ 0, 3 ],
      "id_str" : "893211",
      "id" : 893211
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "237766074584682496",
  "geo" : {
  },
  "id_str" : "237818763964207104",
  "in_reply_to_user_id" : 893211,
  "text" : "@sw Thank you! I feel lucky myself.",
  "id" : 237818763964207104,
  "in_reply_to_status_id" : 237766074584682496,
  "created_at" : "Tue Aug 21 07:49:46 +0000 2012",
  "in_reply_to_screen_name" : "sw",
  "in_reply_to_user_id_str" : "893211",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagr.am\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ali Berman",
      "screen_name" : "spangley",
      "indices" : [ 21, 30 ],
      "id_str" : "776429",
      "id" : 776429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 71 ],
      "url" : "http://t.co/32HrlQgG",
      "expanded_url" : "http://instagr.am/p/Ok0ar3I0Pg/",
      "display_url" : "instagr.am/p/Ok0ar3I0Pg/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7453959788, -122.420013036 ]
  },
  "id_str" : "237755332250701824",
  "text" : "8:36pm Burritos with @spangley!  @ Taqueria Cancun http://t.co/32HrlQgG",
  "id" : 237755332250701824,
  "created_at" : "Tue Aug 21 03:37:43 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Coates",
      "screen_name" : "tomcoates",
      "indices" : [ 0, 10 ],
      "id_str" : "12514",
      "id" : 12514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "237741014641692672",
  "geo" : {
  },
  "id_str" : "237742250896015360",
  "in_reply_to_user_id" : 12514,
  "text" : "@tomcoates Yes! Any open evening plans this week or next?",
  "id" : 237742250896015360,
  "in_reply_to_status_id" : 237741014641692672,
  "created_at" : "Tue Aug 21 02:45:44 +0000 2012",
  "in_reply_to_screen_name" : "tomcoates",
  "in_reply_to_user_id_str" : "12514",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Buster",
      "screen_name" : "Buster",
      "indices" : [ 17, 24 ],
      "id_str" : "272195023",
      "id" : 272195023
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "237741333803040768",
  "text" : "I ate lunch with @buster today.",
  "id" : 237741333803040768,
  "created_at" : "Tue Aug 21 02:42:05 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jane McGonigal",
      "screen_name" : "avantgame",
      "indices" : [ 0, 10 ],
      "id_str" : "681813",
      "id" : 681813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "237736939539808256",
  "geo" : {
  },
  "id_str" : "237737503598186497",
  "in_reply_to_user_id" : 681813,
  "text" : "@avantgame Thank you. I'm stoked. Can't wait to be same-city-neighbors with all so many amazing people, including yourself.",
  "id" : 237737503598186497,
  "in_reply_to_status_id" : 237736939539808256,
  "created_at" : "Tue Aug 21 02:26:52 +0000 2012",
  "in_reply_to_screen_name" : "avantgame",
  "in_reply_to_user_id_str" : "681813",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jane McGonigal",
      "screen_name" : "avantgame",
      "indices" : [ 0, 10 ],
      "id_str" : "681813",
      "id" : 681813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "237736884237910016",
  "geo" : {
  },
  "id_str" : "237737125028691968",
  "in_reply_to_user_id" : 681813,
  "text" : "@avantgame Yup! In the next couple months! We need to hang out!",
  "id" : 237737125028691968,
  "in_reply_to_status_id" : 237736884237910016,
  "created_at" : "Tue Aug 21 02:25:22 +0000 2012",
  "in_reply_to_screen_name" : "avantgame",
  "in_reply_to_user_id_str" : "681813",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "237736638166491136",
  "text" : "Day 1 at Twitter: I think I found my people.",
  "id" : 237736638166491136,
  "created_at" : "Tue Aug 21 02:23:26 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Buster",
      "screen_name" : "Buster",
      "indices" : [ 0, 7 ],
      "id_str" : "272195023",
      "id" : 272195023
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "237718969417596928",
  "in_reply_to_user_id" : 272195023,
  "text" : "@Buster Nice meeting you today, Buster!  So how may I bribe you?",
  "id" : 237718969417596928,
  "created_at" : "Tue Aug 21 01:13:13 +0000 2012",
  "in_reply_to_screen_name" : "Buster",
  "in_reply_to_user_id_str" : "272195023",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Buzz Andersen",
      "screen_name" : "buzz",
      "indices" : [ 0, 5 ],
      "id_str" : "528",
      "id" : 528
    }, {
      "name" : "Ryan King",
      "screen_name" : "rk",
      "indices" : [ 6, 9 ],
      "id_str" : "19853",
      "id" : 19853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "237627231277572097",
  "geo" : {
  },
  "id_str" : "237639489848217600",
  "in_reply_to_user_id" : 528,
  "text" : "@buzz @rk I’m here too! Would love to see you both.",
  "id" : 237639489848217600,
  "in_reply_to_status_id" : 237627231277572097,
  "created_at" : "Mon Aug 20 19:57:24 +0000 2012",
  "in_reply_to_screen_name" : "buzz",
  "in_reply_to_user_id_str" : "528",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 0, 9 ],
      "id_str" : "761628",
      "id" : 761628
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "237625111761543170",
  "geo" : {
  },
  "id_str" : "237638267867103232",
  "in_reply_to_user_id" : 761628,
  "text" : "@RickWebb I’ll see ya there!",
  "id" : 237638267867103232,
  "in_reply_to_status_id" : 237625111761543170,
  "created_at" : "Mon Aug 20 19:52:32 +0000 2012",
  "in_reply_to_screen_name" : "RickWebb",
  "in_reply_to_user_id_str" : "761628",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 0, 9 ],
      "id_str" : "761628",
      "id" : 761628
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "237606919135719424",
  "geo" : {
  },
  "id_str" : "237614167794802690",
  "in_reply_to_user_id" : 761628,
  "text" : "@RickWebb Great, I’ll look it up. What time? And yes, all week!",
  "id" : 237614167794802690,
  "in_reply_to_status_id" : 237606919135719424,
  "created_at" : "Mon Aug 20 18:16:46 +0000 2012",
  "in_reply_to_screen_name" : "RickWebb",
  "in_reply_to_user_id_str" : "761628",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Ott",
      "screen_name" : "ottmark",
      "indices" : [ 0, 8 ],
      "id_str" : "1962801",
      "id" : 1962801
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "237603826587291648",
  "geo" : {
  },
  "id_str" : "237614038090125312",
  "in_reply_to_user_id" : 1962801,
  "text" : "@ottmark Definitely plan on writing as much as possible!",
  "id" : 237614038090125312,
  "in_reply_to_status_id" : 237603826587291648,
  "created_at" : "Mon Aug 20 18:16:15 +0000 2012",
  "in_reply_to_screen_name" : "ottmark",
  "in_reply_to_user_id_str" : "1962801",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lane Becker",
      "screen_name" : "monstro",
      "indices" : [ 0, 8 ],
      "id_str" : "4030",
      "id" : 4030
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "237597517984980992",
  "geo" : {
  },
  "id_str" : "237613914567888896",
  "in_reply_to_user_id" : 4030,
  "text" : "@monstro Just down here a lot til we move down in a few months. Hi!",
  "id" : 237613914567888896,
  "in_reply_to_status_id" : 237597517984980992,
  "created_at" : "Mon Aug 20 18:15:46 +0000 2012",
  "in_reply_to_screen_name" : "monstro",
  "in_reply_to_user_id_str" : "4030",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ali Berman",
      "screen_name" : "spangley",
      "indices" : [ 0, 9 ],
      "id_str" : "776429",
      "id" : 776429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "237595708717400065",
  "geo" : {
  },
  "id_str" : "237613743192825856",
  "in_reply_to_user_id" : 776429,
  "text" : "@spangley The whiteboard says I can get lunch at 12. Wanna meet in the cafeteria?",
  "id" : 237613743192825856,
  "in_reply_to_status_id" : 237595708717400065,
  "created_at" : "Mon Aug 20 18:15:05 +0000 2012",
  "in_reply_to_screen_name" : "spangley",
  "in_reply_to_user_id_str" : "776429",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Sippey",
      "screen_name" : "sippey",
      "indices" : [ 0, 7 ],
      "id_str" : "4711",
      "id" : 4711
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "237586362474328065",
  "geo" : {
  },
  "id_str" : "237613554558177281",
  "in_reply_to_user_id" : 4711,
  "text" : "@sippey Why hello there! Looking forward to running into you sometime soon.",
  "id" : 237613554558177281,
  "in_reply_to_status_id" : 237586362474328065,
  "created_at" : "Mon Aug 20 18:14:20 +0000 2012",
  "in_reply_to_screen_name" : "sippey",
  "in_reply_to_user_id_str" : "4711",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Ewing",
      "screen_name" : "hoverbird",
      "indices" : [ 0, 10 ],
      "id_str" : "792690",
      "id" : 792690
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "237584793708142592",
  "geo" : {
  },
  "id_str" : "237613370931548160",
  "in_reply_to_user_id" : 792690,
  "text" : "@hoverbird Thank you! See ya around soon!",
  "id" : 237613370931548160,
  "in_reply_to_status_id" : 237584793708142592,
  "created_at" : "Mon Aug 20 18:13:36 +0000 2012",
  "in_reply_to_screen_name" : "hoverbird",
  "in_reply_to_user_id_str" : "792690",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 65 ],
      "url" : "http://t.co/wEXWMM9o",
      "expanded_url" : "http://4sq.com/MH7UK5",
      "display_url" : "4sq.com/MH7UK5"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7768119003, -122.4169589583 ]
  },
  "id_str" : "237584213262626817",
  "text" : "Hello Twitter! (@ Twitter, Inc. w/ 8 others) http://t.co/wEXWMM9o",
  "id" : 237584213262626817,
  "created_at" : "Mon Aug 20 16:17:45 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Chou",
      "screen_name" : "garychou",
      "indices" : [ 0, 9 ],
      "id_str" : "29058287",
      "id" : 29058287
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "237583094339735553",
  "geo" : {
  },
  "id_str" : "237583415468232704",
  "in_reply_to_user_id" : 29058287,
  "text" : "@garychou Thanks! Should be fun.",
  "id" : 237583415468232704,
  "in_reply_to_status_id" : 237583094339735553,
  "created_at" : "Mon Aug 20 16:14:34 +0000 2012",
  "in_reply_to_screen_name" : "garychou",
  "in_reply_to_user_id_str" : "29058287",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Reichhold",
      "screen_name" : "jreichhold",
      "indices" : [ 0, 11 ],
      "id_str" : "14934401",
      "id" : 14934401
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "237581618942980096",
  "geo" : {
  },
  "id_str" : "237583220919652353",
  "in_reply_to_user_id" : 14934401,
  "text" : "@jreichhold Thank you. Me too!",
  "id" : 237583220919652353,
  "in_reply_to_status_id" : 237581618942980096,
  "created_at" : "Mon Aug 20 16:13:48 +0000 2012",
  "in_reply_to_screen_name" : "jreichhold",
  "in_reply_to_user_id_str" : "14934401",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ciaran Lyons",
      "screen_name" : "crayonlions",
      "indices" : [ 0, 12 ],
      "id_str" : "231087644",
      "id" : 231087644
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "237581032768040960",
  "geo" : {
  },
  "id_str" : "237581168931926017",
  "in_reply_to_user_id" : 231087644,
  "text" : "@crayonlions Thanks.",
  "id" : 237581168931926017,
  "in_reply_to_status_id" : 237581032768040960,
  "created_at" : "Mon Aug 20 16:05:39 +0000 2012",
  "in_reply_to_screen_name" : "crayonlions",
  "in_reply_to_user_id_str" : "231087644",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael McDaniel",
      "screen_name" : "michaelmcdaniel",
      "indices" : [ 0, 16 ],
      "id_str" : "7565162",
      "id" : 7565162
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "237580311112859648",
  "geo" : {
  },
  "id_str" : "237580964409266176",
  "in_reply_to_user_id" : 7565162,
  "text" : "@michaelmcdaniel Yeah, they’re still in the formative years, which are the kind of years I enjoy most. :) Doing remote for a now…",
  "id" : 237580964409266176,
  "in_reply_to_status_id" : 237580311112859648,
  "created_at" : "Mon Aug 20 16:04:50 +0000 2012",
  "in_reply_to_screen_name" : "michaelmcdaniel",
  "in_reply_to_user_id_str" : "7565162",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "237579853694656513",
  "geo" : {
  },
  "id_str" : "237580043851796480",
  "in_reply_to_user_id" : 220226736,
  "text" : "@digitalmiss Technically, technical.",
  "id" : 237580043851796480,
  "in_reply_to_status_id" : 237579853694656513,
  "created_at" : "Mon Aug 20 16:01:11 +0000 2012",
  "in_reply_to_screen_name" : "KristyT",
  "in_reply_to_user_id_str" : "220226736",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "237579122400960513",
  "geo" : {
  },
  "id_str" : "237579803857911809",
  "in_reply_to_user_id" : 220226736,
  "text" : "@digitalmiss Making it more awesome however I can. :)",
  "id" : 237579803857911809,
  "in_reply_to_status_id" : 237579122400960513,
  "created_at" : "Mon Aug 20 16:00:13 +0000 2012",
  "in_reply_to_screen_name" : "KristyT",
  "in_reply_to_user_id_str" : "220226736",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "237578930272477184",
  "text" : "Did I mention that today’s my first day at Twitter? Very excited to be part of its future! Does anyone have any opinions on the matter?",
  "id" : 237578930272477184,
  "created_at" : "Mon Aug 20 15:56:45 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helen Jane",
      "screen_name" : "helenjane",
      "indices" : [ 0, 10 ],
      "id_str" : "798542",
      "id" : 798542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "237576859938861056",
  "geo" : {
  },
  "id_str" : "237577957634342913",
  "in_reply_to_user_id" : 798542,
  "text" : "@helenjane Wednesday might work! Will know more after today. Pencil in some brain knocking!",
  "id" : 237577957634342913,
  "in_reply_to_status_id" : 237576859938861056,
  "created_at" : "Mon Aug 20 15:52:53 +0000 2012",
  "in_reply_to_screen_name" : "helenjane",
  "in_reply_to_user_id_str" : "798542",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "William Morgan",
      "screen_name" : "wm",
      "indices" : [ 0, 3 ],
      "id_str" : "15504330",
      "id" : 15504330
    }, {
      "name" : "Raffi Krikorian",
      "screen_name" : "raffi",
      "indices" : [ 4, 10 ],
      "id_str" : "8285392",
      "id" : 8285392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "237539799207133184",
  "geo" : {
  },
  "id_str" : "237572225971150849",
  "in_reply_to_user_id" : 15504330,
  "text" : "@wm @raffi I’m probably gonna get one once they’re out too. Especially if you can write apps for it.",
  "id" : 237572225971150849,
  "in_reply_to_status_id" : 237539799207133184,
  "created_at" : "Mon Aug 20 15:30:07 +0000 2012",
  "in_reply_to_screen_name" : "wm",
  "in_reply_to_user_id_str" : "15504330",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helen Jane",
      "screen_name" : "helenjane",
      "indices" : [ 0, 10 ],
      "id_str" : "798542",
      "id" : 798542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "237540906599841793",
  "geo" : {
  },
  "id_str" : "237572048380116992",
  "in_reply_to_user_id" : 798542,
  "text" : "@helenjane That would be awesome. Which days are you in SF this week?",
  "id" : 237572048380116992,
  "in_reply_to_status_id" : 237540906599841793,
  "created_at" : "Mon Aug 20 15:29:24 +0000 2012",
  "in_reply_to_screen_name" : "helenjane",
  "in_reply_to_user_id_str" : "798542",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hugh MacLeod",
      "screen_name" : "gapingvoid",
      "indices" : [ 0, 11 ],
      "id_str" : "50193",
      "id" : 50193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "237533166766796801",
  "geo" : {
  },
  "id_str" : "237533980247875585",
  "in_reply_to_user_id" : 50193,
  "text" : "@gapingvoid That’s one step away from “if Nature meant us to fly It would have given us wings.” We aren’t finished products.",
  "id" : 237533980247875585,
  "in_reply_to_status_id" : 237533166766796801,
  "created_at" : "Mon Aug 20 12:58:08 +0000 2012",
  "in_reply_to_screen_name" : "gapingvoid",
  "in_reply_to_user_id_str" : "50193",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Lowell",
      "screen_name" : "jthomas",
      "indices" : [ 11, 19 ],
      "id_str" : "760181",
      "id" : 760181
    }, {
      "name" : "Michael Zimbalist",
      "screen_name" : "zimbalist",
      "indices" : [ 64, 74 ],
      "id_str" : "1371791",
      "id" : 1371791
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 127 ],
      "url" : "http://t.co/FXMzUrRT",
      "expanded_url" : "http://mobile.nytimes.com/bitsarticle?articleId=116276",
      "display_url" : "mobile.nytimes.com/bitsarticle?ar…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "237533537413255170",
  "text" : "Agreed. RT @jthomas: Apple could crush it with iOS on a nano…  “@zimbalist: The future of the wristwatch.  http://t.co/FXMzUrRT”",
  "id" : 237533537413255170,
  "created_at" : "Mon Aug 20 12:56:23 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benjamin Collins",
      "screen_name" : "bbwcollins",
      "indices" : [ 0, 11 ],
      "id_str" : "646413",
      "id" : 646413
    }, {
      "name" : "Health Month",
      "screen_name" : "healthmonth",
      "indices" : [ 46, 58 ],
      "id_str" : "154236895",
      "id" : 154236895
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "237528158461640704",
  "geo" : {
  },
  "id_str" : "237528927290138624",
  "in_reply_to_user_id" : 646413,
  "text" : "@bbwcollins Thanks! It doesn’t quite fit as a @healthmonth rule but might help other rules like “eat greens”. Let me know how it goes!",
  "id" : 237528927290138624,
  "in_reply_to_status_id" : 237528158461640704,
  "created_at" : "Mon Aug 20 12:38:03 +0000 2012",
  "in_reply_to_screen_name" : "bbwcollins",
  "in_reply_to_user_id_str" : "646413",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NikeFuel",
      "screen_name" : "NikeFuel",
      "indices" : [ 56, 65 ],
      "id_str" : "466807381",
      "id" : 466807381
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "itdoesntcount",
      "indices" : [ 72, 86 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "237522828407230464",
  "text" : "I’ve accidentally fallen out of the habit of wearing my @NikeFuel band. #itdoesntcount",
  "id" : 237522828407230464,
  "created_at" : "Mon Aug 20 12:13:49 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 112 ],
      "url" : "http://t.co/XDKlngcX",
      "expanded_url" : "http://4sq.com/OQ7rqj",
      "display_url" : "4sq.com/OQ7rqj"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.4436465828, -122.3025941849 ]
  },
  "id_str" : "237516667071131648",
  "text" : "Seattle to SF for a whole week! (@ Seattle-Tacoma International Airport (SEA) w/ 14 others) http://t.co/XDKlngcX",
  "id" : 237516667071131648,
  "created_at" : "Mon Aug 20 11:49:20 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 0, 9 ],
      "id_str" : "761628",
      "id" : 761628
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "237502055856603136",
  "geo" : {
  },
  "id_str" : "237512290935652353",
  "in_reply_to_user_id" : 761628,
  "text" : "@RickWebb Whatcha doing tonight? I’m in SF too.",
  "id" : 237512290935652353,
  "in_reply_to_status_id" : 237502055856603136,
  "created_at" : "Mon Aug 20 11:31:57 +0000 2012",
  "in_reply_to_screen_name" : "RickWebb",
  "in_reply_to_user_id_str" : "761628",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amber Case",
      "screen_name" : "caseorganic",
      "indices" : [ 8, 20 ],
      "id_str" : "13860742",
      "id" : 13860742
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 130 ],
      "url" : "http://t.co/QO16rUCX",
      "expanded_url" : "http://en.m.wikipedia.org/wiki/Rubber_duck_debugging",
      "display_url" : "en.m.wikipedia.org/wiki/Rubber_du…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "237511457053474816",
  "text" : "Yes! RT @caseorganic: Rubber duck debugging. Debugging your code by explaining it carefully to a rubber duck. http://t.co/QO16rUCX",
  "id" : 237511457053474816,
  "created_at" : "Mon Aug 20 11:28:38 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 0, 10 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "237420023348621312",
  "geo" : {
  },
  "id_str" : "237420619224985600",
  "in_reply_to_user_id" : 7362142,
  "text" : "@kellianne It only becomes true once you get that luggage from the basement for me. Until then my future, past, universe, etc are FREE!",
  "id" : 237420619224985600,
  "in_reply_to_status_id" : 237420023348621312,
  "created_at" : "Mon Aug 20 05:27:41 +0000 2012",
  "in_reply_to_screen_name" : "kellianne",
  "in_reply_to_user_id_str" : "7362142",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 39 ],
      "url" : "http://t.co/i9OB48RU",
      "expanded_url" : "http://flic.kr/p/cV6cmd",
      "display_url" : "flic.kr/p/cV6cmd"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6085, -122.306167 ]
  },
  "id_str" : "237393234781958144",
  "text" : "8:36pm Pizza party http://t.co/i9OB48RU",
  "id" : 237393234781958144,
  "created_at" : "Mon Aug 20 03:38:52 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Raffi Krikorian",
      "screen_name" : "raffi",
      "indices" : [ 0, 6 ],
      "id_str" : "8285392",
      "id" : 8285392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "237384150414393344",
  "geo" : {
  },
  "id_str" : "237384712623120384",
  "in_reply_to_user_id" : 8285392,
  "text" : "@raffi Me too! It’s gonna be fun.",
  "id" : 237384712623120384,
  "in_reply_to_status_id" : 237384150414393344,
  "created_at" : "Mon Aug 20 03:05:00 +0000 2012",
  "in_reply_to_screen_name" : "raffi",
  "in_reply_to_user_id_str" : "8285392",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Raffi Krikorian",
      "screen_name" : "raffi",
      "indices" : [ 0, 6 ],
      "id_str" : "8285392",
      "id" : 8285392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "237381317019463682",
  "geo" : {
  },
  "id_str" : "237383441971306496",
  "in_reply_to_user_id" : 8285392,
  "text" : "@raffi I’m planning on giving that a try starting tomorrow as well. :)",
  "id" : 237383441971306496,
  "in_reply_to_status_id" : 237381317019463682,
  "created_at" : "Mon Aug 20 02:59:57 +0000 2012",
  "in_reply_to_screen_name" : "raffi",
  "in_reply_to_user_id_str" : "8285392",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lane Becker",
      "screen_name" : "monstro",
      "indices" : [ 0, 8 ],
      "id_str" : "4030",
      "id" : 4030
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "237364937025007616",
  "geo" : {
  },
  "id_str" : "237365323039395840",
  "in_reply_to_user_id" : 4030,
  "text" : "@monstro I was hoping someone was gonna say that! Have any info or links about it?",
  "id" : 237365323039395840,
  "in_reply_to_status_id" : 237364937025007616,
  "created_at" : "Mon Aug 20 01:47:57 +0000 2012",
  "in_reply_to_screen_name" : "monstro",
  "in_reply_to_user_id_str" : "4030",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Santangelo",
      "screen_name" : "endquote",
      "indices" : [ 0, 9 ],
      "id_str" : "408",
      "id" : 408
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "237353258736304129",
  "geo" : {
  },
  "id_str" : "237353487875338242",
  "in_reply_to_user_id" : 408,
  "text" : "@endquote It times how long the app is open. Extra points for playing against someone.",
  "id" : 237353487875338242,
  "in_reply_to_status_id" : 237353258736304129,
  "created_at" : "Mon Aug 20 01:00:55 +0000 2012",
  "in_reply_to_screen_name" : "endquote",
  "in_reply_to_user_id_str" : "408",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Santangelo",
      "screen_name" : "endquote",
      "indices" : [ 0, 9 ],
      "id_str" : "408",
      "id" : 408
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "237353042641575936",
  "geo" : {
  },
  "id_str" : "237353131502075904",
  "in_reply_to_user_id" : 408,
  "text" : "@endquote Exactly. It’s a perfect starter app.",
  "id" : 237353131502075904,
  "in_reply_to_status_id" : 237353042641575936,
  "created_at" : "Mon Aug 20 00:59:31 +0000 2012",
  "in_reply_to_screen_name" : "endquote",
  "in_reply_to_user_id_str" : "408",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Santangelo",
      "screen_name" : "endquote",
      "indices" : [ 0, 9 ],
      "id_str" : "408",
      "id" : 408
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "237352524275916800",
  "geo" : {
  },
  "id_str" : "237352791679569920",
  "in_reply_to_user_id" : 408,
  "text" : "@endquote I was hoping you’d want to build it. :)",
  "id" : 237352791679569920,
  "in_reply_to_status_id" : 237352524275916800,
  "created_at" : "Mon Aug 20 00:58:09 +0000 2012",
  "in_reply_to_screen_name" : "endquote",
  "in_reply_to_user_id_str" : "408",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ted Roden",
      "screen_name" : "tedroden",
      "indices" : [ 0, 9 ],
      "id_str" : "822858",
      "id" : 822858
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "237346783922106370",
  "geo" : {
  },
  "id_str" : "237347319555702784",
  "in_reply_to_user_id" : 822858,
  "text" : "@tedroden Yeah, that’s the idea, with cheating safeguards. I just think it could be packaged and marketed pretty easily.",
  "id" : 237347319555702784,
  "in_reply_to_status_id" : 237346783922106370,
  "created_at" : "Mon Aug 20 00:36:25 +0000 2012",
  "in_reply_to_screen_name" : "tedroden",
  "in_reply_to_user_id_str" : "822858",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "237346557773615104",
  "text" : "Sunday Idea: an iPhone app that turns *not* using your phone into a game. It would basically track how long you could keep that app primary.",
  "id" : 237346557773615104,
  "created_at" : "Mon Aug 20 00:33:23 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niko Benson",
      "screen_name" : "nikobenson",
      "indices" : [ 0, 11 ],
      "id_str" : "142467448",
      "id" : 142467448
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "237325258955296769",
  "in_reply_to_user_id" : 142467448,
  "text" : "@nikobenson has decided that a good substitute for his naps with me is to just sing songs to his toys. For hours.",
  "id" : 237325258955296769,
  "created_at" : "Sun Aug 19 23:08:45 +0000 2012",
  "in_reply_to_screen_name" : "nikobenson",
  "in_reply_to_user_id_str" : "142467448",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Monteiro",
      "screen_name" : "Mike_FTW",
      "indices" : [ 3, 12 ],
      "id_str" : "2426",
      "id" : 2426
    }, {
      "name" : "Rep. W Todd Akin",
      "screen_name" : "RepToddAkin",
      "indices" : [ 65, 77 ],
      "id_str" : "20616305",
      "id" : 20616305
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 109 ],
      "url" : "https://t.co/7g27FdNu",
      "expanded_url" : "https://secure.ppaction.org/site/SPageServer?pagename=pp_ppol_Nondirected_HonoraryGiving",
      "display_url" : "secure.ppaction.org/site/SPageServ…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "237313066985992192",
  "text" : "RT @Mike_FTW: BTW, the URL for donating to Planned Parenthood in @RepToddAkin’s name is https://t.co/7g27FdNu",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Rep. W Todd Akin",
        "screen_name" : "RepToddAkin",
        "indices" : [ 51, 63 ],
        "id_str" : "20616305",
        "id" : 20616305
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 74, 95 ],
        "url" : "https://t.co/7g27FdNu",
        "expanded_url" : "https://secure.ppaction.org/site/SPageServer?pagename=pp_ppol_Nondirected_HonoraryGiving",
        "display_url" : "secure.ppaction.org/site/SPageServ…"
      } ]
    },
    "geo" : {
    },
    "id_str" : "237290999628587008",
    "text" : "BTW, the URL for donating to Planned Parenthood in @RepToddAkin’s name is https://t.co/7g27FdNu",
    "id" : 237290999628587008,
    "created_at" : "Sun Aug 19 20:52:37 +0000 2012",
    "user" : {
      "name" : "Mike Monteiro",
      "screen_name" : "Mike_FTW",
      "protected" : false,
      "id_str" : "2426",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/556789661/pigman_normal.jpg",
      "id" : 2426,
      "verified" : false
    }
  },
  "id" : 237313066985992192,
  "created_at" : "Sun Aug 19 22:20:18 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jonronson",
      "screen_name" : "jonronson",
      "indices" : [ 16, 26 ],
      "id_str" : "18028249",
      "id" : 18028249
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 125 ],
      "url" : "http://t.co/2x80epF5",
      "expanded_url" : "http://www.ted.com/talks/jon_ronson_strange_answers_to_the_psychopath_test.html",
      "display_url" : "ted.com/talks/jon_rons…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "237291660470538240",
  "text" : "The TED talk by @jonronson about his book The Psychopath Test was really interesting, and well-directed! http://t.co/2x80epF5",
  "id" : 237291660470538240,
  "created_at" : "Sun Aug 19 20:55:15 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "237281357171130368",
  "text" : "I wish it was as common to see sane thoughts and ideas from people I disagree with.",
  "id" : 237281357171130368,
  "created_at" : "Sun Aug 19 20:14:18 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emily",
      "screen_name" : "threlkelded",
      "indices" : [ 0, 12 ],
      "id_str" : "4979381",
      "id" : 4979381
    }, {
      "name" : "kellan",
      "screen_name" : "kellan",
      "indices" : [ 13, 20 ],
      "id_str" : "47",
      "id" : 47
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "237267814157803520",
  "geo" : {
  },
  "id_str" : "237278687635070976",
  "in_reply_to_user_id" : 4979381,
  "text" : "@threlkelded @kellan How do you ensure that they’ll be able to gain access to those accounts?",
  "id" : 237278687635070976,
  "in_reply_to_status_id" : 237267814157803520,
  "created_at" : "Sun Aug 19 20:03:42 +0000 2012",
  "in_reply_to_screen_name" : "threlkelded",
  "in_reply_to_user_id_str" : "4979381",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kellan",
      "screen_name" : "kellan",
      "indices" : [ 76, 83 ],
      "id_str" : "47",
      "id" : 47
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "237264290518794240",
  "text" : "Great question. Pass ownership according same rules as physical remains? RT @kellan: What do you do with digital remains of someone’s life?",
  "id" : 237264290518794240,
  "created_at" : "Sun Aug 19 19:06:29 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tanner C",
      "screen_name" : "tannerc",
      "indices" : [ 0, 8 ],
      "id_str" : "9161482",
      "id" : 9161482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "237224988476862464",
  "geo" : {
  },
  "id_str" : "237242955474296832",
  "in_reply_to_user_id" : 9161482,
  "text" : "@tannerc Once I figure out what is it, maybe. :)",
  "id" : 237242955474296832,
  "in_reply_to_status_id" : 237224988476862464,
  "created_at" : "Sun Aug 19 17:41:43 +0000 2012",
  "in_reply_to_screen_name" : "tannerc",
  "in_reply_to_user_id_str" : "9161482",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gretchen Rubin",
      "screen_name" : "gretchenrubin",
      "indices" : [ 3, 17 ],
      "id_str" : "14289835",
      "id" : 14289835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "237212810088701953",
  "text" : "RT @gretchenrubin: “If You Do the Same Thing Every Day at the Same Time For the Same Length of Time…”: “If you do the same thing ev... h ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitterfeed.com\" rel=\"nofollow\">twitterfeed</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 136 ],
        "url" : "http://t.co/2e3siAJo",
        "expanded_url" : "http://bit.ly/NTrcbo",
        "display_url" : "bit.ly/NTrcbo"
      } ]
    },
    "geo" : {
    },
    "id_str" : "237190358893731840",
    "text" : "“If You Do the Same Thing Every Day at the Same Time For the Same Length of Time…”: “If you do the same thing ev... http://t.co/2e3siAJo",
    "id" : 237190358893731840,
    "created_at" : "Sun Aug 19 14:12:43 +0000 2012",
    "user" : {
      "name" : "Gretchen Rubin",
      "screen_name" : "gretchenrubin",
      "protected" : false,
      "id_str" : "14289835",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1436632135/Gretchenonphone_normal.JPG",
      "id" : 14289835,
      "verified" : true
    }
  },
  "id" : 237212810088701953,
  "created_at" : "Sun Aug 19 15:41:55 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TechCrunch",
      "screen_name" : "TechCrunch",
      "indices" : [ 3, 14 ],
      "id_str" : "816653",
      "id" : 816653
    }, {
      "name" : "John Biggs",
      "screen_name" : "johnbiggs",
      "indices" : [ 96, 106 ],
      "id_str" : "788673",
      "id" : 788673
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 92 ],
      "url" : "http://t.co/z2E1vaxO",
      "expanded_url" : "http://tcrn.ch/QOpkkp",
      "display_url" : "tcrn.ch/QOpkkp"
    } ]
  },
  "geo" : {
  },
  "id_str" : "237061713881612288",
  "text" : "RT @TechCrunch: Hey, Guys, Remember When You Used To Care About Flash?  http://t.co/z2E1vaxO by @johnbiggs",
  "retweeted_status" : {
    "source" : "<a href=\"http://vip.wordpress.com/hosting\" rel=\"nofollow\">WordPress.com VIP</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "John Biggs",
        "screen_name" : "johnbiggs",
        "indices" : [ 80, 90 ],
        "id_str" : "788673",
        "id" : 788673
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 56, 76 ],
        "url" : "http://t.co/z2E1vaxO",
        "expanded_url" : "http://tcrn.ch/QOpkkp",
        "display_url" : "tcrn.ch/QOpkkp"
      } ]
    },
    "geo" : {
    },
    "id_str" : "237057254979944448",
    "text" : "Hey, Guys, Remember When You Used To Care About Flash?  http://t.co/z2E1vaxO by @johnbiggs",
    "id" : 237057254979944448,
    "created_at" : "Sun Aug 19 05:23:48 +0000 2012",
    "user" : {
      "name" : "TechCrunch",
      "screen_name" : "TechCrunch",
      "protected" : false,
      "id_str" : "816653",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2176846885/-5-1_normal.jpeg",
      "id" : 816653,
      "verified" : true
    }
  },
  "id" : 237061713881612288,
  "created_at" : "Sun Aug 19 05:41:31 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.apple.com\" rel=\"nofollow\">Safari on iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Ford",
      "screen_name" : "ftrain",
      "indices" : [ 94, 101 ],
      "id_str" : "6981492",
      "id" : 6981492
    }, {
      "name" : "Jane McGonigal",
      "screen_name" : "avantgame",
      "indices" : [ 107, 117 ],
      "id_str" : "681813",
      "id" : 681813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http://t.co/JpZgUVTg",
      "expanded_url" : "http://contentsmagazine.com/articles/10-timeframes/",
      "display_url" : "contentsmagazine.com/articles/10-ti…"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.606284, -122.298418 ]
  },
  "id_str" : "237053693588033536",
  "text" : "So good. \"Even if the world were totally silent, you’d be able to count your heartbeats.\" /by @ftrain /via @avantgame http://t.co/JpZgUVTg",
  "id" : 237053693588033536,
  "created_at" : "Sun Aug 19 05:09:39 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagr.am\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 63 ],
      "url" : "http://t.co/Yitmx6FT",
      "expanded_url" : "http://instagr.am/p/Ofq1Ako0J3/",
      "display_url" : "instagr.am/p/Ofq1Ako0J3/"
    } ]
  },
  "geo" : {
  },
  "id_str" : "237030725835182081",
  "text" : "8:36pm Visiting Susie, Cory, and baby Ozzy http://t.co/Yitmx6FT",
  "id" : 237030725835182081,
  "created_at" : "Sun Aug 19 03:38:23 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagr.am\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 43 ],
      "url" : "http://t.co/lafdjjKG",
      "expanded_url" : "http://instagr.am/p/OfWKdRI0IS/",
      "display_url" : "instagr.am/p/OfWKdRI0IS/"
    } ]
  },
  "geo" : {
  },
  "id_str" : "236985119938850817",
  "text" : "Greetings, Earthlings! http://t.co/lafdjjKG",
  "id" : 236985119938850817,
  "created_at" : "Sun Aug 19 00:37:10 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kav Latiolais",
      "screen_name" : "kavla",
      "indices" : [ 3, 9 ],
      "id_str" : "28838912",
      "id" : 28838912
    }, {
      "name" : "Buster Benson",
      "screen_name" : "busterbenson",
      "indices" : [ 11, 24 ],
      "id_str" : "2185",
      "id" : 2185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "236961054830243840",
  "text" : "RT @kavla: @busterbenson interesting. Also Mitt Romney is a douche. (Wanted to get counted)",
  "retweeted_status" : {
    "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Buster Benson",
        "screen_name" : "busterbenson",
        "indices" : [ 0, 13 ],
        "id_str" : "2185",
        "id" : 2185
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "236957034166243328",
    "geo" : {
    },
    "id_str" : "236960280989540352",
    "in_reply_to_user_id" : 2185,
    "text" : "@busterbenson interesting. Also Mitt Romney is a douche. (Wanted to get counted)",
    "id" : 236960280989540352,
    "in_reply_to_status_id" : 236957034166243328,
    "created_at" : "Sat Aug 18 22:58:28 +0000 2012",
    "in_reply_to_screen_name" : "busterbenson",
    "in_reply_to_user_id_str" : "2185",
    "user" : {
      "name" : "Kav Latiolais",
      "screen_name" : "kavla",
      "protected" : false,
      "id_str" : "28838912",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2398257366/0fzaxm0wvj0ntlz2o4ab_normal.jpeg",
      "id" : 28838912,
      "verified" : false
    }
  },
  "id" : 236961054830243840,
  "created_at" : "Sat Aug 18 23:01:32 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "236957543870636033",
  "text" : "Also related: “On Election Day ‘08 there were a total of 1.8M tweets. That now represents 6 minutes of current Twitter volume.”",
  "id" : 236957543870636033,
  "created_at" : "Sat Aug 18 22:47:35 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.apple.com\" rel=\"nofollow\">Safari on iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 125 ],
      "url" : "http://t.co/W5ERs3rg",
      "expanded_url" : "http://www.washingtonpost.com/blogs/the-fix/post/introducing-the-twitter-political-index/2012/08/01/gJQAGniRPX_blog.html",
      "display_url" : "washingtonpost.com/blogs/the-fix/…"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.603217, -122.299198 ]
  },
  "id_str" : "236957034166243328",
  "text" : "The Twitter Political Index is actually a lot more interesting than I originally thought. How it works:  http://t.co/W5ERs3rg",
  "id" : 236957034166243328,
  "created_at" : "Sat Aug 18 22:45:34 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bubs 'Darius Monsef'",
      "screen_name" : "bubs",
      "indices" : [ 3, 8 ],
      "id_str" : "15119910",
      "id" : 15119910
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "236940279603687424",
  "text" : "RT @bubs: \"It's sad how Wile E. Coyote is only remembered for his violence &amp; not for his brilliantly realistic paintings of tunnels. ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Craig Kausen",
        "screen_name" : "CraigKausen",
        "indices" : [ 128, 140 ],
        "id_str" : "19572710",
        "id" : 19572710
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "236928620772347904",
    "text" : "\"It's sad how Wile E. Coyote is only remembered for his violence &amp; not for his brilliantly realistic paintings of tunnels.\" @CraigKausen",
    "id" : 236928620772347904,
    "created_at" : "Sat Aug 18 20:52:39 +0000 2012",
    "user" : {
      "name" : "Bubs 'Darius Monsef'",
      "screen_name" : "bubs",
      "protected" : false,
      "id_str" : "15119910",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2699486769/ada38cf70064b8566f7046dd318e2f31_normal.jpeg",
      "id" : 15119910,
      "verified" : false
    }
  },
  "id" : 236940279603687424,
  "created_at" : "Sat Aug 18 21:38:59 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 132 ],
      "url" : "http://t.co/xYRN1CUl",
      "expanded_url" : "http://www.technologyreview.com/view/428920/the-emerging-revolution-in-game-theory",
      "display_url" : "technologyreview.com/view/428920/th…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "236893136645931008",
  "text" : "Really interesting new winning strategy for Iterated Prisoner’s Dilemma called the “zero determinant strategy”: http://t.co/xYRN1CUl",
  "id" : 236893136645931008,
  "created_at" : "Sat Aug 18 18:31:39 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "allison kudla",
      "screen_name" : "allisonx",
      "indices" : [ 0, 9 ],
      "id_str" : "14047537",
      "id" : 14047537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "236891300471926785",
  "geo" : {
  },
  "id_str" : "236892319540969472",
  "in_reply_to_user_id" : 14047537,
  "text" : "@allisonx I think the idea is to only use 1 strand for the encoding, and throw out the other strand. Does that change things?",
  "id" : 236892319540969472,
  "in_reply_to_status_id" : 236891300471926785,
  "created_at" : "Sat Aug 18 18:28:24 +0000 2012",
  "in_reply_to_screen_name" : "allisonx",
  "in_reply_to_user_id_str" : "14047537",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "josh",
      "screen_name" : "joshc",
      "indices" : [ 0, 6 ],
      "id_str" : "2015",
      "id" : 2015
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "236880458154139650",
  "geo" : {
  },
  "id_str" : "236883806978719744",
  "in_reply_to_user_id" : 2015,
  "text" : "@joshc It’s still just 0s and 1s, but encoded more densely. But apparently certain sequences aren’t stable.",
  "id" : 236883806978719744,
  "in_reply_to_status_id" : 236880458154139650,
  "created_at" : "Sat Aug 18 17:54:35 +0000 2012",
  "in_reply_to_screen_name" : "joshc",
  "in_reply_to_user_id_str" : "2015",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer Lum",
      "screen_name" : "jenniferlum",
      "indices" : [ 3, 15 ],
      "id_str" : "9891382",
      "id" : 9891382
    }, {
      "name" : "John Battelle",
      "screen_name" : "johnbattelle",
      "indices" : [ 90, 103 ],
      "id_str" : "14600116",
      "id" : 14600116
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 86 ],
      "url" : "http://t.co/hmD63WWb",
      "expanded_url" : "http://battellemedia.com/archives/2012/08/musings-on-streams-and-the-future-of-magazines.php",
      "display_url" : "battellemedia.com/archives/2012/…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "236867509452677121",
  "text" : "RT @jenniferlum: Musings On “Streams” and the Future of Magazines http://t.co/hmD63WWb by @johnbattelle",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "John Battelle",
        "screen_name" : "johnbattelle",
        "indices" : [ 73, 86 ],
        "id_str" : "14600116",
        "id" : 14600116
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 49, 69 ],
        "url" : "http://t.co/hmD63WWb",
        "expanded_url" : "http://battellemedia.com/archives/2012/08/musings-on-streams-and-the-future-of-magazines.php",
        "display_url" : "battellemedia.com/archives/2012/…"
      } ]
    },
    "geo" : {
    },
    "id_str" : "236861769740603392",
    "text" : "Musings On “Streams” and the Future of Magazines http://t.co/hmD63WWb by @johnbattelle",
    "id" : 236861769740603392,
    "created_at" : "Sat Aug 18 16:27:01 +0000 2012",
    "user" : {
      "name" : "Jennifer Lum",
      "screen_name" : "jenniferlum",
      "protected" : false,
      "id_str" : "9891382",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2309335271/jgnqisjak7gjcnx65kcm_normal.jpeg",
      "id" : 9891382,
      "verified" : false
    }
  },
  "id" : 236867509452677121,
  "created_at" : "Sat Aug 18 16:49:49 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.apple.com\" rel=\"nofollow\">Safari on iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 122 ],
      "url" : "http://t.co/lJzAQRP0",
      "expanded_url" : "http://money.cnn.com/2012/08/16/technology/restaurant-cell-phone-discount/index.html",
      "display_url" : "money.cnn.com/2012/08/16/tec…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "236837566068953088",
  "text" : "Restaurant offers a 5% discount to eat without your phone. An awesome idea to help us help ourselves! http://t.co/lJzAQRP0",
  "id" : 236837566068953088,
  "created_at" : "Sat Aug 18 14:50:50 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 131 ],
      "url" : "http://t.co/yTmPH04p",
      "expanded_url" : "http://news.ycombinator.com/item?id=4396931",
      "display_url" : "news.ycombinator.com/item?id=4396931"
    } ]
  },
  "geo" : {
  },
  "id_str" : "236712568192892928",
  "text" : "“The genetic code has presumably evolved to evolve; it's unclear that it's evolved to preserve information.” \n\nhttp://t.co/yTmPH04p",
  "id" : 236712568192892928,
  "created_at" : "Sat Aug 18 06:34:08 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kimberly dawn",
      "screen_name" : "hiitskim",
      "indices" : [ 0, 9 ],
      "id_str" : "26148025",
      "id" : 26148025
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "236707652044984320",
  "geo" : {
  },
  "id_str" : "236711900677799936",
  "in_reply_to_user_id" : 26148025,
  "text" : "@hiitskim Thank you! Let me know if you give it a try!",
  "id" : 236711900677799936,
  "in_reply_to_status_id" : 236707652044984320,
  "created_at" : "Sat Aug 18 06:31:29 +0000 2012",
  "in_reply_to_screen_name" : "hiitskim",
  "in_reply_to_user_id_str" : "26148025",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christian Carter",
      "screen_name" : "cdcarter",
      "indices" : [ 0, 9 ],
      "id_str" : "652073",
      "id" : 652073
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "236698844543451136",
  "geo" : {
  },
  "id_str" : "236701488628523008",
  "in_reply_to_user_id" : 652073,
  "text" : "@cdcarter Awesome, thanks for pointing me to that.",
  "id" : 236701488628523008,
  "in_reply_to_status_id" : 236698844543451136,
  "created_at" : "Sat Aug 18 05:50:07 +0000 2012",
  "in_reply_to_screen_name" : "cdcarter",
  "in_reply_to_user_id_str" : "652073",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christian Carter",
      "screen_name" : "cdcarter",
      "indices" : [ 3, 12 ],
      "id_str" : "652073",
      "id" : 652073
    }, {
      "name" : "Buster Benson",
      "screen_name" : "busterbenson",
      "indices" : [ 14, 27 ],
      "id_str" : "2185",
      "id" : 2185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "236701427672686593",
  "text" : "RT @cdcarter: @busterbenson my understanding is that this would lead to harder to sequence pairs. the paper author answered it on HN htt ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Buster Benson",
        "screen_name" : "busterbenson",
        "indices" : [ 0, 13 ],
        "id_str" : "2185",
        "id" : 2185
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 119, 139 ],
        "url" : "http://t.co/6oVbFwwM",
        "expanded_url" : "http://news.ycombinator.com/item?id=4398367",
        "display_url" : "news.ycombinator.com/item?id=4398367"
      } ]
    },
    "in_reply_to_status_id_str" : "236693971320053763",
    "geo" : {
    },
    "id_str" : "236698844543451136",
    "in_reply_to_user_id" : 2185,
    "text" : "@busterbenson my understanding is that this would lead to harder to sequence pairs. the paper author answered it on HN http://t.co/6oVbFwwM",
    "id" : 236698844543451136,
    "in_reply_to_status_id" : 236693971320053763,
    "created_at" : "Sat Aug 18 05:39:36 +0000 2012",
    "in_reply_to_screen_name" : "busterbenson",
    "in_reply_to_user_id_str" : "2185",
    "user" : {
      "name" : "Christian Carter",
      "screen_name" : "cdcarter",
      "protected" : false,
      "id_str" : "652073",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1787637058/image_normal.jpg",
      "id" : 652073,
      "verified" : false
    }
  },
  "id" : 236701427672686593,
  "created_at" : "Sat Aug 18 05:49:52 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Tauber",
      "screen_name" : "jtauber",
      "indices" : [ 0, 8 ],
      "id_str" : "1583811",
      "id" : 1583811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "236694926547644416",
  "geo" : {
  },
  "id_str" : "236695607434149888",
  "in_reply_to_user_id" : 1583811,
  "text" : "@jtauber That was my initial guess too but then A &amp; T should have same value, when in this experiment it’s G &amp;T that have the same value.",
  "id" : 236695607434149888,
  "in_reply_to_status_id" : 236694926547644416,
  "created_at" : "Sat Aug 18 05:26:45 +0000 2012",
  "in_reply_to_screen_name" : "jtauber",
  "in_reply_to_user_id_str" : "1583811",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christian Carter",
      "screen_name" : "cdcarter",
      "indices" : [ 0, 9 ],
      "id_str" : "652073",
      "id" : 652073
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "236693428149293056",
  "geo" : {
  },
  "id_str" : "236694438368382976",
  "in_reply_to_user_id" : 652073,
  "text" : "@cdcarter Key difference being meat, I think, right?",
  "id" : 236694438368382976,
  "in_reply_to_status_id" : 236693428149293056,
  "created_at" : "Sat Aug 18 05:22:06 +0000 2012",
  "in_reply_to_screen_name" : "cdcarter",
  "in_reply_to_user_id_str" : "652073",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "notascientist",
      "indices" : [ 124, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "236693971320053763",
  "text" : "If you’re storing binary data in DNA, why make T &amp; G = 1 and A &amp; C = 0? Why not T = 00, G = 01, A = 10, and C = 11? #notascientist",
  "id" : 236693971320053763,
  "created_at" : "Sat Aug 18 05:20:14 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.apple.com\" rel=\"nofollow\">iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 95 ],
      "url" : "http://t.co/hIenYwra",
      "expanded_url" : "http://www.extremetech.com/extreme/134672-harvard-cracks-dna-storage-crams-700-terabytes-of-data-into-a-single-gram",
      "display_url" : "extremetech.com/extreme/134672…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "236691033558233088",
  "text" : "Harvard cracks DNA storage, crams 700 terabytes of data into a single gram http://t.co/hIenYwra",
  "id" : 236691033558233088,
  "created_at" : "Sat Aug 18 05:08:34 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ali Berman",
      "screen_name" : "spangley",
      "indices" : [ 0, 9 ],
      "id_str" : "776429",
      "id" : 776429
    }, {
      "name" : "Todd Berman",
      "screen_name" : "tberman",
      "indices" : [ 10, 18 ],
      "id_str" : "15275073",
      "id" : 15275073
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "236680689053995008",
  "geo" : {
  },
  "id_str" : "236681926201724928",
  "in_reply_to_user_id" : 776429,
  "text" : "@spangley @tberman Woah that’s impressive!",
  "id" : 236681926201724928,
  "in_reply_to_status_id" : 236680689053995008,
  "created_at" : "Sat Aug 18 04:32:23 +0000 2012",
  "in_reply_to_screen_name" : "spangley",
  "in_reply_to_user_id_str" : "776429",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 66 ],
      "url" : "http://t.co/7Ny82tza",
      "expanded_url" : "http://flic.kr/p/cTLPW9",
      "display_url" : "flic.kr/p/cTLPW9"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.608666, -122.306167 ]
  },
  "id_str" : "236668538948038658",
  "text" : "8:36pm Playing trains til the tiredness crash http://t.co/7Ny82tza",
  "id" : 236668538948038658,
  "created_at" : "Sat Aug 18 03:39:11 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "christopher jones",
      "screen_name" : "cjlikearockstar",
      "indices" : [ 0, 16 ],
      "id_str" : "34383091",
      "id" : 34383091
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "236646235308687360",
  "geo" : {
  },
  "id_str" : "236646483829587969",
  "in_reply_to_user_id" : 34383091,
  "text" : "@cjlikearockstar Ha! That’s what I like about it too.",
  "id" : 236646483829587969,
  "in_reply_to_status_id" : 236646235308687360,
  "created_at" : "Sat Aug 18 02:11:33 +0000 2012",
  "in_reply_to_screen_name" : "cjlikearockstar",
  "in_reply_to_user_id_str" : "34383091",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sarah kathleen peck",
      "screen_name" : "sarahkpeck",
      "indices" : [ 0, 11 ],
      "id_str" : "196745496",
      "id" : 196745496
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "quackquack",
      "indices" : [ 23, 34 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "236643982321532928",
  "geo" : {
  },
  "id_str" : "236645724908027904",
  "in_reply_to_user_id" : 196745496,
  "text" : "@sarahkpeck Thank you! #quackquack",
  "id" : 236645724908027904,
  "in_reply_to_status_id" : 236643982321532928,
  "created_at" : "Sat Aug 18 02:08:32 +0000 2012",
  "in_reply_to_screen_name" : "sarahkpeck",
  "in_reply_to_user_id_str" : "196745496",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ingopixel",
      "screen_name" : "ingopixel",
      "indices" : [ 0, 10 ],
      "id_str" : "7943892",
      "id" : 7943892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "236642346190639104",
  "geo" : {
  },
  "id_str" : "236643470842933251",
  "in_reply_to_user_id" : 7943892,
  "text" : "@ingopixel Thank you! Yay!",
  "id" : 236643470842933251,
  "in_reply_to_status_id" : 236642346190639104,
  "created_at" : "Sat Aug 18 01:59:34 +0000 2012",
  "in_reply_to_screen_name" : "ingopixel",
  "in_reply_to_user_id_str" : "7943892",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Wang",
      "screen_name" : "brianmwang",
      "indices" : [ 0, 11 ],
      "id_str" : "93478440",
      "id" : 93478440
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "236641932317712384",
  "geo" : {
  },
  "id_str" : "236642078854094848",
  "in_reply_to_user_id" : 93478440,
  "text" : "@brianmwang Health, in my case.",
  "id" : 236642078854094848,
  "in_reply_to_status_id" : 236641932317712384,
  "created_at" : "Sat Aug 18 01:54:02 +0000 2012",
  "in_reply_to_screen_name" : "brianmwang",
  "in_reply_to_user_id_str" : "93478440",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sarah kathleen peck",
      "screen_name" : "sarahkpeck",
      "indices" : [ 0, 11 ],
      "id_str" : "196745496",
      "id" : 196745496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "236641379235807233",
  "geo" : {
  },
  "id_str" : "236641897630810112",
  "in_reply_to_user_id" : 196745496,
  "text" : "@sarahkpeck I like that name too! And am totally on the add-only eating plan methods.",
  "id" : 236641897630810112,
  "in_reply_to_status_id" : 236641379235807233,
  "created_at" : "Sat Aug 18 01:53:19 +0000 2012",
  "in_reply_to_screen_name" : "sarahkpeck",
  "in_reply_to_user_id_str" : "196745496",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "allison kudla",
      "screen_name" : "allisonx",
      "indices" : [ 0, 9 ],
      "id_str" : "14047537",
      "id" : 14047537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "236636697847279617",
  "geo" : {
  },
  "id_str" : "236638791127953408",
  "in_reply_to_user_id" : 14047537,
  "text" : "@allisonx Nice! Check out The Eatery app for easy food journaling too.",
  "id" : 236638791127953408,
  "in_reply_to_status_id" : 236636697847279617,
  "created_at" : "Sat Aug 18 01:40:59 +0000 2012",
  "in_reply_to_screen_name" : "allisonx",
  "in_reply_to_user_id_str" : "14047537",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rudy Jahchan",
      "screen_name" : "rudy",
      "indices" : [ 0, 5 ],
      "id_str" : "779715",
      "id" : 779715
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "236637166787252224",
  "geo" : {
  },
  "id_str" : "236638246409498624",
  "in_reply_to_user_id" : 779715,
  "text" : "@rudy Payout is sorta built in since as your score goes up you can spare a delicious pizza or two. Is that enough?",
  "id" : 236638246409498624,
  "in_reply_to_status_id" : 236637166787252224,
  "created_at" : "Sat Aug 18 01:38:49 +0000 2012",
  "in_reply_to_screen_name" : "rudy",
  "in_reply_to_user_id_str" : "779715",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai",
      "screen_name" : "kaisdavis",
      "indices" : [ 0, 10 ],
      "id_str" : "63337932",
      "id" : 63337932
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "236634677480419329",
  "geo" : {
  },
  "id_str" : "236635962153775104",
  "in_reply_to_user_id" : 63337932,
  "text" : "@kaisdavis Thanks!",
  "id" : 236635962153775104,
  "in_reply_to_status_id" : 236634677480419329,
  "created_at" : "Sat Aug 18 01:29:44 +0000 2012",
  "in_reply_to_screen_name" : "kaisdavis",
  "in_reply_to_user_id_str" : "63337932",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "allison kudla",
      "screen_name" : "allisonx",
      "indices" : [ 0, 9 ],
      "id_str" : "14047537",
      "id" : 14047537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "236632851410460672",
  "geo" : {
  },
  "id_str" : "236633736823857153",
  "in_reply_to_user_id" : 14047537,
  "text" : "@allisonx Awesome! Let me know what your score is after a few days.",
  "id" : 236633736823857153,
  "in_reply_to_status_id" : 236632851410460672,
  "created_at" : "Sat Aug 18 01:20:53 +0000 2012",
  "in_reply_to_screen_name" : "allisonx",
  "in_reply_to_user_id_str" : "14047537",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "236632473080045569",
  "geo" : {
  },
  "id_str" : "236633597199667201",
  "in_reply_to_user_id" : 220226736,
  "text" : "@digitalmiss Thank you! Yeah, choose your own favorite number to aim for. Not too high though.",
  "id" : 236633597199667201,
  "in_reply_to_status_id" : 236632473080045569,
  "created_at" : "Sat Aug 18 01:20:20 +0000 2012",
  "in_reply_to_screen_name" : "KristyT",
  "in_reply_to_user_id_str" : "220226736",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "help",
      "indices" : [ 126, 131 ]
    }, {
      "text" : "thanks",
      "indices" : [ 132, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 125 ],
      "url" : "http://t.co/Od9fnOJ2",
      "expanded_url" : "http://wayoftheduck.com/halfplants",
      "display_url" : "wayoftheduck.com/halfplants"
    } ]
  },
  "geo" : {
  },
  "id_str" : "236629992547692544",
  "text" : "I need some feedback on this super simple eating plan I’m trying to design, called the Half Plants Diet: http://t.co/Od9fnOJ2 #help #thanks",
  "id" : 236629992547692544,
  "created_at" : "Sat Aug 18 01:06:01 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dennis Crowley",
      "screen_name" : "dens",
      "indices" : [ 103, 108 ],
      "id_str" : "418",
      "id" : 418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 97 ],
      "url" : "https://t.co/IYguir3A",
      "expanded_url" : "https://chrome.google.com/webstore/detail/ojhmphdkpgbibohbnpbfiefkgieacjmh",
      "display_url" : "chrome.google.com/webstore/detai…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "236617013076832256",
  "text" : "Super pretty Chrome extension to replace the default boring empty tab page: https://t.co/IYguir3A /via @dens",
  "id" : 236617013076832256,
  "created_at" : "Sat Aug 18 00:14:26 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Hinchley",
      "screen_name" : "hinchley",
      "indices" : [ 3, 12 ],
      "id_str" : "16416992",
      "id" : 16416992
    }, {
      "name" : "Buster Benson",
      "screen_name" : "busterbenson",
      "indices" : [ 14, 27 ],
      "id_str" : "2185",
      "id" : 2185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "236597951101796354",
  "text" : "RT @hinchley: @busterbenson Eat. Not too much. Mostly plants. Move your body. Persistently. Sleep. 8 hours a night. Laugh. With friends.",
  "retweeted_status" : {
    "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Buster Benson",
        "screen_name" : "busterbenson",
        "indices" : [ 0, 13 ],
        "id_str" : "2185",
        "id" : 2185
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "236590572998123520",
    "geo" : {
    },
    "id_str" : "236597184714387456",
    "in_reply_to_user_id" : 2185,
    "text" : "@busterbenson Eat. Not too much. Mostly plants. Move your body. Persistently. Sleep. 8 hours a night. Laugh. With friends.",
    "id" : 236597184714387456,
    "in_reply_to_status_id" : 236590572998123520,
    "created_at" : "Fri Aug 17 22:55:39 +0000 2012",
    "in_reply_to_screen_name" : "busterbenson",
    "in_reply_to_user_id_str" : "2185",
    "user" : {
      "name" : "Peter Hinchley",
      "screen_name" : "hinchley",
      "protected" : false,
      "id_str" : "16416992",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1871587269/Peter-Square_normal.jpg",
      "id" : 16416992,
      "verified" : false
    }
  },
  "id" : 236597951101796354,
  "created_at" : "Fri Aug 17 22:58:41 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "236590572998123520",
  "text" : "What’s your best advice for being healthy or happy (or both)?",
  "id" : 236590572998123520,
  "created_at" : "Fri Aug 17 22:29:22 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sensationalversion",
      "indices" : [ 47, 66 ]
    } ],
    "urls" : [ {
      "indices" : [ 26, 46 ],
      "url" : "http://t.co/QJDOlQLu",
      "expanded_url" : "http://wayoftheduck.com/safety",
      "display_url" : "wayoftheduck.com/safety"
    } ]
  },
  "geo" : {
  },
  "id_str" : "236570454595342337",
  "text" : "Are your tweets safe????? http://t.co/QJDOlQLu #sensationalversion",
  "id" : 236570454595342337,
  "created_at" : "Fri Aug 17 21:09:26 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 63, 71 ],
      "id_str" : "783214",
      "id" : 783214
    }, {
      "name" : "Michael Sippey",
      "screen_name" : "sippey",
      "indices" : [ 73, 80 ],
      "id_str" : "4711",
      "id" : 4711
    }, {
      "name" : "Anil Dash",
      "screen_name" : "anildash",
      "indices" : [ 82, 91 ],
      "id_str" : "36823",
      "id" : 36823
    }, {
      "name" : "Tom Coates",
      "screen_name" : "tomcoates",
      "indices" : [ 93, 103 ],
      "id_str" : "12514",
      "id" : 12514
    }, {
      "name" : "Probably Mat Honan",
      "screen_name" : "mat",
      "indices" : [ 105, 109 ],
      "id_str" : "11113",
      "id" : 11113
    }, {
      "name" : "Oliver Burkeman",
      "screen_name" : "oliverburkeman",
      "indices" : [ 115, 130 ],
      "id_str" : "112037009",
      "id" : 112037009
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http://t.co/QJDOlQLu",
      "expanded_url" : "http://wayoftheduck.com/safety",
      "display_url" : "wayoftheduck.com/safety"
    } ]
  },
  "geo" : {
  },
  "id_str" : "236560179561394176",
  "text" : "A friendly safety reminder: http://t.co/QJDOlQLu\n\n(Inspired by @twitter, @sippey, @anildash, @tomcoates, @mat, and @oliverburkeman)",
  "id" : 236560179561394176,
  "created_at" : "Fri Aug 17 20:28:36 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Probably Mat Honan",
      "screen_name" : "mat",
      "indices" : [ 45, 49 ],
      "id_str" : "11113",
      "id" : 11113
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http://t.co/KUfgblCj",
      "expanded_url" : "http://www.wired.com/gadgetlab/2012/08/mat-honan-data-recovery/all/",
      "display_url" : "wired.com/gadgetlab/2012…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "236558673298726912",
  "text" : "Die by the cloud, get reborn by the cloud RT @mat: So here's the story of how I got my data back. Most of it, at least. http://t.co/KUfgblCj",
  "id" : 236558673298726912,
  "created_at" : "Fri Aug 17 20:22:37 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kimberley",
      "screen_name" : "xaotica",
      "indices" : [ 0, 8 ],
      "id_str" : "13983",
      "id" : 13983
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "236551886986153985",
  "geo" : {
  },
  "id_str" : "236552133472825344",
  "in_reply_to_user_id" : 13983,
  "text" : "@xaotica It just answers the question, is Tweetbot worried about the changes? The answer is no.",
  "id" : 236552133472825344,
  "in_reply_to_status_id" : 236551886986153985,
  "created_at" : "Fri Aug 17 19:56:38 +0000 2012",
  "in_reply_to_screen_name" : "xaotica",
  "in_reply_to_user_id_str" : "13983",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lindy West",
      "screen_name" : "thelindywest",
      "indices" : [ 3, 16 ],
      "id_str" : "73244642",
      "id" : 73244642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "236550580095565824",
  "text" : "RT @thelindywest: You know how sometimes you're sad, but you also have sunglasses on?  B-(",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "236549628210847746",
    "text" : "You know how sometimes you're sad, but you also have sunglasses on?  B-(",
    "id" : 236549628210847746,
    "created_at" : "Fri Aug 17 19:46:40 +0000 2012",
    "user" : {
      "name" : "Lindy West",
      "screen_name" : "thelindywest",
      "protected" : false,
      "id_str" : "73244642",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2606631044/xqbdln60t6zgaj928nhl_normal.jpeg",
      "id" : 73244642,
      "verified" : false
    }
  },
  "id" : 236550580095565824,
  "created_at" : "Fri Aug 17 19:50:27 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Morgan",
      "screen_name" : "MorgonFreeman",
      "indices" : [ 3, 17 ],
      "id_str" : "562057840",
      "id" : 562057840
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "236529397706919936",
  "text" : "RT @MorgonFreeman: I hate the word homophobia. It's not a phobia. You are not scared. You are an asshole.",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.hootsuite.com\" rel=\"nofollow\">HootSuite</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "236212081978929152",
    "text" : "I hate the word homophobia. It's not a phobia. You are not scared. You are an asshole.",
    "id" : 236212081978929152,
    "created_at" : "Thu Aug 16 21:25:23 +0000 2012",
    "user" : {
      "name" : "Morgan",
      "screen_name" : "MorgonFreeman",
      "protected" : false,
      "id_str" : "562057840",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2525018378/c8voh2vynt9r0swsfi45_normal.jpeg",
      "id" : 562057840,
      "verified" : false
    }
  },
  "id" : 236529397706919936,
  "created_at" : "Fri Aug 17 18:26:17 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tweetbot by Tapbots",
      "screen_name" : "tweetbot",
      "indices" : [ 46, 55 ],
      "id_str" : "274626857",
      "id" : 274626857
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http://t.co/f9KkqTNL",
      "expanded_url" : "http://tapbots.com/blog/news/dont-panic",
      "display_url" : "tapbots.com/blog/news/dont…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "236528749766647808",
  "text" : "From one of the bigger Twitter developers: RT @tweetbot: Questions about Twitter’s latest API changes? Don’t Panic! http://t.co/f9KkqTNL",
  "id" : 236528749766647808,
  "created_at" : "Fri Aug 17 18:23:43 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sharon",
      "screen_name" : "sharon",
      "indices" : [ 0, 7 ],
      "id_str" : "260",
      "id" : 260
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "236525939415187458",
  "geo" : {
  },
  "id_str" : "236527327419453441",
  "in_reply_to_user_id" : 260,
  "text" : "@sharon You can do it! :)",
  "id" : 236527327419453441,
  "in_reply_to_status_id" : 236525939415187458,
  "created_at" : "Fri Aug 17 18:18:03 +0000 2012",
  "in_reply_to_screen_name" : "sharon",
  "in_reply_to_user_id_str" : "260",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "236527092500676608",
  "text" : "This is my 10,000th tweet! I should come up with something profound to say… any suggestions?",
  "id" : 236527092500676608,
  "created_at" : "Fri Aug 17 18:17:07 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sharon",
      "screen_name" : "sharon",
      "indices" : [ 0, 7 ],
      "id_str" : "260",
      "id" : 260
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "236523592773427201",
  "geo" : {
  },
  "id_str" : "236525447406575616",
  "in_reply_to_user_id" : 260,
  "text" : "@sharon It could be, but if *you* are ready to change the schedule she should support that decision.",
  "id" : 236525447406575616,
  "in_reply_to_status_id" : 236523592773427201,
  "created_at" : "Fri Aug 17 18:10:35 +0000 2012",
  "in_reply_to_screen_name" : "sharon",
  "in_reply_to_user_id_str" : "260",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sharon",
      "screen_name" : "sharon",
      "indices" : [ 0, 7 ],
      "id_str" : "260",
      "id" : 260
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "236521817391640576",
  "geo" : {
  },
  "id_str" : "236522527260819457",
  "in_reply_to_user_id" : 260,
  "text" : "@sharon That seems very suspicious to me. Don’t just bring it up, tell her what is gonna happen. You hired her!",
  "id" : 236522527260819457,
  "in_reply_to_status_id" : 236521817391640576,
  "created_at" : "Fri Aug 17 17:58:59 +0000 2012",
  "in_reply_to_screen_name" : "sharon",
  "in_reply_to_user_id_str" : "260",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sharon",
      "screen_name" : "sharon",
      "indices" : [ 0, 7 ],
      "id_str" : "260",
      "id" : 260
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "236516543150821377",
  "geo" : {
  },
  "id_str" : "236521123590848512",
  "in_reply_to_user_id" : 260,
  "text" : "@sharon Why not phase it out? We went bi-weekly, and now monthly.",
  "id" : 236521123590848512,
  "in_reply_to_status_id" : 236516543150821377,
  "created_at" : "Fri Aug 17 17:53:24 +0000 2012",
  "in_reply_to_screen_name" : "sharon",
  "in_reply_to_user_id_str" : "260",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "girl jo",
      "screen_name" : "octavekitten",
      "indices" : [ 0, 13 ],
      "id_str" : "16366882",
      "id" : 16366882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "236514734541766656",
  "geo" : {
  },
  "id_str" : "236515448391364608",
  "in_reply_to_user_id" : 16366882,
  "text" : "@octavekitten To see how you respond to an empty threat.",
  "id" : 236515448391364608,
  "in_reply_to_status_id" : 236514734541766656,
  "created_at" : "Fri Aug 17 17:30:51 +0000 2012",
  "in_reply_to_screen_name" : "octavekitten",
  "in_reply_to_user_id_str" : "16366882",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "236513591879151616",
  "text" : "Imagine a hungry tiger behind you, right now, breathing down your neck.",
  "id" : 236513591879151616,
  "created_at" : "Fri Aug 17 17:23:29 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Few",
      "screen_name" : "jfew",
      "indices" : [ 0, 5 ],
      "id_str" : "2067141",
      "id" : 2067141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "236323752621785088",
  "geo" : {
  },
  "id_str" : "236343601024626689",
  "in_reply_to_user_id" : 2067141,
  "text" : "@jfew I think it’s gonna be pretty painless in the end personally. But I may be wrong.",
  "id" : 236343601024626689,
  "in_reply_to_status_id" : 236323752621785088,
  "created_at" : "Fri Aug 17 06:08:00 +0000 2012",
  "in_reply_to_screen_name" : "jfew",
  "in_reply_to_user_id_str" : "2067141",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagr.am\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 53 ],
      "url" : "http://t.co/GSjpYfrK",
      "expanded_url" : "http://instagr.am/p/OafboVo0Dy/",
      "display_url" : "instagr.am/p/OafboVo0Dy/"
    } ]
  },
  "geo" : {
  },
  "id_str" : "236306221546758145",
  "text" : "8:36pm Potty training in Ballard http://t.co/GSjpYfrK",
  "id" : 236306221546758145,
  "created_at" : "Fri Aug 17 03:39:28 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagr.am\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 40 ],
      "url" : "http://t.co/G1UGqU0z",
      "expanded_url" : "http://instagr.am/p/OabpZ3I0A0/",
      "display_url" : "instagr.am/p/OabpZ3I0A0/"
    } ]
  },
  "geo" : {
  },
  "id_str" : "236293635677761536",
  "text" : "Pedicab in training http://t.co/G1UGqU0z",
  "id" : 236293635677761536,
  "created_at" : "Fri Aug 17 02:49:27 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Few",
      "screen_name" : "jfew",
      "indices" : [ 0, 5 ],
      "id_str" : "2067141",
      "id" : 2067141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "236266941063495680",
  "geo" : {
  },
  "id_str" : "236283479405510656",
  "in_reply_to_user_id" : 2067141,
  "text" : "@jfew I think this is just a way of making sure they get something back for the huge support and infrastructure costs that their API has.",
  "id" : 236283479405510656,
  "in_reply_to_status_id" : 236266941063495680,
  "created_at" : "Fri Aug 17 02:09:06 +0000 2012",
  "in_reply_to_screen_name" : "jfew",
  "in_reply_to_user_id_str" : "2067141",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Few",
      "screen_name" : "jfew",
      "indices" : [ 0, 5 ],
      "id_str" : "2067141",
      "id" : 2067141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "236266941063495680",
  "geo" : {
  },
  "id_str" : "236283122625417217",
  "in_reply_to_user_id" : 2067141,
  "text" : "@jfew True. But what other company out there has other companies building their core experience for them?",
  "id" : 236283122625417217,
  "in_reply_to_status_id" : 236266941063495680,
  "created_at" : "Fri Aug 17 02:07:41 +0000 2012",
  "in_reply_to_screen_name" : "jfew",
  "in_reply_to_user_id_str" : "2067141",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MG Siegler",
      "screen_name" : "parislemon",
      "indices" : [ 3, 14 ],
      "id_str" : "652193",
      "id" : 652193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "236265194043604993",
  "text" : "RT @parislemon: wish twitter simply would have made a dodecagon ven diagram to straighten all this out.",
  "retweeted_status" : {
    "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "236250916800565248",
    "text" : "wish twitter simply would have made a dodecagon ven diagram to straighten all this out.",
    "id" : 236250916800565248,
    "created_at" : "Thu Aug 16 23:59:42 +0000 2012",
    "user" : {
      "name" : "MG Siegler",
      "screen_name" : "parislemon",
      "protected" : false,
      "id_str" : "652193",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2748300201/ecc4dbe1c912ebac9a7aee2e85b51859_normal.jpeg",
      "id" : 652193,
      "verified" : true
    }
  },
  "id" : 236265194043604993,
  "created_at" : "Fri Aug 17 00:56:26 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Few",
      "screen_name" : "jfew",
      "indices" : [ 0, 5 ],
      "id_str" : "2067141",
      "id" : 2067141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "236250574809620480",
  "geo" : {
  },
  "id_str" : "236265142621442048",
  "in_reply_to_user_id" : 2067141,
  "text" : "@jfew Which app are you worried about?",
  "id" : 236265142621442048,
  "in_reply_to_status_id" : 236250574809620480,
  "created_at" : "Fri Aug 17 00:56:14 +0000 2012",
  "in_reply_to_screen_name" : "jfew",
  "in_reply_to_user_id_str" : "2067141",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John",
      "screen_name" : "joltdude",
      "indices" : [ 0, 9 ],
      "id_str" : "261274640",
      "id" : 261274640
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "236241251425460224",
  "geo" : {
  },
  "id_str" : "236261549545762818",
  "in_reply_to_user_id" : 261274640,
  "text" : "@joltdude I just don’t follow your logic.",
  "id" : 236261549545762818,
  "in_reply_to_status_id" : 236241251425460224,
  "created_at" : "Fri Aug 17 00:41:57 +0000 2012",
  "in_reply_to_screen_name" : "joltdude",
  "in_reply_to_user_id_str" : "261274640",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John",
      "screen_name" : "joltdude",
      "indices" : [ 0, 9 ],
      "id_str" : "261274640",
      "id" : 261274640
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "236238084965019648",
  "geo" : {
  },
  "id_str" : "236238734994075648",
  "in_reply_to_user_id" : 261274640,
  "text" : "@joltdude That makes me think that you’re pattern-matching and not actually reading the specifics of this particular situation.",
  "id" : 236238734994075648,
  "in_reply_to_status_id" : 236238084965019648,
  "created_at" : "Thu Aug 16 23:11:18 +0000 2012",
  "in_reply_to_screen_name" : "joltdude",
  "in_reply_to_user_id_str" : "261274640",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twitter API",
      "screen_name" : "twitterapi",
      "indices" : [ 3, 14 ],
      "id_str" : "6253282",
      "id" : 6253282
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "236236831828627457",
  "text" : "RT @twitterapi: As promised, we just posted more details on upcoming changes to the platform and a new version of the API, v1.1 https:// ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 112, 133 ],
        "url" : "https://t.co/W7DYaTDY",
        "expanded_url" : "https://dev.twitter.com/blog/changes-coming-to-twitter-api",
        "display_url" : "dev.twitter.com/blog/changes-c…"
      } ]
    },
    "geo" : {
    },
    "id_str" : "236230975980466178",
    "text" : "As promised, we just posted more details on upcoming changes to the platform and a new version of the API, v1.1 https://t.co/W7DYaTDY",
    "id" : 236230975980466178,
    "created_at" : "Thu Aug 16 22:40:28 +0000 2012",
    "user" : {
      "name" : "Twitter API",
      "screen_name" : "twitterapi",
      "protected" : false,
      "id_str" : "6253282",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2284174872/7df3h38zabcvjylnyfe3_normal.png",
      "id" : 6253282,
      "verified" : true
    }
  },
  "id" : 236236831828627457,
  "created_at" : "Thu Aug 16 23:03:44 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://simplymeasured.com\" rel=\"nofollow\">Simply Measured</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Simply Measured",
      "screen_name" : "simplymeasured",
      "indices" : [ 12, 27 ],
      "id_str" : "92162698",
      "id" : 92162698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 91 ],
      "url" : "http://t.co/QCmPH4ew",
      "expanded_url" : "http://bit.ly/KQwnwB",
      "display_url" : "bit.ly/KQwnwB"
    } ]
  },
  "geo" : {
  },
  "id_str" : "236194232635895808",
  "text" : "I just used @simplymeasured to analyze my Instagram profile in Excel - http://t.co/QCmPH4ew",
  "id" : 236194232635895808,
  "created_at" : "Thu Aug 16 20:14:27 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Will Lam",
      "screen_name" : "will_lam",
      "indices" : [ 0, 9 ],
      "id_str" : "16031604",
      "id" : 16031604
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 57 ],
      "url" : "http://t.co/7xOaE3r1",
      "expanded_url" : "http://catanworld.goko.com/prefinery/index.html",
      "display_url" : "catanworld.goko.com/prefinery/inde…"
    } ]
  },
  "in_reply_to_status_id_str" : "236185418008256513",
  "geo" : {
  },
  "id_str" : "236188241789861889",
  "in_reply_to_user_id" : 16031604,
  "text" : "@will_lam Yup, apparently. Try this: http://t.co/7xOaE3r1",
  "id" : 236188241789861889,
  "in_reply_to_status_id" : 236185418008256513,
  "created_at" : "Thu Aug 16 19:50:39 +0000 2012",
  "in_reply_to_screen_name" : "will_lam",
  "in_reply_to_user_id_str" : "16031604",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Randy Stewart",
      "screen_name" : "stewtopia",
      "indices" : [ 3, 13 ],
      "id_str" : "5651",
      "id" : 5651
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 96 ],
      "url" : "http://t.co/QwYfgML8",
      "expanded_url" : "http://bit.ly/N6hx0A",
      "display_url" : "bit.ly/N6hx0A"
    }, {
      "indices" : [ 106, 126 ],
      "url" : "http://t.co/2VlOzX2M",
      "expanded_url" : "http://catanworld.goko.com/prefinery/index.html",
      "display_url" : "catanworld.goko.com/prefinery/inde…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "236184617613414400",
  "text" : "RT @stewtopia: Really looking forward to playing the new Catan World. read: http://t.co/QwYfgML8 sign up: http://t.co/2VlOzX2M Congrats  ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Grant Goodale",
        "screen_name" : "ggoodale",
        "indices" : [ 121, 130 ],
        "id_str" : "4270261",
        "id" : 4270261
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 61, 81 ],
        "url" : "http://t.co/QwYfgML8",
        "expanded_url" : "http://bit.ly/N6hx0A",
        "display_url" : "bit.ly/N6hx0A"
      }, {
        "indices" : [ 91, 111 ],
        "url" : "http://t.co/2VlOzX2M",
        "expanded_url" : "http://catanworld.goko.com/prefinery/index.html",
        "display_url" : "catanworld.goko.com/prefinery/inde…"
      } ]
    },
    "geo" : {
    },
    "id_str" : "236132687650377729",
    "text" : "Really looking forward to playing the new Catan World. read: http://t.co/QwYfgML8 sign up: http://t.co/2VlOzX2M Congrats @ggoodale",
    "id" : 236132687650377729,
    "created_at" : "Thu Aug 16 16:09:54 +0000 2012",
    "user" : {
      "name" : "Randy Stewart",
      "screen_name" : "stewtopia",
      "protected" : false,
      "id_str" : "5651",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1269210192/randy_normal.jpg",
      "id" : 5651,
      "verified" : false
    }
  },
  "id" : 236184617613414400,
  "created_at" : "Thu Aug 16 19:36:15 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://timehop.com/\" rel=\"nofollow\">Timehop</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 89 ],
      "url" : "http://t.co/d0jVUifu",
      "expanded_url" : "http://timehop.com/u/80600",
      "display_url" : "timehop.com/u/80600"
    } ]
  },
  "geo" : {
  },
  "id_str" : "236184213123104768",
  "text" : "I'm sharing my nostalgic photos and stories on Timehop. Follow me at http://t.co/d0jVUifu !",
  "id" : 236184213123104768,
  "created_at" : "Thu Aug 16 19:34:39 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lisa Phillips",
      "screen_name" : "lisaphillips",
      "indices" : [ 0, 13 ],
      "id_str" : "733383",
      "id" : 733383
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "236155889436991489",
  "geo" : {
  },
  "id_str" : "236157358273859584",
  "in_reply_to_user_id" : 733383,
  "text" : "@lisaphillips Thank you! Excited to check it out soon!",
  "id" : 236157358273859584,
  "in_reply_to_status_id" : 236155889436991489,
  "created_at" : "Thu Aug 16 17:47:56 +0000 2012",
  "in_reply_to_screen_name" : "lisaphillips",
  "in_reply_to_user_id_str" : "733383",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Torrez",
      "screen_name" : "torrez",
      "indices" : [ 0, 7 ],
      "id_str" : "11604",
      "id" : 11604
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "235953625590026240",
  "geo" : {
  },
  "id_str" : "236004861454479360",
  "in_reply_to_user_id" : 11604,
  "text" : "@torrez Interesting point! But Peabrain is private… no need to be clever there, right?",
  "id" : 236004861454479360,
  "in_reply_to_status_id" : 235953625590026240,
  "created_at" : "Thu Aug 16 07:41:58 +0000 2012",
  "in_reply_to_screen_name" : "torrez",
  "in_reply_to_user_id_str" : "11604",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tumblr.com/\" rel=\"nofollow\">Tumblr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 125 ],
      "url" : "http://t.co/24pzpcAs",
      "expanded_url" : "http://tmblr.co/ZQJvayRWC5XD",
      "display_url" : "tmblr.co/ZQJvayRWC5XD"
    } ]
  },
  "geo" : {
  },
  "id_str" : "235951759279931393",
  "text" : "\"Of course, the sharing of minutaie hasn’t disappeared on social media. But what I have noticed is a...\" http://t.co/24pzpcAs",
  "id" : 235951759279931393,
  "created_at" : "Thu Aug 16 04:10:57 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hotrobot",
      "indices" : [ 15, 24 ]
    } ],
    "urls" : [ {
      "indices" : [ 66, 86 ],
      "url" : "http://t.co/neQSLJFk",
      "expanded_url" : "http://flic.kr/p/cSCQ2f",
      "display_url" : "flic.kr/p/cSCQ2f"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6085, -122.306 ]
  },
  "id_str" : "235949999073157122",
  "text" : "8:36pm Another #hotrobot kinda night (with my favorite ex-robots) http://t.co/neQSLJFk",
  "id" : 235949999073157122,
  "created_at" : "Thu Aug 16 04:03:58 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "April Schiller",
      "screen_name" : "the_april",
      "indices" : [ 0, 10 ],
      "id_str" : "16644937",
      "id" : 16644937
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "235917417178595329",
  "geo" : {
  },
  "id_str" : "235918697024348161",
  "in_reply_to_user_id" : 16644937,
  "text" : "@the_april There’s a new sensationalist article about that which is totally wrong.",
  "id" : 235918697024348161,
  "in_reply_to_status_id" : 235917417178595329,
  "created_at" : "Thu Aug 16 01:59:35 +0000 2012",
  "in_reply_to_screen_name" : "the_april",
  "in_reply_to_user_id_str" : "16644937",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Medium",
      "screen_name" : "Medium",
      "indices" : [ 5, 12 ],
      "id_str" : "571202103",
      "id" : 571202103
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "pleaseletmein",
      "indices" : [ 92, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 70, 91 ],
      "url" : "https://t.co/q21sAEJI",
      "expanded_url" : "https://medium.com/c/7707024e442b",
      "display_url" : "medium.com/c/7707024e442b"
    } ]
  },
  "geo" : {
  },
  "id_str" : "235906602010570752",
  "text" : "This @medium thing looks promising. Love the photo-collection design: https://t.co/q21sAEJI #pleaseletmein",
  "id" : 235906602010570752,
  "created_at" : "Thu Aug 16 01:11:31 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Coates",
      "screen_name" : "tomcoates",
      "indices" : [ 0, 10 ],
      "id_str" : "12514",
      "id" : 12514
    }, {
      "name" : "Evan Williams",
      "screen_name" : "ev",
      "indices" : [ 26, 29 ],
      "id_str" : "20",
      "id" : 20
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "235905534753124352",
  "geo" : {
  },
  "id_str" : "235905760918384640",
  "in_reply_to_user_id" : 12514,
  "text" : "@tomcoates Pretty please, @ev? :)",
  "id" : 235905760918384640,
  "in_reply_to_status_id" : 235905534753124352,
  "created_at" : "Thu Aug 16 01:08:10 +0000 2012",
  "in_reply_to_screen_name" : "tomcoates",
  "in_reply_to_user_id_str" : "12514",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Coates",
      "screen_name" : "tomcoates",
      "indices" : [ 0, 10 ],
      "id_str" : "12514",
      "id" : 12514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "235886603787194368",
  "geo" : {
  },
  "id_str" : "235905341882261504",
  "in_reply_to_user_id" : 12514,
  "text" : "@tomcoates Awesome, dude. Got any extra invites for us? :)",
  "id" : 235905341882261504,
  "in_reply_to_status_id" : 235886603787194368,
  "created_at" : "Thu Aug 16 01:06:31 +0000 2012",
  "in_reply_to_screen_name" : "tomcoates",
  "in_reply_to_user_id_str" : "12514",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KaiDavis",
      "screen_name" : "KaiDavis",
      "indices" : [ 14, 23 ],
      "id_str" : "7694122",
      "id" : 7694122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 104 ],
      "url" : "http://t.co/L3VJQWqe",
      "expanded_url" : "http://kaisdavis.com/building-habits-with-reminders/",
      "display_url" : "kaisdavis.com/building-habit…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "235905169597009920",
  "text" : "Great post by @kaidavis explaining how he uses alarms on his phone to build habits: http://t.co/L3VJQWqe\n\nGonna check out that Due app now.",
  "id" : 235905169597009920,
  "created_at" : "Thu Aug 16 01:05:49 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai",
      "screen_name" : "kaisdavis",
      "indices" : [ 0, 10 ],
      "id_str" : "63337932",
      "id" : 63337932
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "235900031499132928",
  "geo" : {
  },
  "id_str" : "235904936888643584",
  "in_reply_to_user_id" : 63337932,
  "text" : "@kaisdavis That’s awesome!",
  "id" : 235904936888643584,
  "in_reply_to_status_id" : 235900031499132928,
  "created_at" : "Thu Aug 16 01:04:54 +0000 2012",
  "in_reply_to_screen_name" : "kaisdavis",
  "in_reply_to_user_id_str" : "63337932",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Johnson",
      "screen_name" : "stevenbjohnson",
      "indices" : [ 99, 114 ],
      "id_str" : "2182641",
      "id" : 2182641
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http://t.co/ZwsjY1DS",
      "expanded_url" : "http://peabrain.co",
      "display_url" : "peabrain.co"
    }, {
      "indices" : [ 73, 94 ],
      "url" : "https://t.co/H5NQNc3j",
      "expanded_url" : "https://medium.com/p/8d6e7df7ae58",
      "display_url" : "medium.com/p/8d6e7df7ae58"
    } ]
  },
  "geo" : {
  },
  "id_str" : "235904394284118016",
  "text" : "I’ve been using http://t.co/ZwsjY1DS as a spark file, as mentioned here: https://t.co/H5NQNc3j /cc @stevenbjohnson",
  "id" : 235904394284118016,
  "created_at" : "Thu Aug 16 01:02:45 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Maura McGovern",
      "screen_name" : "mmcgovern",
      "indices" : [ 0, 10 ],
      "id_str" : "15856582",
      "id" : 15856582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "235888033638002688",
  "geo" : {
  },
  "id_str" : "235897808564129792",
  "in_reply_to_user_id" : 15856582,
  "text" : "@mmcgovern I haven’t! I’ll add it to my to-read pile.",
  "id" : 235897808564129792,
  "in_reply_to_status_id" : 235888033638002688,
  "created_at" : "Thu Aug 16 00:36:34 +0000 2012",
  "in_reply_to_screen_name" : "mmcgovern",
  "in_reply_to_user_id_str" : "15856582",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Les Hill",
      "screen_name" : "leshill",
      "indices" : [ 0, 8 ],
      "id_str" : "12495752",
      "id" : 12495752
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "235841540222771202",
  "geo" : {
  },
  "id_str" : "235846189776515073",
  "in_reply_to_user_id" : 12495752,
  "text" : "@leshill Thanks! Yeah, eventually…",
  "id" : 235846189776515073,
  "in_reply_to_status_id" : 235841540222771202,
  "created_at" : "Wed Aug 15 21:11:28 +0000 2012",
  "in_reply_to_screen_name" : "leshill",
  "in_reply_to_user_id_str" : "12495752",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "That Shit Cray",
      "screen_name" : "borat",
      "indices" : [ 3, 9 ],
      "id_str" : "734753",
      "id" : 734753
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "235840320020033536",
  "text" : "RT @borat: they need an app that tells me when the traffic light goes green, i'm really tired of having to look up from my phone to figu ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "235839514659155968",
    "text" : "they need an app that tells me when the traffic light goes green, i'm really tired of having to look up from my phone to figure it out.",
    "id" : 235839514659155968,
    "created_at" : "Wed Aug 15 20:44:56 +0000 2012",
    "user" : {
      "name" : "That Shit Cray",
      "screen_name" : "borat",
      "protected" : false,
      "id_str" : "734753",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1849588698/you-won-that-shit-cray_normal.jpg",
      "id" : 734753,
      "verified" : false
    }
  },
  "id" : 235840320020033536,
  "created_at" : "Wed Aug 15 20:48:08 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Messina™",
      "screen_name" : "chrismessina",
      "indices" : [ 10, 23 ],
      "id_str" : "1186",
      "id" : 1186
    }, {
      "name" : "brynn evans",
      "screen_name" : "brynn",
      "indices" : [ 28, 34 ],
      "id_str" : "8708232",
      "id" : 8708232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "235836553929302016",
  "text" : "Thank you @chrismessina and @brynn for hosting me, feeding me, serving me drinks, and teaching me about colors yesterday.",
  "id" : 235836553929302016,
  "created_at" : "Wed Aug 15 20:33:10 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Schappell",
      "screen_name" : "daveschappell",
      "indices" : [ 18, 32 ],
      "id_str" : "820661",
      "id" : 820661
    }, {
      "name" : "Haiku Deck",
      "screen_name" : "HaikuDeck",
      "indices" : [ 57, 67 ],
      "id_str" : "352538333",
      "id" : 352538333
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 139 ],
      "url" : "http://t.co/x95yKJ2V",
      "expanded_url" : "http://www.geekwire.com/2012/haiku-deck/",
      "display_url" : "geekwire.com/2012/haiku-dec…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "235796900937342977",
  "text" : "Looks awesome! RT @daveschappell: A next-gen PowerPoint? @HaikuDeck looks to help people make beautiful presentations: http://t.co/x95yKJ2V",
  "id" : 235796900937342977,
  "created_at" : "Wed Aug 15 17:55:36 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 3, 13 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http://t.co/ZDWUbZXI",
      "expanded_url" : "http://instagr.am/p/OVxTy4OFTO/",
      "display_url" : "instagr.am/p/OVxTy4OFTO/"
    } ]
  },
  "geo" : {
  },
  "id_str" : "235759755577143296",
  "text" : "RT @kellianne: The Bensons! http://t.co/ZDWUbZXI",
  "retweeted_status" : {
    "source" : "<a href=\"http://instagr.am\" rel=\"nofollow\">Instagram</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 13, 33 ],
        "url" : "http://t.co/ZDWUbZXI",
        "expanded_url" : "http://instagr.am/p/OVxTy4OFTO/",
        "display_url" : "instagr.am/p/OVxTy4OFTO/"
      } ]
    },
    "geo" : {
    },
    "id_str" : "235637381485690880",
    "text" : "The Bensons! http://t.co/ZDWUbZXI",
    "id" : 235637381485690880,
    "created_at" : "Wed Aug 15 07:21:44 +0000 2012",
    "user" : {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "protected" : false,
      "id_str" : "7362142",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/58277407/l1000976_normal.jpg",
      "id" : 7362142,
      "verified" : false
    }
  },
  "id" : 235759755577143296,
  "created_at" : "Wed Aug 15 15:28:00 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stanislav Shabalin",
      "screen_name" : "voxpuibr",
      "indices" : [ 0, 9 ],
      "id_str" : "41597893",
      "id" : 41597893
    }, {
      "name" : "Parmy Olson",
      "screen_name" : "parmy",
      "indices" : [ 46, 52 ],
      "id_str" : "19116515",
      "id" : 19116515
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "235752058324668416",
  "geo" : {
  },
  "id_str" : "235753404444594176",
  "in_reply_to_user_id" : 41597893,
  "text" : "@voxpuibr There is! That’s how I read it. /cc @parmy",
  "id" : 235753404444594176,
  "in_reply_to_status_id" : 235752058324668416,
  "created_at" : "Wed Aug 15 15:02:46 +0000 2012",
  "in_reply_to_screen_name" : "voxpuibr",
  "in_reply_to_user_id_str" : "41597893",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lane Collins",
      "screen_name" : "lane",
      "indices" : [ 0, 5 ],
      "id_str" : "541",
      "id" : 541
    }, {
      "name" : "Helena Price",
      "screen_name" : "helena",
      "indices" : [ 6, 13 ],
      "id_str" : "19699682",
      "id" : 19699682
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "235460712397406208",
  "geo" : {
  },
  "id_str" : "235745339506847745",
  "in_reply_to_user_id" : 541,
  "text" : "@lane @helena Yes! No immediately but within the next 6 months or so. But will be coming down here a lot in the meantime.",
  "id" : 235745339506847745,
  "in_reply_to_status_id" : 235460712397406208,
  "created_at" : "Wed Aug 15 14:30:43 +0000 2012",
  "in_reply_to_screen_name" : "lane",
  "in_reply_to_user_id_str" : "541",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://mobile.twitter.com\" rel=\"nofollow\">Mobile Web</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Frommer",
      "screen_name" : "fromedome",
      "indices" : [ 3, 13 ],
      "id_str" : "8479062",
      "id" : 8479062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "235743343827615744",
  "text" : "RT @fromedome: Just signed up for 2-factor authentication on Instagram. You have to photograph a kale salad to login.",
  "retweeted_status" : {
    "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "233388684114800640",
    "text" : "Just signed up for 2-factor authentication on Instagram. You have to photograph a kale salad to login.",
    "id" : 233388684114800640,
    "created_at" : "Thu Aug 09 02:26:13 +0000 2012",
    "user" : {
      "name" : "Dan Frommer",
      "screen_name" : "fromedome",
      "protected" : false,
      "id_str" : "8479062",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2761253905/6de857b2e01a9cc8985fb6df7121956c_normal.jpeg",
      "id" : 8479062,
      "verified" : false
    }
  },
  "id" : 235743343827615744,
  "created_at" : "Wed Aug 15 14:22:47 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amit superamit Gupta",
      "screen_name" : "superamit",
      "indices" : [ 0, 10 ],
      "id_str" : "10609",
      "id" : 10609
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "235461414171586560",
  "geo" : {
  },
  "id_str" : "235620081659424768",
  "in_reply_to_user_id" : 10609,
  "text" : "@superamit Thank you. Can’t wait to see you too again!",
  "id" : 235620081659424768,
  "in_reply_to_status_id" : 235461414171586560,
  "created_at" : "Wed Aug 15 06:12:59 +0000 2012",
  "in_reply_to_screen_name" : "superamit",
  "in_reply_to_user_id_str" : "10609",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Tauber",
      "screen_name" : "jtauber",
      "indices" : [ 0, 8 ],
      "id_str" : "1583811",
      "id" : 1583811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 133 ],
      "url" : "http://t.co/bBJaraQw",
      "expanded_url" : "http://wayoftheduck.com",
      "display_url" : "wayoftheduck.com"
    } ]
  },
  "in_reply_to_status_id_str" : "235462912502792193",
  "geo" : {
  },
  "id_str" : "235619947148095489",
  "in_reply_to_user_id" : 1583811,
  "text" : "@jtauber Yes, please do. I’m trying to share as much as I can to help others in the meantime. To be posted here: http://t.co/bBJaraQw",
  "id" : 235619947148095489,
  "in_reply_to_status_id" : 235462912502792193,
  "created_at" : "Wed Aug 15 06:12:27 +0000 2012",
  "in_reply_to_screen_name" : "jtauber",
  "in_reply_to_user_id_str" : "1583811",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "stephdub",
      "screen_name" : "stephdub",
      "indices" : [ 0, 9 ],
      "id_str" : "14936359",
      "id" : 14936359
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "235477795172651008",
  "geo" : {
  },
  "id_str" : "235619564258488321",
  "in_reply_to_user_id" : 14936359,
  "text" : "@stephdub !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! :)",
  "id" : 235619564258488321,
  "in_reply_to_status_id" : 235477795172651008,
  "created_at" : "Wed Aug 15 06:10:56 +0000 2012",
  "in_reply_to_screen_name" : "stephdub",
  "in_reply_to_user_id_str" : "14936359",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ali Berman",
      "screen_name" : "spangley",
      "indices" : [ 0, 9 ],
      "id_str" : "776429",
      "id" : 776429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "235497480240902144",
  "geo" : {
  },
  "id_str" : "235619086632116226",
  "in_reply_to_user_id" : 776429,
  "text" : "@spangley We are so excited! Find me a cheap vacant apt near you, please!",
  "id" : 235619086632116226,
  "in_reply_to_status_id" : 235497480240902144,
  "created_at" : "Wed Aug 15 06:09:02 +0000 2012",
  "in_reply_to_screen_name" : "spangley",
  "in_reply_to_user_id_str" : "776429",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Harrison",
      "screen_name" : "sourjayne",
      "indices" : [ 0, 10 ],
      "id_str" : "4981271",
      "id" : 4981271
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "235498065727991809",
  "geo" : {
  },
  "id_str" : "235618891395629056",
  "in_reply_to_user_id" : 4981271,
  "text" : "@sourjayne You heard me! :)",
  "id" : 235618891395629056,
  "in_reply_to_status_id" : 235498065727991809,
  "created_at" : "Wed Aug 15 06:08:15 +0000 2012",
  "in_reply_to_screen_name" : "sourjayne",
  "in_reply_to_user_id_str" : "4981271",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "D. Keith Robinson",
      "screen_name" : "dkr",
      "indices" : [ 0, 4 ],
      "id_str" : "10877",
      "id" : 10877
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "235508386161098753",
  "geo" : {
  },
  "id_str" : "235618814010744832",
  "in_reply_to_user_id" : 10877,
  "text" : "@dkr Thank you. Stoked!",
  "id" : 235618814010744832,
  "in_reply_to_status_id" : 235508386161098753,
  "created_at" : "Wed Aug 15 06:07:57 +0000 2012",
  "in_reply_to_screen_name" : "dkr",
  "in_reply_to_user_id_str" : "10877",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Santangelo",
      "screen_name" : "endquote",
      "indices" : [ 0, 9 ],
      "id_str" : "408",
      "id" : 408
    }, {
      "name" : "twilio",
      "screen_name" : "twilio",
      "indices" : [ 15, 22 ],
      "id_str" : "15936194",
      "id" : 15936194
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "235565023735459841",
  "geo" : {
  },
  "id_str" : "235618751909863425",
  "in_reply_to_user_id" : 408,
  "text" : "@endquote Yes. @twilio, which is plain awesome.",
  "id" : 235618751909863425,
  "in_reply_to_status_id" : 235565023735459841,
  "created_at" : "Wed Aug 15 06:07:42 +0000 2012",
  "in_reply_to_screen_name" : "endquote",
  "in_reply_to_user_id_str" : "408",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zack Shapiro",
      "screen_name" : "ZackShapiro",
      "indices" : [ 0, 12 ],
      "id_str" : "15999465",
      "id" : 15999465
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "235610173786443776",
  "geo" : {
  },
  "id_str" : "235618592148828161",
  "in_reply_to_user_id" : 15999465,
  "text" : "@ZackShapiro Yes! Though it’ll have to be next week as I’m headed back to Seattle early tomorrow.",
  "id" : 235618592148828161,
  "in_reply_to_status_id" : 235610173786443776,
  "created_at" : "Wed Aug 15 06:07:04 +0000 2012",
  "in_reply_to_screen_name" : "ZackShapiro",
  "in_reply_to_user_id_str" : "15999465",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Progressive",
      "screen_name" : "Progressive",
      "indices" : [ 69, 81 ],
      "id_str" : "3331681",
      "id" : 3331681
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 137 ],
      "url" : "http://t.co/wTqpUvXc",
      "expanded_url" : "http://pgrs.in/R0vAtv",
      "display_url" : "pgrs.in/R0vAtv"
    } ]
  },
  "geo" : {
  },
  "id_str" : "235618103474651136",
  "text" : "A better response… though it all depends on their actual details. RT @Progressive: Our statement on the Fisher case: http://t.co/wTqpUvXc",
  "id" : 235618103474651136,
  "created_at" : "Wed Aug 15 06:05:08 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagr.am\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 68 ],
      "url" : "http://t.co/Zy0Aa91b",
      "expanded_url" : "http://instagr.am/p/OVXoBBI0P1/",
      "display_url" : "instagr.am/p/OVXoBBI0P1/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.750391, -122.425197 ]
  },
  "id_str" : "235581052888952832",
  "text" : "8:36pm Dinner with Chris and Brynn  @ Team Lift http://t.co/Zy0Aa91b",
  "id" : 235581052888952832,
  "created_at" : "Wed Aug 15 03:37:54 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lane Collins",
      "screen_name" : "lane",
      "indices" : [ 0, 5 ],
      "id_str" : "541",
      "id" : 541
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "235460333085528065",
  "geo" : {
  },
  "id_str" : "235460598303948800",
  "in_reply_to_user_id" : 541,
  "text" : "@lane WOO!",
  "id" : 235460598303948800,
  "in_reply_to_status_id" : 235460333085528065,
  "created_at" : "Tue Aug 14 19:39:15 +0000 2012",
  "in_reply_to_screen_name" : "lane",
  "in_reply_to_user_id_str" : "541",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Douglas Dollars",
      "screen_name" : "theDoug",
      "indices" : [ 0, 8 ],
      "id_str" : "36043",
      "id" : 36043
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "235460103816507392",
  "geo" : {
  },
  "id_str" : "235460536001757185",
  "in_reply_to_user_id" : 36043,
  "text" : "@theDoug Thank you!",
  "id" : 235460536001757185,
  "in_reply_to_status_id" : 235460103816507392,
  "created_at" : "Tue Aug 14 19:39:01 +0000 2012",
  "in_reply_to_screen_name" : "theDoug",
  "in_reply_to_user_id_str" : "36043",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helena Price",
      "screen_name" : "helena",
      "indices" : [ 0, 7 ],
      "id_str" : "19699682",
      "id" : 19699682
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "235460047583453185",
  "geo" : {
  },
  "id_str" : "235460492137730048",
  "in_reply_to_user_id" : 19699682,
  "text" : "@helena Yup! :)",
  "id" : 235460492137730048,
  "in_reply_to_status_id" : 235460047583453185,
  "created_at" : "Tue Aug 14 19:38:50 +0000 2012",
  "in_reply_to_screen_name" : "helena",
  "in_reply_to_user_id_str" : "19699682",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "April V. Walters",
      "screen_name" : "aprilini",
      "indices" : [ 0, 9 ],
      "id_str" : "875511",
      "id" : 875511
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "235459895858704385",
  "geo" : {
  },
  "id_str" : "235460443655778304",
  "in_reply_to_user_id" : 875511,
  "text" : "@aprilini Thanks! I’m stoked. And will be moving to your fair city shortly.",
  "id" : 235460443655778304,
  "in_reply_to_status_id" : 235459895858704385,
  "created_at" : "Tue Aug 14 19:38:39 +0000 2012",
  "in_reply_to_screen_name" : "aprilini",
  "in_reply_to_user_id_str" : "875511",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Haughey",
      "screen_name" : "mathowie",
      "indices" : [ 0, 9 ],
      "id_str" : "761975",
      "id" : 761975
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "235459105618280448",
  "geo" : {
  },
  "id_str" : "235460276483395585",
  "in_reply_to_user_id" : 761975,
  "text" : "@mathowie Thanks! Yeah moving down eventually.",
  "id" : 235460276483395585,
  "in_reply_to_status_id" : 235459105618280448,
  "created_at" : "Tue Aug 14 19:37:59 +0000 2012",
  "in_reply_to_screen_name" : "mathowie",
  "in_reply_to_user_id_str" : "761975",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Darya Pino",
      "screen_name" : "summertomato",
      "indices" : [ 0, 13 ],
      "id_str" : "17396212",
      "id" : 17396212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "235449043503960064",
  "geo" : {
  },
  "id_str" : "235460065014972417",
  "in_reply_to_user_id" : 17396212,
  "text" : "@summertomato Oh yeah. Me too.",
  "id" : 235460065014972417,
  "in_reply_to_status_id" : 235449043503960064,
  "created_at" : "Tue Aug 14 19:37:08 +0000 2012",
  "in_reply_to_screen_name" : "summertomato",
  "in_reply_to_user_id_str" : "17396212",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Crocker",
      "screen_name" : "nickcrocker",
      "indices" : [ 22, 34 ],
      "id_str" : "30801469",
      "id" : 30801469
    }, {
      "name" : "Skillshare",
      "screen_name" : "skillshare",
      "indices" : [ 51, 62 ],
      "id_str" : "171613435",
      "id" : 171613435
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 119 ],
      "url" : "http://t.co/pt9CVj1Z",
      "expanded_url" : "http://nickcrocker.com/2012/08/build-a-better-you/",
      "display_url" : "nickcrocker.com/2012/08/build-…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "235452571093966849",
  "text" : "Great smart post from @nickcrocker summarizing his @skillshare class on habit and behavior change: http://t.co/pt9CVj1Z",
  "id" : 235452571093966849,
  "created_at" : "Tue Aug 14 19:07:22 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tikva Morowati",
      "screen_name" : "tikkers",
      "indices" : [ 0, 8 ],
      "id_str" : "1054551",
      "id" : 1054551
    }, {
      "name" : "Branch",
      "screen_name" : "branch",
      "indices" : [ 16, 23 ],
      "id_str" : "494518813",
      "id" : 494518813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "235440469235077120",
  "geo" : {
  },
  "id_str" : "235452242986143744",
  "in_reply_to_user_id" : 1054551,
  "text" : "@tikkers I love @branch too.  Let’s start some branches! :)",
  "id" : 235452242986143744,
  "in_reply_to_status_id" : 235440469235077120,
  "created_at" : "Tue Aug 14 19:06:03 +0000 2012",
  "in_reply_to_screen_name" : "tikkers",
  "in_reply_to_user_id_str" : "1054551",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Haughey",
      "screen_name" : "mathowie",
      "indices" : [ 0, 9 ],
      "id_str" : "761975",
      "id" : 761975
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "235448505299259392",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7764080615, -122.4167476489 ]
  },
  "id_str" : "235451607406497792",
  "in_reply_to_user_id" : 761975,
  "text" : "@mathowie Yup. :)",
  "id" : 235451607406497792,
  "in_reply_to_status_id" : 235448505299259392,
  "created_at" : "Tue Aug 14 19:03:32 +0000 2012",
  "in_reply_to_screen_name" : "mathowie",
  "in_reply_to_user_id_str" : "761975",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Darya Pino",
      "screen_name" : "summertomato",
      "indices" : [ 0, 13 ],
      "id_str" : "17396212",
      "id" : 17396212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "235436729170030592",
  "geo" : {
  },
  "id_str" : "235448215657398272",
  "in_reply_to_user_id" : 17396212,
  "text" : "@summertomato What are you suspicious about? I’ve been hearing rumors of this for a while… again, whole foods are okay.",
  "id" : 235448215657398272,
  "in_reply_to_status_id" : 235436729170030592,
  "created_at" : "Tue Aug 14 18:50:03 +0000 2012",
  "in_reply_to_screen_name" : "summertomato",
  "in_reply_to_user_id_str" : "17396212",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Bragger",
      "screen_name" : "kylebragger",
      "indices" : [ 0, 12 ],
      "id_str" : "2039761",
      "id" : 2039761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "235447184827498497",
  "geo" : {
  },
  "id_str" : "235447321444380672",
  "in_reply_to_user_id" : 2039761,
  "text" : "@kylebragger indeed.",
  "id" : 235447321444380672,
  "in_reply_to_status_id" : 235447184827498497,
  "created_at" : "Tue Aug 14 18:46:30 +0000 2012",
  "in_reply_to_screen_name" : "kylebragger",
  "in_reply_to_user_id_str" : "2039761",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Darya Pino",
      "screen_name" : "summertomato",
      "indices" : [ 3, 16 ],
      "id_str" : "17396212",
      "id" : 17396212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "235447173024718848",
  "text" : "RT @summertomato: Looked at the egg study data. Those who ate the most also had lowest BMI, total cholesterol, LDL cholesterol &amp; tri ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "235436729170030592",
    "text" : "Looked at the egg study data. Those who ate the most also had lowest BMI, total cholesterol, LDL cholesterol &amp; triglycerides. Suspicious?",
    "id" : 235436729170030592,
    "created_at" : "Tue Aug 14 18:04:25 +0000 2012",
    "user" : {
      "name" : "Darya Pino",
      "screen_name" : "summertomato",
      "protected" : false,
      "id_str" : "17396212",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2787524861/784ab63d23ee356b110b956f2f4bcef2_normal.jpeg",
      "id" : 17396212,
      "verified" : true
    }
  },
  "id" : 235447173024718848,
  "created_at" : "Tue Aug 14 18:45:55 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagr.am\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 55 ],
      "url" : "http://t.co/vcFzHu41",
      "expanded_url" : "http://instagr.am/p/OUagSSI0EQ/",
      "display_url" : "instagr.am/p/OUagSSI0EQ/"
    } ]
  },
  "geo" : {
  },
  "id_str" : "235446776059011072",
  "text" : "My new employer starting next week http://t.co/vcFzHu41",
  "id" : 235446776059011072,
  "created_at" : "Tue Aug 14 18:44:20 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jad Abumrad",
      "screen_name" : "JadAbumrad",
      "indices" : [ 3, 14 ],
      "id_str" : "135316691",
      "id" : 135316691
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "235442507553595393",
  "text" : "RT @JadAbumrad: A person who buys 50 lottery tickets a week will win the jackpot on avg once every 30,000 years.",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "235438640078139392",
    "text" : "A person who buys 50 lottery tickets a week will win the jackpot on avg once every 30,000 years.",
    "id" : 235438640078139392,
    "created_at" : "Tue Aug 14 18:12:00 +0000 2012",
    "user" : {
      "name" : "Jad Abumrad",
      "screen_name" : "JadAbumrad",
      "protected" : false,
      "id_str" : "135316691",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1529014082/Jad-Pic2_normal.jpg",
      "id" : 135316691,
      "verified" : true
    }
  },
  "id" : 235442507553595393,
  "created_at" : "Tue Aug 14 18:27:22 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TechCrunch",
      "screen_name" : "TechCrunch",
      "indices" : [ 12, 23 ],
      "id_str" : "816653",
      "id" : 816653
    }, {
      "name" : "Greg Ferenstein",
      "screen_name" : "ferenstein",
      "indices" : [ 112, 123 ],
      "id_str" : "14914385",
      "id" : 14914385
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 108 ],
      "url" : "http://t.co/HI0dYhEE",
      "expanded_url" : "http://tcrn.ch/RRiXCB",
      "display_url" : "tcrn.ch/RRiXCB"
    } ]
  },
  "geo" : {
  },
  "id_str" : "235435688806469633",
  "text" : "Awesome. RT @TechCrunch: Khan Academy Launches The Future of Computer Science Education http://t.co/HI0dYhEE by @ferenstein",
  "id" : 235435688806469633,
  "created_at" : "Tue Aug 14 18:00:17 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 118 ],
      "url" : "http://t.co/aLVvgHOF",
      "expanded_url" : "http://seattletimes.nwsource.com/html/health/2018909689_apusmedobesityratesstates.html",
      "display_url" : "seattletimes.nwsource.com/html/health/20…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "235432486300155904",
  "text" : "At least 30% of adults are obese in 12 states: AL, AR, IN, KY, LA, MI, MS, MO, OK, SC, TX and WV. http://t.co/aLVvgHOF",
  "id" : 235432486300155904,
  "created_at" : "Tue Aug 14 17:47:33 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PandoDaily",
      "screen_name" : "PandoDaily",
      "indices" : [ 19, 30 ],
      "id_str" : "419710142",
      "id" : 419710142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 137 ],
      "url" : "http://t.co/JdOk1q7i",
      "expanded_url" : "http://pandodaily.com/2012/08/14/klouts-dramatic-relaunch-can-an-emphasis-on-content-make-people-care-about-scores/",
      "display_url" : "pandodaily.com/2012/08/14/klo…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "235430526595514368",
  "text" : "Great write-up. RT @PandoDaily: Klout’s Dramatic Relaunch: Can an Emphasis on Content Make People Care about Scores? http://t.co/JdOk1q7i",
  "id" : 235430526595514368,
  "created_at" : "Tue Aug 14 17:39:46 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Foursquare",
      "screen_name" : "foursquare",
      "indices" : [ 54, 65 ],
      "id_str" : "14120151",
      "id" : 14120151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 126 ],
      "url" : "http://t.co/GhPzOwbJ",
      "expanded_url" : "http://4sq.com/NBg8zr",
      "display_url" : "4sq.com/NBg8zr"
    } ]
  },
  "geo" : {
  },
  "id_str" : "235421855438213121",
  "text" : "I just reached Level 2 of the \"Greasy Spoon\" badge on @foursquare. I’ve checked in at 5 different diners! http://t.co/GhPzOwbJ",
  "id" : 235421855438213121,
  "created_at" : "Tue Aug 14 17:05:18 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "woohoo",
      "indices" : [ 48, 55 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "235421610688000000",
  "text" : "First 18.4 people to retweet this get a virtual #woohoo.",
  "id" : 235421610688000000,
  "created_at" : "Tue Aug 14 17:04:20 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amit superamit Gupta",
      "screen_name" : "superamit",
      "indices" : [ 0, 10 ],
      "id_str" : "10609",
      "id" : 10609
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "235411121157316608",
  "geo" : {
  },
  "id_str" : "235418462728634370",
  "in_reply_to_user_id" : 10609,
  "text" : "@superamit Yeah it works after a minute. For now…",
  "id" : 235418462728634370,
  "in_reply_to_status_id" : 235411121157316608,
  "created_at" : "Tue Aug 14 16:51:50 +0000 2012",
  "in_reply_to_screen_name" : "superamit",
  "in_reply_to_user_id_str" : "10609",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amit superamit Gupta",
      "screen_name" : "superamit",
      "indices" : [ 0, 10 ],
      "id_str" : "10609",
      "id" : 10609
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "235398322112851969",
  "geo" : {
  },
  "id_str" : "235410505479639040",
  "in_reply_to_user_id" : 10609,
  "text" : "@superamit That happens to me too. But trackpad magically cursor appears after a minute or so.",
  "id" : 235410505479639040,
  "in_reply_to_status_id" : 235398322112851969,
  "created_at" : "Tue Aug 14 16:20:12 +0000 2012",
  "in_reply_to_screen_name" : "superamit",
  "in_reply_to_user_id_str" : "10609",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Xeni Jardin",
      "screen_name" : "xeni",
      "indices" : [ 3, 8 ],
      "id_str" : "767",
      "id" : 767
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "235410233923629056",
  "text" : "RT @xeni: Cancer changes everything. My goal in life now is to be a happy, healthy, very old woman.",
  "retweeted_status" : {
    "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "235397037749829632",
    "text" : "Cancer changes everything. My goal in life now is to be a happy, healthy, very old woman.",
    "id" : 235397037749829632,
    "created_at" : "Tue Aug 14 15:26:41 +0000 2012",
    "user" : {
      "name" : "Xeni Jardin",
      "screen_name" : "xeni",
      "protected" : false,
      "id_str" : "767",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2465926806/2lo81tngfq1maamon0w7_normal.jpeg",
      "id" : 767,
      "verified" : true
    }
  },
  "id" : 235410233923629056,
  "created_at" : "Tue Aug 14 16:19:08 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Murphy",
      "screen_name" : "timothypmurphy",
      "indices" : [ 3, 18 ],
      "id_str" : "17291452",
      "id" : 17291452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "235350489632477185",
  "text" : "RT @timothypmurphy: Paul Ryan backed an anti-abortion bill that would have outlawed IVF—which Mitt Romney's children used. http://t.co/p ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 103, 123 ],
        "url" : "http://t.co/p9JucxtY",
        "expanded_url" : "http://bit.ly/QZLMLz",
        "display_url" : "bit.ly/QZLMLz"
      } ]
    },
    "geo" : {
    },
    "id_str" : "235339073240313856",
    "text" : "Paul Ryan backed an anti-abortion bill that would have outlawed IVF—which Mitt Romney's children used. http://t.co/p9JucxtY",
    "id" : 235339073240313856,
    "created_at" : "Tue Aug 14 11:36:22 +0000 2012",
    "user" : {
      "name" : "Tim Murphy",
      "screen_name" : "timothypmurphy",
      "protected" : false,
      "id_str" : "17291452",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2147832122/Screen_Shot_2012-04-19_at_3.12.51_PM_normal.png",
      "id" : 17291452,
      "verified" : false
    }
  },
  "id" : 235350489632477185,
  "created_at" : "Tue Aug 14 12:21:43 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 121 ],
      "url" : "http://t.co/O0sb5008",
      "expanded_url" : "http://4sq.com/NAjmTP",
      "display_url" : "4sq.com/NAjmTP"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.4436465828, -122.3025941849 ]
  },
  "id_str" : "235343771716435969",
  "text" : "Seattle to SF for the day. Good morning! (@ Seattle-Tacoma International Airport (SEA) w/ 13 others) http://t.co/O0sb5008",
  "id" : 235343771716435969,
  "created_at" : "Tue Aug 14 11:55:02 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Parmy Olson",
      "screen_name" : "parmy",
      "indices" : [ 0, 6 ],
      "id_str" : "19116515",
      "id" : 19116515
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "235325128295202816",
  "geo" : {
  },
  "id_str" : "235340426914168832",
  "in_reply_to_user_id" : 19116515,
  "text" : "@parmy Me too! Please keep writing about it. Who are the current spin-offs that you find most interesting?",
  "id" : 235340426914168832,
  "in_reply_to_status_id" : 235325128295202816,
  "created_at" : "Tue Aug 14 11:41:44 +0000 2012",
  "in_reply_to_screen_name" : "parmy",
  "in_reply_to_user_id_str" : "19116515",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "girl jo",
      "screen_name" : "octavekitten",
      "indices" : [ 0, 13 ],
      "id_str" : "16366882",
      "id" : 16366882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "235246582839250945",
  "geo" : {
  },
  "id_str" : "235251471468343297",
  "in_reply_to_user_id" : 16366882,
  "text" : "@octavekitten Yeah that’s crazy.",
  "id" : 235251471468343297,
  "in_reply_to_status_id" : 235246582839250945,
  "created_at" : "Tue Aug 14 05:48:16 +0000 2012",
  "in_reply_to_screen_name" : "octavekitten",
  "in_reply_to_user_id_str" : "16366882",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Techmeme",
      "screen_name" : "Techmeme",
      "indices" : [ 41, 50 ],
      "id_str" : "817386",
      "id" : 817386
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 122 ],
      "url" : "http://t.co/fWlWe2aD",
      "expanded_url" : "http://techcrunch.com/2012/08/13/putting-an-end-to-the-biggest-lie-on-the-internet/",
      "display_url" : "techcrunch.com/2012/08/13/put…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "235246371307941888",
  "text" : "Disrupting Terms of Service… awesome. RT @Techmeme: Putting An End To The Biggest Lie On The Internet http://t.co/fWlWe2aD",
  "id" : 235246371307941888,
  "created_at" : "Tue Aug 14 05:28:00 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kav Latiolais",
      "screen_name" : "kavla",
      "indices" : [ 0, 6 ],
      "id_str" : "28838912",
      "id" : 28838912
    }, {
      "name" : "Progressive",
      "screen_name" : "Progressive",
      "indices" : [ 104, 116 ],
      "id_str" : "3331681",
      "id" : 3331681
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "235229196065050625",
  "geo" : {
  },
  "id_str" : "235230778810830848",
  "in_reply_to_user_id" : 28838912,
  "text" : "@kavla Agree. A premature flippant half-assed form-letter apology is a lot worse than even silence. /cc @Progressive",
  "id" : 235230778810830848,
  "in_reply_to_status_id" : 235229196065050625,
  "created_at" : "Tue Aug 14 04:26:02 +0000 2012",
  "in_reply_to_screen_name" : "kavla",
  "in_reply_to_user_id_str" : "28838912",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "harryh",
      "screen_name" : "harryh",
      "indices" : [ 0, 7 ],
      "id_str" : "4558",
      "id" : 4558
    }, {
      "name" : "Ryan Freitas",
      "screen_name" : "ryanchris",
      "indices" : [ 8, 18 ],
      "id_str" : "13349",
      "id" : 13349
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "235222280970584064",
  "geo" : {
  },
  "id_str" : "235222842919239681",
  "in_reply_to_user_id" : 4558,
  "text" : "@harryh @ryanchris It does but I truly believe the new mob of social media responds best to truth, facts, and willingness to be open.",
  "id" : 235222842919239681,
  "in_reply_to_status_id" : 235222280970584064,
  "created_at" : "Tue Aug 14 03:54:30 +0000 2012",
  "in_reply_to_screen_name" : "harryh",
  "in_reply_to_user_id_str" : "4558",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "harryh",
      "screen_name" : "harryh",
      "indices" : [ 0, 7 ],
      "id_str" : "4558",
      "id" : 4558
    }, {
      "name" : "Ryan Freitas",
      "screen_name" : "ryanchris",
      "indices" : [ 8, 18 ],
      "id_str" : "13349",
      "id" : 13349
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "235217189316202496",
  "geo" : {
  },
  "id_str" : "235221690437750784",
  "in_reply_to_user_id" : 4558,
  "text" : "@harryh @ryanchris They have an opportunity to share their side of the story. They could still repair this by being authentic right now.",
  "id" : 235221690437750784,
  "in_reply_to_status_id" : 235217189316202496,
  "created_at" : "Tue Aug 14 03:49:55 +0000 2012",
  "in_reply_to_screen_name" : "harryh",
  "in_reply_to_user_id_str" : "4558",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Progressive",
      "screen_name" : "Progressive",
      "indices" : [ 23, 35 ],
      "id_str" : "3331681",
      "id" : 3331681
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 114 ],
      "url" : "http://t.co/WyZyMoIL",
      "expanded_url" : "http://flic.kr/p/cRobBQ",
      "display_url" : "flic.kr/p/cRobBQ"
    } ]
  },
  "geo" : {
  },
  "id_str" : "235218640612491264",
  "text" : "8:36pm Reading through @progressive's social media responses to being a terribly evil company http://t.co/WyZyMoIL",
  "id" : 235218640612491264,
  "created_at" : "Tue Aug 14 03:37:48 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Clay Shirky",
      "screen_name" : "cshirky",
      "indices" : [ 3, 11 ],
      "id_str" : "6141832",
      "id" : 6141832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "235214076849053697",
  "text" : "RT @cshirky: \"If you are insured by Progressive, they will defend your killer in court in order to not pay you your policy.\" http://t.co ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 112, 132 ],
        "url" : "http://t.co/UA4yWoSL",
        "expanded_url" : "http://goo.gl/YQPQH",
        "display_url" : "goo.gl/YQPQH"
      } ]
    },
    "geo" : {
    },
    "id_str" : "235210567583940610",
    "text" : "\"If you are insured by Progressive, they will defend your killer in court in order to not pay you your policy.\" http://t.co/UA4yWoSL",
    "id" : 235210567583940610,
    "created_at" : "Tue Aug 14 03:05:43 +0000 2012",
    "user" : {
      "name" : "Clay Shirky",
      "screen_name" : "cshirky",
      "protected" : false,
      "id_str" : "6141832",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/608299691/hands_normal.jpg",
      "id" : 6141832,
      "verified" : true
    }
  },
  "id" : 235214076849053697,
  "created_at" : "Tue Aug 14 03:19:40 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Seccia",
      "screen_name" : "kevinseccia",
      "indices" : [ 3, 15 ],
      "id_str" : "17243563",
      "id" : 17243563
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "235134865375391745",
  "text" : "RT @kevinseccia: At this point, even Occam's razor has five extra blades and a hydrating gel strip.",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "235108899848601600",
    "text" : "At this point, even Occam's razor has five extra blades and a hydrating gel strip.",
    "id" : 235108899848601600,
    "created_at" : "Mon Aug 13 20:21:44 +0000 2012",
    "user" : {
      "name" : "Kevin Seccia",
      "screen_name" : "kevinseccia",
      "protected" : false,
      "id_str" : "17243563",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/322199758/n673117370_1449452_7610_normal.jpg",
      "id" : 17243563,
      "verified" : false
    }
  },
  "id" : 235134865375391745,
  "created_at" : "Mon Aug 13 22:04:55 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sammy Larbi",
      "screen_name" : "codeodor",
      "indices" : [ 0, 9 ],
      "id_str" : "7853992",
      "id" : 7853992
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "235131202795884544",
  "geo" : {
  },
  "id_str" : "235131691180634112",
  "in_reply_to_user_id" : 7853992,
  "text" : "@codeodor The fear of vapor might be mildly exaggerated then.",
  "id" : 235131691180634112,
  "in_reply_to_status_id" : 235131202795884544,
  "created_at" : "Mon Aug 13 21:52:18 +0000 2012",
  "in_reply_to_screen_name" : "codeodor",
  "in_reply_to_user_id_str" : "7853992",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Jacobs",
      "screen_name" : "djacobs",
      "indices" : [ 0, 8 ],
      "id_str" : "774842",
      "id" : 774842
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "235130021629546496",
  "geo" : {
  },
  "id_str" : "235131049498251265",
  "in_reply_to_user_id" : 774842,
  "text" : "@djacobs There is also simplicity to learning as early as you can.",
  "id" : 235131049498251265,
  "in_reply_to_status_id" : 235130021629546496,
  "created_at" : "Mon Aug 13 21:49:45 +0000 2012",
  "in_reply_to_screen_name" : "djacobs",
  "in_reply_to_user_id_str" : "774842",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sammy Larbi",
      "screen_name" : "codeodor",
      "indices" : [ 0, 9 ],
      "id_str" : "7853992",
      "id" : 7853992
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "235129585115746304",
  "geo" : {
  },
  "id_str" : "235130061265711104",
  "in_reply_to_user_id" : 7853992,
  "text" : "@codeodor That’s the cynical way of viewing it. :)",
  "id" : 235130061265711104,
  "in_reply_to_status_id" : 235129585115746304,
  "created_at" : "Mon Aug 13 21:45:49 +0000 2012",
  "in_reply_to_screen_name" : "codeodor",
  "in_reply_to_user_id_str" : "7853992",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Jacobs",
      "screen_name" : "djacobs",
      "indices" : [ 0, 8 ],
      "id_str" : "774842",
      "id" : 774842
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "235123599831355392",
  "geo" : {
  },
  "id_str" : "235123890676965376",
  "in_reply_to_user_id" : 774842,
  "text" : "@djacobs I think it’s worth exploring since it also validates market earlier and makes early users feel invested in the product’s success.",
  "id" : 235123890676965376,
  "in_reply_to_status_id" : 235123599831355392,
  "created_at" : "Mon Aug 13 21:21:18 +0000 2012",
  "in_reply_to_screen_name" : "djacobs",
  "in_reply_to_user_id_str" : "774842",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 73 ],
      "url" : "http://t.co/ANWL75ex",
      "expanded_url" : "http://join.app.net",
      "display_url" : "join.app.net"
    } ]
  },
  "geo" : {
  },
  "id_str" : "235123301209481216",
  "text" : "I wonder how many entrepreneurs are pivoting towards http://t.co/ANWL75ex’s version of crowd-funding? Pre-orders for subscription services!",
  "id" : 235123301209481216,
  "created_at" : "Mon Aug 13 21:18:58 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Parmy Olson",
      "screen_name" : "parmy",
      "indices" : [ 125, 131 ],
      "id_str" : "19116515",
      "id" : 19116515
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "5stars",
      "indices" : [ 133, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "235115057296588800",
  "text" : "If you’re interested in the Internet, Anonymous, or the evolution of online community, you should read “We Are Anonymous” by @parmy. #5stars",
  "id" : 235115057296588800,
  "created_at" : "Mon Aug 13 20:46:12 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Parmy Olson",
      "screen_name" : "parmy",
      "indices" : [ 0, 6 ],
      "id_str" : "19116515",
      "id" : 19116515
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "235114125074767874",
  "in_reply_to_user_id" : 19116515,
  "text" : "@parmy Just finished \"We Are Anonymous\" and *loved* it. It should be a movie. Are you still following the evolution of Anonymous?",
  "id" : 235114125074767874,
  "created_at" : "Mon Aug 13 20:42:30 +0000 2012",
  "in_reply_to_screen_name" : "parmy",
  "in_reply_to_user_id_str" : "19116515",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rose Broome",
      "screen_name" : "rosical",
      "indices" : [ 0, 8 ],
      "id_str" : "140145169",
      "id" : 140145169
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "235111247824166913",
  "geo" : {
  },
  "id_str" : "235112060457984000",
  "in_reply_to_user_id" : 140145169,
  "text" : "@rosical Great meeting you too!",
  "id" : 235112060457984000,
  "in_reply_to_status_id" : 235111247824166913,
  "created_at" : "Mon Aug 13 20:34:18 +0000 2012",
  "in_reply_to_screen_name" : "rosical",
  "in_reply_to_user_id_str" : "140145169",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 37 ],
      "url" : "http://t.co/AE3mquHi",
      "expanded_url" : "http://App.net",
      "display_url" : "App.net"
    }, {
      "indices" : [ 115, 135 ],
      "url" : "http://t.co/wkH41BqL",
      "expanded_url" : "http://wayoftheduck.com/app-net",
      "display_url" : "wayoftheduck.com/app-net"
    } ]
  },
  "geo" : {
  },
  "id_str" : "235075481655992320",
  "text" : "Will the soul of http://t.co/AE3mquHi remain a shadow of its initial muse or emerge with a personality of its own? http://t.co/wkH41BqL",
  "id" : 235075481655992320,
  "created_at" : "Mon Aug 13 18:08:56 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.apple.com\" rel=\"nofollow\">Safari on iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Pressfield",
      "screen_name" : "SPressfield",
      "indices" : [ 36, 48 ],
      "id_str" : "29272446",
      "id" : 29272446
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 70 ],
      "url" : "http://t.co/gALmgVDY",
      "expanded_url" : "http://www.stevenpressfield.com/2009/10/writing-wednesdays-2-the-most-important-writing-lession-i-ever-learned/",
      "display_url" : "stevenpressfield.com/2009/10/writin…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "235038007332315136",
  "text" : "\"Nobody wants to read your shit.\" - @spressfield  http://t.co/gALmgVDY",
  "id" : 235038007332315136,
  "created_at" : "Mon Aug 13 15:40:02 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Bittman",
      "screen_name" : "bittman",
      "indices" : [ 3, 11 ],
      "id_str" : "20778387",
      "id" : 20778387
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 86 ],
      "url" : "http://t.co/Hp5I2FbN",
      "expanded_url" : "http://nyti.ms/PQCRau",
      "display_url" : "nyti.ms/PQCRau"
    } ]
  },
  "geo" : {
  },
  "id_str" : "235009544797954050",
  "text" : "RT @bittman: Change the rules, kids gain less weight. No-brainer: http://t.co/Hp5I2FbN",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 53, 73 ],
        "url" : "http://t.co/Hp5I2FbN",
        "expanded_url" : "http://nyti.ms/PQCRau",
        "display_url" : "nyti.ms/PQCRau"
      } ]
    },
    "geo" : {
    },
    "id_str" : "234984107124334592",
    "text" : "Change the rules, kids gain less weight. No-brainer: http://t.co/Hp5I2FbN",
    "id" : 234984107124334592,
    "created_at" : "Mon Aug 13 12:05:51 +0000 2012",
    "user" : {
      "name" : "Mark Bittman",
      "screen_name" : "bittman",
      "protected" : false,
      "id_str" : "20778387",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1293112347/Mark_Bittman_new_blk_75_normal.jpg",
      "id" : 20778387,
      "verified" : true
    }
  },
  "id" : 235009544797954050,
  "created_at" : "Mon Aug 13 13:46:56 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Ferriss",
      "screen_name" : "tferriss",
      "indices" : [ 3, 12 ],
      "id_str" : "11740902",
      "id" : 11740902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 86 ],
      "url" : "http://t.co/GUjmWJDv",
      "expanded_url" : "http://bit.ly/NwI2wE",
      "display_url" : "bit.ly/NwI2wE"
    } ]
  },
  "geo" : {
  },
  "id_str" : "235008710592827392",
  "text" : "RT @tferriss: NEW - Understanding the Dangers of “Ego-Depletion”: http://t.co/GUjmWJDv",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 52, 72 ],
        "url" : "http://t.co/GUjmWJDv",
        "expanded_url" : "http://bit.ly/NwI2wE",
        "display_url" : "bit.ly/NwI2wE"
      } ]
    },
    "geo" : {
    },
    "id_str" : "234966950483197952",
    "text" : "NEW - Understanding the Dangers of “Ego-Depletion”: http://t.co/GUjmWJDv",
    "id" : 234966950483197952,
    "created_at" : "Mon Aug 13 10:57:41 +0000 2012",
    "user" : {
      "name" : "Tim Ferriss",
      "screen_name" : "tferriss",
      "protected" : false,
      "id_str" : "11740902",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/49918572/half-face-ice_normal.jpg",
      "id" : 11740902,
      "verified" : true
    }
  },
  "id" : 235008710592827392,
  "created_at" : "Mon Aug 13 13:43:37 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Terence Eden",
      "screen_name" : "edent",
      "indices" : [ 3, 9 ],
      "id_str" : "14054507",
      "id" : 14054507
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "235004775240986624",
  "text" : "RT @edent: Liven things up by substituting \"Cloud\" with \"Clown\".\n\n\"Our infrastructure runs on the clown\"\n\"I'm a clown expert\"\n\"This is c ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://shkspr.mobi/blog/index.php/copyright-terence-eden/\" rel=\"nofollow\">©Terence Eden SomeRightsReserved</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "234937974154989568",
    "text" : "Liven things up by substituting \"Cloud\" with \"Clown\".\n\n\"Our infrastructure runs on the clown\"\n\"I'm a clown expert\"\n\"This is clown based\"",
    "id" : 234937974154989568,
    "created_at" : "Mon Aug 13 09:02:32 +0000 2012",
    "user" : {
      "name" : "Terence Eden",
      "screen_name" : "edent",
      "protected" : false,
      "id_str" : "14054507",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2471236262/Clean_Shaven_square_normal.jpg",
      "id" : 14054507,
      "verified" : false
    }
  },
  "id" : 235004775240986624,
  "created_at" : "Mon Aug 13 13:27:59 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benjamin Collins",
      "screen_name" : "bbwcollins",
      "indices" : [ 0, 11 ],
      "id_str" : "646413",
      "id" : 646413
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "234930926478557184",
  "geo" : {
  },
  "id_str" : "235004449117048832",
  "in_reply_to_user_id" : 646413,
  "text" : "@bbwcollins Thank you.",
  "id" : 235004449117048832,
  "in_reply_to_status_id" : 234930926478557184,
  "created_at" : "Mon Aug 13 13:26:41 +0000 2012",
  "in_reply_to_screen_name" : "bbwcollins",
  "in_reply_to_user_id_str" : "646413",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 111 ],
      "url" : "http://t.co/ga8NIOqc",
      "expanded_url" : "http://flic.kr/p/cQGTn5",
      "display_url" : "flic.kr/p/cQGTn5"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.608666, -122.306167 ]
  },
  "id_str" : "234856720474710016",
  "text" : "8:36pm Sopor got into a fight with the neighbor cat and made Niko sad. Talking it out now. http://t.co/ga8NIOqc",
  "id" : 234856720474710016,
  "created_at" : "Mon Aug 13 03:39:40 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Buzz Andersen",
      "screen_name" : "buzz",
      "indices" : [ 0, 5 ],
      "id_str" : "528",
      "id" : 528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "234851787927064576",
  "geo" : {
  },
  "id_str" : "234852620097953793",
  "in_reply_to_user_id" : 528,
  "text" : "@buzz Yeah, I’d love to see a breakdown of where the backers came from. Fascinating to watch it all unfold.",
  "id" : 234852620097953793,
  "in_reply_to_status_id" : 234851787927064576,
  "created_at" : "Mon Aug 13 03:23:22 +0000 2012",
  "in_reply_to_screen_name" : "buzz",
  "in_reply_to_user_id_str" : "528",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Buzz Andersen",
      "screen_name" : "buzz",
      "indices" : [ 0, 5 ],
      "id_str" : "528",
      "id" : 528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "234849442648432640",
  "geo" : {
  },
  "id_str" : "234851429997752320",
  "in_reply_to_user_id" : 528,
  "text" : "@buzz I think that’s fine for now. Let it evolve into its own thing, right? Which, I’m guessing, will be very different from Twitter.",
  "id" : 234851429997752320,
  "in_reply_to_status_id" : 234849442648432640,
  "created_at" : "Mon Aug 13 03:18:38 +0000 2012",
  "in_reply_to_screen_name" : "buzz",
  "in_reply_to_user_id_str" : "528",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gretchen Rubin",
      "screen_name" : "gretchenrubin",
      "indices" : [ 3, 17 ],
      "id_str" : "14289835",
      "id" : 14289835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "234734926119968768",
  "text" : "RT @gretchenrubin: Always wondered why there's not more discussion of \"nocebo\" (opposite of placebo) so interested to read this: http:// ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 110, 130 ],
        "url" : "http://t.co/U1FBjrnR",
        "expanded_url" : "http://www.nytimes.com/2012/08/12/opinion/sunday/beware-the-nocebo-effect.html",
        "display_url" : "nytimes.com/2012/08/12/opi…"
      } ]
    },
    "geo" : {
    },
    "id_str" : "234730178138497025",
    "text" : "Always wondered why there's not more discussion of \"nocebo\" (opposite of placebo) so interested to read this: http://t.co/U1FBjrnR",
    "id" : 234730178138497025,
    "created_at" : "Sun Aug 12 19:16:50 +0000 2012",
    "user" : {
      "name" : "Gretchen Rubin",
      "screen_name" : "gretchenrubin",
      "protected" : false,
      "id_str" : "14289835",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1436632135/Gretchenonphone_normal.JPG",
      "id" : 14289835,
      "verified" : true
    }
  },
  "id" : 234734926119968768,
  "created_at" : "Sun Aug 12 19:35:42 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Ryan Gosling",
      "screen_name" : "PaulRyanGosling",
      "indices" : [ 3, 19 ],
      "id_str" : "751187245",
      "id" : 751187245
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "234728380002598913",
  "text" : "RT @PaulRyanGosling: Hey girl, I don't believe in global warming. But I do believe in snuggles.",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "234708861565677569",
    "text" : "Hey girl, I don't believe in global warming. But I do believe in snuggles.",
    "id" : 234708861565677569,
    "created_at" : "Sun Aug 12 17:52:07 +0000 2012",
    "user" : {
      "name" : "Paul Ryan Gosling",
      "screen_name" : "PaulRyanGosling",
      "protected" : false,
      "id_str" : "751187245",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2733207454/263275f8be21f8c210f108670292cfe9_normal.jpeg",
      "id" : 751187245,
      "verified" : false
    }
  },
  "id" : 234728380002598913,
  "created_at" : "Sun Aug 12 19:09:41 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dalton Caldwell",
      "screen_name" : "daltonc",
      "indices" : [ 15, 23 ],
      "id_str" : "9151842",
      "id" : 9151842
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 50 ],
      "url" : "http://t.co/DfmBA7dI",
      "expanded_url" : "http://bit.ly/NJCbEB",
      "display_url" : "bit.ly/NJCbEB"
    } ]
  },
  "geo" : {
  },
  "id_str" : "234709660366684160",
  "text" : "Impressed with @daltonc &amp; http://t.co/DfmBA7dI getting funded. Excited to watch it evolve &amp; think it’ll end up different than Twitter.",
  "id" : 234709660366684160,
  "created_at" : "Sun Aug 12 17:55:18 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagr.am\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 77 ],
      "url" : "http://t.co/D9Im8X2w",
      "expanded_url" : "http://instagr.am/p/OPE6Qmo0Dn/",
      "display_url" : "instagr.am/p/OPE6Qmo0Dn/"
    } ]
  },
  "geo" : {
  },
  "id_str" : "234695387041103873",
  "text" : "Very stoked about his fort stocked with books and trains http://t.co/D9Im8X2w",
  "id" : 234695387041103873,
  "created_at" : "Sun Aug 12 16:58:35 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/busterbenson/status/234502692842647552/photo/1",
      "indices" : [ 39, 59 ],
      "url" : "http://t.co/OZONcjdA",
      "media_url" : "http://pbs.twimg.com/media/A0Ee9OoCMAIh9ow.jpg",
      "id_str" : "234502692846841858",
      "id" : 234502692846841858,
      "media_url_https" : "https://pbs.twimg.com/media/A0Ee9OoCMAIh9ow.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com/OZONcjdA"
    } ],
    "hashtags" : [ {
      "text" : "hotrobot",
      "indices" : [ 14, 23 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "234502692842647552",
  "text" : "Time for some #hotrobot. Come on over! http://t.co/OZONcjdA",
  "id" : 234502692842647552,
  "created_at" : "Sun Aug 12 04:12:54 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagr.am\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 55 ],
      "url" : "http://t.co/eblo1reX",
      "expanded_url" : "http://instagr.am/p/ONqEqlI0HG/",
      "display_url" : "instagr.am/p/ONqEqlI0HG/"
    } ]
  },
  "geo" : {
  },
  "id_str" : "234495578283839488",
  "text" : "8:36pm Power walker down the hill  http://t.co/eblo1reX",
  "id" : 234495578283839488,
  "created_at" : "Sun Aug 12 03:44:37 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "234443208250253313",
  "text" : "I think this year's election will be an easy win. I just hope an amazing Democratic candidate is getting ready in the batter's box for 2016.",
  "id" : 234443208250253313,
  "created_at" : "Sun Aug 12 00:16:31 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "234364372040966144",
  "text" : "Memento mori. Memento vivere.",
  "id" : 234364372040966144,
  "created_at" : "Sat Aug 11 19:03:15 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 42 ],
      "url" : "http://t.co/pp5tZlDz",
      "expanded_url" : "http://flic.kr/p/cPqUKJ",
      "display_url" : "flic.kr/p/cPqUKJ"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.666999, -122.322334 ]
  },
  "id_str" : "234131556623597570",
  "text" : "8:36pm The giddy hour http://t.co/pp5tZlDz",
  "id" : 234131556623597570,
  "created_at" : "Sat Aug 11 03:38:07 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tumblr.com/\" rel=\"nofollow\">Tumblr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 93 ],
      "url" : "http://t.co/2w0g6Bzn",
      "expanded_url" : "http://tmblr.co/ZQJvayR9id3u",
      "display_url" : "tmblr.co/ZQJvayR9id3u"
    } ]
  },
  "geo" : {
  },
  "id_str" : "234064150085660672",
  "text" : "The quick brown fox jumps over the lazy dog. The prophesy has come true! http://t.co/2w0g6Bzn",
  "id" : 234064150085660672,
  "created_at" : "Fri Aug 10 23:10:16 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.apple.com\" rel=\"nofollow\">Safari on iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gina Trapani",
      "screen_name" : "ginatrapani",
      "indices" : [ 4, 16 ],
      "id_str" : "930061",
      "id" : 930061
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 43 ],
      "url" : "http://t.co/bYuKzoSl",
      "expanded_url" : "http://m.lifehacker.com/5932887/im-gina-trapani-and-this-is-how-i-work",
      "display_url" : "m.lifehacker.com/5932887/im-gin…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "233951648232378369",
  "text" : "How @ginatrapani works http://t.co/bYuKzoSl",
  "id" : 233951648232378369,
  "created_at" : "Fri Aug 10 15:43:14 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Bittman",
      "screen_name" : "bittman",
      "indices" : [ 3, 11 ],
      "id_str" : "20778387",
      "id" : 20778387
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 60 ],
      "url" : "http://t.co/lolg7C3b",
      "expanded_url" : "http://nyti.ms/OOD1Av",
      "display_url" : "nyti.ms/OOD1Av"
    } ]
  },
  "geo" : {
  },
  "id_str" : "233935183072604162",
  "text" : "RT @bittman: Guns, Butter and Then Some http://t.co/lolg7C3b",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.nytimes.com/twitter\" rel=\"nofollow\">The New York Times</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 27, 47 ],
        "url" : "http://t.co/lolg7C3b",
        "expanded_url" : "http://nyti.ms/OOD1Av",
        "display_url" : "nyti.ms/OOD1Av"
      } ]
    },
    "geo" : {
    },
    "id_str" : "233729829147648001",
    "text" : "Guns, Butter and Then Some http://t.co/lolg7C3b",
    "id" : 233729829147648001,
    "created_at" : "Fri Aug 10 01:01:48 +0000 2012",
    "user" : {
      "name" : "Mark Bittman",
      "screen_name" : "bittman",
      "protected" : false,
      "id_str" : "20778387",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1293112347/Mark_Bittman_new_blk_75_normal.jpg",
      "id" : 20778387,
      "verified" : true
    }
  },
  "id" : 233935183072604162,
  "created_at" : "Fri Aug 10 14:37:48 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jimmy James Hall",
      "screen_name" : "JimmyJameson",
      "indices" : [ 20, 33 ],
      "id_str" : "35141809",
      "id" : 35141809
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 54 ],
      "url" : "http://t.co/xJ1sUq0G",
      "expanded_url" : "http://flic.kr/p/cNViFm",
      "display_url" : "flic.kr/p/cNViFm"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.608166, -122.327334 ]
  },
  "id_str" : "233785064490668036",
  "text" : "8:36pm Talking with @jimmyjameson http://t.co/xJ1sUq0G",
  "id" : 233785064490668036,
  "created_at" : "Fri Aug 10 04:41:17 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Bragger",
      "screen_name" : "kylebragger",
      "indices" : [ 0, 12 ],
      "id_str" : "2039761",
      "id" : 2039761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "233751244068499456",
  "geo" : {
  },
  "id_str" : "233751507869253632",
  "in_reply_to_user_id" : 2039761,
  "text" : "@kylebragger I would to! I actually pitched a 3% stake in my future earnings 10 years ago.",
  "id" : 233751507869253632,
  "in_reply_to_status_id" : 233751244068499456,
  "created_at" : "Fri Aug 10 02:27:57 +0000 2012",
  "in_reply_to_screen_name" : "kylebragger",
  "in_reply_to_user_id_str" : "2039761",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ross Dawson",
      "screen_name" : "rossdawson",
      "indices" : [ 8, 19 ],
      "id_str" : "15184929",
      "id" : 15184929
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 137 ],
      "url" : "http://t.co/lTSCydrm",
      "expanded_url" : "http://bit.ly/NmHkDD",
      "display_url" : "bit.ly/NmHkDD"
    } ]
  },
  "geo" : {
  },
  "id_str" : "233750593234169856",
  "text" : "Wow. RT @rossdawson: The rise of personal equity: you can now raise money in return for part of your future earnings http://t.co/lTSCydrm",
  "id" : 233750593234169856,
  "created_at" : "Fri Aug 10 02:24:18 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/instagram/id389801252?mt=8&uo=4\" rel=\"nofollow\">Instagram on iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 43 ],
      "url" : "http://t.co/bAgNll4W",
      "expanded_url" : "http://instagr.am/p/OITo-3OFYT/",
      "display_url" : "instagr.am/p/OITo-3OFYT/"
    } ]
  },
  "geo" : {
  },
  "id_str" : "233744031509794816",
  "text" : "Niko, budding activist http://t.co/bAgNll4W",
  "id" : 233744031509794816,
  "created_at" : "Fri Aug 10 01:58:14 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Max Ogles",
      "screen_name" : "maxogles",
      "indices" : [ 0, 9 ],
      "id_str" : "143074585",
      "id" : 143074585
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "233679407619911680",
  "geo" : {
  },
  "id_str" : "233684098617602049",
  "in_reply_to_user_id" : 143074585,
  "text" : "@maxogles Have you already heard of willpower fatigue? See also Alfie Kohn’s take on grit. An Sam Harris’s book Free Will.",
  "id" : 233684098617602049,
  "in_reply_to_status_id" : 233679407619911680,
  "created_at" : "Thu Aug 09 22:00:05 +0000 2012",
  "in_reply_to_screen_name" : "maxogles",
  "in_reply_to_user_id_str" : "143074585",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ʎǝʞɔıɥ ʇʇɐɯ",
      "screen_name" : "matthickey",
      "indices" : [ 0, 11 ],
      "id_str" : "8710082",
      "id" : 8710082
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "233683166819401728",
  "geo" : {
  },
  "id_str" : "233683831901786112",
  "in_reply_to_user_id" : 8710082,
  "text" : "@matthickey Twitter bug!",
  "id" : 233683831901786112,
  "in_reply_to_status_id" : 233683166819401728,
  "created_at" : "Thu Aug 09 21:59:01 +0000 2012",
  "in_reply_to_screen_name" : "matthickey",
  "in_reply_to_user_id_str" : "8710082",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 49 ],
      "url" : "http://t.co/aJpKFA6k",
      "expanded_url" : "http://bit.ly/M92VRg",
      "display_url" : "bit.ly/M92VRg"
    } ]
  },
  "geo" : {
  },
  "id_str" : "233676507539722240",
  "text" : "What should I write about on http://t.co/aJpKFA6k today?",
  "id" : 233676507539722240,
  "created_at" : "Thu Aug 09 21:29:55 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kottke.org",
      "screen_name" : "kottke",
      "indices" : [ 3, 10 ],
      "id_str" : "14120215",
      "id" : 14120215
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 103 ],
      "url" : "http://t.co/HalS6qhW",
      "expanded_url" : "http://kottke.org/12/08/why-does-mars-curiosity-have-such-a-small-camera",
      "display_url" : "kottke.org/12/08/why-does…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "233675821099917313",
  "text" : "RT @kottke: Mars Curiosity is only outfitted with 2-megapixel cameras. Here's why: http://t.co/HalS6qhW",
  "retweeted_status" : {
    "source" : "<a href=\"http://kottke.org\" rel=\"nofollow\">kottke tweeter</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 71, 91 ],
        "url" : "http://t.co/HalS6qhW",
        "expanded_url" : "http://kottke.org/12/08/why-does-mars-curiosity-have-such-a-small-camera",
        "display_url" : "kottke.org/12/08/why-does…"
      } ]
    },
    "geo" : {
    },
    "id_str" : "233675528148770818",
    "text" : "Mars Curiosity is only outfitted with 2-megapixel cameras. Here's why: http://t.co/HalS6qhW",
    "id" : 233675528148770818,
    "created_at" : "Thu Aug 09 21:26:02 +0000 2012",
    "user" : {
      "name" : "kottke.org",
      "screen_name" : "kottke",
      "protected" : false,
      "id_str" : "14120215",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/421227828/apple-touch-icon_normal.png",
      "id" : 14120215,
      "verified" : false
    }
  },
  "id" : 233675821099917313,
  "created_at" : "Thu Aug 09 21:27:11 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "233643790068498434",
  "text" : "Really happy that everyone suggested that I look up, outside, at mountains, and at bees, instead of at more computators. Thanks!",
  "id" : 233643790068498434,
  "created_at" : "Thu Aug 09 19:19:55 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charlotte Maberly",
      "screen_name" : "CMaberly",
      "indices" : [ 0, 9 ],
      "id_str" : "128375612",
      "id" : 128375612
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "233628391528620032",
  "geo" : {
  },
  "id_str" : "233643369920856064",
  "in_reply_to_user_id" : 128375612,
  "text" : "@CMaberly That looks simply refreshing! Have one or four for me please?",
  "id" : 233643369920856064,
  "in_reply_to_status_id" : 233628391528620032,
  "created_at" : "Thu Aug 09 19:18:14 +0000 2012",
  "in_reply_to_screen_name" : "CMaberly",
  "in_reply_to_user_id_str" : "128375612",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "maggim",
      "screen_name" : "maggim",
      "indices" : [ 0, 7 ],
      "id_str" : "14290242",
      "id" : 14290242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "233623289623347201",
  "geo" : {
  },
  "id_str" : "233623569102434306",
  "in_reply_to_user_id" : 14290242,
  "text" : "@maggim Haha, nah, just tweeting silly things.",
  "id" : 233623569102434306,
  "in_reply_to_status_id" : 233623289623347201,
  "created_at" : "Thu Aug 09 17:59:34 +0000 2012",
  "in_reply_to_screen_name" : "maggim",
  "in_reply_to_user_id_str" : "14290242",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ingrid Lindstrom",
      "screen_name" : "ialindstrom",
      "indices" : [ 0, 12 ],
      "id_str" : "84408365",
      "id" : 84408365
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "quack",
      "indices" : [ 21, 27 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "233622595818377216",
  "geo" : {
  },
  "id_str" : "233622885711888384",
  "in_reply_to_user_id" : 84408365,
  "text" : "@ialindstrom Thanks! #quack",
  "id" : 233622885711888384,
  "in_reply_to_status_id" : 233622595818377216,
  "created_at" : "Thu Aug 09 17:56:51 +0000 2012",
  "in_reply_to_screen_name" : "ialindstrom",
  "in_reply_to_user_id_str" : "84408365",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Colin Henry",
      "screen_name" : "jchenry",
      "indices" : [ 0, 8 ],
      "id_str" : "113988145",
      "id" : 113988145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "233620244478951424",
  "geo" : {
  },
  "id_str" : "233622811569188866",
  "in_reply_to_user_id" : 113988145,
  "text" : "@jchenry Ha. So what are you fighting?",
  "id" : 233622811569188866,
  "in_reply_to_status_id" : 233620244478951424,
  "created_at" : "Thu Aug 09 17:56:33 +0000 2012",
  "in_reply_to_screen_name" : "jchenry",
  "in_reply_to_user_id_str" : "113988145",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "233622177272975363",
  "text" : "What should I look at today?",
  "id" : 233622177272975363,
  "created_at" : "Thu Aug 09 17:54:02 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Chou",
      "screen_name" : "garychou",
      "indices" : [ 0, 9 ],
      "id_str" : "29058287",
      "id" : 29058287
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "233620199868338177",
  "geo" : {
  },
  "id_str" : "233620784550117376",
  "in_reply_to_user_id" : 29058287,
  "text" : "@garychou Yup! It’s a new day.",
  "id" : 233620784550117376,
  "in_reply_to_status_id" : 233620199868338177,
  "created_at" : "Thu Aug 09 17:48:30 +0000 2012",
  "in_reply_to_screen_name" : "garychou",
  "in_reply_to_user_id_str" : "29058287",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "233619700863610880",
  "text" : "Hey everybody! How’s it going?",
  "id" : 233619700863610880,
  "created_at" : "Thu Aug 09 17:44:11 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Foursquare",
      "screen_name" : "foursquare",
      "indices" : [ 3, 14 ],
      "id_str" : "14120151",
      "id" : 14120151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 107 ],
      "url" : "http://t.co/MRpZCASc",
      "expanded_url" : "http://bit.ly/QJ73sY",
      "display_url" : "bit.ly/QJ73sY"
    } ]
  },
  "geo" : {
  },
  "id_str" : "233590564598185984",
  "text" : "RT @foursquare: You guys! The nearby friends view is back – download the update today! http://t.co/MRpZCASc",
  "retweeted_status" : {
    "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 71, 91 ],
        "url" : "http://t.co/MRpZCASc",
        "expanded_url" : "http://bit.ly/QJ73sY",
        "display_url" : "bit.ly/QJ73sY"
      } ]
    },
    "geo" : {
    },
    "id_str" : "233582332710367232",
    "text" : "You guys! The nearby friends view is back – download the update today! http://t.co/MRpZCASc",
    "id" : 233582332710367232,
    "created_at" : "Thu Aug 09 15:15:42 +0000 2012",
    "user" : {
      "name" : "Foursquare",
      "screen_name" : "foursquare",
      "protected" : false,
      "id_str" : "14120151",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1683433603/foursquare-twitter_normal.png",
      "id" : 14120151,
      "verified" : true
    }
  },
  "id" : 233590564598185984,
  "created_at" : "Thu Aug 09 15:48:25 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Samuel Fine",
      "screen_name" : "samuelfine",
      "indices" : [ 0, 11 ],
      "id_str" : "200236063",
      "id" : 200236063
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "233574308893573121",
  "geo" : {
  },
  "id_str" : "233574506533376000",
  "in_reply_to_user_id" : 200236063,
  "text" : "@samuelfine I’ve been using that too. Works great but tracking over time is a little clunky.",
  "id" : 233574506533376000,
  "in_reply_to_status_id" : 233574308893573121,
  "created_at" : "Thu Aug 09 14:44:36 +0000 2012",
  "in_reply_to_screen_name" : "samuelfine",
  "in_reply_to_user_id_str" : "200236063",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Crocker",
      "screen_name" : "nickcrocker",
      "indices" : [ 31, 43 ],
      "id_str" : "30801469",
      "id" : 30801469
    }, {
      "name" : "Cardiio",
      "screen_name" : "cardiio",
      "indices" : [ 56, 64 ],
      "id_str" : "324201651",
      "id" : 324201651
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http://t.co/HLsXKnBV",
      "expanded_url" : "http://bit.ly/P7BObn",
      "display_url" : "bit.ly/P7BObn"
    } ]
  },
  "geo" : {
  },
  "id_str" : "233573505923440640",
  "text" : "Looks great! Trying it now. RT @nickcrocker: My friends @cardiio just launched their app which measures your heart rate http://t.co/HLsXKnBV",
  "id" : 233573505923440640,
  "created_at" : "Thu Aug 09 14:40:38 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagr.am\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 108 ],
      "url" : "http://t.co/acEa8Zho",
      "expanded_url" : "http://instagr.am/p/OF64vAI0Gs/",
      "display_url" : "instagr.am/p/OF64vAI0Gs/"
    } ]
  },
  "geo" : {
  },
  "id_str" : "233407054310690818",
  "text" : "8:36pm Recovery after record breaking tantrum with Legos and Star Wars forts and trains http://t.co/acEa8Zho",
  "id" : 233407054310690818,
  "created_at" : "Thu Aug 09 03:39:12 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tumblr.com/\" rel=\"nofollow\">Tumblr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 66 ],
      "url" : "http://t.co/WhSitPsu",
      "expanded_url" : "http://tmblr.co/ZQJvayR0A-V9",
      "display_url" : "tmblr.co/ZQJvayR0A-V9"
    } ]
  },
  "geo" : {
  },
  "id_str" : "233271875843788800",
  "text" : "The secret to finding eternal happiness is... http://t.co/WhSitPsu",
  "id" : 233271875843788800,
  "created_at" : "Wed Aug 08 18:42:03 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "D. Keith Robinson",
      "screen_name" : "dkr",
      "indices" : [ 3, 7 ],
      "id_str" : "10877",
      "id" : 10877
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 135 ],
      "url" : "http://t.co/8N6SyxWt",
      "expanded_url" : "http://howtomakelightning.com/how-square-designed-success",
      "display_url" : "howtomakelightning.com/how-square-des…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "233246242036146176",
  "text" : "RT @dkr: Square + Starbucks is a great example how leading by design, and having a solid, iterative process works: http://t.co/8N6SyxWt",
  "retweeted_status" : {
    "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 106, 126 ],
        "url" : "http://t.co/8N6SyxWt",
        "expanded_url" : "http://howtomakelightning.com/how-square-designed-success",
        "display_url" : "howtomakelightning.com/how-square-des…"
      } ]
    },
    "geo" : {
    },
    "id_str" : "233243455768371200",
    "text" : "Square + Starbucks is a great example how leading by design, and having a solid, iterative process works: http://t.co/8N6SyxWt",
    "id" : 233243455768371200,
    "created_at" : "Wed Aug 08 16:49:07 +0000 2012",
    "user" : {
      "name" : "D. Keith Robinson",
      "screen_name" : "dkr",
      "protected" : false,
      "id_str" : "10877",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1668604373/b17900e21c7011e1abb01231381b65e3_7_normal.jpeg",
      "id" : 10877,
      "verified" : false
    }
  },
  "id" : 233246242036146176,
  "created_at" : "Wed Aug 08 17:00:12 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "233228056922312704",
  "text" : "Quack quack.",
  "id" : 233228056922312704,
  "created_at" : "Wed Aug 08 15:47:56 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 58 ],
      "url" : "http://t.co/tShN8Dlh",
      "expanded_url" : "http://flic.kr/p/cMJGZd",
      "display_url" : "flic.kr/p/cMJGZd"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6115, -122.334167 ]
  },
  "id_str" : "233045368416374784",
  "text" : "8:36pm Buying tickets to Total Recall http://t.co/tShN8Dlh",
  "id" : 233045368416374784,
  "created_at" : "Wed Aug 08 03:42:00 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Probably Mat Honan",
      "screen_name" : "mat",
      "indices" : [ 0, 4 ],
      "id_str" : "11113",
      "id" : 11113
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "233041084752728064",
  "geo" : {
  },
  "id_str" : "233042070594543616",
  "in_reply_to_user_id" : 11113,
  "text" : "@mat I haven’t. I’ll check it out. Aren’t Twitter handles easy to return to their owners? Seems like a short term game.",
  "id" : 233042070594543616,
  "in_reply_to_status_id" : 233041084752728064,
  "created_at" : "Wed Aug 08 03:28:54 +0000 2012",
  "in_reply_to_screen_name" : "mat",
  "in_reply_to_user_id_str" : "11113",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Baio",
      "screen_name" : "waxpancake",
      "indices" : [ 0, 11 ],
      "id_str" : "13461",
      "id" : 13461
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "233040856523870208",
  "geo" : {
  },
  "id_str" : "233041505344962561",
  "in_reply_to_user_id" : 13461,
  "text" : "@waxpancake You’re right. I just don’t think it’s a solvable problem. But improvements can and should be made.",
  "id" : 233041505344962561,
  "in_reply_to_status_id" : 233040856523870208,
  "created_at" : "Wed Aug 08 03:26:39 +0000 2012",
  "in_reply_to_screen_name" : "waxpancake",
  "in_reply_to_user_id_str" : "13461",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Baio",
      "screen_name" : "waxpancake",
      "indices" : [ 0, 11 ],
      "id_str" : "13461",
      "id" : 13461
    }, {
      "name" : "Probably Mat Honan",
      "screen_name" : "mat",
      "indices" : [ 26, 30 ],
      "id_str" : "11113",
      "id" : 11113
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "233039772099153920",
  "geo" : {
  },
  "id_str" : "233040245858394112",
  "in_reply_to_user_id" : 13461,
  "text" : "@waxpancake I don’t blame @mat. Even in a perfect world true security is futile. Also, I don’t believe his attacker’s supposed motives.",
  "id" : 233040245858394112,
  "in_reply_to_status_id" : 233039772099153920,
  "created_at" : "Wed Aug 08 03:21:38 +0000 2012",
  "in_reply_to_screen_name" : "waxpancake",
  "in_reply_to_user_id_str" : "13461",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "233039375334793216",
  "text" : "Truly secure authentication is futile. Maybe a better strategy is to have few dangerous secrets and enemies.",
  "id" : 233039375334793216,
  "created_at" : "Wed Aug 08 03:18:11 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.apple.com\" rel=\"nofollow\">Safari on iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Harris",
      "screen_name" : "SamHarrisOrg",
      "indices" : [ 48, 61 ],
      "id_str" : "116994659",
      "id" : 116994659
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 82 ],
      "url" : "http://t.co/RcHexiSq",
      "expanded_url" : "http://www.samharris.org/lying/",
      "display_url" : "samharris.org/lying/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.614179, -122.318886 ]
  },
  "id_str" : "233012054808752128",
  "text" : "Highly recommend this short e-book on lying, by @samharrisorg http://t.co/RcHexiSq",
  "id" : 233012054808752128,
  "created_at" : "Wed Aug 08 01:29:37 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"https://kindle.amazon.com\" rel=\"nofollow\">Kindle</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Kindle",
      "indices" : [ 95, 102 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 94 ],
      "url" : "http://t.co/kj9cPlZT",
      "expanded_url" : "http://amzn.com/k/VV0p32YgQOKrB_eIlVsMWQ",
      "display_url" : "amzn.com/k/VV0p32YgQOKr…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "233010613276794881",
  "text" : "\"How would your relationships change if you resolved never to lie again?\" http://t.co/kj9cPlZT #Kindle",
  "id" : 233010613276794881,
  "created_at" : "Wed Aug 08 01:23:53 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"https://kindle.amazon.com\" rel=\"nofollow\">Kindle</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Kindle",
      "indices" : [ 99, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 98 ],
      "url" : "http://t.co/0hk2jmGr",
      "expanded_url" : "http://amzn.com/k/UYWlciLVRkiwq7J88RBp0Q",
      "display_url" : "amzn.com/k/UYWlciLVRkiw…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "233009139176071168",
  "text" : "\"Vulnerability comes in pretending to be someone you are not.\" True or false? http://t.co/0hk2jmGr #Kindle",
  "id" : 233009139176071168,
  "created_at" : "Wed Aug 08 01:18:02 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Anderegg",
      "screen_name" : "NickAnderegg",
      "indices" : [ 0, 13 ],
      "id_str" : "95100239",
      "id" : 95100239
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "233006400996003840",
  "geo" : {
  },
  "id_str" : "233007290293301248",
  "in_reply_to_user_id" : 95100239,
  "text" : "@NickAnderegg Yes but they were insecure long before they got bad press.",
  "id" : 233007290293301248,
  "in_reply_to_status_id" : 233006400996003840,
  "created_at" : "Wed Aug 08 01:10:41 +0000 2012",
  "in_reply_to_screen_name" : "NickAnderegg",
  "in_reply_to_user_id_str" : "95100239",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mitt Romney",
      "screen_name" : "MittRomney",
      "indices" : [ 3, 14 ],
      "id_str" : "50055701",
      "id" : 50055701
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MittVP",
      "indices" : [ 132, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 131 ],
      "url" : "http://t.co/2Zh9HyVp",
      "expanded_url" : "http://mi.tt/P4Bk5T",
      "display_url" : "mi.tt/P4Bk5T"
    } ]
  },
  "geo" : {
  },
  "id_str" : "233005807229337600",
  "text" : "RT @MittRomney: Soon, I'll be announcing my choice for VP. Download the app and be the first to hear the news! http://t.co/2Zh9HyVp #MittVP",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MittVP",
        "indices" : [ 116, 123 ]
      } ],
      "urls" : [ {
        "indices" : [ 95, 115 ],
        "url" : "http://t.co/2Zh9HyVp",
        "expanded_url" : "http://mi.tt/P4Bk5T",
        "display_url" : "mi.tt/P4Bk5T"
      } ]
    },
    "geo" : {
    },
    "id_str" : "233005169128906753",
    "text" : "Soon, I'll be announcing my choice for VP. Download the app and be the first to hear the news! http://t.co/2Zh9HyVp #MittVP",
    "id" : 233005169128906753,
    "created_at" : "Wed Aug 08 01:02:16 +0000 2012",
    "user" : {
      "name" : "Mitt Romney",
      "screen_name" : "MittRomney",
      "protected" : false,
      "id_str" : "50055701",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2624978379/chw1hdzozfdew973pvjr_normal.png",
      "id" : 50055701,
      "verified" : true
    }
  },
  "id" : 233005807229337600,
  "created_at" : "Wed Aug 08 01:04:48 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "233005732298100736",
  "text" : "Did Amazon and Apple change their security protocols because they were insecure or because they got bad press?",
  "id" : 233005732298100736,
  "created_at" : "Wed Aug 08 01:04:30 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Everest",
      "screen_name" : "everest",
      "indices" : [ 0, 8 ],
      "id_str" : "408072050",
      "id" : 408072050
    }, {
      "name" : "Budge",
      "screen_name" : "budge",
      "indices" : [ 74, 80 ],
      "id_str" : "286384512",
      "id" : 286384512
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "232953454648250370",
  "in_reply_to_user_id" : 408072050,
  "text" : "@everest I'm working on a list of app recommendations for people who like @budge... any room for an extra beta tester?",
  "id" : 232953454648250370,
  "created_at" : "Tue Aug 07 21:36:46 +0000 2012",
  "in_reply_to_screen_name" : "everest",
  "in_reply_to_user_id_str" : "408072050",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Baio",
      "screen_name" : "waxpancake",
      "indices" : [ 0, 11 ],
      "id_str" : "13461",
      "id" : 13461
    }, {
      "name" : "Andre Torrez",
      "screen_name" : "torrez",
      "indices" : [ 12, 19 ],
      "id_str" : "11604",
      "id" : 11604
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "232914903650951168",
  "geo" : {
  },
  "id_str" : "232915098556051456",
  "in_reply_to_user_id" : 13461,
  "text" : "@waxpancake @torrez I am only concerned about photos for the most part. Docs are on Dropbox, code is on Github, music is replaceable...",
  "id" : 232915098556051456,
  "in_reply_to_status_id" : 232914903650951168,
  "created_at" : "Tue Aug 07 19:04:21 +0000 2012",
  "in_reply_to_screen_name" : "waxpancake",
  "in_reply_to_user_id_str" : "13461",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "1Password",
      "screen_name" : "1Password",
      "indices" : [ 35, 45 ],
      "id_str" : "793926",
      "id" : 793926
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "232911574669611009",
  "text" : "Now that I’m getting all set up on @1Password, what’s the latest greatest cloud backup service these days?",
  "id" : 232911574669611009,
  "created_at" : "Tue Aug 07 18:50:21 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "1Password",
      "screen_name" : "1Password",
      "indices" : [ 55, 65 ],
      "id_str" : "793926",
      "id" : 793926
    }, {
      "name" : "LastPass",
      "screen_name" : "LastPass",
      "indices" : [ 83, 92 ],
      "id_str" : "17800533",
      "id" : 17800533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "232891034076577792",
  "text" : "Following up on yesterday’s password improvement plan: @1Password is most popular, @LastPass is a close 2nd, and is cheaper.",
  "id" : 232891034076577792,
  "created_at" : "Tue Aug 07 17:28:44 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Cole",
      "screen_name" : "irondavy",
      "indices" : [ 0, 9 ],
      "id_str" : "14986129",
      "id" : 14986129
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "232684589636780032",
  "geo" : {
  },
  "id_str" : "232696283045974016",
  "in_reply_to_user_id" : 14986129,
  "text" : "@irondavy Yes please!",
  "id" : 232696283045974016,
  "in_reply_to_status_id" : 232684589636780032,
  "created_at" : "Tue Aug 07 04:34:51 +0000 2012",
  "in_reply_to_screen_name" : "irondavy",
  "in_reply_to_user_id_str" : "14986129",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagr.am\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 52 ],
      "url" : "http://t.co/azzOprE3",
      "expanded_url" : "http://instagr.am/p/OA3kGqo0AA/",
      "display_url" : "instagr.am/p/OA3kGqo0AA/"
    } ]
  },
  "geo" : {
  },
  "id_str" : "232695719931310082",
  "text" : "8:36pm Tongue-tied about things http://t.co/azzOprE3",
  "id" : 232695719931310082,
  "created_at" : "Tue Aug 07 04:32:37 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Anderegg",
      "screen_name" : "NickAnderegg",
      "indices" : [ 0, 13 ],
      "id_str" : "95100239",
      "id" : 95100239
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "232637034521575424",
  "geo" : {
  },
  "id_str" : "232637119837900800",
  "in_reply_to_user_id" : 95100239,
  "text" : "@NickAnderegg Why is it better?",
  "id" : 232637119837900800,
  "in_reply_to_status_id" : 232637034521575424,
  "created_at" : "Tue Aug 07 00:39:46 +0000 2012",
  "in_reply_to_screen_name" : "NickAnderegg",
  "in_reply_to_user_id_str" : "95100239",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "232636661681500160",
  "text" : "I have about 5 passwords that I use everywhere. Thinking it’s time to switch to 1Password or something. Is that still the best?",
  "id" : 232636661681500160,
  "created_at" : "Tue Aug 07 00:37:56 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.apple.com/\" rel=\"nofollow\">OS X</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http://t.co/Rw6SnDqk",
      "expanded_url" : "http://www.wired.com/gadgetlab/2012/08/apple-amazon-mat-honan-hacking/all/?utm_source=twitterfeed&utm_medium=twitter",
      "display_url" : "wired.com/gadgetlab/2012…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "232636123279679489",
  "text" : "\"The 4 digits Amazon considers unimportant enough to display = same 4 Apple considers secure enough to verify identity\" http://t.co/Rw6SnDqk",
  "id" : 232636123279679489,
  "created_at" : "Tue Aug 07 00:35:48 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Berkun",
      "screen_name" : "berkun",
      "indices" : [ 3, 10 ],
      "id_str" : "30495974",
      "id" : 30495974
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "232634599954579456",
  "text" : "RT @berkun: The most important habit to have is the habit of evaluating and changing your habits.",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "232593248210780161",
    "text" : "The most important habit to have is the habit of evaluating and changing your habits.",
    "id" : 232593248210780161,
    "created_at" : "Mon Aug 06 21:45:26 +0000 2012",
    "user" : {
      "name" : "Scott Berkun",
      "screen_name" : "berkun",
      "protected" : false,
      "id_str" : "30495974",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1650114946/gravatar_normal.png",
      "id" : 30495974,
      "verified" : false
    }
  },
  "id" : 232634599954579456,
  "created_at" : "Tue Aug 07 00:29:45 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niko Benson",
      "screen_name" : "nikobenson",
      "indices" : [ 11, 22 ],
      "id_str" : "142467448",
      "id" : 142467448
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 95 ],
      "url" : "http://t.co/fIDVCFZz",
      "expanded_url" : "http://www.macrumors.com/2012/08/06/ios-6-beta-4-removes-dedicated-youtube-app/",
      "display_url" : "macrumors.com/2012/08/06/ios…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "232554397165559808",
  "text" : "Looks like @nikobenson's favorite app is going away. He's gonna be pissed! http://t.co/fIDVCFZz",
  "id" : 232554397165559808,
  "created_at" : "Mon Aug 06 19:11:03 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Santangelo",
      "screen_name" : "endquote",
      "indices" : [ 0, 9 ],
      "id_str" : "408",
      "id" : 408
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "232549566145257473",
  "geo" : {
  },
  "id_str" : "232553682883977216",
  "in_reply_to_user_id" : 408,
  "text" : "@endquote I think so. I've been using it without any trouble.",
  "id" : 232553682883977216,
  "in_reply_to_status_id" : 232549566145257473,
  "created_at" : "Mon Aug 06 19:08:13 +0000 2012",
  "in_reply_to_screen_name" : "endquote",
  "in_reply_to_user_id_str" : "408",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "232356937264689152",
  "text" : "Bring on the Mars Curiosity landing conspiracy theories.  Actually, don’t.",
  "id" : 232356937264689152,
  "created_at" : "Mon Aug 06 06:06:25 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Curiosity Rover",
      "screen_name" : "MarsCuriosity",
      "indices" : [ 3, 17 ],
      "id_str" : "15473958",
      "id" : 15473958
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MSL",
      "indices" : [ 123, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "232352468758036481",
  "text" : "RT @MarsCuriosity: No photo or it didn't happen? Well lookee here, I'm casting a shadow on the ground in Mars' Gale crater #MSL http://t ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http://twitter.com/MarsCuriosity/status/232352290919567361/photo/1",
        "indices" : [ 109, 129 ],
        "url" : "http://t.co/cj1zFJty",
        "media_url" : "http://pbs.twimg.com/media/Azl7LXOCUAAJT5z.jpg",
        "id_str" : "232352290927955968",
        "id" : 232352290927955968,
        "media_url_https" : "https://pbs.twimg.com/media/Azl7LXOCUAAJT5z.jpg",
        "sizes" : [ {
          "h" : 256,
          "resize" : "fit",
          "w" : 256
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 256,
          "resize" : "fit",
          "w" : 256
        }, {
          "h" : 256,
          "resize" : "fit",
          "w" : 256
        }, {
          "h" : 256,
          "resize" : "fit",
          "w" : 256
        } ],
        "display_url" : "pic.twitter.com/cj1zFJty"
      } ],
      "hashtags" : [ {
        "text" : "MSL",
        "indices" : [ 104, 108 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "232352290919567361",
    "text" : "No photo or it didn't happen? Well lookee here, I'm casting a shadow on the ground in Mars' Gale crater #MSL http://t.co/cj1zFJty",
    "id" : 232352290919567361,
    "created_at" : "Mon Aug 06 05:47:58 +0000 2012",
    "user" : {
      "name" : "Curiosity Rover",
      "screen_name" : "MarsCuriosity",
      "protected" : false,
      "id_str" : "15473958",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2793288186/43e756fd0434d6ad43a8364b0e777239_normal.jpeg",
      "id" : 15473958,
      "verified" : true
    }
  },
  "id" : 232352468758036481,
  "created_at" : "Mon Aug 06 05:48:40 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trammell",
      "screen_name" : "trammell",
      "indices" : [ 3, 12 ],
      "id_str" : "666073",
      "id" : 666073
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "232350905972948992",
  "text" : "RT @trammell: So many smart babies nine months from now.",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "232350823387107328",
    "text" : "So many smart babies nine months from now.",
    "id" : 232350823387107328,
    "created_at" : "Mon Aug 06 05:42:07 +0000 2012",
    "user" : {
      "name" : "Trammell",
      "screen_name" : "trammell",
      "protected" : false,
      "id_str" : "666073",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2856914747/07a3e543f28d2b732a0161e99358503a_normal.png",
      "id" : 666073,
      "verified" : false
    }
  },
  "id" : 232350905972948992,
  "created_at" : "Mon Aug 06 05:42:27 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jonah.blossom",
      "screen_name" : "jonahb",
      "indices" : [ 3, 10 ],
      "id_str" : "7701332",
      "id" : 7701332
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/jonahb/status/232349932437245953/photo/1",
      "indices" : [ 41, 61 ],
      "url" : "http://t.co/K7WwVZFB",
      "media_url" : "http://pbs.twimg.com/media/Azl5CFLCEAEcuYI.png",
      "id_str" : "232349932441440257",
      "id" : 232349932441440257,
      "media_url_https" : "https://pbs.twimg.com/media/Azl5CFLCEAEcuYI.png",
      "sizes" : [ {
        "h" : 856,
        "resize" : "fit",
        "w" : 958
      }, {
        "h" : 536,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 304,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 856,
        "resize" : "fit",
        "w" : 958
      } ],
      "display_url" : "pic.twitter.com/K7WwVZFB"
    } ],
    "hashtags" : [ {
      "text" : "Curiosity",
      "indices" : [ 29, 39 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "232350337430872064",
  "text" : "RT @jonahb: First image from #Curiosity! http://t.co/K7WwVZFB",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http://twitter.com/jonahb/status/232349932437245953/photo/1",
        "indices" : [ 29, 49 ],
        "url" : "http://t.co/K7WwVZFB",
        "media_url" : "http://pbs.twimg.com/media/Azl5CFLCEAEcuYI.png",
        "id_str" : "232349932441440257",
        "id" : 232349932441440257,
        "media_url_https" : "https://pbs.twimg.com/media/Azl5CFLCEAEcuYI.png",
        "sizes" : [ {
          "h" : 856,
          "resize" : "fit",
          "w" : 958
        }, {
          "h" : 536,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 304,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 856,
          "resize" : "fit",
          "w" : 958
        } ],
        "display_url" : "pic.twitter.com/K7WwVZFB"
      } ],
      "hashtags" : [ {
        "text" : "Curiosity",
        "indices" : [ 17, 27 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "232349932437245953",
    "text" : "First image from #Curiosity! http://t.co/K7WwVZFB",
    "id" : 232349932437245953,
    "created_at" : "Mon Aug 06 05:38:36 +0000 2012",
    "user" : {
      "name" : "jonah.blossom",
      "screen_name" : "jonahb",
      "protected" : false,
      "id_str" : "7701332",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1146281438/DSC_0126_normal.jpg",
      "id" : 7701332,
      "verified" : false
    }
  },
  "id" : 232350337430872064,
  "created_at" : "Mon Aug 06 05:40:11 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Ward",
      "screen_name" : "BenWard",
      "indices" : [ 3, 11 ],
      "id_str" : "12249",
      "id" : 12249
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "232349652182265856",
  "text" : "RT @BenWard: Watching the Mars landing on a live stream is great, but sharing the moment with everyone, and people at NASA on Twitter is ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "232349530069299200",
    "text" : "Watching the Mars landing on a live stream is great, but sharing the moment with everyone, and people at NASA on Twitter is blowing my mind.",
    "id" : 232349530069299200,
    "created_at" : "Mon Aug 06 05:36:59 +0000 2012",
    "user" : {
      "name" : "Ben Ward",
      "screen_name" : "BenWard",
      "protected" : false,
      "id_str" : "12249",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1409204408/2011_normal.png",
      "id" : 12249,
      "verified" : false
    }
  },
  "id" : 232349652182265856,
  "created_at" : "Mon Aug 06 05:37:28 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "232349587971641344",
  "text" : "“We are wheels down on Mars!”\n\n“We’ve got thumbnails!”\n\n“Are we gonna get a full image???”\n\nWoah.",
  "id" : 232349587971641344,
  "created_at" : "Mon Aug 06 05:37:13 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Curiosity Rover",
      "screen_name" : "MarsCuriosity",
      "indices" : [ 3, 17 ],
      "id_str" : "15473958",
      "id" : 15473958
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MSL",
      "indices" : [ 81, 85 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "232348463952695296",
  "text" : "RT @MarsCuriosity: I'm safely on the surface of Mars. GALE CRATER I AM IN YOU!!! #MSL",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MSL",
        "indices" : [ 62, 66 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "232348380431544320",
    "text" : "I'm safely on the surface of Mars. GALE CRATER I AM IN YOU!!! #MSL",
    "id" : 232348380431544320,
    "created_at" : "Mon Aug 06 05:32:25 +0000 2012",
    "user" : {
      "name" : "Curiosity Rover",
      "screen_name" : "MarsCuriosity",
      "protected" : false,
      "id_str" : "15473958",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2793288186/43e756fd0434d6ad43a8364b0e777239_normal.jpeg",
      "id" : 15473958,
      "verified" : true
    }
  },
  "id" : 232348463952695296,
  "created_at" : "Mon Aug 06 05:32:45 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Curiosity Rover",
      "screen_name" : "MarsCuriosity",
      "indices" : [ 3, 17 ],
      "id_str" : "15473958",
      "id" : 15473958
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MSL",
      "indices" : [ 77, 81 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "232348023177494528",
  "text" : "RT @MarsCuriosity: Heatshield separation. Next up: Radar must lock on ground #MSL",
  "retweeted_status" : {
    "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MSL",
        "indices" : [ 58, 62 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "232347953321349121",
    "text" : "Heatshield separation. Next up: Radar must lock on ground #MSL",
    "id" : 232347953321349121,
    "created_at" : "Mon Aug 06 05:30:43 +0000 2012",
    "user" : {
      "name" : "Curiosity Rover",
      "screen_name" : "MarsCuriosity",
      "protected" : false,
      "id_str" : "15473958",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2793288186/43e756fd0434d6ad43a8364b0e777239_normal.jpeg",
      "id" : 15473958,
      "verified" : true
    }
  },
  "id" : 232348023177494528,
  "created_at" : "Mon Aug 06 05:31:00 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Curiosity Rover",
      "screen_name" : "MarsCuriosity",
      "indices" : [ 3, 17 ],
      "id_str" : "15473958",
      "id" : 15473958
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MSL",
      "indices" : [ 94, 98 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "232347687884836864",
  "text" : "RT @MarsCuriosity: Parachute deployed! Velocity 900 mph. Altitude 7 miles. 4 minutes to Mars! #MSL",
  "retweeted_status" : {
    "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MSL",
        "indices" : [ 75, 79 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "232347600597164032",
    "text" : "Parachute deployed! Velocity 900 mph. Altitude 7 miles. 4 minutes to Mars! #MSL",
    "id" : 232347600597164032,
    "created_at" : "Mon Aug 06 05:29:19 +0000 2012",
    "user" : {
      "name" : "Curiosity Rover",
      "screen_name" : "MarsCuriosity",
      "protected" : false,
      "id_str" : "15473958",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2793288186/43e756fd0434d6ad43a8364b0e777239_normal.jpeg",
      "id" : 15473958,
      "verified" : true
    }
  },
  "id" : 232347687884836864,
  "created_at" : "Mon Aug 06 05:29:40 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Estee",
      "screen_name" : "mikeestee",
      "indices" : [ 26, 36 ],
      "id_str" : "428759320",
      "id" : 428759320
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "232346629976498176",
  "text" : "Please, cat, be alive. RT @mikeestee: Schrödinger’s Rover.",
  "id" : 232346629976498176,
  "created_at" : "Mon Aug 06 05:25:28 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helena Price",
      "screen_name" : "helena",
      "indices" : [ 0, 7 ],
      "id_str" : "19699682",
      "id" : 19699682
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "232344768112373760",
  "geo" : {
  },
  "id_str" : "232345785583419392",
  "in_reply_to_user_id" : 19699682,
  "text" : "@helena Thank you! That’s working!",
  "id" : 232345785583419392,
  "in_reply_to_status_id" : 232344768112373760,
  "created_at" : "Mon Aug 06 05:22:06 +0000 2012",
  "in_reply_to_screen_name" : "helena",
  "in_reply_to_user_id_str" : "19699682",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "universefail",
      "indices" : [ 65, 78 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "232345640405983232",
  "text" : "What’s up with the fabric of spacetime and this 14 minute delay? #universefail",
  "id" : 232345640405983232,
  "created_at" : "Mon Aug 06 05:21:32 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Curiosity Rover",
      "screen_name" : "MarsCuriosity",
      "indices" : [ 26, 40 ],
      "id_str" : "15473958",
      "id" : 15473958
    }, {
      "name" : "Ustream",
      "screen_name" : "Ustream",
      "indices" : [ 49, 57 ],
      "id_str" : "5490392",
      "id" : 5490392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "232344210244784129",
  "text" : "Got home just in time for @MarsCuriosity but the @ustream live feed has crashed my computer twice now. Resorting to live tweet stream.",
  "id" : 232344210244784129,
  "created_at" : "Mon Aug 06 05:15:51 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Curiosity Rover",
      "screen_name" : "MarsCuriosity",
      "indices" : [ 3, 17 ],
      "id_str" : "15473958",
      "id" : 15473958
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MSL",
      "indices" : [ 127, 131 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 126 ],
      "url" : "http://t.co/MJLj3uaH",
      "expanded_url" : "http://bit.ly/MarsLive",
      "display_url" : "bit.ly/MarsLive"
    } ]
  },
  "geo" : {
  },
  "id_str" : "232320755105419264",
  "text" : "RT @MarsCuriosity: 2 hours to Mars, 16,300 miles away and closing fast. Velocity = 8,900 mph. Watch live: http://t.co/MJLj3uaH #MSL",
  "retweeted_status" : {
    "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MSL",
        "indices" : [ 108, 112 ]
      } ],
      "urls" : [ {
        "indices" : [ 87, 107 ],
        "url" : "http://t.co/MJLj3uaH",
        "expanded_url" : "http://bit.ly/MarsLive",
        "display_url" : "bit.ly/MarsLive"
      } ]
    },
    "geo" : {
    },
    "id_str" : "232318842867707904",
    "text" : "2 hours to Mars, 16,300 miles away and closing fast. Velocity = 8,900 mph. Watch live: http://t.co/MJLj3uaH #MSL",
    "id" : 232318842867707904,
    "created_at" : "Mon Aug 06 03:35:03 +0000 2012",
    "user" : {
      "name" : "Curiosity Rover",
      "screen_name" : "MarsCuriosity",
      "protected" : false,
      "id_str" : "15473958",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2793288186/43e756fd0434d6ad43a8364b0e777239_normal.jpeg",
      "id" : 15473958,
      "verified" : true
    }
  },
  "id" : 232320755105419264,
  "created_at" : "Mon Aug 06 03:42:38 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 90 ],
      "url" : "http://t.co/38FvTMfH",
      "expanded_url" : "http://flic.kr/p/cLquMw",
      "display_url" : "flic.kr/p/cLquMw"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.623333, -122.512 ]
  },
  "id_str" : "232320036327538690",
  "text" : "8:36pm Reading The Giving Tree as we wait for a ferry back to Seattle http://t.co/38FvTMfH",
  "id" : 232320036327538690,
  "created_at" : "Mon Aug 06 03:39:47 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagr.am\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 37 ],
      "url" : "http://t.co/HPyLur9r",
      "expanded_url" : "http://instagr.am/p/N9QE-vo0PF/",
      "display_url" : "instagr.am/p/N9QE-vo0PF/"
    } ]
  },
  "geo" : {
  },
  "id_str" : "232186605685858304",
  "text" : "Making breakfast http://t.co/HPyLur9r",
  "id" : 232186605685858304,
  "created_at" : "Sun Aug 05 18:49:35 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Galen Ward",
      "screen_name" : "galenward",
      "indices" : [ 78, 88 ],
      "id_str" : "2854761",
      "id" : 2854761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 72 ],
      "url" : "http://t.co/XKFklX65",
      "expanded_url" : "http://tnw.co/MXz0h5",
      "display_url" : "tnw.co/MXz0h5"
    } ]
  },
  "geo" : {
  },
  "id_str" : "232161186202927104",
  "text" : "The 10 most disturbing communities on the internet: http://t.co/XKFklX65 /via @galenward",
  "id" : 232161186202927104,
  "created_at" : "Sun Aug 05 17:08:34 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Loving",
      "screen_name" : "adamloving",
      "indices" : [ 3, 14 ],
      "id_str" : "809641",
      "id" : 809641
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "232155013621899264",
  "text" : "RT @adamloving: Mars Rover Curiosity (the \"7 minutes of terror\" one) is scheduled for landing at 10:31 p.m. PDT tonight. http://t.co/n2Y ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 105, 125 ],
        "url" : "http://t.co/n2YQhwvo",
        "expanded_url" : "http://www.latimes.com/news/science/la-me-0805-mars-rover-curiosity-landing-countdown-20120805,0,2172787.story",
        "display_url" : "latimes.com/news/science/l…"
      } ]
    },
    "geo" : {
    },
    "id_str" : "232142745395920896",
    "text" : "Mars Rover Curiosity (the \"7 minutes of terror\" one) is scheduled for landing at 10:31 p.m. PDT tonight. http://t.co/n2YQhwvo",
    "id" : 232142745395920896,
    "created_at" : "Sun Aug 05 15:55:18 +0000 2012",
    "user" : {
      "name" : "Adam Loving",
      "screen_name" : "adamloving",
      "protected" : false,
      "id_str" : "809641",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1853804101/IMG_1329_normal.jpg",
      "id" : 809641,
      "verified" : false
    }
  },
  "id" : 232155013621899264,
  "created_at" : "Sun Aug 05 16:44:03 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 132 ],
      "url" : "http://t.co/rABnx33h",
      "expanded_url" : "http://onforb.es/MXxRGn",
      "display_url" : "onforb.es/MXxRGn"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6448923601, -122.5655148898 ]
  },
  "id_str" : "232149425034784768",
  "text" : "The group of people interested in personal change are becoming a market segment. Interesting and a bit twisted. http://t.co/rABnx33h",
  "id" : 232149425034784768,
  "created_at" : "Sun Aug 05 16:21:50 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 43 ],
      "url" : "http://t.co/XLuhbiIm",
      "expanded_url" : "http://flic.kr/p/cKH8qy",
      "display_url" : "flic.kr/p/cKH8qy"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.647666, -122.5595 ]
  },
  "id_str" : "231957569441255424",
  "text" : "8:36pm Singing Popcorn http://t.co/XLuhbiIm",
  "id" : 231957569441255424,
  "created_at" : "Sun Aug 05 03:39:28 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagr.am\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 46 ],
      "url" : "http://t.co/Y7NBSoTf",
      "expanded_url" : "http://instagr.am/p/N7ghBdo0Pa/",
      "display_url" : "instagr.am/p/N7ghBdo0Pa/"
    } ]
  },
  "geo" : {
  },
  "id_str" : "231941676535537664",
  "text" : "Meadowfabulous dress code http://t.co/Y7NBSoTf",
  "id" : 231941676535537664,
  "created_at" : "Sun Aug 05 02:36:19 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Curiosity Rover",
      "screen_name" : "MarsCuriosity",
      "indices" : [ 40, 54 ],
      "id_str" : "15473958",
      "id" : 15473958
    }, {
      "name" : "Neil deGrasse Tyson",
      "screen_name" : "neiltyson",
      "indices" : [ 59, 69 ],
      "id_str" : "19725644",
      "id" : 19725644
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http://t.co/fS6X4Ks5",
      "expanded_url" : "http://1.usa.gov/QCcTOT",
      "display_url" : "1.usa.gov/QCcTOT"
    } ]
  },
  "geo" : {
  },
  "id_str" : "231917881993097218",
  "text" : "Great dialogue today on Twitter between @MarsCuriosity and @neiltyson (check their twitter streams). \n\nMore background: http://t.co/fS6X4Ks5",
  "id" : 231917881993097218,
  "created_at" : "Sun Aug 05 01:01:46 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Curiosity Rover",
      "screen_name" : "MarsCuriosity",
      "indices" : [ 3, 17 ],
      "id_str" : "15473958",
      "id" : 15473958
    }, {
      "name" : "Neil deGrasse Tyson",
      "screen_name" : "neiltyson",
      "indices" : [ 24, 34 ],
      "id_str" : "19725644",
      "id" : 19725644
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Olympic",
      "indices" : [ 41, 49 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "231904319518154752",
  "text" : "RT @MarsCuriosity: Dear @neiltyson, like #Olympic athletes, I have a great team behind me. Time to stick the landing",
  "retweeted_status" : {
    "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Neil deGrasse Tyson",
        "screen_name" : "neiltyson",
        "indices" : [ 5, 15 ],
        "id_str" : "19725644",
        "id" : 19725644
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Olympic",
        "indices" : [ 22, 30 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "231891715169087488",
    "geo" : {
    },
    "id_str" : "231892846226067456",
    "in_reply_to_user_id" : 19725644,
    "text" : "Dear @neiltyson, like #Olympic athletes, I have a great team behind me. Time to stick the landing",
    "id" : 231892846226067456,
    "in_reply_to_status_id" : 231891715169087488,
    "created_at" : "Sat Aug 04 23:22:17 +0000 2012",
    "in_reply_to_screen_name" : "neiltyson",
    "in_reply_to_user_id_str" : "19725644",
    "user" : {
      "name" : "Curiosity Rover",
      "screen_name" : "MarsCuriosity",
      "protected" : false,
      "id_str" : "15473958",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2793288186/43e756fd0434d6ad43a8364b0e777239_normal.jpeg",
      "id" : 15473958,
      "verified" : true
    }
  },
  "id" : 231904319518154752,
  "created_at" : "Sun Aug 05 00:07:53 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Neil deGrasse Tyson",
      "screen_name" : "neiltyson",
      "indices" : [ 3, 13 ],
      "id_str" : "19725644",
      "id" : 19725644
    }, {
      "name" : "Curiosity Rover",
      "screen_name" : "MarsCuriosity",
      "indices" : [ 20, 34 ],
      "id_str" : "15473958",
      "id" : 15473958
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "231903942907408384",
  "text" : "RT @neiltyson: Dear @MarsCuriosity, What are your instructions if a Martian crawls onto your back and rides you like a Rodeo Bull?",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Curiosity Rover",
        "screen_name" : "MarsCuriosity",
        "indices" : [ 5, 19 ],
        "id_str" : "15473958",
        "id" : 15473958
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "231890869173772288",
    "text" : "Dear @MarsCuriosity, What are your instructions if a Martian crawls onto your back and rides you like a Rodeo Bull?",
    "id" : 231890869173772288,
    "created_at" : "Sat Aug 04 23:14:26 +0000 2012",
    "user" : {
      "name" : "Neil deGrasse Tyson",
      "screen_name" : "neiltyson",
      "protected" : false,
      "id_str" : "19725644",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/74188698/NeilTysonOriginsA-Crop_normal.jpg",
      "id" : 19725644,
      "verified" : true
    }
  },
  "id" : 231903942907408384,
  "created_at" : "Sun Aug 05 00:06:23 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagr.am\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 53 ],
      "url" : "http://t.co/U6QAERU5",
      "expanded_url" : "http://instagr.am/p/N6ejkTo0K7/",
      "display_url" : "instagr.am/p/N6ejkTo0K7/"
    } ]
  },
  "geo" : {
  },
  "id_str" : "231796443747340288",
  "text" : "The official \"love moment\" bench http://t.co/U6QAERU5",
  "id" : 231796443747340288,
  "created_at" : "Sat Aug 04 16:59:13 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mat honan",
      "screen_name" : "mathonan",
      "indices" : [ 33, 42 ],
      "id_str" : "736101894",
      "id" : 736101894
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 89 ],
      "url" : "http://t.co/nuzf2UnZ",
      "expanded_url" : "http://bit.ly/N5r7EL",
      "display_url" : "bit.ly/N5r7EL"
    } ]
  },
  "geo" : {
  },
  "id_str" : "231763348843274240",
  "text" : "Here’s a scary hacking story. RT @mathonan: So here’s what happened: http://t.co/nuzf2UnZ",
  "id" : 231763348843274240,
  "created_at" : "Sat Aug 04 14:47:42 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Keys",
      "screen_name" : "ProducerMatthew",
      "indices" : [ 3, 19 ],
      "id_str" : "901069933",
      "id" : 901069933
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "231647766529585153",
  "text" : "RT @ProducerMatthew: 900 notes on Tumblr. 1,400 re-tweets on Twitter. 1,000 shares on Facebook. This is the photo of the night - http:// ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "london2012",
        "indices" : [ 129, 140 ]
      } ],
      "urls" : [ {
        "indices" : [ 108, 128 ],
        "url" : "http://t.co/WylJiTET",
        "expanded_url" : "http://bit.ly/MjokDz",
        "display_url" : "bit.ly/MjokDz"
      } ]
    },
    "geo" : {
    },
    "id_str" : "231630809520553985",
    "text" : "900 notes on Tumblr. 1,400 re-tweets on Twitter. 1,000 shares on Facebook. This is the photo of the night - http://t.co/WylJiTET #london2012",
    "id" : 231630809520553985,
    "created_at" : "Sat Aug 04 06:01:03 +0000 2012",
    "user" : {
      "name" : "Matthew Keys",
      "screen_name" : "TheMatthewKeys",
      "protected" : false,
      "id_str" : "754485",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1955846307/401336_305489232826844_100000973092006_851073_1681250623_n_normal.jpeg",
      "id" : 754485,
      "verified" : false
    }
  },
  "id" : 231647766529585153,
  "created_at" : "Sat Aug 04 07:08:26 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagr.am\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 92 ],
      "url" : "http://t.co/crA1gc8z",
      "expanded_url" : "http://instagr.am/p/N5C7QcI0AS/",
      "display_url" : "instagr.am/p/N5C7QcI0AS/"
    } ]
  },
  "geo" : {
  },
  "id_str" : "231594966927962112",
  "text" : "8:36pm At Sacred Groves for the weekend to celebrate with Ariel and Dre http://t.co/crA1gc8z",
  "id" : 231594966927962112,
  "created_at" : "Sat Aug 04 03:38:37 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 78, 88 ],
      "id_str" : "7362142",
      "id" : 7362142
    }, {
      "name" : "Niko Benson",
      "screen_name" : "nikobenson",
      "indices" : [ 117, 128 ],
      "id_str" : "142467448",
      "id" : 142467448
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "231561345676476416",
  "text" : "On a guy trying to cut in line at ferry, when he fails: “Buh bye, jackass!” - @kellianne. Then, “Buh bye jackass!” - @nikobenson",
  "id" : 231561345676476416,
  "created_at" : "Sat Aug 04 01:25:01 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Telegraph Obituaries",
      "screen_name" : "telegraphobits",
      "indices" : [ 17, 32 ],
      "id_str" : "32712796",
      "id" : 32712796
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "obitoftheday",
      "indices" : [ 0, 13 ]
    } ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http://t.co/WNEuxC7f",
      "expanded_url" : "http://bit.ly/QAsEWD",
      "display_url" : "bit.ly/QAsEWD"
    } ]
  },
  "geo" : {
  },
  "id_str" : "231539882693124097",
  "text" : "#obitoftheday RT @telegraphobits: Archaeologist whose encounter w/stranger on a train mired him in mystery and intrigue http://t.co/WNEuxC7f",
  "id" : 231539882693124097,
  "created_at" : "Fri Aug 03 23:59:44 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dalton Caldwell",
      "screen_name" : "daltonc",
      "indices" : [ 0, 8 ],
      "id_str" : "9151842",
      "id" : 9151842
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "231467367165751297",
  "geo" : {
  },
  "id_str" : "231467453316739074",
  "in_reply_to_user_id" : 9151842,
  "text" : "@daltonc I do!",
  "id" : 231467453316739074,
  "in_reply_to_status_id" : 231467367165751297,
  "created_at" : "Fri Aug 03 19:11:55 +0000 2012",
  "in_reply_to_screen_name" : "daltonc",
  "in_reply_to_user_id_str" : "9151842",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ArielMeadowStallings",
      "screen_name" : "OffbeatAriel",
      "indices" : [ 0, 13 ],
      "id_str" : "14095370",
      "id" : 14095370
    }, {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 14, 24 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "231229211485028352",
  "geo" : {
  },
  "id_str" : "231293919391002624",
  "in_reply_to_user_id" : 14095370,
  "text" : "@OffbeatAriel @kellianne Got sent this more than a couple times today! So funny. Niko liked it too.",
  "id" : 231293919391002624,
  "in_reply_to_status_id" : 231229211485028352,
  "created_at" : "Fri Aug 03 07:42:22 +0000 2012",
  "in_reply_to_screen_name" : "OffbeatAriel",
  "in_reply_to_user_id_str" : "14095370",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 87 ],
      "url" : "http://t.co/JtLtwTxK",
      "expanded_url" : "http://flic.kr/p/cJBFWG",
      "display_url" : "flic.kr/p/cJBFWG"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6155, -122.320334 ]
  },
  "id_str" : "231237322509791232",
  "text" : "8:36pm Hanging out on Substantial roof with Tikva, Donte, and Ario http://t.co/JtLtwTxK",
  "id" : 231237322509791232,
  "created_at" : "Fri Aug 03 03:57:28 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tehgeekmeister",
      "screen_name" : "tehgeekmeister",
      "indices" : [ 0, 15 ],
      "id_str" : "6727082",
      "id" : 6727082
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "231159313186553857",
  "geo" : {
  },
  "id_str" : "231160343093731328",
  "in_reply_to_user_id" : 6727082,
  "text" : "@tehgeekmeister You’re welcome. I’ll let you know if I can get around to the web hook anytime soon.",
  "id" : 231160343093731328,
  "in_reply_to_status_id" : 231159313186553857,
  "created_at" : "Thu Aug 02 22:51:35 +0000 2012",
  "in_reply_to_screen_name" : "tehgeekmeister",
  "in_reply_to_user_id_str" : "6727082",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tehgeekmeister",
      "screen_name" : "tehgeekmeister",
      "indices" : [ 0, 15 ],
      "id_str" : "6727082",
      "id" : 6727082
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "231158932347957248",
  "geo" : {
  },
  "id_str" : "231159133779398656",
  "in_reply_to_user_id" : 6727082,
  "text" : "@tehgeekmeister Not at all. Go for it!",
  "id" : 231159133779398656,
  "in_reply_to_status_id" : 231158932347957248,
  "created_at" : "Thu Aug 02 22:46:46 +0000 2012",
  "in_reply_to_screen_name" : "tehgeekmeister",
  "in_reply_to_user_id_str" : "6727082",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tehgeekmeister",
      "screen_name" : "tehgeekmeister",
      "indices" : [ 0, 15 ],
      "id_str" : "6727082",
      "id" : 6727082
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "231158251549495297",
  "geo" : {
  },
  "id_str" : "231158540226674688",
  "in_reply_to_user_id" : 6727082,
  "text" : "@tehgeekmeister The full api is planned but will realistically be a while before it’s functional.",
  "id" : 231158540226674688,
  "in_reply_to_status_id" : 231158251549495297,
  "created_at" : "Thu Aug 02 22:44:25 +0000 2012",
  "in_reply_to_screen_name" : "tehgeekmeister",
  "in_reply_to_user_id_str" : "6727082",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tehgeekmeister",
      "screen_name" : "tehgeekmeister",
      "indices" : [ 0, 15 ],
      "id_str" : "6727082",
      "id" : 6727082
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "231157102792548352",
  "geo" : {
  },
  "id_str" : "231157367348289536",
  "in_reply_to_user_id" : 6727082,
  "text" : "@tehgeekmeister The problem with aggregating long texts is that some carriers prepend “(1/2)” and some arrive out of order.",
  "id" : 231157367348289536,
  "in_reply_to_status_id" : 231157102792548352,
  "created_at" : "Thu Aug 02 22:39:45 +0000 2012",
  "in_reply_to_screen_name" : "tehgeekmeister",
  "in_reply_to_user_id_str" : "6727082",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tehgeekmeister",
      "screen_name" : "tehgeekmeister",
      "indices" : [ 0, 15 ],
      "id_str" : "6727082",
      "id" : 6727082
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "231156982638321664",
  "geo" : {
  },
  "id_str" : "231157202910605313",
  "in_reply_to_user_id" : 6727082,
  "text" : "@tehgeekmeister A web hook is definitely something I’d like to add. Especially if someone already has a use for it.",
  "id" : 231157202910605313,
  "in_reply_to_status_id" : 231156982638321664,
  "created_at" : "Thu Aug 02 22:39:06 +0000 2012",
  "in_reply_to_screen_name" : "tehgeekmeister",
  "in_reply_to_user_id_str" : "6727082",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tehgeekmeister",
      "screen_name" : "tehgeekmeister",
      "indices" : [ 0, 15 ],
      "id_str" : "6727082",
      "id" : 6727082
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "231156725108051968",
  "geo" : {
  },
  "id_str" : "231156957308928002",
  "in_reply_to_user_id" : 6727082,
  "text" : "@tehgeekmeister Definitely wouldn’t bother me! Make your own version if you have the inspiration to.",
  "id" : 231156957308928002,
  "in_reply_to_status_id" : 231156725108051968,
  "created_at" : "Thu Aug 02 22:38:07 +0000 2012",
  "in_reply_to_screen_name" : "tehgeekmeister",
  "in_reply_to_user_id_str" : "6727082",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tehgeekmeister",
      "screen_name" : "tehgeekmeister",
      "indices" : [ 0, 15 ],
      "id_str" : "6727082",
      "id" : 6727082
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "231156395091845120",
  "geo" : {
  },
  "id_str" : "231156490726150144",
  "in_reply_to_user_id" : 6727082,
  "text" : "@tehgeekmeister Send any feature requests on over!",
  "id" : 231156490726150144,
  "in_reply_to_status_id" : 231156395091845120,
  "created_at" : "Thu Aug 02 22:36:16 +0000 2012",
  "in_reply_to_screen_name" : "tehgeekmeister",
  "in_reply_to_user_id_str" : "6727082",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tehgeekmeister",
      "screen_name" : "tehgeekmeister",
      "indices" : [ 0, 15 ],
      "id_str" : "6727082",
      "id" : 6727082
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "231155929515708416",
  "geo" : {
  },
  "id_str" : "231156075905290241",
  "in_reply_to_user_id" : 6727082,
  "text" : "@tehgeekmeister As time permits. It’s definitely a side-project kinda thing.",
  "id" : 231156075905290241,
  "in_reply_to_status_id" : 231155929515708416,
  "created_at" : "Thu Aug 02 22:34:37 +0000 2012",
  "in_reply_to_screen_name" : "tehgeekmeister",
  "in_reply_to_user_id_str" : "6727082",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robin Sloan",
      "screen_name" : "robinsloan",
      "indices" : [ 0, 11 ],
      "id_str" : "13919072",
      "id" : 13919072
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "231149771556007937",
  "geo" : {
  },
  "id_str" : "231151483595395072",
  "in_reply_to_user_id" : 13919072,
  "text" : "@robinsloan What’s your favorite current tool for building stacks? Xcode?",
  "id" : 231151483595395072,
  "in_reply_to_status_id" : 231149771556007937,
  "created_at" : "Thu Aug 02 22:16:22 +0000 2012",
  "in_reply_to_screen_name" : "robinsloan",
  "in_reply_to_user_id_str" : "13919072",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robin Sloan",
      "screen_name" : "robinsloan",
      "indices" : [ 18, 29 ],
      "id_str" : "13919072",
      "id" : 13919072
    }, {
      "name" : "Contents Magazine",
      "screen_name" : "Contents",
      "indices" : [ 92, 101 ],
      "id_str" : "348644988",
      "id" : 348644988
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 124 ],
      "url" : "http://t.co/A0m5Jaah",
      "expanded_url" : "http://contentsmagazine.com/articles/house-of-cards/",
      "display_url" : "contentsmagazine.com/articles/house…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "231150621120671744",
  "text" : "I &lt;3 stacks RT @robinsloan: Sketched out a little stack manifesto (think: HyperCard) for @Contents.  http://t.co/A0m5Jaah",
  "id" : 231150621120671744,
  "created_at" : "Thu Aug 02 22:12:57 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pete Cashmore",
      "screen_name" : "mashable",
      "indices" : [ 73, 82 ],
      "id_str" : "972651",
      "id" : 972651
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 68 ],
      "url" : "http://t.co/KHIStfy8",
      "expanded_url" : "http://mashable.com/2012/08/02/fda-digestible-device/",
      "display_url" : "mashable.com/2012/08/02/fda…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "231113939956670465",
  "text" : "FDA Approves First-Ever Digestible Digital Pill http://t.co/KHIStfy8 via @mashable",
  "id" : 231113939956670465,
  "created_at" : "Thu Aug 02 19:47:11 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aubrey Sabala",
      "screen_name" : "Aubs",
      "indices" : [ 0, 5 ],
      "id_str" : "2781",
      "id" : 2781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "231103098574229506",
  "geo" : {
  },
  "id_str" : "231103357182410752",
  "in_reply_to_user_id" : 2781,
  "text" : "@Aubs You could have queued your tweet to be posted later, while in line.",
  "id" : 231103357182410752,
  "in_reply_to_status_id" : 231103098574229506,
  "created_at" : "Thu Aug 02 19:05:08 +0000 2012",
  "in_reply_to_screen_name" : "Aubs",
  "in_reply_to_user_id_str" : "2781",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "231098458893873153",
  "text" : "“A society is just if a person understands all the conditions within that society and is willing to enter it in a random place.” -John Rawls",
  "id" : 231098458893873153,
  "created_at" : "Thu Aug 02 18:45:40 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http://t.co/bIe2VQ4p",
      "expanded_url" : "http://www.theatlantic.com/business/archive/2012/08/americans-want-to-live-in-a-much-more-equal-country-they-just-dont-realize-it/260639/#.UBq9Vfstuvg.twitter",
      "display_url" : "theatlantic.com/business/archi…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "231098024032612352",
  "text" : "Study asked 1000s of people to describe their ideal distribution of wealth from top to bottom. Interesting results: http://t.co/bIe2VQ4p",
  "id" : 231098024032612352,
  "created_at" : "Thu Aug 02 18:43:57 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 43 ],
      "url" : "http://t.co/bJ5O75FD",
      "expanded_url" : "http://flic.kr/p/cJ6A9L",
      "display_url" : "flic.kr/p/cJ6A9L"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.645833, -73.774334 ]
  },
  "id_str" : "230913610656935937",
  "text" : "8:36pm Was on a plane. http://t.co/bJ5O75FD",
  "id" : 230913610656935937,
  "created_at" : "Thu Aug 02 06:31:09 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Albert Wenger",
      "screen_name" : "albertwenger",
      "indices" : [ 3, 16 ],
      "id_str" : "7015112",
      "id" : 7015112
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 96 ],
      "url" : "http://t.co/OB8Sl56H",
      "expanded_url" : "http://tmblr.co/Z1T9byQXXJd4",
      "display_url" : "tmblr.co/Z1T9byQXXJd4"
    } ]
  },
  "geo" : {
  },
  "id_str" : "230689541885931521",
  "text" : "RT @albertwenger: The Internet, Tape Delay, Proxies and Civil Disobedience  http://t.co/OB8Sl56H",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tumblr.com/\" rel=\"nofollow\">Tumblr</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 58, 78 ],
        "url" : "http://t.co/OB8Sl56H",
        "expanded_url" : "http://tmblr.co/Z1T9byQXXJd4",
        "display_url" : "tmblr.co/Z1T9byQXXJd4"
      } ]
    },
    "geo" : {
    },
    "id_str" : "230631375718465536",
    "text" : "The Internet, Tape Delay, Proxies and Civil Disobedience  http://t.co/OB8Sl56H",
    "id" : 230631375718465536,
    "created_at" : "Wed Aug 01 11:49:39 +0000 2012",
    "user" : {
      "name" : "Albert Wenger",
      "screen_name" : "albertwenger",
      "protected" : false,
      "id_str" : "7015112",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1773890030/aew_artistic_normal.gif",
      "id" : 7015112,
      "verified" : false
    }
  },
  "id" : 230689541885931521,
  "created_at" : "Wed Aug 01 15:40:47 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Crocker",
      "screen_name" : "nickcrocker",
      "indices" : [ 102, 114 ],
      "id_str" : "30801469",
      "id" : 30801469
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 97 ],
      "url" : "http://t.co/yahyt14Y",
      "expanded_url" : "http://bit.ly/OosTRr",
      "display_url" : "bit.ly/OosTRr"
    } ]
  },
  "geo" : {
  },
  "id_str" : "230686826728419329",
  "text" : "“We cannot continue to overestimate peoples’ ability to change themselves.” \nhttp://t.co/yahyt14Y /by @nickcrocker",
  "id" : 230686826728419329,
  "created_at" : "Wed Aug 01 15:30:00 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rusty Foster",
      "screen_name" : "rustyk5",
      "indices" : [ 0, 8 ],
      "id_str" : "577124971",
      "id" : 577124971
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "230682232879194112",
  "geo" : {
  },
  "id_str" : "230683148936175616",
  "in_reply_to_user_id" : 577124971,
  "text" : "@rustyk5 Okay I buy that.",
  "id" : 230683148936175616,
  "in_reply_to_status_id" : 230682232879194112,
  "created_at" : "Wed Aug 01 15:15:23 +0000 2012",
  "in_reply_to_screen_name" : "rustyk5",
  "in_reply_to_user_id_str" : "577124971",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Schappell",
      "screen_name" : "daveschappell",
      "indices" : [ 3, 17 ],
      "id_str" : "820661",
      "id" : 820661
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 104, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 103 ],
      "url" : "http://t.co/7OUelT3k",
      "expanded_url" : "http://www.geekwire.com/2012/tony-wright-pick-startup-idea/",
      "display_url" : "geekwire.com/2012/tony-wrig…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "230678509088034816",
  "text" : "RT @daveschappell: Best of Startup Day: Tony Wright on how to pick a startup idea: http://t.co/7OUelT3k #fb",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "fb",
        "indices" : [ 85, 88 ]
      } ],
      "urls" : [ {
        "indices" : [ 64, 84 ],
        "url" : "http://t.co/7OUelT3k",
        "expanded_url" : "http://www.geekwire.com/2012/tony-wright-pick-startup-idea/",
        "display_url" : "geekwire.com/2012/tony-wrig…"
      } ]
    },
    "geo" : {
    },
    "id_str" : "230674537736441856",
    "text" : "Best of Startup Day: Tony Wright on how to pick a startup idea: http://t.co/7OUelT3k #fb",
    "id" : 230674537736441856,
    "created_at" : "Wed Aug 01 14:41:10 +0000 2012",
    "user" : {
      "name" : "Dave Schappell",
      "screen_name" : "daveschappell",
      "protected" : false,
      "id_str" : "820661",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1847687555/Dave_Schappell_200px_normal.jpg",
      "id" : 820661,
      "verified" : false
    }
  },
  "id" : 230678509088034816,
  "created_at" : "Wed Aug 01 14:56:57 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rusty Foster",
      "screen_name" : "rustyk5",
      "indices" : [ 0, 8 ],
      "id_str" : "577124971",
      "id" : 577124971
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 106 ],
      "url" : "http://t.co/I5Q8t2Yo",
      "expanded_url" : "http://bit.ly/Po3E1f",
      "display_url" : "bit.ly/Po3E1f"
    } ]
  },
  "in_reply_to_status_id_str" : "230508125306892289",
  "geo" : {
  },
  "id_str" : "230677122929287168",
  "in_reply_to_user_id" : 577124971,
  "text" : "@rustyk5 I’d love your feedback on this as an alternative to exaggerated affirmation: http://t.co/I5Q8t2Yo",
  "id" : 230677122929287168,
  "in_reply_to_status_id" : 230508125306892289,
  "created_at" : "Wed Aug 01 14:51:26 +0000 2012",
  "in_reply_to_screen_name" : "rustyk5",
  "in_reply_to_user_id_str" : "577124971",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Timo Zimmermann",
      "screen_name" : "fallenhitokiri",
      "indices" : [ 0, 15 ],
      "id_str" : "9351452",
      "id" : 9351452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http://t.co/I5Q8t2Yo",
      "expanded_url" : "http://bit.ly/Po3E1f",
      "display_url" : "bit.ly/Po3E1f"
    } ]
  },
  "in_reply_to_status_id_str" : "230539986477408256",
  "geo" : {
  },
  "id_str" : "230676630547361792",
  "in_reply_to_user_id" : 9351452,
  "text" : "@fallenhitokiri I’m all for trying. But misleading or exaggerated expectations lead to failure and self-doubt. Instead: http://t.co/I5Q8t2Yo",
  "id" : 230676630547361792,
  "in_reply_to_status_id" : 230539986477408256,
  "created_at" : "Wed Aug 01 14:49:29 +0000 2012",
  "in_reply_to_screen_name" : "fallenhitokiri",
  "in_reply_to_user_id_str" : "9351452",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Foursquare",
      "screen_name" : "foursquare",
      "indices" : [ 55, 66 ],
      "id_str" : "14120151",
      "id" : 14120151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 129 ],
      "url" : "http://t.co/T2Fr91pQ",
      "expanded_url" : "http://4sq.com/NlDtUZ",
      "display_url" : "4sq.com/NlDtUZ"
    } ]
  },
  "geo" : {
  },
  "id_str" : "230653794298523648",
  "text" : "I just reached Level 2 of the \"Baker’s Dozen\" badge on @foursquare. I’ve checked in at 5 different bakeries! http://t.co/T2Fr91pQ",
  "id" : 230653794298523648,
  "created_at" : "Wed Aug 01 13:18:44 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagr.am\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 57 ],
      "url" : "http://t.co/U1KADINe",
      "expanded_url" : "http://instagr.am/p/NyTYWPI0FC/",
      "display_url" : "instagr.am/p/NyTYWPI0FC/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.7206719673, -73.9614254053 ]
  },
  "id_str" : "230645886034800640",
  "text" : "Taking the water taxi  @ The Webbles http://t.co/U1KADINe",
  "id" : 230645886034800640,
  "created_at" : "Wed Aug 01 12:47:19 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
} ]