Grailbird.data.tweets_2010_04 = 
 [ {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "13146882543",
  "text" : "Does anyone have Internet Explorer and a minute to help me track down a javascript error?",
  "id" : 13146882543,
  "created_at" : "Fri Apr 30 19:40:59 +0000 2010",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carl ♫ Smith",
      "screen_name" : "CarlosNZ",
      "indices" : [ 0, 9 ],
      "id_str" : "16728047",
      "id" : 16728047
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "13100112806",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.61279985, -122.3475462667 ]
  },
  "id_str" : "13138999708",
  "in_reply_to_user_id" : 16728047,
  "text" : "@CarlosNZ Good work!",
  "id" : 13138999708,
  "in_reply_to_status_id" : 13100112806,
  "created_at" : "Fri Apr 30 16:48:11 +0000 2010",
  "in_reply_to_screen_name" : "CarlosNZ",
  "in_reply_to_user_id_str" : "16728047",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael McDaniel",
      "screen_name" : "michaelmcdaniel",
      "indices" : [ 0, 16 ],
      "id_str" : "7565162",
      "id" : 7565162
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "13138060999",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6123300259, -122.3471391384 ]
  },
  "id_str" : "13138380613",
  "in_reply_to_user_id" : 7565162,
  "text" : "@michaelmcdaniel Reeder is the best in my opinion if you're syncing with Google Reader.",
  "id" : 13138380613,
  "in_reply_to_status_id" : 13138060999,
  "created_at" : "Fri Apr 30 16:35:57 +0000 2010",
  "in_reply_to_screen_name" : "michaelmcdaniel",
  "in_reply_to_user_id_str" : "7565162",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://dev.twitter.com/\" rel=\"nofollow\">API</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Gruber",
      "screen_name" : "gruber",
      "indices" : [ 3, 10 ],
      "id_str" : "33423",
      "id" : 33423
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "13116001229",
  "text" : "RT @gruber: \"Thoughts on Horses\": http://tumblr.com/x1p99flsl",
  "retweeted_status" : {
    "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "13110088480",
    "text" : "\"Thoughts on Horses\": http://tumblr.com/x1p99flsl",
    "id" : 13110088480,
    "created_at" : "Fri Apr 30 04:16:44 +0000 2010",
    "user" : {
      "name" : "John Gruber",
      "screen_name" : "gruber",
      "protected" : false,
      "id_str" : "33423",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3065313266/7d563f0c22918aba2d6be2eaa9fb92a7_normal.png",
      "id" : 33423,
      "verified" : true
    }
  },
  "id" : 13116001229,
  "created_at" : "Fri Apr 30 07:09:32 +0000 2010",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.614833, -122.329667 ]
  },
  "id_str" : "13108464704",
  "text" : "8:36pm Dining out for life with Scottie and Megan http://flic.kr/p/7XohYq",
  "id" : 13108464704,
  "created_at" : "Fri Apr 30 03:39:35 +0000 2010",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "13098798772",
  "text" : "Brutal but true smackdown from Steve Jobs to Adobe, regarding Flash vs. the iPhone OS.\n\nhttp://bit.ly/9Lt9wD",
  "id" : 13098798772,
  "created_at" : "Fri Apr 30 00:23:45 +0000 2010",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sharon",
      "screen_name" : "sharon",
      "indices" : [ 0, 7 ],
      "id_str" : "260",
      "id" : 260
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "13060905867",
  "geo" : {
  },
  "id_str" : "13084324355",
  "in_reply_to_user_id" : 260,
  "text" : "@sharon Thank you! It's been a fun little project for me too.",
  "id" : 13084324355,
  "in_reply_to_status_id" : 13060905867,
  "created_at" : "Thu Apr 29 19:03:25 +0000 2010",
  "in_reply_to_screen_name" : "sharon",
  "in_reply_to_user_id_str" : "260",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.612333, -122.347167 ]
  },
  "id_str" : "13047950858",
  "text" : "8:36pm An English muffin, a towel rack, a pregnancy book, and a stick of butter walk into a bar... http://flic.kr/p/7XaoJC",
  "id" : 13047950858,
  "created_at" : "Thu Apr 29 03:38:57 +0000 2010",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "13033889432",
  "text" : "With the Noah's Ark \"discovery\" I think it's more interesting to note how some people on both sides want confirmation of beliefs over truth.",
  "id" : 13033889432,
  "created_at" : "Wed Apr 28 23:10:13 +0000 2010",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "13030414933",
  "text" : "Self-trackers in a nutshell: the more they record, the more they want to have something to record.\n\nhttp://nyti.ms/bKuE6P",
  "id" : 13030414933,
  "created_at" : "Wed Apr 28 21:54:02 +0000 2010",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6140918786, -122.3196332133 ]
  },
  "id_str" : "13022410115",
  "text" : "I wish they rented studios or mini offices in the back of the beautiful new Elliot Bay Book Company.",
  "id" : 13022410115,
  "created_at" : "Wed Apr 28 18:57:10 +0000 2010",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "octave kitten",
      "screen_name" : "zombielolita",
      "indices" : [ 0, 13 ],
      "id_str" : "239622110",
      "id" : 239622110
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "12985954542",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.61262665, -122.3478019833 ]
  },
  "id_str" : "12989733426",
  "in_reply_to_user_id" : 16366882,
  "text" : "@zombielolita Gerty may be my favorite movie robot ever! Loved the tears.",
  "id" : 12989733426,
  "in_reply_to_status_id" : 12985954542,
  "created_at" : "Wed Apr 28 05:23:13 +0000 2010",
  "in_reply_to_screen_name" : "octavekitten",
  "in_reply_to_user_id_str" : "16366882",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "definenesting",
      "indices" : [ 102, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.612333, -122.347167 ]
  },
  "id_str" : "12989644955",
  "text" : "Her at 10pm: \"Let's go on a walk!\" Me: \"Okay!\" Then she proceeds to clean the oven and these shelves. #definenesting http://flic.kr/p/7WWZxG",
  "id" : 12989644955,
  "created_at" : "Wed Apr 28 05:20:53 +0000 2010",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6133191683, -122.3473972475 ]
  },
  "id_str" : "12988799684",
  "text" : "Stoked that according to Wikipedia Moon is going to have a sequel (or two). Duncan Zowie Haywood Jones is my new favorite director!",
  "id" : 12988799684,
  "created_at" : "Wed Apr 28 04:58:49 +0000 2010",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.612333, -122.347167 ]
  },
  "id_str" : "12985279520",
  "text" : "8:36pm Watching Moon to make up for Lost re-running. It's good! http://flic.kr/p/7WW2PW",
  "id" : 12985279520,
  "created_at" : "Wed Apr 28 03:39:08 +0000 2010",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.612333, -122.347167 ]
  },
  "id_str" : "12924212032",
  "text" : "8:36pm Visited by Aimee! http://flic.kr/p/7WFmNm",
  "id" : 12924212032,
  "created_at" : "Tue Apr 27 03:38:29 +0000 2010",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.612333, -122.347167 ]
  },
  "id_str" : "12861903085",
  "text" : "8:36pm Soul night at Chef Wang's http://flic.kr/p/7WohBJ",
  "id" : 12861903085,
  "created_at" : "Mon Apr 26 03:39:34 +0000 2010",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.612333, -122.347167 ]
  },
  "id_str" : "12800934065",
  "text" : "8:36pm Jotting down notes on a new idea in my decidely baby-ready livingroom http://flic.kr/p/7W1QSv",
  "id" : 12800934065,
  "created_at" : "Sun Apr 25 03:40:59 +0000 2010",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "12780956426",
  "text" : "Looks like some people take their 750words.com streaks pretty seriously http://750words.com/patrons/note/161",
  "id" : 12780956426,
  "created_at" : "Sat Apr 24 20:02:01 +0000 2010",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.withings.com\" rel=\"nofollow\">WiTwit</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.5951, -122.333 ]
  },
  "id_str" : "12769954078",
  "text" : "My weight: 173.6 lb. Weekly weigh in. http://withings.com",
  "id" : 12769954078,
  "created_at" : "Sat Apr 24 16:00:15 +0000 2010",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "12742771999",
  "text" : "8:36pm Left the awesome Madsen Tea Party slash baby powwow and on our way to dinner with Judi at Betty http://flic.kr/p/7VQypC",
  "id" : 12742771999,
  "created_at" : "Sat Apr 24 03:39:53 +0000 2010",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6112, -122.343 ]
  },
  "id_str" : "12676512133",
  "text" : "Picking up KA after her last day of work for 4+ months!  &kb,25:social (@ Vain) http://4sq.com/8RDzLo",
  "id" : 12676512133,
  "created_at" : "Fri Apr 23 02:11:44 +0000 2010",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Roderic Rinehart",
      "screen_name" : "rodericrinehart",
      "indices" : [ 0, 16 ],
      "id_str" : "23269692",
      "id" : 23269692
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "12660674868",
  "geo" : {
  },
  "id_str" : "12661122387",
  "in_reply_to_user_id" : 23269692,
  "text" : "@rodericrinehart Thanks! I've been archiving all of my RSS feeds from social networks for a while, and just use jQuery to plot the numbers.",
  "id" : 12661122387,
  "in_reply_to_status_id" : 12660674868,
  "created_at" : "Thu Apr 22 21:06:26 +0000 2010",
  "in_reply_to_screen_name" : "rodericrinehart",
  "in_reply_to_user_id_str" : "23269692",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glitch, the game",
      "screen_name" : "playglitch",
      "indices" : [ 6, 17 ],
      "id_str" : "103943240",
      "id" : 103943240
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6128701, -122.3455441 ]
  },
  "id_str" : "12595077087",
  "text" : "Those @playglitch guys aren't just building a beautiful game, they're building a beautiful way to build beautiful games http://bit.ly/b66Nd7",
  "id" : 12595077087,
  "created_at" : "Wed Apr 21 20:02:56 +0000 2010",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Dick",
      "screen_name" : "rymodi",
      "indices" : [ 0, 7 ],
      "id_str" : "122817814",
      "id" : 122817814
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "12560338297",
  "geo" : {
  },
  "id_str" : "12594039635",
  "in_reply_to_user_id" : 122817814,
  "text" : "@rymodi Thank you! That's a high bar to meet these days but I definitely appreciate the thought.",
  "id" : 12594039635,
  "in_reply_to_status_id" : 12560338297,
  "created_at" : "Wed Apr 21 19:38:26 +0000 2010",
  "in_reply_to_screen_name" : "rymodi",
  "in_reply_to_user_id_str" : "122817814",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.675, -122.363667 ]
  },
  "id_str" : "12555800718",
  "text" : "8:36pm Dinner in Ballard with Ben and Nicole http://flic.kr/p/7V83dn",
  "id" : 12555800718,
  "created_at" : "Wed Apr 21 03:38:44 +0000 2010",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ArielMeadowStallings",
      "screen_name" : "OffbeatAriel",
      "indices" : [ 0, 13 ],
      "id_str" : "14095370",
      "id" : 14095370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "12540924820",
  "geo" : {
  },
  "id_str" : "12545148827",
  "in_reply_to_user_id" : 14095370,
  "text" : "@OffbeatAriel That's the great thing about being an indie biz! Throw in the towel when it becomes more  demoralizing than fulfilling.",
  "id" : 12545148827,
  "in_reply_to_status_id" : 12540924820,
  "created_at" : "Tue Apr 20 23:56:35 +0000 2010",
  "in_reply_to_screen_name" : "OffbeatAriel",
  "in_reply_to_user_id_str" : "14095370",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "12539367779",
  "text" : "Sorry for the potentially misleading info... 1 cm dilated doesn't mean she's in labor yet. We could have days or weeks to go. Stay tuned!",
  "id" : 12539367779,
  "created_at" : "Tue Apr 20 21:50:54 +0000 2010",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 77, 87 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.62061, -122.3195293 ]
  },
  "id_str" : "12531482643",
  "text" : "1 centimeter dialated! &kb,lh,2,0:midwifecheckup (@ Rainy City Midwifery w/  @kellianne) http://4sq.com/bGPXo8",
  "id" : 12531482643,
  "created_at" : "Tue Apr 20 18:47:44 +0000 2010",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.611833, -122.333667 ]
  },
  "id_str" : "12378802564",
  "text" : "8:36pm Just got out of The Runaways... now I need to listen to some Joan Jett http://flic.kr/p/7UgkMR",
  "id" : 12378802564,
  "created_at" : "Sun Apr 18 04:04:53 +0000 2010",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "12354135456",
  "text" : "Want to see what Iceland's volcano, Eyjafjallajökull, looked like last night?\n\nhttp://bit.ly/bmIEBp & http://bit.ly/dljbaK",
  "id" : 12354135456,
  "created_at" : "Sat Apr 17 18:06:16 +0000 2010",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "josh",
      "screen_name" : "joshc",
      "indices" : [ 0, 6 ],
      "id_str" : "2015",
      "id" : 2015
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "12350938517",
  "geo" : {
  },
  "id_str" : "12352418690",
  "in_reply_to_user_id" : 2015,
  "text" : "@joshc I would but my slot appears to be taken already! They should allow multiple entries per slot, right?",
  "id" : 12352418690,
  "in_reply_to_status_id" : 12350938517,
  "created_at" : "Sat Apr 17 17:27:35 +0000 2010",
  "in_reply_to_screen_name" : "joshc",
  "in_reply_to_user_id_str" : "2015",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.withings.com\" rel=\"nofollow\">WiTwit</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.0, -122.0 ]
  },
  "id_str" : "12348203735",
  "text" : "My weight: 173.6 lb. Weekly weigh in. http://withings.com",
  "id" : 12348203735,
  "created_at" : "Sat Apr 17 16:00:19 +0000 2010",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Foursquare",
      "screen_name" : "foursquare",
      "indices" : [ 37, 48 ],
      "id_str" : "14120151",
      "id" : 14120151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.614166, -122.345334 ]
  },
  "id_str" : "12322225935",
  "text" : "8:36pm At Mama's Papa's Cantina post @foursquare day in-superswarming http://flic.kr/p/7U5w3E",
  "id" : 12322225935,
  "created_at" : "Sat Apr 17 03:39:19 +0000 2010",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "lia bulaong",
      "screen_name" : "liabulaong",
      "indices" : [ 33, 44 ],
      "id_str" : "188534264",
      "id" : 188534264
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "12300893194",
  "geo" : {
  },
  "id_str" : "12301202281",
  "in_reply_to_user_id" : 15484730,
  "text" : "Woah, that unicorn IS a jerk! RT @liabulaong i love these illustrations of a unicorn being a jerk, by cw moss: http://is.gd/bvYLK",
  "id" : 12301202281,
  "in_reply_to_status_id" : 12300893194,
  "created_at" : "Fri Apr 16 19:48:13 +0000 2010",
  "in_reply_to_screen_name" : "lia",
  "in_reply_to_user_id_str" : "15484730",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6123222897, -122.3471466891 ]
  },
  "id_str" : "12264909635",
  "text" : "I'm gonna go ahead and say that I think I've got this newborn parenting thing down. \n\nWords to eat later must first be served, right?",
  "id" : 12264909635,
  "created_at" : "Fri Apr 16 04:36:45 +0000 2010",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael McDaniel",
      "screen_name" : "michaelmcdaniel",
      "indices" : [ 0, 16 ],
      "id_str" : "7565162",
      "id" : 7565162
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "12263426231",
  "geo" : {
  },
  "id_str" : "12263651559",
  "in_reply_to_user_id" : 7565162,
  "text" : "@michaelmcdaniel Cool, I'll get them both! Thanks!",
  "id" : 12263651559,
  "in_reply_to_status_id" : 12263426231,
  "created_at" : "Fri Apr 16 04:05:20 +0000 2010",
  "in_reply_to_screen_name" : "michaelmcdaniel",
  "in_reply_to_user_id_str" : "7565162",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://mobile.twitter.com\" rel=\"nofollow\">mobile web</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael McDaniel",
      "screen_name" : "michaelmcdaniel",
      "indices" : [ 0, 16 ],
      "id_str" : "7565162",
      "id" : 7565162
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "12262856290",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6124748833, -122.3477973 ]
  },
  "id_str" : "12263315698",
  "in_reply_to_user_id" : 7565162,
  "text" : "@michaelmcdaniel Is that a good book?I want them all!",
  "id" : 12263315698,
  "in_reply_to_status_id" : 12262856290,
  "created_at" : "Fri Apr 16 03:57:38 +0000 2010",
  "in_reply_to_screen_name" : "michaelmcdaniel",
  "in_reply_to_user_id_str" : "7565162",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.612333, -122.347167 ]
  },
  "id_str" : "12262521838",
  "text" : "8:36pm Reading Your Baby and Child, I like the \"devil's advocate\" sidebar items by hysterical parents http://flic.kr/p/7TP1Ze",
  "id" : 12262521838,
  "created_at" : "Fri Apr 16 03:39:11 +0000 2010",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "12256855834",
  "text" : "Starting with what I know, I guess http://flic.kr/p/7TMMFz",
  "id" : 12256855834,
  "created_at" : "Fri Apr 16 01:38:34 +0000 2010",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Rainert",
      "screen_name" : "arainert",
      "indices" : [ 0, 9 ],
      "id_str" : "7482",
      "id" : 7482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "12227655880",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6123345298, -122.3471366205 ]
  },
  "id_str" : "12232721192",
  "in_reply_to_user_id" : 7482,
  "text" : "@arainert That's awesome news, Alex!",
  "id" : 12232721192,
  "in_reply_to_status_id" : 12227655880,
  "created_at" : "Thu Apr 15 16:43:11 +0000 2010",
  "in_reply_to_screen_name" : "arainert",
  "in_reply_to_user_id_str" : "7482",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.666666, -122.383501 ]
  },
  "id_str" : "12202719402",
  "text" : "8:36pm Dinner at Bastille with Tyler and Loren and Kellianne! http://flic.kr/p/7TA3gV",
  "id" : 12202719402,
  "created_at" : "Thu Apr 15 03:39:03 +0000 2010",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Willo O'Brien",
      "screen_name" : "WilloToons",
      "indices" : [ 0, 11 ],
      "id_str" : "772386",
      "id" : 772386
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "12200357973",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6641631, -122.3791980667 ]
  },
  "id_str" : "12201069990",
  "in_reply_to_user_id" : 772386,
  "text" : "@willotoons Thanks Willo! If you need some new tshirt ideas I might have a couple in a week or so! How do you do that anyway? Find ideas?",
  "id" : 12201069990,
  "in_reply_to_status_id" : 12200357973,
  "created_at" : "Thu Apr 15 03:04:20 +0000 2010",
  "in_reply_to_screen_name" : "WilloToons",
  "in_reply_to_user_id_str" : "772386",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 95, 98 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6641631, -122.3791980667 ]
  },
  "id_str" : "12199700810",
  "text" : "I'm thinking of starting a simple comic strip about metaphors about being a human. Yea or nay? #fb",
  "id" : 12199700810,
  "created_at" : "Thu Apr 15 02:36:53 +0000 2010",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.651614181, -122.3784879376 ]
  },
  "id_str" : "12196332077",
  "text" : "Or maybe put another way, the key to happiness is conflicting emotions. Which leads to the logical conclusion that happy + sad = happy.",
  "id" : 12196332077,
  "created_at" : "Thu Apr 15 01:30:35 +0000 2010",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.643, -122.381834 ]
  },
  "id_str" : "12195456797",
  "text" : "A train full of planes with a sign \"Do not hump\" http://flic.kr/p/7TBNzs",
  "id" : 12195456797,
  "created_at" : "Thu Apr 15 01:13:22 +0000 2010",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "deepthoughts",
      "indices" : [ 103, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6404599333, -122.3818077333 ]
  },
  "id_str" : "12195262244",
  "text" : "Maybe to be happy and not entirely satisfied is to be complete. \n\nThat's not quite right. But it is. \n\n#deepthoughts",
  "id" : 12195262244,
  "created_at" : "Thu Apr 15 01:09:28 +0000 2010",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.616, -122.356667 ]
  },
  "id_str" : "12189076742",
  "text" : "Taking a moment to sit in the park by myself with an empty notebook. http://flic.kr/p/7TxiH6",
  "id" : 12189076742,
  "created_at" : "Wed Apr 14 23:01:10 +0000 2010",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "12186150050",
  "geo" : {
  },
  "id_str" : "12186428852",
  "in_reply_to_user_id" : 15887536,
  "text" : "@donschaffner I guess the terrible advertising campaign is at least good at reminding us that they exist!  :)  So maybe it's a success.",
  "id" : 12186428852,
  "in_reply_to_status_id" : 12186150050,
  "created_at" : "Wed Apr 14 22:01:41 +0000 2010",
  "in_reply_to_screen_name" : "bugcounter",
  "in_reply_to_user_id_str" : "15887536",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "12185162710",
  "text" : "That new Hotmail campaign about \"the new busy\" is the WORST advertising I've seen in a while.  Hope I'm not hurting anyone's feelings.",
  "id" : 12185162710,
  "created_at" : "Wed Apr 14 21:32:26 +0000 2010",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kit Latham",
      "screen_name" : "Tarky7",
      "indices" : [ 0, 7 ],
      "id_str" : "2080441",
      "id" : 2080441
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "12004562274",
  "geo" : {
  },
  "id_str" : "12184170604",
  "in_reply_to_user_id" : 2080441,
  "text" : "@Tarky7 Glad you found 750words.com, and like it!  How did you like Locavore?",
  "id" : 12184170604,
  "in_reply_to_status_id" : 12004562274,
  "created_at" : "Wed Apr 14 21:09:35 +0000 2010",
  "in_reply_to_screen_name" : "Tarky7",
  "in_reply_to_user_id_str" : "2080441",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Sutton",
      "screen_name" : "cjerrells",
      "indices" : [ 0, 10 ],
      "id_str" : "19675361",
      "id" : 19675361
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "12167086430",
  "geo" : {
  },
  "id_str" : "12183681232",
  "in_reply_to_user_id" : 19675361,
  "text" : "@cjerrells Thanks!  Do you mean avg time between starting and finishing or avg time typing?  I think the start-finish is around 40 minutes.",
  "id" : 12183681232,
  "in_reply_to_status_id" : 12167086430,
  "created_at" : "Wed Apr 14 20:58:23 +0000 2010",
  "in_reply_to_screen_name" : "cjerrells",
  "in_reply_to_user_id_str" : "19675361",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "12182821302",
  "text" : "I'm in a great mood today. Life is pretty much perfect. Work, friends, family, self--all in alignment. I'm ready for what's next. Bring it!",
  "id" : 12182821302,
  "created_at" : "Wed Apr 14 20:38:16 +0000 2010",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.623, -122.296834 ]
  },
  "id_str" : "12145569995",
  "text" : "8:36pm Birth class is over, recruited some more friends http://flic.kr/p/7TqpSJ",
  "id" : 12145569995,
  "created_at" : "Wed Apr 14 04:36:39 +0000 2010",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://dev.twitter.com/\" rel=\"nofollow\">API</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Sippey",
      "screen_name" : "sippey",
      "indices" : [ 3, 10 ],
      "id_str" : "4711",
      "id" : 4711
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "12093051878",
  "text" : "RT @sippey: quick notes on promoted tweets and platform reach http://bit.ly/dnZTx5",
  "retweeted_status" : {
    "source" : "<a href=\"http://bit.ly\" rel=\"nofollow\">bit.ly</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "12091373299",
    "text" : "quick notes on promoted tweets and platform reach http://bit.ly/dnZTx5",
    "id" : 12091373299,
    "created_at" : "Tue Apr 13 07:03:17 +0000 2010",
    "user" : {
      "name" : "Michael Sippey",
      "screen_name" : "sippey",
      "protected" : false,
      "id_str" : "4711",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2990071228/1badb0fe82fced7ac4068c6669a54a76_normal.jpeg",
      "id" : 4711,
      "verified" : false
    }
  },
  "id" : 12093051878,
  "created_at" : "Tue Apr 13 08:03:00 +0000 2010",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "12084758820",
  "text" : "Our house is so clean it's obscene!",
  "id" : 12084758820,
  "created_at" : "Tue Apr 13 03:49:54 +0000 2010",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.614, -122.3455 ]
  },
  "id_str" : "12084257190",
  "text" : "8:36pm Wrapping up work at Bedlam, accidentally locked out of my house. http://flic.kr/p/7T6ELc",
  "id" : 12084257190,
  "created_at" : "Tue Apr 13 03:38:37 +0000 2010",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6123202647, -122.3471383169 ]
  },
  "id_str" : "12053802112",
  "text" : "Does anyone have an extra invite to dribbble.com? Curious to check it out.",
  "id" : 12053802112,
  "created_at" : "Mon Apr 12 16:14:23 +0000 2010",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com/\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ariel Waldman",
      "screen_name" : "arielwaldman",
      "indices" : [ 0, 13 ],
      "id_str" : "814304",
      "id" : 814304
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "12029474995",
  "geo" : {
  },
  "id_str" : "12033462634",
  "in_reply_to_user_id" : 814304,
  "text" : "@arielwaldman Yeah they're simple and addictive I think. I also take a picture at 8:36pm every day... going on 700 days.",
  "id" : 12033462634,
  "in_reply_to_status_id" : 12029474995,
  "created_at" : "Mon Apr 12 06:44:37 +0000 2010",
  "in_reply_to_screen_name" : "arielwaldman",
  "in_reply_to_user_id_str" : "814304",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.612333, -122.347167 ]
  },
  "id_str" : "12027198052",
  "text" : "8:36pm Looking cross-eyed at a recipe for tonight http://flic.kr/p/7SNe6x",
  "id" : 12027198052,
  "created_at" : "Mon Apr 12 03:39:41 +0000 2010",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ariel Waldman",
      "screen_name" : "arielwaldman",
      "indices" : [ 0, 13 ],
      "id_str" : "814304",
      "id" : 814304
    }, {
      "name" : "Jane McGonigal",
      "screen_name" : "avantgame",
      "indices" : [ 46, 56 ],
      "id_str" : "681813",
      "id" : 681813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "12024871706",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.613008, -122.3476502 ]
  },
  "id_str" : "12026277991",
  "in_reply_to_user_id" : 814304,
  "text" : "@arielwaldman Hi! I found you originally thru @avantgame I think. My fun projects are http://750words.com and the Locavore iPhone app.",
  "id" : 12026277991,
  "in_reply_to_status_id" : 12024871706,
  "created_at" : "Mon Apr 12 03:19:19 +0000 2010",
  "in_reply_to_screen_name" : "arielwaldman",
  "in_reply_to_user_id_str" : "814304",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ingopixel",
      "screen_name" : "ingopixel",
      "indices" : [ 0, 10 ],
      "id_str" : "7943892",
      "id" : 7943892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6144465514, -122.346307379 ]
  },
  "id_str" : "12018021985",
  "in_reply_to_user_id" : 7943892,
  "text" : "@ingopixel How are you holding up?",
  "id" : 12018021985,
  "created_at" : "Mon Apr 12 00:23:06 +0000 2010",
  "in_reply_to_screen_name" : "ingopixel",
  "in_reply_to_user_id_str" : "7943892",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Naomi Morlan",
      "screen_name" : "naomijade",
      "indices" : [ 0, 10 ],
      "id_str" : "3157491",
      "id" : 3157491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "12016474657",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6144452677, -122.3463078233 ]
  },
  "id_str" : "12016566615",
  "in_reply_to_user_id" : 3157491,
  "text" : "@naomijade I just saw that movie recently too. It's a perfect movie.",
  "id" : 12016566615,
  "in_reply_to_status_id" : 12016474657,
  "created_at" : "Sun Apr 11 23:50:26 +0000 2010",
  "in_reply_to_screen_name" : "naomijade",
  "in_reply_to_user_id_str" : "3157491",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "12007235974",
  "text" : "As of today, I've written 750 words 100 days in a row.  I've earned my Phoenix badge.\n\nhttp://bit.ly/cgvyke",
  "id" : 12007235974,
  "created_at" : "Sun Apr 11 20:01:12 +0000 2010",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "12002937216",
  "text" : "Damn, the IRS has found more McLeod taxes that I \"forgot\" to file in 2008. I also forgot the physical reaction I get to this sucky problem.",
  "id" : 12002937216,
  "created_at" : "Sun Apr 11 18:14:31 +0000 2010",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russell Dicker",
      "screen_name" : "rdicker",
      "indices" : [ 3, 11 ],
      "id_str" : "958581",
      "id" : 958581
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "12000749273",
  "text" : "RT @rdicker: Congratulations to Seattle Heights.  No longer Belltown's largest construction f-up: http://bit.ly/dl3Tgc",
  "id" : 12000749273,
  "created_at" : "Sun Apr 11 17:22:31 +0000 2010",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Willo O'Brien",
      "screen_name" : "WilloToons",
      "indices" : [ 0, 11 ],
      "id_str" : "772386",
      "id" : 772386
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "11963487383",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.613008, -122.3476502 ]
  },
  "id_str" : "11979086125",
  "in_reply_to_user_id" : 772386,
  "text" : "@willotoons I'm glad you like it! It's still new and there are kinks to work out, but I think the general idea is pretty neat, right?",
  "id" : 11979086125,
  "in_reply_to_status_id" : 11963487383,
  "created_at" : "Sun Apr 11 06:45:50 +0000 2010",
  "in_reply_to_screen_name" : "WilloToons",
  "in_reply_to_user_id_str" : "772386",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tara Tiger Brown ",
      "screen_name" : "tara",
      "indices" : [ 0, 5 ],
      "id_str" : "10959642",
      "id" : 10959642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "11977507480",
  "geo" : {
  },
  "id_str" : "11977793573",
  "in_reply_to_user_id" : 10959642,
  "text" : "@tara Not what I was expecting, but definitely worth seeing. Tina Fey is always funny.",
  "id" : 11977793573,
  "in_reply_to_status_id" : 11977507480,
  "created_at" : "Sun Apr 11 06:05:50 +0000 2010",
  "in_reply_to_screen_name" : "tara",
  "in_reply_to_user_id_str" : "10959642",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.611333, -122.337167 ]
  },
  "id_str" : "11971909576",
  "text" : "8:36pm Just left Pink Door with friends for romantic comedy hijinx at Date Night, the movie. http://flic.kr/p/7St7k4",
  "id" : 11971909576,
  "created_at" : "Sun Apr 11 03:39:19 +0000 2010",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6124379833, -122.3382085167 ]
  },
  "id_str" : "11960631436",
  "text" : "Trying to park in the most inaccesible parking spot in dt Seattle right now. Thanks street construction and ZipCar lot on 3rd & Virginia.",
  "id" : 11960631436,
  "created_at" : "Sat Apr 10 23:14:31 +0000 2010",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.withings.com\" rel=\"nofollow\">WiTwit</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.0, -122.0 ]
  },
  "id_str" : "11943412132",
  "text" : "My weight: 174.2 lb. Weekly weigh in. http://withings.com",
  "id" : 11943412132,
  "created_at" : "Sat Apr 10 16:00:15 +0000 2010",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.612333, -122.347167 ]
  },
  "id_str" : "11918517113",
  "text" : "8:36pm Cleaning out the junk drawer. These are the last three things to figure out. &kb:cleaning@home http://flic.kr/p/7SgWVw",
  "id" : 11918517113,
  "created_at" : "Sat Apr 10 03:39:18 +0000 2010",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen K",
      "screen_name" : "TheStephenK",
      "indices" : [ 0, 12 ],
      "id_str" : "50394272",
      "id" : 50394272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "11916659773",
  "geo" : {
  },
  "id_str" : "11917511645",
  "in_reply_to_user_id" : 50394272,
  "text" : "@TheStephenK Thanks! I'm glad people are enjoying it as much as I am. Let me know if you have ideas on how to make it better!",
  "id" : 11917511645,
  "in_reply_to_status_id" : 11916659773,
  "created_at" : "Sat Apr 10 03:16:43 +0000 2010",
  "in_reply_to_screen_name" : "TheStephenK",
  "in_reply_to_user_id_str" : "50394272",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Coates",
      "screen_name" : "tomcoates",
      "indices" : [ 9, 19 ],
      "id_str" : "12514",
      "id" : 12514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "11913328647",
  "text" : "Neat! RT @tomcoates: Wow. This is a pretty gutsy move: Twitter acquires Tweetie: http://bit.ly/9GfiOV",
  "id" : 11913328647,
  "created_at" : "Sat Apr 10 01:45:41 +0000 2010",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nils Geylen",
      "screen_name" : "nilsgeylen",
      "indices" : [ 0, 11 ],
      "id_str" : "768058",
      "id" : 768058
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "11866831364",
  "geo" : {
  },
  "id_str" : "11867017878",
  "in_reply_to_user_id" : 768058,
  "text" : "@nilsgeylen Thanks. Yeah, there's definitely something there. The more heads thinking on it the better.",
  "id" : 11867017878,
  "in_reply_to_status_id" : 11866831364,
  "created_at" : "Fri Apr 09 06:16:15 +0000 2010",
  "in_reply_to_screen_name" : "nilsgeylen",
  "in_reply_to_user_id_str" : "768058",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nils Geylen",
      "screen_name" : "nilsgeylen",
      "indices" : [ 0, 11 ],
      "id_str" : "768058",
      "id" : 768058
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "11864171208",
  "geo" : {
  },
  "id_str" : "11866610493",
  "in_reply_to_user_id" : 768058,
  "text" : "@nilsgeylen I'm a fan of that site myself, and a crazy self-tracker in general. Any features in particular you think might fit 750words?",
  "id" : 11866610493,
  "in_reply_to_status_id" : 11864171208,
  "created_at" : "Fri Apr 09 06:02:51 +0000 2010",
  "in_reply_to_screen_name" : "nilsgeylen",
  "in_reply_to_user_id_str" : "768058",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.612333, -122.347167 ]
  },
  "id_str" : "11861356181",
  "text" : "8:36pm Looking at 0s and 1s was not so fun today. &0:working@home http://flic.kr/p/7S4dfN",
  "id" : 11861356181,
  "created_at" : "Fri Apr 09 03:42:16 +0000 2010",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ariel Flesler",
      "screen_name" : "flesler",
      "indices" : [ 0, 8 ],
      "id_str" : "14057318",
      "id" : 14057318
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6130331, -122.3478178 ]
  },
  "id_str" : "11847440354",
  "in_reply_to_user_id" : 14057318,
  "text" : "@flesler I've been using your jQuery.ScrollTo plugin & love it. Noticed on the iPad that it re-scrolls from the top of the page. Any ideas?",
  "id" : 11847440354,
  "created_at" : "Thu Apr 08 22:42:23 +0000 2010",
  "in_reply_to_screen_name" : "flesler",
  "in_reply_to_user_id_str" : "14057318",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "11843377172",
  "text" : "It's too bad that being grumpy doesn't cure grumpiness, because it sure feels like it will at the time.",
  "id" : 11843377172,
  "created_at" : "Thu Apr 08 21:06:19 +0000 2010",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "11837312689",
  "text" : "My favorite features from the iPhone 4.0 announcement were background location, and background photo uploading. &kb:browsing@home",
  "id" : 11837312689,
  "created_at" : "Thu Apr 08 18:35:12 +0000 2010",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "11810878942",
  "text" : "My iPad wouldn't connect to iTunes so I turned it off. Now it won't turn back on. I guess it's not really mine til I break it a few times.",
  "id" : 11810878942,
  "created_at" : "Thu Apr 08 06:51:33 +0000 2010",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.612333, -122.347167 ]
  },
  "id_str" : "11804342912",
  "text" : "8:36pm This day sorta sucked. Trying to self-medicate with brainstorming, iPad, and cat &0:browsing@home http://flic.kr/p/7RLrB2",
  "id" : 11804342912,
  "created_at" : "Thu Apr 08 03:39:44 +0000 2010",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "☮ הלל",
      "screen_name" : "hillel",
      "indices" : [ 0, 7 ],
      "id_str" : "3640341",
      "id" : 3640341
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "11789823064",
  "geo" : {
  },
  "id_str" : "11790073119",
  "in_reply_to_user_id" : 3640341,
  "text" : "@hillel Paid to learn? What are you working on?\n\nps. Congrats on the Story Before Bed app! I love it on the iPad. Just needs a video camera.",
  "id" : 11790073119,
  "in_reply_to_status_id" : 11789823064,
  "created_at" : "Wed Apr 07 22:29:27 +0000 2010",
  "in_reply_to_screen_name" : "hillel",
  "in_reply_to_user_id_str" : "3640341",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joseph Miller",
      "screen_name" : "jos3ph",
      "indices" : [ 0, 7 ],
      "id_str" : "821470",
      "id" : 821470
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "750words",
      "indices" : [ 131, 140 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "11784095119",
  "geo" : {
  },
  "id_str" : "11785133907",
  "in_reply_to_user_id" : 821470,
  "text" : "@jos3ph It's true.  Right around the 30th of March we went from 8ish albatrosses to 50.  And now a couple more are born every day. #750words",
  "id" : 11785133907,
  "in_reply_to_status_id" : 11784095119,
  "created_at" : "Wed Apr 07 20:33:27 +0000 2010",
  "in_reply_to_screen_name" : "jos3ph",
  "in_reply_to_user_id_str" : "821470",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "11783179869",
  "text" : "“I see miracles all around me\nWater, fire, air and dirt\nFucking magnets, how do they work?”\n\nWeirdest video in a while:\nhttp://bit.ly/9uGWcn",
  "id" : 11783179869,
  "created_at" : "Wed Apr 07 19:47:32 +0000 2010",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Assink",
      "screen_name" : "jonassink",
      "indices" : [ 0, 10 ],
      "id_str" : "6604252",
      "id" : 6604252
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "11743657078",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6123220216, -122.347139285 ]
  },
  "id_str" : "11763392842",
  "in_reply_to_user_id" : 6604252,
  "text" : "@jonassink That's not cheating at all. Which Wikipedia prompts did you use?",
  "id" : 11763392842,
  "in_reply_to_status_id" : 11743657078,
  "created_at" : "Wed Apr 07 16:02:24 +0000 2010",
  "in_reply_to_screen_name" : "jonassink",
  "in_reply_to_user_id_str" : "6604252",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6145, -122.346667 ]
  },
  "id_str" : "11740708775",
  "text" : "8:36pm Post birth class dinner with new friends http://flic.kr/p/7RAadm",
  "id" : 11740708775,
  "created_at" : "Wed Apr 07 05:11:46 +0000 2010",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.612, -122.343334 ]
  },
  "id_str" : "11679287315",
  "text" : "8:36pm Walking to Virginia Inn for the 2nd time today &0:walking http://flic.kr/p/7Rf1H4",
  "id" : 11679287315,
  "created_at" : "Tue Apr 06 03:45:33 +0000 2010",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.612333, -122.347167 ]
  },
  "id_str" : "11624797508",
  "text" : "8:36pm Was making a low-maintenance dinner http://flic.kr/p/7QVFeP",
  "id" : 11624797508,
  "created_at" : "Mon Apr 05 04:26:02 +0000 2010",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6131421, -122.3480155 ]
  },
  "id_str" : "11620573263",
  "text" : "I work on my days off (like today), then burn out mid-way thru next week. I think my work week is 10 days. And my Circadian rhythm ~30 hrs.",
  "id" : 11620573263,
  "created_at" : "Mon Apr 05 02:48:59 +0000 2010",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "harryh",
      "screen_name" : "harryh",
      "indices" : [ 0, 7 ],
      "id_str" : "4558",
      "id" : 4558
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "11609397071",
  "geo" : {
  },
  "id_str" : "11609446395",
  "in_reply_to_user_id" : 4558,
  "text" : "@harryh I would personally love it, but I can see why it might not be a top priority.  Thanks!",
  "id" : 11609446395,
  "in_reply_to_status_id" : 11609397071,
  "created_at" : "Sun Apr 04 22:41:46 +0000 2010",
  "in_reply_to_screen_name" : "harryh",
  "in_reply_to_user_id_str" : "4558",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "harryh",
      "screen_name" : "harryh",
      "indices" : [ 0, 7 ],
      "id_str" : "4558",
      "id" : 4558
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "11609213199",
  "geo" : {
  },
  "id_str" : "11609324464",
  "in_reply_to_user_id" : 4558,
  "text" : "@harryh Okay, I can do that.  Any plans on making it a method of its own?  Would be cool to go back in time and backfill it...",
  "id" : 11609324464,
  "in_reply_to_status_id" : 11609213199,
  "created_at" : "Sun Apr 04 22:38:37 +0000 2010",
  "in_reply_to_screen_name" : "harryh",
  "in_reply_to_user_id_str" : "4558",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Foursquare",
      "screen_name" : "foursquare",
      "indices" : [ 0, 11 ],
      "id_str" : "14120151",
      "id" : 14120151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "11609132414",
  "in_reply_to_user_id" : 14120151,
  "text" : "@foursquare Does your API currently allow one to easily find out which of your friends are currently at the same venue as you?",
  "id" : 11609132414,
  "created_at" : "Sun Apr 04 22:33:38 +0000 2010",
  "in_reply_to_screen_name" : "foursquare",
  "in_reply_to_user_id_str" : "14120151",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.612333, -122.347167 ]
  },
  "id_str" : "11568646148",
  "text" : "8:36pm Doing something NOT on my iPad for a change, ie. Kellianne's turn. http://flic.kr/p/7QE8Dm",
  "id" : 11568646148,
  "created_at" : "Sun Apr 04 03:39:23 +0000 2010",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ʎǝʞɔıɥ ʇʇɐɯ",
      "screen_name" : "matthickey",
      "indices" : [ 0, 11 ],
      "id_str" : "8710082",
      "id" : 8710082
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "11565369335",
  "geo" : {
  },
  "id_str" : "11566149218",
  "in_reply_to_user_id" : 8710082,
  "text" : "@matthickey Still digging iBooks, but also liking Words With Friends, NPR, Epicurious, Adobe Ideas, Game Table, Netflix, Gilt, and ABC. You?",
  "id" : 11566149218,
  "in_reply_to_status_id" : 11565369335,
  "created_at" : "Sun Apr 04 02:44:24 +0000 2010",
  "in_reply_to_screen_name" : "matthickey",
  "in_reply_to_user_id_str" : "8710082",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitterrific.com\" rel=\"nofollow\">Twitterrific</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "11559724807",
  "text" : "Best thing about the iPad so far: being able to play with the edges of pages while reading. Didn't realize how much I do that.",
  "id" : 11559724807,
  "created_at" : "Sun Apr 04 00:10:16 +0000 2010",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "11542603038",
  "text" : "35 weeks! 5 more weeks til Baby Benson! iPad is in Seattle, awaiting delivery! The sun just came out! I have a giant coffee! Let's go!",
  "id" : 11542603038,
  "created_at" : "Sat Apr 03 16:38:44 +0000 2010",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.withings.com\" rel=\"nofollow\">WiTwit</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.0, -122.0 ]
  },
  "id_str" : "11540829433",
  "text" : "My weight: 174.2 lb. Weekly weigh in. http://withings.com",
  "id" : 11540829433,
  "created_at" : "Sat Apr 03 16:00:22 +0000 2010",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://dev.twitter.com/\" rel=\"nofollow\">API</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David",
      "screen_name" : "randomcuriosity",
      "indices" : [ 3, 19 ],
      "id_str" : "1306921",
      "id" : 1306921
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "11525956282",
  "text" : "RT @randomcuriosity: You aren't awesome until you have a horse badge from 750 Words saying so... http://flic.kr/p/7QnDZH",
  "retweeted_status" : {
    "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "11521820778",
    "text" : "You aren't awesome until you have a horse badge from 750 Words saying so... http://flic.kr/p/7QnDZH",
    "id" : 11521820778,
    "created_at" : "Sat Apr 03 06:04:39 +0000 2010",
    "user" : {
      "name" : "David",
      "screen_name" : "randomcuriosity",
      "protected" : false,
      "id_str" : "1306921",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1759218968/david_drawn_20100214_normal.jpg",
      "id" : 1306921,
      "verified" : false
    }
  },
  "id" : 11525956282,
  "created_at" : "Sat Apr 03 08:28:51 +0000 2010",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Lane",
      "screen_name" : "futileboy",
      "indices" : [ 0, 10 ],
      "id_str" : "4132781",
      "id" : 4132781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "11520381413",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6123203029, -122.3471379302 ]
  },
  "id_str" : "11521022957",
  "in_reply_to_user_id" : 4132781,
  "text" : "@futileboy I balked at OmniGraffle. You win!",
  "id" : 11521022957,
  "in_reply_to_status_id" : 11520381413,
  "created_at" : "Sat Apr 03 05:41:09 +0000 2010",
  "in_reply_to_screen_name" : "futileboy",
  "in_reply_to_user_id_str" : "4132781",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Lane",
      "screen_name" : "futileboy",
      "indices" : [ 0, 10 ],
      "id_str" : "4132781",
      "id" : 4132781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "11519972352",
  "geo" : {
  },
  "id_str" : "11520238202",
  "in_reply_to_user_id" : 4132781,
  "text" : "@futileboy You've met your match, I guess.",
  "id" : 11520238202,
  "in_reply_to_status_id" : 11519972352,
  "created_at" : "Sat Apr 03 05:19:08 +0000 2010",
  "in_reply_to_screen_name" : "futileboy",
  "in_reply_to_user_id_str" : "4132781",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "11519870755",
  "text" : "Hm, looks like I can download iPad apps even though my iPad is still somewhere over the ocean. Hm, looks like I got about 20 of 'em already!",
  "id" : 11519870755,
  "created_at" : "Sat Apr 03 05:09:10 +0000 2010",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rebecca Leaman",
      "screen_name" : "rjleaman",
      "indices" : [ 3, 12 ],
      "id_str" : "9970122",
      "id" : 9970122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "11508269560",
  "text" : "RT @rjleaman: Another reason to like 750words.com (private online writing space): First donation to 826Seattle.org http://bit.ly/cf3THn",
  "retweeted_status" : {
    "source" : "<a href=\"http://bit.ly\" rel=\"nofollow\">bit.ly</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "11477863133",
    "text" : "Another reason to like 750words.com (private online writing space): First donation to 826Seattle.org http://bit.ly/cf3THn",
    "id" : 11477863133,
    "created_at" : "Fri Apr 02 12:29:11 +0000 2010",
    "user" : {
      "name" : "Rebecca Leaman",
      "screen_name" : "rjleaman",
      "protected" : false,
      "id_str" : "9970122",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1165169399/rebecca_leaman_normal.jpg",
      "id" : 9970122,
      "verified" : false
    }
  },
  "id" : 11508269560,
  "created_at" : "Sat Apr 03 00:33:06 +0000 2010",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Croft",
      "screen_name" : "jcroft",
      "indices" : [ 0, 7 ],
      "id_str" : "25993",
      "id" : 25993
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "11504027546",
  "geo" : {
  },
  "id_str" : "11504198223",
  "in_reply_to_user_id" : 25993,
  "text" : "@jcroft Ooh, cool!  I gotta get that, if only to see one version of the ideas.  Thanks!",
  "id" : 11504198223,
  "in_reply_to_status_id" : 11504027546,
  "created_at" : "Fri Apr 02 22:46:41 +0000 2010",
  "in_reply_to_screen_name" : "jcroft",
  "in_reply_to_user_id_str" : "25993",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kaydria",
      "screen_name" : "Kaydria",
      "indices" : [ 0, 8 ],
      "id_str" : "17801821",
      "id" : 17801821
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "11493433543",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6142222, -122.3453599 ]
  },
  "id_str" : "11501761888",
  "in_reply_to_user_id" : 17801821,
  "text" : "@kaydria What kind of trouble are you having?  Can I help?",
  "id" : 11501761888,
  "in_reply_to_status_id" : 11493433543,
  "created_at" : "Fri Apr 02 21:40:10 +0000 2010",
  "in_reply_to_screen_name" : "Kaydria",
  "in_reply_to_user_id_str" : "17801821",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carinna Tarvin",
      "screen_name" : "carinnatarvin",
      "indices" : [ 0, 14 ],
      "id_str" : "20833838",
      "id" : 20833838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "11495469089",
  "geo" : {
  },
  "id_str" : "11495714640",
  "in_reply_to_user_id" : 20833838,
  "text" : "@carinnatarvin I want to go in a helicopter!  What are the details?",
  "id" : 11495714640,
  "in_reply_to_status_id" : 11495469089,
  "created_at" : "Fri Apr 02 19:00:34 +0000 2010",
  "in_reply_to_screen_name" : "carinnatarvin",
  "in_reply_to_user_id_str" : "20833838",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6123224775, -122.3471396041 ]
  },
  "id_str" : "11489359096",
  "text" : "You know what the opposite is of being really not excited about something? Normal.",
  "id" : 11489359096,
  "created_at" : "Fri Apr 02 16:39:50 +0000 2010",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6123306608, -122.3471428955 ]
  },
  "id_str" : "11488765787",
  "text" : "The degree of your polarization on any issue should be directly proportional to how much it really matters. And whether or not you're right.",
  "id" : 11488765787,
  "created_at" : "Fri Apr 02 16:27:47 +0000 2010",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Biznik, Inc",
      "screen_name" : "bizniktweets",
      "indices" : [ 0, 13 ],
      "id_str" : "170868595",
      "id" : 170868595
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "11483869983",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.612327036, -122.3471426261 ]
  },
  "id_str" : "11487715090",
  "in_reply_to_user_id" : 125456727,
  "text" : "@BiznikTweets What's up with all the welcoming tweets? Can you limit auto tweets per day?",
  "id" : 11487715090,
  "in_reply_to_status_id" : 11483869983,
  "created_at" : "Fri Apr 02 16:06:39 +0000 2010",
  "in_reply_to_screen_name" : "Biznik",
  "in_reply_to_user_id_str" : "125456727",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.614166, -122.345334 ]
  },
  "id_str" : "11461316814",
  "text" : "8:36pm Bedlam is bumpin' as I fiddle with work stuff http://flic.kr/p/7QbAQN",
  "id" : 11461316814,
  "created_at" : "Fri Apr 02 03:41:20 +0000 2010",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "deepthoughts",
      "indices" : [ 111, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "11448627196",
  "text" : "The only thing that really focuses me is being productive. But I can only be productive if I can focus myself. #deepthoughts",
  "id" : 11448627196,
  "created_at" : "Thu Apr 01 22:49:36 +0000 2010",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "11443992237",
  "text" : "Really enjoyed giving 14.3% of 750words.com's March patronage to http://826seattle.org - a nonprofit writing center for kids",
  "id" : 11443992237,
  "created_at" : "Thu Apr 01 20:48:56 +0000 2010",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Goldberg",
      "screen_name" : "bostonsteamer",
      "indices" : [ 0, 14 ],
      "id_str" : "2029651",
      "id" : 2029651
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "11427305129",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6123239465, -122.3471384494 ]
  },
  "id_str" : "11435130274",
  "in_reply_to_user_id" : 2029651,
  "text" : "@bostonsteamer Congrats! That's awesome news!",
  "id" : 11435130274,
  "in_reply_to_status_id" : 11427305129,
  "created_at" : "Thu Apr 01 17:15:46 +0000 2010",
  "in_reply_to_screen_name" : "bostonsteamer",
  "in_reply_to_user_id_str" : "2029651",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.612333, -122.347167 ]
  },
  "id_str" : "11434578697",
  "text" : "The pram arrived. Yup. http://flic.kr/p/7Q1XDc",
  "id" : 11434578697,
  "created_at" : "Thu Apr 01 17:03:27 +0000 2010",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
} ]