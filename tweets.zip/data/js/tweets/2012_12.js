Grailbird.data.tweets_2012_12 = 
[ {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fred Wilson",
      "screen_name" : "fredwilson",
      "indices" : [ 3, 14 ],
      "id_str" : "1000591",
      "id" : 1000591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 50 ],
      "url" : "http://t.co/XdCj4dCF",
      "expanded_url" : "http://www.avc.com/a_vc/2012/12/demand-a-plan.html",
      "display_url" : "avc.com/a_vc/2012/12/d…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "281444566387810305",
  "text" : "RT @fredwilson: Demand A Plan http://t.co/XdCj4dCF",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 14, 34 ],
        "url" : "http://t.co/XdCj4dCF",
        "expanded_url" : "http://www.avc.com/a_vc/2012/12/demand-a-plan.html",
        "display_url" : "avc.com/a_vc/2012/12/d…"
      } ]
    },
    "geo" : {
    },
    "id_str" : "281440853728313344",
    "text" : "Demand A Plan http://t.co/XdCj4dCF",
    "id" : 281440853728313344,
    "created_at" : "Wed Dec 19 16:48:23 +0000 2012",
    "user" : {
      "name" : "Fred Wilson",
      "screen_name" : "fredwilson",
      "protected" : false,
      "id_str" : "1000591",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2994496709/5213943fab4e42dd7b76f14bccaddb5c_normal.png",
      "id" : 1000591,
      "verified" : true
    }
  },
  "id" : 281444566387810305,
  "created_at" : "Wed Dec 19 17:03:08 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Doug Bowman",
      "screen_name" : "stop",
      "indices" : [ 3, 8 ],
      "id_str" : "949521",
      "id" : 949521
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http://t.co/K2BoVEeZ",
      "expanded_url" : "http://stopdesign.com/tweets/",
      "display_url" : "stopdesign.com/tweets/"
    } ]
  },
  "geo" : {
  },
  "id_str" : "281440044571582465",
  "text" : "RT @stop: Here's an example of the data and interactive display you get to download from Twitter as your tweet archive: http://t.co/K2BoVEeZ",
  "retweeted_status" : {
    "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 110, 130 ],
        "url" : "http://t.co/K2BoVEeZ",
        "expanded_url" : "http://stopdesign.com/tweets/",
        "display_url" : "stopdesign.com/tweets/"
      } ]
    },
    "geo" : {
    },
    "id_str" : "281439776014467073",
    "text" : "Here's an example of the data and interactive display you get to download from Twitter as your tweet archive: http://t.co/K2BoVEeZ",
    "id" : 281439776014467073,
    "created_at" : "Wed Dec 19 16:44:06 +0000 2012",
    "user" : {
      "name" : "Doug Bowman",
      "screen_name" : "stop",
      "protected" : false,
      "id_str" : "949521",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/552708586/doug-profile_normal.jpg",
      "id" : 949521,
      "verified" : false
    }
  },
  "id" : 281440044571582465,
  "created_at" : "Wed Dec 19 16:45:10 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ali Berman",
      "screen_name" : "spangley",
      "indices" : [ 0, 9 ],
      "id_str" : "776429",
      "id" : 776429
    }, {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 10, 20 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 68 ],
      "url" : "https://t.co/1U7nqO0o",
      "expanded_url" : "https://mobile.twitter.com/kellianne/tweets",
      "display_url" : "mobile.twitter.com/kellianne/twee…"
    } ]
  },
  "in_reply_to_status_id_str" : "281425417125101569",
  "geo" : {
  },
  "id_str" : "281426324810235908",
  "in_reply_to_user_id" : 776429,
  "text" : "@spangley @kellianne Oops. Try this link then: https://t.co/1U7nqO0o (Ali is that a known bug?)",
  "id" : 281426324810235908,
  "in_reply_to_status_id" : 281425417125101569,
  "created_at" : "Wed Dec 19 15:50:39 +0000 2012",
  "in_reply_to_screen_name" : "spangley",
  "in_reply_to_user_id_str" : "776429",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 107 ],
      "url" : "http://t.co/O5fVLo6z",
      "expanded_url" : "http://blog.twitter.com/2012/12/your-twitter-archive.html?m=1",
      "display_url" : "blog.twitter.com/2012/12/your-t…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "281422972290478080",
  "text" : "Look! You can now download, search, explore all of your tweets on your own computater! http://t.co/O5fVLo6z",
  "id" : 281422972290478080,
  "created_at" : "Wed Dec 19 15:37:19 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Bragger",
      "screen_name" : "kylebragger",
      "indices" : [ 26, 38 ],
      "id_str" : "2039761",
      "id" : 2039761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 91 ],
      "url" : "http://t.co/bgkAx5AQ",
      "expanded_url" : "http://www.theverge.com/2012/12/19/3783616/animate-your-memes-with-vimeo-creators-new-project-moonbase",
      "display_url" : "theverge.com/2012/12/19/378…"
    }, {
      "indices" : [ 109, 129 ],
      "url" : "http://t.co/QRnB760F",
      "expanded_url" : "http://moonbase.com/",
      "display_url" : "moonbase.com"
    } ]
  },
  "geo" : {
  },
  "id_str" : "281420884084932608",
  "text" : "This looks really fun. RT @kylebragger: Happy to be involved in this : http://t.co/bgkAx5AQ (Go have a play! http://t.co/QRnB760F)",
  "id" : 281420884084932608,
  "created_at" : "Wed Dec 19 15:29:01 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Greg Sargent",
      "screen_name" : "ThePlumLineGS",
      "indices" : [ 3, 17 ],
      "id_str" : "20508720",
      "id" : 20508720
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 125 ],
      "url" : "http://t.co/TF0uvbjW",
      "expanded_url" : "http://wapo.st/T76XeW",
      "display_url" : "wapo.st/T76XeW"
    } ]
  },
  "geo" : {
  },
  "id_str" : "281413680384581634",
  "text" : "RT @ThePlumLineGS: Boehner's million-dollar-maneuver doesn't give the GOP a way out. In Morning Roundup: http://t.co/TF0uvbjW",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 86, 106 ],
        "url" : "http://t.co/TF0uvbjW",
        "expanded_url" : "http://wapo.st/T76XeW",
        "display_url" : "wapo.st/T76XeW"
      } ]
    },
    "geo" : {
    },
    "id_str" : "281404386834542593",
    "text" : "Boehner's million-dollar-maneuver doesn't give the GOP a way out. In Morning Roundup: http://t.co/TF0uvbjW",
    "id" : 281404386834542593,
    "created_at" : "Wed Dec 19 14:23:28 +0000 2012",
    "user" : {
      "name" : "Greg Sargent",
      "screen_name" : "ThePlumLineGS",
      "protected" : false,
      "id_str" : "20508720",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/77712921/greg_spic_normal.jpg",
      "id" : 20508720,
      "verified" : false
    }
  },
  "id" : 281413680384581634,
  "created_at" : "Wed Dec 19 15:00:24 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 0, 10 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "281294366058897408",
  "geo" : {
  },
  "id_str" : "281295416836890624",
  "in_reply_to_user_id" : 7362142,
  "text" : "@kellianne You can un-retweet. Hit the retweet thing again.",
  "id" : 281295416836890624,
  "in_reply_to_status_id" : 281294366058897408,
  "created_at" : "Wed Dec 19 07:10:28 +0000 2012",
  "in_reply_to_screen_name" : "kellianne",
  "in_reply_to_user_id_str" : "7362142",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "news.yc Popular",
      "screen_name" : "newsycombinator",
      "indices" : [ 49, 65 ],
      "id_str" : "14335498",
      "id" : 14335498
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 108 ],
      "url" : "http://t.co/FnGCf3FY",
      "expanded_url" : "http://j.mp/V4AALl",
      "display_url" : "j.mp/V4AALl"
    } ]
  },
  "geo" : {
  },
  "id_str" : "281266445374070784",
  "text" : "Super interesting, but maybe not to everyone. RT @newsycombinator: How do we read code? http://t.co/FnGCf3FY",
  "id" : 281266445374070784,
  "created_at" : "Wed Dec 19 05:15:20 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Freedom Spice",
      "screen_name" : "imtboo",
      "indices" : [ 0, 7 ],
      "id_str" : "1037851",
      "id" : 1037851
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "281263884864737280",
  "geo" : {
  },
  "id_str" : "281264578745233408",
  "in_reply_to_user_id" : 1037851,
  "text" : "@imtboo Nah. But I've been using Flickr too all along and may stick with them more often than before.",
  "id" : 281264578745233408,
  "in_reply_to_status_id" : 281263884864737280,
  "created_at" : "Wed Dec 19 05:07:55 +0000 2012",
  "in_reply_to_screen_name" : "imtboo",
  "in_reply_to_user_id_str" : "1037851",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "281262785457971200",
  "text" : "Who's written the best stuff on our increasing capacity for online rage recently?",
  "id" : 281262785457971200,
  "created_at" : "Wed Dec 19 05:00:48 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 41 ],
      "url" : "http://t.co/QSAuL0Kk",
      "expanded_url" : "http://flic.kr/p/dCbDNe",
      "display_url" : "flic.kr/p/dCbDNe"
    } ]
  },
  "geo" : {
  },
  "id_str" : "281261279048511488",
  "text" : "8:36pm In a bathroom http://t.co/QSAuL0Kk",
  "id" : 281261279048511488,
  "created_at" : "Wed Dec 19 04:54:49 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "'alex' groans ",
      "screen_name" : "dreadhole",
      "indices" : [ 3, 13 ],
      "id_str" : "140251842",
      "id" : 140251842
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "281254999332384768",
  "text" : "RT @dreadhole: if you've never spoken 'computer, end program' out loud theres still a chance your whole life has been a holodeck simulation",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "177829056178429952",
    "text" : "if you've never spoken 'computer, end program' out loud theres still a chance your whole life has been a holodeck simulation",
    "id" : 177829056178429952,
    "created_at" : "Thu Mar 08 18:52:05 +0000 2012",
    "user" : {
      "name" : "'alex' groans ",
      "screen_name" : "dreadhole",
      "protected" : false,
      "id_str" : "140251842",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2468714131/oyeg7fpjjmnbsbjven9j_normal.png",
      "id" : 140251842,
      "verified" : false
    }
  },
  "id" : 281254999332384768,
  "created_at" : "Wed Dec 19 04:29:51 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Jacobs",
      "screen_name" : "djacobs",
      "indices" : [ 0, 8 ],
      "id_str" : "774842",
      "id" : 774842
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "281173809170624512",
  "geo" : {
  },
  "id_str" : "281244094565593088",
  "in_reply_to_user_id" : 774842,
  "text" : "@djacobs Buurn.",
  "id" : 281244094565593088,
  "in_reply_to_status_id" : 281173809170624512,
  "created_at" : "Wed Dec 19 03:46:32 +0000 2012",
  "in_reply_to_screen_name" : "djacobs",
  "in_reply_to_user_id_str" : "774842",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://favstar.fm\" rel=\"nofollow\">Favstar.FM</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LeVar Burzum",
      "screen_name" : "weedhitler",
      "indices" : [ 3, 14 ],
      "id_str" : "125386940",
      "id" : 125386940
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "281243728881012736",
  "text" : "RT @weedhitler: 2 New Interaction(s): A PACK OF WOLVES favorited your tweet \"damn, feeling hella vulnerable today\".\nA PACK OF WOLVES sta ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "195259379841384450",
    "text" : "2 New Interaction(s): A PACK OF WOLVES favorited your tweet \"damn, feeling hella vulnerable today\".\nA PACK OF WOLVES started following you.",
    "id" : 195259379841384450,
    "created_at" : "Wed Apr 25 21:13:58 +0000 2012",
    "user" : {
      "name" : "LeVar Burzum",
      "screen_name" : "weedhitler",
      "protected" : false,
      "id_str" : "125386940",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2073506598/oreyhrf_normal.gif",
      "id" : 125386940,
      "verified" : false
    }
  },
  "id" : 281243728881012736,
  "created_at" : "Wed Dec 19 03:45:04 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "281238591269662720",
  "text" : "Looks like everyone's getting their Teslas.",
  "id" : 281238591269662720,
  "created_at" : "Wed Dec 19 03:24:39 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "iiano",
      "screen_name" : "iano",
      "indices" : [ 0, 5 ],
      "id_str" : "14409856",
      "id" : 14409856
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "281214633178718208",
  "geo" : {
  },
  "id_str" : "281214940759613440",
  "in_reply_to_user_id" : 14409856,
  "text" : "@iano I totally borrowed your illustrator for my twitter profile.",
  "id" : 281214940759613440,
  "in_reply_to_status_id" : 281214633178718208,
  "created_at" : "Wed Dec 19 01:50:41 +0000 2012",
  "in_reply_to_screen_name" : "iano",
  "in_reply_to_user_id_str" : "14409856",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ingopixel",
      "screen_name" : "ingopixel",
      "indices" : [ 0, 10 ],
      "id_str" : "7943892",
      "id" : 7943892
    }, {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 123, 133 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "281178991002521600",
  "geo" : {
  },
  "id_str" : "281181999782305792",
  "in_reply_to_user_id" : 7943892,
  "text" : "@ingopixel Hm… actually, this obsession began right around the time that I explained that squirrel worked in the tree with @kellianne.",
  "id" : 281181999782305792,
  "in_reply_to_status_id" : 281178991002521600,
  "created_at" : "Tue Dec 18 23:39:47 +0000 2012",
  "in_reply_to_screen_name" : "ingopixel",
  "in_reply_to_user_id_str" : "7943892",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gina Trapani",
      "screen_name" : "ginatrapani",
      "indices" : [ 0, 12 ],
      "id_str" : "930061",
      "id" : 930061
    }, {
      "name" : "Branch",
      "screen_name" : "branch",
      "indices" : [ 120, 127 ],
      "id_str" : "494518813",
      "id" : 494518813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "281174169981431808",
  "geo" : {
  },
  "id_str" : "281174453944209408",
  "in_reply_to_user_id" : 930061,
  "text" : "@ginatrapani Ah. Yeah. I have lots of ideas and have experimented with it a bit too. Definitely let's start an email or @branch thread.",
  "id" : 281174453944209408,
  "in_reply_to_status_id" : 281174169981431808,
  "created_at" : "Tue Dec 18 23:09:48 +0000 2012",
  "in_reply_to_screen_name" : "ginatrapani",
  "in_reply_to_user_id_str" : "930061",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gina Trapani",
      "screen_name" : "ginatrapani",
      "indices" : [ 0, 12 ],
      "id_str" : "930061",
      "id" : 930061
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "281172618852327424",
  "geo" : {
  },
  "id_str" : "281173443850936320",
  "in_reply_to_user_id" : 930061,
  "text" : "@ginatrapani I would love to help! Can you explain that idea a bit more? What do you want to encourage?",
  "id" : 281173443850936320,
  "in_reply_to_status_id" : 281172618852327424,
  "created_at" : "Tue Dec 18 23:05:47 +0000 2012",
  "in_reply_to_screen_name" : "ginatrapani",
  "in_reply_to_user_id_str" : "930061",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gina Trapani",
      "screen_name" : "ginatrapani",
      "indices" : [ 0, 12 ],
      "id_str" : "930061",
      "id" : 930061
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "281170714256633857",
  "geo" : {
  },
  "id_str" : "281171717395730432",
  "in_reply_to_user_id" : 930061,
  "text" : "@ginatrapani Ooh, that looks really cool! When are you releasing it?",
  "id" : 281171717395730432,
  "in_reply_to_status_id" : 281170714256633857,
  "created_at" : "Tue Dec 18 22:58:56 +0000 2012",
  "in_reply_to_screen_name" : "ginatrapani",
  "in_reply_to_user_id_str" : "930061",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Sarver",
      "screen_name" : "rsarver",
      "indices" : [ 12, 20 ],
      "id_str" : "795649",
      "id" : 795649
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "281097806314360832",
  "text" : "Inspired by @rsarver just now to think bigger. Think bigger!",
  "id" : 281097806314360832,
  "created_at" : "Tue Dec 18 18:05:14 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Guillebeau",
      "screen_name" : "chrisguillebeau",
      "indices" : [ 3, 19 ],
      "id_str" : "10373972",
      "id" : 10373972
    }, {
      "name" : "Nate St. Pierre",
      "screen_name" : "NateStPierre",
      "indices" : [ 63, 76 ],
      "id_str" : "29631095",
      "id" : 29631095
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 100 ],
      "url" : "http://t.co/xPSD7lwj",
      "expanded_url" : "http://aonc.co/ZJNwhw",
      "display_url" : "aonc.co/ZJNwhw"
    } ]
  },
  "geo" : {
  },
  "id_str" : "281085148269801473",
  "text" : "RT @chrisguillebeau: An experiment in personal connection from @natestpierre -- http://t.co/xPSD7lwj",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nate St. Pierre",
        "screen_name" : "NateStPierre",
        "indices" : [ 42, 55 ],
        "id_str" : "29631095",
        "id" : 29631095
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 59, 79 ],
        "url" : "http://t.co/xPSD7lwj",
        "expanded_url" : "http://aonc.co/ZJNwhw",
        "display_url" : "aonc.co/ZJNwhw"
      } ]
    },
    "geo" : {
    },
    "id_str" : "281084143289368576",
    "text" : "An experiment in personal connection from @natestpierre -- http://t.co/xPSD7lwj",
    "id" : 281084143289368576,
    "created_at" : "Tue Dec 18 17:10:56 +0000 2012",
    "user" : {
      "name" : "Chris Guillebeau",
      "screen_name" : "chrisguillebeau",
      "protected" : false,
      "id_str" : "10373972",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1443325474/chris_normal.jpg",
      "id" : 10373972,
      "verified" : true
    }
  },
  "id" : 281085148269801473,
  "created_at" : "Tue Dec 18 17:14:56 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nate Silver",
      "screen_name" : "fivethirtyeight",
      "indices" : [ 3, 19 ],
      "id_str" : "16017475",
      "id" : 16017475
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 109 ],
      "url" : "http://t.co/n4drHdpB",
      "expanded_url" : "http://nyti.ms/ZGXPCN",
      "display_url" : "nyti.ms/ZGXPCN"
    } ]
  },
  "geo" : {
  },
  "id_str" : "281084687592595456",
  "text" : "RT @fivethirtyeight: [new article] In Gun Ownership Statistics, Partisan Divide Is Sharp http://t.co/n4drHdpB",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitterfeed.com\" rel=\"nofollow\">twitterfeed</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 68, 88 ],
        "url" : "http://t.co/n4drHdpB",
        "expanded_url" : "http://nyti.ms/ZGXPCN",
        "display_url" : "nyti.ms/ZGXPCN"
      } ]
    },
    "geo" : {
    },
    "id_str" : "280912356572291072",
    "text" : "[new article] In Gun Ownership Statistics, Partisan Divide Is Sharp http://t.co/n4drHdpB",
    "id" : 280912356572291072,
    "created_at" : "Tue Dec 18 05:48:19 +0000 2012",
    "user" : {
      "name" : "Nate Silver",
      "screen_name" : "fivethirtyeight",
      "protected" : false,
      "id_str" : "16017475",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1110592135/fivethirtyeight73_twitter_normal.png",
      "id" : 16017475,
      "verified" : true
    }
  },
  "id" : 281084687592595456,
  "created_at" : "Tue Dec 18 17:13:06 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GeekWire",
      "screen_name" : "geekwire",
      "indices" : [ 64, 73 ],
      "id_str" : "255784266",
      "id" : 255784266
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 130 ],
      "url" : "http://t.co/KvSUetiH",
      "expanded_url" : "http://goo.gl/fb/Io31k",
      "display_url" : "goo.gl/fb/Io31k"
    } ]
  },
  "geo" : {
  },
  "id_str" : "281082370122203136",
  "text" : "I like my Twitter news delivered by my home town publication RT @geekwire: Twitter reaches 200M monthly users http://t.co/KvSUetiH",
  "id" : 281082370122203136,
  "created_at" : "Tue Dec 18 17:03:53 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sara Mauskopf",
      "screen_name" : "sm",
      "indices" : [ 0, 3 ],
      "id_str" : "22273667",
      "id" : 22273667
    }, {
      "name" : "erin moore",
      "screen_name" : "emoore",
      "indices" : [ 4, 11 ],
      "id_str" : "23640904",
      "id" : 23640904
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "280924004087390208",
  "geo" : {
  },
  "id_str" : "281081077383168000",
  "in_reply_to_user_id" : 22273667,
  "text" : "@sm @emoore Yes, you should!",
  "id" : 281081077383168000,
  "in_reply_to_status_id" : 280924004087390208,
  "created_at" : "Tue Dec 18 16:58:45 +0000 2012",
  "in_reply_to_screen_name" : "sm",
  "in_reply_to_user_id_str" : "22273667",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helen Jane",
      "screen_name" : "helenjane",
      "indices" : [ 0, 10 ],
      "id_str" : "798542",
      "id" : 798542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "280911501928321024",
  "geo" : {
  },
  "id_str" : "280917387216302080",
  "in_reply_to_user_id" : 798542,
  "text" : "@helenjane My imaginary friends speak highly of you as well!",
  "id" : 280917387216302080,
  "in_reply_to_status_id" : 280911501928321024,
  "created_at" : "Tue Dec 18 06:08:18 +0000 2012",
  "in_reply_to_screen_name" : "helenjane",
  "in_reply_to_user_id_str" : "798542",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "erin moore",
      "screen_name" : "emoore",
      "indices" : [ 0, 7 ],
      "id_str" : "23640904",
      "id" : 23640904
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "280910648446185472",
  "geo" : {
  },
  "id_str" : "280916434475958275",
  "in_reply_to_user_id" : 23640904,
  "text" : "@emoore It might be the imaginary drinks speaking but that sounds like a grand plan.",
  "id" : 280916434475958275,
  "in_reply_to_status_id" : 280910648446185472,
  "created_at" : "Tue Dec 18 06:04:31 +0000 2012",
  "in_reply_to_screen_name" : "emoore",
  "in_reply_to_user_id_str" : "23640904",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 129 ],
      "url" : "http://t.co/5ZmIG1MD",
      "expanded_url" : "http://flic.kr/p/dBZhEE",
      "display_url" : "flic.kr/p/dBZhEE"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.778166, -122.4145 ]
  },
  "id_str" : "280899727074144257",
  "text" : "8:36pm Switched rooms because internet was broken. Gonna have a party with my invisible friends (and drinks) http://t.co/5ZmIG1MD",
  "id" : 280899727074144257,
  "created_at" : "Tue Dec 18 04:58:08 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "William Morgan",
      "screen_name" : "wm",
      "indices" : [ 0, 3 ],
      "id_str" : "15504330",
      "id" : 15504330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "280870462362382340",
  "geo" : {
  },
  "id_str" : "280875870552485888",
  "in_reply_to_user_id" : 15504330,
  "text" : "@wm They stripped your @. What did you do to upset them?",
  "id" : 280875870552485888,
  "in_reply_to_status_id" : 280870462362382340,
  "created_at" : "Tue Dec 18 03:23:20 +0000 2012",
  "in_reply_to_screen_name" : "wm",
  "in_reply_to_user_id_str" : "15504330",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagr.am\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jointheflock",
      "indices" : [ 13, 26 ]
    } ],
    "urls" : [ {
      "indices" : [ 43, 63 ],
      "url" : "http://t.co/CLJzxYWv",
      "expanded_url" : "http://instagr.am/p/TXJONeo0Js/",
      "display_url" : "instagr.am/p/TXJONeo0Js/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7769130279, -122.41674326 ]
  },
  "id_str" : "280866841046441984",
  "text" : "My boss, wm. #jointheflock @ Twitter, Inc. http://t.co/CLJzxYWv",
  "id" : 280866841046441984,
  "created_at" : "Tue Dec 18 02:47:27 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Greg Ricks",
      "screen_name" : "Greg_Ricks",
      "indices" : [ 0, 11 ],
      "id_str" : "13268852",
      "id" : 13268852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 77 ],
      "url" : "http://t.co/EsxNT7tx",
      "expanded_url" : "http://bit.ly/WjOQTK",
      "display_url" : "bit.ly/WjOQTK"
    } ]
  },
  "in_reply_to_status_id_str" : "280776202157969408",
  "geo" : {
  },
  "id_str" : "280777141912735745",
  "in_reply_to_user_id" : 13268852,
  "text" : "@Greg_Ricks I just connect directly to Gmail's IMAP API. http://t.co/EsxNT7tx",
  "id" : 280777141912735745,
  "in_reply_to_status_id" : 280776202157969408,
  "created_at" : "Mon Dec 17 20:51:01 +0000 2012",
  "in_reply_to_screen_name" : "Greg_Ricks",
  "in_reply_to_user_id_str" : "13268852",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carinna Tarvin",
      "screen_name" : "carinnatarvin",
      "indices" : [ 0, 14 ],
      "id_str" : "20833838",
      "id" : 20833838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "280775751907827713",
  "geo" : {
  },
  "id_str" : "280776012755775488",
  "in_reply_to_user_id" : 20833838,
  "text" : "@carinnatarvin Ai ai ai.",
  "id" : 280776012755775488,
  "in_reply_to_status_id" : 280775751907827713,
  "created_at" : "Mon Dec 17 20:46:32 +0000 2012",
  "in_reply_to_screen_name" : "carinnatarvin",
  "in_reply_to_user_id_str" : "20833838",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katie Jacobs Stanton",
      "screen_name" : "KatieS",
      "indices" : [ 3, 10 ],
      "id_str" : "94143715",
      "id" : 94143715
    }, {
      "name" : "The White House",
      "screen_name" : "whitehouse",
      "indices" : [ 46, 57 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "280770075592638465",
  "text" : "RT @KatieS: Record # of signatures asking the @whitehouse to address the issue of gun control. 151k &amp; counting. Will you join? https ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "whitehouse",
        "indices" : [ 34, 45 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 119, 140 ],
        "url" : "https://t.co/9yy6qhj7",
        "expanded_url" : "https://petitions.whitehouse.gov/petition/immediately-address-issue-gun-control-through-introduction-legislation-congress/2tgcXzQC",
        "display_url" : "petitions.whitehouse.gov/petition/immed…"
      } ]
    },
    "geo" : {
    },
    "id_str" : "280764838584668160",
    "text" : "Record # of signatures asking the @whitehouse to address the issue of gun control. 151k &amp; counting. Will you join? https://t.co/9yy6qhj7",
    "id" : 280764838584668160,
    "created_at" : "Mon Dec 17 20:02:08 +0000 2012",
    "user" : {
      "name" : "Katie Jacobs Stanton",
      "screen_name" : "KatieS",
      "protected" : false,
      "id_str" : "94143715",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2371721253/w4neiljq3e8xn6eq3lyh_normal.jpeg",
      "id" : 94143715,
      "verified" : false
    }
  },
  "id" : 280770075592638465,
  "created_at" : "Mon Dec 17 20:22:57 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jad Abumrad",
      "screen_name" : "JadAbumrad",
      "indices" : [ 61, 72 ],
      "id_str" : "135316691",
      "id" : 135316691
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 130 ],
      "url" : "http://t.co/WsHiHnWS",
      "expanded_url" : "http://buff.ly/T5CD39",
      "display_url" : "buff.ly/T5CD39"
    } ]
  },
  "geo" : {
  },
  "id_str" : "280749257403822081",
  "text" : "Reminds me of Niko's \"I am programmed to hug\" robot shirt RT @JadAbumrad: \"People will try to hug the robots\" http://t.co/WsHiHnWS",
  "id" : 280749257403822081,
  "created_at" : "Mon Dec 17 19:00:13 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Sarver",
      "screen_name" : "rsarver",
      "indices" : [ 0, 8 ],
      "id_str" : "795649",
      "id" : 795649
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "280716745331847168",
  "geo" : {
  },
  "id_str" : "280717141521604608",
  "in_reply_to_user_id" : 795649,
  "text" : "@rsarver A furnished apartment for a month while we zero in on the best option we can find. Rockridge is our current best guess.",
  "id" : 280717141521604608,
  "in_reply_to_status_id" : 280716745331847168,
  "created_at" : "Mon Dec 17 16:52:36 +0000 2012",
  "in_reply_to_screen_name" : "rsarver",
  "in_reply_to_user_id_str" : "795649",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 120 ],
      "url" : "http://t.co/7tdNXuAH",
      "expanded_url" : "http://4sq.com/XzCwhh",
      "display_url" : "4sq.com/XzCwhh"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.61590564431152, -122.39251255989075 ]
  },
  "id_str" : "280715293569990656",
  "text" : "Mon-Wed. Last partial week before vacation and move! (@ SFO AirTrain Station - Garage G &amp; BART) http://t.co/7tdNXuAH",
  "id" : 280715293569990656,
  "created_at" : "Mon Dec 17 16:45:16 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getprismatic.com\" rel=\"nofollow\">getprismatic.com</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bullshit",
      "indices" : [ 111, 120 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 110 ],
      "url" : "http://t.co/QT3DlCZi",
      "expanded_url" : "http://prsm.tc/nRspem",
      "display_url" : "prsm.tc/nRspem"
    } ]
  },
  "geo" : {
  },
  "id_str" : "280585087999946753",
  "text" : "Thirteen features but a brain ain't one. \"13 must-have features for your next mobile app\" http://t.co/QT3DlCZi #bullshit",
  "id" : 280585087999946753,
  "created_at" : "Mon Dec 17 08:07:52 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "280583494147661824",
  "text" : "Or, if you're a nerd, because &lt;%= universe %&gt;.",
  "id" : 280583494147661824,
  "created_at" : "Mon Dec 17 08:01:32 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "280583085261746177",
  "text" : "Because universe.",
  "id" : 280583085261746177,
  "created_at" : "Mon Dec 17 07:59:55 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Landon Howell",
      "screen_name" : "landonhowell",
      "indices" : [ 0, 13 ],
      "id_str" : "19151705",
      "id" : 19151705
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "280567955891310592",
  "geo" : {
  },
  "id_str" : "280568959059783680",
  "in_reply_to_user_id" : 19151705,
  "text" : "@landonhowell I've yet to start.",
  "id" : 280568959059783680,
  "in_reply_to_status_id" : 280567955891310592,
  "created_at" : "Mon Dec 17 07:03:47 +0000 2012",
  "in_reply_to_screen_name" : "landonhowell",
  "in_reply_to_user_id_str" : "19151705",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "280567558292271104",
  "text" : "The end of Game of Thrones season one was a nice surprise. Yes, I'm way behind.",
  "id" : 280567558292271104,
  "created_at" : "Mon Dec 17 06:58:13 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 0, 10 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "280565548897689600",
  "geo" : {
  },
  "id_str" : "280565998157975552",
  "in_reply_to_user_id" : 7362142,
  "text" : "@kellianne Looks like you're taking my advice to write drunk, edit sober quite literally. :)",
  "id" : 280565998157975552,
  "in_reply_to_status_id" : 280565548897689600,
  "created_at" : "Mon Dec 17 06:52:01 +0000 2012",
  "in_reply_to_screen_name" : "kellianne",
  "in_reply_to_user_id_str" : "7362142",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 116 ],
      "url" : "http://t.co/O7kzl0KZ",
      "expanded_url" : "http://usnews.nbcnews.com/_news/2012/12/16/15948998-obama-reassures-newtown-you-are-not-alone-at-vigil-for-victims-of-connecticut-school-shootings?lite",
      "display_url" : "usnews.nbcnews.com/_news/2012/12/…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "280547452090728449",
  "text" : "\"The answer is no. We are not doing enough. And we will have to change.\" - Barack Obama [video] http://t.co/O7kzl0KZ",
  "id" : 280547452090728449,
  "created_at" : "Mon Dec 17 05:38:19 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay Goldman",
      "screen_name" : "jaygoldman",
      "indices" : [ 0, 11 ],
      "id_str" : "861",
      "id" : 861
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "280530037768331264",
  "geo" : {
  },
  "id_str" : "280533766139674624",
  "in_reply_to_user_id" : 861,
  "text" : "@jaygoldman Thanks! And yes, do it!",
  "id" : 280533766139674624,
  "in_reply_to_status_id" : 280530037768331264,
  "created_at" : "Mon Dec 17 04:43:56 +0000 2012",
  "in_reply_to_screen_name" : "jaygoldman",
  "in_reply_to_user_id_str" : "861",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 54 ],
      "url" : "http://t.co/L1jPxpPk",
      "expanded_url" : "http://flic.kr/p/dBGQ7C",
      "display_url" : "flic.kr/p/dBGQ7C"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.608666, -122.306 ]
  },
  "id_str" : "280532927861886978",
  "text" : "8:36pm Fun lazy day with this guy http://t.co/L1jPxpPk",
  "id" : 280532927861886978,
  "created_at" : "Mon Dec 17 04:40:36 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Bonner",
      "screen_name" : "seanbonner",
      "indices" : [ 0, 11 ],
      "id_str" : "765",
      "id" : 765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "280495233710567425",
  "geo" : {
  },
  "id_str" : "280497565718417408",
  "in_reply_to_user_id" : 765,
  "text" : "@seanbonner You definitely should. It's quite fun.",
  "id" : 280497565718417408,
  "in_reply_to_status_id" : 280495233710567425,
  "created_at" : "Mon Dec 17 02:20:05 +0000 2012",
  "in_reply_to_screen_name" : "seanbonner",
  "in_reply_to_user_id_str" : "765",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Wright",
      "screen_name" : "webwright",
      "indices" : [ 0, 10 ],
      "id_str" : "786818",
      "id" : 786818
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "280486328968298497",
  "geo" : {
  },
  "id_str" : "280491257783005185",
  "in_reply_to_user_id" : 786818,
  "text" : "@webwright Bookmarked for later watching. Thanks.",
  "id" : 280491257783005185,
  "in_reply_to_status_id" : 280486328968298497,
  "created_at" : "Mon Dec 17 01:55:01 +0000 2012",
  "in_reply_to_screen_name" : "webwright",
  "in_reply_to_user_id_str" : "786818",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zack Shapiro",
      "screen_name" : "ZackShapiro",
      "indices" : [ 0, 12 ],
      "id_str" : "15999465",
      "id" : 15999465
    }, {
      "name" : "Tony Wright",
      "screen_name" : "webwright",
      "indices" : [ 13, 23 ],
      "id_str" : "786818",
      "id" : 786818
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "280485363812810754",
  "geo" : {
  },
  "id_str" : "280486129524936704",
  "in_reply_to_user_id" : 15999465,
  "text" : "@ZackShapiro @webwright I do plan to some day. I'll write about it in my 750words this week and see if it makes any more sense.",
  "id" : 280486129524936704,
  "in_reply_to_status_id" : 280485363812810754,
  "created_at" : "Mon Dec 17 01:34:39 +0000 2012",
  "in_reply_to_screen_name" : "ZackShapiro",
  "in_reply_to_user_id_str" : "15999465",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harper",
      "screen_name" : "harper",
      "indices" : [ 26, 33 ],
      "id_str" : "1497",
      "id" : 1497
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "280485836691218432",
  "text" : "Impressive. Good luck! RT @harper: I'm excited to start a week without the internet tomorrow. No smart phone, no laptop, no email &amp; no SMS.",
  "id" : 280485836691218432,
  "created_at" : "Mon Dec 17 01:33:29 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Gordon",
      "screen_name" : "JeremySF",
      "indices" : [ 0, 9 ],
      "id_str" : "19872718",
      "id" : 19872718
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "280478964059885568",
  "geo" : {
  },
  "id_str" : "280484006116593664",
  "in_reply_to_user_id" : 19872718,
  "text" : "@JeremySF I'm also waiting for the first person to submit a pull request on my beliefs.",
  "id" : 280484006116593664,
  "in_reply_to_status_id" : 280478964059885568,
  "created_at" : "Mon Dec 17 01:26:12 +0000 2012",
  "in_reply_to_screen_name" : "JeremySF",
  "in_reply_to_user_id_str" : "19872718",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Wright",
      "screen_name" : "webwright",
      "indices" : [ 0, 10 ],
      "id_str" : "786818",
      "id" : 786818
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "280482683015020544",
  "geo" : {
  },
  "id_str" : "280483736125046784",
  "in_reply_to_user_id" : 786818,
  "text" : "@webwright Yeah some outward resemblances but without the direct channel/insider knowledge/canon of the thoughts &amp; motives of said beings.",
  "id" : 280483736125046784,
  "in_reply_to_status_id" : 280482683015020544,
  "created_at" : "Mon Dec 17 01:25:08 +0000 2012",
  "in_reply_to_screen_name" : "webwright",
  "in_reply_to_user_id_str" : "786818",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Wright",
      "screen_name" : "webwright",
      "indices" : [ 0, 10 ],
      "id_str" : "786818",
      "id" : 786818
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "280480590745174016",
  "geo" : {
  },
  "id_str" : "280480810887434242",
  "in_reply_to_user_id" : 786818,
  "text" : "@webwright Yeah, I think the probability of that (or whatever simulations evolve into) is pretty high. Is that strange? :)",
  "id" : 280480810887434242,
  "in_reply_to_status_id" : 280480590745174016,
  "created_at" : "Mon Dec 17 01:13:31 +0000 2012",
  "in_reply_to_screen_name" : "webwright",
  "in_reply_to_user_id_str" : "786818",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Gordon",
      "screen_name" : "JeremySF",
      "indices" : [ 0, 9 ],
      "id_str" : "19872718",
      "id" : 19872718
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 119 ],
      "url" : "http://t.co/0WZVE14p",
      "expanded_url" : "http://wayoftheduck.com/codex-vitae",
      "display_url" : "wayoftheduck.com/codex-vitae"
    } ]
  },
  "in_reply_to_status_id_str" : "280478964059885568",
  "geo" : {
  },
  "id_str" : "280479378406785025",
  "in_reply_to_user_id" : 19872718,
  "text" : "@JeremySF Thanks! I've been trying to get people to fork and personalize… so please do! More info: http://t.co/0WZVE14p",
  "id" : 280479378406785025,
  "in_reply_to_status_id" : 280478964059885568,
  "created_at" : "Mon Dec 17 01:07:49 +0000 2012",
  "in_reply_to_screen_name" : "JeremySF",
  "in_reply_to_user_id_str" : "19872718",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 124 ],
      "url" : "https://t.co/UKLW7hVo",
      "expanded_url" : "https://github.com/busterbenson/public/blob/master/Beliefs.md",
      "display_url" : "github.com/busterbenson/p…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "280477600198049792",
  "text" : "I also added a section on my beliefs around what Earth will be like in 2100 (4th section from bottom): https://t.co/UKLW7hVo",
  "id" : 280477600198049792,
  "created_at" : "Mon Dec 17 01:00:45 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "rondiver",
      "screen_name" : "rondiver",
      "indices" : [ 0, 9 ],
      "id_str" : "12661782",
      "id" : 12661782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "280475821649559552",
  "geo" : {
  },
  "id_str" : "280476079368585217",
  "in_reply_to_user_id" : 12661782,
  "text" : "@rondiver The former? I did it merely for relaxation/stress purposes. Most people don't do acupuncture without some ailment though...",
  "id" : 280476079368585217,
  "in_reply_to_status_id" : 280475821649559552,
  "created_at" : "Mon Dec 17 00:54:42 +0000 2012",
  "in_reply_to_screen_name" : "rondiver",
  "in_reply_to_user_id_str" : "12661782",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Wang",
      "screen_name" : "brianmwang",
      "indices" : [ 0, 11 ],
      "id_str" : "93478440",
      "id" : 93478440
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "280474075174936576",
  "geo" : {
  },
  "id_str" : "280474658090917888",
  "in_reply_to_user_id" : 93478440,
  "text" : "@brianmwang Thanks! You should write yours up too. :)",
  "id" : 280474658090917888,
  "in_reply_to_status_id" : 280474075174936576,
  "created_at" : "Mon Dec 17 00:49:04 +0000 2012",
  "in_reply_to_screen_name" : "brianmwang",
  "in_reply_to_user_id_str" : "93478440",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "rondiver",
      "screen_name" : "rondiver",
      "indices" : [ 0, 9 ],
      "id_str" : "12661782",
      "id" : 12661782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 97 ],
      "url" : "http://t.co/PcwdFXsv",
      "expanded_url" : "http://www.zeel.com/d/41193/victoria-summerquist-acupuncturist",
      "display_url" : "zeel.com/d/41193/victor…"
    } ]
  },
  "in_reply_to_status_id_str" : "280473136049303552",
  "geo" : {
  },
  "id_str" : "280474578969583617",
  "in_reply_to_user_id" : 12661782,
  "text" : "@rondiver Let me know if you need a recommendation. :) Actually, here it is: http://t.co/PcwdFXsv",
  "id" : 280474578969583617,
  "in_reply_to_status_id" : 280473136049303552,
  "created_at" : "Mon Dec 17 00:48:45 +0000 2012",
  "in_reply_to_screen_name" : "rondiver",
  "in_reply_to_user_id_str" : "12661782",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 79 ],
      "url" : "https://t.co/UKLW7hVo",
      "expanded_url" : "https://github.com/busterbenson/public/blob/master/Beliefs.md",
      "display_url" : "github.com/busterbenson/p…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "280471941498941440",
  "text" : "Updated my beliefs file to include a line on gun control: https://t.co/UKLW7hVo",
  "id" : 280471941498941440,
  "created_at" : "Mon Dec 17 00:38:16 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.apple.com\" rel=\"nofollow\">Safari on iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 51 ],
      "url" : "http://t.co/BWLLNZlo",
      "expanded_url" : "http://www.salon.com/2012/07/25/the_nras_war_on_gun_science/",
      "display_url" : "salon.com/2012/07/25/the…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "280400390195916801",
  "text" : "The NRA's war on gun science.  http://t.co/BWLLNZlo",
  "id" : 280400390195916801,
  "created_at" : "Sun Dec 16 19:53:57 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helen Jane",
      "screen_name" : "helenjane",
      "indices" : [ 0, 10 ],
      "id_str" : "798542",
      "id" : 798542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "280188384100642816",
  "geo" : {
  },
  "id_str" : "280190147427962881",
  "in_reply_to_user_id" : 798542,
  "text" : "@helenjane Prepare yourself for a weekend visit late Jan, early Feb!",
  "id" : 280190147427962881,
  "in_reply_to_status_id" : 280188384100642816,
  "created_at" : "Sun Dec 16 05:58:31 +0000 2012",
  "in_reply_to_screen_name" : "helenjane",
  "in_reply_to_user_id_str" : "798542",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagr.am\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 86 ],
      "url" : "http://t.co/J1bH7qLO",
      "expanded_url" : "http://instagr.am/p/TSND5_o0ID/",
      "display_url" : "instagr.am/p/TSND5_o0ID/"
    } ]
  },
  "geo" : {
  },
  "id_str" : "280171757875392512",
  "text" : "8:36pm Holiday party playing king of the bean bag hill with Ellis http://t.co/J1bH7qLO",
  "id" : 280171757875392512,
  "created_at" : "Sun Dec 16 04:45:27 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 40, 48 ],
      "id_str" : "783214",
      "id" : 783214
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "celebrate",
      "indices" : [ 49, 59 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "280157702674604032",
  "text" : "Bummed to be totally missing out on the @Twitter #celebrate party. Next year!",
  "id" : 280157702674604032,
  "created_at" : "Sun Dec 16 03:49:36 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagr.am\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 57 ],
      "url" : "http://t.co/V0Tdsmg6",
      "expanded_url" : "http://instagr.am/p/TSBHt4I0Jq/",
      "display_url" : "instagr.am/p/TSBHt4I0Jq/"
    } ]
  },
  "geo" : {
  },
  "id_str" : "280145247248465921",
  "text" : "5 little monkeys jumping on the bed. http://t.co/V0Tdsmg6",
  "id" : 280145247248465921,
  "created_at" : "Sun Dec 16 03:00:06 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "April Schiller",
      "screen_name" : "the_april",
      "indices" : [ 0, 10 ],
      "id_str" : "16644937",
      "id" : 16644937
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "280091605086633984",
  "geo" : {
  },
  "id_str" : "280095465951858689",
  "in_reply_to_user_id" : 16644937,
  "text" : "@the_april Yeah the same arguments and counter-arguments get repeated over and over.",
  "id" : 280095465951858689,
  "in_reply_to_status_id" : 280091605086633984,
  "created_at" : "Sat Dec 15 23:42:17 +0000 2012",
  "in_reply_to_screen_name" : "the_april",
  "in_reply_to_user_id_str" : "16644937",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "April Schiller",
      "screen_name" : "the_april",
      "indices" : [ 0, 10 ],
      "id_str" : "16644937",
      "id" : 16644937
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "280083944651759616",
  "geo" : {
  },
  "id_str" : "280085876392984576",
  "in_reply_to_user_id" : 16644937,
  "text" : "@the_april The more conversations the better. We should start them all because another mass shooting will probably happen within 2 months.",
  "id" : 280085876392984576,
  "in_reply_to_status_id" : 280083944651759616,
  "created_at" : "Sat Dec 15 23:04:11 +0000 2012",
  "in_reply_to_screen_name" : "the_april",
  "in_reply_to_user_id_str" : "16644937",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http://t.co/UitFBZux",
      "expanded_url" : "http://www.nytimes.com/2012/12/16/opinion/sunday/kristof-do-we-have-the-courage-to-stop-this.html",
      "display_url" : "nytimes.com/2012/12/16/opi…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "280077475688620032",
  "text" : "\"If we could reduce gun deaths by one third, that would be 10,000 lives saved annually.\" Good steps suggested here: http://t.co/UitFBZux",
  "id" : 280077475688620032,
  "created_at" : "Sat Dec 15 22:30:48 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 131 ],
      "url" : "http://t.co/GlK8taxa",
      "expanded_url" : "http://wh.gov/RN6U",
      "display_url" : "wh.gov/RN6U"
    } ]
  },
  "geo" : {
  },
  "id_str" : "280073282462576640",
  "text" : "Signed it. \"Immediately address the issue of gun control through the introduction of legislation in Congress.\" http://t.co/GlK8taxa",
  "id" : 280073282462576640,
  "created_at" : "Sat Dec 15 22:14:08 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ellen Forney",
      "screen_name" : "ellen_forney",
      "indices" : [ 71, 84 ],
      "id_str" : "804968418",
      "id" : 804968418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 107 ],
      "url" : "http://t.co/vANvTUtE",
      "expanded_url" : "http://marblesbyellenforney.com",
      "display_url" : "marblesbyellenforney.com"
    } ]
  },
  "geo" : {
  },
  "id_str" : "280071215043973120",
  "text" : "Just finished the beautifully told &amp; illustrated graphic memoir by @ellen_forney:  http://t.co/vANvTUtE",
  "id" : 280071215043973120,
  "created_at" : "Sat Dec 15 22:05:55 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helen Jane",
      "screen_name" : "helenjane",
      "indices" : [ 0, 10 ],
      "id_str" : "798542",
      "id" : 798542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "279803039043436546",
  "geo" : {
  },
  "id_str" : "279993099315474432",
  "in_reply_to_user_id" : 798542,
  "text" : "@helenjane Moving on Jan 19th!",
  "id" : 279993099315474432,
  "in_reply_to_status_id" : 279803039043436546,
  "created_at" : "Sat Dec 15 16:55:31 +0000 2012",
  "in_reply_to_screen_name" : "helenjane",
  "in_reply_to_user_id_str" : "798542",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 75 ],
      "url" : "http://t.co/TZUj8St6",
      "expanded_url" : "http://flic.kr/p/dB5QR2",
      "display_url" : "flic.kr/p/dB5QR2"
    } ]
  },
  "geo" : {
  },
  "id_str" : "279829248347340800",
  "text" : "8:36pm Ex-Amazon old friends give me a great farewell. http://t.co/TZUj8St6",
  "id" : 279829248347340800,
  "created_at" : "Sat Dec 15 06:04:26 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagr.am\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 82 ],
      "url" : "http://t.co/oAQuHd96",
      "expanded_url" : "http://instagr.am/p/TPgtmCo0Lo/",
      "display_url" : "instagr.am/p/TPgtmCo0Lo/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6081305535, -122.299547195 ]
  },
  "id_str" : "279792673479602178",
  "text" : "Going away cookies from awesome old friends.  @ Twilight Exit http://t.co/oAQuHd96",
  "id" : 279792673479602178,
  "created_at" : "Sat Dec 15 03:39:06 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Sippey",
      "screen_name" : "sippey",
      "indices" : [ 3, 10 ],
      "id_str" : "4711",
      "id" : 4711
    }, {
      "name" : "Adam Mathes",
      "screen_name" : "adammathes",
      "indices" : [ 109, 120 ],
      "id_str" : "7337442",
      "id" : 7337442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "279767008650858497",
  "text" : "RT @sippey: \"The dream was that by lowering the bar of publishing and communication we’d all be publishers.\" @adammathes at http://t.co/ ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Adam Mathes",
        "screen_name" : "adammathes",
        "indices" : [ 97, 108 ],
        "id_str" : "7337442",
        "id" : 7337442
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 112, 132 ],
        "url" : "http://t.co/b0GOLFlG",
        "expanded_url" : "http://trenchant.org/daily/2012/12/14/",
        "display_url" : "trenchant.org/daily/2012/12/…"
      } ]
    },
    "geo" : {
    },
    "id_str" : "279765018373926912",
    "text" : "\"The dream was that by lowering the bar of publishing and communication we’d all be publishers.\" @adammathes at http://t.co/b0GOLFlG",
    "id" : 279765018373926912,
    "created_at" : "Sat Dec 15 01:49:12 +0000 2012",
    "user" : {
      "name" : "Michael Sippey",
      "screen_name" : "sippey",
      "protected" : false,
      "id_str" : "4711",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2990071228/1badb0fe82fced7ac4068c6669a54a76_normal.jpeg",
      "id" : 4711,
      "verified" : false
    }
  },
  "id" : 279767008650858497,
  "created_at" : "Sat Dec 15 01:57:07 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Weinberger",
      "screen_name" : "dweinberger",
      "indices" : [ 3, 15 ],
      "id_str" : "1285451",
      "id" : 1285451
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 122 ],
      "url" : "http://t.co/2FKhMZTF",
      "expanded_url" : "http://1wg.r2.ly/",
      "display_url" : "1wg.r2.ly"
    } ]
  },
  "geo" : {
  },
  "id_str" : "279750789549920256",
  "text" : "RT @dweinberger: Ray Kurzweil returns from the future, takes job at Google. He must know something... http://t.co/2FKhMZTF",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 85, 105 ],
        "url" : "http://t.co/2FKhMZTF",
        "expanded_url" : "http://1wg.r2.ly/",
        "display_url" : "1wg.r2.ly"
      } ]
    },
    "geo" : {
    },
    "id_str" : "279748553017004032",
    "text" : "Ray Kurzweil returns from the future, takes job at Google. He must know something... http://t.co/2FKhMZTF",
    "id" : 279748553017004032,
    "created_at" : "Sat Dec 15 00:43:47 +0000 2012",
    "user" : {
      "name" : "David Weinberger",
      "screen_name" : "dweinberger",
      "protected" : false,
      "id_str" : "1285451",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2818975033/48570085690504bf484825986abcfb71_normal.jpeg",
      "id" : 1285451,
      "verified" : false
    }
  },
  "id" : 279750789549920256,
  "created_at" : "Sat Dec 15 00:52:40 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"https://findings.com\" rel=\"nofollow\">Findings</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Findings",
      "screen_name" : "findings",
      "indices" : [ 31, 40 ],
      "id_str" : "208197274",
      "id" : 208197274
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 63 ],
      "url" : "http://t.co/PbPVAyMR",
      "expanded_url" : "http://fnd.gs/QYYkEA",
      "display_url" : "fnd.gs/QYYkEA"
    } ]
  },
  "geo" : {
  },
  "id_str" : "279723692030828544",
  "text" : "Moravec's paradox is neat. via @findings - http://t.co/PbPVAyMR",
  "id" : 279723692030828544,
  "created_at" : "Fri Dec 14 23:04:59 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://timehop.com/\" rel=\"nofollow\">Timehop</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 20 ],
      "url" : "http://t.co/UXCU3B0z",
      "expanded_url" : "http://750words.com",
      "display_url" : "750words.com"
    }, {
      "indices" : [ 67, 87 ],
      "url" : "http://t.co/BuMqJ5yQ",
      "expanded_url" : "http://t.imehop.com/RuhLXi",
      "display_url" : "t.imehop.com/RuhLXi"
    } ]
  },
  "geo" : {
  },
  "id_str" : "279722886770601988",
  "text" : "http://t.co/UXCU3B0z was almost ready to launch 3 years ago today. http://t.co/BuMqJ5yQ",
  "id" : 279722886770601988,
  "created_at" : "Fri Dec 14 23:01:47 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagr.am\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 102 ],
      "url" : "http://t.co/glZHbibI",
      "expanded_url" : "http://instagr.am/p/TNLHdKI0MF/",
      "display_url" : "instagr.am/p/TNLHdKI0MF/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6634183886, -122.380287051 ]
  },
  "id_str" : "279463534881042432",
  "text" : "Sea urchin custard, apple cider gelee, salmon roe! @ The Walrus and the Carpenter http://t.co/glZHbibI",
  "id" : 279463534881042432,
  "created_at" : "Fri Dec 14 05:51:13 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagr.am\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 61 ],
      "url" : "http://t.co/BZn7ReQU",
      "expanded_url" : "http://instagr.am/p/TNLJ8tI0MI/",
      "display_url" : "instagr.am/p/TNLJ8tI0MI/"
    } ]
  },
  "geo" : {
  },
  "id_str" : "279463527591333888",
  "text" : "8:36pm Date night with beauteous maximus http://t.co/BZn7ReQU",
  "id" : 279463527591333888,
  "created_at" : "Fri Dec 14 05:51:11 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getprismatic.com\" rel=\"nofollow\">getprismatic.com</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Prismatic",
      "screen_name" : "Prismatic",
      "indices" : [ 91, 101 ],
      "id_str" : "229709694",
      "id" : 229709694
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 86 ],
      "url" : "http://t.co/ScsioPgg",
      "expanded_url" : "http://prsm.tc/5GI5i6",
      "display_url" : "prsm.tc/5GI5i6"
    } ]
  },
  "geo" : {
  },
  "id_str" : "279410864237445120",
  "text" : "How to be evil. \"What Really Made Steve Jobs So Angry at Google?\" http://t.co/ScsioPgg via @prismatic",
  "id" : 279410864237445120,
  "created_at" : "Fri Dec 14 02:21:55 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://bufferapp.com\" rel=\"nofollow\">Buffer</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mailbox",
      "screen_name" : "mailbox",
      "indices" : [ 76, 84 ],
      "id_str" : "624947324",
      "id" : 624947324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 71 ],
      "url" : "http://t.co/NjfcLVgq",
      "expanded_url" : "http://bit.ly/Sjztgo",
      "display_url" : "bit.ly/Sjztgo"
    } ]
  },
  "geo" : {
  },
  "id_str" : "279316266668396544",
  "text" : "MAILBOX for iOS (coming next year) looks super rad http://t.co/NjfcLVgq /cc @mailbox",
  "id" : 279316266668396544,
  "created_at" : "Thu Dec 13 20:06:02 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Weiner",
      "screen_name" : "bweiner",
      "indices" : [ 0, 8 ],
      "id_str" : "787919",
      "id" : 787919
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "279298616454164481",
  "geo" : {
  },
  "id_str" : "279299649964224516",
  "in_reply_to_user_id" : 787919,
  "text" : "@bweiner Interesting. Can you find the link?",
  "id" : 279299649964224516,
  "in_reply_to_status_id" : 279298616454164481,
  "created_at" : "Thu Dec 13 19:00:00 +0000 2012",
  "in_reply_to_screen_name" : "bweiner",
  "in_reply_to_user_id_str" : "787919",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hannah Curious ",
      "screen_name" : "HannahCurious",
      "indices" : [ 0, 14 ],
      "id_str" : "285401666",
      "id" : 285401666
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "279295509955477506",
  "geo" : {
  },
  "id_str" : "279296540978315265",
  "in_reply_to_user_id" : 285401666,
  "text" : "@HannahCurious Do you remember how old you were when you first had the jolt? I remember being in 3rd grade, in bed, freaking out.",
  "id" : 279296540978315265,
  "in_reply_to_status_id" : 279295509955477506,
  "created_at" : "Thu Dec 13 18:47:39 +0000 2012",
  "in_reply_to_screen_name" : "HannahCurious",
  "in_reply_to_user_id_str" : "285401666",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Weiner",
      "screen_name" : "bweiner",
      "indices" : [ 0, 8 ],
      "id_str" : "787919",
      "id" : 787919
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "279293566835126272",
  "geo" : {
  },
  "id_str" : "279296328549429250",
  "in_reply_to_user_id" : 787919,
  "text" : "@bweiner It's actually really difficult for me to get to that jolt of vertigo. It's like my brain is designed to avoid the thought.",
  "id" : 279296328549429250,
  "in_reply_to_status_id" : 279293566835126272,
  "created_at" : "Thu Dec 13 18:46:48 +0000 2012",
  "in_reply_to_screen_name" : "bweiner",
  "in_reply_to_user_id_str" : "787919",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "279289836823773184",
  "text" : "Do you ever peer over the edge of your short life into infinity and get vertigo? It's like a quick jolt of energy to do meaningful things.",
  "id" : 279289836823773184,
  "created_at" : "Thu Dec 13 18:21:00 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "279122449298235392",
  "text" : "I've posted 403 photos on Instagram and 7,528 on Flickr.",
  "id" : 279122449298235392,
  "created_at" : "Thu Dec 13 07:15:52 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 33 ],
      "url" : "http://t.co/jqiK3dR3",
      "expanded_url" : "http://flic.kr/p/dACAXn",
      "display_url" : "flic.kr/p/dACAXn"
    } ]
  },
  "geo" : {
  },
  "id_str" : "279108483285139456",
  "text" : "8:36pm Home! http://t.co/jqiK3dR3",
  "id" : 279108483285139456,
  "created_at" : "Thu Dec 13 06:20:22 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Ellin",
      "screen_name" : "brianellin",
      "indices" : [ 0, 11 ],
      "id_str" : "26123649",
      "id" : 26123649
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "279011784906665984",
  "geo" : {
  },
  "id_str" : "279012506381451264",
  "in_reply_to_user_id" : 26123649,
  "text" : "@brianellin I love when a new social network comes out.",
  "id" : 279012506381451264,
  "in_reply_to_status_id" : 279011784906665984,
  "created_at" : "Wed Dec 12 23:58:59 +0000 2012",
  "in_reply_to_screen_name" : "brianellin",
  "in_reply_to_user_id_str" : "26123649",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachael Horwitz",
      "screen_name" : "RachaelRad",
      "indices" : [ 3, 14 ],
      "id_str" : "22824309",
      "id" : 22824309
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 110 ],
      "url" : "http://t.co/QOZCJp9w",
      "expanded_url" : "http://readwrite.com/2012/12/12/partnering-with-twitter-to-tell-a-bigger-story-qa-with-vizifys-ceo",
      "display_url" : "readwrite.com/2012/12/12/par…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "279009131246022656",
  "text" : "RT @RachaelRad: Partnering With Twitter To Tell A Bigger Story: Q&amp;A With Vizify's CEO http://t.co/QOZCJp9w",
  "retweeted_status" : {
    "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 74, 94 ],
        "url" : "http://t.co/QOZCJp9w",
        "expanded_url" : "http://readwrite.com/2012/12/12/partnering-with-twitter-to-tell-a-bigger-story-qa-with-vizifys-ceo",
        "display_url" : "readwrite.com/2012/12/12/par…"
      } ]
    },
    "geo" : {
    },
    "id_str" : "279002869615710209",
    "text" : "Partnering With Twitter To Tell A Bigger Story: Q&amp;A With Vizify's CEO http://t.co/QOZCJp9w",
    "id" : 279002869615710209,
    "created_at" : "Wed Dec 12 23:20:42 +0000 2012",
    "user" : {
      "name" : "Rachael Horwitz",
      "screen_name" : "RachaelRad",
      "protected" : false,
      "id_str" : "22824309",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2949683102/707309e20fc8a4547063b5caa2579c5d_normal.jpeg",
      "id" : 22824309,
      "verified" : false
    }
  },
  "id" : 279009131246022656,
  "created_at" : "Wed Dec 12 23:45:35 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Flickr",
      "screen_name" : "Flickr",
      "indices" : [ 13, 20 ],
      "id_str" : "21237045",
      "id" : 21237045
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 42 ],
      "url" : "http://t.co/WUiaF199",
      "expanded_url" : "http://tcrn.ch/UjESzw",
      "display_url" : "tcrn.ch/UjESzw"
    } ]
  },
  "geo" : {
  },
  "id_str" : "278931792306769921",
  "text" : "Well played, @flickr. http://t.co/WUiaF199",
  "id" : 278931792306769921,
  "created_at" : "Wed Dec 12 18:38:16 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 54 ],
      "url" : "http://t.co/gAWSYE6e",
      "expanded_url" : "http://flic.kr/p/dAAHzQ",
      "display_url" : "flic.kr/p/dAAHzQ"
    } ]
  },
  "geo" : {
  },
  "id_str" : "278929518679437313",
  "text" : "Testing new Flickr filers on Niko http://t.co/gAWSYE6e",
  "id" : 278929518679437313,
  "created_at" : "Wed Dec 12 18:29:14 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Watkins",
      "screen_name" : "olivia",
      "indices" : [ 15, 22 ],
      "id_str" : "25216995",
      "id" : 25216995
    }, {
      "name" : "Buster Benson",
      "screen_name" : "busterbenson",
      "indices" : [ 81, 94 ],
      "id_str" : "2185",
      "id" : 2185
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "humblebrag",
      "indices" : [ 0, 11 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "278789453839994881",
  "text" : "#humblebrag RT @olivia: \"we A/B tested. one week, tupac ice sculpture; one week, @busterbenson. buster benson had better results.\"",
  "id" : 278789453839994881,
  "created_at" : "Wed Dec 12 09:12:40 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagr.am\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 70 ],
      "url" : "http://t.co/EW69EMn5",
      "expanded_url" : "http://instagr.am/p/TH6SUvI0Ak/",
      "display_url" : "instagr.am/p/TH6SUvI0Ak/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.767702, -122.429301 ]
  },
  "id_str" : "278723013103452160",
  "text" : "8:36pm Dinner with Lane and Jason @ The Residence http://t.co/EW69EMn5",
  "id" : 278723013103452160,
  "created_at" : "Wed Dec 12 04:48:39 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Crystal Goh",
      "screen_name" : "ccwgoh",
      "indices" : [ 0, 7 ],
      "id_str" : "400616744",
      "id" : 400616744
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "quantifiedself",
      "indices" : [ 23, 38 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "278650086093897729",
  "in_reply_to_user_id" : 400616744,
  "text" : "@ccwgoh Hey I saw your #quantifiedself talk a couple weeks ago. Do you need more brain scan volunteers / recommend a place to get it done?",
  "id" : 278650086093897729,
  "created_at" : "Tue Dec 11 23:58:52 +0000 2012",
  "in_reply_to_screen_name" : "ccwgoh",
  "in_reply_to_user_id_str" : "400616744",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emma Welles",
      "screen_name" : "emmarocks",
      "indices" : [ 0, 10 ],
      "id_str" : "766566",
      "id" : 766566
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "278637216811581440",
  "geo" : {
  },
  "id_str" : "278644100868227072",
  "in_reply_to_user_id" : 766566,
  "text" : "@emmarocks I was just thinking the same thing. Is hipstamatic on Android? They do it.",
  "id" : 278644100868227072,
  "in_reply_to_status_id" : 278637216811581440,
  "created_at" : "Tue Dec 11 23:35:05 +0000 2012",
  "in_reply_to_screen_name" : "emmarocks",
  "in_reply_to_user_id_str" : "766566",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://bufferapp.com\" rel=\"nofollow\">Buffer</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Britt Selvitelle",
      "screen_name" : "bs",
      "indices" : [ 95, 98 ],
      "id_str" : "309073",
      "id" : 309073
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 89 ],
      "url" : "http://t.co/9BrpVN1b",
      "expanded_url" : "http://bit.ly/Vy1Bb3",
      "display_url" : "bit.ly/Vy1Bb3"
    } ]
  },
  "geo" : {
  },
  "id_str" : "278591422402277377",
  "text" : "How to improve the quality of our decision making: decision journals http://t.co/9BrpVN1b /via @bs",
  "id" : 278591422402277377,
  "created_at" : "Tue Dec 11 20:05:45 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Coates",
      "screen_name" : "tomcoates",
      "indices" : [ 42, 52 ],
      "id_str" : "12514",
      "id" : 12514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "278566019029692416",
  "text" : "Thanks for being my 2012 golden follower, @tomcoates.",
  "id" : 278566019029692416,
  "created_at" : "Tue Dec 11 18:24:49 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eli Tucker",
      "screen_name" : "etucker",
      "indices" : [ 0, 8 ],
      "id_str" : "5559292",
      "id" : 5559292
    }, {
      "name" : "Todd of Vizify",
      "screen_name" : "vizify",
      "indices" : [ 9, 16 ],
      "id_str" : "295513152",
      "id" : 295513152
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "278553808974524416",
  "geo" : {
  },
  "id_str" : "278563454938390528",
  "in_reply_to_user_id" : 5559292,
  "text" : "@etucker @vizify Definitely. :)",
  "id" : 278563454938390528,
  "in_reply_to_status_id" : 278553808974524416,
  "created_at" : "Tue Dec 11 18:14:37 +0000 2012",
  "in_reply_to_screen_name" : "etucker",
  "in_reply_to_user_id_str" : "5559292",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Twitter2012",
      "indices" : [ 44, 56 ]
    }, {
      "text" : "vizify",
      "indices" : [ 57, 64 ]
    } ],
    "urls" : [ {
      "indices" : [ 65, 86 ],
      "url" : "https://t.co/pjp9Oz6x",
      "expanded_url" : "https://www.vizify.com/buster-benson/year-on-twitter?km_source=share_twitter&km_orig_source=share_twitter&km_generation=0&km_orig_person=DFZP2M4GXQm%2BZIF83TEZjrTGtE4%3D&km_prev_person=DFZP2M4GXQm%2BZIF83TEZjrTGtE4%3D",
      "display_url" : "vizify.com/buster-benson/…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "278554837929578496",
  "text" : "Can you guess my top tweeted words of 2012? #Twitter2012 #vizify https://t.co/pjp9Oz6x",
  "id" : 278554837929578496,
  "created_at" : "Tue Dec 11 17:40:23 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Todd of Vizify",
      "screen_name" : "vizify",
      "indices" : [ 0, 7 ],
      "id_str" : "295513152",
      "id" : 295513152
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "278541097687461888",
  "geo" : {
  },
  "id_str" : "278543823385272321",
  "in_reply_to_user_id" : 295513152,
  "text" : "@vizify I was excited to see this. Well done! And excellent implementation of cards too. :)",
  "id" : 278543823385272321,
  "in_reply_to_status_id" : 278541097687461888,
  "created_at" : "Tue Dec 11 16:56:37 +0000 2012",
  "in_reply_to_screen_name" : "vizify",
  "in_reply_to_user_id_str" : "295513152",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Sposato",
      "screen_name" : "jonathansposato",
      "indices" : [ 3, 19 ],
      "id_str" : "37036797",
      "id" : 37036797
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Twitter2012",
      "indices" : [ 67, 79 ]
    }, {
      "text" : "vizify",
      "indices" : [ 109, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 139 ],
      "url" : "https://t.co/6TGaGHeS",
      "expanded_url" : "https://2012.twitter.com",
      "display_url" : "2012.twitter.com"
    } ]
  },
  "geo" : {
  },
  "id_str" : "278542505119735808",
  "text" : "RT @jonathansposato: What's the top tweet of 2012? Twitter unveils #Twitter2012 + Your top tweet (powered by #vizify) https://t.co/6TGaGHeS",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Twitter2012",
        "indices" : [ 46, 58 ]
      }, {
        "text" : "vizify",
        "indices" : [ 88, 95 ]
      } ],
      "urls" : [ {
        "indices" : [ 97, 118 ],
        "url" : "https://t.co/6TGaGHeS",
        "expanded_url" : "https://2012.twitter.com",
        "display_url" : "2012.twitter.com"
      } ]
    },
    "geo" : {
    },
    "id_str" : "278535319995961344",
    "text" : "What's the top tweet of 2012? Twitter unveils #Twitter2012 + Your top tweet (powered by #vizify) https://t.co/6TGaGHeS",
    "id" : 278535319995961344,
    "created_at" : "Tue Dec 11 16:22:49 +0000 2012",
    "user" : {
      "name" : "Jonathan Sposato",
      "screen_name" : "jonathansposato",
      "protected" : false,
      "id_str" : "37036797",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2577370968/7odw2llusk6vyvwalm5e_normal.jpeg",
      "id" : 37036797,
      "verified" : false
    }
  },
  "id" : 278542505119735808,
  "created_at" : "Tue Dec 11 16:51:22 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pete Cashmore",
      "screen_name" : "mashable",
      "indices" : [ 3, 12 ],
      "id_str" : "972651",
      "id" : 972651
    }, {
      "name" : "The Daily Dot",
      "screen_name" : "dailydot",
      "indices" : [ 80, 89 ],
      "id_str" : "211620426",
      "id" : 211620426
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 75 ],
      "url" : "http://t.co/lwHaDyYY",
      "expanded_url" : "http://on.mash.to/TNACZ5",
      "display_url" : "on.mash.to/TNACZ5"
    } ]
  },
  "geo" : {
  },
  "id_str" : "278541973479124993",
  "text" : "RT @mashable: Pinterest Adds Support for Twitter Cards http://t.co/lwHaDyYY via @dailydot",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.socialflow.com\" rel=\"nofollow\">SocialFlow</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Daily Dot",
        "screen_name" : "dailydot",
        "indices" : [ 66, 75 ],
        "id_str" : "211620426",
        "id" : 211620426
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 41, 61 ],
        "url" : "http://t.co/lwHaDyYY",
        "expanded_url" : "http://on.mash.to/TNACZ5",
        "display_url" : "on.mash.to/TNACZ5"
      } ]
    },
    "geo" : {
    },
    "id_str" : "278529674093678593",
    "text" : "Pinterest Adds Support for Twitter Cards http://t.co/lwHaDyYY via @dailydot",
    "id" : 278529674093678593,
    "created_at" : "Tue Dec 11 16:00:23 +0000 2012",
    "user" : {
      "name" : "Pete Cashmore",
      "screen_name" : "mashable",
      "protected" : false,
      "id_str" : "972651",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2015016150/petecashmoreavatar_normal.png",
      "id" : 972651,
      "verified" : true
    }
  },
  "id" : 278541973479124993,
  "created_at" : "Tue Dec 11 16:49:16 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russell Dicker",
      "screen_name" : "rdicker",
      "indices" : [ 9, 17 ],
      "id_str" : "958581",
      "id" : 958581
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lyke",
      "indices" : [ 0, 5 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "278378135500779520",
  "text" : "#lyke RT @rdicker: Trying out ye new Twitter textte filters. About tyme they released them.",
  "id" : 278378135500779520,
  "created_at" : "Tue Dec 11 05:58:14 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagr.am\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John W. Solomon",
      "screen_name" : "JohnWrede",
      "indices" : [ 21, 31 ],
      "id_str" : "125733",
      "id" : 125733
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 66 ],
      "url" : "http://t.co/aKD3ZFIE",
      "expanded_url" : "http://instagr.am/p/TFUYaVo0LR/",
      "display_url" : "instagr.am/p/TFUYaVo0LR/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7903451921, -122.404593229 ]
  },
  "id_str" : "278358187952992256",
  "text" : "8:36pm Drinking with @johnwrede! @ Irish Bank http://t.co/aKD3ZFIE",
  "id" : 278358187952992256,
  "created_at" : "Tue Dec 11 04:38:58 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cap Watkins",
      "screen_name" : "cap",
      "indices" : [ 0, 4 ],
      "id_str" : "2182141",
      "id" : 2182141
    }, {
      "name" : "Ryan Freitas",
      "screen_name" : "ryanchris",
      "indices" : [ 5, 15 ],
      "id_str" : "13349",
      "id" : 13349
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "278328558110273536",
  "geo" : {
  },
  "id_str" : "278333517535006720",
  "in_reply_to_user_id" : 2182141,
  "text" : "@cap @ryanchris Trying to 1) guess motivations of others with 2) inferior info but 3) assumed superior understanding = a curmudgeonly art :)",
  "id" : 278333517535006720,
  "in_reply_to_status_id" : 278328558110273536,
  "created_at" : "Tue Dec 11 03:00:56 +0000 2012",
  "in_reply_to_screen_name" : "cap",
  "in_reply_to_user_id_str" : "2182141",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Freitas",
      "screen_name" : "ryanchris",
      "indices" : [ 0, 10 ],
      "id_str" : "13349",
      "id" : 13349
    }, {
      "name" : "Cap Watkins",
      "screen_name" : "cap",
      "indices" : [ 11, 15 ],
      "id_str" : "2182141",
      "id" : 2182141
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "oldcurmudeons",
      "indices" : [ 39, 53 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "278323984678932480",
  "geo" : {
  },
  "id_str" : "278328462832439296",
  "in_reply_to_user_id" : 13349,
  "text" : "@ryanchris @cap I am tagging you both  #oldcurmudeons.",
  "id" : 278328462832439296,
  "in_reply_to_status_id" : 278323984678932480,
  "created_at" : "Tue Dec 11 02:40:51 +0000 2012",
  "in_reply_to_screen_name" : "ryanchris",
  "in_reply_to_user_id_str" : "13349",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://bufferapp.com\" rel=\"nofollow\">Buffer</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "rands",
      "screen_name" : "rands",
      "indices" : [ 39, 45 ],
      "id_str" : "30923",
      "id" : 30923
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 34 ],
      "url" : "http://t.co/NYWhOJmW",
      "expanded_url" : "http://bit.ly/SMoxEF",
      "display_url" : "bit.ly/SMoxEF"
    } ]
  },
  "geo" : {
  },
  "id_str" : "278302054877888512",
  "text" : "DIY Instagram http://t.co/NYWhOJmW /by @rands",
  "id" : 278302054877888512,
  "created_at" : "Tue Dec 11 00:55:55 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "girl jo",
      "screen_name" : "octavekitten",
      "indices" : [ 0, 13 ],
      "id_str" : "16366882",
      "id" : 16366882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "278285047054888960",
  "geo" : {
  },
  "id_str" : "278285552904720384",
  "in_reply_to_user_id" : 16366882,
  "text" : "@octavekitten Filters in general? Yeah, there are algorithms designed to automatically apply some series of adjustments in a certain order.",
  "id" : 278285552904720384,
  "in_reply_to_status_id" : 278285047054888960,
  "created_at" : "Mon Dec 10 23:50:20 +0000 2012",
  "in_reply_to_screen_name" : "octavekitten",
  "in_reply_to_user_id_str" : "16366882",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "girl jo",
      "screen_name" : "octavekitten",
      "indices" : [ 0, 13 ],
      "id_str" : "16366882",
      "id" : 16366882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "278284262569021440",
  "geo" : {
  },
  "id_str" : "278284520594214912",
  "in_reply_to_user_id" : 16366882,
  "text" : "@octavekitten I agree. We have some work to do.",
  "id" : 278284520594214912,
  "in_reply_to_status_id" : 278284262569021440,
  "created_at" : "Mon Dec 10 23:46:14 +0000 2012",
  "in_reply_to_screen_name" : "octavekitten",
  "in_reply_to_user_id_str" : "16366882",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/busterbenson/status/278283643405889536/photo/1",
      "indices" : [ 36, 56 ],
      "url" : "http://t.co/fYNHbSQO",
      "media_url" : "http://pbs.twimg.com/media/A9ypf9BCcAA8FEq.jpg",
      "id_str" : "278283643410083840",
      "id" : 278283643410083840,
      "media_url_https" : "https://pbs.twimg.com/media/A9ypf9BCcAA8FEq.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com/fYNHbSQO"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "278283643405889536",
  "text" : "Testing new Twitter filters on Niko http://t.co/fYNHbSQO",
  "id" : 278283643405889536,
  "created_at" : "Mon Dec 10 23:42:46 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagr.am\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 64 ],
      "url" : "http://t.co/0x4PogdN",
      "expanded_url" : "http://instagr.am/p/TEyJ7SI0LC/",
      "display_url" : "instagr.am/p/TEyJ7SI0LC/"
    } ]
  },
  "geo" : {
  },
  "id_str" : "278283224734646273",
  "text" : "Testing new Instagram Willow filter on Niko http://t.co/0x4PogdN",
  "id" : 278283224734646273,
  "created_at" : "Mon Dec 10 23:41:05 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 3, 11 ],
      "id_str" : "783214",
      "id" : 783214
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "278279670082985985",
  "text" : "RT @twitter: Twitter for iPhone and Android let you filter and edit photos right from the app. \"Twitter photos: Put a filter on it\" http ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 119, 139 ],
        "url" : "http://t.co/iNkIkZBD",
        "expanded_url" : "http://blog.twitter.com/2012/12/twitter-photos-put-filter-on-it.html",
        "display_url" : "blog.twitter.com/2012/12/twitte…"
      } ]
    },
    "geo" : {
    },
    "id_str" : "278276920381157377",
    "text" : "Twitter for iPhone and Android let you filter and edit photos right from the app. \"Twitter photos: Put a filter on it\" http://t.co/iNkIkZBD.",
    "id" : 278276920381157377,
    "created_at" : "Mon Dec 10 23:16:02 +0000 2012",
    "user" : {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "protected" : false,
      "id_str" : "783214",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2284174758/v65oai7fxn47qv9nectx_normal.png",
      "id" : 783214,
      "verified" : true
    }
  },
  "id" : 278279670082985985,
  "created_at" : "Mon Dec 10 23:26:58 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Natalya",
      "screen_name" : "talof2cities",
      "indices" : [ 0, 13 ],
      "id_str" : "62600226",
      "id" : 62600226
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "278265468375146496",
  "geo" : {
  },
  "id_str" : "278277164275752960",
  "in_reply_to_user_id" : 62600226,
  "text" : "@talof2cities Wait, is it in common use in your land? Where is your land again? :)",
  "id" : 278277164275752960,
  "in_reply_to_status_id" : 278265468375146496,
  "created_at" : "Mon Dec 10 23:17:00 +0000 2012",
  "in_reply_to_screen_name" : "talof2cities",
  "in_reply_to_user_id_str" : "62600226",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "done",
      "indices" : [ 86, 91 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "278239705437466624",
  "text" : "TODO: Stop using bi-weekly/bi-monthly to mean every 2 weeks. Start using fortnightly. #done",
  "id" : 278239705437466624,
  "created_at" : "Mon Dec 10 20:48:09 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Sarver",
      "screen_name" : "rsarver",
      "indices" : [ 0, 8 ],
      "id_str" : "795649",
      "id" : 795649
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "278222124999647232",
  "geo" : {
  },
  "id_str" : "278222663795757056",
  "in_reply_to_user_id" : 795649,
  "text" : "@rsarver Me too. Does this mean Nike's gonna open up their API?",
  "id" : 278222663795757056,
  "in_reply_to_status_id" : 278222124999647232,
  "created_at" : "Mon Dec 10 19:40:26 +0000 2012",
  "in_reply_to_screen_name" : "rsarver",
  "in_reply_to_user_id_str" : "795649",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Sarver",
      "screen_name" : "rsarver",
      "indices" : [ 0, 8 ],
      "id_str" : "795649",
      "id" : 795649
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "278218207007997952",
  "geo" : {
  },
  "id_str" : "278221922167308288",
  "in_reply_to_user_id" : 795649,
  "text" : "@rsarver Wow, that's awesome! Were you a Techstars mentor prior?",
  "id" : 278221922167308288,
  "in_reply_to_status_id" : 278218207007997952,
  "created_at" : "Mon Dec 10 19:37:30 +0000 2012",
  "in_reply_to_screen_name" : "rsarver",
  "in_reply_to_user_id_str" : "795649",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "STW Group",
      "screen_name" : "STWnextness",
      "indices" : [ 3, 15 ],
      "id_str" : "245763083",
      "id" : 245763083
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 62 ],
      "url" : "http://t.co/jChWy4Bi",
      "expanded_url" : "http://bit.ly/SAjQxH",
      "display_url" : "bit.ly/SAjQxH"
    } ]
  },
  "geo" : {
  },
  "id_str" : "278190341721575424",
  "text" : "RT @STWnextness: The evolution of meaning http://t.co/jChWy4Bi",
  "retweeted_status" : {
    "source" : "<a href=\"http://bufferapp.com\" rel=\"nofollow\">Buffer</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 25, 45 ],
        "url" : "http://t.co/jChWy4Bi",
        "expanded_url" : "http://bit.ly/SAjQxH",
        "display_url" : "bit.ly/SAjQxH"
      } ]
    },
    "geo" : {
    },
    "id_str" : "277928796777218048",
    "text" : "The evolution of meaning http://t.co/jChWy4Bi",
    "id" : 277928796777218048,
    "created_at" : "Mon Dec 10 00:12:43 +0000 2012",
    "user" : {
      "name" : "STW Group",
      "screen_name" : "STWnextness",
      "protected" : false,
      "id_str" : "245763083",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1250495066/Screen_shot_2011-02-21_at_2.10.46_PM_normal.png",
      "id" : 245763083,
      "verified" : false
    }
  },
  "id" : 278190341721575424,
  "created_at" : "Mon Dec 10 17:32:00 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "STW Group",
      "screen_name" : "STWnextness",
      "indices" : [ 11, 23 ],
      "id_str" : "245763083",
      "id" : 245763083
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 78 ],
      "url" : "http://t.co/gxmfrRy2",
      "expanded_url" : "http://bit.ly/SJdj3N",
      "display_url" : "bit.ly/SJdj3N"
    } ]
  },
  "geo" : {
  },
  "id_str" : "278189956009164800",
  "text" : "Busted. RT @STWnextness: \"You are boring. So, so boring.\" http://t.co/gxmfrRy2",
  "id" : 278189956009164800,
  "created_at" : "Mon Dec 10 17:30:28 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://bufferapp.com\" rel=\"nofollow\">Buffer</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Branch",
      "screen_name" : "branch",
      "indices" : [ 75, 82 ],
      "id_str" : "494518813",
      "id" : 494518813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 62 ],
      "url" : "http://t.co/BDWgZS36",
      "expanded_url" : "http://bit.ly/SHkrh3",
      "display_url" : "bit.ly/SHkrh3"
    }, {
      "indices" : [ 84, 104 ],
      "url" : "http://t.co/FvDRAIAG",
      "expanded_url" : "http://bit.ly/SLeIXR",
      "display_url" : "bit.ly/SLeIXR"
    } ]
  },
  "geo" : {
  },
  "id_str" : "278180249311784960",
  "text" : "How \"anything is possible\" is misleading: http://t.co/BDWgZS36 (discuss on @branch: http://t.co/FvDRAIAG)",
  "id" : 278180249311784960,
  "created_at" : "Mon Dec 10 16:51:54 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://bufferapp.com\" rel=\"nofollow\">Buffer</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "truth",
      "indices" : [ 132, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "278174149074120705",
  "text" : "We were given brains the size of thimbles and a desire to grasp a fairly deep puddle. The universe must not like our Facebook page. #truth",
  "id" : 278174149074120705,
  "created_at" : "Mon Dec 10 16:27:40 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Saffitz",
      "screen_name" : "msaffitz",
      "indices" : [ 0, 9 ],
      "id_str" : "14930470",
      "id" : 14930470
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "278160262228492288",
  "geo" : {
  },
  "id_str" : "278170286787010560",
  "in_reply_to_user_id" : 14930470,
  "text" : "@msaffitz Awesome!",
  "id" : 278170286787010560,
  "in_reply_to_status_id" : 278160262228492288,
  "created_at" : "Mon Dec 10 16:12:19 +0000 2012",
  "in_reply_to_screen_name" : "msaffitz",
  "in_reply_to_user_id_str" : "14930470",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Saffitz",
      "screen_name" : "msaffitz",
      "indices" : [ 3, 12 ],
      "id_str" : "14930470",
      "id" : 14930470
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "278170058612674560",
  "text" : "RT @msaffitz: Apptentive Scores $1.2M From Founder’s Co-Op, Google Ventures, To Help App Devs Solicit Better Feedback http://t.co/AztqxP ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "TechCrunch",
        "screen_name" : "TechCrunch",
        "indices" : [ 129, 140 ],
        "id_str" : "816653",
        "id" : 816653
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 104, 124 ],
        "url" : "http://t.co/AztqxPIi",
        "expanded_url" : "http://techcrunch.com/2012/12/10/apptentive/",
        "display_url" : "techcrunch.com/2012/12/10/app…"
      } ]
    },
    "geo" : {
    },
    "id_str" : "278160262228492288",
    "text" : "Apptentive Scores $1.2M From Founder’s Co-Op, Google Ventures, To Help App Devs Solicit Better Feedback http://t.co/AztqxPIi via @techcrunch",
    "id" : 278160262228492288,
    "created_at" : "Mon Dec 10 15:32:29 +0000 2012",
    "user" : {
      "name" : "Michael Saffitz",
      "screen_name" : "msaffitz",
      "protected" : false,
      "id_str" : "14930470",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1524316931/mike_smile_normal.jpg",
      "id" : 14930470,
      "verified" : false
    }
  },
  "id" : 278170058612674560,
  "created_at" : "Mon Dec 10 16:11:24 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mahendra Palsule",
      "screen_name" : "ScepticGeek",
      "indices" : [ 58, 70 ],
      "id_str" : "28520903",
      "id" : 28520903
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 131 ],
      "url" : "http://t.co/YNryLGms",
      "expanded_url" : "http://j.mp/VshQq3",
      "display_url" : "j.mp/VshQq3"
    } ]
  },
  "geo" : {
  },
  "id_str" : "278136468558454786",
  "text" : "Great post reframing how I think about social networks RT @ScepticGeek: The Disillusionment of Social Networks http://t.co/YNryLGms",
  "id" : 278136468558454786,
  "created_at" : "Mon Dec 10 13:57:56 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rob Anderson",
      "screen_name" : "iotaweb",
      "indices" : [ 0, 8 ],
      "id_str" : "19482382",
      "id" : 19482382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "278014966810951681",
  "geo" : {
  },
  "id_str" : "278017603828592640",
  "in_reply_to_user_id" : 19482382,
  "text" : "@iotaweb Oh well, sorry!",
  "id" : 278017603828592640,
  "in_reply_to_status_id" : 278014966810951681,
  "created_at" : "Mon Dec 10 06:05:36 +0000 2012",
  "in_reply_to_screen_name" : "iotaweb",
  "in_reply_to_user_id_str" : "19482382",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Branch",
      "screen_name" : "branch",
      "indices" : [ 10, 17 ],
      "id_str" : "494518813",
      "id" : 494518813
    }, {
      "name" : "Paul Ford",
      "screen_name" : "ftrain",
      "indices" : [ 72, 79 ],
      "id_str" : "6981492",
      "id" : 6981492
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 100 ],
      "url" : "http://t.co/LQwUTI6E",
      "expanded_url" : "http://branch.com/b/what-can-we-do-to-stop-sincerity",
      "display_url" : "branch.com/b/what-can-we-…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "278012984440262657",
  "text" : "Excellent @branch alert: \"What can we do to stop sincerity?\" started by @ftrain http://t.co/LQwUTI6E",
  "id" : 278012984440262657,
  "created_at" : "Mon Dec 10 05:47:15 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tara Tiger Brown ",
      "screen_name" : "tara",
      "indices" : [ 0, 5 ],
      "id_str" : "10959642",
      "id" : 10959642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "278004334254489600",
  "geo" : {
  },
  "id_str" : "278005666969432064",
  "in_reply_to_user_id" : 10959642,
  "text" : "@tara Yes, he's ready to start a new day.",
  "id" : 278005666969432064,
  "in_reply_to_status_id" : 278004334254489600,
  "created_at" : "Mon Dec 10 05:18:10 +0000 2012",
  "in_reply_to_screen_name" : "tara",
  "in_reply_to_user_id_str" : "10959642",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Garry Tan",
      "screen_name" : "garrytan",
      "indices" : [ 3, 12 ],
      "id_str" : "11768582",
      "id" : 11768582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "278005380867571712",
  "text" : "RT @garrytan: Todo sample apps written in 30+ different Javascript MVC frameworks, including Backbone.js, Ember.js, Meteor http://t.co/0 ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 109, 129 ],
        "url" : "http://t.co/0Mn6aUQ1",
        "expanded_url" : "http://todomvc.com/",
        "display_url" : "todomvc.com"
      } ]
    },
    "geo" : {
    },
    "id_str" : "278001659089666048",
    "text" : "Todo sample apps written in 30+ different Javascript MVC frameworks, including Backbone.js, Ember.js, Meteor http://t.co/0Mn6aUQ1 Handy!",
    "id" : 278001659089666048,
    "created_at" : "Mon Dec 10 05:02:15 +0000 2012",
    "user" : {
      "name" : "Garry Tan",
      "screen_name" : "garrytan",
      "protected" : false,
      "id_str" : "11768582",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2673975033/965a165a093e7c0921b9d69d5d99bc41_normal.jpeg",
      "id" : 11768582,
      "verified" : false
    }
  },
  "id" : 278005380867571712,
  "created_at" : "Mon Dec 10 05:17:02 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagr.am\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 116 ],
      "url" : "http://t.co/vubr7z0p",
      "expanded_url" : "http://instagr.am/p/TCzJ9XI0Bw/",
      "display_url" : "instagr.am/p/TCzJ9XI0Bw/"
    } ]
  },
  "geo" : {
  },
  "id_str" : "278003685655719936",
  "text" : "8:36pm Skipped his nap and still claiming that he doesn't need to sleep. He's got things to do. http://t.co/vubr7z0p",
  "id" : 278003685655719936,
  "created_at" : "Mon Dec 10 05:10:18 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagr.am\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 102 ],
      "url" : "http://t.co/XBI46TVp",
      "expanded_url" : "http://instagr.am/p/TB6G0Vo0Cz/",
      "display_url" : "instagr.am/p/TB6G0Vo0Cz/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.615071, -122.354059 ]
  },
  "id_str" : "277878238087356416",
  "text" : "\"4 airplanes coming down the track!\" Weekly choo-spotting @ Old Spaghetti Factory http://t.co/XBI46TVp",
  "id" : 277878238087356416,
  "created_at" : "Sun Dec 09 20:51:49 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Derek Sivers",
      "screen_name" : "sivers",
      "indices" : [ 75, 82 ],
      "id_str" : "2206131",
      "id" : 2206131
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 71 ],
      "url" : "http://t.co/dM6juB6s",
      "expanded_url" : "http://sivers.org/my-fault",
      "display_url" : "sivers.org/my-fault"
    } ]
  },
  "geo" : {
  },
  "id_str" : "277842399550640128",
  "text" : "Accepting responsibility is better than forgiving: http://t.co/dM6juB6s by @sivers",
  "id" : 277842399550640128,
  "created_at" : "Sun Dec 09 18:29:24 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Antonio Neves",
      "screen_name" : "TheAntonioNeves",
      "indices" : [ 0, 16 ],
      "id_str" : "20932488",
      "id" : 20932488
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "277837533319139328",
  "geo" : {
  },
  "id_str" : "277840753168891904",
  "in_reply_to_user_id" : 20932488,
  "text" : "@TheAntonioNeves Choose your filters wisely. :)",
  "id" : 277840753168891904,
  "in_reply_to_status_id" : 277837533319139328,
  "created_at" : "Sun Dec 09 18:22:52 +0000 2012",
  "in_reply_to_screen_name" : "TheAntonioNeves",
  "in_reply_to_user_id_str" : "20932488",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Antonio Neves",
      "screen_name" : "TheAntonioNeves",
      "indices" : [ 0, 16 ],
      "id_str" : "20932488",
      "id" : 20932488
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "277832574938775552",
  "geo" : {
  },
  "id_str" : "277833902435995648",
  "in_reply_to_user_id" : 20932488,
  "text" : "@TheAntonioNeves Isn't everything through a filter? Our senses and brain are massive filters.",
  "id" : 277833902435995648,
  "in_reply_to_status_id" : 277832574938775552,
  "created_at" : "Sun Dec 09 17:55:38 +0000 2012",
  "in_reply_to_screen_name" : "TheAntonioNeves",
  "in_reply_to_user_id_str" : "20932488",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 67 ],
      "url" : "http://t.co/prWtGWup",
      "expanded_url" : "http://flic.kr/p/dzDgkb",
      "display_url" : "flic.kr/p/dzDgkb"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.555499, -122.311 ]
  },
  "id_str" : "277634661948194817",
  "text" : "8:36pm Niko partying late at the Luxury Beacon http://t.co/prWtGWup",
  "id" : 277634661948194817,
  "created_at" : "Sun Dec 09 04:43:56 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "April Schiller",
      "screen_name" : "the_april",
      "indices" : [ 8, 18 ],
      "id_str" : "16644937",
      "id" : 16644937
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 97 ],
      "url" : "http://t.co/P1qZQayx",
      "expanded_url" : "http://4sq.com/WRQx9C",
      "display_url" : "4sq.com/WRQx9C"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.5604044624, -122.3108653823 ]
  },
  "id_str" : "277608875648233472",
  "text" : "Warming @the_april's awesome new house! (@ Luxury Beacon w/ 2 others) [pic]: http://t.co/P1qZQayx",
  "id" : 277608875648233472,
  "created_at" : "Sun Dec 09 03:01:28 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard Harrison",
      "screen_name" : "a_rich_life",
      "indices" : [ 1, 13 ],
      "id_str" : "260919174",
      "id" : 260919174
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "277593119845920768",
  "geo" : {
  },
  "id_str" : "277594762884833280",
  "in_reply_to_user_id" : 260919174,
  "text" : ".@a_rich_life What's depressing is when we're told over and over that something is easy, and yet we repeatedly fail at it.",
  "id" : 277594762884833280,
  "in_reply_to_status_id" : 277593119845920768,
  "created_at" : "Sun Dec 09 02:05:23 +0000 2012",
  "in_reply_to_screen_name" : "a_rich_life",
  "in_reply_to_user_id_str" : "260919174",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://bufferapp.com\" rel=\"nofollow\">Buffer</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 61 ],
      "url" : "http://t.co/BDWgZS36",
      "expanded_url" : "http://bit.ly/SHkrh3",
      "display_url" : "bit.ly/SHkrh3"
    } ]
  },
  "geo" : {
  },
  "id_str" : "277576594736943104",
  "text" : "“Anything is possible” - Way of the Duck http://t.co/BDWgZS36",
  "id" : 277576594736943104,
  "created_at" : "Sun Dec 09 00:53:11 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "277540969639985152",
  "text" : "All of these Top 10 Tricks articles have the added benefit of being easily republished as Top 10 Debunked Myths in a month.",
  "id" : 277540969639985152,
  "created_at" : "Sat Dec 08 22:31:38 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Wolfram",
      "screen_name" : "stephen_wolfram",
      "indices" : [ 41, 57 ],
      "id_str" : "31586578",
      "id" : 31586578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 137 ],
      "url" : "http://t.co/T5Nqz0TK",
      "expanded_url" : "http://wolfr.am/TFNCQh",
      "display_url" : "wolfr.am/TFNCQh"
    } ]
  },
  "geo" : {
  },
  "id_str" : "277514864031834112",
  "text" : "Always up to something interesting... RT @stephen_wolfram: A big new idea of Mathematica 9: the Predictive Interface http://t.co/T5Nqz0TK",
  "id" : 277514864031834112,
  "created_at" : "Sat Dec 08 20:47:54 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jad Abumrad",
      "screen_name" : "JadAbumrad",
      "indices" : [ 3, 14 ],
      "id_str" : "135316691",
      "id" : 135316691
    }, {
      "name" : "Rowan Singh",
      "screen_name" : "rowansingh",
      "indices" : [ 47, 58 ],
      "id_str" : "19239462",
      "id" : 19239462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "277513642008793088",
  "text" : "RT @JadAbumrad: The moral ?s posed by twitter “@rowansingh: Your child is being eaten by a camel. Do u a) save him or b) take a photo ht ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Rowan Singh",
        "screen_name" : "rowansingh",
        "indices" : [ 31, 42 ],
        "id_str" : "19239462",
        "id" : 19239462
      } ],
      "media" : [ {
        "expanded_url" : "http://twitter.com/rowansingh/status/277425009595662337/photo/1",
        "indices" : [ 118, 138 ],
        "url" : "http://t.co/LXoXeP3b",
        "media_url" : "http://pbs.twimg.com/media/A9mck42CQAE3JUO.jpg",
        "id_str" : "277425009608245249",
        "id" : 277425009608245249,
        "media_url_https" : "https://pbs.twimg.com/media/A9mck42CQAE3JUO.jpg",
        "sizes" : [ {
          "h" : 425,
          "resize" : "fit",
          "w" : 637
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 425,
          "resize" : "fit",
          "w" : 637
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com/LXoXeP3b"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "277512766691082240",
    "text" : "The moral ?s posed by twitter “@rowansingh: Your child is being eaten by a camel. Do u a) save him or b) take a photo http://t.co/LXoXeP3b”",
    "id" : 277512766691082240,
    "created_at" : "Sat Dec 08 20:39:34 +0000 2012",
    "user" : {
      "name" : "Jad Abumrad",
      "screen_name" : "JadAbumrad",
      "protected" : false,
      "id_str" : "135316691",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1529014082/Jad-Pic2_normal.jpg",
      "id" : 135316691,
      "verified" : true
    }
  },
  "id" : 277513642008793088,
  "created_at" : "Sat Dec 08 20:43:02 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "277502032485687297",
  "text" : "\"Everything you read online is true, unless it's something you actually know about.\" - somewhere online",
  "id" : 277502032485687297,
  "created_at" : "Sat Dec 08 19:56:54 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.apple.com\" rel=\"nofollow\">iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jumping",
      "indices" : [ 38, 46 ]
    } ],
    "urls" : [ {
      "indices" : [ 17, 37 ],
      "url" : "http://t.co/nbic1LOj",
      "expanded_url" : "http://cinemagr.am/show/68885864",
      "display_url" : "cinemagr.am/show/68885864"
    } ]
  },
  "geo" : {
  },
  "id_str" : "277495430147883009",
  "text" : "Cine: Trampoline http://t.co/nbic1LOj #jumping",
  "id" : 277495430147883009,
  "created_at" : "Sat Dec 08 19:30:40 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Galligan",
      "screen_name" : "mg",
      "indices" : [ 3, 6 ],
      "id_str" : "607",
      "id" : 607
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 85 ],
      "url" : "http://t.co/yCC6BEXa",
      "expanded_url" : "http://cir.ca/story/bitcoin-gains-bank-status/69157",
      "display_url" : "cir.ca/story/bitcoin-…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "277481761531916288",
  "text" : "RT @mg: Bitcoin gains 'bank' status. This is pretty interesting. http://t.co/yCC6BEXa",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 57, 77 ],
        "url" : "http://t.co/yCC6BEXa",
        "expanded_url" : "http://cir.ca/story/bitcoin-gains-bank-status/69157",
        "display_url" : "cir.ca/story/bitcoin-…"
      } ]
    },
    "geo" : {
    },
    "id_str" : "277477360129953792",
    "text" : "Bitcoin gains 'bank' status. This is pretty interesting. http://t.co/yCC6BEXa",
    "id" : 277477360129953792,
    "created_at" : "Sat Dec 08 18:18:52 +0000 2012",
    "user" : {
      "name" : "Matt Galligan",
      "screen_name" : "mg",
      "protected" : false,
      "id_str" : "607",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2303024416/forest_normal.jpg",
      "id" : 607,
      "verified" : false
    }
  },
  "id" : 277481761531916288,
  "created_at" : "Sat Dec 08 18:36:21 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 123 ],
      "url" : "http://t.co/8wO2FarV",
      "expanded_url" : "http://www.thedailyshow.com/full-episodes/thu-december-6-2012-chris-christie",
      "display_url" : "thedailyshow.com/full-episodes/…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "277480948243767298",
  "text" : "An actual productive/interesting political discussion between Jon Stewart and Chris Christie occurred: http://t.co/8wO2FarV",
  "id" : 277480948243767298,
  "created_at" : "Sat Dec 08 18:33:08 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Santangelo",
      "screen_name" : "endquote",
      "indices" : [ 0, 9 ],
      "id_str" : "408",
      "id" : 408
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "277247523771531264",
  "geo" : {
  },
  "id_str" : "277309663601635328",
  "in_reply_to_user_id" : 408,
  "text" : "@endquote I do! But only half the time. My team's all in SF.",
  "id" : 277309663601635328,
  "in_reply_to_status_id" : 277247523771531264,
  "created_at" : "Sat Dec 08 07:12:30 +0000 2012",
  "in_reply_to_screen_name" : "endquote",
  "in_reply_to_user_id_str" : "408",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "benji shine",
      "screen_name" : "bshine",
      "indices" : [ 0, 7 ],
      "id_str" : "7305682",
      "id" : 7305682
    }, {
      "name" : "Dan Becker",
      "screen_name" : "doofusdan",
      "indices" : [ 8, 18 ],
      "id_str" : "11153642",
      "id" : 11153642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "277265666409644032",
  "geo" : {
  },
  "id_str" : "277309032019140609",
  "in_reply_to_user_id" : 7305682,
  "text" : "@bshine @doofusdan Oops, if it is they forgot to tell me. :)",
  "id" : 277309032019140609,
  "in_reply_to_status_id" : 277265666409644032,
  "created_at" : "Sat Dec 08 07:10:00 +0000 2012",
  "in_reply_to_screen_name" : "bshine",
  "in_reply_to_user_id_str" : "7305682",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "277307769319743488",
  "text" : "Uh oh I'm watching Game of Thrones.",
  "id" : 277307769319743488,
  "created_at" : "Sat Dec 08 07:04:58 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 60 ],
      "url" : "http://t.co/VJubRDbp",
      "expanded_url" : "http://flic.kr/p/dzphto",
      "display_url" : "flic.kr/p/dzphto"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6205, -122.288167 ]
  },
  "id_str" : "277270805249945603",
  "text" : "8:36pm Dinner at Daniel and Brangien's! http://t.co/VJubRDbp",
  "id" : 277270805249945603,
  "created_at" : "Sat Dec 08 04:38:06 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/busterbenson/status/277230522181230592/photo/1",
      "indices" : [ 34, 54 ],
      "url" : "http://t.co/mCVjdkqO",
      "media_url" : "http://pbs.twimg.com/media/A9jrsOvCIAAWWEc.jpg",
      "id_str" : "277230522185424896",
      "id" : 277230522185424896,
      "media_url_https" : "https://pbs.twimg.com/media/A9jrsOvCIAAWWEc.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com/mCVjdkqO"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "277230522181230592",
  "text" : "View from Twitter Seattle office. http://t.co/mCVjdkqO",
  "id" : 277230522181230592,
  "created_at" : "Sat Dec 08 01:58:02 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Expereal",
      "screen_name" : "expereal",
      "indices" : [ 0, 9 ],
      "id_str" : "580504676",
      "id" : 580504676
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "277142974738075648",
  "geo" : {
  },
  "id_str" : "277186028182319104",
  "in_reply_to_user_id" : 580504676,
  "text" : "@expereal I have! Liking it so far but payoff for tracking is a little low...",
  "id" : 277186028182319104,
  "in_reply_to_status_id" : 277142974738075648,
  "created_at" : "Fri Dec 07 23:01:13 +0000 2012",
  "in_reply_to_screen_name" : "expereal",
  "in_reply_to_user_id_str" : "580504676",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Victor Mathieux",
      "screen_name" : "VictorMathieux",
      "indices" : [ 0, 15 ],
      "id_str" : "178841000",
      "id" : 178841000
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "277121566364561408",
  "geo" : {
  },
  "id_str" : "277124676780716034",
  "in_reply_to_user_id" : 178841000,
  "text" : "@VictorMathieux The exciting calm...",
  "id" : 277124676780716034,
  "in_reply_to_status_id" : 277121566364561408,
  "created_at" : "Fri Dec 07 18:57:26 +0000 2012",
  "in_reply_to_screen_name" : "VictorMathieux",
  "in_reply_to_user_id_str" : "178841000",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Leys",
      "screen_name" : "heyryanleys",
      "indices" : [ 0, 12 ],
      "id_str" : "16036987",
      "id" : 16036987
    }, {
      "name" : "Simple",
      "screen_name" : "Simplify",
      "indices" : [ 124, 133 ],
      "id_str" : "71165241",
      "id" : 71165241
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "276927461088964608",
  "geo" : {
  },
  "id_str" : "277100465148293120",
  "in_reply_to_user_id" : 16036987,
  "text" : "@heyryanleys I do! I send a flat $X budget to the account every paycheck, and use it for all of my day-to-day expenses. /cc @Simplify",
  "id" : 277100465148293120,
  "in_reply_to_status_id" : 276927461088964608,
  "created_at" : "Fri Dec 07 17:21:13 +0000 2012",
  "in_reply_to_screen_name" : "heyryanleys",
  "in_reply_to_user_id_str" : "16036987",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagr.am\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 55 ],
      "url" : "http://t.co/8cj709KD",
      "expanded_url" : "http://instagr.am/p/S7O9DzI0EK/",
      "display_url" : "instagr.am/p/S7O9DzI0EK/"
    } ]
  },
  "geo" : {
  },
  "id_str" : "276938748485328896",
  "text" : "8:36pm Dinner at Ryan and Carla's! http://t.co/8cj709KD",
  "id" : 276938748485328896,
  "created_at" : "Fri Dec 07 06:38:37 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 112 ],
      "url" : "http://t.co/2Gc1YdCM",
      "expanded_url" : "http://gigaom.com/video/netflix-ted-sarandos-ubs-media/",
      "display_url" : "gigaom.com/video/netflix-…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "276784030786129920",
  "text" : "How Netflix is changing tv. I especially like the idea of releasing entire seasons at once. http://t.co/2Gc1YdCM",
  "id" : 276784030786129920,
  "created_at" : "Thu Dec 06 20:23:49 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "lawblob",
      "screen_name" : "lawblob",
      "indices" : [ 3, 11 ],
      "id_str" : "41875694",
      "id" : 41875694
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "276766731953909760",
  "text" : "RT @lawblob: i like to keep my friends close &amp; haters closer. but both theoretical and in my phone",
  "retweeted_status" : {
    "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "276766500969390081",
    "text" : "i like to keep my friends close &amp; haters closer. but both theoretical and in my phone",
    "id" : 276766500969390081,
    "created_at" : "Thu Dec 06 19:14:10 +0000 2012",
    "user" : {
      "name" : "lawblob",
      "screen_name" : "lawblob",
      "protected" : false,
      "id_str" : "41875694",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2974765538/f16e648383ee5c35da1184e188580b7a_normal.jpeg",
      "id" : 41875694,
      "verified" : false
    }
  },
  "id" : 276766731953909760,
  "created_at" : "Thu Dec 06 19:15:05 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "girl jo",
      "screen_name" : "octavekitten",
      "indices" : [ 0, 13 ],
      "id_str" : "16366882",
      "id" : 16366882
    }, {
      "name" : "Deacon 87",
      "screen_name" : "Deacon87",
      "indices" : [ 14, 23 ],
      "id_str" : "17628107",
      "id" : 17628107
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "276752664501551104",
  "geo" : {
  },
  "id_str" : "276756301340610562",
  "in_reply_to_user_id" : 16366882,
  "text" : "@octavekitten @deacon87 And we have super movers packing for us... stoked to not have to lift a finger.",
  "id" : 276756301340610562,
  "in_reply_to_status_id" : 276752664501551104,
  "created_at" : "Thu Dec 06 18:33:38 +0000 2012",
  "in_reply_to_screen_name" : "octavekitten",
  "in_reply_to_user_id_str" : "16366882",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "girl jo",
      "screen_name" : "octavekitten",
      "indices" : [ 0, 13 ],
      "id_str" : "16366882",
      "id" : 16366882
    }, {
      "name" : "Deacon 87",
      "screen_name" : "Deacon87",
      "indices" : [ 14, 23 ],
      "id_str" : "17628107",
      "id" : 17628107
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "276752664501551104",
  "geo" : {
  },
  "id_str" : "276756053297872896",
  "in_reply_to_user_id" : 16366882,
  "text" : "@octavekitten @deacon87 We're done with all the outdoor stuff but would probably like to keep plants around a bit longer.",
  "id" : 276756053297872896,
  "in_reply_to_status_id" : 276752664501551104,
  "created_at" : "Thu Dec 06 18:32:39 +0000 2012",
  "in_reply_to_screen_name" : "octavekitten",
  "in_reply_to_user_id_str" : "16366882",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Deacon 87",
      "screen_name" : "Deacon87",
      "indices" : [ 0, 9 ],
      "id_str" : "17628107",
      "id" : 17628107
    }, {
      "name" : "girl jo",
      "screen_name" : "octavekitten",
      "indices" : [ 10, 23 ],
      "id_str" : "16366882",
      "id" : 16366882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "276751650968985602",
  "geo" : {
  },
  "id_str" : "276752408149897217",
  "in_reply_to_user_id" : 17628107,
  "text" : "@Deacon87 @octavekitten Awesome. Let me know when you'd like to come pick stuff up!",
  "id" : 276752408149897217,
  "in_reply_to_status_id" : 276751650968985602,
  "created_at" : "Thu Dec 06 18:18:10 +0000 2012",
  "in_reply_to_screen_name" : "Deacon87",
  "in_reply_to_user_id_str" : "17628107",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "girl jo",
      "screen_name" : "octavekitten",
      "indices" : [ 0, 13 ],
      "id_str" : "16366882",
      "id" : 16366882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "276750651046907904",
  "geo" : {
  },
  "id_str" : "276751358374326272",
  "in_reply_to_user_id" : 16366882,
  "text" : "@octavekitten You probably don't want my old jeans and socks, but do you want a BBQ, lawn chairs, or plants?",
  "id" : 276751358374326272,
  "in_reply_to_status_id" : 276750651046907904,
  "created_at" : "Thu Dec 06 18:14:00 +0000 2012",
  "in_reply_to_screen_name" : "octavekitten",
  "in_reply_to_user_id_str" : "16366882",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "276750494645514240",
  "text" : "Someone just came over to assess our moving strategy for Jan 19th (to SF). Excited!",
  "id" : 276750494645514240,
  "created_at" : "Thu Dec 06 18:10:34 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anil Dash",
      "screen_name" : "anildash",
      "indices" : [ 3, 12 ],
      "id_str" : "36823",
      "id" : 36823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "276506512879398912",
  "text" : "RT @anildash: Tech media are like climate deniers about facts like Microsoft revenues, Facebook malignancy, or anything outside the U.S. ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TechTruthers",
        "indices" : [ 123, 136 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "276505547421913088",
    "text" : "Tech media are like climate deniers about facts like Microsoft revenues, Facebook malignancy, or anything outside the U.S. #TechTruthers",
    "id" : 276505547421913088,
    "created_at" : "Thu Dec 06 01:57:14 +0000 2012",
    "user" : {
      "name" : "Anil Dash",
      "screen_name" : "anildash",
      "protected" : false,
      "id_str" : "36823",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2819125443/08240a3283301594794bcf6333ce8e6f_normal.png",
      "id" : 36823,
      "verified" : true
    }
  },
  "id" : 276506512879398912,
  "created_at" : "Thu Dec 06 02:01:04 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://bufferapp.com\" rel=\"nofollow\">Buffer</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "quantifiedself",
      "indices" : [ 81, 96 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 123 ],
      "url" : "http://t.co/GDrTzQxF",
      "expanded_url" : "http://bit.ly/RCdSPU",
      "display_url" : "bit.ly/RCdSPU"
    } ]
  },
  "geo" : {
  },
  "id_str" : "276410708785238018",
  "text" : "\"Why I track\" - a history of my self-tracking projects + insights from my recent #quantifiedself talk: http://t.co/GDrTzQxF",
  "id" : 276410708785238018,
  "created_at" : "Wed Dec 05 19:40:23 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Carmichael",
      "screen_name" : "accarmichael",
      "indices" : [ 0, 13 ],
      "id_str" : "15916492",
      "id" : 15916492
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "276409356772335616",
  "geo" : {
  },
  "id_str" : "276410266844004352",
  "in_reply_to_user_id" : 15916492,
  "text" : "@accarmichael Thanks! :)",
  "id" : 276410266844004352,
  "in_reply_to_status_id" : 276409356772335616,
  "created_at" : "Wed Dec 05 19:38:37 +0000 2012",
  "in_reply_to_screen_name" : "accarmichael",
  "in_reply_to_user_id_str" : "15916492",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "276351284053962752",
  "text" : "Striving for fairness can move us towards both acceptance of equality and declarations of war.",
  "id" : 276351284053962752,
  "created_at" : "Wed Dec 05 15:44:15 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lada Adamic",
      "screen_name" : "ladamic",
      "indices" : [ 3, 11 ],
      "id_str" : "2329921",
      "id" : 2329921
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 83 ],
      "url" : "http://t.co/i9U7rNUP",
      "expanded_url" : "http://www.ladamic.com/wordpress/?p=547",
      "display_url" : "ladamic.com/wordpress/?p=5…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "276211155876331520",
  "text" : "RT @ladamic: My initial thoughts on Coursera vs. the classroom http://t.co/i9U7rNUP",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 50, 70 ],
        "url" : "http://t.co/i9U7rNUP",
        "expanded_url" : "http://www.ladamic.com/wordpress/?p=547",
        "display_url" : "ladamic.com/wordpress/?p=5…"
      } ]
    },
    "geo" : {
    },
    "id_str" : "274589593741975552",
    "text" : "My initial thoughts on Coursera vs. the classroom http://t.co/i9U7rNUP",
    "id" : 274589593741975552,
    "created_at" : "Fri Nov 30 19:03:55 +0000 2012",
    "user" : {
      "name" : "Lada Adamic",
      "screen_name" : "ladamic",
      "protected" : false,
      "id_str" : "2329921",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2617103633/wv6aqjyiko1fjycskkk2_normal.png",
      "id" : 2329921,
      "verified" : false
    }
  },
  "id" : 276211155876331520,
  "created_at" : "Wed Dec 05 06:27:25 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Brault",
      "screen_name" : "adambrault",
      "indices" : [ 0, 11 ],
      "id_str" : "1568",
      "id" : 1568
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 132 ],
      "url" : "http://t.co/M4YTVWEi",
      "expanded_url" : "http://branch.com/b/disconnect-saturdays",
      "display_url" : "branch.com/b/disconnect-s…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "276208693232689152",
  "in_reply_to_user_id" : 1568,
  "text" : "@adambrault A few people are talking about various strategies to get uninterrupted thought time back over here: http://t.co/M4YTVWEi",
  "id" : 276208693232689152,
  "created_at" : "Wed Dec 05 06:17:38 +0000 2012",
  "in_reply_to_screen_name" : "adambrault",
  "in_reply_to_user_id_str" : "1568",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.apple.com\" rel=\"nofollow\">Safari on iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 89 ],
      "url" : "http://t.co/zWL35bEs",
      "expanded_url" : "http://adambrault.com/post/37201680402/i-quit-twitter-for-a-month-and-it-completely-changed-my",
      "display_url" : "adambrault.com/post/372016804…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "276207563245228032",
  "text" : "\"The single most valuable resource I have is uninterrupted thought.\" http://t.co/zWL35bEs",
  "id" : 276207563245228032,
  "created_at" : "Wed Dec 05 06:13:09 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 64 ],
      "url" : "http://t.co/i6UXhKEM",
      "expanded_url" : "http://flic.kr/p/dyCKWV",
      "display_url" : "flic.kr/p/dyCKWV"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.777833, -122.415 ]
  },
  "id_str" : "276187383064563712",
  "text" : "8:36pm Today I managed to take off my shoes http://t.co/i6UXhKEM",
  "id" : 276187383064563712,
  "created_at" : "Wed Dec 05 04:52:58 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 0, 10 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "276128676758843392",
  "geo" : {
  },
  "id_str" : "276151314201849856",
  "in_reply_to_user_id" : 7362142,
  "text" : "@kellianne Oh, crap, just saw this. That's terrible. Niko's a frat rock fan.",
  "id" : 276151314201849856,
  "in_reply_to_status_id" : 276128676758843392,
  "created_at" : "Wed Dec 05 02:29:38 +0000 2012",
  "in_reply_to_screen_name" : "kellianne",
  "in_reply_to_user_id_str" : "7362142",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 0, 10 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "276128860872003585",
  "geo" : {
  },
  "id_str" : "276151128188674048",
  "in_reply_to_user_id" : 7362142,
  "text" : "@kellianne What was the song?",
  "id" : 276151128188674048,
  "in_reply_to_status_id" : 276128860872003585,
  "created_at" : "Wed Dec 05 02:28:54 +0000 2012",
  "in_reply_to_screen_name" : "kellianne",
  "in_reply_to_user_id_str" : "7362142",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://bufferapp.com\" rel=\"nofollow\">Buffer</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http://t.co/dx4PhLju",
      "expanded_url" : "http://bit.ly/Sw2TV6",
      "display_url" : "bit.ly/Sw2TV6"
    } ]
  },
  "geo" : {
  },
  "id_str" : "276127685661577217",
  "text" : "Comics of all the greatest hits of \"weird twitter\". Surprisingly, the plain tweets are often funnier than the drawings. http://t.co/dx4PhLju",
  "id" : 276127685661577217,
  "created_at" : "Wed Dec 05 00:55:45 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "fredtrotter",
      "screen_name" : "fredtrotter",
      "indices" : [ 0, 12 ],
      "id_str" : "16971428",
      "id" : 16971428
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "276062916120309760",
  "geo" : {
  },
  "id_str" : "276120822534508545",
  "in_reply_to_user_id" : 16971428,
  "text" : "@fredtrotter Thanks! I'm enjoying myself here.",
  "id" : 276120822534508545,
  "in_reply_to_status_id" : 276062916120309760,
  "created_at" : "Wed Dec 05 00:28:28 +0000 2012",
  "in_reply_to_screen_name" : "fredtrotter",
  "in_reply_to_user_id_str" : "16971428",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "276061134191198209",
  "text" : "Want to ditch your old job and work on the awesome Platform Services team at Twitter (which I'm on)? Email me! buster@twitter.com",
  "id" : 276061134191198209,
  "created_at" : "Tue Dec 04 20:31:18 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ingopixel",
      "screen_name" : "ingopixel",
      "indices" : [ 0, 10 ],
      "id_str" : "7943892",
      "id" : 7943892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "275824851661516801",
  "geo" : {
  },
  "id_str" : "275826186859446272",
  "in_reply_to_user_id" : 7943892,
  "text" : "@ingopixel You are the only person I know who has the willpower to follow that rule.",
  "id" : 275826186859446272,
  "in_reply_to_status_id" : 275824851661516801,
  "created_at" : "Tue Dec 04 04:57:42 +0000 2012",
  "in_reply_to_screen_name" : "ingopixel",
  "in_reply_to_user_id_str" : "7943892",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 58 ],
      "url" : "http://t.co/Y0G8pd20",
      "expanded_url" : "http://flic.kr/p/dyo6Wr",
      "display_url" : "flic.kr/p/dyo6Wr"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.778, -122.414834 ]
  },
  "id_str" : "275824263485849600",
  "text" : "8:36pm Too tired to take off my shoes http://t.co/Y0G8pd20",
  "id" : 275824263485849600,
  "created_at" : "Tue Dec 04 04:50:03 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Davidson",
      "screen_name" : "mikeindustries",
      "indices" : [ 3, 18 ],
      "id_str" : "74523",
      "id" : 74523
    }, {
      "name" : "Dave Dearman",
      "screen_name" : "dearman",
      "indices" : [ 82, 90 ],
      "id_str" : "14061523",
      "id" : 14061523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "275692594527363072",
  "text" : "RT @mikeindustries: \"You can still 'be' something and just really suck at it.\" -- @dearman on why he can eat meat and still be vegan.",
  "retweeted_status" : {
    "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Dave Dearman",
        "screen_name" : "dearman",
        "indices" : [ 62, 70 ],
        "id_str" : "14061523",
        "id" : 14061523
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "275686697738571776",
    "text" : "\"You can still 'be' something and just really suck at it.\" -- @dearman on why he can eat meat and still be vegan.",
    "id" : 275686697738571776,
    "created_at" : "Mon Dec 03 19:43:25 +0000 2012",
    "user" : {
      "name" : "Mike Davidson",
      "screen_name" : "mikeindustries",
      "protected" : false,
      "id_str" : "74523",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1241788588/twitter_avatar_normal.jpg",
      "id" : 74523,
      "verified" : false
    }
  },
  "id" : 275692594527363072,
  "created_at" : "Mon Dec 03 20:06:51 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Davidson",
      "screen_name" : "mikeindustries",
      "indices" : [ 0, 15 ],
      "id_str" : "74523",
      "id" : 74523
    }, {
      "name" : "Dave Dearman",
      "screen_name" : "dearman",
      "indices" : [ 16, 24 ],
      "id_str" : "14061523",
      "id" : 14061523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "275686697738571776",
  "geo" : {
  },
  "id_str" : "275692568950484992",
  "in_reply_to_user_id" : 74523,
  "text" : "@mikeindustries @dearman That just blew my mind. I love that logic.",
  "id" : 275692568950484992,
  "in_reply_to_status_id" : 275686697738571776,
  "created_at" : "Mon Dec 03 20:06:45 +0000 2012",
  "in_reply_to_screen_name" : "mikeindustries",
  "in_reply_to_user_id_str" : "74523",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benedict XVI",
      "screen_name" : "Pontifex",
      "indices" : [ 83, 92 ],
      "id_str" : "500704345",
      "id" : 500704345
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ff",
      "indices" : [ 93, 96 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "275672896045719552",
  "text" : "While the Pope prepares his first tweet, he already follows 7 versions of himself. @pontifex #ff",
  "id" : 275672896045719552,
  "created_at" : "Mon Dec 03 18:48:34 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagr.am\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 68 ],
      "url" : "http://t.co/ueikF8gP",
      "expanded_url" : "http://instagr.am/p/Sw85F0o0KX/",
      "display_url" : "instagr.am/p/Sw85F0o0KX/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6193817928, -122.323804996 ]
  },
  "id_str" : "275491613478879233",
  "text" : "Gonna miss the Vain crew @ FRED Wildlife REFUGE http://t.co/ueikF8gP",
  "id" : 275491613478879233,
  "created_at" : "Mon Dec 03 06:48:13 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagr.am\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 66 ],
      "url" : "http://t.co/UgPGkAJP",
      "expanded_url" : "http://instagr.am/p/Sw1yV0I0G9/",
      "display_url" : "instagr.am/p/Sw1yV0I0G9/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6193817928, -122.323804996 ]
  },
  "id_str" : "275476108982505472",
  "text" : "8:36pm Heavenly Spies! @ FRED Wildlife REFUGE http://t.co/UgPGkAJP",
  "id" : 275476108982505472,
  "created_at" : "Mon Dec 03 05:46:37 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagr.am\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 88 ],
      "url" : "http://t.co/J7eZyaaZ",
      "expanded_url" : "http://instagr.am/p/SuJQ0Yo0I9/",
      "display_url" : "instagr.am/p/SuJQ0Yo0I9/"
    } ]
  },
  "geo" : {
  },
  "id_str" : "275096645031575552",
  "text" : "\"It's flying really high\" presented as an argument against bed time http://t.co/J7eZyaaZ",
  "id" : 275096645031575552,
  "created_at" : "Sun Dec 02 04:38:45 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagr.am\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 54 ],
      "url" : "http://t.co/eY5V7mY4",
      "expanded_url" : "http://instagr.am/p/SuFrbLI0FD/",
      "display_url" : "instagr.am/p/SuFrbLI0FD/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6082245871, -122.340316772 ]
  },
  "id_str" : "275088686528483328",
  "text" : "Family by the gum wall @ Gum Wall http://t.co/eY5V7mY4",
  "id" : 275088686528483328,
  "created_at" : "Sun Dec 02 04:07:08 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagr.am\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 50 ],
      "url" : "http://t.co/5eT8Hl40",
      "expanded_url" : "http://instagr.am/p/StHWYGo0Lk/",
      "display_url" : "instagr.am/p/StHWYGo0Lk/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6113709964, -122.342805862 ]
  },
  "id_str" : "274951687817547776",
  "text" : "Cutting hair is an art @ Vain http://t.co/5eT8Hl40",
  "id" : 274951687817547776,
  "created_at" : "Sat Dec 01 19:02:45 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://timehop.com/\" rel=\"nofollow\">Timehop</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 61 ],
      "url" : "http://t.co/2XlbfBQH",
      "expanded_url" : "http://t.imehop.com/Rrn9u5",
      "display_url" : "t.imehop.com/Rrn9u5"
    } ]
  },
  "geo" : {
  },
  "id_str" : "274913658021240833",
  "text" : "Still thinking about this a year later.  http://t.co/2XlbfBQH",
  "id" : 274913658021240833,
  "created_at" : "Sat Dec 01 16:31:38 +0000 2012",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
} ]