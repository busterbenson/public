Grailbird.data.tweets_2013_03 = 
 [ {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http://t.co/1aIe77akZI",
      "expanded_url" : "http://flic.kr/p/e7K6n5",
      "display_url" : "flic.kr/p/e7K6n5"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859666, -122.2755 ]
  },
  "id_str" : "318568538744971264",
  "text" : "8:36pm Trying to pick book number 2 while we wait http://t.co/1aIe77akZI",
  "id" : 318568538744971264,
  "created_at" : "Mon Apr 01 03:40:33 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 62 ],
      "url" : "http://t.co/VsyrpcYpTs",
      "expanded_url" : "http://flic.kr/p/e7wMjP",
      "display_url" : "flic.kr/p/e7wMjP"
    } ]
  },
  "geo" : {
  },
  "id_str" : "318456861433151488",
  "text" : "Yup, they're roasting a lamb on a cross http://t.co/VsyrpcYpTs",
  "id" : 318456861433151488,
  "created_at" : "Sun Mar 31 20:16:47 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alicetiara",
      "screen_name" : "alicetiara",
      "indices" : [ 0, 11 ],
      "id_str" : "784078",
      "id" : 784078
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "318411057213362176",
  "geo" : {
  },
  "id_str" : "318413146056454144",
  "in_reply_to_user_id" : 784078,
  "text" : "@alicetiara I thought it covered both well but did emphasize the \"think globally act locally\" pragmatic approach that is actionable by all.",
  "id" : 318413146056454144,
  "in_reply_to_status_id" : 318411057213362176,
  "created_at" : "Sun Mar 31 17:23:04 +0000 2013",
  "in_reply_to_screen_name" : "alicetiara",
  "in_reply_to_user_id_str" : "784078",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://vine.co\" rel=\"nofollow\">Vine - Make a Scene</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 43 ],
      "url" : "https://t.co/1r0T8pl6Dr",
      "expanded_url" : "https://vine.co/v/bIqTbhbQ1ht",
      "display_url" : "vine.co/v/bIqTbhbQ1ht"
    } ]
  },
  "geo" : {
  },
  "id_str" : "318394660190048256",
  "text" : "A slinky! A slinky! https://t.co/1r0T8pl6Dr",
  "id" : 318394660190048256,
  "created_at" : "Sun Mar 31 16:09:37 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://vine.co\" rel=\"nofollow\">Vine - Make a Scene</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 46 ],
      "url" : "https://t.co/m3P07BWZqd",
      "expanded_url" : "https://vine.co/v/bIAYizeqeOQ",
      "display_url" : "vine.co/v/bIAYizeqeOQ"
    } ]
  },
  "geo" : {
  },
  "id_str" : "318369632408965120",
  "text" : "It's the Easter Froggy https://t.co/m3P07BWZqd",
  "id" : 318369632408965120,
  "created_at" : "Sun Mar 31 14:30:10 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Berkun",
      "screen_name" : "berkun",
      "indices" : [ 0, 7 ],
      "id_str" : "30495974",
      "id" : 30495974
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "318231109295042560",
  "geo" : {
  },
  "id_str" : "318231492616650752",
  "in_reply_to_user_id" : 30495974,
  "text" : "@berkun Same. Let's skip the bet and eat! PS I'm in SF now... you plan on visiting anytime soon? My trips to Sea are few these days.",
  "id" : 318231492616650752,
  "in_reply_to_status_id" : 318231109295042560,
  "created_at" : "Sun Mar 31 05:21:14 +0000 2013",
  "in_reply_to_screen_name" : "berkun",
  "in_reply_to_user_id_str" : "30495974",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Berkun",
      "screen_name" : "berkun",
      "indices" : [ 0, 7 ],
      "id_str" : "30495974",
      "id" : 30495974
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "318227673405067264",
  "geo" : {
  },
  "id_str" : "318230202125791233",
  "in_reply_to_user_id" : 30495974,
  "text" : "@berkun Deal. Though it's a bit unfair to you considering either you or Vine would have to die for you to win. Why are you anti-Vine?",
  "id" : 318230202125791233,
  "in_reply_to_status_id" : 318227673405067264,
  "created_at" : "Sun Mar 31 05:16:07 +0000 2013",
  "in_reply_to_screen_name" : "berkun",
  "in_reply_to_user_id_str" : "30495974",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Berkun",
      "screen_name" : "berkun",
      "indices" : [ 0, 7 ],
      "id_str" : "30495974",
      "id" : 30495974
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "318212427189743616",
  "geo" : {
  },
  "id_str" : "318226463872655360",
  "in_reply_to_user_id" : 30495974,
  "text" : "@berkun I'll take that bet.",
  "id" : 318226463872655360,
  "in_reply_to_status_id" : 318212427189743616,
  "created_at" : "Sun Mar 31 05:01:16 +0000 2013",
  "in_reply_to_screen_name" : "berkun",
  "in_reply_to_user_id_str" : "30495974",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 51 ],
      "url" : "http://t.co/7PpPilCGwc",
      "expanded_url" : "http://flic.kr/p/e7qCrC",
      "display_url" : "flic.kr/p/e7qCrC"
    } ]
  },
  "geo" : {
  },
  "id_str" : "318206682025062400",
  "text" : "8:36pm Look I tied a bow tie http://t.co/7PpPilCGwc",
  "id" : 318206682025062400,
  "created_at" : "Sun Mar 31 03:42:39 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://bufferapp.com\" rel=\"nofollow\">Buffer</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http://t.co/GBzYoYtsE4",
      "expanded_url" : "http://bit.ly/1114xDe",
      "display_url" : "bit.ly/1114xDe"
    } ]
  },
  "geo" : {
  },
  "id_str" : "317834594370076672",
  "text" : "Read this! \"It requires geeks to re-examine their own revenge fantasies of being outsiders who now rule the world...\" http://t.co/GBzYoYtsE4",
  "id" : 317834594370076672,
  "created_at" : "Sat Mar 30 03:04:07 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Govella",
      "screen_name" : "austingovella",
      "indices" : [ 0, 14 ],
      "id_str" : "2543461",
      "id" : 2543461
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "317822696689905664",
  "geo" : {
  },
  "id_str" : "317823844645752833",
  "in_reply_to_user_id" : 2543461,
  "text" : "@austingovella \"Thinking, Fast and Slow\" which is an awesome book.",
  "id" : 317823844645752833,
  "in_reply_to_status_id" : 317822696689905664,
  "created_at" : "Sat Mar 30 02:21:24 +0000 2013",
  "in_reply_to_screen_name" : "austingovella",
  "in_reply_to_user_id_str" : "2543461",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "317821503284596739",
  "text" : "\"Confidence is determined by the coherence of the best story that you can tell with the evidence at hand.\" - Kahneman",
  "id" : 317821503284596739,
  "created_at" : "Sat Mar 30 02:12:05 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Todd Berman",
      "screen_name" : "tberman",
      "indices" : [ 0, 8 ],
      "id_str" : "15275073",
      "id" : 15275073
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "317781833012088832",
  "geo" : {
  },
  "id_str" : "317792791214297088",
  "in_reply_to_user_id" : 15275073,
  "text" : "@tberman Do it!",
  "id" : 317792791214297088,
  "in_reply_to_status_id" : 317781833012088832,
  "created_at" : "Sat Mar 30 00:18:00 +0000 2013",
  "in_reply_to_screen_name" : "tberman",
  "in_reply_to_user_id_str" : "15275073",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://bufferapp.com\" rel=\"nofollow\">Buffer</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http://t.co/658HGyWoDv",
      "expanded_url" : "http://bit.ly/YP2U7w",
      "display_url" : "bit.ly/YP2U7w"
    } ]
  },
  "geo" : {
  },
  "id_str" : "317787037140926465",
  "text" : "Cyro is a giant self-aware robot jellyfish that could soon roam the seas:  http://t.co/658HGyWoDv",
  "id" : 317787037140926465,
  "created_at" : "Fri Mar 29 23:55:08 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Runner's World",
      "screen_name" : "runnersworld",
      "indices" : [ 3, 16 ],
      "id_str" : "14882900",
      "id" : 14882900
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http://t.co/HfGwdF8rn7",
      "expanded_url" : "http://ow.ly/jztlk",
      "display_url" : "ow.ly/jztlk"
    } ]
  },
  "geo" : {
  },
  "id_str" : "317774016150634497",
  "text" : "RT @runnersworld: Want to know if you're getting faster? This simple workout will help you track progress http://t.co/HfGwdF8rn7",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.hootsuite.com\" rel=\"nofollow\">HootSuite</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 88, 110 ],
        "url" : "http://t.co/HfGwdF8rn7",
        "expanded_url" : "http://ow.ly/jztlk",
        "display_url" : "ow.ly/jztlk"
      } ]
    },
    "geo" : {
    },
    "id_str" : "317773402851123201",
    "text" : "Want to know if you're getting faster? This simple workout will help you track progress http://t.co/HfGwdF8rn7",
    "id" : 317773402851123201,
    "created_at" : "Fri Mar 29 23:00:57 +0000 2013",
    "user" : {
      "name" : "Runner's World",
      "screen_name" : "runnersworld",
      "protected" : false,
      "id_str" : "14882900",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000109947263/1a5eace1c628a3043f3867322b8e812b_normal.jpeg",
      "id" : 14882900,
      "verified" : true
    }
  },
  "id" : 317774016150634497,
  "created_at" : "Fri Mar 29 23:03:24 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/buster/status/317713172666658816/photo/1",
      "indices" : [ 99, 121 ],
      "url" : "http://t.co/fqh8Kzn2nX",
      "media_url" : "http://pbs.twimg.com/media/BGi-cn2CMAAqX0N.jpg",
      "id_str" : "317713172670853120",
      "id" : 317713172670853120,
      "media_url_https" : "https://pbs.twimg.com/media/BGi-cn2CMAAqX0N.jpg",
      "sizes" : [ {
        "h" : 258,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 607,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 455,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 607,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com/fqh8Kzn2nX"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http://t.co/x692lhFvGQ",
      "expanded_url" : "http://www.collegehumor.com/article/6880782/12-game-of-thrones-house-sigils-for-the-internet",
      "display_url" : "collegehumor.com/article/688078\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "317713172666658816",
  "text" : "Count me in. \"House Twitter - Dark Wings, Dumb Words.\" Which house are you? http://t.co/x692lhFvGQ http://t.co/fqh8Kzn2nX",
  "id" : 317713172666658816,
  "created_at" : "Fri Mar 29 19:01:38 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Reeve S. Thompson ",
      "screen_name" : "Reeve",
      "indices" : [ 0, 6 ],
      "id_str" : "9317922",
      "id" : 9317922
    }, {
      "name" : "DietBet",
      "screen_name" : "DietBet",
      "indices" : [ 7, 15 ],
      "id_str" : "185399301",
      "id" : 185399301
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "317661003875774465",
  "geo" : {
  },
  "id_str" : "317661334277857280",
  "in_reply_to_user_id" : 9317922,
  "text" : "@Reeve @dietbet It really does.",
  "id" : 317661334277857280,
  "in_reply_to_status_id" : 317661003875774465,
  "created_at" : "Fri Mar 29 15:35:38 +0000 2013",
  "in_reply_to_screen_name" : "Reeve",
  "in_reply_to_user_id_str" : "9317922",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "newgoal",
      "indices" : [ 75, 83 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "317660563209609219",
  "text" : "965. Hit 165lbs by 4/26 (4 weeks from today) by sticking to the same plan. #newgoal",
  "id" : 317660563209609219,
  "created_at" : "Fri Mar 29 15:32:34 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DietBet",
      "screen_name" : "DietBet",
      "indices" : [ 12, 20 ],
      "id_str" : "185399301",
      "id" : 185399301
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/buster/status/317658345379082240/photo/1",
      "indices" : [ 91, 113 ],
      "url" : "http://t.co/oXzRNrZESj",
      "media_url" : "http://pbs.twimg.com/media/BGiMlQTCMAAoLIs.jpg",
      "id_str" : "317658345387470848",
      "id" : 317658345387470848,
      "media_url_https" : "https://pbs.twimg.com/media/BGiMlQTCMAAoLIs.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 577
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 577
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 603,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 577
      } ],
      "display_url" : "pic.twitter.com/oXzRNrZESj"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "317658345379082240",
  "text" : "966. Won my @dietbet! Lost 9.4lbs in 4 weeks by avoiding processed foods most of the time. http://t.co/oXzRNrZESj",
  "id" : 317658345379082240,
  "created_at" : "Fri Mar 29 15:23:46 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Fry",
      "screen_name" : "chfry",
      "indices" : [ 0, 6 ],
      "id_str" : "57963332",
      "id" : 57963332
    }, {
      "name" : "Simon Fell",
      "screen_name" : "superfell",
      "indices" : [ 7, 17 ],
      "id_str" : "17104583",
      "id" : 17104583
    }, {
      "name" : "Peter Morelli",
      "screen_name" : "pmorelli",
      "indices" : [ 18, 27 ],
      "id_str" : "14161459",
      "id" : 14161459
    }, {
      "name" : "Raffi Krikorian",
      "screen_name" : "raffi",
      "indices" : [ 28, 34 ],
      "id_str" : "8285392",
      "id" : 8285392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "317512415434637312",
  "geo" : {
  },
  "id_str" : "317517916230791169",
  "in_reply_to_user_id" : 57963332,
  "text" : "@chfry @superfell @pmorelli @raffi A Fire Upon The Deep by Vernor Vinge if you haven't already. Amazing.",
  "id" : 317517916230791169,
  "in_reply_to_status_id" : 317512415434637312,
  "created_at" : "Fri Mar 29 06:05:45 +0000 2013",
  "in_reply_to_screen_name" : "chfry",
  "in_reply_to_user_id_str" : "57963332",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amelia Greenhall",
      "screen_name" : "ameliagreenhall",
      "indices" : [ 0, 16 ],
      "id_str" : "246531241",
      "id" : 246531241
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "317504413935755264",
  "geo" : {
  },
  "id_str" : "317517040162328577",
  "in_reply_to_user_id" : 246531241,
  "text" : "@ameliagreenhall Can you cut it in half and mail it to me?",
  "id" : 317517040162328577,
  "in_reply_to_status_id" : 317504413935755264,
  "created_at" : "Fri Mar 29 06:02:16 +0000 2013",
  "in_reply_to_screen_name" : "ameliagreenhall",
  "in_reply_to_user_id_str" : "246531241",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Nobbs",
      "screen_name" : "michaelnobbs",
      "indices" : [ 3, 16 ],
      "id_str" : "6996832",
      "id" : 6996832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http://t.co/bw93pMfY1k",
      "expanded_url" : "http://buff.ly/152xYnc",
      "display_url" : "buff.ly/152xYnc"
    } ]
  },
  "geo" : {
  },
  "id_str" : "317516849837387776",
  "text" : "RT @michaelnobbs: Austin Kleon on writing post fatherhood http://t.co/bw93pMfY1k",
  "retweeted_status" : {
    "source" : "<a href=\"http://bufferapp.com\" rel=\"nofollow\">Buffer</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 40, 62 ],
        "url" : "http://t.co/bw93pMfY1k",
        "expanded_url" : "http://buff.ly/152xYnc",
        "display_url" : "buff.ly/152xYnc"
      } ]
    },
    "geo" : {
    },
    "id_str" : "317502643192860672",
    "text" : "Austin Kleon on writing post fatherhood http://t.co/bw93pMfY1k",
    "id" : 317502643192860672,
    "created_at" : "Fri Mar 29 05:05:03 +0000 2013",
    "user" : {
      "name" : "Michael Nobbs",
      "screen_name" : "michaelnobbs",
      "protected" : false,
      "id_str" : "6996832",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1145178262/twitter.avatar_normal.jpg",
      "id" : 6996832,
      "verified" : false
    }
  },
  "id" : 317516849837387776,
  "created_at" : "Fri Mar 29 06:01:30 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http://t.co/BQ01VnOYZo",
      "expanded_url" : "http://buswk.co/YH7ACl",
      "display_url" : "buswk.co/YH7ACl"
    } ]
  },
  "geo" : {
  },
  "id_str" : "317498587523203074",
  "text" : "How do I get me a bitcoin? \"Bitcoin May Be a Hoax. It May Also Be the Future\" http://t.co/BQ01VnOYZo",
  "id" : 317498587523203074,
  "created_at" : "Fri Mar 29 04:48:56 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http://t.co/Peq1e8A9p3",
      "expanded_url" : "http://flic.kr/p/e6Qh94",
      "display_url" : "flic.kr/p/e6Qh94"
    } ]
  },
  "geo" : {
  },
  "id_str" : "317481623157370880",
  "text" : "8:36pm Niko just advised me to breathe through my mouth since my nose is all stuffed up http://t.co/Peq1e8A9p3",
  "id" : 317481623157370880,
  "created_at" : "Fri Mar 29 03:41:32 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kc",
      "screen_name" : "kris",
      "indices" : [ 0, 5 ],
      "id_str" : "115734106",
      "id" : 115734106
    }, {
      "name" : "April Underwood",
      "screen_name" : "aunder",
      "indices" : [ 6, 13 ],
      "id_str" : "4265731",
      "id" : 4265731
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "317474175843442689",
  "geo" : {
  },
  "id_str" : "317478350165798912",
  "in_reply_to_user_id" : 115734106,
  "text" : "@kris @aunder I'm tempted to try both of these ideas.",
  "id" : 317478350165798912,
  "in_reply_to_status_id" : 317474175843442689,
  "created_at" : "Fri Mar 29 03:28:31 +0000 2013",
  "in_reply_to_screen_name" : "kris",
  "in_reply_to_user_id_str" : "115734106",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Ward",
      "screen_name" : "benward",
      "indices" : [ 0, 8 ],
      "id_str" : "12249",
      "id" : 12249
    }, {
      "name" : "Tom Coates",
      "screen_name" : "tomcoates",
      "indices" : [ 9, 19 ],
      "id_str" : "12514",
      "id" : 12514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "317447206271582209",
  "geo" : {
  },
  "id_str" : "317451356602523648",
  "in_reply_to_user_id" : 12249,
  "text" : "@BenWard @tomcoates Until you hear that I'm 237?",
  "id" : 317451356602523648,
  "in_reply_to_status_id" : 317447206271582209,
  "created_at" : "Fri Mar 29 01:41:16 +0000 2013",
  "in_reply_to_screen_name" : "benward",
  "in_reply_to_user_id_str" : "12249",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Schappell",
      "screen_name" : "daveschappell",
      "indices" : [ 0, 14 ],
      "id_str" : "820661",
      "id" : 820661
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "317376510908592129",
  "geo" : {
  },
  "id_str" : "317376678781399040",
  "in_reply_to_user_id" : 820661,
  "text" : "@daveschappell Ooh, that's cool. I love that site. Please don't let them destroy it.",
  "id" : 317376678781399040,
  "in_reply_to_status_id" : 317376510908592129,
  "created_at" : "Thu Mar 28 20:44:31 +0000 2013",
  "in_reply_to_screen_name" : "daveschappell",
  "in_reply_to_user_id_str" : "820661",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Onion",
      "screen_name" : "TheOnion",
      "indices" : [ 108, 117 ],
      "id_str" : "14075928",
      "id" : 14075928
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http://t.co/Vyjrva9tPF",
      "expanded_url" : "http://onion.com/103ptYF",
      "display_url" : "onion.com/103ptYF"
    } ]
  },
  "geo" : {
  },
  "id_str" : "317358648382849024",
  "text" : "Hang in there! \"Guy With 10,000 Tweets, 15 Followers About Ready To Hang It Up\" http://t.co/Vyjrva9tPF /via @TheOnion",
  "id" : 317358648382849024,
  "created_at" : "Thu Mar 28 19:32:52 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Corrie Borris",
      "screen_name" : "corrieborris",
      "indices" : [ 0, 13 ],
      "id_str" : "16190979",
      "id" : 16190979
    }, {
      "name" : "Lift",
      "screen_name" : "liftapp",
      "indices" : [ 14, 22 ],
      "id_str" : "353195232",
      "id" : 353195232
    }, {
      "name" : "Tony Stubblebine",
      "screen_name" : "tonystubblebine",
      "indices" : [ 23, 39 ],
      "id_str" : "17",
      "id" : 17
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "317354256288075776",
  "geo" : {
  },
  "id_str" : "317357096242917376",
  "in_reply_to_user_id" : 16190979,
  "text" : "@corrieborris @liftapp @tonystubblebine Being inclusive to different personality types with meditation would be a good thing, right?",
  "id" : 317357096242917376,
  "in_reply_to_status_id" : 317354256288075776,
  "created_at" : "Thu Mar 28 19:26:42 +0000 2013",
  "in_reply_to_screen_name" : "corrieborris",
  "in_reply_to_user_id_str" : "16190979",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anil Dash",
      "screen_name" : "anildash",
      "indices" : [ 116, 125 ],
      "id_str" : "36823",
      "id" : 36823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http://t.co/MhjAbcUKp4",
      "expanded_url" : "http://2.dashes.com/XJnjL8",
      "display_url" : "2.dashes.com/XJnjL8"
    } ]
  },
  "geo" : {
  },
  "id_str" : "317346041013882880",
  "text" : "Here you go. Top 10 simple tips that are *guaranteed* to increase your odds of success. http://t.co/MhjAbcUKp4 /via @anildash",
  "id" : 317346041013882880,
  "created_at" : "Thu Mar 28 18:42:46 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "317324818489954305",
  "text" : "Affect heuristic: things we like are assumed to be good, safe, beneficial, and things we don't like are assumed to be bad, risky, harmful.",
  "id" : 317324818489954305,
  "created_at" : "Thu Mar 28 17:18:26 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 3, 13 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http://t.co/rUimjEKjCH",
      "expanded_url" : "http://instagram.com/p/XaAho8OFZY/",
      "display_url" : "instagram.com/p/XaAho8OFZY/"
    } ]
  },
  "geo" : {
  },
  "id_str" : "317298824202829826",
  "text" : "RT @kellianne: Mr. Crane is very excited for his first day of preschool at Garden Day! http://t.co/rUimjEKjCH",
  "retweeted_status" : {
    "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 72, 94 ],
        "url" : "http://t.co/rUimjEKjCH",
        "expanded_url" : "http://instagram.com/p/XaAho8OFZY/",
        "display_url" : "instagram.com/p/XaAho8OFZY/"
      } ]
    },
    "geo" : {
    },
    "id_str" : "317298643969376256",
    "text" : "Mr. Crane is very excited for his first day of preschool at Garden Day! http://t.co/rUimjEKjCH",
    "id" : 317298643969376256,
    "created_at" : "Thu Mar 28 15:34:26 +0000 2013",
    "user" : {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "protected" : false,
      "id_str" : "7362142",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3058433557/056b99ecb9df9b6b9b382b2470b6ee82_normal.jpeg",
      "id" : 7362142,
      "verified" : false
    }
  },
  "id" : 317298824202829826,
  "created_at" : "Thu Mar 28 15:35:09 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Stubblebine",
      "screen_name" : "tonystubblebine",
      "indices" : [ 70, 86 ],
      "id_str" : "17",
      "id" : 17
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http://t.co/Kvh1bezwSl",
      "expanded_url" : "http://bit.ly/10kblJv",
      "display_url" : "bit.ly/10kblJv"
    } ]
  },
  "geo" : {
  },
  "id_str" : "317298466336428032",
  "text" : "967. Today marks 28 days of meditation. Watch me mumble about it with @tonystubblebine here: http://t.co/Kvh1bezwSl",
  "id" : 317298466336428032,
  "created_at" : "Thu Mar 28 15:33:44 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lift",
      "screen_name" : "liftapp",
      "indices" : [ 3, 11 ],
      "id_str" : "353195232",
      "id" : 353195232
    }, {
      "name" : "Tony Stubblebine",
      "screen_name" : "tonystubblebine",
      "indices" : [ 65, 81 ],
      "id_str" : "17",
      "id" : 17
    }, {
      "name" : "Buster",
      "screen_name" : "buster",
      "indices" : [ 93, 100 ],
      "id_str" : "2185",
      "id" : 2185
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MarchMeditation",
      "indices" : [ 101, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 42, 64 ],
      "url" : "http://t.co/QmepD3vbTL",
      "expanded_url" : "http://bit.ly/10kblJv",
      "display_url" : "bit.ly/10kblJv"
    } ]
  },
  "geo" : {
  },
  "id_str" : "317295140962181120",
  "text" : "RT @liftapp: Can Madonna Save Meditation? http://t.co/QmepD3vbTL @tonystubblebine interviews @buster #MarchMeditation",
  "retweeted_status" : {
    "source" : "<a href=\"http://sproutsocial.com\" rel=\"nofollow\">Sprout Social</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Tony Stubblebine",
        "screen_name" : "tonystubblebine",
        "indices" : [ 52, 68 ],
        "id_str" : "17",
        "id" : 17
      }, {
        "name" : "Buster",
        "screen_name" : "buster",
        "indices" : [ 80, 87 ],
        "id_str" : "2185",
        "id" : 2185
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MarchMeditation",
        "indices" : [ 88, 104 ]
      } ],
      "urls" : [ {
        "indices" : [ 29, 51 ],
        "url" : "http://t.co/QmepD3vbTL",
        "expanded_url" : "http://bit.ly/10kblJv",
        "display_url" : "bit.ly/10kblJv"
      } ]
    },
    "geo" : {
    },
    "id_str" : "317290186985836544",
    "text" : "Can Madonna Save Meditation? http://t.co/QmepD3vbTL @tonystubblebine interviews @buster #MarchMeditation",
    "id" : 317290186985836544,
    "created_at" : "Thu Mar 28 15:00:50 +0000 2013",
    "user" : {
      "name" : "Lift",
      "screen_name" : "liftapp",
      "protected" : false,
      "id_str" : "353195232",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2553948018/m4bp61wehttc623ie6c7_normal.png",
      "id" : 353195232,
      "verified" : false
    }
  },
  "id" : 317295140962181120,
  "created_at" : "Thu Mar 28 15:20:31 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "susan wu",
      "screen_name" : "sw",
      "indices" : [ 0, 3 ],
      "id_str" : "893211",
      "id" : 893211
    }, {
      "name" : "Aaron Levie",
      "screen_name" : "levie",
      "indices" : [ 4, 10 ],
      "id_str" : "914061",
      "id" : 914061
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "317160852576944129",
  "geo" : {
  },
  "id_str" : "317163580816494593",
  "in_reply_to_user_id" : 893211,
  "text" : "@sw @levie The dangers and benefits of overconfidence are in my zeitgeist. Nate Silver and Daniel Kahneman are obsessed with it.",
  "id" : 317163580816494593,
  "in_reply_to_status_id" : 317160852576944129,
  "created_at" : "Thu Mar 28 06:37:44 +0000 2013",
  "in_reply_to_screen_name" : "sw",
  "in_reply_to_user_id_str" : "893211",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "317142525104238592",
  "text" : "I want to drink a bottle of honey.",
  "id" : 317142525104238592,
  "created_at" : "Thu Mar 28 05:14:04 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Levie",
      "screen_name" : "levie",
      "indices" : [ 33, 39 ],
      "id_str" : "914061",
      "id" : 914061
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "317133626515025920",
  "geo" : {
  },
  "id_str" : "317139258202812416",
  "in_reply_to_user_id" : 914061,
  "text" : "It's also the secret to lying RT @levie: The secret to entrepreneurship is having 100% conviction with only 80% of the answer.",
  "id" : 317139258202812416,
  "in_reply_to_status_id" : 317133626515025920,
  "created_at" : "Thu Mar 28 05:01:05 +0000 2013",
  "in_reply_to_screen_name" : "levie",
  "in_reply_to_user_id_str" : "914061",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "317131351490965504",
  "text" : "968. Meditating while sick was interesting. I could almost sense a sick animal self inside me.",
  "id" : 317131351490965504,
  "created_at" : "Thu Mar 28 04:29:40 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Loving",
      "screen_name" : "adamloving",
      "indices" : [ 3, 14 ],
      "id_str" : "809641",
      "id" : 809641
    }, {
      "name" : "techstars",
      "screen_name" : "techstars",
      "indices" : [ 17, 27 ],
      "id_str" : "14277276",
      "id" : 14277276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http://t.co/Gt4pKkSZsq",
      "expanded_url" : "http://apply.techstars.com/",
      "display_url" : "apply.techstars.com"
    } ]
  },
  "geo" : {
  },
  "id_str" : "317128916483575810",
  "text" : "RT @adamloving: .@TechStars Seattle is now accepting applications. Hit me up if you want more info  http://t.co/Gt4pKkSZsq",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "techstars",
        "screen_name" : "techstars",
        "indices" : [ 1, 11 ],
        "id_str" : "14277276",
        "id" : 14277276
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 84, 106 ],
        "url" : "http://t.co/Gt4pKkSZsq",
        "expanded_url" : "http://apply.techstars.com/",
        "display_url" : "apply.techstars.com"
      } ]
    },
    "geo" : {
    },
    "id_str" : "317128581723598848",
    "text" : ".@TechStars Seattle is now accepting applications. Hit me up if you want more info  http://t.co/Gt4pKkSZsq",
    "id" : 317128581723598848,
    "created_at" : "Thu Mar 28 04:18:40 +0000 2013",
    "user" : {
      "name" : "Adam Loving",
      "screen_name" : "adamloving",
      "protected" : false,
      "id_str" : "809641",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3596120795/6bc52037ad90fa33da999b74316df179_normal.jpeg",
      "id" : 809641,
      "verified" : false
    }
  },
  "id" : 317128916483575810,
  "created_at" : "Thu Mar 28 04:20:00 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http://t.co/ri5ibbaete",
      "expanded_url" : "http://flic.kr/p/e6Bd7x",
      "display_url" : "flic.kr/p/e6Bd7x"
    } ]
  },
  "geo" : {
  },
  "id_str" : "317118610130759680",
  "text" : "8:36pm So much I need to do but giving into this cold, and this cozy room http://t.co/ri5ibbaete",
  "id" : 317118610130759680,
  "created_at" : "Thu Mar 28 03:39:03 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cap Watkins",
      "screen_name" : "cap",
      "indices" : [ 0, 4 ],
      "id_str" : "2182141",
      "id" : 2182141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "317063525761708032",
  "geo" : {
  },
  "id_str" : "317063917266411521",
  "in_reply_to_user_id" : 2182141,
  "text" : "@cap Deal! I just had a call with Etsy today, by the way. Hope we get to work together at some point.",
  "id" : 317063917266411521,
  "in_reply_to_status_id" : 317063525761708032,
  "created_at" : "Thu Mar 28 00:01:43 +0000 2013",
  "in_reply_to_screen_name" : "cap",
  "in_reply_to_user_id_str" : "2182141",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cap Watkins",
      "screen_name" : "cap",
      "indices" : [ 0, 4 ],
      "id_str" : "2182141",
      "id" : 2182141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "317057260662714368",
  "geo" : {
  },
  "id_str" : "317063437018611712",
  "in_reply_to_user_id" : 2182141,
  "text" : "@cap busterbenson at gmail. Thanks, man!",
  "id" : 317063437018611712,
  "in_reply_to_status_id" : 317057260662714368,
  "created_at" : "Wed Mar 27 23:59:48 +0000 2013",
  "in_reply_to_screen_name" : "cap",
  "in_reply_to_user_id_str" : "2182141",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cap Watkins",
      "screen_name" : "cap",
      "indices" : [ 0, 4 ],
      "id_str" : "2182141",
      "id" : 2182141
    }, {
      "name" : "Editorially",
      "screen_name" : "GetEditorially",
      "indices" : [ 29, 44 ],
      "id_str" : "368540976",
      "id" : 368540976
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "317055967999164416",
  "geo" : {
  },
  "id_str" : "317056095996747776",
  "in_reply_to_user_id" : 2182141,
  "text" : "@cap Got any invites? :) /cc @geteditorially",
  "id" : 317056095996747776,
  "in_reply_to_status_id" : 317055967999164416,
  "created_at" : "Wed Mar 27 23:30:38 +0000 2013",
  "in_reply_to_screen_name" : "cap",
  "in_reply_to_user_id_str" : "2182141",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "316951060512129024",
  "text" : "\"A remarkable aspect of our mental lives is that we are rarely stumped. We often have answers to questions we barely understand.\" - Kahneman",
  "id" : 316951060512129024,
  "created_at" : "Wed Mar 27 16:33:16 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan King",
      "screen_name" : "rk",
      "indices" : [ 0, 3 ],
      "id_str" : "19853",
      "id" : 19853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "316776750996668416",
  "geo" : {
  },
  "id_str" : "316780048810143744",
  "in_reply_to_user_id" : 19853,
  "text" : "@rk I haven't, but that was a pretty smart post there! Who is this guy?",
  "id" : 316780048810143744,
  "in_reply_to_status_id" : 316776750996668416,
  "created_at" : "Wed Mar 27 05:13:43 +0000 2013",
  "in_reply_to_screen_name" : "rk",
  "in_reply_to_user_id_str" : "19853",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carinna Tarvin",
      "screen_name" : "carinnatarvin",
      "indices" : [ 0, 14 ],
      "id_str" : "20833838",
      "id" : 20833838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "316772630600503296",
  "geo" : {
  },
  "id_str" : "316776278160183296",
  "in_reply_to_user_id" : 20833838,
  "text" : "@carinnatarvin I *do* plan on a series of marshmallow-like willpower challenges for Niko in his near future. Just for laughs.",
  "id" : 316776278160183296,
  "in_reply_to_status_id" : 316772630600503296,
  "created_at" : "Wed Mar 27 04:58:44 +0000 2013",
  "in_reply_to_screen_name" : "carinnatarvin",
  "in_reply_to_user_id_str" : "20833838",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 42 ],
      "url" : "http://t.co/RvJaUjyNJM",
      "expanded_url" : "http://flic.kr/p/e6tvsf",
      "display_url" : "flic.kr/p/e6tvsf"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859833, -122.2755 ]
  },
  "id_str" : "316764020138967041",
  "text" : "8:36pm Brusha brush http://t.co/RvJaUjyNJM",
  "id" : 316764020138967041,
  "created_at" : "Wed Mar 27 04:10:02 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aimee",
      "screen_name" : "LilHossler",
      "indices" : [ 0, 11 ],
      "id_str" : "123116307",
      "id" : 123116307
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "316753067867521024",
  "geo" : {
  },
  "id_str" : "316756939306590208",
  "in_reply_to_user_id" : 123116307,
  "text" : "@LilHossler What about Moses? And do you really believe Noah did that?",
  "id" : 316756939306590208,
  "in_reply_to_status_id" : 316753067867521024,
  "created_at" : "Wed Mar 27 03:41:54 +0000 2013",
  "in_reply_to_screen_name" : "LilHossler",
  "in_reply_to_user_id_str" : "123116307",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Berkun",
      "screen_name" : "berkun",
      "indices" : [ 0, 7 ],
      "id_str" : "30495974",
      "id" : 30495974
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "316754759656824833",
  "geo" : {
  },
  "id_str" : "316755870660849664",
  "in_reply_to_user_id" : 30495974,
  "text" : "@berkun Both, and yet it makes a great story and is almost impossible to resist.",
  "id" : 316755870660849664,
  "in_reply_to_status_id" : 316754759656824833,
  "created_at" : "Wed Mar 27 03:37:39 +0000 2013",
  "in_reply_to_screen_name" : "berkun",
  "in_reply_to_user_id_str" : "30495974",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "316754468563726336",
  "text" : "1st law of behavior books: you cannot not mention the marshmallow test.",
  "id" : 316754468563726336,
  "created_at" : "Wed Mar 27 03:32:04 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "316746322025779200",
  "text" : "How many animals of each kind did Moses take into the Ark?",
  "id" : 316746322025779200,
  "created_at" : "Wed Mar 27 02:59:42 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nya",
      "screen_name" : "nyashirzad",
      "indices" : [ 0, 11 ],
      "id_str" : "625957521",
      "id" : 625957521
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "316743865832992768",
  "geo" : {
  },
  "id_str" : "316745736995876864",
  "in_reply_to_user_id" : 625957521,
  "text" : "@nyashirzad best answer. :)",
  "id" : 316745736995876864,
  "in_reply_to_status_id" : 316743865832992768,
  "created_at" : "Wed Mar 27 02:57:23 +0000 2013",
  "in_reply_to_screen_name" : "nyashirzad",
  "in_reply_to_user_id_str" : "625957521",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "316743974075371521",
  "text" : "\"Familiarity breeds liking.\" - Kahneman in Thinking, Fast and Slow",
  "id" : 316743974075371521,
  "created_at" : "Wed Mar 27 02:50:22 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "316742654492807168",
  "text" : "System 1: good mood, intuition, creativity, gullibility. System 2: sadness, vigilance, suspicion, an analytic approach, &amp; increased effort.",
  "id" : 316742654492807168,
  "created_at" : "Wed Mar 27 02:45:08 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ingopixel",
      "screen_name" : "ingopixel",
      "indices" : [ 0, 10 ],
      "id_str" : "7943892",
      "id" : 7943892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "316739102370320384",
  "geo" : {
  },
  "id_str" : "316740635510059008",
  "in_reply_to_user_id" : 7943892,
  "text" : "@ingopixel Correct! How did you catch the error?",
  "id" : 316740635510059008,
  "in_reply_to_status_id" : 316739102370320384,
  "created_at" : "Wed Mar 27 02:37:06 +0000 2013",
  "in_reply_to_screen_name" : "ingopixel",
  "in_reply_to_user_id_str" : "7943892",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "316738245239123968",
  "text" : "If it take 5 machines 5 minutes to make 5 widgets, how long would it take 100 machines to make 100 widgets?",
  "id" : 316738245239123968,
  "created_at" : "Wed Mar 27 02:27:37 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "316737452964450304",
  "text" : "\"How do you know/believe if a statement is true? By its cognitive ease. The problem is, the sense of ease has multiple causes.\" - Kahnemsn",
  "id" : 316737452964450304,
  "created_at" : "Wed Mar 27 02:24:28 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "rob delaney",
      "screen_name" : "robdelaney",
      "indices" : [ 3, 14 ],
      "id_str" : "22084427",
      "id" : 22084427
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "316734726369054720",
  "text" : "RT @robdelaney: I love gay people. Or as I sometimes call them, \"people.\"",
  "retweeted_status" : {
    "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "172828056573059074",
    "text" : "I love gay people. Or as I sometimes call them, \"people.\"",
    "id" : 172828056573059074,
    "created_at" : "Thu Feb 23 23:39:54 +0000 2012",
    "user" : {
      "name" : "rob delaney",
      "screen_name" : "robdelaney",
      "protected" : false,
      "id_str" : "22084427",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1643163355/Screen_shot_2011-11-16_at_9.08.14_PM_normal.png",
      "id" : 22084427,
      "verified" : true
    }
  },
  "id" : 316734726369054720,
  "created_at" : "Wed Mar 27 02:13:38 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "316734326219882497",
  "text" : "On the impression of familiarity: \"Things that you have seen before become easier to see again.\" - Kahneman",
  "id" : 316734326219882497,
  "created_at" : "Wed Mar 27 02:12:02 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Rainert",
      "screen_name" : "arainert",
      "indices" : [ 24, 33 ],
      "id_str" : "7482",
      "id" : 7482
    }, {
      "name" : "Bar Agricole",
      "screen_name" : "baragricole",
      "indices" : [ 39, 51 ],
      "id_str" : "116125324",
      "id" : 116125324
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http://t.co/q8xpXqRTLv",
      "expanded_url" : "http://4sq.com/YDci15",
      "display_url" : "4sq.com/YDci15"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.771362, -122.412966 ]
  },
  "id_str" : "316700950649786368",
  "text" : "Hanging with Foursquare @arainert! (at @BarAgricole) http://t.co/q8xpXqRTLv",
  "id" : 316700950649786368,
  "created_at" : "Tue Mar 26 23:59:25 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://vine.co\" rel=\"nofollow\">Vine - Make a Scene</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 37 ],
      "url" : "https://t.co/oSw4En453n",
      "expanded_url" : "https://vine.co/v/bDlpZUgxMvB",
      "display_url" : "vine.co/v/bDlpZUgxMvB"
    } ]
  },
  "geo" : {
  },
  "id_str" : "316397909342031873",
  "text" : "Getting dizzy https://t.co/oSw4En453n",
  "id" : 316397909342031873,
  "created_at" : "Tue Mar 26 03:55:14 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 79 ],
      "url" : "http://t.co/u19KxZRMQQ",
      "expanded_url" : "http://flic.kr/p/e68axx",
      "display_url" : "flic.kr/p/e68axx"
    } ]
  },
  "geo" : {
  },
  "id_str" : "316394680382283777",
  "text" : "8:36pm There can never be too many books about trains... http://t.co/u19KxZRMQQ",
  "id" : 316394680382283777,
  "created_at" : "Tue Mar 26 03:42:24 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian Bogost",
      "screen_name" : "ibogost",
      "indices" : [ 3, 11 ],
      "id_str" : "6825792",
      "id" : 6825792
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "316375861404254208",
  "text" : "RT @ibogost: Lessons from Successman:\n\n1. Be success\n2. Be wealthy playa\n3. Keep em guessing: caramel sundae\n4. Skate or die? Choose skate",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "316366123203444736",
    "text" : "Lessons from Successman:\n\n1. Be success\n2. Be wealthy playa\n3. Keep em guessing: caramel sundae\n4. Skate or die? Choose skate",
    "id" : 316366123203444736,
    "created_at" : "Tue Mar 26 01:48:56 +0000 2013",
    "user" : {
      "name" : "Ian Bogost",
      "screen_name" : "ibogost",
      "protected" : false,
      "id_str" : "6825792",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3724699383/d09b568c3fa3a4ecaa8e62535453c881_normal.jpeg",
      "id" : 6825792,
      "verified" : false
    }
  },
  "id" : 316375861404254208,
  "created_at" : "Tue Mar 26 02:27:37 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "adri larsen",
      "screen_name" : "luckytink",
      "indices" : [ 0, 10 ],
      "id_str" : "17348865",
      "id" : 17348865
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "316368361443454977",
  "geo" : {
  },
  "id_str" : "316374768779657217",
  "in_reply_to_user_id" : 17348865,
  "text" : "@luckytink What did you not like about it?",
  "id" : 316374768779657217,
  "in_reply_to_status_id" : 316368361443454977,
  "created_at" : "Tue Mar 26 02:23:17 +0000 2013",
  "in_reply_to_screen_name" : "luckytink",
  "in_reply_to_user_id_str" : "17348865",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "316366017716699137",
  "text" : "\"Two important facts about our minds. We can be blind to the obvious. And we are also blind to our blindness.\" - Kahneman",
  "id" : 316366017716699137,
  "created_at" : "Tue Mar 26 01:48:31 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "316358887274078208",
  "text" : "\"When faced with a difficult question, we often answer an easier one instead. Often without realizing the substitution.\" - Kahneman",
  "id" : 316358887274078208,
  "created_at" : "Tue Mar 26 01:20:11 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/buster/status/316358016670773248/photo/1",
      "indices" : [ 102, 124 ],
      "url" : "http://t.co/JUBQ3EwCKY",
      "media_url" : "http://pbs.twimg.com/media/BGPt8KYCMAAHjsC.jpg",
      "id_str" : "316358016679161856",
      "id" : 316358016679161856,
      "media_url_https" : "https://pbs.twimg.com/media/BGPt8KYCMAAHjsC.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 577
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 577
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 603,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 577
      } ],
      "display_url" : "pic.twitter.com/JUBQ3EwCKY"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "316358016670773248",
  "text" : "Starting the \"Thinking Fast and Slow\" audiobook by Daniel Kahneman. High hopes for it. Who's read it? http://t.co/JUBQ3EwCKY",
  "id" : 316358016670773248,
  "created_at" : "Tue Mar 26 01:16:43 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https://t.co/ibyn3q3nyl",
      "expanded_url" : "https://dev.twitter.com/form/twitter-platform-event",
      "display_url" : "dev.twitter.com/form/twitter-p\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "316293742573285376",
  "text" : "Developers! Come to our first Twitter Platform event in a while and learn about what I've been working on: https://t.co/ibyn3q3nyl",
  "id" : 316293742573285376,
  "created_at" : "Mon Mar 25 21:01:19 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Greg Linden",
      "screen_name" : "greglinden",
      "indices" : [ 0, 11 ],
      "id_str" : "87719108",
      "id" : 87719108
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "316288714944958466",
  "geo" : {
  },
  "id_str" : "316289710223941632",
  "in_reply_to_user_id" : 87719108,
  "text" : "@greglinden That's the conflict I'm running into. It's beneficial/effective to the individual even though it is less accurate.",
  "id" : 316289710223941632,
  "in_reply_to_status_id" : 316288714944958466,
  "created_at" : "Mon Mar 25 20:45:17 +0000 2013",
  "in_reply_to_screen_name" : "greglinden",
  "in_reply_to_user_id_str" : "87719108",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Prismatic",
      "screen_name" : "Prismatic",
      "indices" : [ 11, 21 ],
      "id_str" : "229709694",
      "id" : 229709694
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/buster/status/316268487892951040/photo/1",
      "indices" : [ 118, 140 ],
      "url" : "http://t.co/qJ3oAvDE4E",
      "media_url" : "http://pbs.twimg.com/media/BGOcg5wCYAI0ieC.png",
      "id_str" : "316268487918116866",
      "id" : 316268487918116866,
      "media_url_https" : "https://pbs.twimg.com/media/BGOcg5wCYAI0ieC.png",
      "sizes" : [ {
        "h" : 776,
        "resize" : "fit",
        "w" : 395
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 668,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 776,
        "resize" : "fit",
        "w" : 395
      }, {
        "h" : 776,
        "resize" : "fit",
        "w" : 395
      } ],
      "display_url" : "pic.twitter.com/qJ3oAvDE4E"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "316268487892951040",
  "text" : "Unfollowed @prismatic because they're spamming people like crazy. Dare you to look at their last few thousand tweets. http://t.co/qJ3oAvDE4E",
  "id" : 316268487892951040,
  "created_at" : "Mon Mar 25 19:20:58 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twitter Seattle",
      "screen_name" : "TwitterSeattle",
      "indices" : [ 23, 38 ],
      "id_str" : "1228433617",
      "id" : 1228433617
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https://t.co/FT6hAyFJ22",
      "expanded_url" : "https://twitter.com/jobs/positions?jvi=oWyaXfwl,Job",
      "display_url" : "twitter.com/jobs/positions\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "316264167537512448",
  "text" : "ATTN: Seattle-ites! RT @TwitterSeattle: We're hiring in Seattle for the data infrastructure team!  Interested? https://t.co/FT6hAyFJ22",
  "id" : 316264167537512448,
  "created_at" : "Mon Mar 25 19:03:48 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Ellin",
      "screen_name" : "brianellin",
      "indices" : [ 0, 11 ],
      "id_str" : "26123649",
      "id" : 26123649
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "316218848359616512",
  "geo" : {
  },
  "id_str" : "316233216669413376",
  "in_reply_to_user_id" : 26123649,
  "text" : "@brianellin Probably close to 0 times on average if my bookshelf is any indication.",
  "id" : 316233216669413376,
  "in_reply_to_status_id" : 316218848359616512,
  "created_at" : "Mon Mar 25 17:00:48 +0000 2013",
  "in_reply_to_screen_name" : "brianellin",
  "in_reply_to_user_id_str" : "26123649",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lauren Leto",
      "screen_name" : "laurenleto",
      "indices" : [ 17, 28 ],
      "id_str" : "15510569",
      "id" : 15510569
    }, {
      "name" : "betaworks",
      "screen_name" : "betaworks",
      "indices" : [ 42, 52 ],
      "id_str" : "14445325",
      "id" : 14445325
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http://t.co/QbCdGk6dmN",
      "expanded_url" : "http://pandodaily.com/2013/03/22/early-adopter-try-earliest-adopter-with-betaworks-new-openbeta-community/",
      "display_url" : "pandodaily.com/2013/03/22/ear\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "316193511147991040",
  "geo" : {
  },
  "id_str" : "316196694100430848",
  "in_reply_to_user_id" : 15510569,
  "text" : "This is cool. RT @laurenleto: Introducing @Betaworks' new Openbeta community http://t.co/QbCdGk6dmN",
  "id" : 316196694100430848,
  "in_reply_to_status_id" : 316193511147991040,
  "created_at" : "Mon Mar 25 14:35:41 +0000 2013",
  "in_reply_to_screen_name" : "laurenleto",
  "in_reply_to_user_id_str" : "15510569",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Goldman",
      "screen_name" : "goldman",
      "indices" : [ 3, 11 ],
      "id_str" : "291",
      "id" : 291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "316046627485921280",
  "text" : "RT @goldman: Reddit, Men's Rights, a pickup artist and Bitcoins: the PyCon Affair may be hitting rock bottom at this point. http://t.co/FZz\u2026",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/#!/download/ipad\" rel=\"nofollow\">Twitter for iPad</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 111, 133 ],
        "url" : "http://t.co/FZzqCV6fvp",
        "expanded_url" : "http://www.buzzfeed.com/katienotopoulos/reddit-mens-rights-activists-are-fundraising-for-the-victim",
        "display_url" : "buzzfeed.com/katienotopoulo\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "316033552162643968",
    "text" : "Reddit, Men's Rights, a pickup artist and Bitcoins: the PyCon Affair may be hitting rock bottom at this point. http://t.co/FZzqCV6fvp",
    "id" : 316033552162643968,
    "created_at" : "Mon Mar 25 03:47:25 +0000 2013",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "goldman",
      "protected" : false,
      "id_str" : "291",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3688249569/d66d1c75fb8fd4cf36ec692b25c80a67_normal.jpeg",
      "id" : 291,
      "verified" : false
    }
  },
  "id" : 316046627485921280,
  "created_at" : "Mon Mar 25 04:39:22 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 53 ],
      "url" : "http://t.co/77ImJ6lNpw",
      "expanded_url" : "http://flic.kr/p/e5R3oD",
      "display_url" : "flic.kr/p/e5R3oD"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.867833, -122.284167 ]
  },
  "id_str" : "316031317106114560",
  "text" : "8:36pm Hanging with the locals http://t.co/77ImJ6lNpw",
  "id" : 316031317106114560,
  "created_at" : "Mon Mar 25 03:38:32 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "315927788446154752",
  "text" : "0 for 3,000 on first guesses for which earbud goes my left ear.",
  "id" : 315927788446154752,
  "created_at" : "Sun Mar 24 20:47:09 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Self Aware ROOMBA",
      "screen_name" : "SelfAwareROOMBA",
      "indices" : [ 3, 19 ],
      "id_str" : "620654544",
      "id" : 620654544
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "315925281703600129",
  "text" : "RT @SelfAwareROOMBA: Runnin' over these same old mimosa stains. Is this all there is?",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "315920989911408640",
    "text" : "Runnin' over these same old mimosa stains. Is this all there is?",
    "id" : 315920989911408640,
    "created_at" : "Sun Mar 24 20:20:08 +0000 2013",
    "user" : {
      "name" : "Self Aware ROOMBA",
      "screen_name" : "SelfAwareROOMBA",
      "protected" : false,
      "id_str" : "620654544",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2347821270/roomba_normal.jpg",
      "id" : 620654544,
      "verified" : false
    }
  },
  "id" : 315925281703600129,
  "created_at" : "Sun Mar 24 20:37:11 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jacqueline wolven",
      "screen_name" : "jackiewolven",
      "indices" : [ 0, 13 ],
      "id_str" : "7413172",
      "id" : 7413172
    }, {
      "name" : "HSofia",
      "screen_name" : "hsofia",
      "indices" : [ 14, 21 ],
      "id_str" : "14372614",
      "id" : 14372614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "315919713265909761",
  "geo" : {
  },
  "id_str" : "315924439705468928",
  "in_reply_to_user_id" : 7413172,
  "text" : "@jackiewolven @hsofia You might be surprised. That's what this book is all about!",
  "id" : 315924439705468928,
  "in_reply_to_status_id" : 315919713265909761,
  "created_at" : "Sun Mar 24 20:33:50 +0000 2013",
  "in_reply_to_screen_name" : "jackiewolven",
  "in_reply_to_user_id_str" : "7413172",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jacqueline wolven",
      "screen_name" : "jackiewolven",
      "indices" : [ 0, 13 ],
      "id_str" : "7413172",
      "id" : 7413172
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "315911972942123011",
  "geo" : {
  },
  "id_str" : "315912598094766080",
  "in_reply_to_user_id" : 7413172,
  "text" : "@jackiewolven Of course. It's a long slow process that will take generations, as long as it keeps moving forward. I recommend Lean In.",
  "id" : 315912598094766080,
  "in_reply_to_status_id" : 315911972942123011,
  "created_at" : "Sun Mar 24 19:46:47 +0000 2013",
  "in_reply_to_screen_name" : "jackiewolven",
  "in_reply_to_user_id_str" : "7413172",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jacqueline wolven",
      "screen_name" : "jackiewolven",
      "indices" : [ 0, 13 ],
      "id_str" : "7413172",
      "id" : 7413172
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "315909081900666881",
  "geo" : {
  },
  "id_str" : "315911279502053378",
  "in_reply_to_user_id" : 7413172,
  "text" : "@jackiewolven Gender is more than genitalia. It's cultural and personal.",
  "id" : 315911279502053378,
  "in_reply_to_status_id" : 315909081900666881,
  "created_at" : "Sun Mar 24 19:41:33 +0000 2013",
  "in_reply_to_screen_name" : "jackiewolven",
  "in_reply_to_user_id_str" : "7413172",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "315902573569777664",
  "geo" : {
  },
  "id_str" : "315907822057570304",
  "in_reply_to_user_id" : 2185,
  "text" : "I'm convinced: we should work towards a world where half our institutions are run by women and half our homes are run by men. Read Lean In!",
  "id" : 315907822057570304,
  "in_reply_to_status_id" : 315902573569777664,
  "created_at" : "Sun Mar 24 19:27:48 +0000 2013",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marina Martin",
      "screen_name" : "MarinaMartin",
      "indices" : [ 0, 13 ],
      "id_str" : "60663",
      "id" : 60663
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "315905557120811008",
  "geo" : {
  },
  "id_str" : "315906348887990272",
  "in_reply_to_user_id" : 60663,
  "text" : "@MarinaMartin Mainstream terms will always become messy. It's important (to me) that the movement continues to push rather than fragment.",
  "id" : 315906348887990272,
  "in_reply_to_status_id" : 315905557120811008,
  "created_at" : "Sun Mar 24 19:21:57 +0000 2013",
  "in_reply_to_screen_name" : "MarinaMartin",
  "in_reply_to_user_id_str" : "60663",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sara Mauskopf",
      "screen_name" : "sm",
      "indices" : [ 10, 13 ],
      "id_str" : "22273667",
      "id" : 22273667
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "315905968498163713",
  "text" : "Thanks to @sm for the nudge to read Lean In. Highly recommended as an antidote to non-productive, polarized conversations about gender.",
  "id" : 315905968498163713,
  "created_at" : "Sun Mar 24 19:20:26 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marina Martin",
      "screen_name" : "MarinaMartin",
      "indices" : [ 0, 13 ],
      "id_str" : "60663",
      "id" : 60663
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "315893976731377664",
  "geo" : {
  },
  "id_str" : "315905198134542337",
  "in_reply_to_user_id" : 60663,
  "text" : "@MarinaMartin Wars of independence require one power to dominate another. This is about equal distribution of power... it's non-zero sum.",
  "id" : 315905198134542337,
  "in_reply_to_status_id" : 315893976731377664,
  "created_at" : "Sun Mar 24 19:17:23 +0000 2013",
  "in_reply_to_screen_name" : "MarinaMartin",
  "in_reply_to_user_id_str" : "60663",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u24D5\u24E3",
      "screen_name" : "folktrash",
      "indices" : [ 3, 13 ],
      "id_str" : "15265271",
      "id" : 15265271
    }, {
      "name" : "Buster",
      "screen_name" : "buster",
      "indices" : [ 15, 22 ],
      "id_str" : "2185",
      "id" : 2185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "315896627917373442",
  "text" : "RT @folktrash: @buster if (2) {1=true;}",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Buster",
        "screen_name" : "buster",
        "indices" : [ 0, 7 ],
        "id_str" : "2185",
        "id" : 2185
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "315893044908011522",
    "geo" : {
    },
    "id_str" : "315893355378774017",
    "in_reply_to_user_id" : 2185,
    "text" : "@buster if (2) {1=true;}",
    "id" : 315893355378774017,
    "in_reply_to_status_id" : 315893044908011522,
    "created_at" : "Sun Mar 24 18:30:19 +0000 2013",
    "in_reply_to_screen_name" : "buster",
    "in_reply_to_user_id_str" : "2185",
    "user" : {
      "name" : "\u24D5\u24E3",
      "screen_name" : "folktrash",
      "protected" : false,
      "id_str" : "15265271",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1211960020/nsq_normal.jpg",
      "id" : 15265271,
      "verified" : false
    }
  },
  "id" : 315896627917373442,
  "created_at" : "Sun Mar 24 18:43:19 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "315893044908011522",
  "text" : "1) Are you a feminist? 2) Do you believe in social, political, and economic equality of the sexes?",
  "id" : 315893044908011522,
  "created_at" : "Sun Mar 24 18:29:05 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brett Shell",
      "screen_name" : "Brethren",
      "indices" : [ 0, 9 ],
      "id_str" : "9857922",
      "id" : 9857922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "315877265701498881",
  "geo" : {
  },
  "id_str" : "315880659610648576",
  "in_reply_to_user_id" : 9857922,
  "text" : "@Brethren I kept some and would've kept more that was too big. About Kuhlman prices... though they seem to have a range.",
  "id" : 315880659610648576,
  "in_reply_to_status_id" : 315877265701498881,
  "created_at" : "Sun Mar 24 17:39:52 +0000 2013",
  "in_reply_to_screen_name" : "Brethren",
  "in_reply_to_user_id_str" : "9857922",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Britt Crawford",
      "screen_name" : "britt",
      "indices" : [ 0, 6 ],
      "id_str" : "5362",
      "id" : 5362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "315698539802001408",
  "geo" : {
  },
  "id_str" : "315877153206059008",
  "in_reply_to_user_id" : 5362,
  "text" : "@britt Not sure but I wouldn't be surprised if overconfidence actually increases chance of success, and chance of starting at all.",
  "id" : 315877153206059008,
  "in_reply_to_status_id" : 315698539802001408,
  "created_at" : "Sun Mar 24 17:25:56 +0000 2013",
  "in_reply_to_screen_name" : "britt",
  "in_reply_to_user_id_str" : "5362",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Carson",
      "screen_name" : "okdan",
      "indices" : [ 0, 6 ],
      "id_str" : "35679148",
      "id" : 35679148
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "315871513423261696",
  "geo" : {
  },
  "id_str" : "315875019928510464",
  "in_reply_to_user_id" : 35679148,
  "text" : "@okdan Sure! I only just realized I could rate my box on the website. Make that more obvious!",
  "id" : 315875019928510464,
  "in_reply_to_status_id" : 315871513423261696,
  "created_at" : "Sun Mar 24 17:17:28 +0000 2013",
  "in_reply_to_screen_name" : "okdan",
  "in_reply_to_user_id_str" : "35679148",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trunk Club",
      "screen_name" : "TrunkClub",
      "indices" : [ 13, 23 ],
      "id_str" : "19734728",
      "id" : 19734728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https://t.co/u02XdshXSn",
      "expanded_url" : "https://trunkclub.com/invited/Buster0000000scw",
      "display_url" : "trunkclub.com/invited/Buster\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "315868906642350080",
  "text" : "Got my first @trunkclub box of stuff. They get to know you, ship you clothes, and you keep some and return the rest! https://t.co/u02XdshXSn",
  "id" : 315868906642350080,
  "created_at" : "Sun Mar 24 16:53:10 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Cook",
      "screen_name" : "johnhcook",
      "indices" : [ 21, 31 ],
      "id_str" : "14326765",
      "id" : 14326765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http://t.co/mC2ZTnRdAJ",
      "expanded_url" : "http://www.geekwire.com/2013/tony-wright-chucking-tech-industry-travel-world/",
      "display_url" : "geekwire.com/2013/tony-wrig\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "315853062453473280",
  "geo" : {
  },
  "id_str" : "315861503003725825",
  "in_reply_to_user_id" : 14326765,
  "text" : "Excited for Tony! RT @johnhcook: Tony Wright is chucking the tech industry to travel around the world: http://t.co/mC2ZTnRdAJ",
  "id" : 315861503003725825,
  "in_reply_to_status_id" : 315853062453473280,
  "created_at" : "Sun Mar 24 16:23:45 +0000 2013",
  "in_reply_to_screen_name" : "johnhcook",
  "in_reply_to_user_id_str" : "14326765",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 51 ],
      "url" : "http://t.co/DDDGQSnUpV",
      "expanded_url" : "http://flic.kr/p/e5x77F",
      "display_url" : "flic.kr/p/e5x77F"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859666, -122.2755 ]
  },
  "id_str" : "315680962463801345",
  "text" : "8:36pm Probably getting sick http://t.co/DDDGQSnUpV",
  "id" : 315680962463801345,
  "created_at" : "Sun Mar 24 04:26:21 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Hogg",
      "screen_name" : "cwhogg",
      "indices" : [ 0, 7 ],
      "id_str" : "15727738",
      "id" : 15727738
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "315665266493227008",
  "geo" : {
  },
  "id_str" : "315670100122406913",
  "in_reply_to_user_id" : 15727738,
  "text" : "@cwhogg Overconfidence will lead to ignoring signs of danger and making poor decisions in both cases. And yet, we look for it in leaders.",
  "id" : 315670100122406913,
  "in_reply_to_status_id" : 315665266493227008,
  "created_at" : "Sun Mar 24 03:43:11 +0000 2013",
  "in_reply_to_screen_name" : "cwhogg",
  "in_reply_to_user_id_str" : "15727738",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Gralian",
      "screen_name" : "Tapeleg",
      "indices" : [ 0, 8 ],
      "id_str" : "7826622",
      "id" : 7826622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http://t.co/kO4I77Bqss",
      "expanded_url" : "http://wayoftheduck.com/1000-small-things",
      "display_url" : "wayoftheduck.com/1000-small-thi\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "315660199794966528",
  "geo" : {
  },
  "id_str" : "315660821172744192",
  "in_reply_to_user_id" : 7826622,
  "text" : "@Tapeleg Not directly but here's a recent one where it was applied: http://t.co/kO4I77Bqss",
  "id" : 315660821172744192,
  "in_reply_to_status_id" : 315660199794966528,
  "created_at" : "Sun Mar 24 03:06:19 +0000 2013",
  "in_reply_to_screen_name" : "Tapeleg",
  "in_reply_to_user_id_str" : "7826622",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Buzz Andersen",
      "screen_name" : "buzz",
      "indices" : [ 0, 5 ],
      "id_str" : "528",
      "id" : 528
    }, {
      "name" : "Anil Dash",
      "screen_name" : "anildash",
      "indices" : [ 6, 15 ],
      "id_str" : "36823",
      "id" : 36823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "315653786397966338",
  "geo" : {
  },
  "id_str" : "315659438478479361",
  "in_reply_to_user_id" : 528,
  "text" : "@buzz @anildash I agree. It's just ominous to me that taking the more dangerous/faulty/wrong stance is in some ways more rational/desirable.",
  "id" : 315659438478479361,
  "in_reply_to_status_id" : 315653786397966338,
  "created_at" : "Sun Mar 24 03:00:49 +0000 2013",
  "in_reply_to_screen_name" : "buzz",
  "in_reply_to_user_id_str" : "528",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Hogg",
      "screen_name" : "cwhogg",
      "indices" : [ 0, 7 ],
      "id_str" : "15727738",
      "id" : 15727738
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "315653169780776960",
  "geo" : {
  },
  "id_str" : "315657733800071169",
  "in_reply_to_user_id" : 15727738,
  "text" : "@cwhogg They were both talking about the first one... basically people trying to predict the future (entrepreneurs, economists, etc).",
  "id" : 315657733800071169,
  "in_reply_to_status_id" : 315653169780776960,
  "created_at" : "Sun Mar 24 02:54:03 +0000 2013",
  "in_reply_to_screen_name" : "cwhogg",
  "in_reply_to_user_id_str" : "15727738",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Martell",
      "screen_name" : "danmartell",
      "indices" : [ 0, 11 ],
      "id_str" : "10638782",
      "id" : 10638782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "315651870083383298",
  "geo" : {
  },
  "id_str" : "315656572237934593",
  "in_reply_to_user_id" : 10638782,
  "text" : "@danmartell The NRA so I could run it into the ground.",
  "id" : 315656572237934593,
  "in_reply_to_status_id" : 315651870083383298,
  "created_at" : "Sun Mar 24 02:49:26 +0000 2013",
  "in_reply_to_screen_name" : "danmartell",
  "in_reply_to_user_id_str" : "10638782",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian Chan",
      "screen_name" : "chanian",
      "indices" : [ 0, 8 ],
      "id_str" : "22891211",
      "id" : 22891211
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "315646241583292417",
  "geo" : {
  },
  "id_str" : "315655817783304192",
  "in_reply_to_user_id" : 22891211,
  "text" : "@chanian How are the fish?",
  "id" : 315655817783304192,
  "in_reply_to_status_id" : 315646241583292417,
  "created_at" : "Sun Mar 24 02:46:26 +0000 2013",
  "in_reply_to_screen_name" : "chanian",
  "in_reply_to_user_id_str" : "22891211",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Coates",
      "screen_name" : "tomcoates",
      "indices" : [ 0, 10 ],
      "id_str" : "12514",
      "id" : 12514
    }, {
      "name" : "Erika Hall",
      "screen_name" : "mulegirl",
      "indices" : [ 11, 20 ],
      "id_str" : "2391",
      "id" : 2391
    }, {
      "name" : "Anil Dash",
      "screen_name" : "anildash",
      "indices" : [ 21, 30 ],
      "id_str" : "36823",
      "id" : 36823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "315614981192290305",
  "geo" : {
  },
  "id_str" : "315618002861178881",
  "in_reply_to_user_id" : 12514,
  "text" : "@tomcoates @mulegirl @anildash But that would end the Internet!",
  "id" : 315618002861178881,
  "in_reply_to_status_id" : 315614981192290305,
  "created_at" : "Sun Mar 24 00:16:10 +0000 2013",
  "in_reply_to_screen_name" : "tomcoates",
  "in_reply_to_user_id_str" : "12514",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://vine.co\" rel=\"nofollow\">Vine - Make a Scene</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 56 ],
      "url" : "https://t.co/1Kyrq9vXIi",
      "expanded_url" : "https://vine.co/v/bDXB7XllJpJ",
      "display_url" : "vine.co/v/bDXB7XllJpJ"
    } ]
  },
  "geo" : {
  },
  "id_str" : "315613866518249472",
  "text" : "Along came a crocodile... CHOMP. https://t.co/1Kyrq9vXIi",
  "id" : 315613866518249472,
  "created_at" : "Sat Mar 23 23:59:44 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erika Hall",
      "screen_name" : "mulegirl",
      "indices" : [ 0, 9 ],
      "id_str" : "2391",
      "id" : 2391
    }, {
      "name" : "Anil Dash",
      "screen_name" : "anildash",
      "indices" : [ 10, 19 ],
      "id_str" : "36823",
      "id" : 36823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "315603956917231617",
  "geo" : {
  },
  "id_str" : "315608060548763649",
  "in_reply_to_user_id" : 2391,
  "text" : "@mulegirl @anildash True, but first couple chapters in Lean In make a good case that overconfidence gets you closer to leadership roles.",
  "id" : 315608060548763649,
  "in_reply_to_status_id" : 315603956917231617,
  "created_at" : "Sat Mar 23 23:36:40 +0000 2013",
  "in_reply_to_screen_name" : "mulegirl",
  "in_reply_to_user_id_str" : "2391",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Britt Crawford",
      "screen_name" : "britt",
      "indices" : [ 0, 6 ],
      "id_str" : "5362",
      "id" : 5362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "315599810751262720",
  "geo" : {
  },
  "id_str" : "315600015919837184",
  "in_reply_to_user_id" : 5362,
  "text" : "@britt Both the confident and the insecure are equally represented there.",
  "id" : 315600015919837184,
  "in_reply_to_status_id" : 315599810751262720,
  "created_at" : "Sat Mar 23 23:04:42 +0000 2013",
  "in_reply_to_screen_name" : "britt",
  "in_reply_to_user_id_str" : "5362",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Kelleher",
      "screen_name" : "etienneshrdlu",
      "indices" : [ 0, 14 ],
      "id_str" : "106122883",
      "id" : 106122883
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "315599331459743744",
  "geo" : {
  },
  "id_str" : "315599839142502400",
  "in_reply_to_user_id" : 106122883,
  "text" : "@etienneshrdlu I believe Nate Silver does. Though he does not address the problem of overconfidence's utility and effectiveness in society.",
  "id" : 315599839142502400,
  "in_reply_to_status_id" : 315599331459743744,
  "created_at" : "Sat Mar 23 23:03:59 +0000 2013",
  "in_reply_to_screen_name" : "etienneshrdlu",
  "in_reply_to_user_id_str" : "106122883",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Buzz Andersen",
      "screen_name" : "buzz",
      "indices" : [ 0, 5 ],
      "id_str" : "528",
      "id" : 528
    }, {
      "name" : "Erika Hall",
      "screen_name" : "mulegirl",
      "indices" : [ 6, 15 ],
      "id_str" : "2391",
      "id" : 2391
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "315599047421480960",
  "geo" : {
  },
  "id_str" : "315599363609071616",
  "in_reply_to_user_id" : 528,
  "text" : "@buzz @mulegirl Kickstarter it, I'm in!",
  "id" : 315599363609071616,
  "in_reply_to_status_id" : 315599047421480960,
  "created_at" : "Sat Mar 23 23:02:06 +0000 2013",
  "in_reply_to_screen_name" : "buzz",
  "in_reply_to_user_id_str" : "528",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Buzz Andersen",
      "screen_name" : "buzz",
      "indices" : [ 1, 6 ],
      "id_str" : "528",
      "id" : 528
    }, {
      "name" : "Erika Hall",
      "screen_name" : "mulegirl",
      "indices" : [ 7, 16 ],
      "id_str" : "2391",
      "id" : 2391
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http://t.co/Lr287sGXUO",
      "expanded_url" : "http://bit.ly/Y70lkT",
      "display_url" : "bit.ly/Y70lkT"
    } ]
  },
  "in_reply_to_status_id_str" : "315598480112492544",
  "geo" : {
  },
  "id_str" : "315599061107482624",
  "in_reply_to_user_id" : 528,
  "text" : ".@buzz @mulegirl The scary flip side to overconfidence is depressive realism: http://t.co/Lr287sGXUO",
  "id" : 315599061107482624,
  "in_reply_to_status_id" : 315598480112492544,
  "created_at" : "Sat Mar 23 23:00:54 +0000 2013",
  "in_reply_to_screen_name" : "buzz",
  "in_reply_to_user_id_str" : "528",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anil Dash",
      "screen_name" : "anildash",
      "indices" : [ 0, 9 ],
      "id_str" : "36823",
      "id" : 36823
    }, {
      "name" : "Erika Hall",
      "screen_name" : "mulegirl",
      "indices" : [ 10, 19 ],
      "id_str" : "2391",
      "id" : 2391
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "315597946068537344",
  "geo" : {
  },
  "id_str" : "315598606814040065",
  "in_reply_to_user_id" : 36823,
  "text" : "@anildash @mulegirl I don't think they are. I just read their latest books back to back.",
  "id" : 315598606814040065,
  "in_reply_to_status_id" : 315597946068537344,
  "created_at" : "Sat Mar 23 22:59:06 +0000 2013",
  "in_reply_to_screen_name" : "anildash",
  "in_reply_to_user_id_str" : "36823",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erika Hall",
      "screen_name" : "mulegirl",
      "indices" : [ 0, 9 ],
      "id_str" : "2391",
      "id" : 2391
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "315597429074440192",
  "geo" : {
  },
  "id_str" : "315598103212326913",
  "in_reply_to_user_id" : 2391,
  "text" : "@mulegirl I agree that both are true. What is the best response to this information? Should we fight overconfidence or embrace it?",
  "id" : 315598103212326913,
  "in_reply_to_status_id" : 315597429074440192,
  "created_at" : "Sat Mar 23 22:57:05 +0000 2013",
  "in_reply_to_screen_name" : "mulegirl",
  "in_reply_to_user_id_str" : "2391",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http://t.co/YezPSn7pfw",
      "expanded_url" : "http://bit.ly/Y6ZOzj",
      "display_url" : "bit.ly/Y6ZOzj"
    } ]
  },
  "geo" : {
  },
  "id_str" : "315597685811990528",
  "text" : "\"Overconfidence Effect: when someone's confidence in their judgments is greater than their accuracy\" - http://t.co/YezPSn7pfw",
  "id" : 315597685811990528,
  "created_at" : "Sat Mar 23 22:55:26 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "315596941536927744",
  "text" : "Nate Silver says overconfidence is society's most pernicious bias. Sheryl Sandberg points out that it gives competitive advantage. Thoughts?",
  "id" : 315596941536927744,
  "created_at" : "Sat Mar 23 22:52:29 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "daisy barringer",
      "screen_name" : "daisy",
      "indices" : [ 0, 6 ],
      "id_str" : "7390862",
      "id" : 7390862
    }, {
      "name" : "Anil Dash",
      "screen_name" : "anildash",
      "indices" : [ 7, 16 ],
      "id_str" : "36823",
      "id" : 36823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "315557797796397057",
  "geo" : {
  },
  "id_str" : "315562700736458752",
  "in_reply_to_user_id" : 7390862,
  "text" : "@daisy @anildash The same impulse that compels you to make judgements publicly instead of privately with her probably compelled her.",
  "id" : 315562700736458752,
  "in_reply_to_status_id" : 315557797796397057,
  "created_at" : "Sat Mar 23 20:36:25 +0000 2013",
  "in_reply_to_screen_name" : "daisy",
  "in_reply_to_user_id_str" : "7390862",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "daisy barringer",
      "screen_name" : "daisy",
      "indices" : [ 0, 6 ],
      "id_str" : "7390862",
      "id" : 7390862
    }, {
      "name" : "Anil Dash",
      "screen_name" : "anildash",
      "indices" : [ 7, 16 ],
      "id_str" : "36823",
      "id" : 36823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "315550382958981120",
  "geo" : {
  },
  "id_str" : "315556350526636032",
  "in_reply_to_user_id" : 7390862,
  "text" : "@daisy @anildash All she did was judge how they were handling the situation too: poorly. Should you be treated the same as her?",
  "id" : 315556350526636032,
  "in_reply_to_status_id" : 315550382958981120,
  "created_at" : "Sat Mar 23 20:11:11 +0000 2013",
  "in_reply_to_screen_name" : "daisy",
  "in_reply_to_user_id_str" : "7390862",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 17, 27 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "315542877080023040",
  "text" : "969. No idea how @kellianne never mentioned that going up the hill to College Ave on a bike pulling Niko's chariot wasn't so easy.",
  "id" : 315542877080023040,
  "created_at" : "Sat Mar 23 19:17:39 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Neilson",
      "screen_name" : "TheCulprit",
      "indices" : [ 0, 11 ],
      "id_str" : "6726182",
      "id" : 6726182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "315517479793352704",
  "geo" : {
  },
  "id_str" : "315523990481432576",
  "in_reply_to_user_id" : 6726182,
  "text" : "@TheCulprit I probably should since things aren't really getting much better on their own.",
  "id" : 315523990481432576,
  "in_reply_to_status_id" : 315517479793352704,
  "created_at" : "Sat Mar 23 18:02:36 +0000 2013",
  "in_reply_to_screen_name" : "TheCulprit",
  "in_reply_to_user_id_str" : "6726182",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fareed Mosavat",
      "screen_name" : "far33d",
      "indices" : [ 0, 7 ],
      "id_str" : "1264641",
      "id" : 1264641
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "315510471463690241",
  "geo" : {
  },
  "id_str" : "315511648582508544",
  "in_reply_to_user_id" : 1264641,
  "text" : "@far33d I use the built in sharing to fb but like having more control over the tweet + card in Twitter. Bias: I'm on the Twitter Cards team.",
  "id" : 315511648582508544,
  "in_reply_to_status_id" : 315510471463690241,
  "created_at" : "Sat Mar 23 17:13:33 +0000 2013",
  "in_reply_to_screen_name" : "far33d",
  "in_reply_to_user_id_str" : "1264641",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/buster/status/315509232109756418/photo/1",
      "indices" : [ 121, 143 ],
      "url" : "http://t.co/krNZwEcKHu",
      "media_url" : "http://pbs.twimg.com/media/BGDp-ZfCIAANhZL.jpg",
      "id_str" : "315509232118145024",
      "id" : 315509232118145024,
      "media_url_https" : "https://pbs.twimg.com/media/BGDp-ZfCIAANhZL.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 577
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 577
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 603,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 577
      } ],
      "display_url" : "pic.twitter.com/krNZwEcKHu"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "315509232109756418",
  "text" : "970. Longest, slowest run yet: 6.25mi@10:00pace. Body felt like drying cement the whole way. Knee &amp; hip being weird. http://t.co/krNZwEcKHu",
  "id" : 315509232109756418,
  "created_at" : "Sat Mar 23 17:03:57 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sheryl Sandberg",
      "screen_name" : "sherylsandberg",
      "indices" : [ 36, 51 ],
      "id_str" : "19506790",
      "id" : 19506790
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "315499509893451778",
  "text" : "Previous quote by Gloria Steinem in @sherylsandberg's Lean In.",
  "id" : 315499509893451778,
  "created_at" : "Sat Mar 23 16:25:19 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "315499067004309505",
  "text" : "\"Nobody can have 2 jobs, perfect children, cook 3 meals, &amp; be multi-orgasmic til dawn. Superwoman is the adversary of the woman's movement.\"",
  "id" : 315499067004309505,
  "created_at" : "Sat Mar 23 16:23:33 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 52 ],
      "url" : "http://t.co/GeEsDqcy8i",
      "expanded_url" : "http://flic.kr/p/e5nPh4",
      "display_url" : "flic.kr/p/e5nPh4"
    } ]
  },
  "geo" : {
  },
  "id_str" : "315488953165807616",
  "text" : "Conductor hat bike helmet guy http://t.co/GeEsDqcy8i",
  "id" : 315488953165807616,
  "created_at" : "Sat Mar 23 15:43:22 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Pullara",
      "screen_name" : "sampullara",
      "indices" : [ 0, 11 ],
      "id_str" : "668473",
      "id" : 668473
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "315327744986734592",
  "geo" : {
  },
  "id_str" : "315330365248110594",
  "in_reply_to_user_id" : 668473,
  "text" : "@sampullara Excel maybe but check out keen.io too.",
  "id" : 315330365248110594,
  "in_reply_to_status_id" : 315327744986734592,
  "created_at" : "Sat Mar 23 05:13:12 +0000 2013",
  "in_reply_to_screen_name" : "sampullara",
  "in_reply_to_user_id_str" : "668473",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dana McCallum",
      "screen_name" : "DanaDanger",
      "indices" : [ 0, 11 ],
      "id_str" : "821958",
      "id" : 821958
    }, {
      "name" : "Alissa",
      "screen_name" : "alissa",
      "indices" : [ 12, 19 ],
      "id_str" : "94",
      "id" : 94
    }, {
      "name" : "Ryan King",
      "screen_name" : "rk",
      "indices" : [ 20, 23 ],
      "id_str" : "19853",
      "id" : 19853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "315307929521766400",
  "geo" : {
  },
  "id_str" : "315313065618993152",
  "in_reply_to_user_id" : 821958,
  "text" : "@DanaDanger @alissa @rk Can we also have one sorted by twitter user id? :)",
  "id" : 315313065618993152,
  "in_reply_to_status_id" : 315307929521766400,
  "created_at" : "Sat Mar 23 04:04:27 +0000 2013",
  "in_reply_to_screen_name" : "DanaDanger",
  "in_reply_to_user_id_str" : "821958",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "everynight",
      "indices" : [ 38, 49 ]
    } ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http://t.co/UElPKKiwcM",
      "expanded_url" : "http://flic.kr/p/e5gy8a",
      "display_url" : "flic.kr/p/e5gy8a"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859666, -122.2755 ]
  },
  "id_str" : "315309159803387904",
  "text" : "8:36pm It's a smurf pants kinda night #everynight http://t.co/UElPKKiwcM",
  "id" : 315309159803387904,
  "created_at" : "Sat Mar 23 03:48:56 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "countingit",
      "indices" : [ 122, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "315306675143864320",
  "text" : "971. Aspiring marathoners eat an occasional delicious burger with lots of avocado on a beautiful Friday afternoon, right? #countingit",
  "id" : 315306675143864320,
  "created_at" : "Sat Mar 23 03:39:04 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Sippey",
      "screen_name" : "sippey",
      "indices" : [ 0, 7 ],
      "id_str" : "4711",
      "id" : 4711
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "woods",
      "indices" : [ 8, 14 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "315291392974921728",
  "geo" : {
  },
  "id_str" : "315304635936161795",
  "in_reply_to_user_id" : 4711,
  "text" : "@sippey #woods",
  "id" : 315304635936161795,
  "in_reply_to_status_id" : 315291392974921728,
  "created_at" : "Sat Mar 23 03:30:57 +0000 2013",
  "in_reply_to_screen_name" : "sippey",
  "in_reply_to_user_id_str" : "4711",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Stamatiou",
      "screen_name" : "Stammy",
      "indices" : [ 3, 10 ],
      "id_str" : "624683",
      "id" : 624683
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "315245954372612096",
  "text" : "RT @Stammy: A sensor that vibrates when you are slouching. Because your fitbit, Up,  fuelband &amp; polar watch are not enough.  http://t.c\u2026",
  "retweeted_status" : {
    "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http://t.co/SXNDGSAwz2",
        "expanded_url" : "http://www.lumoback.com/",
        "display_url" : "lumoback.com"
      } ]
    },
    "geo" : {
    },
    "id_str" : "315245731231436800",
    "text" : "A sensor that vibrates when you are slouching. Because your fitbit, Up,  fuelband &amp; polar watch are not enough.  http://t.co/SXNDGSAwz2",
    "id" : 315245731231436800,
    "created_at" : "Fri Mar 22 23:36:53 +0000 2013",
    "user" : {
      "name" : "Paul Stamatiou",
      "screen_name" : "Stammy",
      "protected" : false,
      "id_str" : "624683",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1778867511/Screen_Shot_2012-01-24_at_2.03.52_PM_normal.png",
      "id" : 624683,
      "verified" : false
    }
  },
  "id" : 315245954372612096,
  "created_at" : "Fri Mar 22 23:37:47 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "April Schiller",
      "screen_name" : "the_april",
      "indices" : [ 0, 10 ],
      "id_str" : "16644937",
      "id" : 16644937
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "315117820008611840",
  "geo" : {
  },
  "id_str" : "315119640873426944",
  "in_reply_to_user_id" : 16644937,
  "text" : "@the_april Awesome!",
  "id" : 315119640873426944,
  "in_reply_to_status_id" : 315117820008611840,
  "created_at" : "Fri Mar 22 15:15:51 +0000 2013",
  "in_reply_to_screen_name" : "the_april",
  "in_reply_to_user_id_str" : "16644937",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "April Schiller",
      "screen_name" : "the_april",
      "indices" : [ 0, 10 ],
      "id_str" : "16644937",
      "id" : 16644937
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "315114864928514048",
  "geo" : {
  },
  "id_str" : "315116628679475202",
  "in_reply_to_user_id" : 16644937,
  "text" : "@the_april It works really well for a month or two. Then you gotta switch it up again. What's your competition?",
  "id" : 315116628679475202,
  "in_reply_to_status_id" : 315114864928514048,
  "created_at" : "Fri Mar 22 15:03:53 +0000 2013",
  "in_reply_to_screen_name" : "the_april",
  "in_reply_to_user_id_str" : "16644937",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "April Schiller",
      "screen_name" : "the_april",
      "indices" : [ 0, 10 ],
      "id_str" : "16644937",
      "id" : 16644937
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "315110311126507520",
  "geo" : {
  },
  "id_str" : "315112277206507520",
  "in_reply_to_user_id" : 16644937,
  "text" : "@the_april Thanks! I'm thinking of going double or nothing next month.",
  "id" : 315112277206507520,
  "in_reply_to_status_id" : 315110311126507520,
  "created_at" : "Fri Mar 22 14:46:36 +0000 2013",
  "in_reply_to_screen_name" : "the_april",
  "in_reply_to_user_id_str" : "16644937",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "teamprensky",
      "indices" : [ 0, 12 ]
    }, {
      "text" : "thenativeshavewon",
      "indices" : [ 13, 31 ]
    } ],
    "urls" : [ {
      "indices" : [ 32, 54 ],
      "url" : "http://t.co/TVbulUuHCw",
      "expanded_url" : "http://m.theatlantic.com/magazine/archive/2013/04/the-touch-screen-generation/309250/?single_page=true",
      "display_url" : "m.theatlantic.com/magazine/archi\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "315110571626356738",
  "text" : "#teamprensky #thenativeshavewon http://t.co/TVbulUuHCw",
  "id" : 315110571626356738,
  "created_at" : "Fri Mar 22 14:39:49 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hiren",
      "screen_name" : "bebopconnect",
      "indices" : [ 0, 13 ],
      "id_str" : "238640592",
      "id" : 238640592
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "315106833738125313",
  "geo" : {
  },
  "id_str" : "315109590171783168",
  "in_reply_to_user_id" : 238640592,
  "text" : "@bebopconnect Sounds great!",
  "id" : 315109590171783168,
  "in_reply_to_status_id" : 315106833738125313,
  "created_at" : "Fri Mar 22 14:35:55 +0000 2013",
  "in_reply_to_screen_name" : "bebopconnect",
  "in_reply_to_user_id_str" : "238640592",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Omid Ashtari",
      "screen_name" : "omid",
      "indices" : [ 0, 5 ],
      "id_str" : "114971521",
      "id" : 114971521
    }, {
      "name" : "DietBet",
      "screen_name" : "DietBet",
      "indices" : [ 6, 14 ],
      "id_str" : "185399301",
      "id" : 185399301
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "315108258027274241",
  "geo" : {
  },
  "id_str" : "315109462232940544",
  "in_reply_to_user_id" : 114971521,
  "text" : "@omid @dietbet rookie mistake.",
  "id" : 315109462232940544,
  "in_reply_to_status_id" : 315108258027274241,
  "created_at" : "Fri Mar 22 14:35:24 +0000 2013",
  "in_reply_to_screen_name" : "omid",
  "in_reply_to_user_id_str" : "114971521",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DietBet",
      "screen_name" : "DietBet",
      "indices" : [ 15, 23 ],
      "id_str" : "185399301",
      "id" : 185399301
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http://t.co/Nf3NVgG5SO",
      "expanded_url" : "http://flic.kr/p/e5dVz1",
      "display_url" : "flic.kr/p/e5dVz1"
    } ]
  },
  "geo" : {
  },
  "id_str" : "315107973938692096",
  "text" : "972. Passed my @dietbet challenge with a week to spare. http://t.co/Nf3NVgG5SO",
  "id" : 315107973938692096,
  "created_at" : "Fri Mar 22 14:29:30 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http://t.co/p4VC7C1mvo",
      "expanded_url" : "http://movi.es/Vp5VO",
      "display_url" : "movi.es/Vp5VO"
    } ]
  },
  "geo" : {
  },
  "id_str" : "314979349679980545",
  "text" : "Oooh, Hemlock Grove, Netflix's next original series starting April 19th http://t.co/p4VC7C1mvo",
  "id" : 314979349679980545,
  "created_at" : "Fri Mar 22 05:58:23 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrice O'Rourke",
      "screen_name" : "Patrice_ORourke",
      "indices" : [ 3, 19 ],
      "id_str" : "120151540",
      "id" : 120151540
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http://t.co/lAhnng7VJj",
      "expanded_url" : "http://thkpr.gs/YrmQAm",
      "display_url" : "thkpr.gs/YrmQAm"
    } ]
  },
  "geo" : {
  },
  "id_str" : "314977068788101120",
  "text" : "RT @Patrice_ORourke: Starbucks CEO: If You Don\u2019t Like Marriage Equality, Feel Free To Sell Your Starbucks Stock http://t.co/lAhnng7VJj via \u2026",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "ThinkProgress",
        "screen_name" : "thinkprogress",
        "indices" : [ 118, 132 ],
        "id_str" : "55355654",
        "id" : 55355654
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 113 ],
        "url" : "http://t.co/lAhnng7VJj",
        "expanded_url" : "http://thkpr.gs/YrmQAm",
        "display_url" : "thkpr.gs/YrmQAm"
      } ]
    },
    "geo" : {
    },
    "id_str" : "314964054265454592",
    "text" : "Starbucks CEO: If You Don\u2019t Like Marriage Equality, Feel Free To Sell Your Starbucks Stock http://t.co/lAhnng7VJj via @thinkprogress",
    "id" : 314964054265454592,
    "created_at" : "Fri Mar 22 04:57:36 +0000 2013",
    "user" : {
      "name" : "Patrice O'Rourke",
      "screen_name" : "Patrice_ORourke",
      "protected" : false,
      "id_str" : "120151540",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000131257567/56273cf4776cffe58a0347fe35d9375c_normal.jpeg",
      "id" : 120151540,
      "verified" : false
    }
  },
  "id" : 314977068788101120,
  "created_at" : "Fri Mar 22 05:49:19 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hiren",
      "screen_name" : "bebopconnect",
      "indices" : [ 0, 13 ],
      "id_str" : "238640592",
      "id" : 238640592
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314912421112344576",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7933950589, -122.39644727 ]
  },
  "id_str" : "314913586097041408",
  "in_reply_to_user_id" : 238640592,
  "text" : "@bebopconnect How would you phrase #2 in \"I'm an aspiring ___.\" Not with a job title but with a kind of person.",
  "id" : 314913586097041408,
  "in_reply_to_status_id" : 314912421112344576,
  "created_at" : "Fri Mar 22 01:37:04 +0000 2013",
  "in_reply_to_screen_name" : "bebopconnect",
  "in_reply_to_user_id_str" : "238640592",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MG Siegler",
      "screen_name" : "parislemon",
      "indices" : [ 0, 11 ],
      "id_str" : "652193",
      "id" : 652193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314889279975333888",
  "geo" : {
  },
  "id_str" : "314889774647369730",
  "in_reply_to_user_id" : 652193,
  "text" : "@parislemon so sloppy. i'm like, how do you just conjure up 3% more universe?",
  "id" : 314889774647369730,
  "in_reply_to_status_id" : 314889279975333888,
  "created_at" : "Fri Mar 22 00:02:27 +0000 2013",
  "in_reply_to_screen_name" : "parislemon",
  "in_reply_to_user_id_str" : "652193",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://bufferapp.com\" rel=\"nofollow\">Buffer</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http://t.co/oYABra1m2W",
      "expanded_url" : "http://nyti.ms/YuBYd6",
      "display_url" : "nyti.ms/YuBYd6"
    } ]
  },
  "geo" : {
  },
  "id_str" : "314888076142993409",
  "text" : "\"An earlier version of this article misstated the % of the universe by mass that is dark energy. It is 68%, not 71%.\" http://t.co/oYABra1m2W",
  "id" : 314888076142993409,
  "created_at" : "Thu Mar 21 23:55:42 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Derek Sivers",
      "screen_name" : "sivers",
      "indices" : [ 84, 91 ],
      "id_str" : "2206131",
      "id" : 2206131
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 79 ],
      "url" : "http://t.co/c8hVmWUQFu",
      "expanded_url" : "http://sivers.org/hi",
      "display_url" : "sivers.org/hi"
    } ]
  },
  "geo" : {
  },
  "id_str" : "314879775304982528",
  "text" : "When it makes sense to use humans instead of algorithms: http://t.co/c8hVmWUQFu /by @sivers",
  "id" : 314879775304982528,
  "created_at" : "Thu Mar 21 23:22:43 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Couch",
      "screen_name" : "couch",
      "indices" : [ 3, 9 ],
      "id_str" : "631823",
      "id" : 631823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "314876768764952576",
  "text" : "RT @couch: So happy to see that the Twitter archive feature is now available to all, in all of our supported languages. https://t.co/EFB ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 109, 132 ],
        "url" : "https://t.co/EFB4eyKyGD",
        "expanded_url" : "https://twitter.com/twitter/status/314875925953130497",
        "display_url" : "twitter.com/twitter/status\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "314876664213540865",
    "text" : "So happy to see that the Twitter archive feature is now available to all, in all of our supported languages. https://t.co/EFB4eyKyGD",
    "id" : 314876664213540865,
    "created_at" : "Thu Mar 21 23:10:21 +0000 2013",
    "user" : {
      "name" : "Bill Couch",
      "screen_name" : "couch",
      "protected" : false,
      "id_str" : "631823",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000014386973/f2fb401cd715a4d36fef103efe02ec06_normal.jpeg",
      "id" : 631823,
      "verified" : false
    }
  },
  "id" : 314876768764952576,
  "created_at" : "Thu Mar 21 23:10:46 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Frommer",
      "screen_name" : "fromedome",
      "indices" : [ 119, 129 ],
      "id_str" : "8479062",
      "id" : 8479062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http://t.co/VQbOR8IHDw",
      "expanded_url" : "http://www.splatf.com/2013/03/twitter-seven/",
      "display_url" : "splatf.com/2013/03/twitte\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "314833075819401216",
  "text" : "Twitter is 7 years old today! Here are 7 things that could have killed Twitter, but didn't: http://t.co/VQbOR8IHDw /by @fromedome",
  "id" : 314833075819401216,
  "created_at" : "Thu Mar 21 20:17:09 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tanner Christensen",
      "screen_name" : "tannerc",
      "indices" : [ 0, 8 ],
      "id_str" : "9161482",
      "id" : 9161482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314771651063599104",
  "geo" : {
  },
  "id_str" : "314799599242063872",
  "in_reply_to_user_id" : 9161482,
  "text" : "@tannerc That's the problem with streaks I guess.",
  "id" : 314799599242063872,
  "in_reply_to_status_id" : 314771651063599104,
  "created_at" : "Thu Mar 21 18:04:07 +0000 2013",
  "in_reply_to_screen_name" : "tannerc",
  "in_reply_to_user_id_str" : "9161482",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stewart Butterfield",
      "screen_name" : "stewart",
      "indices" : [ 0, 8 ],
      "id_str" : "5699",
      "id" : 5699
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314777212844908547",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7764582897, -122.4167421857 ]
  },
  "id_str" : "314783212427689984",
  "in_reply_to_user_id" : 5699,
  "text" : "@stewart Happy birthday old chum!",
  "id" : 314783212427689984,
  "in_reply_to_status_id" : 314777212844908547,
  "created_at" : "Thu Mar 21 16:59:00 +0000 2013",
  "in_reply_to_screen_name" : "stewart",
  "in_reply_to_user_id_str" : "5699",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "~",
      "screen_name" : "iano",
      "indices" : [ 0, 5 ],
      "id_str" : "14409856",
      "id" : 14409856
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314767056224538624",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7764592925, -122.4166523573 ]
  },
  "id_str" : "314782368554688512",
  "in_reply_to_user_id" : 14409856,
  "text" : "@iano Good point. But I bet they're also counting people who visit pages without logging in. Can't verify though.",
  "id" : 314782368554688512,
  "in_reply_to_status_id" : 314767056224538624,
  "created_at" : "Thu Mar 21 16:55:39 +0000 2013",
  "in_reply_to_screen_name" : "iano",
  "in_reply_to_user_id_str" : "14409856",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 20, 28 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596177465, -122.2735450232 ]
  },
  "id_str" : "314766824858329089",
  "text" : "Does anyone know if @YouTube counts logged out users in their \"1 billion monthly users\" statement?",
  "id" : 314766824858329089,
  "created_at" : "Thu Mar 21 15:53:53 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Abby Phenix",
      "screen_name" : "aphenix",
      "indices" : [ 0, 8 ],
      "id_str" : "9926492",
      "id" : 9926492
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314760867327643648",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597855103, -122.2754933127 ]
  },
  "id_str" : "314764350504181761",
  "in_reply_to_user_id" : 9926492,
  "text" : "@aphenix the Equanimity iPhone app, which is pretty simple but great.",
  "id" : 314764350504181761,
  "in_reply_to_status_id" : 314760867327643648,
  "created_at" : "Thu Mar 21 15:44:03 +0000 2013",
  "in_reply_to_screen_name" : "aphenix",
  "in_reply_to_user_id_str" : "9926492",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/buster/status/314757064578719748/photo/1",
      "indices" : [ 71, 93 ],
      "url" : "http://t.co/csS9DVR0qI",
      "media_url" : "http://pbs.twimg.com/media/BF494fFCYAElTIO.jpg",
      "id_str" : "314757064587108353",
      "id" : 314757064587108353,
      "media_url_https" : "https://pbs.twimg.com/media/BF494fFCYAElTIO.jpg",
      "sizes" : [ {
        "h" : 577,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 192,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 577,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com/csS9DVR0qI"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596985899, -122.2754807399 ]
  },
  "id_str" : "314757064578719748",
  "text" : "973. 3 weeks of trying to remember what I'm doing for 5 minutes a day. http://t.co/csS9DVR0qI",
  "id" : 314757064578719748,
  "created_at" : "Thu Mar 21 15:15:06 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http://t.co/V0PqXpNNwT",
      "expanded_url" : "http://flic.kr/p/e4UzHN",
      "display_url" : "flic.kr/p/e4UzHN"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.777166, -122.421501 ]
  },
  "id_str" : "314581857045995522",
  "text" : "8:36pm Kvetching and gossiping about habits and behavior change http://t.co/V0PqXpNNwT",
  "id" : 314581857045995522,
  "created_at" : "Thu Mar 21 03:38:54 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Timberlake ",
      "screen_name" : "jtimberlake",
      "indices" : [ 27, 39 ],
      "id_str" : "26565946",
      "id" : 26565946
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "314524828600262657",
  "text" : "Okay, fine, I'll listen to @jtimberlake's new album.",
  "id" : 314524828600262657,
  "created_at" : "Wed Mar 20 23:52:17 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Frommer",
      "screen_name" : "fromedome",
      "indices" : [ 0, 10 ],
      "id_str" : "8479062",
      "id" : 8479062
    }, {
      "name" : "Ryan Sarver",
      "screen_name" : "rsarver",
      "indices" : [ 11, 19 ],
      "id_str" : "795649",
      "id" : 795649
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314493102700236800",
  "geo" : {
  },
  "id_str" : "314510208292491264",
  "in_reply_to_user_id" : 8479062,
  "text" : "@fromedome @rsarver I like that idea.",
  "id" : 314510208292491264,
  "in_reply_to_status_id" : 314493102700236800,
  "created_at" : "Wed Mar 20 22:54:11 +0000 2013",
  "in_reply_to_screen_name" : "fromedome",
  "in_reply_to_user_id_str" : "8479062",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Coleman",
      "screen_name" : "aarondcoleman",
      "indices" : [ 0, 14 ],
      "id_str" : "1379965428",
      "id" : 1379965428
    }, {
      "name" : "Chris Hogg",
      "screen_name" : "cwhogg",
      "indices" : [ 15, 22 ],
      "id_str" : "15727738",
      "id" : 15727738
    }, {
      "name" : "Emilio Ramirez",
      "screen_name" : "e_ramirez",
      "indices" : [ 23, 33 ],
      "id_str" : "1273564632",
      "id" : 1273564632
    }, {
      "name" : "Gary Wolf",
      "screen_name" : "agaricus",
      "indices" : [ 34, 43 ],
      "id_str" : "21678279",
      "id" : 21678279
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314421104603197440",
  "geo" : {
  },
  "id_str" : "314488440278372352",
  "in_reply_to_user_id" : 9609062,
  "text" : "@aarondcoleman @cwhogg @e_ramirez @agaricus Okay, let's go back to the Grove in Hayes Valley. I'll get there 6:30ish. First shot on me.",
  "id" : 314488440278372352,
  "in_reply_to_status_id" : 314421104603197440,
  "created_at" : "Wed Mar 20 21:27:41 +0000 2013",
  "in_reply_to_screen_name" : "aaronc",
  "in_reply_to_user_id_str" : "9609062",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeroen Haijen",
      "screen_name" : "GraphicGorilla",
      "indices" : [ 0, 15 ],
      "id_str" : "54848434",
      "id" : 54848434
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314039203266715649",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.776339233, -122.417432013 ]
  },
  "id_str" : "314455858761330688",
  "in_reply_to_user_id" : 54848434,
  "text" : "@GraphicGorilla It's basically a small thing I do to get closer to my goal that doesn't yet come naturally.",
  "id" : 314455858761330688,
  "in_reply_to_status_id" : 314039203266715649,
  "created_at" : "Wed Mar 20 19:18:13 +0000 2013",
  "in_reply_to_screen_name" : "GraphicGorilla",
  "in_reply_to_user_id_str" : "54848434",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/buster/status/314455482846822400/photo/1",
      "indices" : [ 61, 83 ],
      "url" : "http://t.co/zIojmAmm7t",
      "media_url" : "http://pbs.twimg.com/media/BF0rmHkCQAEdLo2.jpg",
      "id_str" : "314455482851016705",
      "id" : 314455482851016705,
      "media_url_https" : "https://pbs.twimg.com/media/BF0rmHkCQAEdLo2.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com/zIojmAmm7t"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7763433111, -122.4173177536 ]
  },
  "id_str" : "314455482846822400",
  "text" : "974. I didn't want to eat a salad for lunch, but did anyway. http://t.co/zIojmAmm7t",
  "id" : 314455482846822400,
  "created_at" : "Wed Mar 20 19:16:44 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brandon Wang",
      "screen_name" : "bradr",
      "indices" : [ 101, 107 ],
      "id_str" : "7994562",
      "id" : 7994562
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https://t.co/vTHczIf54L",
      "expanded_url" : "https://medium.com/were-young-lets-change-the-world/bb5a18c5840f",
      "display_url" : "medium.com/were-young-let\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.776337658, -122.4173718679 ]
  },
  "id_str" : "314454892423049219",
  "text" : "\u201CWe\u2019re just leaves in a hurricane, are we not? What does a leaf have to grab onto besides itself?\u201D - @bradr https://t.co/vTHczIf54L",
  "id" : 314454892423049219,
  "created_at" : "Wed Mar 20 19:14:23 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moe Arora",
      "screen_name" : "moearora",
      "indices" : [ 0, 9 ],
      "id_str" : "13809752",
      "id" : 13809752
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314431517705265152",
  "geo" : {
  },
  "id_str" : "314432855147175936",
  "in_reply_to_user_id" : 13809752,
  "text" : "@moearora It was actually great. I never felt like the content wasn't coming through at all\u2026 and the reader was good.",
  "id" : 314432855147175936,
  "in_reply_to_status_id" : 314431517705265152,
  "created_at" : "Wed Mar 20 17:46:49 +0000 2013",
  "in_reply_to_screen_name" : "moearora",
  "in_reply_to_user_id_str" : "13809752",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Coleman",
      "screen_name" : "aarondcoleman",
      "indices" : [ 0, 14 ],
      "id_str" : "1379965428",
      "id" : 1379965428
    }, {
      "name" : "Chris Hogg",
      "screen_name" : "cwhogg",
      "indices" : [ 15, 22 ],
      "id_str" : "15727738",
      "id" : 15727738
    }, {
      "name" : "Emilio Ramirez",
      "screen_name" : "e_ramirez",
      "indices" : [ 23, 33 ],
      "id_str" : "1273564632",
      "id" : 1273564632
    }, {
      "name" : "Gary Wolf",
      "screen_name" : "agaricus",
      "indices" : [ 34, 43 ],
      "id_str" : "21678279",
      "id" : 21678279
    }, {
      "name" : "Nick Crocker",
      "screen_name" : "nickcrocker",
      "indices" : [ 67, 79 ],
      "id_str" : "30801469",
      "id" : 30801469
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314421104603197440",
  "geo" : {
  },
  "id_str" : "314424823398948864",
  "in_reply_to_user_id" : 9609062,
  "text" : "@aarondcoleman @cwhogg @e_ramirez @agaricus I love those slides by @nickcrocker so much. Nick are you in SF? Wanna join us tonight?",
  "id" : 314424823398948864,
  "in_reply_to_status_id" : 314421104603197440,
  "created_at" : "Wed Mar 20 17:14:54 +0000 2013",
  "in_reply_to_screen_name" : "aaronc",
  "in_reply_to_user_id_str" : "9609062",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sheryl Sandberg",
      "screen_name" : "sherylsandberg",
      "indices" : [ 102, 117 ],
      "id_str" : "19506790",
      "id" : 19506790
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7780396166, -122.4158158434 ]
  },
  "id_str" : "314420506638045184",
  "text" : "\"What would you do if you weren't afraid? Writing this book is what I would do if I wasn't afraid.\" - @sherylsandberg  in Lean In",
  "id" : 314420506638045184,
  "created_at" : "Wed Mar 20 16:57:45 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mari Huertas",
      "screen_name" : "marihuertas",
      "indices" : [ 0, 12 ],
      "id_str" : "195863654",
      "id" : 195863654
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314415611029647361",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7932875075, -122.3966173861 ]
  },
  "id_str" : "314418653259001857",
  "in_reply_to_user_id" : 195863654,
  "text" : "@marihuertas Yes!",
  "id" : 314418653259001857,
  "in_reply_to_status_id" : 314415611029647361,
  "created_at" : "Wed Mar 20 16:50:23 +0000 2013",
  "in_reply_to_screen_name" : "marihuertas",
  "in_reply_to_user_id_str" : "195863654",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nate Silver",
      "screen_name" : "fivethirtyeight",
      "indices" : [ 9, 25 ],
      "id_str" : "16017475",
      "id" : 16017475
    }, {
      "name" : "Sheryl Sandberg",
      "screen_name" : "sherylsandberg",
      "indices" : [ 67, 82 ],
      "id_str" : "19506790",
      "id" : 19506790
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/buster/status/314415185404256257/photo/1",
      "indices" : [ 111, 133 ],
      "url" : "http://t.co/0qJDZOQf4t",
      "media_url" : "http://pbs.twimg.com/media/BF0G8f6CYAAOjVv.jpg",
      "id_str" : "314415185412644864",
      "id" : 314415185412644864,
      "media_url_https" : "https://pbs.twimg.com/media/BF0G8f6CYAAOjVv.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 577
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 577
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 603,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 577
      } ],
      "display_url" : "pic.twitter.com/0qJDZOQf4t"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8035802445, -122.2720641103 ]
  },
  "id_str" : "314415185404256257",
  "text" : "Finished @fivethirtyeight's great \"Signal and the Noise\". Starting @sherylsandberg's \"Lean In\". Who's read it? http://t.co/0qJDZOQf4t",
  "id" : 314415185404256257,
  "created_at" : "Wed Mar 20 16:36:36 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http://t.co/iMPmYzcsBD",
      "expanded_url" : "http://bit.ly/Zwf07Y",
      "display_url" : "bit.ly/Zwf07Y"
    } ]
  },
  "geo" : {
  },
  "id_str" : "314402118754770947",
  "text" : "\"The bias against things anyone can have at any time because they seem too easy, too obvious, too simple, too cheap.\" http://t.co/iMPmYzcsBD",
  "id" : 314402118754770947,
  "created_at" : "Wed Mar 20 15:44:41 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://bufferapp.com\" rel=\"nofollow\">Buffer</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http://t.co/67YubGvWiC",
      "expanded_url" : "http://bit.ly/14c8bwY",
      "display_url" : "bit.ly/14c8bwY"
    } ]
  },
  "geo" : {
  },
  "id_str" : "314399552524390401",
  "text" : "How do I get one? \"Under the skin, a tiny blood-testing laboratory\" http://t.co/67YubGvWiC",
  "id" : 314399552524390401,
  "created_at" : "Wed Mar 20 15:34:29 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emilio Ramirez",
      "screen_name" : "e_ramirez",
      "indices" : [ 0, 10 ],
      "id_str" : "1273564632",
      "id" : 1273564632
    }, {
      "name" : "Aaron Coleman",
      "screen_name" : "aarondcoleman",
      "indices" : [ 11, 25 ],
      "id_str" : "1379965428",
      "id" : 1379965428
    }, {
      "name" : "Chris Hogg",
      "screen_name" : "cwhogg",
      "indices" : [ 26, 33 ],
      "id_str" : "15727738",
      "id" : 15727738
    }, {
      "name" : "Gary Wolf",
      "screen_name" : "agaricus",
      "indices" : [ 34, 43 ],
      "id_str" : "21678279",
      "id" : 21678279
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "314241007644450816",
  "in_reply_to_user_id" : 21135674,
  "text" : "@e_ramirez @aarondcoleman @cwhogg @agaricus My calendar says we're supposed to have beer tomorrow! Who's in???",
  "id" : 314241007644450816,
  "created_at" : "Wed Mar 20 05:04:29 +0000 2013",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Galen",
      "screen_name" : "dolface",
      "indices" : [ 0, 8 ],
      "id_str" : "4366051",
      "id" : 4366051
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314231257724760064",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596794639, -122.2753602773 ]
  },
  "id_str" : "314231713242951681",
  "in_reply_to_user_id" : 4366051,
  "text" : "@dolface Bam. 10pts to me.",
  "id" : 314231713242951681,
  "in_reply_to_status_id" : 314231257724760064,
  "created_at" : "Wed Mar 20 04:27:33 +0000 2013",
  "in_reply_to_screen_name" : "gln",
  "in_reply_to_user_id_str" : "4366051",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596579377, -122.2753726972 ]
  },
  "id_str" : "314230879557914624",
  "text" : "My tweet spelling skills have been on the fritz lately.",
  "id" : 314230879557914624,
  "created_at" : "Wed Mar 20 04:24:14 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Gilman",
      "screen_name" : "jongilman",
      "indices" : [ 0, 10 ],
      "id_str" : "16908938",
      "id" : 16908938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314213416518684673",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597065527, -122.2753666622 ]
  },
  "id_str" : "314219769106677761",
  "in_reply_to_user_id" : 16908938,
  "text" : "@jongilman That's what started my kick. Loved it too!",
  "id" : 314219769106677761,
  "in_reply_to_status_id" : 314213416518684673,
  "created_at" : "Wed Mar 20 03:40:05 +0000 2013",
  "in_reply_to_screen_name" : "jongilman",
  "in_reply_to_user_id_str" : "16908938",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http://t.co/bqx89mEo5z",
      "expanded_url" : "http://flic.kr/p/e4yF7M",
      "display_url" : "flic.kr/p/e4yF7M"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859666, -122.275334 ]
  },
  "id_str" : "314219663628333056",
  "text" : "8:36pm Singing new bumblebee songs Niko learned from his visiting his new daycare http://t.co/bqx89mEo5z",
  "id" : 314219663628333056,
  "created_at" : "Wed Mar 20 03:39:40 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TriemTeam",
      "screen_name" : "TriemTeam",
      "indices" : [ 0, 10 ],
      "id_str" : "24792603",
      "id" : 24792603
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314200208470835200",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597241966, -122.2753779778 ]
  },
  "id_str" : "314200889776807937",
  "in_reply_to_user_id" : 24792603,
  "text" : "@TriemTeam I also love Equanimity for meditation, the Eatery for food, Fitbit, and others for specific trackings.",
  "id" : 314200889776807937,
  "in_reply_to_status_id" : 314200208470835200,
  "created_at" : "Wed Mar 20 02:25:04 +0000 2013",
  "in_reply_to_screen_name" : "TriemTeam",
  "in_reply_to_user_id_str" : "24792603",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TriemTeam",
      "screen_name" : "TriemTeam",
      "indices" : [ 0, 10 ],
      "id_str" : "24792603",
      "id" : 24792603
    }, {
      "name" : "Lift",
      "screen_name" : "liftapp",
      "indices" : [ 18, 26 ],
      "id_str" : "353195232",
      "id" : 353195232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314197303315546112",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859750432, -122.2755798978 ]
  },
  "id_str" : "314197579124576256",
  "in_reply_to_user_id" : 24792603,
  "text" : "@TriemTeam I love @liftapp for simple tracking needs. Tell me more about what you want to track and I'll recommend more!",
  "id" : 314197579124576256,
  "in_reply_to_status_id" : 314197303315546112,
  "created_at" : "Wed Mar 20 02:11:55 +0000 2013",
  "in_reply_to_screen_name" : "TriemTeam",
  "in_reply_to_user_id_str" : "24792603",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nate Silver",
      "screen_name" : "fivethirtyeight",
      "indices" : [ 117, 133 ],
      "id_str" : "16017475",
      "id" : 16017475
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8577476397, -122.2728845986 ]
  },
  "id_str" : "314195768229650432",
  "text" : "How to fight over-confidence: \"When we are making predictions, we need a balance between curiosity on skepticism.\" - @fivethirtyeight",
  "id" : 314195768229650432,
  "created_at" : "Wed Mar 20 02:04:43 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Stubblebine",
      "screen_name" : "tonystubblebine",
      "indices" : [ 11, 27 ],
      "id_str" : "17",
      "id" : 17
    }, {
      "name" : "Jason Goldman",
      "screen_name" : "goldman",
      "indices" : [ 83, 91 ],
      "id_str" : "291",
      "id" : 291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https://t.co/KbctsXDT8p",
      "expanded_url" : "https://medium.com/lets-not-pretend-we-have-it-all-figured-out/1283d2d17eda",
      "display_url" : "medium.com/lets-not-prete\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "314183278590562304",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8542049229, -122.2709242535 ]
  },
  "id_str" : "314193976452321281",
  "in_reply_to_user_id" : 17,
  "text" : "Agreed! RT @tonystubblebine: Totally awesome. \"Weight loss &amp; habit forming\" by @goldman https://t.co/KbctsXDT8p",
  "id" : 314193976452321281,
  "in_reply_to_status_id" : 314183278590562304,
  "created_at" : "Wed Mar 20 01:57:36 +0000 2013",
  "in_reply_to_screen_name" : "tonystubblebine",
  "in_reply_to_user_id_str" : "17",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jill Slowbloom",
      "screen_name" : "outseide",
      "indices" : [ 0, 9 ],
      "id_str" : "143694663",
      "id" : 143694663
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314174443138215936",
  "geo" : {
  },
  "id_str" : "314175103955001346",
  "in_reply_to_user_id" : 143694663,
  "text" : "@outseide I have not! I will check her out. Thanks!",
  "id" : 314175103955001346,
  "in_reply_to_status_id" : 314174443138215936,
  "created_at" : "Wed Mar 20 00:42:36 +0000 2013",
  "in_reply_to_screen_name" : "outseide",
  "in_reply_to_user_id_str" : "143694663",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pippin Lee",
      "screen_name" : "pippinlee",
      "indices" : [ 0, 10 ],
      "id_str" : "18591169",
      "id" : 18591169
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314172560390643712",
  "geo" : {
  },
  "id_str" : "314173388463669248",
  "in_reply_to_user_id" : 18591169,
  "text" : "@PippinLee I can always use more Feynman in my life. Thanks.",
  "id" : 314173388463669248,
  "in_reply_to_status_id" : 314172560390643712,
  "created_at" : "Wed Mar 20 00:35:47 +0000 2013",
  "in_reply_to_screen_name" : "pippinlee",
  "in_reply_to_user_id_str" : "18591169",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "D. Keith Robinson",
      "screen_name" : "dkr",
      "indices" : [ 0, 4 ],
      "id_str" : "10877",
      "id" : 10877
    }, {
      "name" : "Scott Belsky",
      "screen_name" : "scottbelsky",
      "indices" : [ 45, 57 ],
      "id_str" : "15698507",
      "id" : 15698507
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314172793124171777",
  "geo" : {
  },
  "id_str" : "314173329718272003",
  "in_reply_to_user_id" : 10877,
  "text" : "@dkr Awesome. I'll check it out. Thanks! /cc @scottbelsky",
  "id" : 314173329718272003,
  "in_reply_to_status_id" : 314172793124171777,
  "created_at" : "Wed Mar 20 00:35:33 +0000 2013",
  "in_reply_to_screen_name" : "dkr",
  "in_reply_to_user_id_str" : "10877",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "314170953921859586",
  "text" : "People building products: which recently read book has most influenced your current thinking about building awesome things?",
  "id" : 314170953921859586,
  "created_at" : "Wed Mar 20 00:26:07 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ioan Mitrea",
      "screen_name" : "awarenesss",
      "indices" : [ 0, 11 ],
      "id_str" : "18603224",
      "id" : 18603224
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "1000slogs",
      "indices" : [ 33, 43 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314152140069298176",
  "geo" : {
  },
  "id_str" : "314152531699851264",
  "in_reply_to_user_id" : 18603224,
  "text" : "@awarenesss Yes! Welcome aboard! #1000slogs",
  "id" : 314152531699851264,
  "in_reply_to_status_id" : 314152140069298176,
  "created_at" : "Tue Mar 19 23:12:54 +0000 2013",
  "in_reply_to_screen_name" : "awarenesss",
  "in_reply_to_user_id_str" : "18603224",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ioan Mitrea",
      "screen_name" : "awarenesss",
      "indices" : [ 0, 11 ],
      "id_str" : "18603224",
      "id" : 18603224
    }, {
      "name" : "Brennan Novak",
      "screen_name" : "brennannovak",
      "indices" : [ 12, 25 ],
      "id_str" : "17958179",
      "id" : 17958179
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314151646835912704",
  "geo" : {
  },
  "id_str" : "314152446660337665",
  "in_reply_to_user_id" : 18603224,
  "text" : "@awarenesss @brennannovak It doesn't, and that's a bummer. No idea if it's something the can add later or not...",
  "id" : 314152446660337665,
  "in_reply_to_status_id" : 314151646835912704,
  "created_at" : "Tue Mar 19 23:12:34 +0000 2013",
  "in_reply_to_screen_name" : "awarenesss",
  "in_reply_to_user_id_str" : "18603224",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rose Broome",
      "screen_name" : "rosical",
      "indices" : [ 0, 8 ],
      "id_str" : "140145169",
      "id" : 140145169
    }, {
      "name" : "Nick Pinkston",
      "screen_name" : "NickPinkston",
      "indices" : [ 9, 22 ],
      "id_str" : "17973378",
      "id" : 17973378
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314103848274886656",
  "geo" : {
  },
  "id_str" : "314105429657538560",
  "in_reply_to_user_id" : 140145169,
  "text" : "@rosical @NickPinkston OOOOOhhhhhh\u2026 that looks awesome.",
  "id" : 314105429657538560,
  "in_reply_to_status_id" : 314103848274886656,
  "created_at" : "Tue Mar 19 20:05:44 +0000 2013",
  "in_reply_to_screen_name" : "rosical",
  "in_reply_to_user_id_str" : "140145169",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "matthew deiters",
      "screen_name" : "mdeiters",
      "indices" : [ 3, 12 ],
      "id_str" : "6271932",
      "id" : 6271932
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "314104456650305537",
  "text" : "RT @mdeiters: PG on bitcoin: \"It has all the signs. Paradigm shift, hackers love it, yet it's derided as a toy.  Just like microcomputers.\"",
  "retweeted_status" : {
    "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "314103803395850241",
    "text" : "PG on bitcoin: \"It has all the signs. Paradigm shift, hackers love it, yet it's derided as a toy.  Just like microcomputers.\"",
    "id" : 314103803395850241,
    "created_at" : "Tue Mar 19 19:59:17 +0000 2013",
    "user" : {
      "name" : "matthew deiters",
      "screen_name" : "mdeiters",
      "protected" : false,
      "id_str" : "6271932",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3394906753/f42503fb651980e420edbd28596a71b5_normal.jpeg",
      "id" : 6271932,
      "verified" : false
    }
  },
  "id" : 314104456650305537,
  "created_at" : "Tue Mar 19 20:01:52 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ingopixel",
      "screen_name" : "ingopixel",
      "indices" : [ 0, 10 ],
      "id_str" : "7943892",
      "id" : 7943892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314090309728473090",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7763045898, -122.4173586644 ]
  },
  "id_str" : "314093364670775296",
  "in_reply_to_user_id" : 7943892,
  "text" : "@ingopixel Oh no! I'm sorry.",
  "id" : 314093364670775296,
  "in_reply_to_status_id" : 314090309728473090,
  "created_at" : "Tue Mar 19 19:17:48 +0000 2013",
  "in_reply_to_screen_name" : "ingopixel",
  "in_reply_to_user_id_str" : "7943892",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twitter API",
      "screen_name" : "twitterapi",
      "indices" : [ 39, 50 ],
      "id_str" : "6253282",
      "id" : 6253282
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "314079216608083969",
  "text" : "I've been waiting for this FOREVER! RT @twitterapi: The REST API now contains a field called \"favorite_count\". (# faves per tweet)",
  "id" : 314079216608083969,
  "created_at" : "Tue Mar 19 18:21:35 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brennan Novak",
      "screen_name" : "brennannovak",
      "indices" : [ 0, 13 ],
      "id_str" : "17958179",
      "id" : 17958179
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 44 ],
      "url" : "http://t.co/Cp3rcMF5L7",
      "expanded_url" : "http://mybasis.com",
      "display_url" : "mybasis.com"
    } ]
  },
  "in_reply_to_status_id_str" : "314078576695705601",
  "geo" : {
  },
  "id_str" : "314078737291411456",
  "in_reply_to_user_id" : 17958179,
  "text" : "@brennannovak The new http://t.co/Cp3rcMF5L7 watch, which is awesome.",
  "id" : 314078737291411456,
  "in_reply_to_status_id" : 314078576695705601,
  "created_at" : "Tue Mar 19 18:19:40 +0000 2013",
  "in_reply_to_screen_name" : "brennannovak",
  "in_reply_to_user_id_str" : "17958179",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremie Miller",
      "screen_name" : "jeremie",
      "indices" : [ 0, 8 ],
      "id_str" : "1704421",
      "id" : 1704421
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314072715852128256",
  "geo" : {
  },
  "id_str" : "314078198570831872",
  "in_reply_to_user_id" : 1704421,
  "text" : "@jeremie I agree.",
  "id" : 314078198570831872,
  "in_reply_to_status_id" : 314072715852128256,
  "created_at" : "Tue Mar 19 18:17:32 +0000 2013",
  "in_reply_to_screen_name" : "jeremie",
  "in_reply_to_user_id_str" : "1704421",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "maggim",
      "screen_name" : "maggim",
      "indices" : [ 0, 7 ],
      "id_str" : "14290242",
      "id" : 14290242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 51 ],
      "url" : "http://t.co/Cp3rcMF5L7",
      "expanded_url" : "http://mybasis.com",
      "display_url" : "mybasis.com"
    } ]
  },
  "in_reply_to_status_id_str" : "314036387064193024",
  "geo" : {
  },
  "id_str" : "314059021114019841",
  "in_reply_to_user_id" : 14290242,
  "text" : "@maggim It's the awesome new http://t.co/Cp3rcMF5L7 watch. Get one!",
  "id" : 314059021114019841,
  "in_reply_to_status_id" : 314036387064193024,
  "created_at" : "Tue Mar 19 17:01:20 +0000 2013",
  "in_reply_to_screen_name" : "maggim",
  "in_reply_to_user_id_str" : "14290242",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "yaqui n\u00FA\u00F1ez",
      "screen_name" : "yaqui",
      "indices" : [ 0, 6 ],
      "id_str" : "638283",
      "id" : 638283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 37 ],
      "url" : "http://t.co/Cp3rcMF5L7",
      "expanded_url" : "http://mybasis.com",
      "display_url" : "mybasis.com"
    } ]
  },
  "in_reply_to_status_id_str" : "314058700841164800",
  "geo" : {
  },
  "id_str" : "314058879199744000",
  "in_reply_to_user_id" : 638283,
  "text" : "@yaqui the new http://t.co/Cp3rcMF5L7",
  "id" : 314058879199744000,
  "in_reply_to_status_id" : 314058700841164800,
  "created_at" : "Tue Mar 19 17:00:46 +0000 2013",
  "in_reply_to_screen_name" : "yaqui",
  "in_reply_to_user_id_str" : "638283",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "April Schiller",
      "screen_name" : "the_april",
      "indices" : [ 0, 10 ],
      "id_str" : "16644937",
      "id" : 16644937
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314036874819801092",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8593735397, -122.2758337856 ]
  },
  "id_str" : "314039827026812929",
  "in_reply_to_user_id" : 16644937,
  "text" : "@the_april Yeah me too bit wouldn't have guessed it would be 3 whole hours. My temp doesn't stay high for as long.",
  "id" : 314039827026812929,
  "in_reply_to_status_id" : 314036874819801092,
  "created_at" : "Tue Mar 19 15:45:03 +0000 2013",
  "in_reply_to_screen_name" : "the_april",
  "in_reply_to_user_id_str" : "16644937",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "1000slogs",
      "indices" : [ 128, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http://t.co/sq3CmEJT53",
      "expanded_url" : "http://bit.ly/13nMKJd",
      "display_url" : "bit.ly/13nMKJd"
    } ]
  },
  "geo" : {
  },
  "id_str" : "314037595086659585",
  "text" : "Just hit 975. Current velocity: 1.31 slogs per day. Expected slog end date: March 31st, 2015. More info: http://t.co/sq3CmEJT53 #1000slogs",
  "id" : 314037595086659585,
  "created_at" : "Tue Mar 19 15:36:11 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/buster/status/314035458051031040/photo/1",
      "indices" : [ 96, 118 ],
      "url" : "http://t.co/03rtFitsAk",
      "media_url" : "http://pbs.twimg.com/media/BFutldSCQAAHhZV.png",
      "id_str" : "314035458059419648",
      "id" : 314035458059419648,
      "media_url_https" : "https://pbs.twimg.com/media/BFutldSCQAAHhZV.png",
      "sizes" : [ {
        "h" : 539,
        "resize" : "fit",
        "w" : 938
      }, {
        "h" : 539,
        "resize" : "fit",
        "w" : 938
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 195,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 345,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com/03rtFitsAk"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "314035458051031040",
  "text" : "975. According to my futuristic watch, I keep sweating for 3 hours after a run. Is that normal? http://t.co/03rtFitsAk",
  "id" : 314035458051031040,
  "created_at" : "Tue Mar 19 15:27:42 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 143 ],
      "url" : "http://t.co/y2oWKqdwnM",
      "expanded_url" : "http://flic.kr/p/e4pNcS",
      "display_url" : "flic.kr/p/e4pNcS"
    } ]
  },
  "geo" : {
  },
  "id_str" : "313875046097625090",
  "text" : "8:36pm Niko didn't want dinner &amp; I figured I'd let him learn the hard way, but he was sweet and played his uke to... http://t.co/y2oWKqdwnM",
  "id" : 313875046097625090,
  "created_at" : "Tue Mar 19 04:50:17 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596579654, -122.2754949161 ]
  },
  "id_str" : "313849874061856768",
  "text" : "Is it possible to be self-confident, out-going, risk-tolerant, and NOT over-confident?",
  "id" : 313849874061856768,
  "created_at" : "Tue Mar 19 03:10:15 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597246157, -122.2754332983 ]
  },
  "id_str" : "313842643576696832",
  "text" : "2 questions:\n1) How over-confident are you?\n2) How confident are you in the answer to 1?",
  "id" : 313842643576696832,
  "created_at" : "Tue Mar 19 02:41:31 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nate Silver",
      "screen_name" : "fivethirtyeight",
      "indices" : [ 99, 115 ],
      "id_str" : "16017475",
      "id" : 16017475
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8031232581, -122.2898048257 ]
  },
  "id_str" : "313832241228812289",
  "text" : "\"There's reason to suspect that over-confidence is the most pernicious of all cognitive biases.\" - @fivethirtyeight in his awesome book",
  "id" : 313832241228812289,
  "created_at" : "Tue Mar 19 02:00:11 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jane McGonigal",
      "screen_name" : "avantgame",
      "indices" : [ 0, 10 ],
      "id_str" : "681813",
      "id" : 681813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "313823475724873728",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7792441864, -122.4142422704 ]
  },
  "id_str" : "313825065315758081",
  "in_reply_to_user_id" : 681813,
  "text" : "@avantgame Ask them to hire \"Yeah, That's Not Going To Work\" consultants. :) Or just say what you said, honesty is helpful!",
  "id" : 313825065315758081,
  "in_reply_to_status_id" : 313823475724873728,
  "created_at" : "Tue Mar 19 01:31:40 +0000 2013",
  "in_reply_to_screen_name" : "avantgame",
  "in_reply_to_user_id_str" : "681813",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "gdp",
      "screen_name" : "dolface",
      "indices" : [ 0, 8 ],
      "id_str" : "1598795184",
      "id" : 1598795184
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 52 ],
      "url" : "http://t.co/R2Nmm1w6Vp",
      "expanded_url" : "http://bit.ly/WAccry",
      "display_url" : "bit.ly/WAccry"
    } ]
  },
  "in_reply_to_status_id_str" : "313817034771283968",
  "geo" : {
  },
  "id_str" : "313819672078319617",
  "in_reply_to_user_id" : 4366051,
  "text" : "@dolface Definitely check out http://t.co/R2Nmm1w6Vp\u2026 leaps over competition in many ways (but needs API). Come find me for a demo.",
  "id" : 313819672078319617,
  "in_reply_to_status_id" : 313817034771283968,
  "created_at" : "Tue Mar 19 01:10:14 +0000 2013",
  "in_reply_to_screen_name" : "gln",
  "in_reply_to_user_id_str" : "4366051",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Wild",
      "screen_name" : "dorkitude",
      "indices" : [ 0, 10 ],
      "id_str" : "12626542",
      "id" : 12626542
    }, {
      "name" : "Micah Baldwin",
      "screen_name" : "micah",
      "indices" : [ 71, 77 ],
      "id_str" : "5469512",
      "id" : 5469512
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "313791522036383744",
  "geo" : {
  },
  "id_str" : "313798782594727936",
  "in_reply_to_user_id" : 12626542,
  "text" : "@dorkitude You too! Sorry I had to run off so quickly\u2026 how do you know @micah?",
  "id" : 313798782594727936,
  "in_reply_to_status_id" : 313791522036383744,
  "created_at" : "Mon Mar 18 23:47:14 +0000 2013",
  "in_reply_to_screen_name" : "dorkitude",
  "in_reply_to_user_id_str" : "12626542",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ioan Mitrea",
      "screen_name" : "awarenesss",
      "indices" : [ 0, 11 ],
      "id_str" : "18603224",
      "id" : 18603224
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "313709957356875776",
  "geo" : {
  },
  "id_str" : "313712441248866305",
  "in_reply_to_user_id" : 18603224,
  "text" : "@awarenesss I think the threshold is at \"am I trying to change into a different person?\" If yes, do 1,000. If no, maybe not.",
  "id" : 313712441248866305,
  "in_reply_to_status_id" : 313709957356875776,
  "created_at" : "Mon Mar 18 18:04:09 +0000 2013",
  "in_reply_to_screen_name" : "awarenesss",
  "in_reply_to_user_id_str" : "18603224",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ioan Mitrea",
      "screen_name" : "awarenesss",
      "indices" : [ 0, 11 ],
      "id_str" : "18603224",
      "id" : 18603224
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "313704455218536448",
  "geo" : {
  },
  "id_str" : "313708242805080064",
  "in_reply_to_user_id" : 18603224,
  "text" : "@awarenesss You should give it a try\u2026 and readjust towards what works on the 1st of every month! :)",
  "id" : 313708242805080064,
  "in_reply_to_status_id" : 313704455218536448,
  "created_at" : "Mon Mar 18 17:47:28 +0000 2013",
  "in_reply_to_screen_name" : "awarenesss",
  "in_reply_to_user_id_str" : "18603224",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http://t.co/fv76MkkyTI",
      "expanded_url" : "http://bit.ly/YjWct5",
      "display_url" : "bit.ly/YjWct5"
    } ]
  },
  "geo" : {
  },
  "id_str" : "313668392328511488",
  "text" : "\"How to change yourself (v0.1)\" - Way of the Duck http://t.co/fv76MkkyTI",
  "id" : 313668392328511488,
  "created_at" : "Mon Mar 18 15:09:07 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http://t.co/9T5Wqg9X4b",
      "expanded_url" : "http://flic.kr/p/e47pMG",
      "display_url" : "flic.kr/p/e47pMG"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859666, -122.2755 ]
  },
  "id_str" : "313497745874890752",
  "text" : "8:36pm Niko's still working out some technical kinks in his photographic style http://t.co/9T5Wqg9X4b",
  "id" : 313497745874890752,
  "created_at" : "Mon Mar 18 03:51:01 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 45 ],
      "url" : "http://t.co/2LP1cjEhEa",
      "expanded_url" : "http://flic.kr/p/e3Y8jp",
      "display_url" : "flic.kr/p/e3Y8jp"
    } ]
  },
  "geo" : {
  },
  "id_str" : "313448555480231937",
  "text" : "Niko and the conductor http://t.co/2LP1cjEhEa",
  "id" : 313448555480231937,
  "created_at" : "Mon Mar 18 00:35:33 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://vine.co\" rel=\"nofollow\">Vine - Make a Scene</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 55 ],
      "url" : "http://t.co/b0pDkFYcOh",
      "expanded_url" : "http://vine.co/v/bpKxm2AxXDP",
      "display_url" : "vine.co/v/bpKxm2AxXDP"
    } ]
  },
  "geo" : {
  },
  "id_str" : "313446297061429250",
  "text" : "Mini steam train in Tilden Park! http://t.co/b0pDkFYcOh",
  "id" : 313446297061429250,
  "created_at" : "Mon Mar 18 00:26:35 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://vine.co\" rel=\"nofollow\">Vine - Make a Scene</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 40 ],
      "url" : "http://t.co/cgkfjCLuYp",
      "expanded_url" : "http://vine.co/v/bpKUW7AAOz5",
      "display_url" : "vine.co/v/bpKUW7AAOz5"
    } ]
  },
  "geo" : {
  },
  "id_str" : "313444889390108673",
  "text" : "Making Niko's day http://t.co/cgkfjCLuYp",
  "id" : 313444889390108673,
  "created_at" : "Mon Mar 18 00:20:59 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 37 ],
      "url" : "http://t.co/uGeCy2DjpF",
      "expanded_url" : "http://flic.kr/p/e3XRHe",
      "display_url" : "flic.kr/p/e3XRHe"
    } ]
  },
  "geo" : {
  },
  "id_str" : "313443722593456129",
  "text" : "Two thumbs up! http://t.co/uGeCy2DjpF",
  "id" : 313443722593456129,
  "created_at" : "Mon Mar 18 00:16:21 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http://t.co/Dsvd72cbL5",
      "expanded_url" : "http://flic.kr/p/e44oyh",
      "display_url" : "flic.kr/p/e44oyh"
    } ]
  },
  "geo" : {
  },
  "id_str" : "313442495822458881",
  "text" : "What you don't know is that he has train underwear and a train t-shirt on too (@ Tilden Park Steam Trains) http://t.co/Dsvd72cbL5",
  "id" : 313442495822458881,
  "created_at" : "Mon Mar 18 00:11:29 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ali Berman",
      "screen_name" : "spangley",
      "indices" : [ 3, 12 ],
      "id_str" : "776429",
      "id" : 776429
    }, {
      "name" : "Buster",
      "screen_name" : "buster",
      "indices" : [ 14, 21 ],
      "id_str" : "2185",
      "id" : 2185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "313427575034761216",
  "text" : "RT @spangley: @buster He's not human. He's a celestial super-being sent to the planet Earth to save our earholes (&amp; marry our models.)",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Buster",
        "screen_name" : "buster",
        "indices" : [ 0, 7 ],
        "id_str" : "2185",
        "id" : 2185
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "313415335594311680",
    "geo" : {
    },
    "id_str" : "313422696102899712",
    "in_reply_to_user_id" : 2185,
    "text" : "@buster He's not human. He's a celestial super-being sent to the planet Earth to save our earholes (&amp; marry our models.)",
    "id" : 313422696102899712,
    "in_reply_to_status_id" : 313415335594311680,
    "created_at" : "Sun Mar 17 22:52:48 +0000 2013",
    "in_reply_to_screen_name" : "buster",
    "in_reply_to_user_id_str" : "2185",
    "user" : {
      "name" : "Ali Berman",
      "screen_name" : "spangley",
      "protected" : false,
      "id_str" : "776429",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3624998904/00fd2d53171e98e1fd96504fc0f61099_normal.jpeg",
      "id" : 776429,
      "verified" : false
    }
  },
  "id" : 313427575034761216,
  "created_at" : "Sun Mar 17 23:12:11 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597233815, -122.275220049 ]
  },
  "id_str" : "313415335594311680",
  "text" : "I don't understand how David Bowie is still making good music.",
  "id" : 313415335594311680,
  "created_at" : "Sun Mar 17 22:23:33 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 37 ],
      "url" : "http://t.co/wbrQW1d37E",
      "expanded_url" : "http://flic.kr/p/e41Mxo",
      "display_url" : "flic.kr/p/e41Mxo"
    } ]
  },
  "geo" : {
  },
  "id_str" : "313399304196861953",
  "text" : "The tough life http://t.co/wbrQW1d37E",
  "id" : 313399304196861953,
  "created_at" : "Sun Mar 17 21:19:51 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "josh",
      "screen_name" : "joshc",
      "indices" : [ 0, 6 ],
      "id_str" : "2015",
      "id" : 2015
    }, {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 7, 17 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "313374941745651712",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596791439, -122.2754817457 ]
  },
  "id_str" : "313383332765392897",
  "in_reply_to_user_id" : 2015,
  "text" : "@joshc @kellianne Be the duck.",
  "id" : 313383332765392897,
  "in_reply_to_status_id" : 313374941745651712,
  "created_at" : "Sun Mar 17 20:16:23 +0000 2013",
  "in_reply_to_screen_name" : "joshc",
  "in_reply_to_user_id_str" : "2015",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jake Knapp",
      "screen_name" : "jakek",
      "indices" : [ 29, 35 ],
      "id_str" : "703643",
      "id" : 703643
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https://t.co/Wk8leaIFXU",
      "expanded_url" : "https://medium.com/life-hacks/80f8d525b0d8",
      "display_url" : "medium.com/life-hacks/80f\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "312347895489781760",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596878192, -122.2754699272 ]
  },
  "id_str" : "313382345581412352",
  "in_reply_to_user_id" : 703643,
  "text" : "Live like you're in 2006. RT @jakek: Try this for 24 hrs and let me know how it goes: No Safari/Twitter/email iPhone https://t.co/Wk8leaIFXU",
  "id" : 313382345581412352,
  "in_reply_to_status_id" : 312347895489781760,
  "created_at" : "Sun Mar 17 20:12:28 +0000 2013",
  "in_reply_to_screen_name" : "jakek",
  "in_reply_to_user_id_str" : "703643",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay Holler",
      "screen_name" : "jayholler",
      "indices" : [ 0, 10 ],
      "id_str" : "14110325",
      "id" : 14110325
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "313212139152220160",
  "geo" : {
  },
  "id_str" : "313379148729040896",
  "in_reply_to_user_id" : 14110325,
  "text" : "@jayholler I haven't read the book yet but I can't tell if Evgeny Morozov is just a troll/bully or not.",
  "id" : 313379148729040896,
  "in_reply_to_status_id" : 313212139152220160,
  "created_at" : "Sun Mar 17 19:59:46 +0000 2013",
  "in_reply_to_screen_name" : "jayholler",
  "in_reply_to_user_id_str" : "14110325",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597260886, -122.2757038543 ]
  },
  "id_str" : "313363388392677376",
  "text" : "Sunday morning backseat tweeting is our new national pastime.",
  "id" : 313363388392677376,
  "created_at" : "Sun Mar 17 18:57:08 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http://t.co/kj3n3bqKRL",
      "expanded_url" : "http://flic.kr/p/e3N4zC",
      "display_url" : "flic.kr/p/e3N4zC"
    } ]
  },
  "geo" : {
  },
  "id_str" : "313134702280208384",
  "text" : "8:36pm \"This is my angry face. Take a picture. Arrrrr.\" http://t.co/kj3n3bqKRL",
  "id" : 313134702280208384,
  "created_at" : "Sun Mar 17 03:48:25 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "313088837679190016",
  "text" : "The truth is out there, but it hasn't quite found product/market fit.",
  "id" : 313088837679190016,
  "created_at" : "Sun Mar 17 00:46:10 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marina Martin",
      "screen_name" : "MarinaMartin",
      "indices" : [ 0, 13 ],
      "id_str" : "60663",
      "id" : 60663
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http://t.co/zsnaEVKRJA",
      "expanded_url" : "http://bit.ly/Yzi1kE",
      "display_url" : "bit.ly/Yzi1kE"
    } ]
  },
  "in_reply_to_status_id_str" : "313085095881871360",
  "geo" : {
  },
  "id_str" : "313086062081757184",
  "in_reply_to_user_id" : 60663,
  "text" : "@MarinaMartin Hm\u2026 that must be the Air one then. This one isn't going away: http://t.co/zsnaEVKRJA",
  "id" : 313086062081757184,
  "in_reply_to_status_id" : 313085095881871360,
  "created_at" : "Sun Mar 17 00:35:08 +0000 2013",
  "in_reply_to_screen_name" : "MarinaMartin",
  "in_reply_to_user_id_str" : "60663",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marina Martin",
      "screen_name" : "MarinaMartin",
      "indices" : [ 0, 13 ],
      "id_str" : "60663",
      "id" : 60663
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "313077586005749760",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596201447, -122.2753291273 ]
  },
  "id_str" : "313084943012098049",
  "in_reply_to_user_id" : 60663,
  "text" : "@MarinaMartin Which desktop version are you talking about? The Mac version is staying. Only Air is ending, but barely anyone was using that.",
  "id" : 313084943012098049,
  "in_reply_to_status_id" : 313077586005749760,
  "created_at" : "Sun Mar 17 00:30:41 +0000 2013",
  "in_reply_to_screen_name" : "MarinaMartin",
  "in_reply_to_user_id_str" : "60663",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ephie",
      "screen_name" : "goodballs",
      "indices" : [ 3, 13 ],
      "id_str" : "50923",
      "id" : 50923
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "313076080426774529",
  "text" : "RT @goodballs: If your bf/gf is mad at you put a cape on them and say, \"Now you're super mad!\" If they laugh marry them.",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "288339528102596608",
    "text" : "If your bf/gf is mad at you put a cape on them and say, \"Now you're super mad!\" If they laugh marry them.",
    "id" : 288339528102596608,
    "created_at" : "Mon Jan 07 17:41:15 +0000 2013",
    "user" : {
      "name" : "Ephie",
      "screen_name" : "goodballs",
      "protected" : false,
      "id_str" : "50923",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000036892365/04b72501a0424ac72e7e99003ce55e87_normal.jpeg",
      "id" : 50923,
      "verified" : false
    }
  },
  "id" : 313076080426774529,
  "created_at" : "Sat Mar 16 23:55:28 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http://t.co/jNspZLoa1A",
      "expanded_url" : "http://bit.ly/Z6nZJB",
      "display_url" : "bit.ly/Z6nZJB"
    } ]
  },
  "geo" : {
  },
  "id_str" : "313073659776495617",
  "text" : "\"Rule 110 is arguably the simplest known Turing complete system.\" - http://t.co/jNspZLoa1A",
  "id" : 313073659776495617,
  "created_at" : "Sat Mar 16 23:45:51 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nate Silver",
      "screen_name" : "fivethirtyeight",
      "indices" : [ 82, 98 ],
      "id_str" : "16017475",
      "id" : 16017475
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597306479, -122.2755605125 ]
  },
  "id_str" : "313047493610971136",
  "text" : "\"The most objective among us are those who make the most accurate predictions.\" - @fivethirtyeight (can I just join his cult already?)",
  "id" : 313047493610971136,
  "created_at" : "Sat Mar 16 22:01:53 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sara Mauskopf",
      "screen_name" : "sm",
      "indices" : [ 0, 3 ],
      "id_str" : "22273667",
      "id" : 22273667
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "313017075440443392",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8598040762, -122.2755523213 ]
  },
  "id_str" : "313026741042036736",
  "in_reply_to_user_id" : 22273667,
  "text" : "@sm How about regular people? Added to my audiobook queue!",
  "id" : 313026741042036736,
  "in_reply_to_status_id" : 313017075440443392,
  "created_at" : "Sat Mar 16 20:39:25 +0000 2013",
  "in_reply_to_screen_name" : "sm",
  "in_reply_to_user_id_str" : "22273667",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Moody",
      "screen_name" : "notaustintexas",
      "indices" : [ 0, 15 ],
      "id_str" : "597623360",
      "id" : 597623360
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "312977835931340800",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8621152648, -122.2812068119 ]
  },
  "id_str" : "312984317611626496",
  "in_reply_to_user_id" : 597623360,
  "text" : "@notaustintexas RunKeeper. They just redesigned and it's looking pretty good.",
  "id" : 312984317611626496,
  "in_reply_to_status_id" : 312977835931340800,
  "created_at" : "Sat Mar 16 17:50:50 +0000 2013",
  "in_reply_to_screen_name" : "notaustintexas",
  "in_reply_to_user_id_str" : "597623360",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/buster/status/312963730847698944/photo/1",
      "indices" : [ 49, 71 ],
      "url" : "http://t.co/2B64c7qeS9",
      "media_url" : "http://pbs.twimg.com/media/BFfe2uUCEAETA_b.jpg",
      "id_str" : "312963730851893249",
      "id" : 312963730851893249,
      "media_url_https" : "https://pbs.twimg.com/media/BFfe2uUCEAETA_b.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 577
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 577
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 603,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 577
      } ],
      "display_url" : "pic.twitter.com/2B64c7qeS9"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8642815401, -122.3030074996 ]
  },
  "id_str" : "312963730847698944",
  "text" : "976. 5.3 mile fun run. Knee is still weird, boo. http://t.co/2B64c7qeS9",
  "id" : 312963730847698944,
  "created_at" : "Sat Mar 16 16:29:03 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "312774379622776832",
  "text" : "I wish the cast of The New Girl would do a remake of House of Cards.",
  "id" : 312774379622776832,
  "created_at" : "Sat Mar 16 03:56:37 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http://t.co/umUrzuxTtx",
      "expanded_url" : "http://flic.kr/p/e3y5Cq",
      "display_url" : "flic.kr/p/e3y5Cq"
    } ]
  },
  "geo" : {
  },
  "id_str" : "312772792040960000",
  "text" : "8:36pm Ready for a lazy night of Netflix streaming. The New Girl or House of Cards or both? http://t.co/umUrzuxTtx",
  "id" : 312772792040960000,
  "created_at" : "Sat Mar 16 03:50:19 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Magnus Johansson",
      "screen_name" : "pgmjoh",
      "indices" : [ 0, 7 ],
      "id_str" : "389920517",
      "id" : 389920517
    }, {
      "name" : "Lift",
      "screen_name" : "liftapp",
      "indices" : [ 8, 16 ],
      "id_str" : "353195232",
      "id" : 353195232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "312689731123163137",
  "geo" : {
  },
  "id_str" : "312692380979580929",
  "in_reply_to_user_id" : 389920517,
  "text" : "@pgmjoh @liftapp It is meant as a conversation starter\u2026 more about questions than answers.",
  "id" : 312692380979580929,
  "in_reply_to_status_id" : 312689731123163137,
  "created_at" : "Fri Mar 15 22:30:47 +0000 2013",
  "in_reply_to_screen_name" : "pgmjoh",
  "in_reply_to_user_id_str" : "389920517",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ArielMeadowStallings",
      "screen_name" : "OffbeatAriel",
      "indices" : [ 0, 13 ],
      "id_str" : "14095370",
      "id" : 14095370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http://t.co/riBGqDn9I5",
      "expanded_url" : "http://business.pinterest.com/analytics/",
      "display_url" : "business.pinterest.com/analytics/"
    } ]
  },
  "geo" : {
  },
  "id_str" : "312691768586022912",
  "in_reply_to_user_id" : 14095370,
  "text" : "@offbeatariel Did you offbeat sites up for this yet? Seems interesting. http://t.co/riBGqDn9I5",
  "id" : 312691768586022912,
  "created_at" : "Fri Mar 15 22:28:21 +0000 2013",
  "in_reply_to_screen_name" : "OffbeatAriel",
  "in_reply_to_user_id_str" : "14095370",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Jobson",
      "screen_name" : "Colossal",
      "indices" : [ 38, 47 ],
      "id_str" : "203063180",
      "id" : 203063180
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 32 ],
      "url" : "http://t.co/0drecvdDvN",
      "expanded_url" : "http://flickr.com/photos/lesleyercolano/8520777339/",
      "display_url" : "flickr.com/photos/lesleye\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7768620958, -122.4172450288 ]
  },
  "id_str" : "312685502702698496",
  "text" : "I see you http://t.co/0drecvdDvN /via @Colossal",
  "id" : 312685502702698496,
  "created_at" : "Fri Mar 15 22:03:27 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Danny Newman",
      "screen_name" : "dannynewman",
      "indices" : [ 0, 12 ],
      "id_str" : "8273",
      "id" : 8273
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "312663727163985921",
  "geo" : {
  },
  "id_str" : "312683568675565569",
  "in_reply_to_user_id" : 8273,
  "text" : "@dannynewman If I had the space I'd make an offer\u2026 looks awesome.",
  "id" : 312683568675565569,
  "in_reply_to_status_id" : 312663727163985921,
  "created_at" : "Fri Mar 15 21:55:46 +0000 2013",
  "in_reply_to_screen_name" : "dannynewman",
  "in_reply_to_user_id_str" : "8273",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Danny Newman",
      "screen_name" : "dannynewman",
      "indices" : [ 0, 12 ],
      "id_str" : "8273",
      "id" : 8273
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "312655534757142528",
  "geo" : {
  },
  "id_str" : "312659088817410049",
  "in_reply_to_user_id" : 8273,
  "text" : "@dannynewman Why don't you want it?",
  "id" : 312659088817410049,
  "in_reply_to_status_id" : 312655534757142528,
  "created_at" : "Fri Mar 15 20:18:30 +0000 2013",
  "in_reply_to_screen_name" : "dannynewman",
  "in_reply_to_user_id_str" : "8273",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8057957186, -122.3033919361 ]
  },
  "id_str" : "312601984836464640",
  "text" : "Reading about earthquake prediction in Signal and the Noise. 1/35 chance of big earthquake in SF every year. PS I'm currently under SF Bay.",
  "id" : 312601984836464640,
  "created_at" : "Fri Mar 15 16:31:35 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Moos",
      "screen_name" : "sjmoos",
      "indices" : [ 0, 7 ],
      "id_str" : "445878959",
      "id" : 445878959
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "312541541757489152",
  "geo" : {
  },
  "id_str" : "312568578421452800",
  "in_reply_to_user_id" : 445878959,
  "text" : "@sjmoos Ah, okay, I'll be sure to do that. :)",
  "id" : 312568578421452800,
  "in_reply_to_status_id" : 312541541757489152,
  "created_at" : "Fri Mar 15 14:18:50 +0000 2013",
  "in_reply_to_screen_name" : "sjmoos",
  "in_reply_to_user_id_str" : "445878959",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 73 ],
      "url" : "http://t.co/Cm8b5RrZZd",
      "expanded_url" : "http://flic.kr/p/e3kDFU",
      "display_url" : "flic.kr/p/e3kDFU"
    } ]
  },
  "geo" : {
  },
  "id_str" : "312407965179195393",
  "text" : "8:36pm Getting lost in Rockridge, late for my date http://t.co/Cm8b5RrZZd",
  "id" : 312407965179195393,
  "created_at" : "Fri Mar 15 03:40:37 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Guto Hernandes",
      "screen_name" : "gutohernandes",
      "indices" : [ 0, 14 ],
      "id_str" : "18721607",
      "id" : 18721607
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "312331857519853568",
  "geo" : {
  },
  "id_str" : "312335385864851456",
  "in_reply_to_user_id" : 18721607,
  "text" : "@gutohernandes If you use the \"Still can't log in\" link on the log in page you should still be able to log in via Google.",
  "id" : 312335385864851456,
  "in_reply_to_status_id" : 312331857519853568,
  "created_at" : "Thu Mar 14 22:52:13 +0000 2013",
  "in_reply_to_screen_name" : "gutohernandes",
  "in_reply_to_user_id_str" : "18721607",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Siobhan Quinn",
      "screen_name" : "siobhanquinn",
      "indices" : [ 20, 33 ],
      "id_str" : "7650782",
      "id" : 7650782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http://t.co/7sqlnUHdPT",
      "expanded_url" : "http://blog.foursquare.com/2013/03/14/the-best-things-nearby-right-now-right-when-you-open-foursquare/",
      "display_url" : "blog.foursquare.com/2013/03/14/the\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "312297042380742656",
  "geo" : {
  },
  "id_str" : "312304066766200832",
  "in_reply_to_user_id" : 7650782,
  "text" : "This is awesome. RT @siobhanquinn: Realtime local insights &amp; recommendations up front in foursquare. Pumped! http://t.co/7sqlnUHdPT",
  "id" : 312304066766200832,
  "in_reply_to_status_id" : 312297042380742656,
  "created_at" : "Thu Mar 14 20:47:46 +0000 2013",
  "in_reply_to_screen_name" : "siobhanquinn",
  "in_reply_to_user_id_str" : "7650782",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Kottke",
      "screen_name" : "jkottke",
      "indices" : [ 0, 8 ],
      "id_str" : "1305941",
      "id" : 1305941
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "312266367460077569",
  "geo" : {
  },
  "id_str" : "312266919975714817",
  "in_reply_to_user_id" : 1305941,
  "text" : "@jkottke That's simply amazing. Top contender for most consistently great independent corner of ze ol' interweb.",
  "id" : 312266919975714817,
  "in_reply_to_status_id" : 312266367460077569,
  "created_at" : "Thu Mar 14 18:20:10 +0000 2013",
  "in_reply_to_screen_name" : "jkottke",
  "in_reply_to_user_id_str" : "1305941",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Susannah Fox",
      "screen_name" : "SusannahFox",
      "indices" : [ 0, 12 ],
      "id_str" : "17843236",
      "id" : 17843236
    }, {
      "name" : "Emilio Ramirez",
      "screen_name" : "e_ramirez",
      "indices" : [ 13, 23 ],
      "id_str" : "1273564632",
      "id" : 1273564632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "312250958354731008",
  "geo" : {
  },
  "id_str" : "312255146400808960",
  "in_reply_to_user_id" : 17843236,
  "text" : "@SusannahFox @e_ramirez Thank you! Would love to hear any reactions/thoughts/etc as well. Still very much a thought-in-progress.",
  "id" : 312255146400808960,
  "in_reply_to_status_id" : 312250958354731008,
  "created_at" : "Thu Mar 14 17:33:22 +0000 2013",
  "in_reply_to_screen_name" : "SusannahFox",
  "in_reply_to_user_id_str" : "17843236",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jad Abumrad",
      "screen_name" : "JadAbumrad",
      "indices" : [ 3, 14 ],
      "id_str" : "135316691",
      "id" : 135316691
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 50 ],
      "url" : "http://t.co/CKwaHJsPMa",
      "expanded_url" : "http://buff.ly/151u3H7",
      "display_url" : "buff.ly/151u3H7"
    } ]
  },
  "geo" : {
  },
  "id_str" : "312236872241917953",
  "text" : "RT @JadAbumrad: Genius is...http://t.co/CKwaHJsPMa",
  "retweeted_status" : {
    "source" : "<a href=\"http://bufferapp.com\" rel=\"nofollow\">Buffer</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 12, 34 ],
        "url" : "http://t.co/CKwaHJsPMa",
        "expanded_url" : "http://buff.ly/151u3H7",
        "display_url" : "buff.ly/151u3H7"
      } ]
    },
    "geo" : {
    },
    "id_str" : "312231457869410304",
    "text" : "Genius is...http://t.co/CKwaHJsPMa",
    "id" : 312231457869410304,
    "created_at" : "Thu Mar 14 15:59:15 +0000 2013",
    "user" : {
      "name" : "Jad Abumrad",
      "screen_name" : "JadAbumrad",
      "protected" : false,
      "id_str" : "135316691",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1529014082/Jad-Pic2_normal.jpg",
      "id" : 135316691,
      "verified" : true
    }
  },
  "id" : 312236872241917953,
  "created_at" : "Thu Mar 14 16:20:46 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http://t.co/7xWHNCk7Vx",
      "expanded_url" : "http://bit.ly/YtVkOG",
      "display_url" : "bit.ly/YtVkOG"
    } ]
  },
  "geo" : {
  },
  "id_str" : "312209323642212353",
  "text" : "Google Tech Talk from Jeff Hawkins on building machine brains, with Q&amp;A from Ray Kurzweil at the end: http://t.co/7xWHNCk7Vx",
  "id" : 312209323642212353,
  "created_at" : "Thu Mar 14 14:31:17 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amy Jo Kim",
      "screen_name" : "amyjokim",
      "indices" : [ 0, 9 ],
      "id_str" : "780991",
      "id" : 780991
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "312076483235557376",
  "geo" : {
  },
  "id_str" : "312076579448713216",
  "in_reply_to_user_id" : 780991,
  "text" : "@amyjokim For Sebastian's book.",
  "id" : 312076579448713216,
  "in_reply_to_status_id" : 312076483235557376,
  "created_at" : "Thu Mar 14 05:43:49 +0000 2013",
  "in_reply_to_screen_name" : "amyjokim",
  "in_reply_to_user_id_str" : "780991",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gamification",
      "indices" : [ 56, 69 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "312048405247582208",
  "text" : "I've been struggling for weeks to submit my thoughts on #gamification (due 3/15). Trying desperately to find something constructive to say.",
  "id" : 312048405247582208,
  "created_at" : "Thu Mar 14 03:51:52 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Raffi Krikorian",
      "screen_name" : "raffi",
      "indices" : [ 35, 41 ],
      "id_str" : "8285392",
      "id" : 8285392
    }, {
      "name" : "Jeremy Gordon",
      "screen_name" : "JeremySF",
      "indices" : [ 46, 55 ],
      "id_str" : "19872718",
      "id" : 19872718
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http://t.co/zEjHSFerKS",
      "expanded_url" : "http://flic.kr/p/e38aXL",
      "display_url" : "flic.kr/p/e38aXL"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859666, -122.2755 ]
  },
  "id_str" : "312045398070005761",
  "text" : "8:36pm Reading congratulations for @raffi and @jeremysf. Stoked that good people are moving up. http://t.co/zEjHSFerKS",
  "id" : 312045398070005761,
  "created_at" : "Thu Mar 14 03:39:55 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 0, 9 ],
      "id_str" : "761628",
      "id" : 761628
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "312009264870866944",
  "geo" : {
  },
  "id_str" : "312013332318150656",
  "in_reply_to_user_id" : 761628,
  "text" : "@RickWebb Search indexing perhaps?",
  "id" : 312013332318150656,
  "in_reply_to_status_id" : 312009264870866944,
  "created_at" : "Thu Mar 14 01:32:30 +0000 2013",
  "in_reply_to_screen_name" : "RickWebb",
  "in_reply_to_user_id_str" : "761628",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Ward",
      "screen_name" : "benward",
      "indices" : [ 3, 11 ],
      "id_str" : "12249",
      "id" : 12249
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "311950770062913537",
  "text" : "RT @BenWard: \u201CWealth is not a number of dollars. It is not a number of material possessions. It\u2019s having options to take on risk.\u201D http: ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http://t.co/taedNoVteN",
        "expanded_url" : "http://vruba.tumblr.com/post/45256059128/wealth-risk-and-stuff",
        "display_url" : "vruba.tumblr.com/post/452560591\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "311950619403501568",
    "text" : "\u201CWealth is not a number of dollars. It is not a number of material possessions. It\u2019s having options to take on risk.\u201D http://t.co/taedNoVteN",
    "id" : 311950619403501568,
    "created_at" : "Wed Mar 13 21:23:18 +0000 2013",
    "user" : {
      "name" : "Ben Ward",
      "screen_name" : "benward",
      "protected" : false,
      "id_str" : "12249",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3491826165/a64d6748a969b9e6fabd3405649d78b0_normal.png",
      "id" : 12249,
      "verified" : false
    }
  },
  "id" : 311950770062913537,
  "created_at" : "Wed Mar 13 21:23:54 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emilio Ramirez",
      "screen_name" : "e_ramirez",
      "indices" : [ 0, 10 ],
      "id_str" : "1273564632",
      "id" : 1273564632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "311939315527716864",
  "geo" : {
  },
  "id_str" : "311939734115065856",
  "in_reply_to_user_id" : 21135674,
  "text" : "@e_ramirez Thank you, sir.",
  "id" : 311939734115065856,
  "in_reply_to_status_id" : 311939315527716864,
  "created_at" : "Wed Mar 13 20:40:02 +0000 2013",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Jacobs",
      "screen_name" : "evanjacobs",
      "indices" : [ 0, 11 ],
      "id_str" : "14803483",
      "id" : 14803483
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "311866183223746560",
  "geo" : {
  },
  "id_str" : "311884909365055488",
  "in_reply_to_user_id" : 14803483,
  "text" : "@evanjacobs Woah, thanks. :) And that reminds me, I owe you an email. Will get on that today.",
  "id" : 311884909365055488,
  "in_reply_to_status_id" : 311866183223746560,
  "created_at" : "Wed Mar 13 17:02:11 +0000 2013",
  "in_reply_to_screen_name" : "evanjacobs",
  "in_reply_to_user_id_str" : "14803483",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emily Chen",
      "screen_name" : "emilychen",
      "indices" : [ 3, 13 ],
      "id_str" : "12658972",
      "id" : 12658972
    }, {
      "name" : "Kickstarter",
      "screen_name" : "kickstarter",
      "indices" : [ 102, 114 ],
      "id_str" : "16186995",
      "id" : 16186995
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http://t.co/yIJYOKx1hS",
      "expanded_url" : "http://kck.st/Z1HJRR",
      "display_url" : "kck.st/Z1HJRR"
    } ]
  },
  "geo" : {
  },
  "id_str" : "311878710007590914",
  "text" : "RT @emilychen: The Veronica Mars Movie Project by Rob Thomas \u2014 Kickstarter http://t.co/yIJYOKx1hS via @kickstarter // Yes please.",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kickstarter",
        "screen_name" : "kickstarter",
        "indices" : [ 87, 99 ],
        "id_str" : "16186995",
        "id" : 16186995
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 60, 82 ],
        "url" : "http://t.co/yIJYOKx1hS",
        "expanded_url" : "http://kck.st/Z1HJRR",
        "display_url" : "kck.st/Z1HJRR"
      } ]
    },
    "geo" : {
    },
    "id_str" : "311870624425443328",
    "text" : "The Veronica Mars Movie Project by Rob Thomas \u2014 Kickstarter http://t.co/yIJYOKx1hS via @kickstarter // Yes please.",
    "id" : 311870624425443328,
    "created_at" : "Wed Mar 13 16:05:25 +0000 2013",
    "user" : {
      "name" : "Emily Chen",
      "screen_name" : "emilychen",
      "protected" : false,
      "id_str" : "12658972",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1949454462/IMG_6846_normal.jpg",
      "id" : 12658972,
      "verified" : false
    }
  },
  "id" : 311878710007590914,
  "created_at" : "Wed Mar 13 16:37:33 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nate Silver",
      "screen_name" : "fivethirtyeight",
      "indices" : [ 118, 134 ],
      "id_str" : "16017475",
      "id" : 16017475
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "311874458455523328",
  "text" : "\"When there's an excess of greed in a system, there is a bubble. When there's an excess of fear, there is a panic.\" - @fivethirtyeight",
  "id" : 311874458455523328,
  "created_at" : "Wed Mar 13 16:20:39 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Magnus Johansson",
      "screen_name" : "pgmjoh",
      "indices" : [ 0, 7 ],
      "id_str" : "389920517",
      "id" : 389920517
    }, {
      "name" : "Lift",
      "screen_name" : "liftapp",
      "indices" : [ 8, 16 ],
      "id_str" : "353195232",
      "id" : 353195232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "311860377052934144",
  "geo" : {
  },
  "id_str" : "311861981273530368",
  "in_reply_to_user_id" : 389920517,
  "text" : "@pgmjoh @liftapp I don't really know yet. But it's not easy. Many of these questions are not yet answered.",
  "id" : 311861981273530368,
  "in_reply_to_status_id" : 311860377052934144,
  "created_at" : "Wed Mar 13 15:31:05 +0000 2013",
  "in_reply_to_screen_name" : "pgmjoh",
  "in_reply_to_user_id_str" : "389920517",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lift",
      "screen_name" : "liftapp",
      "indices" : [ 72, 80 ],
      "id_str" : "353195232",
      "id" : 353195232
    }, {
      "name" : "BJ Fogg",
      "screen_name" : "bjfogg",
      "indices" : [ 81, 88 ],
      "id_str" : "1118691",
      "id" : 1118691
    }, {
      "name" : "Emilio Ramirez",
      "screen_name" : "e_ramirez",
      "indices" : [ 89, 99 ],
      "id_str" : "1273564632",
      "id" : 1273564632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 67 ],
      "url" : "http://t.co/B0yIUZqCS6",
      "expanded_url" : "http://bit.ly/YnqVoh",
      "display_url" : "bit.ly/YnqVoh"
    } ]
  },
  "geo" : {
  },
  "id_str" : "311859650691756032",
  "text" : "\"Are habits tiny or huge?\" - Way of the Duck http://t.co/B0yIUZqCS6 /cc @liftapp @bjfogg @e_ramirez",
  "id" : 311859650691756032,
  "created_at" : "Wed Mar 13 15:21:49 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Livia Labate",
      "screen_name" : "livlab",
      "indices" : [ 0, 7 ],
      "id_str" : "769920",
      "id" : 769920
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "311719784821710849",
  "geo" : {
  },
  "id_str" : "311720390613401600",
  "in_reply_to_user_id" : 769920,
  "text" : "@livlab The interesting thing in many cases is that \"trying\" has nothing to do with it.",
  "id" : 311720390613401600,
  "in_reply_to_status_id" : 311719784821710849,
  "created_at" : "Wed Mar 13 06:08:27 +0000 2013",
  "in_reply_to_screen_name" : "livlab",
  "in_reply_to_user_id_str" : "769920",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Berkun",
      "screen_name" : "berkun",
      "indices" : [ 23, 30 ],
      "id_str" : "30495974",
      "id" : 30495974
    }, {
      "name" : "Buster",
      "screen_name" : "buster",
      "indices" : [ 32, 39 ],
      "id_str" : "2185",
      "id" : 2185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "311718140079910914",
  "text" : "Charlie Brown Bias. RT @berkun: @buster it seems consumers have the habit of believing lies they want to hear",
  "id" : 311718140079910914,
  "created_at" : "Wed Mar 13 05:59:30 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian McAllister",
      "screen_name" : "ianmcall",
      "indices" : [ 69, 78 ],
      "id_str" : "2035631",
      "id" : 2035631
    }, {
      "name" : "Buster",
      "screen_name" : "buster",
      "indices" : [ 80, 87 ],
      "id_str" : "2185",
      "id" : 2185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "311717837540564992",
  "text" : "At first I thought you said 26,486 days and I was going to agree. RT @ianmcall: @buster Agree. It's actually 26.486 days +/- 0.53 days.",
  "id" : 311717837540564992,
  "created_at" : "Wed Mar 13 05:58:18 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "311717285524017153",
  "text" : "Some people say it takes 14/21/30/etc days to start a new habit. They say science proves it. Research show it. Look, testimonials!\n\nLIES.",
  "id" : 311717285524017153,
  "created_at" : "Wed Mar 13 05:56:06 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "April Schiller",
      "screen_name" : "the_april",
      "indices" : [ 0, 10 ],
      "id_str" : "16644937",
      "id" : 16644937
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "311704762695442432",
  "geo" : {
  },
  "id_str" : "311707822104670208",
  "in_reply_to_user_id" : 16644937,
  "text" : "@the_april Neat! Who was the talk by?",
  "id" : 311707822104670208,
  "in_reply_to_status_id" : 311704762695442432,
  "created_at" : "Wed Mar 13 05:18:30 +0000 2013",
  "in_reply_to_screen_name" : "the_april",
  "in_reply_to_user_id_str" : "16644937",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http://t.co/9Qaqh92z2N",
      "expanded_url" : "http://flic.kr/p/e2Tcfh",
      "display_url" : "flic.kr/p/e2Tcfh"
    } ]
  },
  "geo" : {
  },
  "id_str" : "311683438920994817",
  "text" : "8:36pm Niko keeps telling me how cute his bathtub gift from Vivienne is http://t.co/9Qaqh92z2N",
  "id" : 311683438920994817,
  "created_at" : "Wed Mar 13 03:41:37 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u028E\u01DD\u029E\u0254\u0131\u0265 \u0287\u0287\u0250\u026F",
      "screen_name" : "matthickey",
      "indices" : [ 0, 11 ],
      "id_str" : "8710082",
      "id" : 8710082
    }, {
      "name" : "Parmy Olson",
      "screen_name" : "parmy",
      "indices" : [ 41, 47 ],
      "id_str" : "19116515",
      "id" : 19116515
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "311641512498827264",
  "geo" : {
  },
  "id_str" : "311666734392295424",
  "in_reply_to_user_id" : 8710082,
  "text" : "@matthickey Congrats! If you get to meet @parmy I'll be jealous! Loved her book.",
  "id" : 311666734392295424,
  "in_reply_to_status_id" : 311641512498827264,
  "created_at" : "Wed Mar 13 02:35:14 +0000 2013",
  "in_reply_to_screen_name" : "matthickey",
  "in_reply_to_user_id_str" : "8710082",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nate Silver",
      "screen_name" : "fivethirtyeight",
      "indices" : [ 122, 138 ],
      "id_str" : "16017475",
      "id" : 16017475
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "311659697692360705",
  "text" : "\"We have to stop and admit it: we have a prediction problem. We love to predict things, but we aren't very good at it.\" - @fivethirtyeight",
  "id" : 311659697692360705,
  "created_at" : "Wed Mar 13 02:07:16 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Automatic ",
      "screen_name" : "automatic",
      "indices" : [ 27, 37 ],
      "id_str" : "618542623",
      "id" : 618542623
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http://t.co/4AzsYdmX0u",
      "expanded_url" : "http://bit.ly/Y8Io1A",
      "display_url" : "bit.ly/Y8Io1A"
    } ]
  },
  "geo" : {
  },
  "id_str" : "311544648533417985",
  "text" : "STOKED. I just pre-ordered @automatic to upgrade my car with my smartphone. Check it out: http://t.co/4AzsYdmX0u",
  "id" : 311544648533417985,
  "created_at" : "Tue Mar 12 18:30:07 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Rainert",
      "screen_name" : "arainert",
      "indices" : [ 0, 9 ],
      "id_str" : "7482",
      "id" : 7482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "311529486334193664",
  "geo" : {
  },
  "id_str" : "311532763893346304",
  "in_reply_to_user_id" : 7482,
  "text" : "@arainert I've been lax in my reading for a while but feel like there are a ton of great books to catch up on now. What's your top rec?",
  "id" : 311532763893346304,
  "in_reply_to_status_id" : 311529486334193664,
  "created_at" : "Tue Mar 12 17:42:53 +0000 2013",
  "in_reply_to_screen_name" : "arainert",
  "in_reply_to_user_id_str" : "7482",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Wayne",
      "screen_name" : "joshwayne",
      "indices" : [ 0, 10 ],
      "id_str" : "17052088",
      "id" : 17052088
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "311519437339643904",
  "geo" : {
  },
  "id_str" : "311519800125960192",
  "in_reply_to_user_id" : 17052088,
  "text" : "@joshwayne The book itself. It was written as a collaboration with 2 others, and I suspect they did most of the writing.",
  "id" : 311519800125960192,
  "in_reply_to_status_id" : 311519437339643904,
  "created_at" : "Tue Mar 12 16:51:22 +0000 2013",
  "in_reply_to_screen_name" : "joshwayne",
  "in_reply_to_user_id_str" : "17052088",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Pusateri",
      "screen_name" : "Cruftbox",
      "indices" : [ 0, 9 ],
      "id_str" : "792738",
      "id" : 792738
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "311518632066822144",
  "geo" : {
  },
  "id_str" : "311519176307126272",
  "in_reply_to_user_id" : 792738,
  "text" : "@Cruftbox That's exactly what I'm hoping. :)",
  "id" : 311519176307126272,
  "in_reply_to_status_id" : 311518632066822144,
  "created_at" : "Tue Mar 12 16:48:54 +0000 2013",
  "in_reply_to_screen_name" : "Cruftbox",
  "in_reply_to_user_id_str" : "792738",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nate Silver",
      "screen_name" : "fivethirtyeight",
      "indices" : [ 13, 29 ],
      "id_str" : "16017475",
      "id" : 16017475
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "311518176393449472",
  "text" : "Moving on to @fivethirtyeight's Signal and the Noise. Who's read it?",
  "id" : 311518176393449472,
  "created_at" : "Tue Mar 12 16:44:55 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "311517240136720384",
  "text" : "My first dud of an audiobook: How Will You Measure Your Life, by Clayton Christensen. Suspect book was just compiled from old notes.",
  "id" : 311517240136720384,
  "created_at" : "Tue Mar 12 16:41:12 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Svbtle Feed",
      "screen_name" : "SvbtleFeed",
      "indices" : [ 3, 14 ],
      "id_str" : "1352847072",
      "id" : 1352847072
    }, {
      "name" : "Kenton Kivestu",
      "screen_name" : "kivestu",
      "indices" : [ 131, 139 ],
      "id_str" : "14906420",
      "id" : 14906420
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http://t.co/UTA4MGG5Zm",
      "expanded_url" : "http://blog.kentonkivestu.com/what-behavioral-economics-can-teach-you-about-product-development-the-remembering-self",
      "display_url" : "blog.kentonkivestu.com/what-behaviora\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "311335241442807808",
  "text" : "RT @SvbtleFeed: What behavioral economics can teach you about product development: The remembering self\n\nhttp://t.co/UTA4MGG5Zm by @kivestu",
  "retweeted_status" : {
    "source" : "<a href=\"http://svbtle.com\" rel=\"nofollow\">Svbtle Feed</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kenton Kivestu",
        "screen_name" : "kivestu",
        "indices" : [ 115, 123 ],
        "id_str" : "14906420",
        "id" : 14906420
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 89, 111 ],
        "url" : "http://t.co/UTA4MGG5Zm",
        "expanded_url" : "http://blog.kentonkivestu.com/what-behavioral-economics-can-teach-you-about-product-development-the-remembering-self",
        "display_url" : "blog.kentonkivestu.com/what-behaviora\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "311328996270952448",
    "text" : "What behavioral economics can teach you about product development: The remembering self\n\nhttp://t.co/UTA4MGG5Zm by @kivestu",
    "id" : 311328996270952448,
    "created_at" : "Tue Mar 12 04:13:11 +0000 2013",
    "user" : {
      "name" : "Svbtle",
      "screen_name" : "Svbtle",
      "protected" : false,
      "id_str" : "776098190",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3628360840/42e89e02ef6e7a798d74e8bdf7ed4364_normal.png",
      "id" : 776098190,
      "verified" : false
    }
  },
  "id" : 311335241442807808,
  "created_at" : "Tue Mar 12 04:38:00 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niko Benson",
      "screen_name" : "nikobenson",
      "indices" : [ 19, 30 ],
      "id_str" : "142467448",
      "id" : 142467448
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 53 ],
      "url" : "http://t.co/Ik5bhqCpa9",
      "expanded_url" : "http://flic.kr/p/e2wb9c",
      "display_url" : "flic.kr/p/e2wb9c"
    } ]
  },
  "geo" : {
  },
  "id_str" : "311332873158406145",
  "text" : "8:36pm Courtesy of @nikobenson http://t.co/Ik5bhqCpa9",
  "id" : 311332873158406145,
  "created_at" : "Tue Mar 12 04:28:35 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LeVar Burzum",
      "screen_name" : "drugleaf",
      "indices" : [ 3, 12 ],
      "id_str" : "125386940",
      "id" : 125386940
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "311273887717535745",
  "text" : "RT @drugleaf: TWITTER HARD MODE: there's no \"connect\" tab, you can't see anyone's followers (even your own), and using irony gets you banned",
  "retweeted_status" : {
    "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M5)</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "311273390826721281",
    "text" : "TWITTER HARD MODE: there's no \"connect\" tab, you can't see anyone's followers (even your own), and using irony gets you banned",
    "id" : 311273390826721281,
    "created_at" : "Tue Mar 12 00:32:14 +0000 2013",
    "user" : {
      "name" : "LeVar Burzum",
      "screen_name" : "drugleaf",
      "protected" : false,
      "id_str" : "125386940",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2073506598/oreyhrf_normal.gif",
      "id" : 125386940,
      "verified" : false
    }
  },
  "id" : 311273887717535745,
  "created_at" : "Tue Mar 12 00:34:12 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/buster/status/311190663251238912/photo/1",
      "indices" : [ 100, 122 ],
      "url" : "http://t.co/pxy3QKhaxL",
      "media_url" : "http://pbs.twimg.com/media/BFGSQm0CIAA9HLg.jpg",
      "id_str" : "311190663259627520",
      "id" : 311190663259627520,
      "media_url_https" : "https://pbs.twimg.com/media/BFGSQm0CIAA9HLg.jpg",
      "sizes" : [ {
        "h" : 905,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 848,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 905,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 481,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com/pxy3QKhaxL"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "311190663251238912",
  "text" : "977. Ate 89% healthy lunches last week (20% WoW improvement). Gonna try to beat it again this week. http://t.co/pxy3QKhaxL",
  "id" : 311190663251238912,
  "created_at" : "Mon Mar 11 19:03:30 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/read-it-later-pro/id309601447?mt=8&uo=4\" rel=\"nofollow\">Pocket for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "longreads",
      "indices" : [ 81, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http://t.co/2yuN3uLJ2S",
      "expanded_url" : "http://pocket.co/s62KV",
      "display_url" : "pocket.co/s62KV"
    } ]
  },
  "geo" : {
  },
  "id_str" : "311004933812011009",
  "text" : "A Day in the Life of a Digital Editor, 2013. A must read if you haven't already. #longreads http://t.co/2yuN3uLJ2S",
  "id" : 311004933812011009,
  "created_at" : "Mon Mar 11 06:45:29 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/read-it-later-pro/id309601447?mt=8&uo=4\" rel=\"nofollow\">Pocket for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http://t.co/dmsAaxNzEE",
      "expanded_url" : "http://pocket.co/s62D5",
      "display_url" : "pocket.co/s62D5"
    } ]
  },
  "geo" : {
  },
  "id_str" : "311000626727374848",
  "text" : "Gonna ponder this idea. \"Every five or ten years, learn something entirely new.\" http://t.co/dmsAaxNzEE",
  "id" : 311000626727374848,
  "created_at" : "Mon Mar 11 06:28:22 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lawrence Yoga",
      "screen_name" : "lawrenceyoga",
      "indices" : [ 0, 13 ],
      "id_str" : "407975744",
      "id" : 407975744
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "310859555439517696",
  "geo" : {
  },
  "id_str" : "310997945522733057",
  "in_reply_to_user_id" : 407975744,
  "text" : "@lawrenceyoga The Equanimity iPhone app. Simple but delightful to use.",
  "id" : 310997945522733057,
  "in_reply_to_status_id" : 310859555439517696,
  "created_at" : "Mon Mar 11 06:17:42 +0000 2013",
  "in_reply_to_screen_name" : "lawrenceyoga",
  "in_reply_to_user_id_str" : "407975744",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Heer Salaiti",
      "screen_name" : "digital_heer",
      "indices" : [ 0, 13 ],
      "id_str" : "204916326",
      "id" : 204916326
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "310995063553523712",
  "geo" : {
  },
  "id_str" : "310996293327671296",
  "in_reply_to_user_id" : 204916326,
  "text" : "@digital_heer Workouts and anything that feels like progress towards my goal of running a marathon and getting in shape.",
  "id" : 310996293327671296,
  "in_reply_to_status_id" : 310995063553523712,
  "created_at" : "Mon Mar 11 06:11:09 +0000 2013",
  "in_reply_to_screen_name" : "digital_heer",
  "in_reply_to_user_id_str" : "204916326",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/buster/status/310996084065447936/photo/1",
      "indices" : [ 112, 134 ],
      "url" : "http://t.co/0QpB641NoK",
      "media_url" : "http://pbs.twimg.com/media/BFDhSm3CMAA0Lf1.jpg",
      "id_str" : "310996084073836544",
      "id" : 310996084073836544,
      "media_url_https" : "https://pbs.twimg.com/media/BFDhSm3CMAA0Lf1.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 577
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 577
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 603,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 577
      } ],
      "display_url" : "pic.twitter.com/0QpB641NoK"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "310996084065447936",
  "text" : "978. The last 3-4 chapters of How To Create A Mind were written directly to my interests. Whole book was great. http://t.co/0QpB641NoK",
  "id" : 310996084065447936,
  "created_at" : "Mon Mar 11 06:10:19 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "310994643955380224",
  "text" : "979. Still sore from yesterday's run. I think that makes it count again.",
  "id" : 310994643955380224,
  "created_at" : "Mon Mar 11 06:04:35 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kelly McGonigal",
      "screen_name" : "kellymcgonigal",
      "indices" : [ 0, 15 ],
      "id_str" : "38981543",
      "id" : 38981543
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "310992632325226497",
  "geo" : {
  },
  "id_str" : "310993991707553793",
  "in_reply_to_user_id" : 38981543,
  "text" : "@kellymcgonigal Your pause/plan response resonates with me. So does the slow breathing. Helped to frame it as antidote to fight/flight.",
  "id" : 310993991707553793,
  "in_reply_to_status_id" : 310992632325226497,
  "created_at" : "Mon Mar 11 06:02:00 +0000 2013",
  "in_reply_to_screen_name" : "kellymcgonigal",
  "in_reply_to_user_id_str" : "38981543",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kelly McGonigal",
      "screen_name" : "kellymcgonigal",
      "indices" : [ 0, 15 ],
      "id_str" : "38981543",
      "id" : 38981543
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "310991460545736704",
  "geo" : {
  },
  "id_str" : "310992040605396992",
  "in_reply_to_user_id" : 38981543,
  "text" : "@kellymcgonigal Meditation needs rebranding, like a hundred kinds of soda, something for every personal taste. Even Meditation Zero.",
  "id" : 310992040605396992,
  "in_reply_to_status_id" : 310991460545736704,
  "created_at" : "Mon Mar 11 05:54:15 +0000 2013",
  "in_reply_to_screen_name" : "kellymcgonigal",
  "in_reply_to_user_id_str" : "38981543",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kelly McGonigal",
      "screen_name" : "kellymcgonigal",
      "indices" : [ 0, 15 ],
      "id_str" : "38981543",
      "id" : 38981543
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "310987792891133952",
  "geo" : {
  },
  "id_str" : "310989019142049792",
  "in_reply_to_user_id" : 38981543,
  "text" : "@kellymcgonigal Meditation?",
  "id" : 310989019142049792,
  "in_reply_to_status_id" : 310987792891133952,
  "created_at" : "Mon Mar 11 05:42:14 +0000 2013",
  "in_reply_to_screen_name" : "kellymcgonigal",
  "in_reply_to_user_id_str" : "38981543",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http://t.co/RmcQtharCA",
      "expanded_url" : "http://flic.kr/p/e2eEyt",
      "display_url" : "flic.kr/p/e2eEyt"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859666, -122.275334 ]
  },
  "id_str" : "310965012854362114",
  "text" : "8:36pm Playing trains with Jimmy James http://t.co/RmcQtharCA",
  "id" : 310965012854362114,
  "created_at" : "Mon Mar 11 04:06:51 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.apple.com\" rel=\"nofollow\">Safari on iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Hyde",
      "screen_name" : "andrewhyde",
      "indices" : [ 5, 16 ],
      "id_str" : "841791",
      "id" : 841791
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http://t.co/LQWM5DZ8FI",
      "expanded_url" : "http://15things.me/",
      "display_url" : "15things.me"
    } ]
  },
  "geo" : {
  },
  "id_str" : "310852951403008002",
  "text" : "When @andrewhyde  started his world travels, he limited his belongings to 15 things. What would your 15 things be? http://t.co/LQWM5DZ8FI",
  "id" : 310852951403008002,
  "created_at" : "Sun Mar 10 20:41:33 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://vine.co\" rel=\"nofollow\">Vine - Make a Scene</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 38 ],
      "url" : "http://t.co/JsVsxw4MXu",
      "expanded_url" : "http://vine.co/v/bwdd6dQEtIV",
      "display_url" : "vine.co/v/bwdd6dQEtIV"
    } ]
  },
  "geo" : {
  },
  "id_str" : "310847564494811136",
  "text" : "Planting a tree http://t.co/JsVsxw4MXu",
  "id" : 310847564494811136,
  "created_at" : "Sun Mar 10 20:20:09 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicola Gibb",
      "screen_name" : "nicgibb",
      "indices" : [ 0, 8 ],
      "id_str" : "17619709",
      "id" : 17619709
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "310816211611041792",
  "geo" : {
  },
  "id_str" : "310816455010684928",
  "in_reply_to_user_id" : 17619709,
  "text" : "@nicgibb The Equanimity iPhone app, which is pretty simple but nice to use.",
  "id" : 310816455010684928,
  "in_reply_to_status_id" : 310816211611041792,
  "created_at" : "Sun Mar 10 18:16:32 +0000 2013",
  "in_reply_to_screen_name" : "nicgibb",
  "in_reply_to_user_id_str" : "17619709",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/buster/status/310813442594447361/photo/1",
      "indices" : [ 105, 127 ],
      "url" : "http://t.co/tUi5StPLYh",
      "media_url" : "http://pbs.twimg.com/media/BFA7LeXCIAAsZn3.jpg",
      "id_str" : "310813442602835968",
      "id" : 310813442602835968,
      "media_url_https" : "https://pbs.twimg.com/media/BFA7LeXCIAAsZn3.jpg",
      "sizes" : [ {
        "h" : 577,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 192,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 577,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com/tUi5StPLYh"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "310813442594447361",
  "text" : "980. 10-day 5-minute meditation streak. Trying to think of it as 10+ reps of attention catch and return. http://t.co/tUi5StPLYh",
  "id" : 310813442594447361,
  "created_at" : "Sun Mar 10 18:04:34 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 37 ],
      "url" : "http://t.co/HrXa0Gyoy4",
      "expanded_url" : "http://flic.kr/p/e1WmxT",
      "display_url" : "flic.kr/p/e1WmxT"
    } ]
  },
  "geo" : {
  },
  "id_str" : "310633711148351488",
  "text" : "The last chair http://t.co/HrXa0Gyoy4",
  "id" : 310633711148351488,
  "created_at" : "Sun Mar 10 06:10:22 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http://t.co/WmqhMQ0kvF",
      "expanded_url" : "http://flic.kr/p/e22feL",
      "display_url" : "flic.kr/p/e22feL"
    } ]
  },
  "geo" : {
  },
  "id_str" : "310612738063872000",
  "text" : "8:36pm Amelia and Adam are our first official dinner guests. Post dinner train madness in evidence. http://t.co/WmqhMQ0kvF",
  "id" : 310612738063872000,
  "created_at" : "Sun Mar 10 04:47:02 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 64 ],
      "url" : "http://t.co/eEVChPWn11",
      "expanded_url" : "http://flic.kr/p/e1Tr84",
      "display_url" : "flic.kr/p/e1Tr84"
    } ]
  },
  "geo" : {
  },
  "id_str" : "310558626848854017",
  "text" : "How are y'all liking the snow over there? http://t.co/eEVChPWn11",
  "id" : 310558626848854017,
  "created_at" : "Sun Mar 10 01:12:01 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tehgeekmeister",
      "screen_name" : "tehgeekmeister",
      "indices" : [ 0, 15 ],
      "id_str" : "6727082",
      "id" : 6727082
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 38 ],
      "url" : "http://t.co/9OiUIZGIZo",
      "expanded_url" : "http://www.amazon.com/gp/aw/d/0981690408/",
      "display_url" : "amazon.com/gp/aw/d/098169\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "310541696180056065",
  "geo" : {
  },
  "id_str" : "310542106185826304",
  "in_reply_to_user_id" : 6727082,
  "text" : "@tehgeekmeister http://t.co/9OiUIZGIZo",
  "id" : 310542106185826304,
  "in_reply_to_status_id" : 310541696180056065,
  "created_at" : "Sun Mar 10 00:06:22 +0000 2013",
  "in_reply_to_screen_name" : "tehgeekmeister",
  "in_reply_to_user_id_str" : "6727082",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tehgeekmeister",
      "screen_name" : "tehgeekmeister",
      "indices" : [ 0, 15 ],
      "id_str" : "6727082",
      "id" : 6727082
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "310539983696048129",
  "geo" : {
  },
  "id_str" : "310540639982993408",
  "in_reply_to_user_id" : 6727082,
  "text" : "@tehgeekmeister It's a book. Worth a read.",
  "id" : 310540639982993408,
  "in_reply_to_status_id" : 310539983696048129,
  "created_at" : "Sun Mar 10 00:00:32 +0000 2013",
  "in_reply_to_screen_name" : "tehgeekmeister",
  "in_reply_to_user_id_str" : "6727082",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "310540469144801280",
  "text" : "\"Serving others\" sounds diminutive but it sets constraints on range of possibility for those they serve. In that sense they're also masters.",
  "id" : 310540469144801280,
  "created_at" : "Sat Mar 09 23:59:52 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "310539243267174400",
  "text" : "\"Hardware serves software, software serves user experience, user experience serves emotion.\" - nice summary from end of Inspired.",
  "id" : 310539243267174400,
  "created_at" : "Sat Mar 09 23:54:59 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Polar",
      "screen_name" : "polarpolls",
      "indices" : [ 9, 20 ],
      "id_str" : "870483607",
      "id" : 870483607
    }, {
      "name" : "James King",
      "screen_name" : "elroyjetson",
      "indices" : [ 101, 113 ],
      "id_str" : "7632932",
      "id" : 7632932
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "reading",
      "indices" : [ 82, 90 ]
    }, {
      "text" : "poll",
      "indices" : [ 91, 96 ]
    } ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http://t.co/LIYS7bfgbi",
      "expanded_url" : "http://polarb.com/65740",
      "display_url" : "polarb.com/65740"
    } ]
  },
  "in_reply_to_status_id_str" : "310499509564239872",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597579757, -122.2756664829 ]
  },
  "id_str" : "310505115029209088",
  "in_reply_to_user_id" : 870483607,
  "text" : "Yes!! RT @polarpolls: Do You Count Audio Books As Reading? http://t.co/LIYS7bfgbi #reading #poll via @elroyjetson",
  "id" : 310505115029209088,
  "in_reply_to_status_id" : 310499509564239872,
  "created_at" : "Sat Mar 09 21:39:22 +0000 2013",
  "in_reply_to_screen_name" : "polarpolls",
  "in_reply_to_user_id_str" : "870483607",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "todd sawicki",
      "screen_name" : "sawickipedia",
      "indices" : [ 0, 13 ],
      "id_str" : "1784841",
      "id" : 1784841
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "310497651017793536",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596731878, -122.2754877894 ]
  },
  "id_str" : "310504409266262016",
  "in_reply_to_user_id" : 1784841,
  "text" : "@sawickipedia I just mean it in the sense of making public predictions about the future. The title has a low bar to meet.",
  "id" : 310504409266262016,
  "in_reply_to_status_id" : 310497651017793536,
  "created_at" : "Sat Mar 09 21:36:34 +0000 2013",
  "in_reply_to_screen_name" : "sawickipedia",
  "in_reply_to_user_id_str" : "1784841",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian McFarland",
      "screen_name" : "imf",
      "indices" : [ 3, 7 ],
      "id_str" : "1260941",
      "id" : 1260941
    }, {
      "name" : "Elon Musk",
      "screen_name" : "elonmusk",
      "indices" : [ 56, 65 ],
      "id_str" : "44196397",
      "id" : 44196397
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sxsw",
      "indices" : [ 66, 71 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "310495515538251776",
  "text" : "RT @imf: \"I'd like to die on Mars, just not on impact.\" @elonmusk #sxsw",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Elon Musk",
        "screen_name" : "elonmusk",
        "indices" : [ 47, 56 ],
        "id_str" : "44196397",
        "id" : 44196397
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "sxsw",
        "indices" : [ 57, 62 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "310493601631178752",
    "text" : "\"I'd like to die on Mars, just not on impact.\" @elonmusk #sxsw",
    "id" : 310493601631178752,
    "created_at" : "Sat Mar 09 20:53:37 +0000 2013",
    "user" : {
      "name" : "Ian McFarland",
      "screen_name" : "imf",
      "protected" : false,
      "id_str" : "1260941",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/234546376/ian_in_malaysia_normal.png",
      "id" : 1260941,
      "verified" : false
    }
  },
  "id" : 310495515538251776,
  "created_at" : "Sat Mar 09 21:01:14 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Guarraci",
      "screen_name" : "eismcc",
      "indices" : [ 0, 7 ],
      "id_str" : "13257392",
      "id" : 13257392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "310483581841596416",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8594991087, -122.2755118815 ]
  },
  "id_str" : "310483748560965632",
  "in_reply_to_user_id" : 13257392,
  "text" : "@eismcc Tech news is full of prophets.",
  "id" : 310483748560965632,
  "in_reply_to_status_id" : 310483581841596416,
  "created_at" : "Sat Mar 09 20:14:28 +0000 2013",
  "in_reply_to_screen_name" : "eismcc",
  "in_reply_to_user_id_str" : "13257392",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://vine.co\" rel=\"nofollow\">Vine - Make a Scene</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 51 ],
      "url" : "http://t.co/uauS9jC8zK",
      "expanded_url" : "http://vine.co/v/bw5HxaL5Hw5",
      "display_url" : "vine.co/v/bw5HxaL5Hw5"
    } ]
  },
  "geo" : {
  },
  "id_str" : "310480846543015936",
  "text" : "Reading Cat in the Hat to us http://t.co/uauS9jC8zK",
  "id" : 310480846543015936,
  "created_at" : "Sat Mar 09 20:02:56 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http://t.co/bF5o9W6KuJ",
      "expanded_url" : "http://bit.ly/YjItyz",
      "display_url" : "bit.ly/YjItyz"
    } ]
  },
  "geo" : {
  },
  "id_str" : "310479678395785216",
  "text" : "Kurzweil is the only prophet I know who periodically reviews his own predictions. How his 147 predictions are faring: http://t.co/bF5o9W6KuJ",
  "id" : 310479678395785216,
  "created_at" : "Sat Mar 09 19:58:18 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "teamkurzweil",
      "indices" : [ 113, 126 ]
    } ],
    "urls" : [ {
      "indices" : [ 34, 56 ],
      "url" : "http://t.co/uhbd6Ydnad",
      "expanded_url" : "http://bit.ly/YjI0MI",
      "display_url" : "bit.ly/YjI0MI"
    }, {
      "indices" : [ 76, 98 ],
      "url" : "http://t.co/m9QoU0Z4r7",
      "expanded_url" : "http://bit.ly/YjHY7z",
      "display_url" : "bit.ly/YjHY7z"
    } ]
  },
  "geo" : {
  },
  "id_str" : "310478555085676544",
  "text" : "In the debate between Paul Allen (http://t.co/uhbd6Ydnad) and Ray Kurzweil (http://t.co/m9QoU0Z4r7), I'm 100% on #teamkurzweil.",
  "id" : 310478555085676544,
  "created_at" : "Sat Mar 09 19:53:50 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Rainert",
      "screen_name" : "arainert",
      "indices" : [ 0, 9 ],
      "id_str" : "7482",
      "id" : 7482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http://t.co/kO4I77Bqss",
      "expanded_url" : "http://wayoftheduck.com/1000-small-things",
      "display_url" : "wayoftheduck.com/1000-small-thi\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "310461606809174016",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596716234, -122.2754450646 ]
  },
  "id_str" : "310477166934642688",
  "in_reply_to_user_id" : 7482,
  "text" : "@arainert Counting down 1,000 small things I'm doing to run a marathon and generally get my health back in order http://t.co/kO4I77Bqss",
  "id" : 310477166934642688,
  "in_reply_to_status_id" : 310461606809174016,
  "created_at" : "Sat Mar 09 19:48:19 +0000 2013",
  "in_reply_to_screen_name" : "arainert",
  "in_reply_to_user_id_str" : "7482",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.apple.com\" rel=\"nofollow\">iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http://t.co/hFMKeHurZ3",
      "expanded_url" : "http://runkeeper.com/activity?userId=1481953&trip=155721899",
      "display_url" : "runkeeper.com/activity?userI\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.860761, -122.29991 ]
  },
  "id_str" : "310459887706591233",
  "text" : "981. Longest run so far this year. Felt nice.  http://t.co/hFMKeHurZ3",
  "id" : 310459887706591233,
  "created_at" : "Sat Mar 09 18:39:39 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 43 ],
      "url" : "http://t.co/ACRZ2hBNHN",
      "expanded_url" : "http://flic.kr/p/e1NkLF",
      "display_url" : "flic.kr/p/e1NkLF"
    } ]
  },
  "geo" : {
  },
  "id_str" : "310452075110748161",
  "text" : "Pretty day is pretty http://t.co/ACRZ2hBNHN",
  "id" : 310452075110748161,
  "created_at" : "Sat Mar 09 18:08:37 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Lambert",
      "screen_name" : "trichris",
      "indices" : [ 0, 9 ],
      "id_str" : "40340735",
      "id" : 40340735
    }, {
      "name" : "ibrahim bashir",
      "screen_name" : "ibrahimbashir",
      "indices" : [ 10, 24 ],
      "id_str" : "19079210",
      "id" : 19079210
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "greattrackstogreatdestinations",
      "indices" : [ 52, 83 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "310262322419621888",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596815104, -122.275589685 ]
  },
  "id_str" : "310264729149009920",
  "in_reply_to_user_id" : 40340735,
  "text" : "@trichris @ibrahimbashir You guys know your trains! #greattrackstogreatdestinations",
  "id" : 310264729149009920,
  "in_reply_to_status_id" : 310262322419621888,
  "created_at" : "Sat Mar 09 05:44:10 +0000 2013",
  "in_reply_to_screen_name" : "trichris",
  "in_reply_to_user_id_str" : "40340735",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trunk Club",
      "screen_name" : "TrunkClub",
      "indices" : [ 13, 23 ],
      "id_str" : "19734728",
      "id" : 19734728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http://t.co/OqHf9bSRsy",
      "expanded_url" : "http://flic.kr/p/e1Fnj2",
      "display_url" : "flic.kr/p/e1Fnj2"
    } ]
  },
  "geo" : {
  },
  "id_str" : "310259520045727744",
  "text" : "Got my first @trunkclub! http://t.co/OqHf9bSRsy",
  "id" : 310259520045727744,
  "created_at" : "Sat Mar 09 05:23:28 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://vine.co\" rel=\"nofollow\">Vine - Make a Scene</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "flipbook",
      "indices" : [ 23, 32 ]
    } ],
    "urls" : [ {
      "indices" : [ 33, 55 ],
      "url" : "http://t.co/4zeWEexje9",
      "expanded_url" : "http://vine.co/v/bwqtv6erulV",
      "display_url" : "vine.co/v/bwqtv6erulV"
    } ]
  },
  "geo" : {
  },
  "id_str" : "310252888851087360",
  "text" : "The Butter Battle Book #flipbook http://t.co/4zeWEexje9",
  "id" : 310252888851087360,
  "created_at" : "Sat Mar 09 04:57:07 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http://t.co/uRgqE57BvS",
      "expanded_url" : "http://flic.kr/p/e1F6Fr",
      "display_url" : "flic.kr/p/e1F6Fr"
    } ]
  },
  "geo" : {
  },
  "id_str" : "310249989823672321",
  "text" : "8:36pm Reading one of my favorite childhood books http://t.co/uRgqE57BvS",
  "id" : 310249989823672321,
  "created_at" : "Sat Mar 09 04:45:36 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amelia Greenhall",
      "screen_name" : "ameliagreenhall",
      "indices" : [ 0, 16 ],
      "id_str" : "246531241",
      "id" : 246531241
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "310238590024167424",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597288905, -122.275215285 ]
  },
  "id_str" : "310239018753343491",
  "in_reply_to_user_id" : 246531241,
  "text" : "@ameliagreenhall Indeed quite a year. Can't really build anything now but thinking about stuff still. Tomorrow is gonna be fun!",
  "id" : 310239018753343491,
  "in_reply_to_status_id" : 310238590024167424,
  "created_at" : "Sat Mar 09 04:02:00 +0000 2013",
  "in_reply_to_screen_name" : "ameliagreenhall",
  "in_reply_to_user_id_str" : "246531241",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amelia Greenhall",
      "screen_name" : "ameliagreenhall",
      "indices" : [ 0, 16 ],
      "id_str" : "246531241",
      "id" : 246531241
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "310237413165375488",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597754541, -122.2753423409 ]
  },
  "id_str" : "310237963932024832",
  "in_reply_to_user_id" : 246531241,
  "text" : "@ameliagreenhall The domain is up for renewal. That was just a year ago. Still a good idea!",
  "id" : 310237963932024832,
  "in_reply_to_status_id" : 310237413165375488,
  "created_at" : "Sat Mar 09 03:57:49 +0000 2013",
  "in_reply_to_screen_name" : "ameliagreenhall",
  "in_reply_to_user_id_str" : "246531241",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amelia Greenhall",
      "screen_name" : "ameliagreenhall",
      "indices" : [ 0, 16 ],
      "id_str" : "246531241",
      "id" : 246531241
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 48 ],
      "url" : "http://t.co/4B27umY9P1",
      "expanded_url" : "http://nagmode.com",
      "display_url" : "nagmode.com"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596957672, -122.2752867712 ]
  },
  "id_str" : "310237228574056448",
  "in_reply_to_user_id" : 246531241,
  "text" : "@ameliagreenhall remember http://t.co/4B27umY9P1?",
  "id" : 310237228574056448,
  "created_at" : "Sat Mar 09 03:54:53 +0000 2013",
  "in_reply_to_screen_name" : "ameliagreenhall",
  "in_reply_to_user_id_str" : "246531241",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8551055584, -122.2712928896 ]
  },
  "id_str" : "310227348123447296",
  "text" : "Prediction that computers passing the Turing Test is gonna come down to making human-like mistakes.",
  "id" : 310227348123447296,
  "created_at" : "Sat Mar 09 03:15:38 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7792431942, -122.414242947 ]
  },
  "id_str" : "310219889728167936",
  "text" : "Sometimes I wonder how many if us would pass a Turing Test.",
  "id" : 310219889728167936,
  "created_at" : "Sat Mar 09 02:45:59 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sessions",
      "screen_name" : "joinsessions",
      "indices" : [ 3, 16 ],
      "id_str" : "360907906",
      "id" : 360907906
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "310143961710874625",
  "text" : "RT @joinsessions: We're going to start coaching people to improve the way they eat using everything we've learned. Interested? Click: ht ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 138 ],
        "url" : "http://t.co/vQFzm9vJ5a",
        "expanded_url" : "http://bit.ly/YQ5ngL",
        "display_url" : "bit.ly/YQ5ngL"
      } ]
    },
    "geo" : {
    },
    "id_str" : "310143697683623937",
    "text" : "We're going to start coaching people to improve the way they eat using everything we've learned. Interested? Click: http://t.co/vQFzm9vJ5a",
    "id" : 310143697683623937,
    "created_at" : "Fri Mar 08 21:43:14 +0000 2013",
    "user" : {
      "name" : "Sessions",
      "screen_name" : "joinsessions",
      "protected" : false,
      "id_str" : "360907906",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1780748654/Screen_Shot_2012-01-25_at_9.53.58_AM_normal.png",
      "id" : 360907906,
      "verified" : false
    }
  },
  "id" : 310143961710874625,
  "created_at" : "Fri Mar 08 21:44:17 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ken Jennings",
      "screen_name" : "KenJennings",
      "indices" : [ 42, 54 ],
      "id_str" : "234270825",
      "id" : 234270825
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7762614976, -122.4175752607 ]
  },
  "id_str" : "310126251140583424",
  "text" : "What would Watson (the computer that beat @KenJennings at Jeopardy) be like if instead of reading all of Wikipedia had read all of Twitter?",
  "id" : 310126251140583424,
  "created_at" : "Fri Mar 08 20:33:54 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"https://findings.com\" rel=\"nofollow\">Findings</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Findings",
      "screen_name" : "findings",
      "indices" : [ 99, 108 ],
      "id_str" : "208197274",
      "id" : 208197274
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http://t.co/veSqv0TbUa",
      "expanded_url" : "http://fnd.gs/Y0FldM",
      "display_url" : "fnd.gs/Y0FldM"
    } ]
  },
  "geo" : {
  },
  "id_str" : "310081825324298240",
  "text" : "\"Shaped a little like a loaf of French country bread, our brain is a crowded chemistry lab...\" via @findings - http://t.co/veSqv0TbUa",
  "id" : 310081825324298240,
  "created_at" : "Fri Mar 08 17:37:22 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin Jo Richey",
      "screen_name" : "erinjo",
      "indices" : [ 3, 10 ],
      "id_str" : "14961286",
      "id" : 14961286
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "310080069823504385",
  "text" : "RT @erinjo: Recently I learned FOMO is a thing. Today I learned JOMO (joy of missing out) is a thing too. Maybe UOMO (unaware of...) sho ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://bufferapp.com\" rel=\"nofollow\">Buffer</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "310079515252637697",
    "text" : "Recently I learned FOMO is a thing. Today I learned JOMO (joy of missing out) is a thing too. Maybe UOMO (unaware of...) should be a thing.",
    "id" : 310079515252637697,
    "created_at" : "Fri Mar 08 17:28:12 +0000 2013",
    "user" : {
      "name" : "Erin Jo Richey",
      "screen_name" : "erinjo",
      "protected" : false,
      "id_str" : "14961286",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3688224237/d32400fb06956732bf7c2c86e4e5a489_normal.jpeg",
      "id" : 14961286,
      "verified" : false
    }
  },
  "id" : 310080069823504385,
  "created_at" : "Fri Mar 08 17:30:24 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "310059759615217664",
  "text" : "Me: *burp* Excuse me.\nNiko: You're welcome.",
  "id" : 310059759615217664,
  "created_at" : "Fri Mar 08 16:09:41 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "healthmonth",
      "indices" : [ 50, 62 ]
    } ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http://t.co/cqz85L4hk7",
      "expanded_url" : "http://flic.kr/p/e1yp8G",
      "display_url" : "flic.kr/p/e1yp8G"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859666, -122.275334 ]
  },
  "id_str" : "309904949733625856",
  "text" : "8:36pm Thought suppression doesn't work, they say #healthmonth http://t.co/cqz85L4hk7",
  "id" : 309904949733625856,
  "created_at" : "Fri Mar 08 05:54:32 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://vine.co\" rel=\"nofollow\">Vine - Make a Scene</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 45 ],
      "url" : "http://t.co/bmmrGjEoiC",
      "expanded_url" : "http://vine.co/v/bHlvJeMIO0u",
      "display_url" : "vine.co/v/bHlvJeMIO0u"
    } ]
  },
  "geo" : {
  },
  "id_str" : "309878989227429889",
  "text" : "The peanut butter song http://t.co/bmmrGjEoiC",
  "id" : 309878989227429889,
  "created_at" : "Fri Mar 08 04:11:22 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Haiku Deck",
      "screen_name" : "HaikuDeck",
      "indices" : [ 0, 10 ],
      "id_str" : "352538333",
      "id" : 352538333
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "309769410866999298",
  "geo" : {
  },
  "id_str" : "309773481996849154",
  "in_reply_to_user_id" : 352538333,
  "text" : "@HaikuDeck It's well-deserved love, yo.",
  "id" : 309773481996849154,
  "in_reply_to_status_id" : 309769410866999298,
  "created_at" : "Thu Mar 07 21:12:08 +0000 2013",
  "in_reply_to_screen_name" : "HaikuDeck",
  "in_reply_to_user_id_str" : "352538333",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Haiku Deck",
      "screen_name" : "HaikuDeck",
      "indices" : [ 13, 23 ],
      "id_str" : "352538333",
      "id" : 352538333
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http://t.co/dPZUhZt7Vn",
      "expanded_url" : "http://tcrn.ch/XtnVYG",
      "display_url" : "tcrn.ch/XtnVYG"
    } ]
  },
  "geo" : {
  },
  "id_str" : "309769049489956865",
  "text" : "Stoked about @haikudeck 2.0. I love easy charts and lists. http://t.co/dPZUhZt7Vn",
  "id" : 309769049489956865,
  "created_at" : "Thu Mar 07 20:54:31 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alex choi \u2744",
      "screen_name" : "xc",
      "indices" : [ 0, 3 ],
      "id_str" : "26233",
      "id" : 26233
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "309705272052555777",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596913381, -122.2758807677 ]
  },
  "id_str" : "309706053371715584",
  "in_reply_to_user_id" : 26233,
  "text" : "@xc Equanimity, my fave meditation app because it does almost nothing.",
  "id" : 309706053371715584,
  "in_reply_to_status_id" : 309705272052555777,
  "created_at" : "Thu Mar 07 16:44:11 +0000 2013",
  "in_reply_to_screen_name" : "xc",
  "in_reply_to_user_id_str" : "26233",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/buster/status/309702223196200961/photo/1",
      "indices" : [ 115, 137 ],
      "url" : "http://t.co/tVA3nOd3mp",
      "media_url" : "http://pbs.twimg.com/media/BExIh_hCIAAB8Y4.jpg",
      "id_str" : "309702223204589568",
      "id" : 309702223204589568,
      "media_url_https" : "https://pbs.twimg.com/media/BExIh_hCIAAB8Y4.jpg",
      "sizes" : [ {
        "h" : 577,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 192,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 577,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com/tVA3nOd3mp"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596669902, -122.2754254193 ]
  },
  "id_str" : "309702223196200961",
  "text" : "982. Meditation, for me, is about trying to be notice all the impulses that make me not want to meditate. (7 days) http://t.co/tVA3nOd3mp",
  "id" : 309702223196200961,
  "created_at" : "Thu Mar 07 16:28:58 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tehgeekmeister",
      "screen_name" : "tehgeekmeister",
      "indices" : [ 0, 15 ],
      "id_str" : "6727082",
      "id" : 6727082
    }, {
      "name" : "Kelly McGonigal",
      "screen_name" : "kellymcgonigal",
      "indices" : [ 39, 54 ],
      "id_str" : "38981543",
      "id" : 38981543
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "309556661331324931",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8595474009, -122.2754357296 ]
  },
  "id_str" : "309559844451524608",
  "in_reply_to_user_id" : 6727082,
  "text" : "@tehgeekmeister Willpower Instinct /cc @kellymcgonigal",
  "id" : 309559844451524608,
  "in_reply_to_status_id" : 309556661331324931,
  "created_at" : "Thu Mar 07 07:03:12 +0000 2013",
  "in_reply_to_screen_name" : "tehgeekmeister",
  "in_reply_to_user_id_str" : "6727082",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Garry Tan",
      "screen_name" : "garrytan",
      "indices" : [ 3, 12 ],
      "id_str" : "11768582",
      "id" : 11768582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "309557428905730048",
  "text" : "RT @garrytan: My answer to What are the differences between the hosted blogging products Tumblr, Posthaven, and Svbtle? http://t.co/KapX ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.quora.com/\" rel=\"nofollow\">Quora</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 106, 128 ],
        "url" : "http://t.co/KapX3MRXxj",
        "expanded_url" : "http://qr.ae/TY4Dt",
        "display_url" : "qr.ae/TY4Dt"
      } ]
    },
    "geo" : {
    },
    "id_str" : "309555048239742979",
    "text" : "My answer to What are the differences between the hosted blogging products Tumblr, Posthaven, and Svbtle? http://t.co/KapX3MRXxj",
    "id" : 309555048239742979,
    "created_at" : "Thu Mar 07 06:44:09 +0000 2013",
    "user" : {
      "name" : "Garry Tan",
      "screen_name" : "garrytan",
      "protected" : false,
      "id_str" : "11768582",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2673975033/965a165a093e7c0921b9d69d5d99bc41_normal.jpeg",
      "id" : 11768582,
      "verified" : false
    }
  },
  "id" : 309557428905730048,
  "created_at" : "Thu Mar 07 06:53:37 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin Jo Richey",
      "screen_name" : "erinjo",
      "indices" : [ 0, 7 ],
      "id_str" : "14961286",
      "id" : 14961286
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "309555960412778496",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596378305, -122.2755002205 ]
  },
  "id_str" : "309556373312655361",
  "in_reply_to_user_id" : 14961286,
  "text" : "@erinjo Audible iPhone app. Totally gamified inside with badges and everything. :)",
  "id" : 309556373312655361,
  "in_reply_to_status_id" : 309555960412778496,
  "created_at" : "Thu Mar 07 06:49:25 +0000 2013",
  "in_reply_to_screen_name" : "erinjo",
  "in_reply_to_user_id_str" : "14961286",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kelly McGonigal",
      "screen_name" : "kellymcgonigal",
      "indices" : [ 0, 15 ],
      "id_str" : "38981543",
      "id" : 38981543
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596339729, -122.275363484 ]
  },
  "id_str" : "309556086552276994",
  "in_reply_to_user_id" : 38981543,
  "text" : "@kellymcgonigal Loved your book! Moral licensing and false hope syndrome were some of my fave ideas. Keep it up.",
  "id" : 309556086552276994,
  "created_at" : "Thu Mar 07 06:48:16 +0000 2013",
  "in_reply_to_screen_name" : "kellymcgonigal",
  "in_reply_to_user_id_str" : "38981543",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kelly McGonigal",
      "screen_name" : "kellymcgonigal",
      "indices" : [ 36, 51 ],
      "id_str" : "38981543",
      "id" : 38981543
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/buster/status/309555081567674368/photo/1",
      "indices" : [ 106, 128 ],
      "url" : "http://t.co/MCKMx7AmyF",
      "media_url" : "http://pbs.twimg.com/media/BEvCtOPCIAA7sxK.jpg",
      "id_str" : "309555081576062976",
      "id" : 309555081576062976,
      "media_url_https" : "https://pbs.twimg.com/media/BEvCtOPCIAA7sxK.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 577
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 577
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 603,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 577
      } ],
      "display_url" : "pic.twitter.com/MCKMx7AmyF"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597770459, -122.2757456971 ]
  },
  "id_str" : "309555081567674368",
  "text" : "983. Finished Willpower Instinct by @kellymcgonigal. Def worth reading... not the same old rehashed shit. http://t.co/MCKMx7AmyF",
  "id" : 309555081567674368,
  "created_at" : "Thu Mar 07 06:44:17 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tehgeekmeister",
      "screen_name" : "tehgeekmeister",
      "indices" : [ 0, 15 ],
      "id_str" : "6727082",
      "id" : 6727082
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "309526964811730944",
  "geo" : {
  },
  "id_str" : "309535688330727425",
  "in_reply_to_user_id" : 6727082,
  "text" : "@tehgeekmeister Great recs! Added the 2 I haven't read yet (Wikipedia Revolution, The Ego Tunnel). Thank you!",
  "id" : 309535688330727425,
  "in_reply_to_status_id" : 309526964811730944,
  "created_at" : "Thu Mar 07 05:27:13 +0000 2013",
  "in_reply_to_screen_name" : "tehgeekmeister",
  "in_reply_to_user_id_str" : "6727082",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 57 ],
      "url" : "http://t.co/VP8duUmiA4",
      "expanded_url" : "http://flic.kr/p/e1dyur",
      "display_url" : "flic.kr/p/e1dyur"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859666, -122.275167 ]
  },
  "id_str" : "309527046332231680",
  "text" : "8:36pm Still running this guy down http://t.co/VP8duUmiA4",
  "id" : 309527046332231680,
  "created_at" : "Thu Mar 07 04:52:53 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tehgeekmeister",
      "screen_name" : "tehgeekmeister",
      "indices" : [ 0, 15 ],
      "id_str" : "6727082",
      "id" : 6727082
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "309522942847512576",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8598159195, -122.2750891609 ]
  },
  "id_str" : "309526010074914816",
  "in_reply_to_user_id" : 6727082,
  "text" : "@tehgeekmeister I have! And loved it. More like that!",
  "id" : 309526010074914816,
  "in_reply_to_status_id" : 309522942847512576,
  "created_at" : "Thu Mar 07 04:48:46 +0000 2013",
  "in_reply_to_screen_name" : "tehgeekmeister",
  "in_reply_to_user_id_str" : "6727082",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596685408, -122.2753400077 ]
  },
  "id_str" : "309522536159399937",
  "text" : "On the hunt for my next audiobook. Gender of reader matching gender of writer is an extra plus.",
  "id" : 309522536159399937,
  "created_at" : "Thu Mar 07 04:34:57 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Colbert",
      "screen_name" : "StephenAtHome",
      "indices" : [ 3, 17 ],
      "id_str" : "16303106",
      "id" : 16303106
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "309513317662203904",
  "text" : "RT @StephenAtHome: The record Dow numbers show once again that a rising tide lifts all boats of people who can afford boats.",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.socialoomph.com\" rel=\"nofollow\">SocialOomph</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "309499913425809408",
    "text" : "The record Dow numbers show once again that a rising tide lifts all boats of people who can afford boats.",
    "id" : 309499913425809408,
    "created_at" : "Thu Mar 07 03:05:04 +0000 2013",
    "user" : {
      "name" : "Stephen Colbert",
      "screen_name" : "StephenAtHome",
      "protected" : false,
      "id_str" : "16303106",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3291883997/fae26d278dac0db23cc44e0465f42c4a_normal.png",
      "id" : 16303106,
      "verified" : true
    }
  },
  "id" : 309513317662203904,
  "created_at" : "Thu Mar 07 03:58:20 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8544200445, -122.2711312027 ]
  },
  "id_str" : "309494161202114561",
  "text" : "Don't think about ironic rebound effect.",
  "id" : 309494161202114561,
  "created_at" : "Thu Mar 07 02:42:12 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Colin Henry",
      "screen_name" : "jchenry",
      "indices" : [ 0, 8 ],
      "id_str" : "113988145",
      "id" : 113988145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http://t.co/hSTCjgAzmX",
      "expanded_url" : "http://bit.ly/ZrFIgI",
      "display_url" : "bit.ly/ZrFIgI"
    } ]
  },
  "in_reply_to_status_id_str" : "309464681972649984",
  "geo" : {
  },
  "id_str" : "309465048357683200",
  "in_reply_to_user_id" : 113988145,
  "text" : "@jchenry They've always had premium photo filters, but this sticker store just launched today with 3.0. http://t.co/hSTCjgAzmX",
  "id" : 309465048357683200,
  "in_reply_to_status_id" : 309464681972649984,
  "created_at" : "Thu Mar 07 00:46:31 +0000 2013",
  "in_reply_to_screen_name" : "jchenry",
  "in_reply_to_user_id_str" : "113988145",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "309464436157071360",
  "text" : "New idea: SnapChat with expensive virtual single use stickers.",
  "id" : 309464436157071360,
  "created_at" : "Thu Mar 07 00:44:05 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Path",
      "screen_name" : "path",
      "indices" : [ 41, 46 ],
      "id_str" : "106333951",
      "id" : 106333951
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "really",
      "indices" : [ 63, 70 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "309463092058804224",
  "text" : "I just paid $2 for red panda stickers on @path. Who wants one? #really?",
  "id" : 309463092058804224,
  "created_at" : "Thu Mar 07 00:38:45 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Wright",
      "screen_name" : "webwright",
      "indices" : [ 3, 13 ],
      "id_str" : "786818",
      "id" : 786818
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http://t.co/LLtiVTopOl",
      "expanded_url" : "http://www.seomoz.org/blog/announcing-fresh-web-explorer",
      "display_url" : "seomoz.org/blog/announcin\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "309374401974005760",
  "text" : "RT @webwright: How many times have I wished for a decent Google Alerts alternative...  Moz built it! http://t.co/LLtiVTopOl",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 86, 108 ],
        "url" : "http://t.co/LLtiVTopOl",
        "expanded_url" : "http://www.seomoz.org/blog/announcing-fresh-web-explorer",
        "display_url" : "seomoz.org/blog/announcin\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "309371675064025088",
    "text" : "How many times have I wished for a decent Google Alerts alternative...  Moz built it! http://t.co/LLtiVTopOl",
    "id" : 309371675064025088,
    "created_at" : "Wed Mar 06 18:35:29 +0000 2013",
    "user" : {
      "name" : "Tony Wright",
      "screen_name" : "webwright",
      "protected" : false,
      "id_str" : "786818",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000106343055/1d532c4e1ba53b3d5acc4568b21f2df1_normal.jpeg",
      "id" : 786818,
      "verified" : false
    }
  },
  "id" : 309374401974005760,
  "created_at" : "Wed Mar 06 18:46:19 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Bodge",
      "screen_name" : "mikebodge",
      "indices" : [ 3, 13 ],
      "id_str" : "19344531",
      "id" : 19344531
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 57 ],
      "url" : "http://t.co/AmB1IJyWXs",
      "expanded_url" : "http://p4no.com",
      "display_url" : "p4no.com"
    } ]
  },
  "geo" : {
  },
  "id_str" : "309373586630643712",
  "text" : "RT @mikebodge: Oh, I just launched http://t.co/AmB1IJyWXs \u2026an easy way to post and share panorama photos. Try it and give me feedback!",
  "retweeted_status" : {
    "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 20, 42 ],
        "url" : "http://t.co/AmB1IJyWXs",
        "expanded_url" : "http://p4no.com",
        "display_url" : "p4no.com"
      } ]
    },
    "geo" : {
    },
    "id_str" : "309370907024052226",
    "text" : "Oh, I just launched http://t.co/AmB1IJyWXs \u2026an easy way to post and share panorama photos. Try it and give me feedback!",
    "id" : 309370907024052226,
    "created_at" : "Wed Mar 06 18:32:26 +0000 2013",
    "user" : {
      "name" : "Mike Bodge",
      "screen_name" : "mikebodge",
      "protected" : false,
      "id_str" : "19344531",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/81797804/n722045008_725817_1816_normal.jpg",
      "id" : 19344531,
      "verified" : false
    }
  },
  "id" : 309373586630643712,
  "created_at" : "Wed Mar 06 18:43:05 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Bodge",
      "screen_name" : "mikebodge",
      "indices" : [ 0, 10 ],
      "id_str" : "19344531",
      "id" : 19344531
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "309371845449228288",
  "geo" : {
  },
  "id_str" : "309372156553330688",
  "in_reply_to_user_id" : 19344531,
  "text" : "@mikebodge Cool site! I currently use Tumblr for panoramas but it's definitely not ideal. It took me a bit to figure the drag thing.",
  "id" : 309372156553330688,
  "in_reply_to_status_id" : 309371845449228288,
  "created_at" : "Wed Mar 06 18:37:24 +0000 2013",
  "in_reply_to_screen_name" : "mikebodge",
  "in_reply_to_user_id_str" : "19344531",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YourUsername",
      "screen_name" : "YourUsername",
      "indices" : [ 84, 97 ],
      "id_str" : "14200205",
      "id" : 14200205
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "309355703368290304",
  "text" : "New Idea: ability to delete each other's tweets, but a placeholder with [deleted by @yourusername] remains in its place.",
  "id" : 309355703368290304,
  "created_at" : "Wed Mar 06 17:32:01 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sara Mauskopf",
      "screen_name" : "sm",
      "indices" : [ 0, 3 ],
      "id_str" : "22273667",
      "id" : 22273667
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/buster/status/309333197366362112/photo/1",
      "indices" : [ 4, 26 ],
      "url" : "http://t.co/hU1274kA6I",
      "media_url" : "http://pbs.twimg.com/media/BEr453KCAAEI1UQ.jpg",
      "id_str" : "309333197370556417",
      "id" : 309333197370556417,
      "media_url_https" : "https://pbs.twimg.com/media/BEr453KCAAEI1UQ.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com/hU1274kA6I"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "309327609630699520",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8598346282, -122.2754975037 ]
  },
  "id_str" : "309333197366362112",
  "in_reply_to_user_id" : 22273667,
  "text" : "@sm http://t.co/hU1274kA6I",
  "id" : 309333197366362112,
  "in_reply_to_status_id" : 309327609630699520,
  "created_at" : "Wed Mar 06 16:02:36 +0000 2013",
  "in_reply_to_screen_name" : "sm",
  "in_reply_to_user_id_str" : "22273667",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah L Martinez",
      "screen_name" : "SarahLMartinez1",
      "indices" : [ 3, 19 ],
      "id_str" : "505216005",
      "id" : 505216005
    }, {
      "name" : "Vivek Wadhwa",
      "screen_name" : "wadhwa",
      "indices" : [ 107, 114 ],
      "id_str" : "32718488",
      "id" : 32718488
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http://t.co/SS1USWInx7",
      "expanded_url" : "http://www.linkedin.com/today/post/article/20130305180236-8451-our-future-will-be-brighter-than-you-think-but-more-disruptive",
      "display_url" : "linkedin.com/today/post/art\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "309331462744862721",
  "text" : "RT @SarahLMartinez1: A vision of a bright future in a world of limited resources. Think it's possible? Thx @wadhwa   http://t.co/SS1USWInx7",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Vivek Wadhwa",
        "screen_name" : "wadhwa",
        "indices" : [ 86, 93 ],
        "id_str" : "32718488",
        "id" : 32718488
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 96, 118 ],
        "url" : "http://t.co/SS1USWInx7",
        "expanded_url" : "http://www.linkedin.com/today/post/article/20130305180236-8451-our-future-will-be-brighter-than-you-think-but-more-disruptive",
        "display_url" : "linkedin.com/today/post/art\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "309288857759776770",
    "text" : "A vision of a bright future in a world of limited resources. Think it's possible? Thx @wadhwa   http://t.co/SS1USWInx7",
    "id" : 309288857759776770,
    "created_at" : "Wed Mar 06 13:06:24 +0000 2013",
    "user" : {
      "name" : "Sarah L Martinez",
      "screen_name" : "SarahLMartinez1",
      "protected" : false,
      "id_str" : "505216005",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2798023284/c1d1f67a70e92a66ce2acf02568a3d51_normal.jpeg",
      "id" : 505216005,
      "verified" : false
    }
  },
  "id" : 309331462744862721,
  "created_at" : "Wed Mar 06 15:55:42 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Seitz",
      "screen_name" : "BillSeitz",
      "indices" : [ 0, 10 ],
      "id_str" : "1239971",
      "id" : 1239971
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "309270975978024960",
  "geo" : {
  },
  "id_str" : "309326591463391234",
  "in_reply_to_user_id" : 1239971,
  "text" : "@BillSeitz Interesting. Hadn't heard of that before. Is it really a thing or just a cool idea?",
  "id" : 309326591463391234,
  "in_reply_to_status_id" : 309270975978024960,
  "created_at" : "Wed Mar 06 15:36:21 +0000 2013",
  "in_reply_to_screen_name" : "BillSeitz",
  "in_reply_to_user_id_str" : "1239971",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http://t.co/4gkXgw92QV",
      "expanded_url" : "http://bit.ly/Ywgcrx",
      "display_url" : "bit.ly/Ywgcrx"
    } ]
  },
  "geo" : {
  },
  "id_str" : "309191257220063233",
  "text" : "\"The Game of Life (now with more levels!)\" - Way of the Duck http://t.co/4gkXgw92QV",
  "id" : 309191257220063233,
  "created_at" : "Wed Mar 06 06:38:34 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Davidson",
      "screen_name" : "mikeindustries",
      "indices" : [ 0, 15 ],
      "id_str" : "74523",
      "id" : 74523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "309173293460639746",
  "in_reply_to_user_id" : 74523,
  "text" : "@mikeindustries \"G\u00F6del's Proof\" is also a great short read and more entertaining than G\u00F6del's actual \"On Formally Undecidable Propositions.\"",
  "id" : 309173293460639746,
  "created_at" : "Wed Mar 06 05:27:11 +0000 2013",
  "in_reply_to_screen_name" : "mikeindustries",
  "in_reply_to_user_id_str" : "74523",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Davidson",
      "screen_name" : "mikeindustries",
      "indices" : [ 0, 15 ],
      "id_str" : "74523",
      "id" : 74523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "309171439070769152",
  "geo" : {
  },
  "id_str" : "309171977795559425",
  "in_reply_to_user_id" : 74523,
  "text" : "@mikeindustries I highly recommend The Duty of Genius, a biography of Wittgenstein, my fave philosopher. And then diving in deeper.",
  "id" : 309171977795559425,
  "in_reply_to_status_id" : 309171439070769152,
  "created_at" : "Wed Mar 06 05:21:58 +0000 2013",
  "in_reply_to_screen_name" : "mikeindustries",
  "in_reply_to_user_id_str" : "74523",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Davidson",
      "screen_name" : "mikeindustries",
      "indices" : [ 0, 15 ],
      "id_str" : "74523",
      "id" : 74523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "309170084881002496",
  "geo" : {
  },
  "id_str" : "309171219918364672",
  "in_reply_to_user_id" : 74523,
  "text" : "@mikeindustries Do you mean classic philosophy or something simply philosophical nonfiction?",
  "id" : 309171219918364672,
  "in_reply_to_status_id" : 309170084881002496,
  "created_at" : "Wed Mar 06 05:18:57 +0000 2013",
  "in_reply_to_screen_name" : "mikeindustries",
  "in_reply_to_user_id_str" : "74523",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niko Benson",
      "screen_name" : "nikobenson",
      "indices" : [ 21, 32 ],
      "id_str" : "142467448",
      "id" : 142467448
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http://t.co/D2xcaNpOEi",
      "expanded_url" : "http://flic.kr/p/dZYTj6",
      "display_url" : "flic.kr/p/dZYTj6"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859666, -122.2755 ]
  },
  "id_str" : "309168125847404545",
  "text" : "8:36pm Need to start @nikobenson's own 8:36pm account http://t.co/D2xcaNpOEi",
  "id" : 309168125847404545,
  "created_at" : "Wed Mar 06 05:06:39 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John W. Solomon",
      "screen_name" : "JohnWrede",
      "indices" : [ 0, 10 ],
      "id_str" : "125733",
      "id" : 125733
    }, {
      "name" : "Andrew J. Rosenthal",
      "screen_name" : "rosenthal",
      "indices" : [ 11, 21 ],
      "id_str" : "15792969",
      "id" : 15792969
    }, {
      "name" : "Jane McGonigal",
      "screen_name" : "avantgame",
      "indices" : [ 22, 32 ],
      "id_str" : "681813",
      "id" : 681813
    }, {
      "name" : "Chris Hogg",
      "screen_name" : "cwhogg",
      "indices" : [ 33, 40 ],
      "id_str" : "15727738",
      "id" : 15727738
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "309158687975563265",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597623762, -122.2755415087 ]
  },
  "id_str" : "309165997498191872",
  "in_reply_to_user_id" : 125733,
  "text" : "@JohnWrede @rosenthal @avantgame @cwhogg In!",
  "id" : 309165997498191872,
  "in_reply_to_status_id" : 309158687975563265,
  "created_at" : "Wed Mar 06 04:58:12 +0000 2013",
  "in_reply_to_screen_name" : "JohnWrede",
  "in_reply_to_user_id_str" : "125733",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jane McGonigal",
      "screen_name" : "avantgame",
      "indices" : [ 0, 10 ],
      "id_str" : "681813",
      "id" : 681813
    }, {
      "name" : "John W. Solomon",
      "screen_name" : "JohnWrede",
      "indices" : [ 11, 21 ],
      "id_str" : "125733",
      "id" : 125733
    }, {
      "name" : "Andrew J. Rosenthal",
      "screen_name" : "rosenthal",
      "indices" : [ 22, 32 ],
      "id_str" : "15792969",
      "id" : 15792969
    }, {
      "name" : "Chris Hogg",
      "screen_name" : "cwhogg",
      "indices" : [ 33, 40 ],
      "id_str" : "15727738",
      "id" : 15727738
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "309157274172153857",
  "geo" : {
  },
  "id_str" : "309157616251191297",
  "in_reply_to_user_id" : 681813,
  "text" : "@avantgame @JohnWrede @rosenthal @cwhogg Looks like we should work around your schedule then, if you're up for it. Name a date!",
  "id" : 309157616251191297,
  "in_reply_to_status_id" : 309157274172153857,
  "created_at" : "Wed Mar 06 04:24:54 +0000 2013",
  "in_reply_to_screen_name" : "avantgame",
  "in_reply_to_user_id_str" : "681813",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John W. Solomon",
      "screen_name" : "JohnWrede",
      "indices" : [ 0, 10 ],
      "id_str" : "125733",
      "id" : 125733
    }, {
      "name" : "Jane McGonigal",
      "screen_name" : "avantgame",
      "indices" : [ 11, 21 ],
      "id_str" : "681813",
      "id" : 681813
    }, {
      "name" : "Andrew J. Rosenthal",
      "screen_name" : "rosenthal",
      "indices" : [ 22, 32 ],
      "id_str" : "15792969",
      "id" : 15792969
    }, {
      "name" : "Chris Hogg",
      "screen_name" : "cwhogg",
      "indices" : [ 33, 40 ],
      "id_str" : "15727738",
      "id" : 15727738
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "309145926147112960",
  "geo" : {
  },
  "id_str" : "309156799762804736",
  "in_reply_to_user_id" : 125733,
  "text" : "@JohnWrede @avantgame @rosenthal @cwhogg I'm free most nights except Tuesday, and need about a week notice. Jane are you back in SF?",
  "id" : 309156799762804736,
  "in_reply_to_status_id" : 309145926147112960,
  "created_at" : "Wed Mar 06 04:21:39 +0000 2013",
  "in_reply_to_screen_name" : "JohnWrede",
  "in_reply_to_user_id_str" : "125733",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John W. Solomon",
      "screen_name" : "JohnWrede",
      "indices" : [ 0, 10 ],
      "id_str" : "125733",
      "id" : 125733
    }, {
      "name" : "Jane McGonigal",
      "screen_name" : "avantgame",
      "indices" : [ 11, 21 ],
      "id_str" : "681813",
      "id" : 681813
    }, {
      "name" : "Andrew J. Rosenthal",
      "screen_name" : "rosenthal",
      "indices" : [ 22, 32 ],
      "id_str" : "15792969",
      "id" : 15792969
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "309144691880890368",
  "geo" : {
  },
  "id_str" : "309145133432053761",
  "in_reply_to_user_id" : 125733,
  "text" : "@JohnWrede @avantgame @rosenthal I'm only jaded because I care. :) In all honesty, I have a couple ideas I'm thinking through that I like.",
  "id" : 309145133432053761,
  "in_reply_to_status_id" : 309144691880890368,
  "created_at" : "Wed Mar 06 03:35:18 +0000 2013",
  "in_reply_to_screen_name" : "JohnWrede",
  "in_reply_to_user_id_str" : "125733",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jane McGonigal",
      "screen_name" : "avantgame",
      "indices" : [ 0, 10 ],
      "id_str" : "681813",
      "id" : 681813
    }, {
      "name" : "John W. Solomon",
      "screen_name" : "JohnWrede",
      "indices" : [ 11, 21 ],
      "id_str" : "125733",
      "id" : 125733
    }, {
      "name" : "Andrew J. Rosenthal",
      "screen_name" : "rosenthal",
      "indices" : [ 22, 32 ],
      "id_str" : "15792969",
      "id" : 15792969
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "309140195519889408",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597079, -122.2756574297 ]
  },
  "id_str" : "309141158477561857",
  "in_reply_to_user_id" : 681813,
  "text" : "@avantgame @johnwrede @rosenthal Love it! We can call it \"Yeah, That's Not Gonna Work, Sorry!\"",
  "id" : 309141158477561857,
  "in_reply_to_status_id" : 309140195519889408,
  "created_at" : "Wed Mar 06 03:19:30 +0000 2013",
  "in_reply_to_screen_name" : "avantgame",
  "in_reply_to_user_id_str" : "681813",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John W. Solomon",
      "screen_name" : "JohnWrede",
      "indices" : [ 0, 10 ],
      "id_str" : "125733",
      "id" : 125733
    }, {
      "name" : "Andrew J. Rosenthal",
      "screen_name" : "rosenthal",
      "indices" : [ 11, 21 ],
      "id_str" : "15792969",
      "id" : 15792969
    }, {
      "name" : "Jane McGonigal",
      "screen_name" : "avantgame",
      "indices" : [ 22, 32 ],
      "id_str" : "681813",
      "id" : 681813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "309135212577701888",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596285466, -122.2754418379 ]
  },
  "id_str" : "309137980080132096",
  "in_reply_to_user_id" : 125733,
  "text" : "@JohnWrede @rosenthal @avantgame Count me in on this hypothetical SF jam in the near future.",
  "id" : 309137980080132096,
  "in_reply_to_status_id" : 309135212577701888,
  "created_at" : "Wed Mar 06 03:06:52 +0000 2013",
  "in_reply_to_screen_name" : "JohnWrede",
  "in_reply_to_user_id_str" : "125733",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jane McGonigal",
      "screen_name" : "avantgame",
      "indices" : [ 0, 10 ],
      "id_str" : "681813",
      "id" : 681813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "309129066412384256",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8595412855, -122.275073544 ]
  },
  "id_str" : "309136650548703232",
  "in_reply_to_user_id" : 681813,
  "text" : "@avantgame Yes.",
  "id" : 309136650548703232,
  "in_reply_to_status_id" : 309129066412384256,
  "created_at" : "Wed Mar 06 03:01:35 +0000 2013",
  "in_reply_to_screen_name" : "avantgame",
  "in_reply_to_user_id_str" : "681813",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sara Mauskopf",
      "screen_name" : "sm",
      "indices" : [ 0, 3 ],
      "id_str" : "22273667",
      "id" : 22273667
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "smurfpajamas",
      "indices" : [ 4, 17 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "309098720316755968",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8595817881, -122.2754356452 ]
  },
  "id_str" : "309099027553726465",
  "in_reply_to_user_id" : 22273667,
  "text" : "@sm #smurfpajamas",
  "id" : 309099027553726465,
  "in_reply_to_status_id" : 309098720316755968,
  "created_at" : "Wed Mar 06 00:32:05 +0000 2013",
  "in_reply_to_screen_name" : "sm",
  "in_reply_to_user_id_str" : "22273667",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sharon",
      "screen_name" : "sharon",
      "indices" : [ 0, 7 ],
      "id_str" : "260",
      "id" : 260
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "309097360087191552",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8595519993, -122.2751851949 ]
  },
  "id_str" : "309098872716800000",
  "in_reply_to_user_id" : 260,
  "text" : "@sharon \"nothing gold can stay\"",
  "id" : 309098872716800000,
  "in_reply_to_status_id" : 309097360087191552,
  "created_at" : "Wed Mar 06 00:31:28 +0000 2013",
  "in_reply_to_screen_name" : "sharon",
  "in_reply_to_user_id_str" : "260",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Reichhold",
      "screen_name" : "jreichhold",
      "indices" : [ 0, 11 ],
      "id_str" : "14934401",
      "id" : 14934401
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "309097238234271744",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596419978, -122.2755472544 ]
  },
  "id_str" : "309097932005715968",
  "in_reply_to_user_id" : 14934401,
  "text" : "@jreichhold That will pass too.",
  "id" : 309097932005715968,
  "in_reply_to_status_id" : 309097238234271744,
  "created_at" : "Wed Mar 06 00:27:44 +0000 2013",
  "in_reply_to_screen_name" : "jreichhold",
  "in_reply_to_user_id_str" : "14934401",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596284999, -122.2752579435 ]
  },
  "id_str" : "309096760394002432",
  "text" : "When you feel unwell, remember that it will pass. And when you feel well, remember that that will pass too.",
  "id" : 309096760394002432,
  "created_at" : "Wed Mar 06 00:23:05 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://bufferapp.com\" rel=\"nofollow\">Buffer</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http://t.co/vGqf7H50N8",
      "expanded_url" : "http://bit.ly/12rGv7o",
      "display_url" : "bit.ly/12rGv7o"
    } ]
  },
  "geo" : {
  },
  "id_str" : "309018082997837824",
  "text" : "Easy to understand article (and interesting story) about how Google and Twitter are improving data centers http://t.co/vGqf7H50N8",
  "id" : 309018082997837824,
  "created_at" : "Tue Mar 05 19:10:26 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ingopixel",
      "screen_name" : "ingopixel",
      "indices" : [ 0, 10 ],
      "id_str" : "7943892",
      "id" : 7943892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "308813285782851585",
  "geo" : {
  },
  "id_str" : "308851652671205376",
  "in_reply_to_user_id" : 7943892,
  "text" : "@ingopixel \"And that's where little babies come from. THE END.\"",
  "id" : 308851652671205376,
  "in_reply_to_status_id" : 308813285782851585,
  "created_at" : "Tue Mar 05 08:09:06 +0000 2013",
  "in_reply_to_screen_name" : "ingopixel",
  "in_reply_to_user_id_str" : "7943892",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Seth Bindernagel",
      "screen_name" : "binder",
      "indices" : [ 89, 96 ],
      "id_str" : "1249881",
      "id" : 1249881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http://t.co/95cPMVgM2R",
      "expanded_url" : "http://m.youtube.com/#/watch?v=zAIPL5O9Uwk&desktop_uri=%2Fwatch%3Fv%3DzAIPL5O9Uwk",
      "display_url" : "m.youtube.com/#/watch?v=zAIP\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596510279, -122.2753055863 ]
  },
  "id_str" : "308814833686560769",
  "text" : "Holy moley. This guy solves a Rubik's Cube while juggling it http://t.co/95cPMVgM2R /via @binder",
  "id" : 308814833686560769,
  "created_at" : "Tue Mar 05 05:42:48 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 59 ],
      "url" : "http://t.co/SKnFTwAIFi",
      "expanded_url" : "http://flic.kr/p/dZHEEi",
      "display_url" : "flic.kr/p/dZHEEi"
    } ]
  },
  "geo" : {
  },
  "id_str" : "308799543699451907",
  "text" : "8:36pm Being entertained by this guy http://t.co/SKnFTwAIFi",
  "id" : 308799543699451907,
  "created_at" : "Tue Mar 05 04:42:03 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Stamatiou",
      "screen_name" : "Stammy",
      "indices" : [ 0, 7 ],
      "id_str" : "624683",
      "id" : 624683
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "308780626985771009",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8598330974, -122.2757653155 ]
  },
  "id_str" : "308781111314616321",
  "in_reply_to_user_id" : 624683,
  "text" : "@Stammy What's your gym?",
  "id" : 308781111314616321,
  "in_reply_to_status_id" : 308780626985771009,
  "created_at" : "Tue Mar 05 03:28:48 +0000 2013",
  "in_reply_to_screen_name" : "Stammy",
  "in_reply_to_user_id_str" : "624683",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Clayton Cubitt",
      "screen_name" : "claytoncubitt",
      "indices" : [ 0, 14 ],
      "id_str" : "15875898",
      "id" : 15875898
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "308730333170388992",
  "geo" : {
  },
  "id_str" : "308738116456427520",
  "in_reply_to_user_id" : 15875898,
  "text" : "@claytoncubitt I'm but a lowly peon, but I'll pass the word on. :)",
  "id" : 308738116456427520,
  "in_reply_to_status_id" : 308730333170388992,
  "created_at" : "Tue Mar 05 00:37:57 +0000 2013",
  "in_reply_to_screen_name" : "claytoncubitt",
  "in_reply_to_user_id_str" : "15875898",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Clayton Cubitt",
      "screen_name" : "claytoncubitt",
      "indices" : [ 0, 14 ],
      "id_str" : "15875898",
      "id" : 15875898
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "308728579015966721",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7769944716, -122.4171123512 ]
  },
  "id_str" : "308728840711204864",
  "in_reply_to_user_id" : 15875898,
  "text" : "@claytoncubitt Ah, forgot about the AIR one...",
  "id" : 308728840711204864,
  "in_reply_to_status_id" : 308728579015966721,
  "created_at" : "Tue Mar 05 00:01:06 +0000 2013",
  "in_reply_to_screen_name" : "claytoncubitt",
  "in_reply_to_user_id_str" : "15875898",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Clayton Cubitt",
      "screen_name" : "claytoncubitt",
      "indices" : [ 0, 14 ],
      "id_str" : "15875898",
      "id" : 15875898
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "308727235249049602",
  "geo" : {
  },
  "id_str" : "308727943985778689",
  "in_reply_to_user_id" : 15875898,
  "text" : "@claytoncubitt It's not being abandoned as a Mac app -- just the iPhone and Android versions.",
  "id" : 308727943985778689,
  "in_reply_to_status_id" : 308727235249049602,
  "created_at" : "Mon Mar 04 23:57:32 +0000 2013",
  "in_reply_to_screen_name" : "claytoncubitt",
  "in_reply_to_user_id_str" : "15875898",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Isaac Hepworth",
      "screen_name" : "isaach",
      "indices" : [ 0, 7 ],
      "id_str" : "7852612",
      "id" : 7852612
    }, {
      "name" : "Elaine Filadelfo",
      "screen_name" : "urchkin",
      "indices" : [ 8, 16 ],
      "id_str" : "14129316",
      "id" : 14129316
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "308711145106194432",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7769357619, -122.4172182403 ]
  },
  "id_str" : "308715668541407232",
  "in_reply_to_user_id" : 7852612,
  "text" : "@isaach @urchkin Don't forget 6 do you/dost thou.",
  "id" : 308715668541407232,
  "in_reply_to_status_id" : 308711145106194432,
  "created_at" : "Mon Mar 04 23:08:45 +0000 2013",
  "in_reply_to_screen_name" : "isaach",
  "in_reply_to_user_id_str" : "7852612",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/buster/status/308713680823013377/photo/1",
      "indices" : [ 82, 104 ],
      "url" : "http://t.co/XKZnMOmWRN",
      "media_url" : "http://pbs.twimg.com/media/BEjFdQNCUAAbOlk.jpg",
      "id_str" : "308713680831401984",
      "id" : 308713680831401984,
      "media_url_https" : "https://pbs.twimg.com/media/BEjFdQNCUAAbOlk.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 577
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 577
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 603,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 577
      } ],
      "display_url" : "pic.twitter.com/XKZnMOmWRN"
    } ],
    "hashtags" : [ {
      "text" : "eatery",
      "indices" : [ 44, 51 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.776923966, -122.4172220641 ]
  },
  "id_str" : "308713680823013377",
  "text" : "984. Ate 69% healthy last week according to #eatery. Hope to beat that this week. http://t.co/XKZnMOmWRN",
  "id" : 308713680823013377,
  "created_at" : "Mon Mar 04 23:00:52 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Libby Brittain",
      "screen_name" : "libbybrittain",
      "indices" : [ 0, 14 ],
      "id_str" : "18749271",
      "id" : 18749271
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "308675861375225858",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7762202698, -122.4174224334 ]
  },
  "id_str" : "308676729176719360",
  "in_reply_to_user_id" : 18749271,
  "text" : "@libbybrittain We are the arbiter of the algorithm's relevance to us. :)",
  "id" : 308676729176719360,
  "in_reply_to_status_id" : 308675861375225858,
  "created_at" : "Mon Mar 04 20:34:01 +0000 2013",
  "in_reply_to_screen_name" : "libbybrittain",
  "in_reply_to_user_id_str" : "18749271",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Libby Brittain",
      "screen_name" : "libbybrittain",
      "indices" : [ 0, 14 ],
      "id_str" : "18749271",
      "id" : 18749271
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "308672993922535424",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7762547623, -122.4174243731 ]
  },
  "id_str" : "308675087157047296",
  "in_reply_to_user_id" : 18749271,
  "text" : "@libbybrittain Personally I'm still okay with it. But my impression of the \"issue\" was that the algorithm might impair relevance on purpose.",
  "id" : 308675087157047296,
  "in_reply_to_status_id" : 308672993922535424,
  "created_at" : "Mon Mar 04 20:27:30 +0000 2013",
  "in_reply_to_screen_name" : "libbybrittain",
  "in_reply_to_user_id_str" : "18749271",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Libby Brittain",
      "screen_name" : "libbybrittain",
      "indices" : [ 0, 14 ],
      "id_str" : "18749271",
      "id" : 18749271
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "308636724207157248",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7765027163, -122.4167284814 ]
  },
  "id_str" : "308671675027816448",
  "in_reply_to_user_id" : 18749271,
  "text" : "@libbybrittain I think it's about the inherent conflict of interest in the algorithm itself. Is it optimizing for relevance or $?",
  "id" : 308671675027816448,
  "in_reply_to_status_id" : 308636724207157248,
  "created_at" : "Mon Mar 04 20:13:56 +0000 2013",
  "in_reply_to_screen_name" : "libbybrittain",
  "in_reply_to_user_id_str" : "18749271",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricky Gervais",
      "screen_name" : "rickygervais",
      "indices" : [ 3, 16 ],
      "id_str" : "20015311",
      "id" : 20015311
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "308670572269817856",
  "text" : "RT @rickygervais: Over 100% of Internet facts are logically impossible.",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "308670332888285185",
    "text" : "Over 100% of Internet facts are logically impossible.",
    "id" : 308670332888285185,
    "created_at" : "Mon Mar 04 20:08:36 +0000 2013",
    "user" : {
      "name" : "Ricky Gervais",
      "screen_name" : "rickygervais",
      "protected" : false,
      "id_str" : "20015311",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3035009585/93fdaf003d2b213dd6c4d6cae860e76e_normal.jpeg",
      "id" : 20015311,
      "verified" : true
    }
  },
  "id" : 308670572269817856,
  "created_at" : "Mon Mar 04 20:09:33 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Couch",
      "screen_name" : "couch",
      "indices" : [ 0, 6 ],
      "id_str" : "631823",
      "id" : 631823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "308573395107344384",
  "geo" : {
  },
  "id_str" : "308634521526480897",
  "in_reply_to_user_id" : 631823,
  "text" : "@couch I agree. The truly lucky are those who've had opportunities to work really hard and become masters at something.",
  "id" : 308634521526480897,
  "in_reply_to_status_id" : 308573395107344384,
  "created_at" : "Mon Mar 04 17:46:18 +0000 2013",
  "in_reply_to_screen_name" : "couch",
  "in_reply_to_user_id_str" : "631823",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Jacobs",
      "screen_name" : "djacobs",
      "indices" : [ 0, 8 ],
      "id_str" : "774842",
      "id" : 774842
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "308609510002544641",
  "geo" : {
  },
  "id_str" : "308613906027405312",
  "in_reply_to_user_id" : 774842,
  "text" : "@djacobs Not sure if that's what you were asking.",
  "id" : 308613906027405312,
  "in_reply_to_status_id" : 308609510002544641,
  "created_at" : "Mon Mar 04 16:24:23 +0000 2013",
  "in_reply_to_screen_name" : "djacobs",
  "in_reply_to_user_id_str" : "774842",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Jacobs",
      "screen_name" : "djacobs",
      "indices" : [ 0, 8 ],
      "id_str" : "774842",
      "id" : 774842
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http://t.co/mRK6IA6nQE",
      "expanded_url" : "http://bit.ly/14kPEdo",
      "display_url" : "bit.ly/14kPEdo"
    } ]
  },
  "in_reply_to_status_id_str" : "308609510002544641",
  "geo" : {
  },
  "id_str" : "308613656197865472",
  "in_reply_to_user_id" : 774842,
  "text" : "@djacobs That page redirects to the app store, so it won't be possible to have cards unless you change markup on http://t.co/mRK6IA6nQE.",
  "id" : 308613656197865472,
  "in_reply_to_status_id" : 308609510002544641,
  "created_at" : "Mon Mar 04 16:23:24 +0000 2013",
  "in_reply_to_screen_name" : "djacobs",
  "in_reply_to_user_id_str" : "774842",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 54 ],
      "url" : "http://t.co/UXqua1lk84",
      "expanded_url" : "http://bit.ly/102jGpB",
      "display_url" : "bit.ly/102jGpB"
    } ]
  },
  "geo" : {
  },
  "id_str" : "308473675034816512",
  "text" : "\"My 2 brains\" - Way of the Duck http://t.co/UXqua1lk84",
  "id" : 308473675034816512,
  "created_at" : "Mon Mar 04 07:07:09 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carinna Tarvin",
      "screen_name" : "carinnatarvin",
      "indices" : [ 0, 14 ],
      "id_str" : "20833838",
      "id" : 20833838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "308461453109776384",
  "geo" : {
  },
  "id_str" : "308461744068624384",
  "in_reply_to_user_id" : 20833838,
  "text" : "@carinnatarvin It's so awesome to think about. Perfect for the high school (and 20-years post-high school) mind.",
  "id" : 308461744068624384,
  "in_reply_to_status_id" : 308461453109776384,
  "created_at" : "Mon Mar 04 06:19:45 +0000 2013",
  "in_reply_to_screen_name" : "carinnatarvin",
  "in_reply_to_user_id_str" : "20833838",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Ashton",
      "screen_name" : "Kevin_Ashton",
      "indices" : [ 103, 116 ],
      "id_str" : "6220862",
      "id" : 6220862
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https://t.co/gXSfRgbWzW",
      "expanded_url" : "https://medium.com/the-ingredients-2/221d449929ef",
      "display_url" : "medium.com/the-ingredient\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "308460177663868928",
  "text" : "In case you haven't read this yet (I just read it again because it's awesome). \"What Coke Contains\" by @Kevin_Ashton https://t.co/gXSfRgbWzW",
  "id" : 308460177663868928,
  "created_at" : "Mon Mar 04 06:13:31 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "308445088420335616",
  "text" : "The best opportunities aren't short cuts to easy payouts, they're the opportunities to work really hard on something you find meaningful.",
  "id" : 308445088420335616,
  "created_at" : "Mon Mar 04 05:13:34 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Troy Davis",
      "screen_name" : "troyd",
      "indices" : [ 0, 6 ],
      "id_str" : "14701738",
      "id" : 14701738
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "308234486708043778",
  "geo" : {
  },
  "id_str" : "308443236547047425",
  "in_reply_to_user_id" : 14701738,
  "text" : "@troyd That would be awesome if someone did that. :)",
  "id" : 308443236547047425,
  "in_reply_to_status_id" : 308234486708043778,
  "created_at" : "Mon Mar 04 05:06:12 +0000 2013",
  "in_reply_to_screen_name" : "troyd",
  "in_reply_to_user_id_str" : "14701738",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "308442636996452352",
  "text" : "To slog successfully toward goals, habits, or a better life: Go slow. Work hard. Avoid shortcuts. Remember to remember. Be kind to yourself.",
  "id" : 308442636996452352,
  "created_at" : "Mon Mar 04 05:03:49 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http://t.co/80K9pJyzxW",
      "expanded_url" : "http://flic.kr/p/dZri14",
      "display_url" : "flic.kr/p/dZri14"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859666, -122.275667 ]
  },
  "id_str" : "308440406004219904",
  "text" : "8:36pm Day 3 of dietary change has my brain screaming \"Wine! Cheese! Chocolate!\" Hope tea will suffice. http://t.co/80K9pJyzxW",
  "id" : 308440406004219904,
  "created_at" : "Mon Mar 04 04:54:57 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Guarraci",
      "screen_name" : "eismcc",
      "indices" : [ 0, 7 ],
      "id_str" : "13257392",
      "id" : 13257392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "308389019824300032",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596566993, -122.2757594059 ]
  },
  "id_str" : "308389164435525632",
  "in_reply_to_user_id" : 13257392,
  "text" : "@eismcc or rather hive-programming.",
  "id" : 308389164435525632,
  "in_reply_to_status_id" : 308389019824300032,
  "created_at" : "Mon Mar 04 01:31:21 +0000 2013",
  "in_reply_to_screen_name" : "eismcc",
  "in_reply_to_user_id_str" : "13257392",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http://t.co/TSsstDldMv",
      "expanded_url" : "http://www.guardian.co.uk/science/neurophilosophy/2013/feb/28/brain-to-brain-interface",
      "display_url" : "guardian.co.uk/science/neurop\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596455239, -122.2753032937 ]
  },
  "id_str" : "308387766469808128",
  "text" : "Rat A has brain connected to Rat B's brain and can learn what Rat B learns. And the article gets crazier at the end. http://t.co/TSsstDldMv",
  "id" : 308387766469808128,
  "created_at" : "Mon Mar 04 01:25:47 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TechCrunch",
      "screen_name" : "TechCrunch",
      "indices" : [ 3, 14 ],
      "id_str" : "816653",
      "id" : 816653
    }, {
      "name" : "Michael Arrington",
      "screen_name" : "arrington",
      "indices" : [ 83, 93 ],
      "id_str" : "37570179",
      "id" : 37570179
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 79 ],
      "url" : "http://t.co/6ljicyCsqS",
      "expanded_url" : "http://tcrn.ch/XQh0oR",
      "display_url" : "tcrn.ch/XQh0oR"
    } ]
  },
  "geo" : {
  },
  "id_str" : "308374875775574016",
  "text" : "RT @TechCrunch: There Was That Whole Internet Thing, Too http://t.co/6ljicyCsqS by @arrington",
  "retweeted_status" : {
    "source" : "<a href=\"http://10up.com\" rel=\"nofollow\">10up Publish Tweet</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Michael Arrington",
        "screen_name" : "arrington",
        "indices" : [ 67, 77 ],
        "id_str" : "37570179",
        "id" : 37570179
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 41, 63 ],
        "url" : "http://t.co/6ljicyCsqS",
        "expanded_url" : "http://tcrn.ch/XQh0oR",
        "display_url" : "tcrn.ch/XQh0oR"
      } ]
    },
    "geo" : {
    },
    "id_str" : "308352565425369088",
    "text" : "There Was That Whole Internet Thing, Too http://t.co/6ljicyCsqS by @arrington",
    "id" : 308352565425369088,
    "created_at" : "Sun Mar 03 23:05:55 +0000 2013",
    "user" : {
      "name" : "TechCrunch",
      "screen_name" : "TechCrunch",
      "protected" : false,
      "id_str" : "816653",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2176846885/-5-1_normal.jpeg",
      "id" : 816653,
      "verified" : true
    }
  },
  "id" : 308374875775574016,
  "created_at" : "Mon Mar 04 00:34:34 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jake Brewer",
      "screen_name" : "jakebrewer",
      "indices" : [ 3, 14 ],
      "id_str" : "14188895",
      "id" : 14188895
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "308373446004469762",
  "text" : "RT @jakebrewer: An important read: \"power is eroding: It is easier to get, but harder to use and far easier to lose.\" http://t.co/t611LA ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "marcidale",
        "screen_name" : "marcidale",
        "indices" : [ 129, 139 ],
        "id_str" : "15067551",
        "id" : 15067551
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 102, 124 ],
        "url" : "http://t.co/t611LARqDc",
        "expanded_url" : "http://wapo.st/1002CQO",
        "display_url" : "wapo.st/1002CQO"
      } ]
    },
    "geo" : {
    },
    "id_str" : "308362922520891392",
    "text" : "An important read: \"power is eroding: It is easier to get, but harder to use and far easier to lose.\" http://t.co/t611LARqDc via @marcidale",
    "id" : 308362922520891392,
    "created_at" : "Sun Mar 03 23:47:04 +0000 2013",
    "user" : {
      "name" : "Jake Brewer",
      "screen_name" : "jakebrewer",
      "protected" : false,
      "id_str" : "14188895",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/506945370/jbDSC_6125_bw_-2_normal.jpg",
      "id" : 14188895,
      "verified" : false
    }
  },
  "id" : 308373446004469762,
  "created_at" : "Mon Mar 04 00:28:53 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http://t.co/4yfTZmePaX",
      "expanded_url" : "http://bit.ly/VfdvrE",
      "display_url" : "bit.ly/VfdvrE"
    } ]
  },
  "geo" : {
  },
  "id_str" : "308366786754142208",
  "text" : "985. Checked in to report on February / start March with my Rabbit Rabbit Resolution Accountability Squad http://t.co/4yfTZmePaX",
  "id" : 308366786754142208,
  "created_at" : "Mon Mar 04 00:02:25 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http://t.co/dEOlMggdfX",
      "expanded_url" : "http://flic.kr/p/dZihn6",
      "display_url" : "flic.kr/p/dZihn6"
    } ]
  },
  "geo" : {
  },
  "id_str" : "308305661509382144",
  "text" : "Niko's preferred daily uniform has moved on from rain coat and rain boots to bike gear. http://t.co/dEOlMggdfX",
  "id" : 308305661509382144,
  "created_at" : "Sun Mar 03 19:59:32 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zach Wade",
      "screen_name" : "zwadep",
      "indices" : [ 0, 7 ],
      "id_str" : "37469773",
      "id" : 37469773
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "308104941979971585",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8595382116, -122.2750657792 ]
  },
  "id_str" : "308107905213820928",
  "in_reply_to_user_id" : 37469773,
  "text" : "@zwadep Seems like a reasonable request.",
  "id" : 308107905213820928,
  "in_reply_to_status_id" : 308104941979971585,
  "created_at" : "Sun Mar 03 06:53:43 +0000 2013",
  "in_reply_to_screen_name" : "zwadep",
  "in_reply_to_user_id_str" : "37469773",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zach Wade",
      "screen_name" : "zwadep",
      "indices" : [ 0, 7 ],
      "id_str" : "37469773",
      "id" : 37469773
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "308088154555031553",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596178965, -122.2753907129 ]
  },
  "id_str" : "308104035997720577",
  "in_reply_to_user_id" : 37469773,
  "text" : "@zwadep What kind of notification would you want? Have you tried TweetDeck or TweetBot?",
  "id" : 308104035997720577,
  "in_reply_to_status_id" : 308088154555031553,
  "created_at" : "Sun Mar 03 06:38:21 +0000 2013",
  "in_reply_to_screen_name" : "zwadep",
  "in_reply_to_user_id_str" : "37469773",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "IFTF",
      "screen_name" : "iftf",
      "indices" : [ 3, 8 ],
      "id_str" : "14620544",
      "id" : 14620544
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AutonomousAlgorithms",
      "indices" : [ 107, 128 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http://t.co/DIvfLoA6g0",
      "expanded_url" : "http://boingboing.net/2013/03/02/how-an-algorithm-came-up-with.html",
      "display_url" : "boingboing.net/2013/03/02/how\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "308077060193148928",
  "text" : "RT @iftf: How an algorithm came up with Amazon's KEEP CALM AND RAPE A LOT t-shirt - http://t.co/DIvfLoA6g0 #AutonomousAlgorithms",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AutonomousAlgorithms",
        "indices" : [ 97, 118 ]
      } ],
      "urls" : [ {
        "indices" : [ 74, 96 ],
        "url" : "http://t.co/DIvfLoA6g0",
        "expanded_url" : "http://boingboing.net/2013/03/02/how-an-algorithm-came-up-with.html",
        "display_url" : "boingboing.net/2013/03/02/how\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "308066927450927105",
    "text" : "How an algorithm came up with Amazon's KEEP CALM AND RAPE A LOT t-shirt - http://t.co/DIvfLoA6g0 #AutonomousAlgorithms",
    "id" : 308066927450927105,
    "created_at" : "Sun Mar 03 04:10:53 +0000 2013",
    "user" : {
      "name" : "IFTF",
      "screen_name" : "iftf",
      "protected" : false,
      "id_str" : "14620544",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3496025091/51e55928594eb40d5610bce931749672_normal.png",
      "id" : 14620544,
      "verified" : false
    }
  },
  "id" : 308077060193148928,
  "created_at" : "Sun Mar 03 04:51:09 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "chris dixon",
      "screen_name" : "cdixon",
      "indices" : [ 12, 19 ],
      "id_str" : "2529971",
      "id" : 2529971
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http://t.co/utGFVBvChi",
      "expanded_url" : "http://cdixon.org/2013/03/02/what-the-smartest-people-do-on-the-weekend-is-what-everyone-else-will-do-during-the-week-in-ten-years/",
      "display_url" : "cdixon.org/2013/03/02/wha\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "308064471606243329",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8595486377, -122.2753538379 ]
  },
  "id_str" : "308076247903248384",
  "in_reply_to_user_id" : 2529971,
  "text" : "Totally! RT @cdixon: What the smartest people do on the weekend is what everyone else will do during week in 10yrs http://t.co/utGFVBvChi",
  "id" : 308076247903248384,
  "in_reply_to_status_id" : 308064471606243329,
  "created_at" : "Sun Mar 03 04:47:55 +0000 2013",
  "in_reply_to_screen_name" : "cdixon",
  "in_reply_to_user_id_str" : "2529971",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http://t.co/OPsvTMGRB5",
      "expanded_url" : "http://flic.kr/p/dZ7fcB",
      "display_url" : "flic.kr/p/dZ7fcB"
    } ]
  },
  "geo" : {
  },
  "id_str" : "308074774960152576",
  "text" : "8:36pm New bikes, new little red caboose books, new delicious dinner spots down the street = great day http://t.co/OPsvTMGRB5",
  "id" : 308074774960152576,
  "created_at" : "Sun Mar 03 04:42:04 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.apple.com\" rel=\"nofollow\">Safari on iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http://t.co/7ArpGplwrd",
      "expanded_url" : "http://mobile.theverge.com/2013/2/26/4031938/new-crowdfunding-platforms-let-you-sell-stock-in-yourself",
      "display_url" : "mobile.theverge.com/2013/2/26/4031\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "308065530852564992",
  "text" : "New form of crowd funding sites allow you to buy equity in a person's future income http://t.co/7ArpGplwrd",
  "id" : 308065530852564992,
  "created_at" : "Sun Mar 03 04:05:20 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sara Miller",
      "screen_name" : "nishushan",
      "indices" : [ 0, 10 ],
      "id_str" : "712822328",
      "id" : 712822328
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "308023439061565440",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8574016317, -122.2530878109 ]
  },
  "id_str" : "308040920790601729",
  "in_reply_to_user_id" : 712822328,
  "text" : "@nishushan I listened to that one years ago. Was really great.",
  "id" : 308040920790601729,
  "in_reply_to_status_id" : 308023439061565440,
  "created_at" : "Sun Mar 03 02:27:33 +0000 2013",
  "in_reply_to_screen_name" : "nishushan",
  "in_reply_to_user_id_str" : "712822328",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moe Arora",
      "screen_name" : "moearora",
      "indices" : [ 0, 9 ],
      "id_str" : "13809752",
      "id" : 13809752
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "308035241774284801",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8573126393, -122.2531455663 ]
  },
  "id_str" : "308040778586931200",
  "in_reply_to_user_id" : 13809752,
  "text" : "@moearora Any recommendations of audiobook subscription services?",
  "id" : 308040778586931200,
  "in_reply_to_status_id" : 308035241774284801,
  "created_at" : "Sun Mar 03 02:26:59 +0000 2013",
  "in_reply_to_screen_name" : "moearora",
  "in_reply_to_user_id_str" : "13809752",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael S Galpert",
      "screen_name" : "msg",
      "indices" : [ 0, 4 ],
      "id_str" : "937961",
      "id" : 937961
    }, {
      "name" : "Alex Rainert",
      "screen_name" : "arainert",
      "indices" : [ 5, 14 ],
      "id_str" : "7482",
      "id" : 7482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "308035748723056640",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8573583207, -122.2531608214 ]
  },
  "id_str" : "308040602753323008",
  "in_reply_to_user_id" : 937961,
  "text" : "@msg @arainert Also learning that the quality of book goes way up with a good reader. Malcolm Gladwell reading Outliers was very enjoyable.",
  "id" : 308040602753323008,
  "in_reply_to_status_id" : 308035748723056640,
  "created_at" : "Sun Mar 03 02:26:17 +0000 2013",
  "in_reply_to_screen_name" : "msg",
  "in_reply_to_user_id_str" : "937961",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael S Galpert",
      "screen_name" : "msg",
      "indices" : [ 0, 4 ],
      "id_str" : "937961",
      "id" : 937961
    }, {
      "name" : "Alex Rainert",
      "screen_name" : "arainert",
      "indices" : [ 5, 14 ],
      "id_str" : "7482",
      "id" : 7482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "308035748723056640",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8573100549, -122.2530852319 ]
  },
  "id_str" : "308040372444078080",
  "in_reply_to_user_id" : 937961,
  "text" : "@msg @arainert Ooh I didn't realize that. Definitely a perk of Audible being owned by Amazon.",
  "id" : 308040372444078080,
  "in_reply_to_status_id" : 308035748723056640,
  "created_at" : "Sun Mar 03 02:25:22 +0000 2013",
  "in_reply_to_screen_name" : "msg",
  "in_reply_to_user_id_str" : "937961",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moe Arora",
      "screen_name" : "moearora",
      "indices" : [ 0, 9 ],
      "id_str" : "13809752",
      "id" : 13809752
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "308024379843956736",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.858373979, -122.2532829805 ]
  },
  "id_str" : "308030222790447104",
  "in_reply_to_user_id" : 13809752,
  "text" : "@moearora Yeah, Audible. Haven't looked around enough to know if there's something better though.",
  "id" : 308030222790447104,
  "in_reply_to_status_id" : 308024379843956736,
  "created_at" : "Sun Mar 03 01:45:02 +0000 2013",
  "in_reply_to_screen_name" : "moearora",
  "in_reply_to_user_id_str" : "13809752",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 68 ],
      "url" : "http://t.co/6seJbnIB7t",
      "expanded_url" : "http://flic.kr/p/dZ4KWK",
      "display_url" : "flic.kr/p/dZ4KWK"
    } ]
  },
  "geo" : {
  },
  "id_str" : "308017531917062144",
  "text" : "986. Bought me a bike so I can be sporty too. http://t.co/6seJbnIB7t",
  "id" : 308017531917062144,
  "created_at" : "Sun Mar 03 00:54:36 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Bonner",
      "screen_name" : "seanbonner",
      "indices" : [ 0, 11 ],
      "id_str" : "765",
      "id" : 765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "308005224176553984",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596805462, -122.2754583175 ]
  },
  "id_str" : "308015617028530178",
  "in_reply_to_user_id" : 765,
  "text" : "@seanbonner I try to say listen but then have to add context that it's an audiobook. Depends on how many chars I have left in my tweet.",
  "id" : 308015617028530178,
  "in_reply_to_status_id" : 308005224176553984,
  "created_at" : "Sun Mar 03 00:47:00 +0000 2013",
  "in_reply_to_screen_name" : "seanbonner",
  "in_reply_to_user_id_str" : "765",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leah Reich",
      "screen_name" : "ohheygreat",
      "indices" : [ 0, 11 ],
      "id_str" : "9670142",
      "id" : 9670142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307997466060533760",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8738757003, -122.2684349762 ]
  },
  "id_str" : "307999904201068544",
  "in_reply_to_user_id" : 9670142,
  "text" : "@ohheygreat Please continue.",
  "id" : 307999904201068544,
  "in_reply_to_status_id" : 307997466060533760,
  "created_at" : "Sat Mar 02 23:44:34 +0000 2013",
  "in_reply_to_screen_name" : "ohheygreat",
  "in_reply_to_user_id_str" : "9670142",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Ellin",
      "screen_name" : "brianellin",
      "indices" : [ 0, 11 ],
      "id_str" : "26123649",
      "id" : 26123649
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307998419761385472",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8739525276, -122.268549889 ]
  },
  "id_str" : "307999520191569920",
  "in_reply_to_user_id" : 26123649,
  "text" : "@brianellin The Willpower Instinct. Just finished Outliers. Next up Thinking Fast And Slow and You Are Not Smart. Getting pricey though.",
  "id" : 307999520191569920,
  "in_reply_to_status_id" : 307998419761385472,
  "created_at" : "Sat Mar 02 23:43:02 +0000 2013",
  "in_reply_to_screen_name" : "brianellin",
  "in_reply_to_user_id_str" : "26123649",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Sippey",
      "screen_name" : "sippey",
      "indices" : [ 0, 7 ],
      "id_str" : "4711",
      "id" : 4711
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "yum",
      "indices" : [ 37, 41 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307997153001885698",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8738668349, -122.268573089 ]
  },
  "id_str" : "307997614853472256",
  "in_reply_to_user_id" : 4711,
  "text" : "@sippey Salted rock. And moss chips. #yum",
  "id" : 307997614853472256,
  "in_reply_to_status_id" : 307997153001885698,
  "created_at" : "Sat Mar 02 23:35:28 +0000 2013",
  "in_reply_to_screen_name" : "sippey",
  "in_reply_to_user_id_str" : "4711",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8739540385, -122.2685907747 ]
  },
  "id_str" : "307997306383372288",
  "text" : "Was just daydreaming about going blind and being able to listen to audiobooks for rest of life.",
  "id" : 307997306383372288,
  "created_at" : "Sat Mar 02 23:34:14 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8739334418, -122.268589842 ]
  },
  "id_str" : "307997140305715200",
  "text" : "My name is Buster and I and addicted to audiobooks.",
  "id" : 307997140305715200,
  "created_at" : "Sat Mar 02 23:33:35 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Sippey",
      "screen_name" : "sippey",
      "indices" : [ 0, 7 ],
      "id_str" : "4711",
      "id" : 4711
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307993828340686848",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8739219931, -122.2686399276 ]
  },
  "id_str" : "307996526637101056",
  "in_reply_to_user_id" : 4711,
  "text" : "@sippey Plenty of parking here in the woods.",
  "id" : 307996526637101056,
  "in_reply_to_status_id" : 307993828340686848,
  "created_at" : "Sat Mar 02 23:31:08 +0000 2013",
  "in_reply_to_screen_name" : "sippey",
  "in_reply_to_user_id_str" : "4711",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen Christensen",
      "screen_name" : "TheLegacyBoutiq",
      "indices" : [ 0, 16 ],
      "id_str" : "123995876",
      "id" : 123995876
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307965389286035456",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8704634005, -122.2680647844 ]
  },
  "id_str" : "307969059662753793",
  "in_reply_to_user_id" : 123995876,
  "text" : "@TheLegacyBoutiq I'm in SF. Let me know if any come up here!",
  "id" : 307969059662753793,
  "in_reply_to_status_id" : 307965389286035456,
  "created_at" : "Sat Mar 02 21:42:00 +0000 2013",
  "in_reply_to_screen_name" : "TheLegacyBoutiq",
  "in_reply_to_user_id_str" : "123995876",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 43 ],
      "url" : "http://t.co/IAfg0qltlP",
      "expanded_url" : "http://instagr.am/p/WXnf11o0DL/",
      "display_url" : "instagr.am/p/WXnf11o0DL/"
    } ]
  },
  "geo" : {
  },
  "id_str" : "307954829546901505",
  "text" : "987. Sporty family \u2714 http://t.co/IAfg0qltlP",
  "id" : 307954829546901505,
  "created_at" : "Sat Mar 02 20:45:27 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://runkeeper.com\" rel=\"nofollow\">RunKeeper</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RunKeeper",
      "indices" : [ 90, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http://t.co/FWpxuCnl6P",
      "expanded_url" : "http://rnkpr.com/a2jfmkm",
      "display_url" : "rnkpr.com/a2jfmkm"
    } ]
  },
  "geo" : {
  },
  "id_str" : "307947429079183360",
  "text" : "Just posted a 4.51 mi run - 988. Half outside, half on treadmill.  http://t.co/FWpxuCnl6P #RunKeeper",
  "id" : 307947429079183360,
  "created_at" : "Sat Mar 02 20:16:03 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lift",
      "screen_name" : "liftapp",
      "indices" : [ 27, 35 ],
      "id_str" : "353195232",
      "id" : 353195232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http://t.co/POUYj55Rr9",
      "expanded_url" : "http://bit.ly/Z8yJZM",
      "display_url" : "bit.ly/Z8yJZM"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597963547, -122.2756676893 ]
  },
  "id_str" : "307923663460638720",
  "text" : "989. Meditated, and joined @liftapp's March Meditation Challenge too: http://t.co/POUYj55Rr9",
  "id" : 307923663460638720,
  "created_at" : "Sat Mar 02 18:41:36 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://bufferapp.com\" rel=\"nofollow\">Buffer</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "307895921197334528",
  "text" : "Being too careful is dangerous.",
  "id" : 307895921197334528,
  "created_at" : "Sat Mar 02 16:51:22 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen Christensen",
      "screen_name" : "TheLegacyBoutiq",
      "indices" : [ 0, 16 ],
      "id_str" : "123995876",
      "id" : 123995876
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307749354809221120",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596740236, -122.2755387049 ]
  },
  "id_str" : "307776348460568578",
  "in_reply_to_user_id" : 123995876,
  "text" : "@TheLegacyBoutiq I did not but following her &amp; the movie now! How were you involved? Any other screenings planned?",
  "id" : 307776348460568578,
  "in_reply_to_status_id" : 307749354809221120,
  "created_at" : "Sat Mar 02 08:56:14 +0000 2013",
  "in_reply_to_screen_name" : "TheLegacyBoutiq",
  "in_reply_to_user_id_str" : "123995876",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859659583, -122.2753478606 ]
  },
  "id_str" : "307728129860964352",
  "text" : "990. Does meditation help you prepare for a marathon? I'm counting it.",
  "id" : 307728129860964352,
  "created_at" : "Sat Mar 02 05:44:38 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http://t.co/UIwJxFDArV",
      "expanded_url" : "http://flic.kr/p/dYRbCx",
      "display_url" : "flic.kr/p/dYRbCx"
    } ]
  },
  "geo" : {
  },
  "id_str" : "307720645846900736",
  "text" : "8:36pm \"They jump and jump but nobody has ever touched the moon.\" http://t.co/UIwJxFDArV",
  "id" : 307720645846900736,
  "created_at" : "Sat Mar 02 05:14:53 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Shen",
      "screen_name" : "JasonShen",
      "indices" : [ 3, 13 ],
      "id_str" : "10242",
      "id" : 10242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http://t.co/lsosItwp8B",
      "expanded_url" : "http://jshen.me/XIBvXJ",
      "display_url" : "jshen.me/XIBvXJ"
    } ]
  },
  "geo" : {
  },
  "id_str" : "307709205278781440",
  "text" : "RT @JasonShen: A married couple who spent 15 in Antarctica together, share tips for surviving maritial bliss \u2014 http://t.co/lsosItwp8B",
  "retweeted_status" : {
    "source" : "<a href=\"http://bufferapp.com\" rel=\"nofollow\">Buffer</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 96, 118 ],
        "url" : "http://t.co/lsosItwp8B",
        "expanded_url" : "http://jshen.me/XIBvXJ",
        "display_url" : "jshen.me/XIBvXJ"
      } ]
    },
    "geo" : {
    },
    "id_str" : "307704331451367424",
    "text" : "A married couple who spent 15 in Antarctica together, share tips for surviving maritial bliss \u2014 http://t.co/lsosItwp8B",
    "id" : 307704331451367424,
    "created_at" : "Sat Mar 02 04:10:04 +0000 2013",
    "user" : {
      "name" : "Jason Shen",
      "screen_name" : "JasonShen",
      "protected" : false,
      "id_str" : "10242",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3226722715/23598bd0e9e65690ccc38613ff392ce3_normal.jpeg",
      "id" : 10242,
      "verified" : false
    }
  },
  "id" : 307709205278781440,
  "created_at" : "Sat Mar 02 04:29:26 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 36, 44 ],
      "id_str" : "783214",
      "id" : 783214
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "brag",
      "indices" : [ 134, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596063818, -122.2753626953 ]
  },
  "id_str" : "307691943218003968",
  "text" : "One of the best perks of working at @Twitter is being able to alpha test new exciting ideas. I especially like the one I'm using now. #brag",
  "id" : 307691943218003968,
  "created_at" : "Sat Mar 02 03:20:50 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Sippey",
      "screen_name" : "sippey",
      "indices" : [ 3, 10 ],
      "id_str" : "4711",
      "id" : 4711
    }, {
      "name" : "Buster",
      "screen_name" : "buster",
      "indices" : [ 12, 19 ],
      "id_str" : "2185",
      "id" : 2185
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bark",
      "indices" : [ 61, 66 ]
    }, {
      "text" : "leaves",
      "indices" : [ 67, 74 ]
    }, {
      "text" : "rabbits",
      "indices" : [ 75, 83 ]
    }, {
      "text" : "notlettingthisjokego",
      "indices" : [ 84, 105 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "307681987106316289",
  "text" : "RT @sippey: @buster food decisions are easier in the forest. #bark #leaves #rabbits #notlettingthisjokego",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Buster",
        "screen_name" : "buster",
        "indices" : [ 0, 7 ],
        "id_str" : "2185",
        "id" : 2185
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "bark",
        "indices" : [ 49, 54 ]
      }, {
        "text" : "leaves",
        "indices" : [ 55, 62 ]
      }, {
        "text" : "rabbits",
        "indices" : [ 63, 71 ]
      }, {
        "text" : "notlettingthisjokego",
        "indices" : [ 72, 93 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "307671492655722496",
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 37.8918700109, -122.2798607753 ]
    },
    "id_str" : "307674712757133312",
    "in_reply_to_user_id" : 2185,
    "text" : "@buster food decisions are easier in the forest. #bark #leaves #rabbits #notlettingthisjokego",
    "id" : 307674712757133312,
    "in_reply_to_status_id" : 307671492655722496,
    "created_at" : "Sat Mar 02 02:12:22 +0000 2013",
    "in_reply_to_screen_name" : "buster",
    "in_reply_to_user_id_str" : "2185",
    "user" : {
      "name" : "Michael Sippey",
      "screen_name" : "sippey",
      "protected" : false,
      "id_str" : "4711",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3541799518/c8ea5593267cad82eb9de763a9456d3b_normal.jpeg",
      "id" : 4711,
      "verified" : false
    }
  },
  "id" : 307681987106316289,
  "created_at" : "Sat Mar 02 02:41:16 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kelly McGonigal",
      "screen_name" : "kellymcgonigal",
      "indices" : [ 44, 59 ],
      "id_str" : "38981543",
      "id" : 38981543
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.779243424, -122.4142427485 ]
  },
  "id_str" : "307671492655722496",
  "text" : "991. Listening to The Willpower Instinct by @kellymcgonigal. Learned that we make 200+ food-related decisions a day (mostly subconscious).",
  "id" : 307671492655722496,
  "created_at" : "Sat Mar 02 01:59:34 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Sarver",
      "screen_name" : "rsarver",
      "indices" : [ 0, 8 ],
      "id_str" : "795649",
      "id" : 795649
    }, {
      "name" : "Ian Chan",
      "screen_name" : "chanian",
      "indices" : [ 9, 17 ],
      "id_str" : "22891211",
      "id" : 22891211
    }, {
      "name" : "Arne Roomann-Kurrik",
      "screen_name" : "kurrik",
      "indices" : [ 18, 25 ],
      "id_str" : "7588892",
      "id" : 7588892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307647780963352576",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7768969326, -122.4172002778 ]
  },
  "id_str" : "307655987177861122",
  "in_reply_to_user_id" : 795649,
  "text" : "@rsarver @chanian @kurrik And it was awesome.",
  "id" : 307655987177861122,
  "in_reply_to_status_id" : 307647780963352576,
  "created_at" : "Sat Mar 02 00:57:57 +0000 2013",
  "in_reply_to_screen_name" : "rsarver",
  "in_reply_to_user_id_str" : "795649",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Neilson",
      "screen_name" : "TheCulprit",
      "indices" : [ 0, 11 ],
      "id_str" : "6726182",
      "id" : 6726182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307603017702727680",
  "geo" : {
  },
  "id_str" : "307604145723019264",
  "in_reply_to_user_id" : 6726182,
  "text" : "@TheCulprit OoOoOoOoH...",
  "id" : 307604145723019264,
  "in_reply_to_status_id" : 307603017702727680,
  "created_at" : "Fri Mar 01 21:31:58 +0000 2013",
  "in_reply_to_screen_name" : "TheCulprit",
  "in_reply_to_user_id_str" : "6726182",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Neilson",
      "screen_name" : "TheCulprit",
      "indices" : [ 0, 11 ],
      "id_str" : "6726182",
      "id" : 6726182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307575779670257664",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7768989677, -122.4173070842 ]
  },
  "id_str" : "307602476897533952",
  "in_reply_to_user_id" : 6726182,
  "text" : "@TheCulprit That's so awesome! We'll probably drive up early Sat to enjoy the area a bit too. Know of good places to stay?",
  "id" : 307602476897533952,
  "in_reply_to_status_id" : 307575779670257664,
  "created_at" : "Fri Mar 01 21:25:20 +0000 2013",
  "in_reply_to_screen_name" : "TheCulprit",
  "in_reply_to_user_id_str" : "6726182",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donna",
      "screen_name" : "donna",
      "indices" : [ 19, 25 ],
      "id_str" : "385159039",
      "id" : 385159039
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http://t.co/X0chlRci6u",
      "expanded_url" : "http://don.na/invite/iy",
      "display_url" : "don.na/invite/iy"
    } ]
  },
  "geo" : {
  },
  "id_str" : "307590000466341888",
  "text" : "I can\u2019t wait until @Donna\u2019s ready. If you\u2019re looking for someone to help organize your day, you should write to her: http://t.co/X0chlRci6u",
  "id" : 307590000466341888,
  "created_at" : "Fri Mar 01 20:35:45 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/the-eatery/id468299990?mt=8&uo=4\" rel=\"nofollow\">The Eatery on iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "healthmonth",
      "indices" : [ 11, 23 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https://t.co/WO4xQIzzgL",
      "expanded_url" : "https://eatery.massivehealth.com/foods/da76c741-c6ae-42ba-9cb1-0cf068d95c6a",
      "display_url" : "eatery.massivehealth.com/foods/da76c741\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "307587477777022976",
  "text" : "992. March #healthmonth begins. Trying to avoid processed ingredients.  https://t.co/WO4xQIzzgL",
  "id" : 307587477777022976,
  "created_at" : "Fri Mar 01 20:25:44 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://bufferapp.com\" rel=\"nofollow\">Buffer</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Heitzeberg",
      "screen_name" : "jheitzeb",
      "indices" : [ 77, 86 ],
      "id_str" : "6629572",
      "id" : 6629572
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http://t.co/mqG1Bduq4P",
      "expanded_url" : "http://bit.ly/YPAMUI",
      "display_url" : "bit.ly/YPAMUI"
    } ]
  },
  "geo" : {
  },
  "id_str" : "307580775342174209",
  "text" : "Great articulation of what makes work worth doing http://t.co/mqG1Bduq4P /by @jheitzeb",
  "id" : 307580775342174209,
  "created_at" : "Fri Mar 01 19:59:06 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Sippey",
      "screen_name" : "sippey",
      "indices" : [ 0, 7 ],
      "id_str" : "4711",
      "id" : 4711
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307524175524929536",
  "geo" : {
  },
  "id_str" : "307531317040525313",
  "in_reply_to_user_id" : 4711,
  "text" : "@sippey That would explain all the woodland creatures scratching on my tent in the night, I suppose.",
  "id" : 307531317040525313,
  "in_reply_to_status_id" : 307524175524929536,
  "created_at" : "Fri Mar 01 16:42:34 +0000 2013",
  "in_reply_to_screen_name" : "sippey",
  "in_reply_to_user_id_str" : "4711",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596351167, -122.2758268996 ]
  },
  "id_str" : "307523563777294336",
  "text" : "Rabbit rabbit!",
  "id" : 307523563777294336,
  "created_at" : "Fri Mar 01 16:11:45 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
} ]