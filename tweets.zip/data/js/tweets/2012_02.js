Grailbird.data.tweets_2012_02 = 
 [ {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ciaran Lyons",
      "screen_name" : "crayonlions",
      "indices" : [ 0, 12 ],
      "id_str" : "231087644",
      "id" : 231087644
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "175077097683955712",
  "geo" : { },
  "id_str" : "175087591870316544",
  "in_reply_to_user_id" : 231087644,
  "text" : "@crayonlions That's what I'm trying to say. It seems like a good idea until you actually try to think of a blackmail you'd do yourself.",
  "id" : 175087591870316544,
  "in_reply_to_status_id" : 175077097683955712,
  "created_at" : "2012-03-01 05:18:29 +0000",
  "in_reply_to_screen_name" : "crayonlions",
  "in_reply_to_user_id_str" : "231087644",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcelo Calbucci",
      "screen_name" : "calbucci",
      "indices" : [ 12, 21 ],
      "id_str" : "14232711",
      "id" : 14232711
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 101 ],
      "url" : "http://t.co/3Ws17OSH",
      "expanded_url" : "http://flic.kr/p/bmBn4w",
      "display_url" : "flic.kr/p/bmBn4w"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.623, -122.337 ]
  },
  "id_str" : "175078274182033409",
  "text" : "8:36pm Just @calbucci and I keeping the lights on. Health startups in the house! http://t.co/3Ws17OSH",
  "id" : 175078274182033409,
  "created_at" : "2012-03-01 04:41:28 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joshua Harbert",
      "screen_name" : "JRHarbert",
      "indices" : [ 22, 32 ],
      "id_str" : "65202704",
      "id" : 65202704
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "pegasus",
      "indices" : [ 126, 134 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 124 ],
      "url" : "http://t.co/UXCYBb9J",
      "expanded_url" : "http://750words.com",
      "display_url" : "750words.com"
    } ]
  },
  "geo" : { },
  "id_str" : "175073503295455233",
  "text" : "That's pretty rad. RT @JRHarbert: can only say wow / after a year of writing / every single day (thanks http://t.co/UXCYBb9J) #pegasus",
  "id" : 175073503295455233,
  "created_at" : "2012-03-01 04:22:30 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ciaran Lyons",
      "screen_name" : "crayonlions",
      "indices" : [ 0, 12 ],
      "id_str" : "231087644",
      "id" : 231087644
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "175061824151105536",
  "geo" : { },
  "id_str" : "175063951997018113",
  "in_reply_to_user_id" : 231087644,
  "text" : "@crayonlions What's something you want to do, and how much will you authorize a future payment for if you don't do it?",
  "id" : 175063951997018113,
  "in_reply_to_status_id" : 175061824151105536,
  "created_at" : "2012-03-01 03:44:33 +0000",
  "in_reply_to_screen_name" : "crayonlions",
  "in_reply_to_user_id_str" : "231087644",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 114 ],
      "url" : "http://t.co/UuOO6fg4",
      "expanded_url" : "http://bustr.me/post/18514936276/massive-asteroid-to-hit-earth-in-2040",
      "display_url" : "bustr.me/post/185149362\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "174989153585475584",
  "text" : "I know what I'll be doing on Feb 5th, 2040: Instagraming this with my senior citizen friends: http://t.co/UuOO6fg4",
  "id" : 174989153585475584,
  "created_at" : "2012-02-29 22:47:20 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 83 ],
      "url" : "http://t.co/SSV9scuQ",
      "expanded_url" : "http://bustr.me/post/18506640485/omgpop-is-a-gaming-company-that-has-been-plugging",
      "display_url" : "bustr.me/post/185066404\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "174953248883609600",
  "text" : "BREAKING! Magic secret ingredient for success revealed inside: http://t.co/SSV9scuQ",
  "id" : 174953248883609600,
  "created_at" : "2012-02-29 20:24:39 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://leapfor.it\" rel=\"nofollow\">Leap Application</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leap",
      "screen_name" : "leap",
      "indices" : [ 41, 46 ],
      "id_str" : "257098055",
      "id" : 257098055
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 104 ],
      "url" : "http://t.co/EeZvFMdR",
      "expanded_url" : "http://leapfor.it/c/9m",
      "display_url" : "leapfor.it/c/9m"
    } ]
  },
  "geo" : { },
  "id_str" : "174944911605510145",
  "text" : "Just created the Inbox Zero challenge on @leap. Anyone can join in. Come take me on http://t.co/EeZvFMdR",
  "id" : 174944911605510145,
  "created_at" : "2012-02-29 19:51:31 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tumblr.com/\" rel=\"nofollow\">Tumblr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 79 ],
      "url" : "http://t.co/LyJMGaRU",
      "expanded_url" : "http://tmblr.co/ZQJvayHE_-hs",
      "display_url" : "tmblr.co/ZQJvayHE_-hs"
    } ]
  },
  "geo" : { },
  "id_str" : "174944379121831938",
  "text" : "+10 pts for using Leap Day to launch your app called Leap: http://t.co/LyJMGaRU",
  "id" : 174944379121831938,
  "created_at" : "2012-02-29 19:49:24 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nikki Lee",
      "screen_name" : "nkkl",
      "indices" : [ 0, 5 ],
      "id_str" : "22096585",
      "id" : 22096585
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "174911951502188544",
  "geo" : { },
  "id_str" : "174914152899411968",
  "in_reply_to_user_id" : 22096585,
  "text" : "@nkkl I definitely am. I'll check it out, thanks!",
  "id" : 174914152899411968,
  "in_reply_to_status_id" : 174911951502188544,
  "created_at" : "2012-02-29 17:49:18 +0000",
  "in_reply_to_screen_name" : "nkkl",
  "in_reply_to_user_id_str" : "22096585",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tumblr.com/\" rel=\"nofollow\">Tumblr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 83 ],
      "url" : "http://t.co/YM944Qaj",
      "expanded_url" : "http://tmblr.co/ZQJvayHEgmjl",
      "display_url" : "tmblr.co/ZQJvayHEgmjl"
    } ]
  },
  "geo" : { },
  "id_str" : "174910299894317056",
  "text" : "A formula for how altruism could evolve via natural selection: http://t.co/YM944Qaj",
  "id" : 174910299894317056,
  "created_at" : "2012-02-29 17:33:59 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 93 ],
      "url" : "http://t.co/5aGPJxCn",
      "expanded_url" : "http://flic.kr/p/bmoayq",
      "display_url" : "flic.kr/p/bmoayq"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.614833, -122.343167 ]
  },
  "id_str" : "174732438881312768",
  "text" : "8:36pm Was watching Pina. The kind of movie that wants to sink in a bit. http://t.co/5aGPJxCn",
  "id" : 174732438881312768,
  "created_at" : "2012-02-29 05:47:14 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 118 ],
      "url" : "http://t.co/CNPvYjkW",
      "expanded_url" : "http://instagr.am/p/HkzGU3I0Hn/",
      "display_url" : "instagr.am/p/HkzGU3I0Hn/"
    } ]
  },
  "geo" : { },
  "id_str" : "174702144694394880",
  "text" : "Whenever Niko doesn't want to do something, Panda Friend tries it and discovers it ain't that bad http://t.co/CNPvYjkW",
  "id" : 174702144694394880,
  "created_at" : "2012-02-29 03:46:51 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Jacobs",
      "screen_name" : "djacobs",
      "indices" : [ 18, 26 ],
      "id_str" : "774842",
      "id" : 774842
    }, {
      "name" : "Unroll.Me",
      "screen_name" : "Unrollme",
      "indices" : [ 38, 47 ],
      "id_str" : "339769044",
      "id" : 339769044
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 128 ],
      "url" : "http://t.co/K9xsmGny",
      "expanded_url" : "http://unroll.me",
      "display_url" : "unroll.me"
    } ]
  },
  "geo" : { },
  "id_str" : "174700330804719618",
  "text" : "Looks awesome. RT @djacobs: Check out @unrollme - I just unsubscribed from all my unwanted emails at once - http://t.co/K9xsmGny",
  "id" : 174700330804719618,
  "created_at" : "2012-02-29 03:39:39 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Rainert",
      "screen_name" : "arainert",
      "indices" : [ 0, 9 ],
      "id_str" : "7482",
      "id" : 7482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "174691194876604416",
  "geo" : { },
  "id_str" : "174698720166813696",
  "in_reply_to_user_id" : 7482,
  "text" : "@arainert They definitely need a notes and highlights API. In the meantime there are a few scrapers out there...",
  "id" : 174698720166813696,
  "in_reply_to_status_id" : 174691194876604416,
  "created_at" : "2012-02-29 03:33:15 +0000",
  "in_reply_to_screen_name" : "arainert",
  "in_reply_to_user_id_str" : "7482",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tara Tiger Brown",
      "screen_name" : "tara",
      "indices" : [ 0, 5 ],
      "id_str" : "10959642",
      "id" : 10959642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "174688831747002370",
  "geo" : { },
  "id_str" : "174697843691495425",
  "in_reply_to_user_id" : 10959642,
  "text" : "@tara I've noticed too with Niko that denial of responsibility is the first form of deceit.",
  "id" : 174697843691495425,
  "in_reply_to_status_id" : 174688831747002370,
  "created_at" : "2012-02-29 03:29:46 +0000",
  "in_reply_to_screen_name" : "tara",
  "in_reply_to_user_id_str" : "10959642",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nancy Dougherty",
      "screen_name" : "nancyhd",
      "indices" : [ 0, 8 ],
      "id_str" : "19854731",
      "id" : 19854731
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "174688069751021568",
  "geo" : { },
  "id_str" : "174697207306518528",
  "in_reply_to_user_id" : 19854731,
  "text" : "@nancyhd Do you agree with that post? It seemed rather cynical and opportunistic to me.",
  "id" : 174697207306518528,
  "in_reply_to_status_id" : 174688069751021568,
  "created_at" : "2012-02-29 03:27:14 +0000",
  "in_reply_to_screen_name" : "nancyhd",
  "in_reply_to_user_id_str" : "19854731",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diana Kimball",
      "screen_name" : "dianakimball",
      "indices" : [ 0, 13 ],
      "id_str" : "14471007",
      "id" : 14471007
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "174685440190849024",
  "geo" : { },
  "id_str" : "174686952497491968",
  "in_reply_to_user_id" : 14471007,
  "text" : "@dianakimball It definitely is. But a lot better looking.",
  "id" : 174686952497491968,
  "in_reply_to_status_id" : 174685440190849024,
  "created_at" : "2012-02-29 02:46:29 +0000",
  "in_reply_to_screen_name" : "dianakimball",
  "in_reply_to_user_id_str" : "14471007",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Foster",
      "screen_name" : "mfstr",
      "indices" : [ 0, 6 ],
      "id_str" : "97275453",
      "id" : 97275453
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "174674727124742145",
  "geo" : { },
  "id_str" : "174680064074579968",
  "in_reply_to_user_id" : 97275453,
  "text" : "@mfstr You're right! I've been collecting Feltron reports for years. He's awesome and an inspiration.",
  "id" : 174680064074579968,
  "in_reply_to_status_id" : 174674727124742145,
  "created_at" : "2012-02-29 02:19:07 +0000",
  "in_reply_to_screen_name" : "mfstr",
  "in_reply_to_user_id_str" : "97275453",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jimmy Jacobson",
      "screen_name" : "jimmyjacobson",
      "indices" : [ 0, 14 ],
      "id_str" : "17545050",
      "id" : 17545050
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "174631778072530945",
  "geo" : { },
  "id_str" : "174654720756023296",
  "in_reply_to_user_id" : 17545050,
  "text" : "@jimmyjacobson I had to look that up. I figure we should just embrace our automatic natures until given a reason to think otherwise.",
  "id" : 174654720756023296,
  "in_reply_to_status_id" : 174631778072530945,
  "created_at" : "2012-02-29 00:38:25 +0000",
  "in_reply_to_screen_name" : "jimmyjacobson",
  "in_reply_to_user_id_str" : "17545050",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jimmy Jacobson",
      "screen_name" : "jimmyjacobson",
      "indices" : [ 0, 14 ],
      "id_str" : "17545050",
      "id" : 17545050
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "174539654400454658",
  "geo" : { },
  "id_str" : "174583008005857281",
  "in_reply_to_user_id" : 17545050,
  "text" : "@jimmyjacobson Yes, I completely agree. We are tiny riders on the elephant of our subconscious.",
  "id" : 174583008005857281,
  "in_reply_to_status_id" : 174539654400454658,
  "created_at" : "2012-02-28 19:53:27 +0000",
  "in_reply_to_screen_name" : "jimmyjacobson",
  "in_reply_to_user_id_str" : "17545050",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ingopixel",
      "screen_name" : "ingopixel",
      "indices" : [ 0, 10 ],
      "id_str" : "7943892",
      "id" : 7943892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "174367859131162626",
  "geo" : { },
  "id_str" : "174368256067506177",
  "in_reply_to_user_id" : 7943892,
  "text" : "@ingopixel Oh man, I just tried to retweet that, but you have a private account! :)",
  "id" : 174368256067506177,
  "in_reply_to_status_id" : 174367859131162626,
  "created_at" : "2012-02-28 05:40:06 +0000",
  "in_reply_to_screen_name" : "ingopixel",
  "in_reply_to_user_id_str" : "7943892",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 72 ],
      "url" : "http://t.co/BPUib7AM",
      "expanded_url" : "http://flic.kr/p/bm7uES",
      "display_url" : "flic.kr/p/bm7uES"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.608833, -122.306167 ]
  },
  "id_str" : "174355949203636224",
  "text" : "8:36pm A day of sleeping fails but it wasn't so bad http://t.co/BPUib7AM",
  "id" : 174355949203636224,
  "created_at" : "2012-02-28 04:51:12 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "harryh",
      "screen_name" : "harryh",
      "indices" : [ 3, 10 ],
      "id_str" : "4558",
      "id" : 4558
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FiveWordTEDTalks",
      "indices" : [ 47, 64 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "174345966353260545",
  "text" : "RT @harryh: Smart people will fix everything.  #FiveWordTEDTalks",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FiveWordTEDTalks",
        "indices" : [ 35, 52 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "174344558509957120",
    "text" : "Smart people will fix everything.  #FiveWordTEDTalks",
    "id" : 174344558509957120,
    "created_at" : "2012-02-28 04:05:56 +0000",
    "user" : {
      "name" : "harryh",
      "screen_name" : "harryh",
      "protected" : false,
      "id_str" : "4558",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000064813755/302df95cdee7add81895ac398c661cea_normal.jpeg",
      "id" : 4558,
      "verified" : false
    }
  },
  "id" : 174345966353260545,
  "created_at" : "2012-02-28 04:11:32 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Cole",
      "screen_name" : "irondavy",
      "indices" : [ 0, 9 ],
      "id_str" : "14986129",
      "id" : 14986129
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "174334186503684098",
  "geo" : { },
  "id_str" : "174334584706703360",
  "in_reply_to_user_id" : 14986129,
  "text" : "@irondavy I need some CSS organization ideas, so I might have to look into it.",
  "id" : 174334584706703360,
  "in_reply_to_status_id" : 174334186503684098,
  "created_at" : "2012-02-28 03:26:18 +0000",
  "in_reply_to_screen_name" : "irondavy",
  "in_reply_to_user_id_str" : "14986129",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Cole",
      "screen_name" : "irondavy",
      "indices" : [ 0, 9 ],
      "id_str" : "14986129",
      "id" : 14986129
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "174332087464239104",
  "geo" : { },
  "id_str" : "174334095910895617",
  "in_reply_to_user_id" : 14986129,
  "text" : "@irondavy Worth buying?",
  "id" : 174334095910895617,
  "in_reply_to_status_id" : 174332087464239104,
  "created_at" : "2012-02-28 03:24:22 +0000",
  "in_reply_to_screen_name" : "irondavy",
  "in_reply_to_user_id_str" : "14986129",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http://t.co/shWLKYs5",
      "expanded_url" : "http://instagr.am/p/HiLS6wI0BA/",
      "display_url" : "instagr.am/p/HiLS6wI0BA/"
    } ]
  },
  "geo" : { },
  "id_str" : "174333052300955648",
  "text" : "A day full of new tricks from this guy http://t.co/shWLKYs5",
  "id" : 174333052300955648,
  "created_at" : "2012-02-28 03:20:13 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tumblr.com/\" rel=\"nofollow\">Tumblr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "behaviorchange",
      "indices" : [ 47, 62 ]
    } ],
    "urls" : [ {
      "indices" : [ 26, 46 ],
      "url" : "http://t.co/pzyQtaGS",
      "expanded_url" : "http://tmblr.co/ZQJvayH5ZClu",
      "display_url" : "tmblr.co/ZQJvayH5ZClu"
    } ]
  },
  "geo" : { },
  "id_str" : "174326623959650304",
  "text" : "Habits are the new viral: http://t.co/pzyQtaGS #behaviorchange",
  "id" : 174326623959650304,
  "created_at" : "2012-02-28 02:54:40 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Buzz Andersen",
      "screen_name" : "buzz",
      "indices" : [ 81, 86 ],
      "id_str" : "528",
      "id" : 528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "174323987738918912",
  "text" : "What was your first BBS/Internet username? Mine was ignorantuser10. /inspired by @buzz",
  "id" : 174323987738918912,
  "created_at" : "2012-02-28 02:44:12 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "josh",
      "screen_name" : "joshc",
      "indices" : [ 0, 6 ],
      "id_str" : "2015",
      "id" : 2015
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "174308410429415424",
  "in_reply_to_user_id" : 2015,
  "text" : "@joshc For some reason I can't reply to your Tumblr replies on Tumblr. But Google Latitude etc don't have easy APIs to get data back.",
  "id" : 174308410429415424,
  "created_at" : "2012-02-28 01:42:18 +0000",
  "in_reply_to_screen_name" : "joshc",
  "in_reply_to_user_id_str" : "2015",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tumblr.com/\" rel=\"nofollow\">Tumblr</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leo Babauta",
      "screen_name" : "zen_habits",
      "indices" : [ 42, 53 ],
      "id_str" : "15859268",
      "id" : 15859268
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "behaviorchange",
      "indices" : [ 54, 69 ]
    } ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http://t.co/MtnNOuXX",
      "expanded_url" : "http://tmblr.co/ZQJvayH8A7Jj",
      "display_url" : "tmblr.co/ZQJvayH8A7Jj"
    } ]
  },
  "geo" : { },
  "id_str" : "174221974543941632",
  "text" : "Learn to pause: http://t.co/MtnNOuXX /via @zen_habits #behaviorchange",
  "id" : 174221974543941632,
  "created_at" : "2012-02-27 19:58:50 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Santangelo",
      "screen_name" : "endquote",
      "indices" : [ 0, 9 ],
      "id_str" : "408",
      "id" : 408
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "174213871949721601",
  "geo" : { },
  "id_str" : "174214578920620032",
  "in_reply_to_user_id" : 408,
  "text" : "@endquote Let me know what it is if you remember it!",
  "id" : 174214578920620032,
  "in_reply_to_status_id" : 174213871949721601,
  "created_at" : "2012-02-27 19:29:27 +0000",
  "in_reply_to_screen_name" : "endquote",
  "in_reply_to_user_id_str" : "408",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Santangelo",
      "screen_name" : "endquote",
      "indices" : [ 0, 9 ],
      "id_str" : "408",
      "id" : 408
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "174213871949721601",
  "geo" : { },
  "id_str" : "174214465343062016",
  "in_reply_to_user_id" : 408,
  "text" : "@endquote Hmm\u2026 I don't think I do know of that one. Sounds vaguely like EpicWinApp, but for health? Nike+ is sorta like that too...",
  "id" : 174214465343062016,
  "in_reply_to_status_id" : 174213871949721601,
  "created_at" : "2012-02-27 19:28:59 +0000",
  "in_reply_to_screen_name" : "endquote",
  "in_reply_to_user_id_str" : "408",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Arrington",
      "screen_name" : "arrington",
      "indices" : [ 3, 13 ],
      "id_str" : "37570179",
      "id" : 37570179
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 74 ],
      "url" : "http://t.co/bJ9GMZKi",
      "expanded_url" : "http://www.avc.com/a_vc/2012/02/whats-wrong-with-traditional-media.html",
      "display_url" : "avc.com/a_vc/2012/02/w\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "174214259692154881",
  "text" : "RT @arrington: What's Wrong With Sensationalist Media http://t.co/bJ9GMZKi",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 39, 59 ],
        "url" : "http://t.co/bJ9GMZKi",
        "expanded_url" : "http://www.avc.com/a_vc/2012/02/whats-wrong-with-traditional-media.html",
        "display_url" : "avc.com/a_vc/2012/02/w\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "174213262819344386",
    "text" : "What's Wrong With Sensationalist Media http://t.co/bJ9GMZKi",
    "id" : 174213262819344386,
    "created_at" : "2012-02-27 19:24:13 +0000",
    "user" : {
      "name" : "Michael Arrington",
      "screen_name" : "arrington",
      "protected" : false,
      "id_str" : "37570179",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3439210570/43ecb9359319ef753f0b4157104d8d14_normal.png",
      "id" : 37570179,
      "verified" : true
    }
  },
  "id" : 174214259692154881,
  "created_at" : "2012-02-27 19:28:10 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tumblr.com/\" rel=\"nofollow\">Tumblr</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Foursquare",
      "screen_name" : "foursquare",
      "indices" : [ 53, 64 ],
      "id_str" : "14120151",
      "id" : 14120151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 92 ],
      "url" : "http://t.co/lx1KRhx2",
      "expanded_url" : "http://tmblr.co/ZQJvayH7ybyP",
      "display_url" : "tmblr.co/ZQJvayH7ybyP"
    } ]
  },
  "geo" : { },
  "id_str" : "174200095158439936",
  "text" : "Initial thoughts on combining openpaths.cc data with @foursquare's api: http://t.co/lx1KRhx2",
  "id" : 174200095158439936,
  "created_at" : "2012-02-27 18:31:53 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Susannah Fox",
      "screen_name" : "SusannahFox",
      "indices" : [ 0, 12 ],
      "id_str" : "17843236",
      "id" : 17843236
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "174193558163693568",
  "geo" : { },
  "id_str" : "174194362723483649",
  "in_reply_to_user_id" : 17843236,
  "text" : "@SusannahFox I am now! Thanks.",
  "id" : 174194362723483649,
  "in_reply_to_status_id" : 174193558163693568,
  "created_at" : "2012-02-27 18:09:07 +0000",
  "in_reply_to_screen_name" : "SusannahFox",
  "in_reply_to_user_id_str" : "17843236",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tumblr.com/\" rel=\"nofollow\">Tumblr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "motivation",
      "indices" : [ 55, 66 ]
    } ],
    "urls" : [ {
      "indices" : [ 34, 54 ],
      "url" : "http://t.co/iPE5DUG3",
      "expanded_url" : "http://tmblr.co/ZQJvayH7t-Eq",
      "display_url" : "tmblr.co/ZQJvayH7t-Eq"
    } ]
  },
  "geo" : { },
  "id_str" : "174192100273963009",
  "text" : "A shotgun approach to motivation: http://t.co/iPE5DUG3 #motivation",
  "id" : 174192100273963009,
  "created_at" : "2012-02-27 18:00:07 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Susannah Fox",
      "screen_name" : "SusannahFox",
      "indices" : [ 0, 12 ],
      "id_str" : "17843236",
      "id" : 17843236
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "174184381924122626",
  "geo" : { },
  "id_str" : "174185946105921537",
  "in_reply_to_user_id" : 17843236,
  "text" : "@SusannahFox Ha. I think I just woke up on the wrong side of the bed. Wishing informed smart articles could compete with sensationalism.",
  "id" : 174185946105921537,
  "in_reply_to_status_id" : 174184381924122626,
  "created_at" : "2012-02-27 17:35:40 +0000",
  "in_reply_to_screen_name" : "SusannahFox",
  "in_reply_to_user_id_str" : "17843236",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "174182415533748224",
  "text" : "We need a bullshit button.",
  "id" : 174182415533748224,
  "created_at" : "2012-02-27 17:21:38 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "174175848138686464",
  "text" : "Gotta love the experts who swarm in on the latest successful businesses and translate their brilliant secrets for the rest of us.",
  "id" : 174175848138686464,
  "created_at" : "2012-02-27 16:55:32 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tumblr.com/\" rel=\"nofollow\">Tumblr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "globalbrain",
      "indices" : [ 40, 52 ]
    } ],
    "urls" : [ {
      "indices" : [ 19, 39 ],
      "url" : "http://t.co/fKJEgY5f",
      "expanded_url" : "http://tmblr.co/ZQJvayH7ahKr",
      "display_url" : "tmblr.co/ZQJvayH7ahKr"
    } ]
  },
  "geo" : { },
  "id_str" : "174153556960620544",
  "text" : "Humans and neurons http://t.co/fKJEgY5f #globalbrain",
  "id" : 174153556960620544,
  "created_at" : "2012-02-27 15:26:58 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Dean",
      "screen_name" : "dandean",
      "indices" : [ 0, 8 ],
      "id_str" : "9525212",
      "id" : 9525212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "174010840620605440",
  "geo" : { },
  "id_str" : "174015842869198849",
  "in_reply_to_user_id" : 9525212,
  "text" : "@dandean It IS awesome. Though there are a lot of things that could be even better about it, I'm finding.",
  "id" : 174015842869198849,
  "in_reply_to_status_id" : 174010840620605440,
  "created_at" : "2012-02-27 06:19:44 +0000",
  "in_reply_to_screen_name" : "dandean",
  "in_reply_to_user_id_str" : "9525212",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dennis Crowley",
      "screen_name" : "dens",
      "indices" : [ 0, 5 ],
      "id_str" : "418",
      "id" : 418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "174008523385094144",
  "geo" : { },
  "id_str" : "174008800343375872",
  "in_reply_to_user_id" : 418,
  "text" : "@dens For sure! Will write it up in my tumblr if anything interesting comes out of it.",
  "id" : 174008800343375872,
  "in_reply_to_status_id" : 174008523385094144,
  "created_at" : "2012-02-27 05:51:45 +0000",
  "in_reply_to_screen_name" : "dens",
  "in_reply_to_user_id_str" : "418",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Foursquare",
      "screen_name" : "foursquare",
      "indices" : [ 45, 56 ],
      "id_str" : "14120151",
      "id" : 14120151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 84 ],
      "url" : "http://t.co/fLXgbIDb",
      "expanded_url" : "http://flic.kr/p/bkQtGd",
      "display_url" : "flic.kr/p/bkQtGd"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.608666, -122.306167 ]
  },
  "id_str" : "174004637383409665",
  "text" : "8:36pm Playing around with an openpaths.cc + @foursquare mashup http://t.co/fLXgbIDb",
  "id" : 174004637383409665,
  "created_at" : "2012-02-27 05:35:13 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hunter Walk",
      "screen_name" : "hunterwalk",
      "indices" : [ 3, 14 ],
      "id_str" : "46063",
      "id" : 46063
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OccupyOscars",
      "indices" : [ 101, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "173953339116109824",
  "text" : "RT @hunterwalk: The 5,765 person Oscar voting committee is 94% white, 77% male & 86% age 50 or older #OccupyOscars",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "OccupyOscars",
        "indices" : [ 85, 98 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "173873692487593984",
    "text" : "The 5,765 person Oscar voting committee is 94% white, 77% male & 86% age 50 or older #OccupyOscars",
    "id" : 173873692487593984,
    "created_at" : "2012-02-26 20:54:53 +0000",
    "user" : {
      "name" : "Hunter Walk",
      "screen_name" : "hunterwalk",
      "protected" : false,
      "id_str" : "46063",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3530636661/448f950491b7c174df124e6ce8d7ba79_normal.png",
      "id" : 46063,
      "verified" : false
    }
  },
  "id" : 173953339116109824,
  "created_at" : "2012-02-27 02:11:22 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kellan",
      "screen_name" : "kellan",
      "indices" : [ 0, 7 ],
      "id_str" : "47",
      "id" : 47
    }, {
      "name" : "Ryan King",
      "screen_name" : "rk",
      "indices" : [ 8, 11 ],
      "id_str" : "19853",
      "id" : 19853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "173929866197086210",
  "geo" : { },
  "id_str" : "173933204720459777",
  "in_reply_to_user_id" : 47,
  "text" : "@kellan @rk I'm pretty sure you can't. I'm not explaining it well. I want a filtered stream of the \"best\" tweets by people I follow.",
  "id" : 173933204720459777,
  "in_reply_to_status_id" : 173929866197086210,
  "created_at" : "2012-02-27 00:51:22 +0000",
  "in_reply_to_screen_name" : "kellan",
  "in_reply_to_user_id_str" : "47",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan King",
      "screen_name" : "rk",
      "indices" : [ 0, 3 ],
      "id_str" : "19853",
      "id" : 19853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "173925418322247681",
  "geo" : { },
  "id_str" : "173927330677403648",
  "in_reply_to_user_id" : 19853,
  "text" : "@rk I'm looking to filter my timeline to only show the favorited/retweeted tweets\u2026 not to get favorites/retweets from people I follow.",
  "id" : 173927330677403648,
  "in_reply_to_status_id" : 173925418322247681,
  "created_at" : "2012-02-27 00:28:01 +0000",
  "in_reply_to_screen_name" : "rk",
  "in_reply_to_user_id_str" : "19853",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Ritchie",
      "screen_name" : "mattritchie",
      "indices" : [ 0, 12 ],
      "id_str" : "8299212",
      "id" : 8299212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "173894746606022658",
  "geo" : { },
  "id_str" : "173895514700529665",
  "in_reply_to_user_id" : 8299212,
  "text" : "@mattritchie I see the option to see retweets by people I follow. But what about\u2026 which tweets by people I follow have been retweeted?",
  "id" : 173895514700529665,
  "in_reply_to_status_id" : 173894746606022658,
  "created_at" : "2012-02-26 22:21:36 +0000",
  "in_reply_to_screen_name" : "mattritchie",
  "in_reply_to_user_id_str" : "8299212",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "R\u014Dbin Layfield",
      "screen_name" : "robinlayfield",
      "indices" : [ 0, 14 ],
      "id_str" : "14140557",
      "id" : 14140557
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "173890098784514049",
  "geo" : { },
  "id_str" : "173890528830697473",
  "in_reply_to_user_id" : 14140557,
  "text" : "@robinlayfield Thanks for the invite! Definitely looks cool, but it's not exactly what I was looking for. I want popular tweets, not links.",
  "id" : 173890528830697473,
  "in_reply_to_status_id" : 173890098784514049,
  "created_at" : "2012-02-26 22:01:47 +0000",
  "in_reply_to_screen_name" : "robinlayfield",
  "in_reply_to_user_id_str" : "14140557",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "R\u014Dbin Layfield",
      "screen_name" : "robinlayfield",
      "indices" : [ 0, 14 ],
      "id_str" : "14140557",
      "id" : 14140557
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "173887885907460096",
  "geo" : { },
  "id_str" : "173888006187520001",
  "in_reply_to_user_id" : 14140557,
  "text" : "@robinlayfield busterbenson at gmail. Thank you!",
  "id" : 173888006187520001,
  "in_reply_to_status_id" : 173887885907460096,
  "created_at" : "2012-02-26 21:51:46 +0000",
  "in_reply_to_screen_name" : "robinlayfield",
  "in_reply_to_user_id_str" : "14140557",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "R\u014Dbin Layfield",
      "screen_name" : "robinlayfield",
      "indices" : [ 0, 14 ],
      "id_str" : "14140557",
      "id" : 14140557
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "173886744087887872",
  "geo" : { },
  "id_str" : "173887610958258176",
  "in_reply_to_user_id" : 14140557,
  "text" : "@robinlayfield That looks awesome! Have an extra invite?",
  "id" : 173887610958258176,
  "in_reply_to_status_id" : 173886744087887872,
  "created_at" : "2012-02-26 21:50:11 +0000",
  "in_reply_to_screen_name" : "robinlayfield",
  "in_reply_to_user_id_str" : "14140557",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Coates",
      "screen_name" : "tomcoates",
      "indices" : [ 0, 10 ],
      "id_str" : "12514",
      "id" : 12514
    }, {
      "name" : "Jason Kottke",
      "screen_name" : "jkottke",
      "indices" : [ 108, 116 ],
      "id_str" : "1305941",
      "id" : 1305941
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "173885395799506944",
  "geo" : { },
  "id_str" : "173886046403182592",
  "in_reply_to_user_id" : 12514,
  "text" : "@tomcoates Yeah! What did he say? Why not build it? It'd probably make good money as an iPhone app. /paging @jkottke",
  "id" : 173886046403182592,
  "in_reply_to_status_id" : 173885395799506944,
  "created_at" : "2012-02-26 21:43:58 +0000",
  "in_reply_to_screen_name" : "tomcoates",
  "in_reply_to_user_id_str" : "12514",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "173884501745872896",
  "text" : "Has anyone built a filter for Twitter to only show the tweets that were favorited, replied to, or retweeted? For times when I fall behind?",
  "id" : 173884501745872896,
  "created_at" : "2012-02-26 21:37:50 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Esther Dyson",
      "screen_name" : "edyson",
      "indices" : [ 3, 10 ],
      "id_str" : "15921173",
      "id" : 15921173
    }, {
      "name" : "The Guardian",
      "screen_name" : "guardian",
      "indices" : [ 67, 76 ],
      "id_str" : "87818409",
      "id" : 87818409
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 62 ],
      "url" : "http://t.co/9GpKPMJg",
      "expanded_url" : "http://gu.com/p/35kc2/tw",
      "display_url" : "gu.com/p/35kc2/tw"
    } ]
  },
  "geo" : { },
  "id_str" : "173859150302941184",
  "text" : "RT @edyson: The true fathers of computing http://t.co/9GpKPMJg via @guardian intvw v George Dyson about Turing's Cathedral",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Guardian",
        "screen_name" : "guardian",
        "indices" : [ 55, 64 ],
        "id_str" : "87818409",
        "id" : 87818409
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 30, 50 ],
        "url" : "http://t.co/9GpKPMJg",
        "expanded_url" : "http://gu.com/p/35kc2/tw",
        "display_url" : "gu.com/p/35kc2/tw"
      } ]
    },
    "geo" : { },
    "id_str" : "173849666557972481",
    "text" : "The true fathers of computing http://t.co/9GpKPMJg via @guardian intvw v George Dyson about Turing's Cathedral",
    "id" : 173849666557972481,
    "created_at" : "2012-02-26 19:19:25 +0000",
    "user" : {
      "name" : "Esther Dyson",
      "screen_name" : "edyson",
      "protected" : false,
      "id_str" : "15921173",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/58744051/DSC_0336_proof1_normal.jpg",
      "id" : 15921173,
      "verified" : false
    }
  },
  "id" : 173859150302941184,
  "created_at" : "2012-02-26 19:57:06 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tumblr.com/\" rel=\"nofollow\">Tumblr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 105 ],
      "url" : "http://t.co/7JviS5Fx",
      "expanded_url" : "http://tmblr.co/ZQJvayH4EvJg",
      "display_url" : "tmblr.co/ZQJvayH4EvJg"
    } ]
  },
  "geo" : { },
  "id_str" : "173831082771361792",
  "text" : "Photo: stitchtagram: Gonna make sure this picture is on my next stitchtagram pillow. http://t.co/7JviS5Fx",
  "id" : 173831082771361792,
  "created_at" : "2012-02-26 18:05:34 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachel pfeffer",
      "screen_name" : "Rachel_pfeffer",
      "indices" : [ 0, 15 ],
      "id_str" : "17981363",
      "id" : 17981363
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "173803185704677376",
  "geo" : { },
  "id_str" : "173805958135431168",
  "in_reply_to_user_id" : 17981363,
  "text" : "@Rachel_pfeffer Of course! Can you get it from Instagram or do you need us to send the file over?",
  "id" : 173805958135431168,
  "in_reply_to_status_id" : 173803185704677376,
  "created_at" : "2012-02-26 16:25:44 +0000",
  "in_reply_to_screen_name" : "Rachel_pfeffer",
  "in_reply_to_user_id_str" : "17981363",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 68 ],
      "url" : "http://t.co/tv0E4nJW",
      "expanded_url" : "http://instagr.am/p/HdMwpII0Bd/",
      "display_url" : "instagr.am/p/HdMwpII0Bd/"
    } ]
  },
  "geo" : { },
  "id_str" : "173632695107194881",
  "text" : "8:36pm Closest I've gotten to thumbs up so far! http://t.co/tv0E4nJW",
  "id" : 173632695107194881,
  "created_at" : "2012-02-26 04:57:15 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "harryh",
      "screen_name" : "harryh",
      "indices" : [ 0, 7 ],
      "id_str" : "4558",
      "id" : 4558
    }, {
      "name" : "Stellar",
      "screen_name" : "yo_stellar",
      "indices" : [ 26, 37 ],
      "id_str" : "180817904",
      "id" : 180817904
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 101 ],
      "url" : "http://t.co/fVhDQfZ1",
      "expanded_url" : "http://stellar.io/busterbenson",
      "display_url" : "stellar.io/busterbenson"
    } ]
  },
  "in_reply_to_status_id_str" : "173602281512636416",
  "geo" : { },
  "id_str" : "173602632018038785",
  "in_reply_to_user_id" : 4558,
  "text" : "@harryh Want an invite to @yo_stellar? It's pretty sweet, and does exactly that. http://t.co/fVhDQfZ1",
  "id" : 173602632018038785,
  "in_reply_to_status_id" : 173602281512636416,
  "created_at" : "2012-02-26 02:57:47 +0000",
  "in_reply_to_screen_name" : "harryh",
  "in_reply_to_user_id_str" : "4558",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Wright",
      "screen_name" : "webwright",
      "indices" : [ 3, 13 ],
      "id_str" : "786818",
      "id" : 786818
    }, {
      "name" : "Anti-Buster",
      "screen_name" : "busterbenson",
      "indices" : [ 15, 28 ],
      "id_str" : "1024917050",
      "id" : 1024917050
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "173600042408620032",
  "text" : "RT @webwright: @busterbenson Favorite Steve Jobs quote: \"Don't waste your time living someone else's life.\" We spend way too much time c ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Anti-Buster",
        "screen_name" : "busterbenson",
        "indices" : [ 0, 13 ],
        "id_str" : "1024917050",
        "id" : 1024917050
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "173584054229270530",
    "geo" : { },
    "id_str" : "173599865660649472",
    "in_reply_to_user_id" : 2185,
    "text" : "@busterbenson Favorite Steve Jobs quote: \"Don't waste your time living someone else's life.\" We spend way too much time climbing for others.",
    "id" : 173599865660649472,
    "in_reply_to_status_id" : 173584054229270530,
    "created_at" : "2012-02-26 02:46:47 +0000",
    "in_reply_to_screen_name" : "buster",
    "in_reply_to_user_id_str" : "2185",
    "user" : {
      "name" : "Tony Wright",
      "screen_name" : "webwright",
      "protected" : false,
      "id_str" : "786818",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000106343055/1d532c4e1ba53b3d5acc4568b21f2df1_normal.jpeg",
      "id" : 786818,
      "verified" : false
    }
  },
  "id" : 173600042408620032,
  "created_at" : "2012-02-26 02:47:30 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marina Martin",
      "screen_name" : "MarinaMartin",
      "indices" : [ 0, 13 ],
      "id_str" : "60663",
      "id" : 60663
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "173588920276226048",
  "geo" : { },
  "id_str" : "173590142102142976",
  "in_reply_to_user_id" : 60663,
  "text" : "@MarinaMartin That's definitely a more positive spin on it.",
  "id" : 173590142102142976,
  "in_reply_to_status_id" : 173588920276226048,
  "created_at" : "2012-02-26 02:08:09 +0000",
  "in_reply_to_screen_name" : "MarinaMartin",
  "in_reply_to_user_id_str" : "60663",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Rainert",
      "screen_name" : "arainert",
      "indices" : [ 0, 9 ],
      "id_str" : "7482",
      "id" : 7482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "173587653768380416",
  "geo" : { },
  "id_str" : "173588506160005120",
  "in_reply_to_user_id" : 7482,
  "text" : "@arainert I'm just a sucker for the latest cool app. :) No Austin for me this year unfortunately\u2026 it's all work and no play over here.",
  "id" : 173588506160005120,
  "in_reply_to_status_id" : 173587653768380416,
  "created_at" : "2012-02-26 02:01:39 +0000",
  "in_reply_to_screen_name" : "arainert",
  "in_reply_to_user_id_str" : "7482",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "173584054229270530",
  "text" : "What % of our fears can be traced back to the fear of disappointing someone who A) may or may not even be alive or B) care about us?",
  "id" : 173584054229270530,
  "created_at" : "2012-02-26 01:43:58 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Rainert",
      "screen_name" : "arainert",
      "indices" : [ 0, 9 ],
      "id_str" : "7482",
      "id" : 7482
    }, {
      "name" : "SparrowMail",
      "screen_name" : "sparrow",
      "indices" : [ 97, 105 ],
      "id_str" : "163449492",
      "id" : 163449492
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nofair",
      "indices" : [ 85, 92 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "173583533749714945",
  "geo" : { },
  "id_str" : "173583995173474304",
  "in_reply_to_user_id" : 7482,
  "text" : "@arainert You made me just search for it, but I see now you're using a private beta? #nofair /cc @sparrow",
  "id" : 173583995173474304,
  "in_reply_to_status_id" : 173583533749714945,
  "created_at" : "2012-02-26 01:43:44 +0000",
  "in_reply_to_screen_name" : "arainert",
  "in_reply_to_user_id_str" : "7482",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "doug pfeffer",
      "screen_name" : "pfeffunit",
      "indices" : [ 0, 10 ],
      "id_str" : "16001452",
      "id" : 16001452
    }, {
      "name" : "Rachel pfeffer",
      "screen_name" : "Rachel_pfeffer",
      "indices" : [ 11, 26 ],
      "id_str" : "17981363",
      "id" : 17981363
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "173523881750044672",
  "geo" : { },
  "id_str" : "173582087297830912",
  "in_reply_to_user_id" : 16001452,
  "text" : "@pfeffunit @rachel_pfeffer We *love* the pillow. Gonna be ordering more in the next couple days, too!",
  "id" : 173582087297830912,
  "in_reply_to_status_id" : 173523881750044672,
  "created_at" : "2012-02-26 01:36:09 +0000",
  "in_reply_to_screen_name" : "pfeffunit",
  "in_reply_to_user_id_str" : "16001452",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "globalbrain",
      "indices" : [ 63, 75 ]
    } ],
    "urls" : [ {
      "indices" : [ 42, 62 ],
      "url" : "http://t.co/jz53dimn",
      "expanded_url" : "http://bustr.tumblr.com/post/18281108589/daydream-about-the-global-brain",
      "display_url" : "bustr.tumblr.com/post/182811085\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "173562809672675328",
  "text" : "Saturday daydream about the global brain: http://t.co/jz53dimn #globalbrain",
  "id" : 173562809672675328,
  "created_at" : "2012-02-26 00:19:33 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/instagram/id389801252?mt=8&uo=4\" rel=\"nofollow\">Instagram on iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 58, 68 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 52 ],
      "url" : "http://t.co/dg0egmH8",
      "expanded_url" : "http://instagr.am/p/Hb65bsuFU3/",
      "display_url" : "instagr.am/p/Hb65bsuFU3/"
    } ]
  },
  "geo" : { },
  "id_str" : "173513219640541184",
  "text" : "Our \"I'm going to work\" routine http://t.co/dg0egmH8 /via @kellianne",
  "id" : 173513219640541184,
  "created_at" : "2012-02-25 21:02:29 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u24D5\u24E3",
      "screen_name" : "folktrash",
      "indices" : [ 0, 10 ],
      "id_str" : "15265271",
      "id" : 15265271
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 73 ],
      "url" : "http://t.co/aH0EFtad",
      "expanded_url" : "http://status.heroku.com",
      "display_url" : "status.heroku.com"
    } ]
  },
  "in_reply_to_status_id_str" : "173485734118965248",
  "geo" : { },
  "id_str" : "173487060433383424",
  "in_reply_to_user_id" : 15265271,
  "text" : "@folktrash Looks like heroku is having some trouble. http://t.co/aH0EFtad Hope to be back up soon.",
  "id" : 173487060433383424,
  "in_reply_to_status_id" : 173485734118965248,
  "created_at" : "2012-02-25 19:18:33 +0000",
  "in_reply_to_screen_name" : "folktrash",
  "in_reply_to_user_id_str" : "15265271",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u24D5\u24E3",
      "screen_name" : "folktrash",
      "indices" : [ 0, 10 ],
      "id_str" : "15265271",
      "id" : 15265271
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "173485734118965248",
  "geo" : { },
  "id_str" : "173486212642897920",
  "in_reply_to_user_id" : 15265271,
  "text" : "@folktrash Looking into it\u2026",
  "id" : 173486212642897920,
  "in_reply_to_status_id" : 173485734118965248,
  "created_at" : "2012-02-25 19:15:10 +0000",
  "in_reply_to_screen_name" : "folktrash",
  "in_reply_to_user_id_str" : "15265271",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 42 ],
      "url" : "http://t.co/crpiu7lV",
      "expanded_url" : "http://flic.kr/p/bkfry1",
      "display_url" : "flic.kr/p/bkfry1"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.608666, -122.306167 ]
  },
  "id_str" : "173265999137734656",
  "text" : "8:36pm Feet and legs. http://t.co/crpiu7lV",
  "id" : 173265999137734656,
  "created_at" : "2012-02-25 04:40:07 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "honor harger",
      "screen_name" : "honorharger",
      "indices" : [ 3, 15 ],
      "id_str" : "29941998",
      "id" : 29941998
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "173083442773377024",
  "text" : "RT @honorharger: We now continuously having to prove we're human on the internet. This is not how Turing thought it was going to work -  ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "James Bridle",
        "screen_name" : "jamesbridle",
        "indices" : [ 120, 132 ],
        "id_str" : "187512368",
        "id" : 187512368
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "lift12",
        "indices" : [ 133, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "172995078804078592",
    "text" : "We now continuously having to prove we're human on the internet. This is not how Turing thought it was going to work -  @jamesbridle #lift12",
    "id" : 172995078804078592,
    "created_at" : "2012-02-24 10:43:35 +0000",
    "user" : {
      "name" : "honor harger",
      "screen_name" : "honorharger",
      "protected" : false,
      "id_str" : "29941998",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1767440114/hh_twitter_normal.jpg",
      "id" : 29941998,
      "verified" : false
    }
  },
  "id" : 173083442773377024,
  "created_at" : "2012-02-24 16:34:43 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 76 ],
      "url" : "http://t.co/I2E7LRCT",
      "expanded_url" : "http://flic.kr/p/bxWT6i",
      "display_url" : "flic.kr/p/bxWT6i"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.608666, -122.306 ]
  },
  "id_str" : "172942553556070400",
  "text" : "8:36pm Trying to figure out where all of my energy went http://t.co/I2E7LRCT",
  "id" : 172942553556070400,
  "created_at" : "2012-02-24 07:14:52 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 80 ],
      "url" : "http://t.co/ATac710l",
      "expanded_url" : "http://flic.kr/p/bxW9ce",
      "display_url" : "flic.kr/p/bxW9ce"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.608, -122.3 ]
  },
  "id_str" : "172917115689512960",
  "text" : "8:36pm Happy to be home and showered and hanging with wifey http://t.co/ATac710l",
  "id" : 172917115689512960,
  "created_at" : "2012-02-24 05:33:47 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Fox",
      "screen_name" : "heychrisfox",
      "indices" : [ 0, 12 ],
      "id_str" : "9354282",
      "id" : 9354282
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "172835750470107136",
  "geo" : { },
  "id_str" : "172836080175951872",
  "in_reply_to_user_id" : 9354282,
  "text" : "@heychrisfox How did you become a great writer?",
  "id" : 172836080175951872,
  "in_reply_to_status_id" : 172835750470107136,
  "created_at" : "2012-02-24 00:11:47 +0000",
  "in_reply_to_screen_name" : "heychrisfox",
  "in_reply_to_user_id_str" : "9354282",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Fox",
      "screen_name" : "heychrisfox",
      "indices" : [ 0, 12 ],
      "id_str" : "9354282",
      "id" : 9354282
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "172833747656392704",
  "geo" : { },
  "id_str" : "172834211466706944",
  "in_reply_to_user_id" : 9354282,
  "text" : "@heychrisfox Doesn't mastering a skill (like coding, riding a bike, or playing piano) require a habit of practice?",
  "id" : 172834211466706944,
  "in_reply_to_status_id" : 172833747656392704,
  "created_at" : "2012-02-24 00:04:21 +0000",
  "in_reply_to_screen_name" : "heychrisfox",
  "in_reply_to_user_id_str" : "9354282",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "behaviorchange",
      "indices" : [ 116, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "172824057526493185",
  "text" : "If you haven't mastered the ability to change your own habits/behaviors when you want to, what can you ever master? #behaviorchange",
  "id" : 172824057526493185,
  "created_at" : "2012-02-23 23:24:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Hagel",
      "screen_name" : "jhagel",
      "indices" : [ 3, 10 ],
      "id_str" : "14076943",
      "id" : 14076943
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 125 ],
      "url" : "http://t.co/OLhhXe3f",
      "expanded_url" : "http://bit.ly/yHq13E",
      "display_url" : "bit.ly/yHq13E"
    } ]
  },
  "geo" : { },
  "id_str" : "172702151829757955",
  "text" : "RT @jhagel: Everything is connected to everything else - a 100 second explanation by physicist Brian Cox http://t.co/OLhhXe3f",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 113 ],
        "url" : "http://t.co/OLhhXe3f",
        "expanded_url" : "http://bit.ly/yHq13E",
        "display_url" : "bit.ly/yHq13E"
      } ]
    },
    "geo" : { },
    "id_str" : "172700044812746752",
    "text" : "Everything is connected to everything else - a 100 second explanation by physicist Brian Cox http://t.co/OLhhXe3f",
    "id" : 172700044812746752,
    "created_at" : "2012-02-23 15:11:13 +0000",
    "user" : {
      "name" : "John Hagel",
      "screen_name" : "jhagel",
      "protected" : false,
      "id_str" : "14076943",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/60658775/Photos_John1_normal.jpg",
      "id" : 14076943,
      "verified" : false
    }
  },
  "id" : 172702151829757955,
  "created_at" : "2012-02-23 15:19:36 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay Goldman",
      "screen_name" : "jaygoldman",
      "indices" : [ 0, 11 ],
      "id_str" : "861",
      "id" : 861
    }, {
      "name" : "Brad Einarsen",
      "screen_name" : "bradeinarsen",
      "indices" : [ 12, 25 ],
      "id_str" : "15231391",
      "id" : 15231391
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 133 ],
      "url" : "http://t.co/oFUdNcs7",
      "expanded_url" : "http://habitlabs.com",
      "display_url" : "habitlabs.com"
    } ]
  },
  "in_reply_to_status_id_str" : "172519799409213440",
  "geo" : { },
  "id_str" : "172599774233624576",
  "in_reply_to_user_id" : 861,
  "text" : "@jaygoldman @bradeinarsen Thanks for the intro, Jay! Brad, I'd love to help however I can\u2026 my email is buster at http://t.co/oFUdNcs7.",
  "id" : 172599774233624576,
  "in_reply_to_status_id" : 172519799409213440,
  "created_at" : "2012-02-23 08:32:47 +0000",
  "in_reply_to_screen_name" : "jaygoldman",
  "in_reply_to_user_id_str" : "861",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Willo O'Brien",
      "screen_name" : "WilloToons",
      "indices" : [ 0, 11 ],
      "id_str" : "1099629326",
      "id" : 1099629326
    }, {
      "name" : "Aubrey Sabala",
      "screen_name" : "Aubs",
      "indices" : [ 12, 17 ],
      "id_str" : "2781",
      "id" : 2781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "172579939982389248",
  "geo" : { },
  "id_str" : "172593284315746304",
  "in_reply_to_user_id" : 772386,
  "text" : "@willotoons @aubs I am sadly only here until 4pm tomorrow. :( So bummed to be missing out on all the SF fun happening this week.",
  "id" : 172593284315746304,
  "in_reply_to_status_id" : 172579939982389248,
  "created_at" : "2012-02-23 08:07:00 +0000",
  "in_reply_to_screen_name" : "WilloLovesYou",
  "in_reply_to_user_id_str" : "772386",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 62 ],
      "url" : "http://t.co/aN05xNHc",
      "expanded_url" : "http://flic.kr/p/bjNVxf",
      "display_url" : "flic.kr/p/bjNVxf"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.796333, -122.395834 ]
  },
  "id_str" : "172561614485192704",
  "text" : "8:36pm Walking around SF with Jimmy James http://t.co/aN05xNHc",
  "id" : 172561614485192704,
  "created_at" : "2012-02-23 06:01:09 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shane Mac",
      "screen_name" : "ShaneMac",
      "indices" : [ 0, 9 ],
      "id_str" : "44378228",
      "id" : 44378228
    }, {
      "name" : "paigecraig",
      "screen_name" : "paigecraig",
      "indices" : [ 10, 21 ],
      "id_str" : "9976962",
      "id" : 9976962
    }, {
      "name" : "Klout",
      "screen_name" : "klout",
      "indices" : [ 56, 62 ],
      "id_str" : "15134782",
      "id" : 15134782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "172466484793196545",
  "geo" : { },
  "id_str" : "172471595703603200",
  "in_reply_to_user_id" : 44378228,
  "text" : "@ShaneMac @paigecraig I think it's already true! Though @klout has more work to do before it represents true reputation.",
  "id" : 172471595703603200,
  "in_reply_to_status_id" : 172466484793196545,
  "created_at" : "2012-02-23 00:03:27 +0000",
  "in_reply_to_screen_name" : "ShaneMac",
  "in_reply_to_user_id_str" : "44378228",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 104 ],
      "url" : "http://t.co/QqGVvb8a",
      "expanded_url" : "http://4sq.com/yTj0d6",
      "display_url" : "4sq.com/yTj0d6"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.4436465828, -122.3025941849 ]
  },
  "id_str" : "172467305161306112",
  "text" : "SEA -&gt; SFO for a day (@ Seattle-Tacoma International Airport (SEA) w/ 55 others) http://t.co/QqGVvb8a",
  "id" : 172467305161306112,
  "created_at" : "2012-02-22 23:46:24 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.quora.com/\" rel=\"nofollow\">Quora</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Quora",
      "screen_name" : "Quora",
      "indices" : [ 134, 140 ],
      "id_str" : "33696409",
      "id" : 33696409
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 130 ],
      "url" : "http://t.co/pOy0nf6R",
      "expanded_url" : "http://qr.ae/RIwuj",
      "display_url" : "qr.ae/RIwuj"
    } ]
  },
  "geo" : { },
  "id_str" : "172451197662412800",
  "text" : "What are the best estimates for total number of servers powering the Internet, number of new servers\u2026 Answer: http://t.co/pOy0nf6R on @Quora",
  "id" : 172451197662412800,
  "created_at" : "2012-02-22 22:42:24 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Herrmann",
      "screen_name" : "pete",
      "indices" : [ 0, 5 ],
      "id_str" : "14408537",
      "id" : 14408537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "172447910888353792",
  "geo" : { },
  "id_str" : "172450032451203073",
  "in_reply_to_user_id" : 14408537,
  "text" : "@pete Awesome resource! I wonder how # of websites relates to number of servers powering them.",
  "id" : 172450032451203073,
  "in_reply_to_status_id" : 172447910888353792,
  "created_at" : "2012-02-22 22:37:46 +0000",
  "in_reply_to_screen_name" : "pete",
  "in_reply_to_user_id_str" : "14408537",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan King",
      "screen_name" : "rk",
      "indices" : [ 0, 3 ],
      "id_str" : "19853",
      "id" : 19853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "172444472519565314",
  "geo" : { },
  "id_str" : "172447102645972992",
  "in_reply_to_user_id" : 19853,
  "text" : "@rk Ah good call. As a pure Quora consumer I never considered asking a question.",
  "id" : 172447102645972992,
  "in_reply_to_status_id" : 172444472519565314,
  "created_at" : "2012-02-22 22:26:07 +0000",
  "in_reply_to_screen_name" : "rk",
  "in_reply_to_user_id_str" : "19853",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bucket List Society",
      "screen_name" : "bucketlistsoc",
      "indices" : [ 0, 14 ],
      "id_str" : "452619716",
      "id" : 452619716
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "172442475657572353",
  "geo" : { },
  "id_str" : "172443322634338304",
  "in_reply_to_user_id" : 452619716,
  "text" : "@bucketlistsoc My time-traveling friend needs to know!",
  "id" : 172443322634338304,
  "in_reply_to_status_id" : 172442475657572353,
  "created_at" : "2012-02-22 22:11:06 +0000",
  "in_reply_to_screen_name" : "bucketlistsoc",
  "in_reply_to_user_id_str" : "452619716",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "172439587078156288",
  "text" : "What's the best estimate for: \n\n1) Total # of servers that make up the internet \n\n2) # of new servers added to the internet per day",
  "id" : 172439587078156288,
  "created_at" : "2012-02-22 21:56:15 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/pixel-pix/id501717166?mt=8&uo=4\" rel=\"nofollow\">Pixel Pix on iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Brown",
      "screen_name" : "benbrown",
      "indices" : [ 8, 17 ],
      "id_str" : "9027",
      "id" : 9027
    }, {
      "name" : "PixelPix",
      "screen_name" : "pixelpixapp",
      "indices" : [ 32, 44 ],
      "id_str" : "481511811",
      "id" : 481511811
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/buster/status/172373980945203200/photo/1",
      "indices" : [ 77, 97 ],
      "url" : "http://t.co/canxFR7n",
      "media_url" : "http://pbs.twimg.com/media/AmRlOO8CQAAMWt6.jpg",
      "id_str" : "172373980949397504",
      "id" : 172373980949397504,
      "media_url_https" : "https://pbs.twimg.com/media/AmRlOO8CQAAMWt6.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 300
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 300
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 300
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 300
      } ],
      "display_url" : "pic.twitter.com/canxFR7n"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "172373980945203200",
  "text" : "Testing @benbrown's awesome new @PixelPixApp. It's free right now... get it! http://t.co/canxFR7n",
  "id" : 172373980945203200,
  "created_at" : "2012-02-22 17:35:34 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Buffington",
      "screen_name" : "go",
      "indices" : [ 0, 3 ],
      "id_str" : "2984",
      "id" : 2984
    }, {
      "name" : "kellan",
      "screen_name" : "kellan",
      "indices" : [ 4, 11 ],
      "id_str" : "47",
      "id" : 47
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "172363061372534784",
  "geo" : { },
  "id_str" : "172363297063051264",
  "in_reply_to_user_id" : 2984,
  "text" : "@go @kellan What do you like most about it?",
  "id" : 172363297063051264,
  "in_reply_to_status_id" : 172363061372534784,
  "created_at" : "2012-02-22 16:53:07 +0000",
  "in_reply_to_screen_name" : "go",
  "in_reply_to_user_id_str" : "2984",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 76 ],
      "url" : "http://t.co/E0Pdfzg3",
      "expanded_url" : "http://flic.kr/p/bjxzxW",
      "display_url" : "flic.kr/p/bjxzxW"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6175, -122.326667 ]
  },
  "id_str" : "172179133986635777",
  "text" : "8:36pm Talking about old friends and things that happen http://t.co/E0Pdfzg3",
  "id" : 172179133986635777,
  "created_at" : "2012-02-22 04:41:19 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ron Diver",
      "screen_name" : "rondiver",
      "indices" : [ 66, 75 ],
      "id_str" : "12661782",
      "id" : 12661782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 128 ],
      "url" : "http://t.co/ywgy8ZDH",
      "expanded_url" : "http://bit.ly/zl1a7t",
      "display_url" : "bit.ly/zl1a7t"
    } ]
  },
  "geo" : { },
  "id_str" : "172158918523498498",
  "text" : "Please welcome our new rulers: algorithms. Just the beginning. RT @rondiver: Computer Game Bot Turing Test. http://t.co/ywgy8ZDH",
  "id" : 172158918523498498,
  "created_at" : "2012-02-22 03:20:59 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcelo Calbucci",
      "screen_name" : "calbucci",
      "indices" : [ 0, 9 ],
      "id_str" : "14232711",
      "id" : 14232711
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "172129411393519617",
  "geo" : { },
  "id_str" : "172137327991324672",
  "in_reply_to_user_id" : 14232711,
  "text" : "@calbucci Me too!",
  "id" : 172137327991324672,
  "in_reply_to_status_id" : 172129411393519617,
  "created_at" : "2012-02-22 01:55:11 +0000",
  "in_reply_to_screen_name" : "calbucci",
  "in_reply_to_user_id_str" : "14232711",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The New York Times",
      "screen_name" : "nytimes",
      "indices" : [ 15, 23 ],
      "id_str" : "807095",
      "id" : 807095
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 98 ],
      "url" : "http://t.co/Dyo5WmDz",
      "expanded_url" : "http://nyti.ms/z3RPnv",
      "display_url" : "nyti.ms/z3RPnv"
    } ]
  },
  "geo" : { },
  "id_str" : "172129062112862209",
  "text" : "Holy moley! RT @nytimes Google to Sell Heads-Up Display Glasses by Year's End http://t.co/Dyo5WmDz",
  "id" : 172129062112862209,
  "created_at" : "2012-02-22 01:22:21 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim O'Reilly",
      "screen_name" : "timoreilly",
      "indices" : [ 14, 25 ],
      "id_str" : "2384071",
      "id" : 2384071
    }, {
      "name" : "Word Spy",
      "screen_name" : "wordspy",
      "indices" : [ 127, 135 ],
      "id_str" : "15021155",
      "id" : 15021155
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 126 ],
      "url" : "http://t.co/wYR9RDhp",
      "expanded_url" : "http://www.wordspy.com/words/nomophobia.asp",
      "display_url" : "wordspy.com/words/nomophob\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "172025902694281216",
  "text" : "It's real! RT @timoreilly: nomophobia: Fear of being without a mobile phone or without a cellular signal. http://t.co/wYR9RDhp @wordspy",
  "id" : 172025902694281216,
  "created_at" : "2012-02-21 18:32:25 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amelia Greenhall",
      "screen_name" : "ameliagreenhall",
      "indices" : [ 3, 19 ],
      "id_str" : "246531241",
      "id" : 246531241
    }, {
      "name" : "Anti-Buster",
      "screen_name" : "busterbenson",
      "indices" : [ 44, 57 ],
      "id_str" : "1024917050",
      "id" : 1024917050
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "171804625693982720",
  "text" : "RT @ameliagreenhall: Pitching a new idea to @busterbenson and his response: \"reminds me of peter in the new testament.\"",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Anti-Buster",
        "screen_name" : "busterbenson",
        "indices" : [ 23, 36 ],
        "id_str" : "1024917050",
        "id" : 1024917050
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "171727265527369728",
    "text" : "Pitching a new idea to @busterbenson and his response: \"reminds me of peter in the new testament.\"",
    "id" : 171727265527369728,
    "created_at" : "2012-02-20 22:45:45 +0000",
    "user" : {
      "name" : "Amelia Greenhall",
      "screen_name" : "ameliagreenhall",
      "protected" : false,
      "id_str" : "246531241",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000183057643/da88438620af670d8728d2dc19ca3843_normal.jpeg",
      "id" : 246531241,
      "verified" : false
    }
  },
  "id" : 171804625693982720,
  "created_at" : "2012-02-21 03:53:09 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "flow",
      "indices" : [ 119, 124 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 118 ],
      "url" : "http://t.co/AA8bwd2Q",
      "expanded_url" : "http://www.newscientist.com/mobile/article/mg21328501.600-zap-your-brain-into-the-zone-fast-track-to-pure-focus.html",
      "display_url" : "newscientist.com/mobile/article\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "171647402187563009",
  "text" : "Sending electricity through your brain in order to get into a flow state? Crazy, but interesting! http://t.co/AA8bwd2Q #flow",
  "id" : 171647402187563009,
  "created_at" : "2012-02-20 17:28:24 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard Felix",
      "screen_name" : "rfelix",
      "indices" : [ 0, 7 ],
      "id_str" : "665313",
      "id" : 665313
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "171612611207639042",
  "geo" : { },
  "id_str" : "171617392298954753",
  "in_reply_to_user_id" : 665313,
  "text" : "@rfelix That's an inspiring post! Thanks for writing it!",
  "id" : 171617392298954753,
  "in_reply_to_status_id" : 171612611207639042,
  "created_at" : "2012-02-20 15:29:09 +0000",
  "in_reply_to_screen_name" : "rfelix",
  "in_reply_to_user_id_str" : "665313",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "StartupWknd Redmond",
      "screen_name" : "SWRedmond",
      "indices" : [ 3, 13 ],
      "id_str" : "463194878",
      "id" : 463194878
    }, {
      "name" : "carpoolcarma",
      "screen_name" : "carpoolcarma",
      "indices" : [ 38, 51 ],
      "id_str" : "496294664",
      "id" : 496294664
    }, {
      "name" : "peacl\u014D",
      "screen_name" : "peaclo",
      "indices" : [ 56, 63 ],
      "id_str" : "496427835",
      "id" : 496427835
    }, {
      "name" : "Beat Machine",
      "screen_name" : "BM_App",
      "indices" : [ 68, 75 ],
      "id_str" : "496440899",
      "id" : 496440899
    }, {
      "name" : "Save Gramps",
      "screen_name" : "savegramps",
      "indices" : [ 93, 104 ],
      "id_str" : "496290910",
      "id" : 496290910
    }, {
      "name" : "HowBoutCoffee",
      "screen_name" : "HowBoutCoffee",
      "indices" : [ 109, 123 ],
      "id_str" : "496299999",
      "id" : 496299999
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "171497704495656963",
  "text" : "RT @SWRedmond: The results are in! 1: @carpoolcarma, 2: @peaclo, 3: @bm_app. Windows phones: @savegramps and @HowBoutCoffee. Blogs post  ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "carpoolcarma",
        "screen_name" : "carpoolcarma",
        "indices" : [ 23, 36 ],
        "id_str" : "496294664",
        "id" : 496294664
      }, {
        "name" : "peacl\u014D",
        "screen_name" : "peaclo",
        "indices" : [ 41, 48 ],
        "id_str" : "496427835",
        "id" : 496427835
      }, {
        "name" : "Beat Machine",
        "screen_name" : "BM_App",
        "indices" : [ 53, 60 ],
        "id_str" : "496440899",
        "id" : 496440899
      }, {
        "name" : "Save Gramps",
        "screen_name" : "savegramps",
        "indices" : [ 78, 89 ],
        "id_str" : "496290910",
        "id" : 496290910
      }, {
        "name" : "HowBoutCoffee",
        "screen_name" : "HowBoutCoffee",
        "indices" : [ 94, 108 ],
        "id_str" : "496299999",
        "id" : 496299999
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "171496659962957824",
    "text" : "The results are in! 1: @carpoolcarma, 2: @peaclo, 3: @bm_app. Windows phones: @savegramps and @HowBoutCoffee. Blogs post and video soon!",
    "id" : 171496659962957824,
    "created_at" : "2012-02-20 07:29:24 +0000",
    "user" : {
      "name" : "StartupWknd Redmond",
      "screen_name" : "SWRedmond",
      "protected" : false,
      "id_str" : "463194878",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1752811354/swredmond_normal.png",
      "id" : 463194878,
      "verified" : false
    }
  },
  "id" : 171497704495656963,
  "created_at" : "2012-02-20 07:33:33 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Anderson",
      "screen_name" : "RyanAnderson529",
      "indices" : [ 0, 16 ],
      "id_str" : "399110944",
      "id" : 399110944
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "171489084437577728",
  "geo" : { },
  "id_str" : "171497645376942080",
  "in_reply_to_user_id" : 399110944,
  "text" : "@RyanAnderson529 It was fun! Which startup did you join? That's awesome!",
  "id" : 171497645376942080,
  "in_reply_to_status_id" : 171489084437577728,
  "created_at" : "2012-02-20 07:33:19 +0000",
  "in_reply_to_screen_name" : "RyanAnderson529",
  "in_reply_to_user_id_str" : "399110944",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HowBoutCoffee",
      "screen_name" : "HowBoutCoffee",
      "indices" : [ 0, 14 ],
      "id_str" : "496299999",
      "id" : 496299999
    }, {
      "name" : "\u262E \u05D4\u05DC\u05DC",
      "screen_name" : "hillel",
      "indices" : [ 94, 101 ],
      "id_str" : "3640341",
      "id" : 3640341
    }, {
      "name" : "Rahul Sood",
      "screen_name" : "rahulsood",
      "indices" : [ 102, 112 ],
      "id_str" : "14118292",
      "id" : 14118292
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "171446973080141824",
  "geo" : { },
  "id_str" : "171473473393278976",
  "in_reply_to_user_id" : 496299999,
  "text" : "@HowBoutCoffee You had the clearest MVP in my mind. Good job keeping it simple and clear. /cc @hillel @rahulsood",
  "id" : 171473473393278976,
  "in_reply_to_status_id" : 171446973080141824,
  "created_at" : "2012-02-20 05:57:16 +0000",
  "in_reply_to_screen_name" : "HowBoutCoffee",
  "in_reply_to_user_id_str" : "496299999",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouValue.Me",
      "screen_name" : "youvalueme",
      "indices" : [ 0, 11 ],
      "id_str" : "496230387",
      "id" : 496230387
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "171435937371394048",
  "geo" : { },
  "id_str" : "171472924031725568",
  "in_reply_to_user_id" : 496230387,
  "text" : "@youvalueme The idea is really interesting! Good luck with it!",
  "id" : 171472924031725568,
  "in_reply_to_status_id" : 171435937371394048,
  "created_at" : "2012-02-20 05:55:05 +0000",
  "in_reply_to_screen_name" : "youvalueme",
  "in_reply_to_user_id_str" : "496230387",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 82 ],
      "url" : "http://t.co/sCn2QBUe",
      "expanded_url" : "http://flic.kr/p/bwpc9R",
      "display_url" : "flic.kr/p/bwpc9R"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.641, -122.126 ]
  },
  "id_str" : "171455334890737664",
  "text" : "8:36pm Giving out awards to the winning Startup Weekend teams http://t.co/sCn2QBUe",
  "id" : 171455334890737664,
  "created_at" : "2012-02-20 04:45:11 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u262E \u05D4\u05DC\u05DC",
      "screen_name" : "hillel",
      "indices" : [ 27, 34 ],
      "id_str" : "3640341",
      "id" : 3640341
    }, {
      "name" : "Rahul Sood",
      "screen_name" : "rahulsood",
      "indices" : [ 39, 49 ],
      "id_str" : "14118292",
      "id" : 14118292
    }, {
      "name" : "Startup Weekend",
      "screen_name" : "StartupWeekend",
      "indices" : [ 58, 73 ],
      "id_str" : "7315022",
      "id" : 7315022
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SWRedmond",
      "indices" : [ 74, 84 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "171369499415678976",
  "text" : "Excited to be a judge with @hillel and @rahulsood for the @StartupWeekend #SWRedmond ending tonight. Heading over very soon!",
  "id" : 171369499415678976,
  "created_at" : "2012-02-19 23:04:07 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 85 ],
      "url" : "http://t.co/ntO9Q90g",
      "expanded_url" : "http://instagr.am/p/HMrgbUI0IF/",
      "display_url" : "instagr.am/p/HMrgbUI0IF/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6148716063, -122.328279018 ]
  },
  "id_str" : "171307882225217536",
  "text" : "He's excited to have his baby toilet seat adapter  @ Terra Plata http://t.co/ntO9Q90g",
  "id" : 171307882225217536,
  "created_at" : "2012-02-19 18:59:16 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rags Srinivasan",
      "screen_name" : "rags",
      "indices" : [ 9, 14 ],
      "id_str" : "40309057",
      "id" : 40309057
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "171123948459802624",
  "text" : "Only? RT @rags: Apple's hardware revenue is $99 billion, Amazon, a channel, makes only $28 billion in the entire Electronics category",
  "id" : 171123948459802624,
  "created_at" : "2012-02-19 06:48:23 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brett Shell",
      "screen_name" : "Brethren",
      "indices" : [ 0, 9 ],
      "id_str" : "9857922",
      "id" : 9857922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "171088153069879296",
  "geo" : { },
  "id_str" : "171123273793404928",
  "in_reply_to_user_id" : 9857922,
  "text" : "@Brethren Sure sure. I know you're a nudie foodie at heart.",
  "id" : 171123273793404928,
  "in_reply_to_status_id" : 171088153069879296,
  "created_at" : "2012-02-19 06:45:42 +0000",
  "in_reply_to_screen_name" : "Brethren",
  "in_reply_to_user_id_str" : "9857922",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "danielspils",
      "screen_name" : "danielspils",
      "indices" : [ 45, 57 ],
      "id_str" : "14136059",
      "id" : 14136059
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 99 ],
      "url" : "http://t.co/kpphWFDr",
      "expanded_url" : "http://flic.kr/p/bvNxUe",
      "display_url" : "flic.kr/p/bvNxUe"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.649166, -122.356334 ]
  },
  "id_str" : "171115079889199104",
  "text" : "8:36pm Watched a screening of The Shelf that @danielspils help write music for http://t.co/kpphWFDr",
  "id" : 171115079889199104,
  "created_at" : "2012-02-19 06:13:08 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brett Shell",
      "screen_name" : "Brethren",
      "indices" : [ 0, 9 ],
      "id_str" : "9857922",
      "id" : 9857922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 94 ],
      "url" : "http://t.co/ZqU1wbna",
      "expanded_url" : "http://thenudiefoodies.com/",
      "display_url" : "thenudiefoodies.com"
    } ]
  },
  "in_reply_to_status_id_str" : "170983565520150528",
  "geo" : { },
  "id_str" : "171052331914379264",
  "in_reply_to_user_id" : 9857922,
  "text" : "@Brethren Cool, thanks! And thanks also for this find, only 1 click away\u2026 http://t.co/ZqU1wbna",
  "id" : 171052331914379264,
  "in_reply_to_status_id" : 170983565520150528,
  "created_at" : "2012-02-19 02:03:48 +0000",
  "in_reply_to_screen_name" : "Brethren",
  "in_reply_to_user_id_str" : "9857922",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "susie tennant",
      "screen_name" : "susietennant",
      "indices" : [ 0, 13 ],
      "id_str" : "43269343",
      "id" : 43269343
    }, {
      "name" : "Town Hall Seattle",
      "screen_name" : "THSEA",
      "indices" : [ 36, 42 ],
      "id_str" : "46236831",
      "id" : 46236831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "170931530464628736",
  "geo" : { },
  "id_str" : "170932052563206144",
  "in_reply_to_user_id" : 43269343,
  "text" : "@susietennant I saw Jonah Lehrer at @thsea last time he was here! He's awesome. Will definitely try to make it!",
  "id" : 170932052563206144,
  "in_reply_to_status_id" : 170931530464628736,
  "created_at" : "2012-02-18 18:05:51 +0000",
  "in_reply_to_screen_name" : "susietennant",
  "in_reply_to_user_id_str" : "43269343",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Rubin",
      "screen_name" : "bsrubin",
      "indices" : [ 38, 46 ],
      "id_str" : "12192172",
      "id" : 12192172
    }, {
      "name" : "Amber Rae",
      "screen_name" : "heyamberrae",
      "indices" : [ 73, 85 ],
      "id_str" : "15019184",
      "id" : 15019184
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 112 ],
      "url" : "http://t.co/2cyTcPY3",
      "expanded_url" : "http://tumblr.heyamberrae.com/post/17712004118/priorities-and-plans",
      "display_url" : "tumblr.heyamberrae.com/post/177120041\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "170931014636539906",
  "text" : "Looks like a great strategy to me! RT @bsrubin: Becoming Fucking Awesome @heyamberrae style http://t.co/2cyTcPY3",
  "id" : 170931014636539906,
  "created_at" : "2012-02-18 18:01:44 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jonahlehrer",
      "screen_name" : "jonahlehrer",
      "indices" : [ 56, 68 ],
      "id_str" : "18994661",
      "id" : 18994661
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 134 ],
      "url" : "http://t.co/PcLfg1jh",
      "expanded_url" : "http://on.wsj.com/yD8Eka",
      "display_url" : "on.wsj.com/yD8Eka"
    } ]
  },
  "geo" : { },
  "id_str" : "170927161832783872",
  "text" : "I gotta learn more about this NMDA receptor protein! RT @jonahlehrer: The science of habit, my latest WSJ column: http://t.co/PcLfg1jh",
  "id" : 170927161832783872,
  "created_at" : "2012-02-18 17:46:25 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Esther Dyson",
      "screen_name" : "edyson",
      "indices" : [ 115, 122 ],
      "id_str" : "15921173",
      "id" : 15921173
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "technium",
      "indices" : [ 123, 132 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 109 ],
      "url" : "http://t.co/VMm7nJLZ",
      "expanded_url" : "http://www.wired.com/magazine/2012/02/ff_dysonqa/",
      "display_url" : "wired.com/magazine/2012/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "170922246985101313",
  "text" : "AMAZING interview about the early history of computers with George Dyson by Kevin Kelly: http://t.co/VMm7nJLZ /via @edyson #technium",
  "id" : 170922246985101313,
  "created_at" : "2012-02-18 17:26:53 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gretchen Rubin",
      "screen_name" : "gretchenrubin",
      "indices" : [ 3, 17 ],
      "id_str" : "14289835",
      "id" : 14289835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "170889791116812289",
  "text" : "RT @gretchenrubin: To Be Happier, Write Your Own Set of Personal Commandments: Each person's list will differ. One person's command... h ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitterfeed.com\" rel=\"nofollow\">twitterfeed</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 136 ],
        "url" : "http://t.co/ZKqJQVm8",
        "expanded_url" : "http://huff.to/wgcwIk",
        "display_url" : "huff.to/wgcwIk"
      } ]
    },
    "geo" : { },
    "id_str" : "170880660578381825",
    "text" : "To Be Happier, Write Your Own Set of Personal Commandments: Each person's list will differ. One person's command... http://t.co/ZKqJQVm8",
    "id" : 170880660578381825,
    "created_at" : "2012-02-18 14:41:38 +0000",
    "user" : {
      "name" : "Gretchen Rubin",
      "screen_name" : "gretchenrubin",
      "protected" : false,
      "id_str" : "14289835",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1436632135/Gretchenonphone_normal.JPG",
      "id" : 14289835,
      "verified" : true
    }
  },
  "id" : 170889791116812289,
  "created_at" : "2012-02-18 15:17:55 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 70 ],
      "url" : "http://t.co/iW24q7bl",
      "expanded_url" : "http://instagr.am/p/HIt6g_I0Cs/",
      "display_url" : "instagr.am/p/HIt6g_I0Cs/"
    } ]
  },
  "geo" : { },
  "id_str" : "170750091232161793",
  "text" : "8:36pm Family dinner with friends (taken by Lucy) http://t.co/iW24q7bl",
  "id" : 170750091232161793,
  "created_at" : "2012-02-18 06:02:48 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "M. McGovern",
      "screen_name" : "mmcgovern",
      "indices" : [ 0, 10 ],
      "id_str" : "15856582",
      "id" : 15856582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "170583830372171777",
  "geo" : { },
  "id_str" : "170597448153182208",
  "in_reply_to_user_id" : 15856582,
  "text" : "@mmcgovern Thanks, I'll take a look!",
  "id" : 170597448153182208,
  "in_reply_to_status_id" : 170583830372171777,
  "created_at" : "2012-02-17 19:56:15 +0000",
  "in_reply_to_screen_name" : "mmcgovern",
  "in_reply_to_user_id_str" : "15856582",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Wright",
      "screen_name" : "webwright",
      "indices" : [ 80, 90 ],
      "id_str" : "786818",
      "id" : 786818
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 135 ],
      "url" : "http://t.co/SbAZLir2",
      "expanded_url" : "http://www.tonywright.com/2012/how-to-evaluate-a-paid-iphone-app-idea",
      "display_url" : "tonywright.com/2012/how-to-ev\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "170568240110641152",
  "text" : "If you build iPhone apps or are curious about how they make money, this post by @webwright is full of awesomeness: http://t.co/SbAZLir2",
  "id" : 170568240110641152,
  "created_at" : "2012-02-17 18:00:12 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kay Vreeland",
      "screen_name" : "cay_anchor",
      "indices" : [ 14, 25 ],
      "id_str" : "16275525",
      "id" : 16275525
    }, {
      "name" : "Anti-Buster",
      "screen_name" : "busterbenson",
      "indices" : [ 103, 116 ],
      "id_str" : "1024917050",
      "id" : 1024917050
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/cay_anchor/status/170554588972322816/photo/1",
      "indices" : [ 117, 137 ],
      "url" : "http://t.co/Yc60vo59",
      "media_url" : "http://pbs.twimg.com/media/Al3ufrrCEAA6fjq.jpg",
      "id_str" : "170554588976517120",
      "id" : 170554588976517120,
      "media_url_https" : "https://pbs.twimg.com/media/Al3ufrrCEAA6fjq.jpg",
      "sizes" : [ {
        "h" : 315,
        "resize" : "fit",
        "w" : 850
      }, {
        "h" : 222,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 126,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 315,
        "resize" : "fit",
        "w" : 850
      } ],
      "display_url" : "pic.twitter.com/Yc60vo59"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 67 ],
      "url" : "http://t.co/UXCYBb9J",
      "expanded_url" : "http://750words.com",
      "display_url" : "750words.com"
    } ]
  },
  "geo" : { },
  "id_str" : "170556766306836480",
  "text" : "Good work! RT @cay_anchor: New Badge for me on http://t.co/UXCYBb9J =  100,000 words written!! Wooots! @busterbenson http://t.co/Yc60vo59",
  "id" : 170556766306836480,
  "created_at" : "2012-02-17 17:14:36 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thor Muller",
      "screen_name" : "tempo",
      "indices" : [ 3, 9 ],
      "id_str" : "5814",
      "id" : 5814
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "170547263142240256",
  "text" : "RT @tempo: The old way was make tons of money & then give back. The new way is build a company that gives back as it makes money. http:/ ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 119, 139 ],
        "url" : "http://t.co/5ypsm82o",
        "expanded_url" : "http://www.fastcoexist.com/1679342/how-to-solve-the-good-business-generation-gap",
        "display_url" : "fastcoexist.com/1679342/how-to\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "170546630922207232",
    "text" : "The old way was make tons of money & then give back. The new way is build a company that gives back as it makes money. http://t.co/5ypsm82o",
    "id" : 170546630922207232,
    "created_at" : "2012-02-17 16:34:20 +0000",
    "user" : {
      "name" : "Thor Muller",
      "screen_name" : "tempo",
      "protected" : false,
      "id_str" : "5814",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1809986362/265877_10150230867513403_512098402_7439693_1811499_o_normal.jpg",
      "id" : 5814,
      "verified" : false
    }
  },
  "id" : 170547263142240256,
  "created_at" : "2012-02-17 16:36:50 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Berkun",
      "screen_name" : "berkun",
      "indices" : [ 0, 7 ],
      "id_str" : "30495974",
      "id" : 30495974
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "170398617897680897",
  "geo" : { },
  "id_str" : "170399658550636546",
  "in_reply_to_user_id" : 30495974,
  "text" : "@berkun Interesting. Craving endless possibility over singular focus is sane in early life & grows increasingly insane as time goes on.",
  "id" : 170399658550636546,
  "in_reply_to_status_id" : 170398617897680897,
  "created_at" : "2012-02-17 06:50:19 +0000",
  "in_reply_to_screen_name" : "berkun",
  "in_reply_to_user_id_str" : "30495974",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Berkun",
      "screen_name" : "berkun",
      "indices" : [ 0, 7 ],
      "id_str" : "30495974",
      "id" : 30495974
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "170395877754679296",
  "geo" : { },
  "id_str" : "170397259777835008",
  "in_reply_to_user_id" : 30495974,
  "text" : "@berkun Living in constant awareness of death and cosmic insignificance, for example. Though I guess that can lead to insanity too.",
  "id" : 170397259777835008,
  "in_reply_to_status_id" : 170395877754679296,
  "created_at" : "2012-02-17 06:40:47 +0000",
  "in_reply_to_screen_name" : "berkun",
  "in_reply_to_user_id_str" : "30495974",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Berkun",
      "screen_name" : "berkun",
      "indices" : [ 0, 7 ],
      "id_str" : "30495974",
      "id" : 30495974
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "170395877754679296",
  "geo" : { },
  "id_str" : "170396553079554048",
  "in_reply_to_user_id" : 30495974,
  "text" : "@berkun I'd say it's ONE way to be super-motivated. While insanity is a way to over inflate importance of actions, where are other ways too.",
  "id" : 170396553079554048,
  "in_reply_to_status_id" : 170395877754679296,
  "created_at" : "2012-02-17 06:37:58 +0000",
  "in_reply_to_screen_name" : "berkun",
  "in_reply_to_user_id_str" : "30495974",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Berkun",
      "screen_name" : "berkun",
      "indices" : [ 3, 10 ],
      "id_str" : "30495974",
      "id" : 30495974
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "discuss",
      "indices" : [ 105, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "170396088065466368",
  "text" : "RT @berkun: Paradox: the super-motivated drive the world, but to be super-motivated you must be insane.  #discuss",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "discuss",
        "indices" : [ 93, 101 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "170395877754679296",
    "text" : "Paradox: the super-motivated drive the world, but to be super-motivated you must be insane.  #discuss",
    "id" : 170395877754679296,
    "created_at" : "2012-02-17 06:35:17 +0000",
    "user" : {
      "name" : "Scott Berkun",
      "screen_name" : "berkun",
      "protected" : false,
      "id_str" : "30495974",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000401465840/15f3d66a746f653fefddd98f198c58e5_normal.png",
      "id" : 30495974,
      "verified" : false
    }
  },
  "id" : 170396088065466368,
  "created_at" : "2012-02-17 06:36:07 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "josh",
      "screen_name" : "joshc",
      "indices" : [ 0, 6 ],
      "id_str" : "2015",
      "id" : 2015
    }, {
      "name" : "April Schiller",
      "screen_name" : "the_april",
      "indices" : [ 7, 17 ],
      "id_str" : "16644937",
      "id" : 16644937
    }, {
      "name" : "Megan Welling",
      "screen_name" : "MeganWelling",
      "indices" : [ 18, 31 ],
      "id_str" : "26166039",
      "id" : 26166039
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "170393799653203968",
  "geo" : { },
  "id_str" : "170393994822565888",
  "in_reply_to_user_id" : 2015,
  "text" : "@joshc @the_april @meganwelling There certainly is!",
  "id" : 170393994822565888,
  "in_reply_to_status_id" : 170393799653203968,
  "created_at" : "2012-02-17 06:27:48 +0000",
  "in_reply_to_screen_name" : "joshc",
  "in_reply_to_user_id_str" : "2015",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "170393871862341632",
  "text" : "Niko dropped and broke our mouse's right click and scroll ability. Makes using a computer feel like swimming in a wool coat.",
  "id" : 170393871862341632,
  "created_at" : "2012-02-17 06:27:19 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Megan Welling",
      "screen_name" : "MeganWelling",
      "indices" : [ 0, 13 ],
      "id_str" : "26166039",
      "id" : 26166039
    }, {
      "name" : "April Schiller",
      "screen_name" : "the_april",
      "indices" : [ 14, 24 ],
      "id_str" : "16644937",
      "id" : 16644937
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "170390621272551425",
  "geo" : { },
  "id_str" : "170391367778967552",
  "in_reply_to_user_id" : 26166039,
  "text" : "@MeganWelling @the_april 11am?",
  "id" : 170391367778967552,
  "in_reply_to_status_id" : 170390621272551425,
  "created_at" : "2012-02-17 06:17:22 +0000",
  "in_reply_to_screen_name" : "MeganWelling",
  "in_reply_to_user_id_str" : "26166039",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Megan Welling",
      "screen_name" : "MeganWelling",
      "indices" : [ 0, 13 ],
      "id_str" : "26166039",
      "id" : 26166039
    }, {
      "name" : "April Schiller",
      "screen_name" : "the_april",
      "indices" : [ 14, 24 ],
      "id_str" : "16644937",
      "id" : 16644937
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "170390272218378240",
  "geo" : { },
  "id_str" : "170390473201037312",
  "in_reply_to_user_id" : 26166039,
  "text" : "@MeganWelling @the_april How about Local 360? Niko likes that place.",
  "id" : 170390473201037312,
  "in_reply_to_status_id" : 170390272218378240,
  "created_at" : "2012-02-17 06:13:49 +0000",
  "in_reply_to_screen_name" : "MeganWelling",
  "in_reply_to_user_id_str" : "26166039",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "April Schiller",
      "screen_name" : "the_april",
      "indices" : [ 0, 10 ],
      "id_str" : "16644937",
      "id" : 16644937
    }, {
      "name" : "Megan Welling",
      "screen_name" : "MeganWelling",
      "indices" : [ 11, 24 ],
      "id_str" : "26166039",
      "id" : 26166039
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "170382115203063809",
  "geo" : { },
  "id_str" : "170389947159805952",
  "in_reply_to_user_id" : 16644937,
  "text" : "@the_april @MeganWelling What is the standard Sunday ritual these days? I'm way out of the loop!",
  "id" : 170389947159805952,
  "in_reply_to_status_id" : 170382115203063809,
  "created_at" : "2012-02-17 06:11:43 +0000",
  "in_reply_to_screen_name" : "the_april",
  "in_reply_to_user_id_str" : "16644937",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Megan Welling",
      "screen_name" : "MeganWelling",
      "indices" : [ 0, 13 ],
      "id_str" : "26166039",
      "id" : 26166039
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "170375875253121024",
  "geo" : { },
  "id_str" : "170376723190398977",
  "in_reply_to_user_id" : 26166039,
  "text" : "@MeganWelling You should come over on Sunday! Or should we join brunch plans perhaps?",
  "id" : 170376723190398977,
  "in_reply_to_status_id" : 170375875253121024,
  "created_at" : "2012-02-17 05:19:10 +0000",
  "in_reply_to_screen_name" : "MeganWelling",
  "in_reply_to_user_id_str" : "26166039",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 80 ],
      "url" : "http://t.co/SeWL5ytw",
      "expanded_url" : "http://flic.kr/p/buQBF6",
      "display_url" : "flic.kr/p/buQBF6"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.608666, -122.306167 ]
  },
  "id_str" : "170375136782974978",
  "text" : "8:36pm Niko was proud to show off his valentine cards today http://t.co/SeWL5ytw",
  "id" : 170375136782974978,
  "created_at" : "2012-02-17 05:12:52 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Caterina Fake",
      "screen_name" : "Caterina",
      "indices" : [ 25, 34 ],
      "id_str" : "5702",
      "id" : 5702
    }, {
      "name" : "Caterina Fake",
      "screen_name" : "Caterina",
      "indices" : [ 45, 54 ],
      "id_str" : "5702",
      "id" : 5702
    }, {
      "name" : "Pinwheel HQ",
      "screen_name" : "PinwheelHQ",
      "indices" : [ 110, 121 ],
      "id_str" : "1631516617",
      "id" : 1631516617
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 103 ],
      "url" : "http://t.co/pCYaJwpk",
      "expanded_url" : "http://caterina.net/wp-archives/126",
      "display_url" : "caterina.net/wp-archives/126"
    } ]
  },
  "geo" : { },
  "id_str" : "170316669095387136",
  "text" : "Excited about everything @caterina makes! RT @Caterina: Pinwheel! In Private Beta: http://t.co/pCYaJwpk Woot! @pinwheelhq",
  "id" : 170316669095387136,
  "created_at" : "2012-02-17 01:20:32 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ali Berman",
      "screen_name" : "spangley",
      "indices" : [ 0, 9 ],
      "id_str" : "776429",
      "id" : 776429
    }, {
      "name" : "josh",
      "screen_name" : "joshc",
      "indices" : [ 10, 16 ],
      "id_str" : "2015",
      "id" : 2015
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "170253631860391936",
  "geo" : { },
  "id_str" : "170254827262181376",
  "in_reply_to_user_id" : 776429,
  "text" : "@spangley @joshc But moms are also notorious with overloading old email threads with random stuff, right? Which is more annoying?",
  "id" : 170254827262181376,
  "in_reply_to_status_id" : 170253631860391936,
  "created_at" : "2012-02-16 21:14:48 +0000",
  "in_reply_to_screen_name" : "spangley",
  "in_reply_to_user_id_str" : "776429",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ali Berman",
      "screen_name" : "spangley",
      "indices" : [ 0, 9 ],
      "id_str" : "776429",
      "id" : 776429
    }, {
      "name" : "josh",
      "screen_name" : "joshc",
      "indices" : [ 10, 16 ],
      "id_str" : "2015",
      "id" : 2015
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "letsubjectlinesdie",
      "indices" : [ 59, 78 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "170252355835674624",
  "geo" : { },
  "id_str" : "170253040778084352",
  "in_reply_to_user_id" : 776429,
  "text" : "@spangley @joshc Do you wish tweets had subject lines too? #letsubjectlinesdie",
  "id" : 170253040778084352,
  "in_reply_to_status_id" : 170252355835674624,
  "created_at" : "2012-02-16 21:07:42 +0000",
  "in_reply_to_screen_name" : "spangley",
  "in_reply_to_user_id_str" : "776429",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "josh",
      "screen_name" : "joshc",
      "indices" : [ 0, 6 ],
      "id_str" : "2015",
      "id" : 2015
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "170250582806896640",
  "geo" : { },
  "id_str" : "170252319236173824",
  "in_reply_to_user_id" : 2015,
  "text" : "@joshc Oh I think those messages *will* show up on your Mac. I haven't verified though.",
  "id" : 170252319236173824,
  "in_reply_to_status_id" : 170250582806896640,
  "created_at" : "2012-02-16 21:04:50 +0000",
  "in_reply_to_screen_name" : "joshc",
  "in_reply_to_user_id_str" : "2015",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "josh",
      "screen_name" : "joshc",
      "indices" : [ 0, 6 ],
      "id_str" : "2015",
      "id" : 2015
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "170248085551857664",
  "geo" : { },
  "id_str" : "170249551381397505",
  "in_reply_to_user_id" : 2015,
  "text" : "@joshc Yeah, but is your dream to pay AT&T for the honor of seeing/sending SMS from your Mac?",
  "id" : 170249551381397505,
  "in_reply_to_status_id" : 170248085551857664,
  "created_at" : "2012-02-16 20:53:50 +0000",
  "in_reply_to_screen_name" : "joshc",
  "in_reply_to_user_id_str" : "2015",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "josh",
      "screen_name" : "joshc",
      "indices" : [ 0, 6 ],
      "id_str" : "2015",
      "id" : 2015
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "170246249805656065",
  "geo" : { },
  "id_str" : "170246856973107200",
  "in_reply_to_user_id" : 2015,
  "text" : "@joshc The same difference as Gmail versus Gchat, I think, right? Though Facebook is probably one step ahead with merging them.",
  "id" : 170246856973107200,
  "in_reply_to_status_id" : 170246249805656065,
  "created_at" : "2012-02-16 20:43:08 +0000",
  "in_reply_to_screen_name" : "joshc",
  "in_reply_to_user_id_str" : "2015",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Foursquare",
      "screen_name" : "foursquare",
      "indices" : [ 48, 59 ],
      "id_str" : "14120151",
      "id" : 14120151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 98 ],
      "url" : "http://t.co/SpG92UUl",
      "expanded_url" : "http://4sq.com/w5M9RE",
      "display_url" : "4sq.com/w5M9RE"
    } ]
  },
  "geo" : { },
  "id_str" : "170241491925602305",
  "text" : "I just unlocked the Level 2 \"Mall Rat\" badge on @foursquare! In it to win it! http://t.co/SpG92UUl",
  "id" : 170241491925602305,
  "created_at" : "2012-02-16 20:21:49 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ArielMeadowStallings",
      "screen_name" : "OffbeatAriel",
      "indices" : [ 19, 32 ],
      "id_str" : "14095370",
      "id" : 14095370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 53 ],
      "url" : "http://t.co/dXD2EaIP",
      "expanded_url" : "http://instagr.am/p/HDxK19o0Ha/",
      "display_url" : "instagr.am/p/HDxK19o0Ha/"
    } ]
  },
  "geo" : { },
  "id_str" : "170053769244053505",
  "text" : "Dudes reading /via @offbeatariel http://t.co/dXD2EaIP",
  "id" : 170053769244053505,
  "created_at" : "2012-02-16 07:55:52 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 100 ],
      "url" : "http://t.co/x9kAlFYN",
      "expanded_url" : "http://flic.kr/p/buq9N6",
      "display_url" : "flic.kr/p/buq9N6"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.608833, -122.305834 ]
  },
  "id_str" : "170047599825530880",
  "text" : "8:36pm Niko was demonstrating his counter-walking abilities to Jim and Michelle http://t.co/x9kAlFYN",
  "id" : 170047599825530880,
  "created_at" : "2012-02-16 07:31:21 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "169995781321928705",
  "text" : "The quaint notion of private contact information will be replaced with smarter filters. The info is public. Access, however, never will be.",
  "id" : 169995781321928705,
  "created_at" : "2012-02-16 04:05:27 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Greg Kumparak",
      "screen_name" : "Grg",
      "indices" : [ 21, 25 ],
      "id_str" : "14074418",
      "id" : 14074418
    }, {
      "name" : "PandoDaily",
      "screen_name" : "PandoDaily",
      "indices" : [ 52, 63 ],
      "id_str" : "419710142",
      "id" : 419710142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 115 ],
      "url" : "http://t.co/jDge7Wgb",
      "expanded_url" : "http://bit.ly/xDTVUb",
      "display_url" : "bit.ly/xDTVUb"
    } ]
  },
  "geo" : { },
  "id_str" : "169994834789150721",
  "text" : "Interesting take. RT @Grg: My first longer piece on @PandoDaily: Your Address Book Isn't Yours http://t.co/jDge7Wgb",
  "id" : 169994834789150721,
  "created_at" : "2012-02-16 04:01:41 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jonahlehrer",
      "screen_name" : "jonahlehrer",
      "indices" : [ 114, 126 ],
      "id_str" : "18994661",
      "id" : 18994661
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 109 ],
      "url" : "http://t.co/97BknGj1",
      "expanded_url" : "http://www.wired.com/wiredscience/2012/02/what-jeremy-lin-teaches-us-about-talent/",
      "display_url" : "wired.com/wiredscience/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "169836670500356097",
  "text" : "This applies to more than just sports. Talent exists, we just don't know how to find it. http://t.co/97BknGj1 /by @jonahlehrer",
  "id" : 169836670500356097,
  "created_at" : "2012-02-15 17:33:12 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "169622881003778048",
  "text" : "The inspiration for my Valentine's fashion statement today was hipster Bill Cosby.",
  "id" : 169622881003778048,
  "created_at" : "2012-02-15 03:23:40 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "harryh",
      "screen_name" : "harryh",
      "indices" : [ 0, 7 ],
      "id_str" : "4558",
      "id" : 4558
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "169583992763453440",
  "geo" : { },
  "id_str" : "169589824007831553",
  "in_reply_to_user_id" : 4558,
  "text" : "@harryh Me too except it's almost always someone's dog!",
  "id" : 169589824007831553,
  "in_reply_to_status_id" : 169583992763453440,
  "created_at" : "2012-02-15 01:12:19 +0000",
  "in_reply_to_screen_name" : "harryh",
  "in_reply_to_user_id_str" : "4558",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Crocker",
      "screen_name" : "nickcrocker",
      "indices" : [ 0, 12 ],
      "id_str" : "30801469",
      "id" : 30801469
    }, {
      "name" : "Adam Gilbert",
      "screen_name" : "MyBodyTutor",
      "indices" : [ 63, 75 ],
      "id_str" : "17905221",
      "id" : 17905221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 45 ],
      "url" : "http://t.co/2MMvPvS3",
      "expanded_url" : "http://mybodytutor.com",
      "display_url" : "mybodytutor.com"
    } ]
  },
  "in_reply_to_status_id_str" : "169573837548158977",
  "geo" : { },
  "id_str" : "169587589714681856",
  "in_reply_to_user_id" : 30801469,
  "text" : "@nickcrocker Ah, Adam at http://t.co/2MMvPvS3! He's great. /cc @MyBodyTutor",
  "id" : 169587589714681856,
  "in_reply_to_status_id" : 169573837548158977,
  "created_at" : "2012-02-15 01:03:26 +0000",
  "in_reply_to_screen_name" : "nickcrocker",
  "in_reply_to_user_id_str" : "30801469",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Crocker",
      "screen_name" : "nickcrocker",
      "indices" : [ 0, 12 ],
      "id_str" : "30801469",
      "id" : 30801469
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 79 ],
      "url" : "http://t.co/wzdxuysD",
      "expanded_url" : "http://blog.habitlabs.com/post/11061804386/a-90-day-reverse-new-years-resolution",
      "display_url" : "blog.habitlabs.com/post/110618043\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "169572794563174400",
  "geo" : { },
  "id_str" : "169573582127640576",
  "in_reply_to_user_id" : 30801469,
  "text" : "@nickcrocker Do you mean my reverse new year's resolution? http://t.co/wzdxuysD",
  "id" : 169573582127640576,
  "in_reply_to_status_id" : 169572794563174400,
  "created_at" : "2012-02-15 00:07:47 +0000",
  "in_reply_to_screen_name" : "nickcrocker",
  "in_reply_to_user_id_str" : "30801469",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Gubelman",
      "screen_name" : "gubester",
      "indices" : [ 0, 9 ],
      "id_str" : "186833531",
      "id" : 186833531
    }, {
      "name" : "Forrest Smith",
      "screen_name" : "ForrestTheWoods",
      "indices" : [ 10, 26 ],
      "id_str" : "114908092",
      "id" : 114908092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "169485699165339648",
  "geo" : { },
  "id_str" : "169490633143222272",
  "in_reply_to_user_id" : 186833531,
  "text" : "@gubester @ForrestTheWoods Ha. Noted.",
  "id" : 169490633143222272,
  "in_reply_to_status_id" : 169485699165339648,
  "created_at" : "2012-02-14 18:38:10 +0000",
  "in_reply_to_screen_name" : "gubester",
  "in_reply_to_user_id_str" : "186833531",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Sippey",
      "screen_name" : "sippey",
      "indices" : [ 3, 10 ],
      "id_str" : "4711",
      "id" : 4711
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "decisionsdec",
      "indices" : [ 123, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 122 ],
      "url" : "http://t.co/flFhkdjz",
      "expanded_url" : "http://www.grantland.com/story/_/id/7559458/cte-concussion-crisis-economic-look-end-football",
      "display_url" : "grantland.com/story/_/id/755\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "169311158703112192",
  "text" : "RT @sippey: \"To the extent that fans replace football with another sport (instead of meth or oxy)...\" http://t.co/flFhkdjz #decisionsdec ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "decisionsdecisions",
        "indices" : [ 111, 130 ]
      } ],
      "urls" : [ {
        "indices" : [ 90, 110 ],
        "url" : "http://t.co/flFhkdjz",
        "expanded_url" : "http://www.grantland.com/story/_/id/7559458/cte-concussion-crisis-economic-look-end-football",
        "display_url" : "grantland.com/story/_/id/755\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "169307949439778816",
    "text" : "\"To the extent that fans replace football with another sport (instead of meth or oxy)...\" http://t.co/flFhkdjz #decisionsdecisions",
    "id" : 169307949439778816,
    "created_at" : "2012-02-14 06:32:15 +0000",
    "user" : {
      "name" : "Michael Sippey",
      "screen_name" : "sippey",
      "protected" : false,
      "id_str" : "4711",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3541799518/c8ea5593267cad82eb9de763a9456d3b_normal.jpeg",
      "id" : 4711,
      "verified" : false
    }
  },
  "id" : 169311158703112192,
  "created_at" : "2012-02-14 06:45:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Payne",
      "screen_name" : "al3x",
      "indices" : [ 26, 31 ],
      "id_str" : "18713",
      "id" : 18713
    }, {
      "name" : "Chris DeVore",
      "screen_name" : "crashdev",
      "indices" : [ 123, 132 ],
      "id_str" : "14763501",
      "id" : 14763501
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "business",
      "indices" : [ 108, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 107 ],
      "url" : "http://t.co/l2aZp8QS",
      "expanded_url" : "http://al3x.net/2012/02/12/on-business-madness.html",
      "display_url" : "al3x.net/2012/02/12/on-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "169288244331155456",
  "text" : "Wow, this is really good. @al3x just became one of my favorite writers with this post: http://t.co/l2aZp8QS #business /via @crashdev",
  "id" : 169288244331155456,
  "created_at" : "2012-02-14 05:13:57 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 83 ],
      "url" : "http://t.co/9X4BAd6W",
      "expanded_url" : "http://flic.kr/p/btqem4",
      "display_url" : "flic.kr/p/btqem4"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.608666, -122.306167 ]
  },
  "id_str" : "169286259884306433",
  "text" : "8:36pm Passed out briefly in Niko's room. That guy is awesome. http://t.co/9X4BAd6W",
  "id" : 169286259884306433,
  "created_at" : "2012-02-14 05:06:04 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Les Hill",
      "screen_name" : "leshill",
      "indices" : [ 0, 8 ],
      "id_str" : "12495752",
      "id" : 12495752
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "168833194064478209",
  "geo" : { },
  "id_str" : "169263361308102656",
  "in_reply_to_user_id" : 12495752,
  "text" : "@leshill Thanks, I'll definitely look into that!",
  "id" : 169263361308102656,
  "in_reply_to_status_id" : 168833194064478209,
  "created_at" : "2012-02-14 03:35:04 +0000",
  "in_reply_to_screen_name" : "leshill",
  "in_reply_to_user_id_str" : "12495752",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Fuchs",
      "screen_name" : "jfuchs",
      "indices" : [ 0, 7 ],
      "id_str" : "1026",
      "id" : 1026
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "168933020714283008",
  "geo" : { },
  "id_str" : "169263278978113536",
  "in_reply_to_user_id" : 1026,
  "text" : "@jfuchs It all \"seems\" to work together at first but I'm finding lots of limitations as I get into it. Too many separate frameworks!",
  "id" : 169263278978113536,
  "in_reply_to_status_id" : 168933020714283008,
  "created_at" : "2012-02-14 03:34:45 +0000",
  "in_reply_to_screen_name" : "jfuchs",
  "in_reply_to_user_id_str" : "1026",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Todd Gehman",
      "screen_name" : "pugetive",
      "indices" : [ 0, 9 ],
      "id_str" : "16355060",
      "id" : 16355060
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "168957876507918337",
  "geo" : { },
  "id_str" : "169263049583243264",
  "in_reply_to_user_id" : 16355060,
  "text" : "@pugetive What's your setup for HAML and Backbone templates? Underscore is pretty limited...",
  "id" : 169263049583243264,
  "in_reply_to_status_id" : 168957876507918337,
  "created_at" : "2012-02-14 03:33:50 +0000",
  "in_reply_to_screen_name" : "pugetive",
  "in_reply_to_user_id_str" : "16355060",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michelle Broderick",
      "screen_name" : "MichelleBee",
      "indices" : [ 0, 12 ],
      "id_str" : "1059951",
      "id" : 1059951
    }, {
      "name" : "Scott Berkun",
      "screen_name" : "berkun",
      "indices" : [ 13, 20 ],
      "id_str" : "30495974",
      "id" : 30495974
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "169261471736414208",
  "geo" : { },
  "id_str" : "169262629028773889",
  "in_reply_to_user_id" : 1059951,
  "text" : "@MichelleBee @berkun We do share a brain. He hogs it mostly, though.",
  "id" : 169262629028773889,
  "in_reply_to_status_id" : 169261471736414208,
  "created_at" : "2012-02-14 03:32:10 +0000",
  "in_reply_to_screen_name" : "MichelleBee",
  "in_reply_to_user_id_str" : "1059951",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jane McGonigal",
      "screen_name" : "avantgame",
      "indices" : [ 3, 13 ],
      "id_str" : "681813",
      "id" : 681813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "169260176795377665",
  "text" : "RT @avantgame: \"Be kind, for everyone you meet is fighting a hard battle.\" I feel like everyone should tweet this, every day.",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "169259778063876097",
    "text" : "\"Be kind, for everyone you meet is fighting a hard battle.\" I feel like everyone should tweet this, every day.",
    "id" : 169259778063876097,
    "created_at" : "2012-02-14 03:20:50 +0000",
    "user" : {
      "name" : "Jane McGonigal",
      "screen_name" : "avantgame",
      "protected" : false,
      "id_str" : "681813",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000116152853/47c4501ee2d80e97b423129fe0db016a_normal.jpeg",
      "id" : 681813,
      "verified" : false
    }
  },
  "id" : 169260176795377665,
  "created_at" : "2012-02-14 03:22:25 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jane McGonigal",
      "screen_name" : "avantgame",
      "indices" : [ 0, 10 ],
      "id_str" : "681813",
      "id" : 681813
    }, {
      "name" : "craignewmark",
      "screen_name" : "craignewmark",
      "indices" : [ 34, 47 ],
      "id_str" : "14368074",
      "id" : 14368074
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "169259778063876097",
  "geo" : { },
  "id_str" : "169260166385123328",
  "in_reply_to_user_id" : 681813,
  "text" : "@avantgame So true! I think about @craignewmark's \"give people a break\" quite often. And also apply it to myself.",
  "id" : 169260166385123328,
  "in_reply_to_status_id" : 169259778063876097,
  "created_at" : "2012-02-14 03:22:23 +0000",
  "in_reply_to_screen_name" : "avantgame",
  "in_reply_to_user_id_str" : "681813",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "169259257034842112",
  "text" : "Our inability to understand anything other than binary truths/outcomes is gonna be the end of us.",
  "id" : 169259257034842112,
  "created_at" : "2012-02-14 03:18:46 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://bud.ge\" rel=\"nofollow\">Budge</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 83 ],
      "url" : "http://t.co/KKcdaMOG",
      "expanded_url" : "http://bud.ge/n/d7u",
      "display_url" : "bud.ge/n/d7u"
    } ]
  },
  "geo" : { },
  "id_str" : "169252007591411712",
  "text" : "My nemesis in the Pushup Animal program is Niko climbing on me http://t.co/KKcdaMOG",
  "id" : 169252007591411712,
  "created_at" : "2012-02-14 02:49:57 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jen S. McCabe",
      "screen_name" : "jensmccabe",
      "indices" : [ 11, 22 ],
      "id_str" : "14258044",
      "id" : 14258044
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "169175035393740800",
  "geo" : { },
  "id_str" : "169248388867559424",
  "in_reply_to_user_id" : 171754967,
  "text" : "@1CharlesH @jensmccabe Cool! Who's talk was that?",
  "id" : 169248388867559424,
  "in_reply_to_status_id" : 169175035393740800,
  "created_at" : "2012-02-14 02:35:35 +0000",
  "in_reply_to_screen_name" : "cch",
  "in_reply_to_user_id_str" : "171754967",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MICHELLE",
      "screen_name" : "itsninson",
      "indices" : [ 0, 10 ],
      "id_str" : "124363227",
      "id" : 124363227
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "168787201218461696",
  "geo" : { },
  "id_str" : "168804918952591361",
  "in_reply_to_user_id" : 124363227,
  "text" : "@itsninson Yes, our paths will cross some day! Are you ever in Seattle?",
  "id" : 168804918952591361,
  "in_reply_to_status_id" : 168787201218461696,
  "created_at" : "2012-02-12 21:13:23 +0000",
  "in_reply_to_screen_name" : "itsninson",
  "in_reply_to_user_id_str" : "124363227",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Artem",
      "screen_name" : "ignart",
      "indices" : [ 0, 7 ],
      "id_str" : "16451653",
      "id" : 16451653
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "168759900426604544",
  "geo" : { },
  "id_str" : "168761303056400384",
  "in_reply_to_user_id" : 16451653,
  "text" : "@ignart I'm slowly piecing it together, but would love any pointers you run across",
  "id" : 168761303056400384,
  "in_reply_to_status_id" : 168759900426604544,
  "created_at" : "2012-02-12 18:20:04 +0000",
  "in_reply_to_screen_name" : "ignart",
  "in_reply_to_user_id_str" : "16451653",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Artem",
      "screen_name" : "ignart",
      "indices" : [ 0, 7 ],
      "id_str" : "16451653",
      "id" : 16451653
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "168757489205125120",
  "geo" : { },
  "id_str" : "168757880990859265",
  "in_reply_to_user_id" : 16451653,
  "text" : "@ignart Awesome! Any pointers or code samples of using HAML in Backbone Views?",
  "id" : 168757880990859265,
  "in_reply_to_status_id" : 168757489205125120,
  "created_at" : "2012-02-12 18:06:28 +0000",
  "in_reply_to_screen_name" : "ignart",
  "in_reply_to_user_id_str" : "16451653",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "168751836466126849",
  "text" : "Nerd question. Has anyone seen coffee script, backbone, and haml all used together to great effect? Is it possible?",
  "id" : 168751836466126849,
  "created_at" : "2012-02-12 17:42:27 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Schappell",
      "screen_name" : "daveschappell",
      "indices" : [ 63, 77 ],
      "id_str" : "820661",
      "id" : 820661
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 125 ],
      "url" : "http://t.co/WY3CosJ6",
      "expanded_url" : "http://techcrunch.com/2012/02/11/dont-call-me-a-douchebag/",
      "display_url" : "techcrunch.com/2012/02/11/don\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "168731023180435456",
  "text" : "This post needs a better title. I propose: News Isn't True. RT @daveschappell: Don't Call Me a Douchebag http://t.co/WY3CosJ6",
  "id" : 168731023180435456,
  "created_at" : "2012-02-12 16:19:45 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http://t.co/RcPmEK47",
      "expanded_url" : "http://flic.kr/p/bsfBQ4",
      "display_url" : "flic.kr/p/bsfBQ4"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.623333, -122.336 ]
  },
  "id_str" : "168565976038768640",
  "text" : "8:36pm Self-edumacation Saturday goes late. Catching up on coffeescript, bootstrap, backbone, devise, and Rails 3.2 http://t.co/RcPmEK47",
  "id" : 168565976038768640,
  "created_at" : "2012-02-12 05:23:55 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://bud.ge\" rel=\"nofollow\">Budge</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 114 ],
      "url" : "http://t.co/Fm9IwFMO",
      "expanded_url" : "http://bud.ge/n/cgl",
      "display_url" : "bud.ge/n/cgl"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.623494, -122.3358507 ]
  },
  "id_str" : "168427724925444096",
  "text" : "My nemesis in the Drinking Problems program is Charles Shaw (turns out I can still drink it!) http://t.co/Fm9IwFMO",
  "id" : 168427724925444096,
  "created_at" : "2012-02-11 20:14:33 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.rdio.com\" rel=\"nofollow\">Rdio</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rdio",
      "screen_name" : "Rdio",
      "indices" : [ 80, 85 ],
      "id_str" : "54205414",
      "id" : 54205414
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "recommended",
      "indices" : [ 108, 120 ]
    }, {
      "text" : "album",
      "indices" : [ 121, 127 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 107 ],
      "url" : "http://t.co/B4sItfAa",
      "expanded_url" : "http://rd.io/x/QFvDPk6AeQ",
      "display_url" : "rd.io/x/QFvDPk6AeQ"
    } ]
  },
  "geo" : { },
  "id_str" : "168413005665681409",
  "text" : "\u266B Loving this album right now! Listening to \"The Mistress\" by Yellow Ostrich on @Rdio: http://t.co/B4sItfAa #recommended #album",
  "id" : 168413005665681409,
  "created_at" : "2012-02-11 19:16:04 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dimitar Roustchev",
      "screen_name" : "droustchev",
      "indices" : [ 0, 11 ],
      "id_str" : "223907856",
      "id" : 223907856
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 79 ],
      "url" : "http://t.co/oFUdNcs7",
      "expanded_url" : "http://habitlabs.com",
      "display_url" : "habitlabs.com"
    } ]
  },
  "in_reply_to_status_id_str" : "168238027729141760",
  "geo" : { },
  "id_str" : "168238347490304000",
  "in_reply_to_user_id" : 223907856,
  "text" : "@droustchev Yeah, what's your email? Email me at buster at http://t.co/oFUdNcs7 if you don't want to tweet it.",
  "id" : 168238347490304000,
  "in_reply_to_status_id" : 168238027729141760,
  "created_at" : "2012-02-11 07:42:02 +0000",
  "in_reply_to_screen_name" : "droustchev",
  "in_reply_to_user_id_str" : "223907856",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u028E\u01DD\u029E\u0254\u0131\u0265 \u0287\u0287\u0250\u026F",
      "screen_name" : "matthickey",
      "indices" : [ 0, 11 ],
      "id_str" : "8710082",
      "id" : 8710082
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "168202865012260864",
  "geo" : { },
  "id_str" : "168236613204312064",
  "in_reply_to_user_id" : 8710082,
  "text" : "@matthickey Sorta crazy and workaholic unless you wanna meet Niko and I for coffee on Sun. Or try sometime next week.",
  "id" : 168236613204312064,
  "in_reply_to_status_id" : 168202865012260864,
  "created_at" : "2012-02-11 07:35:08 +0000",
  "in_reply_to_screen_name" : "matthickey",
  "in_reply_to_user_id_str" : "8710082",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ScottieYahtzee",
      "screen_name" : "ScottieYahtzee",
      "indices" : [ 0, 15 ],
      "id_str" : "15486015",
      "id" : 15486015
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "168234554967072768",
  "geo" : { },
  "id_str" : "168236188505874432",
  "in_reply_to_user_id" : 15486015,
  "text" : "@ScottieYahtzee That is such a classic.",
  "id" : 168236188505874432,
  "in_reply_to_status_id" : 168234554967072768,
  "created_at" : "2012-02-11 07:33:27 +0000",
  "in_reply_to_screen_name" : "ScottieYahtzee",
  "in_reply_to_user_id_str" : "15486015",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 87 ],
      "url" : "http://t.co/Eh2Y3ZUt",
      "expanded_url" : "http://flic.kr/p/brJPKz",
      "display_url" : "flic.kr/p/brJPKz"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.609333, -122.306167 ]
  },
  "id_str" : "168192135051493376",
  "text" : "8:36pm Nice walk home thinking about logic puzzles for some reason http://t.co/Eh2Y3ZUt",
  "id" : 168192135051493376,
  "created_at" : "2012-02-11 04:38:24 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://bud.ge\" rel=\"nofollow\">Budge</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 90 ],
      "url" : "http://t.co/zYSSeDtR",
      "expanded_url" : "http://bud.ge/n/c8g",
      "display_url" : "bud.ge/n/c8g"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6086824, -122.306093 ]
  },
  "id_str" : "168135749261197313",
  "text" : "My secret ingredient for the Pushup Animal program is Niko copying me http://t.co/zYSSeDtR",
  "id" : 168135749261197313,
  "created_at" : "2012-02-11 00:54:21 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://bud.ge\" rel=\"nofollow\">Budge</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 123 ],
      "url" : "http://t.co/MoXin2yV",
      "expanded_url" : "http://bud.ge/n/c8e",
      "display_url" : "bud.ge/n/c8e"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6086838, -122.3060896 ]
  },
  "id_str" : "168111252994932736",
  "text" : "My secret ingredient for the Pushup Animal program is knowing that April is doing more pushups than me http://t.co/MoXin2yV",
  "id" : 168111252994932736,
  "created_at" : "2012-02-10 23:17:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Max Daniels",
      "screen_name" : "maxdaniels",
      "indices" : [ 0, 11 ],
      "id_str" : "17490227",
      "id" : 17490227
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "168091653096214528",
  "geo" : { },
  "id_str" : "168092169465380865",
  "in_reply_to_user_id" : 17490227,
  "text" : "@maxdaniels You like it?  :)",
  "id" : 168092169465380865,
  "in_reply_to_status_id" : 168091653096214528,
  "created_at" : "2012-02-10 22:01:10 +0000",
  "in_reply_to_screen_name" : "maxdaniels",
  "in_reply_to_user_id_str" : "17490227",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Samuel Fine",
      "screen_name" : "samuelfine",
      "indices" : [ 0, 11 ],
      "id_str" : "200236063",
      "id" : 200236063
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "168090047067865088",
  "geo" : { },
  "id_str" : "168091380470648832",
  "in_reply_to_user_id" : 200236063,
  "text" : "@samuelfine Great! What's your email address?  Send it to buster at habitlabs.com if you don't want to tweet it.",
  "id" : 168091380470648832,
  "in_reply_to_status_id" : 168090047067865088,
  "created_at" : "2012-02-10 21:58:02 +0000",
  "in_reply_to_screen_name" : "samuelfine",
  "in_reply_to_user_id_str" : "200236063",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Samuel Fine",
      "screen_name" : "samuelfine",
      "indices" : [ 0, 11 ],
      "id_str" : "200236063",
      "id" : 200236063
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "168089509781704704",
  "geo" : { },
  "id_str" : "168089770138935296",
  "in_reply_to_user_id" : 200236063,
  "text" : "@samuelfine Yeah, it's a known problem\u2026 fix coming soon!",
  "id" : 168089770138935296,
  "in_reply_to_status_id" : 168089509781704704,
  "created_at" : "2012-02-10 21:51:38 +0000",
  "in_reply_to_screen_name" : "samuelfine",
  "in_reply_to_user_id_str" : "200236063",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shannon Garcia",
      "screen_name" : "clover",
      "indices" : [ 0, 7 ],
      "id_str" : "756336",
      "id" : 756336
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "168088323108257792",
  "geo" : { },
  "id_str" : "168088696166432769",
  "in_reply_to_user_id" : 756336,
  "text" : "@clover Great! What's your email? Send it to buster at habitlabs.com if you'd rather not tweet it.",
  "id" : 168088696166432769,
  "in_reply_to_status_id" : 168088323108257792,
  "created_at" : "2012-02-10 21:47:22 +0000",
  "in_reply_to_screen_name" : "clover",
  "in_reply_to_user_id_str" : "756336",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kristie Macris",
      "screen_name" : "kristiemacris",
      "indices" : [ 0, 14 ],
      "id_str" : "52161849",
      "id" : 52161849
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "168088261200322560",
  "geo" : { },
  "id_str" : "168088670438563840",
  "in_reply_to_user_id" : 52161849,
  "text" : "@kristiemacris Share Your Food is brand new! What's your email? Send it to buster at habitlabs.com if you'd rather not tweet it.",
  "id" : 168088670438563840,
  "in_reply_to_status_id" : 168088261200322560,
  "created_at" : "2012-02-10 21:47:16 +0000",
  "in_reply_to_screen_name" : "kristiemacris",
  "in_reply_to_user_id_str" : "52161849",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Max Daniels",
      "screen_name" : "maxdaniels",
      "indices" : [ 0, 11 ],
      "id_str" : "17490227",
      "id" : 17490227
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "168088039787204608",
  "geo" : { },
  "id_str" : "168088451529441281",
  "in_reply_to_user_id" : 17490227,
  "text" : "@maxdaniels Great! What's your email? Send it to buster at habitlabs.com if you'd rather not tweet it.",
  "id" : 168088451529441281,
  "in_reply_to_status_id" : 168088039787204608,
  "created_at" : "2012-02-10 21:46:24 +0000",
  "in_reply_to_screen_name" : "maxdaniels",
  "in_reply_to_user_id_str" : "17490227",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://bud.ge\" rel=\"nofollow\">Budge</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 112 ],
      "url" : "http://t.co/cyAGXMo1",
      "expanded_url" : "http://bud.ge/n/c7l",
      "display_url" : "bud.ge/n/c7l"
    } ]
  },
  "geo" : { },
  "id_str" : "168087357843709952",
  "text" : "My nemesis in the Share Your Food program is delicious taco trucks that stare at me all day http://t.co/cyAGXMo1",
  "id" : 168087357843709952,
  "created_at" : "2012-02-10 21:42:03 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 43 ],
      "url" : "http://t.co/VSxp2sYJ",
      "expanded_url" : "http://bud.ge/store",
      "display_url" : "bud.ge/store"
    } ]
  },
  "geo" : { },
  "id_str" : "168087326944272384",
  "text" : "Who wants to help test http://t.co/VSxp2sYJ? I've got some invites to give away\u2026 take a look & tell me which program you want to try!",
  "id" : 168087326944272384,
  "created_at" : "2012-02-10 21:41:56 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Wright",
      "screen_name" : "webwright",
      "indices" : [ 18, 28 ],
      "id_str" : "786818",
      "id" : 786818
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 114 ],
      "url" : "http://t.co/ELopVkMA",
      "expanded_url" : "http://www.tonywright.com/2012/mobile-is-whats-next-for-me/",
      "display_url" : "tonywright.com/2012/mobile-is\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "168078001270042624",
  "text" : "Super stoked that @webwright is finally building something new! This is gonna be interesting: http://t.co/ELopVkMA",
  "id" : 168078001270042624,
  "created_at" : "2012-02-10 21:04:52 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "girl jo",
      "screen_name" : "octavekitten",
      "indices" : [ 0, 13 ],
      "id_str" : "16366882",
      "id" : 16366882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 84 ],
      "url" : "http://t.co/JLKcCPxd",
      "expanded_url" : "http://swole.me/",
      "display_url" : "swole.me"
    } ]
  },
  "in_reply_to_status_id_str" : "168031759898902528",
  "geo" : { },
  "id_str" : "168032246329126912",
  "in_reply_to_user_id" : 16366882,
  "text" : "@octavekitten Another new site that looks pretty interesting is http://t.co/JLKcCPxd",
  "id" : 168032246329126912,
  "in_reply_to_status_id" : 168031759898902528,
  "created_at" : "2012-02-10 18:03:04 +0000",
  "in_reply_to_screen_name" : "octavekitten",
  "in_reply_to_user_id_str" : "16366882",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "girl jo",
      "screen_name" : "octavekitten",
      "indices" : [ 0, 13 ],
      "id_str" : "16366882",
      "id" : 16366882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 131 ],
      "url" : "http://t.co/92Q5m151",
      "expanded_url" : "http://whfoods.com/foodstoc.php",
      "display_url" : "whfoods.com/foodstoc.php"
    } ]
  },
  "in_reply_to_status_id_str" : "168027954465607682",
  "geo" : { },
  "id_str" : "168030203761795073",
  "in_reply_to_user_id" : 16366882,
  "text" : "@octavekitten What kind are you looking for in particular? I reference this page a lot for specific food info: http://t.co/92Q5m151",
  "id" : 168030203761795073,
  "in_reply_to_status_id" : 168027954465607682,
  "created_at" : "2012-02-10 17:54:57 +0000",
  "in_reply_to_screen_name" : "octavekitten",
  "in_reply_to_user_id_str" : "16366882",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Harman",
      "screen_name" : "tomharman",
      "indices" : [ 3, 13 ],
      "id_str" : "7069062",
      "id" : 7069062
    }, {
      "name" : "Anti-Buster",
      "screen_name" : "busterbenson",
      "indices" : [ 37, 50 ],
      "id_str" : "1024917050",
      "id" : 1024917050
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 114 ],
      "url" : "http://t.co/oNRnZU1X",
      "expanded_url" : "http://blog.harmantom.com/post/17375936929/the-value-of-daily-writing",
      "display_url" : "blog.harmantom.com/post/173759369\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "168018046412259328",
  "text" : "RT @tomharman: A new blog post about @busterbenson's 750words and the value of daily writing: http://t.co/oNRnZU1X",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Anti-Buster",
        "screen_name" : "busterbenson",
        "indices" : [ 22, 35 ],
        "id_str" : "1024917050",
        "id" : 1024917050
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 79, 99 ],
        "url" : "http://t.co/oNRnZU1X",
        "expanded_url" : "http://blog.harmantom.com/post/17375936929/the-value-of-daily-writing",
        "display_url" : "blog.harmantom.com/post/173759369\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "168017137531756544",
    "text" : "A new blog post about @busterbenson's 750words and the value of daily writing: http://t.co/oNRnZU1X",
    "id" : 168017137531756544,
    "created_at" : "2012-02-10 17:03:01 +0000",
    "user" : {
      "name" : "Tom Harman",
      "screen_name" : "tomharman",
      "protected" : false,
      "id_str" : "7069062",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1375002418/tom-sq_normal.jpg",
      "id" : 7069062,
      "verified" : false
    }
  },
  "id" : 168018046412259328,
  "created_at" : "2012-02-10 17:06:38 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diana Kimball",
      "screen_name" : "dianakimball",
      "indices" : [ 0, 13 ],
      "id_str" : "14471007",
      "id" : 14471007
    }, {
      "name" : "David Cole",
      "screen_name" : "irondavy",
      "indices" : [ 14, 23 ],
      "id_str" : "14986129",
      "id" : 14986129
    }, {
      "name" : "/mentoring",
      "screen_name" : "mentoring",
      "indices" : [ 87, 97 ],
      "id_str" : "360733236",
      "id" : 360733236
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "167990433467736065",
  "geo" : { },
  "id_str" : "168012075430461440",
  "in_reply_to_user_id" : 14471007,
  "text" : "@dianakimball @irondavy That was a great email filled with awesome ideas! Gonna put my @mentoring hat on today.",
  "id" : 168012075430461440,
  "in_reply_to_status_id" : 167990433467736065,
  "created_at" : "2012-02-10 16:42:54 +0000",
  "in_reply_to_screen_name" : "dianakimball",
  "in_reply_to_user_id_str" : "14471007",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Helen Fisher",
      "screen_name" : "DrHelenFisher",
      "indices" : [ 3, 17 ],
      "id_str" : "34322822",
      "id" : 34322822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "168005944129757186",
  "text" : "RT @DrHelenFisher: Last bit of chocolate, last kiss, graduation day experienced as best (positivity effect) prob bec barriers heighten d ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://ubersocial.com\" rel=\"nofollow\">UberSocial Pro for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "168002802608635906",
    "text" : "Last bit of chocolate, last kiss, graduation day experienced as best (positivity effect) prob bec barriers heighten dopamine-giving pleasure",
    "id" : 168002802608635906,
    "created_at" : "2012-02-10 16:06:04 +0000",
    "user" : {
      "name" : "Dr. Helen Fisher",
      "screen_name" : "DrHelenFisher",
      "protected" : false,
      "id_str" : "34322822",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/278558635/Helen_Twitter_normal.JPG",
      "id" : 34322822,
      "verified" : false
    }
  },
  "id" : 168005944129757186,
  "created_at" : "2012-02-10 16:18:33 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "budge",
      "indices" : [ 68, 74 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "167848107613233153",
  "text" : "I ate rice, chicken, and sweet potatoes for dinner. This is a test. #budge",
  "id" : 167848107613233153,
  "created_at" : "2012-02-10 05:51:21 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Guillebeau",
      "screen_name" : "chrisguillebeau",
      "indices" : [ 3, 19 ],
      "id_str" : "10373972",
      "id" : 10373972
    }, {
      "name" : "Amber Rae",
      "screen_name" : "heyamberrae",
      "indices" : [ 58, 70 ],
      "id_str" : "15019184",
      "id" : 15019184
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "167843221500735488",
  "text" : "RT @chrisguillebeau: Comparison is the thief of joy. (via @heyamberrae)",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Amber Rae",
        "screen_name" : "heyamberrae",
        "indices" : [ 37, 49 ],
        "id_str" : "15019184",
        "id" : 15019184
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "167842526613614592",
    "text" : "Comparison is the thief of joy. (via @heyamberrae)",
    "id" : 167842526613614592,
    "created_at" : "2012-02-10 05:29:11 +0000",
    "user" : {
      "name" : "Chris Guillebeau",
      "screen_name" : "chrisguillebeau",
      "protected" : false,
      "id_str" : "10373972",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1443325474/chris_normal.jpg",
      "id" : 10373972,
      "verified" : true
    }
  },
  "id" : 167843221500735488,
  "created_at" : "2012-02-10 05:31:57 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "April Schiller",
      "screen_name" : "the_april",
      "indices" : [ 48, 58 ],
      "id_str" : "16644937",
      "id" : 16644937
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 79 ],
      "url" : "http://t.co/YLGocASZ",
      "expanded_url" : "http://flic.kr/p/briXWB",
      "display_url" : "flic.kr/p/briXWB"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.608666, -122.306167 ]
  },
  "id_str" : "167832285939372032",
  "text" : "8:36pm Talking Pushup Animal with its champion, @the_april http://t.co/YLGocASZ",
  "id" : 167832285939372032,
  "created_at" : "2012-02-10 04:48:29 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "paul rush",
      "screen_name" : "skwaer",
      "indices" : [ 50, 57 ],
      "id_str" : "3734051",
      "id" : 3734051
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 78 ],
      "url" : "http://t.co/yfZjzFdE",
      "expanded_url" : "http://flic.kr/p/bqRUo6",
      "display_url" : "flic.kr/p/bqRUo6"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.612833, -122.314 ]
  },
  "id_str" : "167478159107829761",
  "text" : "8:36pm Walking home from a deep conversation with @skwaer http://t.co/yfZjzFdE",
  "id" : 167478159107829761,
  "created_at" : "2012-02-09 05:21:19 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 130 ],
      "url" : "http://t.co/QlQQ0IXw",
      "expanded_url" : "http://blog.habitlabs.com/post/17276843333/much-love-from-habit-labs-get-your-free-azumio-stress",
      "display_url" : "blog.habitlabs.com/post/172768433\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "167351558718234624",
  "text" : "I've been playing around with the Stress Check app for a while. It's awesome and now we are giving some away: http://t.co/QlQQ0IXw",
  "id" : 167351558718234624,
  "created_at" : "2012-02-08 20:58:15 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Sanders",
      "screen_name" : "nextmat",
      "indices" : [ 0, 8 ],
      "id_str" : "43580287",
      "id" : 43580287
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "167287583473278978",
  "geo" : { },
  "id_str" : "167326678337593344",
  "in_reply_to_user_id" : 43580287,
  "text" : "@nextmat Hm... I'll look into that. What device (phone, iPad, web browser) did you click the invite link from?\n\nAlso, you should be in now",
  "id" : 167326678337593344,
  "in_reply_to_status_id" : 167287583473278978,
  "created_at" : "2012-02-08 19:19:23 +0000",
  "in_reply_to_screen_name" : "nextmat",
  "in_reply_to_user_id_str" : "43580287",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 80 ],
      "url" : "http://t.co/dhhchlwh",
      "expanded_url" : "http://flic.kr/p/bqo5vc",
      "display_url" : "flic.kr/p/bqo5vc"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.612166, -122.317 ]
  },
  "id_str" : "167107167034421248",
  "text" : "8:36pm Talking about the highs and lows of the working life http://t.co/dhhchlwh",
  "id" : 167107167034421248,
  "created_at" : "2012-02-08 04:47:07 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trapper Markelz",
      "screen_name" : "trappermarkelz",
      "indices" : [ 0, 15 ],
      "id_str" : "1032241",
      "id" : 1032241
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "166893976488656898",
  "geo" : { },
  "id_str" : "166949005841018880",
  "in_reply_to_user_id" : 1032241,
  "text" : "@trappermarkelz Yes! But I do think that investing is not as interesting as prediction/stating beliefs with accountability.",
  "id" : 166949005841018880,
  "in_reply_to_status_id" : 166893976488656898,
  "created_at" : "2012-02-07 18:18:39 +0000",
  "in_reply_to_screen_name" : "trappermarkelz",
  "in_reply_to_user_id_str" : "1032241",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amelia Greenhall",
      "screen_name" : "ameliagreenhall",
      "indices" : [ 3, 19 ],
      "id_str" : "246531241",
      "id" : 246531241
    }, {
      "name" : "Budge",
      "screen_name" : "budge",
      "indices" : [ 64, 70 ],
      "id_str" : "286384512",
      "id" : 286384512
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "thesnailmakesfunofyo",
      "indices" : [ 115, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "166759637998239745",
  "text" : "RT @ameliagreenhall: 8 out of ten people who have tried the new @budge flossing program have successfully flossed. #thesnailmakesfunofyo ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Budge",
        "screen_name" : "budge",
        "indices" : [ 43, 49 ],
        "id_str" : "286384512",
        "id" : 286384512
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "thesnailmakesfunofyouuntilyoudo",
        "indices" : [ 94, 126 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "166758096604114944",
    "text" : "8 out of ten people who have tried the new @budge flossing program have successfully flossed. #thesnailmakesfunofyouuntilyoudo",
    "id" : 166758096604114944,
    "created_at" : "2012-02-07 05:40:03 +0000",
    "user" : {
      "name" : "Amelia Greenhall",
      "screen_name" : "ameliagreenhall",
      "protected" : false,
      "id_str" : "246531241",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000183057643/da88438620af670d8728d2dc19ca3843_normal.jpeg",
      "id" : 246531241,
      "verified" : false
    }
  },
  "id" : 166759637998239745,
  "created_at" : "2012-02-07 05:46:10 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u028E\u01DD\u029E\u0254\u0131\u0265 \u0287\u0287\u0250\u026F",
      "screen_name" : "matthickey",
      "indices" : [ 0, 11 ],
      "id_str" : "8710082",
      "id" : 8710082
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "166755241663012865",
  "geo" : { },
  "id_str" : "166756555872673793",
  "in_reply_to_user_id" : 8710082,
  "text" : "@matthickey No, I want accountability.",
  "id" : 166756555872673793,
  "in_reply_to_status_id" : 166755241663012865,
  "created_at" : "2012-02-07 05:33:55 +0000",
  "in_reply_to_screen_name" : "matthickey",
  "in_reply_to_user_id_str" : "8710082",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Colin Henry",
      "screen_name" : "jchenry",
      "indices" : [ 0, 8 ],
      "id_str" : "113988145",
      "id" : 113988145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "166751952661790722",
  "geo" : { },
  "id_str" : "166752876784386049",
  "in_reply_to_user_id" : 113988145,
  "text" : "@jchenry Reputation has a bad rep.",
  "id" : 166752876784386049,
  "in_reply_to_status_id" : 166751952661790722,
  "created_at" : "2012-02-07 05:19:18 +0000",
  "in_reply_to_screen_name" : "jchenry",
  "in_reply_to_user_id_str" : "113988145",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirill Zubovsky",
      "screen_name" : "kirillzubovsky",
      "indices" : [ 3, 18 ],
      "id_str" : "17541787",
      "id" : 17541787
    }, {
      "name" : "Anti-Buster",
      "screen_name" : "busterbenson",
      "indices" : [ 20, 33 ],
      "id_str" : "1024917050",
      "id" : 1024917050
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "166752680763596800",
  "text" : "RT @kirillzubovsky: @busterbenson don't be hating on my php-fueled social media content aggregator for health related issues for cats ag ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Anti-Buster",
        "screen_name" : "busterbenson",
        "indices" : [ 0, 13 ],
        "id_str" : "1024917050",
        "id" : 1024917050
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "166749010516914176",
    "geo" : { },
    "id_str" : "166752600904056833",
    "in_reply_to_user_id" : 2185,
    "text" : "@busterbenson don't be hating on my php-fueled social media content aggregator for health related issues for cats ages 12-14.",
    "id" : 166752600904056833,
    "in_reply_to_status_id" : 166749010516914176,
    "created_at" : "2012-02-07 05:18:12 +0000",
    "in_reply_to_screen_name" : "buster",
    "in_reply_to_user_id_str" : "2185",
    "user" : {
      "name" : "Kirill Zubovsky",
      "screen_name" : "kirillzubovsky",
      "protected" : false,
      "id_str" : "17541787",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000200686152/949c98ac97811c76793d5e032630f892_normal.jpeg",
      "id" : 17541787,
      "verified" : false
    }
  },
  "id" : 166752680763596800,
  "created_at" : "2012-02-07 05:18:31 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "i.am.donte",
      "screen_name" : "iamdonte",
      "indices" : [ 3, 12 ],
      "id_str" : "17977759",
      "id" : 17977759
    }, {
      "name" : "Anti-Buster",
      "screen_name" : "busterbenson",
      "indices" : [ 14, 27 ],
      "id_str" : "1024917050",
      "id" : 1024917050
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "166752122292027392",
  "text" : "RT @iamdonte: @busterbenson Before clicking I was hoping it said \"Yo mama so fat...\"",
  "retweeted_status" : {
    "source" : "<a href=\"http://ubersocial.com\" rel=\"nofollow\">UberSocial for Android</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Anti-Buster",
        "screen_name" : "busterbenson",
        "indices" : [ 0, 13 ],
        "id_str" : "1024917050",
        "id" : 1024917050
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "166749010516914176",
    "geo" : { },
    "id_str" : "166751952007467008",
    "in_reply_to_user_id" : 2185,
    "text" : "@busterbenson Before clicking I was hoping it said \"Yo mama so fat...\"",
    "id" : 166751952007467008,
    "in_reply_to_status_id" : 166749010516914176,
    "created_at" : "2012-02-07 05:15:38 +0000",
    "in_reply_to_screen_name" : "buster",
    "in_reply_to_user_id_str" : "2185",
    "user" : {
      "name" : "i.am.donte",
      "screen_name" : "iamdonte",
      "protected" : false,
      "id_str" : "17977759",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3382360338/8ce48a2fa41d3263d5c2e67498f7a47e_normal.png",
      "id" : 17977759,
      "verified" : false
    }
  },
  "id" : 166752122292027392,
  "created_at" : "2012-02-07 05:16:18 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "166751679545475072",
  "text" : "Basically, I wish there was a central place to place friendly bets on non-public startups. Dealing in reputation rather than money/access.",
  "id" : 166751679545475072,
  "created_at" : "2012-02-07 05:14:33 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Dole",
      "screen_name" : "adamdole",
      "indices" : [ 0, 9 ],
      "id_str" : "14789168",
      "id" : 14789168
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "166750215418822656",
  "geo" : { },
  "id_str" : "166750707003817984",
  "in_reply_to_user_id" : 14789168,
  "text" : "@adamdole Oh, me too! I'm generally pretty lenient with people and ideas\u2026 going out and building in the face of criticism is a rare trait.",
  "id" : 166750707003817984,
  "in_reply_to_status_id" : 166750215418822656,
  "created_at" : "2012-02-07 05:10:41 +0000",
  "in_reply_to_screen_name" : "adamdole",
  "in_reply_to_user_id_str" : "14789168",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Chou",
      "screen_name" : "garychou",
      "indices" : [ 0, 9 ],
      "id_str" : "29058287",
      "id" : 29058287
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "166749229157584898",
  "geo" : { },
  "id_str" : "166749945154646016",
  "in_reply_to_user_id" : 29058287,
  "text" : "@garychou It would! Someone else would have to do it though\u2026 I'm too busy trying to avoid that fate myself! :)",
  "id" : 166749945154646016,
  "in_reply_to_status_id" : 166749229157584898,
  "created_at" : "2012-02-07 05:07:39 +0000",
  "in_reply_to_screen_name" : "garychou",
  "in_reply_to_user_id_str" : "29058287",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 71 ],
      "url" : "http://t.co/WxHmlPwo",
      "expanded_url" : "http://flic.kr/p/bpTRs6",
      "display_url" : "flic.kr/p/bpTRs6"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.608833, -122.305667 ]
  },
  "id_str" : "166749010516914176",
  "text" : "8:36pm Wish I had the guts to complete this tweet: http://t.co/WxHmlPwo",
  "id" : 166749010516914176,
  "created_at" : "2012-02-07 05:03:56 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris DeVore",
      "screen_name" : "crashdev",
      "indices" : [ 3, 12 ],
      "id_str" : "14763501",
      "id" : 14763501
    }, {
      "name" : "Jon Tinter",
      "screen_name" : "jontinter",
      "indices" : [ 117, 127 ],
      "id_str" : "11809242",
      "id" : 11809242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "166739254452559872",
  "text" : "RT @crashdev: \"The Virtues of Autonomy, Efficiency and Skepticism\" - Dr. Seuss titles deconstructed, pure genius! HT @jontinter http://t ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jon Tinter",
        "screen_name" : "jontinter",
        "indices" : [ 103, 113 ],
        "id_str" : "11809242",
        "id" : 11809242
      } ],
      "media" : [ {
        "expanded_url" : "http://twitter.com/crashdev/status/166738269986492416/photo/1",
        "indices" : [ 114, 134 ],
        "url" : "http://t.co/gHqe3Rqc",
        "media_url" : "http://pbs.twimg.com/media/AlBfkrmCEAAjRkD.jpg",
        "id_str" : "166738269994881024",
        "id" : 166738269994881024,
        "media_url_https" : "https://pbs.twimg.com/media/AlBfkrmCEAAjRkD.jpg",
        "sizes" : [ {
          "h" : 407,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 230,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 685,
          "resize" : "fit",
          "w" : 1011
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 685,
          "resize" : "fit",
          "w" : 1011
        } ],
        "display_url" : "pic.twitter.com/gHqe3Rqc"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "166738269986492416",
    "text" : "\"The Virtues of Autonomy, Efficiency and Skepticism\" - Dr. Seuss titles deconstructed, pure genius! HT @jontinter http://t.co/gHqe3Rqc",
    "id" : 166738269986492416,
    "created_at" : "2012-02-07 04:21:16 +0000",
    "user" : {
      "name" : "Chris DeVore",
      "screen_name" : "crashdev",
      "protected" : false,
      "id_str" : "14763501",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1575672961/CHD_Headshot_normal.png",
      "id" : 14763501,
      "verified" : false
    }
  },
  "id" : 166739254452559872,
  "created_at" : "2012-02-07 04:25:10 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Cole",
      "screen_name" : "irondavy",
      "indices" : [ 3, 12 ],
      "id_str" : "14986129",
      "id" : 14986129
    }, {
      "name" : "/mentoring",
      "screen_name" : "mentoring",
      "indices" : [ 80, 90 ],
      "id_str" : "360733236",
      "id" : 360733236
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "166630642992418816",
  "text" : "RT @irondavy: A new blog by me where I write about design for the benefit of my @mentoring mentorees (mentees? manatees?): http://t.co/q ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "/mentoring",
        "screen_name" : "mentoring",
        "indices" : [ 66, 76 ],
        "id_str" : "360733236",
        "id" : 360733236
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 109, 129 ],
        "url" : "http://t.co/qCPv0uEb",
        "expanded_url" : "http://trash.davidcole.me/post/17160314475/breaking-mentoring",
        "display_url" : "trash.davidcole.me/post/171603144\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "166584628252131328",
    "text" : "A new blog by me where I write about design for the benefit of my @mentoring mentorees (mentees? manatees?): http://t.co/qCPv0uEb",
    "id" : 166584628252131328,
    "created_at" : "2012-02-06 18:10:45 +0000",
    "user" : {
      "name" : "David Cole",
      "screen_name" : "irondavy",
      "protected" : false,
      "id_str" : "14986129",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000439160621/2e9df852495d884169a264c2609c2b57_normal.jpeg",
      "id" : 14986129,
      "verified" : false
    }
  },
  "id" : 166630642992418816,
  "created_at" : "2012-02-06 21:13:35 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u24D5\u24E3",
      "screen_name" : "folktrash",
      "indices" : [ 0, 10 ],
      "id_str" : "15265271",
      "id" : 15265271
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "166594560246558720",
  "geo" : { },
  "id_str" : "166594964866859009",
  "in_reply_to_user_id" : 15265271,
  "text" : "@folktrash Go to Broadcast Coffee on 20th and Yesler. It's a cool coffee shop as well.",
  "id" : 166594964866859009,
  "in_reply_to_status_id" : 166594560246558720,
  "created_at" : "2012-02-06 18:51:49 +0000",
  "in_reply_to_screen_name" : "folktrash",
  "in_reply_to_user_id_str" : "15265271",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u24D5\u24E3",
      "screen_name" : "folktrash",
      "indices" : [ 0, 10 ],
      "id_str" : "15265271",
      "id" : 15265271
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "166593161026732032",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6008522092, -122.3066213542 ]
  },
  "id_str" : "166594483641794560",
  "in_reply_to_user_id" : 15265271,
  "text" : "@folktrash Yup.",
  "id" : 166594483641794560,
  "in_reply_to_status_id" : 166593161026732032,
  "created_at" : "2012-02-06 18:49:54 +0000",
  "in_reply_to_screen_name" : "folktrash",
  "in_reply_to_user_id_str" : "15265271",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 126 ],
      "url" : "http://t.co/MkVKmFS5",
      "expanded_url" : "http://4sq.com/AfAaZT",
      "display_url" : "4sq.com/AfAaZT"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6016490655, -122.3065853119 ]
  },
  "id_str" : "166592226812641280",
  "text" : "Just used Square's awesome tab feature for 1st time here. Only thing it didn't do was check me in on 4sq! http://t.co/MkVKmFS5",
  "id" : 166592226812641280,
  "created_at" : "2012-02-06 18:40:56 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Sippey",
      "screen_name" : "sippey",
      "indices" : [ 3, 10 ],
      "id_str" : "4711",
      "id" : 4711
    }, {
      "name" : "Kris Kr\u00FCg",
      "screen_name" : "kk",
      "indices" : [ 13, 16 ],
      "id_str" : "13669",
      "id" : 13669
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 139 ],
      "url" : "http://t.co/jY9KuiFL",
      "expanded_url" : "http://www.kk.org/thetechnium/archives/2012/02/next_phase_of_c.php?utm_source=feedburner&utm_medium=email&utm_campaign=Feed%3A+thetechnium+%28The+Technium%29",
      "display_url" : "kk.org/thetechnium/ar\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "166547512411422721",
  "text" : "RT @sippey: .@kk on super bowl advertising: \"the early clips were commercials for the commercials of the commercials.\" http://t.co/jY9KuiFL",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.apple.com\" rel=\"nofollow\">Safari on iOS</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kris Kr\u00FCg",
        "screen_name" : "kk",
        "indices" : [ 1, 4 ],
        "id_str" : "13669",
        "id" : 13669
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 107, 127 ],
        "url" : "http://t.co/jY9KuiFL",
        "expanded_url" : "http://www.kk.org/thetechnium/archives/2012/02/next_phase_of_c.php?utm_source=feedburner&utm_medium=email&utm_campaign=Feed%3A+thetechnium+%28The+Technium%29",
        "display_url" : "kk.org/thetechnium/ar\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "166522167306100736",
    "text" : ".@kk on super bowl advertising: \"the early clips were commercials for the commercials of the commercials.\" http://t.co/jY9KuiFL",
    "id" : 166522167306100736,
    "created_at" : "2012-02-06 14:02:33 +0000",
    "user" : {
      "name" : "Michael Sippey",
      "screen_name" : "sippey",
      "protected" : false,
      "id_str" : "4711",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3541799518/c8ea5593267cad82eb9de763a9456d3b_normal.jpeg",
      "id" : 4711,
      "verified" : false
    }
  },
  "id" : 166547512411422721,
  "created_at" : "2012-02-06 15:43:15 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 77 ],
      "url" : "http://t.co/8nsdFYzg",
      "expanded_url" : "http://flic.kr/p/bpmDpX",
      "display_url" : "flic.kr/p/bpmDpX"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6085, -122.306167 ]
  },
  "id_str" : "166390635706843137",
  "text" : "8:36pm Catching up on what PhoneGap has improved lately. http://t.co/8nsdFYzg",
  "id" : 166390635706843137,
  "created_at" : "2012-02-06 05:19:53 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Will Rogers",
      "screen_name" : "spozbo",
      "indices" : [ 3, 10 ],
      "id_str" : "326617601",
      "id" : 326617601
    }, {
      "name" : "Anti-Buster",
      "screen_name" : "busterbenson",
      "indices" : [ 12, 25 ],
      "id_str" : "1024917050",
      "id" : 1024917050
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "166388031715151872",
  "text" : "RT @spozbo: @busterbenson the patriots had more tweets when they were in the lead, and now (after the game) the giants are in the lead",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Anti-Buster",
        "screen_name" : "busterbenson",
        "indices" : [ 0, 13 ],
        "id_str" : "1024917050",
        "id" : 1024917050
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "166299055016779779",
    "geo" : { },
    "id_str" : "166382578511785984",
    "in_reply_to_user_id" : 2185,
    "text" : "@busterbenson the patriots had more tweets when they were in the lead, and now (after the game) the giants are in the lead",
    "id" : 166382578511785984,
    "in_reply_to_status_id" : 166299055016779779,
    "created_at" : "2012-02-06 04:47:52 +0000",
    "in_reply_to_screen_name" : "buster",
    "in_reply_to_user_id_str" : "2185",
    "user" : {
      "name" : "Will Rogers",
      "screen_name" : "spozbo",
      "protected" : false,
      "id_str" : "326617601",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1805297846/395957_704916684875_72401204_33993530_157637356_n_normal.jpg",
      "id" : 326617601,
      "verified" : false
    }
  },
  "id" : 166388031715151872,
  "created_at" : "2012-02-06 05:09:32 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "166299055016779779",
  "text" : "What's ultimately more important for a team to get: points or tweets? Or are they the same thing?",
  "id" : 166299055016779779,
  "created_at" : "2012-02-05 23:15:59 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Sacca",
      "screen_name" : "sacca",
      "indices" : [ 56, 62 ],
      "id_str" : "586",
      "id" : 586
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "superbowl",
      "indices" : [ 17, 27 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 103 ],
      "url" : "https://t.co/WPFI55Kt",
      "expanded_url" : "https://sb46.twitter.com/",
      "display_url" : "sb46.twitter.com"
    } ]
  },
  "geo" : { },
  "id_str" : "166297951591862273",
  "text" : "Not watching the #superbowl but this is pretty cool. RT @sacca: This site is hot: https://t.co/WPFI55Kt",
  "id" : 166297951591862273,
  "created_at" : "2012-02-05 23:11:35 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 100 ],
      "url" : "http://t.co/i3sRjYNj",
      "expanded_url" : "http://flic.kr/p/boJHui",
      "display_url" : "flic.kr/p/boJHui"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6085, -122.306 ]
  },
  "id_str" : "166018638195855360",
  "text" : "8:36pm Celebrating birth with Aimee before heading over to celebrate with Megan http://t.co/i3sRjYNj",
  "id" : 166018638195855360,
  "created_at" : "2012-02-05 04:41:42 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "i.am.donte",
      "screen_name" : "iamdonte",
      "indices" : [ 0, 9 ],
      "id_str" : "17977759",
      "id" : 17977759
    }, {
      "name" : "&y",
      "screen_name" : "andypixel",
      "indices" : [ 40, 50 ],
      "id_str" : "10015122",
      "id" : 10015122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "165936950149259264",
  "geo" : { },
  "id_str" : "165988329815412736",
  "in_reply_to_user_id" : 17977759,
  "text" : "@iamdonte According to twitter, you and @andypixel hanging out together would create a fun explosion!",
  "id" : 165988329815412736,
  "in_reply_to_status_id" : 165936950149259264,
  "created_at" : "2012-02-05 02:41:16 +0000",
  "in_reply_to_screen_name" : "iamdonte",
  "in_reply_to_user_id_str" : "17977759",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Graham Kendall",
      "screen_name" : "Graham_Kendall",
      "indices" : [ 0, 15 ],
      "id_str" : "180287955",
      "id" : 180287955
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "165985736791822336",
  "in_reply_to_user_id" : 180287955,
  "text" : "@Graham_Kendall Why didn't you re-run the Prisoner's Dilemma tournament in 2005? Was collusion too difficult to avoid with players?",
  "id" : 165985736791822336,
  "created_at" : "2012-02-05 02:30:58 +0000",
  "in_reply_to_screen_name" : "Graham_Kendall",
  "in_reply_to_user_id_str" : "180287955",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "altruism",
      "indices" : [ 129, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 128 ],
      "url" : "http://t.co/zIwE00L8",
      "expanded_url" : "http://www.wired.com/culture/lifestyle/news/2004/10/65317",
      "display_url" : "wired.com/culture/lifest\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "165981390876323840",
  "text" : "Interesting results from a 2004 competition for Iterated Prisoner's Dilemma where \"Tit for Tat\" didn't win: http://t.co/zIwE00L8 #altruism",
  "id" : 165981390876323840,
  "created_at" : "2012-02-05 02:13:42 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charlie Park",
      "screen_name" : "charliepark",
      "indices" : [ 3, 15 ],
      "id_str" : "3225381",
      "id" : 3225381
    }, {
      "name" : "Anti-Buster",
      "screen_name" : "busterbenson",
      "indices" : [ 17, 30 ],
      "id_str" : "1024917050",
      "id" : 1024917050
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "165929617868337152",
  "text" : "RT @charliepark: @busterbenson I'm going to go with \u201Cme\u201D. Although my fun might not be everyone's. Last night: programming, by a fire, w ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Anti-Buster",
        "screen_name" : "busterbenson",
        "indices" : [ 0, 13 ],
        "id_str" : "1024917050",
        "id" : 1024917050
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "165927668569751553",
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 37.3747622827, -76.9476453961 ]
    },
    "id_str" : "165928967545683968",
    "in_reply_to_user_id" : 2185,
    "text" : "@busterbenson I'm going to go with \u201Cme\u201D. Although my fun might not be everyone's. Last night: programming, by a fire, with a rootbeer float.",
    "id" : 165928967545683968,
    "in_reply_to_status_id" : 165927668569751553,
    "created_at" : "2012-02-04 22:45:23 +0000",
    "in_reply_to_screen_name" : "buster",
    "in_reply_to_user_id_str" : "2185",
    "user" : {
      "name" : "Charlie Park",
      "screen_name" : "charliepark",
      "protected" : false,
      "id_str" : "3225381",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1829312406/charlie_park_normal.png",
      "id" : 3225381,
      "verified" : false
    }
  },
  "id" : 165929617868337152,
  "created_at" : "2012-02-04 22:47:58 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Beth Bates",
      "screen_name" : "bethbates",
      "indices" : [ 0, 10 ],
      "id_str" : "18231040",
      "id" : 18231040
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "165928366648737792",
  "geo" : { },
  "id_str" : "165929118544830464",
  "in_reply_to_user_id" : 18231040,
  "text" : "@bethbates I wish!",
  "id" : 165929118544830464,
  "in_reply_to_status_id" : 165928366648737792,
  "created_at" : "2012-02-04 22:45:59 +0000",
  "in_reply_to_screen_name" : "bethbates",
  "in_reply_to_user_id_str" : "18231040",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Neilson",
      "screen_name" : "TheCulprit",
      "indices" : [ 0, 11 ],
      "id_str" : "6726182",
      "id" : 6726182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "165928382880694272",
  "geo" : { },
  "id_str" : "165929049477226497",
  "in_reply_to_user_id" : 6726182,
  "text" : "@TheCulprit I'm not sure about artists. But 8 year olds: yes!",
  "id" : 165929049477226497,
  "in_reply_to_status_id" : 165928382880694272,
  "created_at" : "2012-02-04 22:45:42 +0000",
  "in_reply_to_screen_name" : "TheCulprit",
  "in_reply_to_user_id_str" : "6726182",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "165927668569751553",
  "text" : "Who, out of everyone, has the most fun?",
  "id" : 165927668569751553,
  "created_at" : "2012-02-04 22:40:13 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.apple.com\" rel=\"nofollow\">Safari on iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "psychology",
      "indices" : [ 68, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 100 ],
      "url" : "http://t.co/pNdgFcwC",
      "expanded_url" : "http://online.wsj.com/article/SB10001424052970204740904577193413554397928.html?mod=wsj_share_tweet",
      "display_url" : "online.wsj.com/article/SB1000\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.608654, -122.306299 ]
  },
  "id_str" : "165824853725818881",
  "text" : "A balanced dopamine system turns out to produce the best investors. #psychology http://t.co/pNdgFcwC",
  "id" : 165824853725818881,
  "created_at" : "2012-02-04 15:51:40 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://summify.com\" rel=\"nofollow\">Summify</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Summify",
      "screen_name" : "summify",
      "indices" : [ 60, 68 ],
      "id_str" : "66700936",
      "id" : 66700936
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 54 ],
      "url" : "http://t.co/5WnMdDXT",
      "expanded_url" : "http://smf.is/1FxhJB",
      "display_url" : "smf.is/1FxhJB"
    } ]
  },
  "geo" : { },
  "id_str" : "165822974711173120",
  "text" : "Do the dead outnumber the living? http://t.co/5WnMdDXT (via @summify)",
  "id" : 165822974711173120,
  "created_at" : "2012-02-04 15:44:12 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 41 ],
      "url" : "http://t.co/xH6Lkfe8",
      "expanded_url" : "http://flic.kr/p/boeUue",
      "display_url" : "flic.kr/p/boeUue"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6155, -122.330667 ]
  },
  "id_str" : "165655763249930240",
  "text" : "8:36pm Walking home. http://t.co/xH6Lkfe8",
  "id" : 165655763249930240,
  "created_at" : "2012-02-04 04:39:46 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 83 ],
      "url" : "http://t.co/lldV5M9v",
      "expanded_url" : "http://www.amazon.com/dp/0465005640/ref=cm_sw_r_tw_asp_ADs8D.1V3S9GH",
      "display_url" : "amazon.com/dp/0465005640/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "165326660223246336",
  "text" : "I just bought 'The Evolution of Cooperation' by Robert Axelrod http://t.co/lldV5M9v (talks about iterated prisoners' dilemma strategy)",
  "id" : 165326660223246336,
  "created_at" : "2012-02-03 06:52:02 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 65 ],
      "url" : "http://t.co/RguKqqRX",
      "expanded_url" : "http://flic.kr/p/bnNtuM",
      "display_url" : "flic.kr/p/bnNtuM"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.608666, -122.306167 ]
  },
  "id_str" : "165294181567311872",
  "text" : "8:36pm Feeling a little nutty and scattered. http://t.co/RguKqqRX",
  "id" : 165294181567311872,
  "created_at" : "2012-02-03 04:42:58 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amber Rae",
      "screen_name" : "heyamberrae",
      "indices" : [ 0, 12 ],
      "id_str" : "15019184",
      "id" : 15019184
    }, {
      "name" : "Shawn Achor",
      "screen_name" : "shawnachor",
      "indices" : [ 94, 105 ],
      "id_str" : "51085686",
      "id" : 51085686
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "165271504836231169",
  "geo" : { },
  "id_str" : "165275118677934080",
  "in_reply_to_user_id" : 15019184,
  "text" : "@heyamberrae You're right! I've probably watched it 5 times already! Topic is right on... AND @shawnachor is also a great speaker.",
  "id" : 165275118677934080,
  "in_reply_to_status_id" : 165271504836231169,
  "created_at" : "2012-02-03 03:27:13 +0000",
  "in_reply_to_screen_name" : "heyamberrae",
  "in_reply_to_user_id_str" : "15019184",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Venessa Goldberg",
      "screen_name" : "kernelsandseeds",
      "indices" : [ 0, 16 ],
      "id_str" : "174538822",
      "id" : 174538822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "165154151188267008",
  "geo" : { },
  "id_str" : "165159951382233091",
  "in_reply_to_user_id" : 174538822,
  "text" : "@kernelsandseeds Hahaha. Babies, so easily confused. :)",
  "id" : 165159951382233091,
  "in_reply_to_status_id" : 165154151188267008,
  "created_at" : "2012-02-02 19:49:35 +0000",
  "in_reply_to_screen_name" : "kernelsandseeds",
  "in_reply_to_user_id_str" : "174538822",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "katrina panovich",
      "screen_name" : "katrina_",
      "indices" : [ 0, 9 ],
      "id_str" : "9381242",
      "id" : 9381242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "165140536334880768",
  "geo" : { },
  "id_str" : "165144878706204672",
  "in_reply_to_user_id" : 9381242,
  "text" : "@katrina_ Yeah sure! What days/times do you have available?",
  "id" : 165144878706204672,
  "in_reply_to_status_id" : 165140536334880768,
  "created_at" : "2012-02-02 18:49:41 +0000",
  "in_reply_to_screen_name" : "katrina_",
  "in_reply_to_user_id_str" : "9381242",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philanthropy",
      "screen_name" : "Philanthropy",
      "indices" : [ 3, 16 ],
      "id_str" : "10880202",
      "id" : 10880202
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 99 ],
      "url" : "http://t.co/UcC6I6oU",
      "expanded_url" : "http://ow.ly/1h6poO",
      "display_url" : "ow.ly/1h6poO"
    } ]
  },
  "geo" : { },
  "id_str" : "165112163848028161",
  "text" : "RT @Philanthropy: Donors Quickly Replace Planned Parenthood\u2019s Lost Komen Funds http://t.co/UcC6I6oU",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.hootsuite.com\" rel=\"nofollow\">HootSuite</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 61, 81 ],
        "url" : "http://t.co/UcC6I6oU",
        "expanded_url" : "http://ow.ly/1h6poO",
        "display_url" : "ow.ly/1h6poO"
      } ]
    },
    "geo" : { },
    "id_str" : "165110346372231170",
    "text" : "Donors Quickly Replace Planned Parenthood\u2019s Lost Komen Funds http://t.co/UcC6I6oU",
    "id" : 165110346372231170,
    "created_at" : "2012-02-02 16:32:28 +0000",
    "user" : {
      "name" : "Philanthropy",
      "screen_name" : "Philanthropy",
      "protected" : false,
      "id_str" : "10880202",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1252650541/Twitter_normal.png",
      "id" : 10880202,
      "verified" : true
    }
  },
  "id" : 165112163848028161,
  "created_at" : "2012-02-02 16:39:42 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "umair haque",
      "screen_name" : "umairh",
      "indices" : [ 3, 10 ],
      "id_str" : "14321959",
      "id" : 14321959
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 122 ],
      "url" : "http://t.co/Vqw2wbZi",
      "expanded_url" : "http://bit.ly/w283BM",
      "display_url" : "bit.ly/w283BM"
    } ]
  },
  "geo" : { },
  "id_str" : "165111643355881474",
  "text" : "RT @umairh: Create a Meaningful Life Through Meaningful Work - Umair Haque - Harvard Business Review: http://t.co/Vqw2wbZi",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 90, 110 ],
        "url" : "http://t.co/Vqw2wbZi",
        "expanded_url" : "http://bit.ly/w283BM",
        "display_url" : "bit.ly/w283BM"
      } ]
    },
    "geo" : { },
    "id_str" : "164479399654195200",
    "text" : "Create a Meaningful Life Through Meaningful Work - Umair Haque - Harvard Business Review: http://t.co/Vqw2wbZi",
    "id" : 164479399654195200,
    "created_at" : "2012-01-31 22:45:19 +0000",
    "user" : {
      "name" : "umair haque",
      "screen_name" : "umairh",
      "protected" : false,
      "id_str" : "14321959",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/129730596/2630509441_944a6ee3e2_m_normal.jpg",
      "id" : 14321959,
      "verified" : true
    }
  },
  "id" : 165111643355881474,
  "created_at" : "2012-02-02 16:37:38 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daryn Nakhuda",
      "screen_name" : "daryn",
      "indices" : [ 3, 9 ],
      "id_str" : "804808",
      "id" : 804808
    }, {
      "name" : "Amazon Local",
      "screen_name" : "AmazonLocal",
      "indices" : [ 58, 70 ],
      "id_str" : "285377790",
      "id" : 285377790
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 92 ],
      "url" : "http://t.co/xc5olrL5",
      "expanded_url" : "http://www.geekwire.com/2012/exclusive-amazoncom-buys-teachstreet",
      "display_url" : "geekwire.com/2012/exclusive\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "165099536660971520",
  "text" : "RT @daryn: It's official: the teachstreet team has joined @amazonlocal! http://t.co/xc5olrL5",
  "retweeted_status" : {
    "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Amazon Local",
        "screen_name" : "AmazonLocal",
        "indices" : [ 47, 59 ],
        "id_str" : "285377790",
        "id" : 285377790
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 61, 81 ],
        "url" : "http://t.co/xc5olrL5",
        "expanded_url" : "http://www.geekwire.com/2012/exclusive-amazoncom-buys-teachstreet",
        "display_url" : "geekwire.com/2012/exclusive\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "165092960394940416",
    "text" : "It's official: the teachstreet team has joined @amazonlocal! http://t.co/xc5olrL5",
    "id" : 165092960394940416,
    "created_at" : "2012-02-02 15:23:23 +0000",
    "user" : {
      "name" : "Daryn Nakhuda",
      "screen_name" : "daryn",
      "protected" : false,
      "id_str" : "804808",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1820149549/avatar_normal.png",
      "id" : 804808,
      "verified" : false
    }
  },
  "id" : 165099536660971520,
  "created_at" : "2012-02-02 15:49:31 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 0, 9 ],
      "id_str" : "761628",
      "id" : 761628
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "164956270833573888",
  "geo" : { },
  "id_str" : "164958010194665472",
  "in_reply_to_user_id" : 761628,
  "text" : "@RickWebb Well I look forward to hearing more when the time is right!",
  "id" : 164958010194665472,
  "in_reply_to_status_id" : 164956270833573888,
  "created_at" : "2012-02-02 06:27:09 +0000",
  "in_reply_to_screen_name" : "RickWebb",
  "in_reply_to_user_id_str" : "761628",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 0, 9 ],
      "id_str" : "761628",
      "id" : 761628
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "164953572344217600",
  "geo" : { },
  "id_str" : "164954715556290560",
  "in_reply_to_user_id" : 761628,
  "text" : "@RickWebb Ooooh! Why two?",
  "id" : 164954715556290560,
  "in_reply_to_status_id" : 164953572344217600,
  "created_at" : "2012-02-02 06:14:03 +0000",
  "in_reply_to_screen_name" : "RickWebb",
  "in_reply_to_user_id_str" : "761628",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 80 ],
      "url" : "http://t.co/9uz3N4o4",
      "expanded_url" : "http://flic.kr/p/bnkLtK",
      "display_url" : "flic.kr/p/bnkLtK"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.608666, -122.306 ]
  },
  "id_str" : "164931333020327937",
  "text" : "8:36pm Catching up on exciting gay marriage news with Sopor http://t.co/9uz3N4o4",
  "id" : 164931333020327937,
  "created_at" : "2012-02-02 04:41:08 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Waxy.org Links Feed",
      "screen_name" : "waxylinks",
      "indices" : [ 16, 26 ],
      "id_str" : "219952089",
      "id" : 219952089
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 135 ],
      "url" : "http://t.co/1vb6RwYd",
      "expanded_url" : "http://bit.ly/yOpm98",
      "display_url" : "bit.ly/yOpm98"
    } ]
  },
  "geo" : { },
  "id_str" : "164678391742742528",
  "text" : "Super scary! RT @waxylinks: Nano quadrotors flying in formation: don't miss the figure 8 pattern at the end [via]  http://t.co/1vb6RwYd",
  "id" : 164678391742742528,
  "created_at" : "2012-02-01 11:56:02 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
} ]