Grailbird.data.tweets_2006_09 = 
 [ {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "36176",
  "text" : "At the Hideout passing ridiculousness around like free kittens.",
  "id" : 36176,
  "created_at" : "2006-09-28 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "32769",
  "text" : "Applied for a new social security card today! You can call me Buster Butterfield McLeod from now on. Until I change it back, at least.",
  "id" : 32769,
  "created_at" : "2006-09-20 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28242",
  "text" : "Just hot air ballooned over Snohomish. It was awesome!",
  "id" : 28242,
  "created_at" : "2006-09-10 00:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
} ]