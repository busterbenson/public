Grailbird.data.tweets_2006_09 = 
 [ {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "36176",
  "text" : "At the Hideout passing ridiculousness around like free kittens.",
  "id" : 36176,
  "created_at" : "Thu Sep 28 05:36:57 +0000 2006",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "32769",
  "text" : "Applied for a new social security card today! You can call me Buster Butterfield McLeod from now on. Until I change it back, at least.",
  "id" : 32769,
  "created_at" : "Wed Sep 20 04:40:47 +0000 2006",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "28242",
  "text" : "Just hot air ballooned over Snohomish. It was awesome!",
  "id" : 28242,
  "created_at" : "Sun Sep 10 18:47:14 +0000 2006",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
} ]