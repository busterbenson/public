Grailbird.data.tweets_2013_01 = 
[ {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anil Dash",
      "screen_name" : "anildash",
      "indices" : [ 0, 9 ],
      "id_str" : "36823",
      "id" : 36823
    }, {
      "name" : "Malthe Sigurdsson",
      "screen_name" : "malthe",
      "indices" : [ 10, 17 ],
      "id_str" : "496223",
      "id" : 496223
    }, {
      "name" : "David Jacobs",
      "screen_name" : "djacobs",
      "indices" : [ 19, 27 ],
      "id_str" : "774842",
      "id" : 774842
    }, {
      "name" : "Isaac Hepworth",
      "screen_name" : "isaach",
      "indices" : [ 28, 35 ],
      "id_str" : "7852612",
      "id" : 7852612
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/buster/status/288820877972344833/photo/1",
      "indices" : [ 93, 113 ],
      "url" : "http://t.co/gT7cJ2XR",
      "media_url" : "http://pbs.twimg.com/media/BAIZDuuCEAAKvFe.jpg",
      "id_str" : "288820877976539136",
      "id" : 288820877976539136,
      "media_url_https" : "https://pbs.twimg.com/media/BAIZDuuCEAAKvFe.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com/gT7cJ2XR"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288820248969367552",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.77687722588112, -122.4172509191793 ]
  },
  "id_str" : "288820877972344833",
  "in_reply_to_user_id" : 496223,
  "text" : "@anildash @malthe  @djacobs @isaach Yeah, cohort retention graphs looks something like this: http://t.co/gT7cJ2XR",
  "id" : 288820877972344833,
  "in_reply_to_status_id" : 288820248969367552,
  "created_at" : "Wed Jan 09 01:33:58 +0000 2013",
  "in_reply_to_screen_name" : "malthe",
  "in_reply_to_user_id_str" : "496223",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anil Dash",
      "screen_name" : "anildash",
      "indices" : [ 0, 9 ],
      "id_str" : "36823",
      "id" : 36823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288811555150241793",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.77692114742001, -122.4172114846978 ]
  },
  "id_str" : "288812991837794304",
  "in_reply_to_user_id" : 36823,
  "text" : "@anildash Okay, yeah, so feeds work well in ThinkUp + social media, but not for all cases of web-based dashboard analytics.",
  "id" : 288812991837794304,
  "in_reply_to_status_id" : 288811555150241793,
  "created_at" : "Wed Jan 09 01:02:37 +0000 2013",
  "in_reply_to_screen_name" : "anildash",
  "in_reply_to_user_id_str" : "36823",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anil Dash",
      "screen_name" : "anildash",
      "indices" : [ 0, 9 ],
      "id_str" : "36823",
      "id" : 36823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288810187798745089",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7769516398, -122.4171978842 ]
  },
  "id_str" : "288811299587117057",
  "in_reply_to_user_id" : 36823,
  "text" : "@anildash True but if you wanna make data-based decisions, you gotta be at least a bit advanced. It's really easy to reach bad conclusions.",
  "id" : 288811299587117057,
  "in_reply_to_status_id" : 288810187798745089,
  "created_at" : "Wed Jan 09 00:55:54 +0000 2013",
  "in_reply_to_screen_name" : "anildash",
  "in_reply_to_user_id_str" : "36823",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Isaac Hepworth",
      "screen_name" : "isaach",
      "indices" : [ 0, 7 ],
      "id_str" : "7852612",
      "id" : 7852612
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288809935117094912",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.77699654347968, -122.4172156978945 ]
  },
  "id_str" : "288810471417597953",
  "in_reply_to_user_id" : 7852612,
  "text" : "@isaach I'll dig something up or draw a picture.",
  "id" : 288810471417597953,
  "in_reply_to_status_id" : 288809935117094912,
  "created_at" : "Wed Jan 09 00:52:36 +0000 2013",
  "in_reply_to_screen_name" : "isaach",
  "in_reply_to_user_id_str" : "7852612",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anil Dash",
      "screen_name" : "anildash",
      "indices" : [ 0, 9 ],
      "id_str" : "36823",
      "id" : 36823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 75 ],
      "url" : "http://t.co/iMFYGO9n",
      "expanded_url" : "http://bit.ly/TJK7M2",
      "display_url" : "bit.ly/TJK7M2"
    } ]
  },
  "in_reply_to_status_id_str" : "288792168326381568",
  "geo" : {
  },
  "id_str" : "288808362378948608",
  "in_reply_to_user_id" : 36823,
  "text" : "@anildash My response got a bit long, so I blogged it: http://t.co/iMFYGO9n",
  "id" : 288808362378948608,
  "in_reply_to_status_id" : 288792168326381568,
  "created_at" : "Wed Jan 09 00:44:14 +0000 2013",
  "in_reply_to_screen_name" : "anildash",
  "in_reply_to_user_id_str" : "36823",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenna Wortham  ",
      "screen_name" : "jennydeluxe",
      "indices" : [ 3, 15 ],
      "id_str" : "10454572",
      "id" : 10454572
    }, {
      "name" : "Mathew Ingram",
      "screen_name" : "mathewi",
      "indices" : [ 43, 51 ],
      "id_str" : "824157",
      "id" : 824157
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "288759303370850304",
  "text" : "RT @jennydeluxe: Singularity starts now RT @mathewi Twitter uses Mechanical Turk workers to help it understand trending topics http://t. ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mathew Ingram",
        "screen_name" : "mathewi",
        "indices" : [ 26, 34 ],
        "id_str" : "824157",
        "id" : 824157
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 110, 130 ],
        "url" : "http://t.co/n5KfQvrh",
        "expanded_url" : "http://engineering.twitter.com/2013/01/improving-twitter-search-with-real-time.html",
        "display_url" : "engineering.twitter.com/2013/01/improv…"
      } ]
    },
    "geo" : {
    },
    "id_str" : "288756144086872067",
    "text" : "Singularity starts now RT @mathewi Twitter uses Mechanical Turk workers to help it understand trending topics http://t.co/n5KfQvrh …",
    "id" : 288756144086872067,
    "created_at" : "Tue Jan 08 21:16:44 +0000 2013",
    "user" : {
      "name" : "Jenna Wortham  ",
      "screen_name" : "jennydeluxe",
      "protected" : false,
      "id_str" : "10454572",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1541555730/qbEleAiJKZJRKqceqLRo_normal.gif",
      "id" : 10454572,
      "verified" : true
    }
  },
  "id" : 288759303370850304,
  "created_at" : "Tue Jan 08 21:29:17 +0000 2013",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Kelly",
      "screen_name" : "kevin2kelly",
      "indices" : [ 55, 67 ],
      "id_str" : "1532061",
      "id" : 1532061
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 50 ],
      "url" : "http://t.co/dSgf3PJ4",
      "expanded_url" : "http://fnd.gs/13gF7Bo",
      "display_url" : "fnd.gs/13gF7Bo"
    } ]
  },
  "geo" : {
  },
  "id_str" : "288752540307296257",
  "text" : "The Post-Productivity Economy http://t.co/dSgf3PJ4 /by @kevin2kelly",
  "id" : 288752540307296257,
  "created_at" : "Tue Jan 08 21:02:25 +0000 2013",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Davidson",
      "screen_name" : "mikeindustries",
      "indices" : [ 3, 18 ],
      "id_str" : "74523",
      "id" : 74523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 118 ],
      "url" : "http://t.co/zkrX9Onj",
      "expanded_url" : "http://www.businessinsider.com/why-the-mint-the-coin-debate-could-be-the-most-important-fiscal-policy-debate-youll-ever-see-in-your-life-2013-1",
      "display_url" : "businessinsider.com/why-the-mint-t…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "288710935235936257",
  "text" : "RT @mikeindustries: Finally caught up on the trillion dollar coin debate. Excellent reading here: http://t.co/zkrX9Onj",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 78, 98 ],
        "url" : "http://t.co/zkrX9Onj",
        "expanded_url" : "http://www.businessinsider.com/why-the-mint-the-coin-debate-could-be-the-most-important-fiscal-policy-debate-youll-ever-see-in-your-life-2013-1",
        "display_url" : "businessinsider.com/why-the-mint-t…"
      } ]
    },
    "geo" : {
    },
    "id_str" : "288709961092042753",
    "text" : "Finally caught up on the trillion dollar coin debate. Excellent reading here: http://t.co/zkrX9Onj",
    "id" : 288709961092042753,
    "created_at" : "Tue Jan 08 18:13:13 +0000 2013",
    "user" : {
      "name" : "Mike Davidson",
      "screen_name" : "mikeindustries",
      "protected" : false,
      "id_str" : "74523",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1241788588/twitter_avatar_normal.jpg",
      "id" : 74523,
      "verified" : false
    }
  },
  "id" : 288710935235936257,
  "created_at" : "Tue Jan 08 18:17:05 +0000 2013",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dustin curtis",
      "screen_name" : "dcurtis",
      "indices" : [ 0, 8 ],
      "id_str" : "9395832",
      "id" : 9395832
    }, {
      "name" : "Svbtle Feed",
      "screen_name" : "SvbtleFeed",
      "indices" : [ 83, 94 ],
      "id_str" : "776098190",
      "id" : 776098190
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 131 ],
      "url" : "http://t.co/EEMPWiv6",
      "expanded_url" : "http://blog.svbtle.com/svbtle-funding",
      "display_url" : "blog.svbtle.com/svbtle-funding"
    } ]
  },
  "geo" : {
  },
  "id_str" : "288706482768314368",
  "in_reply_to_user_id" : 9395832,
  "text" : "@dcurtis Congrats on funding! PS - the link here + on the homepage doesn't work RT @SvbtleFeed: Svbtle funding http://t.co/EEMPWiv6",
  "id" : 288706482768314368,
  "created_at" : "Tue Jan 08 17:59:24 +0000 2013",
  "in_reply_to_screen_name" : "dcurtis",
  "in_reply_to_user_id_str" : "9395832",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 62 ],
      "url" : "http://t.co/QCXl9u1Z",
      "expanded_url" : "http://flic.kr/p/dJHGyn",
      "display_url" : "flic.kr/p/dJHGyn"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7735, -122.422167 ]
  },
  "id_str" : "288531954553458688",
  "text" : "8:36pm I like my coworkers, they are smrt http://t.co/QCXl9u1Z",
  "id" : 288531954553458688,
  "created_at" : "Tue Jan 08 06:25:53 +0000 2013",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brendan Donohoe",
      "screen_name" : "bdonohoe",
      "indices" : [ 12, 21 ],
      "id_str" : "1193421",
      "id" : 1193421
    }, {
      "name" : "Reeve S. Thompson",
      "screen_name" : "Reeve",
      "indices" : [ 22, 28 ],
      "id_str" : "9317922",
      "id" : 9317922
    }, {
      "name" : "Brian Ellin",
      "screen_name" : "brianellin",
      "indices" : [ 29, 40 ],
      "id_str" : "26123649",
      "id" : 26123649
    }, {
      "name" : "erin moore",
      "screen_name" : "emoore",
      "indices" : [ 41, 48 ],
      "id_str" : "23640904",
      "id" : 23640904
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 97 ],
      "url" : "http://t.co/zkBkmm1h",
      "expanded_url" : "http://4sq.com/TZbIaJ",
      "display_url" : "4sq.com/TZbIaJ"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.773536, -122.42211 ]
  },
  "id_str" : "288462580840792065",
  "text" : "Drinks with @bdonohoe @reeve @brianellin @emoore (@ Hotel Biron w/ 2 others) http://t.co/zkBkmm1h",
  "id" : 288462580840792065,
  "created_at" : "Tue Jan 08 01:50:13 +0000 2013",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 110 ],
      "url" : "http://t.co/MpwUgJO2",
      "expanded_url" : "http://bit.ly/WERGRi",
      "display_url" : "bit.ly/WERGRi"
    } ]
  },
  "geo" : {
  },
  "id_str" : "288384490286485504",
  "text" : "Interesting take on why people don't seem to like 48 frames per second in the new Hobbit: http://t.co/MpwUgJO2",
  "id" : 288384490286485504,
  "created_at" : "Mon Jan 07 20:39:55 +0000 2013",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/buster/status/288369671370051585/photo/1",
      "indices" : [ 47, 67 ],
      "url" : "http://t.co/ikuv09Xh",
      "media_url" : "http://pbs.twimg.com/media/BAB-sDJCEAAdmt2.png",
      "id_str" : "288369671374245888",
      "id" : 288369671374245888,
      "media_url_https" : "https://pbs.twimg.com/media/BAB-sDJCEAAdmt2.png",
      "sizes" : [ {
        "h" : 580,
        "resize" : "fit",
        "w" : 516
      }, {
        "h" : 382,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 580,
        "resize" : "fit",
        "w" : 516
      }, {
        "h" : 580,
        "resize" : "fit",
        "w" : 516
      } ],
      "display_url" : "pic.twitter.com/ikuv09Xh"
    } ],
    "hashtags" : [ {
      "text" : "hackweek",
      "indices" : [ 0, 9 ]
    }, {
      "text" : "hackweek",
      "indices" : [ 28, 37 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "288369671370051585",
  "text" : "#hackweek is trending in my #hackweek project. http://t.co/ikuv09Xh",
  "id" : 288369671370051585,
  "created_at" : "Mon Jan 07 19:41:02 +0000 2013",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Davidson",
      "screen_name" : "mikeindustries",
      "indices" : [ 14, 29 ],
      "id_str" : "74523",
      "id" : 74523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "288361270766350336",
  "text" : "It should! MT @mikeindustries: Does a service exist which takes my Instapaper backlog &amp; mails me a nice bound periodical every month?",
  "id" : 288361270766350336,
  "created_at" : "Mon Jan 07 19:07:39 +0000 2013",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diana Kimball",
      "screen_name" : "dianakimball",
      "indices" : [ 0, 13 ],
      "id_str" : "14471007",
      "id" : 14471007
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 97 ],
      "url" : "http://t.co/ONyzEjjz",
      "expanded_url" : "http://bit.ly/WEr9nt",
      "display_url" : "bit.ly/WEr9nt"
    } ]
  },
  "in_reply_to_status_id_str" : "288347320234430464",
  "geo" : {
  },
  "id_str" : "288358075818184704",
  "in_reply_to_user_id" : 14471007,
  "text" : "@dianakimball RE 750: yeah, we're deprecating it. You can still use it here: http://t.co/ONyzEjjz but should create a password pronto. :)",
  "id" : 288358075818184704,
  "in_reply_to_status_id" : 288347320234430464,
  "created_at" : "Mon Jan 07 18:54:57 +0000 2013",
  "in_reply_to_screen_name" : "dianakimball",
  "in_reply_to_user_id_str" : "14471007",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Deacon 87",
      "screen_name" : "Deacon87",
      "indices" : [ 0, 9 ],
      "id_str" : "17628107",
      "id" : 17628107
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288203794624421888",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.77782926171349, -122.4151700952993 ]
  },
  "id_str" : "288211618888830976",
  "in_reply_to_user_id" : 17628107,
  "text" : "@Deacon87 is it MS?",
  "id" : 288211618888830976,
  "in_reply_to_status_id" : 288203794624421888,
  "created_at" : "Mon Jan 07 09:12:59 +0000 2013",
  "in_reply_to_screen_name" : "Deacon87",
  "in_reply_to_user_id_str" : "17628107",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ingopixel",
      "screen_name" : "ingopixel",
      "indices" : [ 0, 10 ],
      "id_str" : "7943892",
      "id" : 7943892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288188131990175744",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.77781510878422, -122.4151272669251 ]
  },
  "id_str" : "288192379847077888",
  "in_reply_to_user_id" : 7943892,
  "text" : "@ingopixel A bunch of Chinese iBankers have a bad day so go fishing and carb-loading til the sun goes down. And then drunk walkie-talkie.",
  "id" : 288192379847077888,
  "in_reply_to_status_id" : 288188131990175744,
  "created_at" : "Mon Jan 07 07:56:32 +0000 2013",
  "in_reply_to_screen_name" : "ingopixel",
  "in_reply_to_user_id_str" : "7943892",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Davidson",
      "screen_name" : "mikeindustries",
      "indices" : [ 0, 15 ],
      "id_str" : "74523",
      "id" : 74523
    }, {
      "name" : "Bill Couch",
      "screen_name" : "couch",
      "indices" : [ 16, 22 ],
      "id_str" : "631823",
      "id" : 631823
    }, {
      "name" : "David Jacobs",
      "screen_name" : "djacobs",
      "indices" : [ 23, 31 ],
      "id_str" : "774842",
      "id" : 774842
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288189157925343233",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.77791559094602, -122.4150865938954 ]
  },
  "id_str" : "288189795639906304",
  "in_reply_to_user_id" : 74523,
  "text" : "@mikeindustries @couch @djacobs Hm you are probably correct. But I like your RTs.",
  "id" : 288189795639906304,
  "in_reply_to_status_id" : 288189157925343233,
  "created_at" : "Mon Jan 07 07:46:16 +0000 2013",
  "in_reply_to_screen_name" : "mikeindustries",
  "in_reply_to_user_id_str" : "74523",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carinna Tarvin",
      "screen_name" : "carinnatarvin",
      "indices" : [ 0, 14 ],
      "id_str" : "20833838",
      "id" : 20833838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288181310973947904",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.77780306439661, -122.4151969054625 ]
  },
  "id_str" : "288189483709526016",
  "in_reply_to_user_id" : 20833838,
  "text" : "@carinnatarvin Wanna hop on to World of Warcraft and befriend some orcs?",
  "id" : 288189483709526016,
  "in_reply_to_status_id" : 288181310973947904,
  "created_at" : "Mon Jan 07 07:45:01 +0000 2013",
  "in_reply_to_screen_name" : "carinnatarvin",
  "in_reply_to_user_id_str" : "20833838",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Davidson",
      "screen_name" : "mikeindustries",
      "indices" : [ 0, 15 ],
      "id_str" : "74523",
      "id" : 74523
    }, {
      "name" : "Bill Couch",
      "screen_name" : "couch",
      "indices" : [ 16, 22 ],
      "id_str" : "631823",
      "id" : 631823
    }, {
      "name" : "David Jacobs",
      "screen_name" : "djacobs",
      "indices" : [ 23, 31 ],
      "id_str" : "774842",
      "id" : 774842
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hackweek",
      "indices" : [ 93, 102 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288187882450063360",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.77772097960893, -122.4153082718453 ]
  },
  "id_str" : "288188869243965441",
  "in_reply_to_user_id" : 74523,
  "text" : "@mikeindustries @couch @djacobs Accept my vote for making this a more integrated experience. #hackweek",
  "id" : 288188869243965441,
  "in_reply_to_status_id" : 288187882450063360,
  "created_at" : "Mon Jan 07 07:42:35 +0000 2013",
  "in_reply_to_screen_name" : "mikeindustries",
  "in_reply_to_user_id_str" : "74523",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Couch",
      "screen_name" : "couch",
      "indices" : [ 0, 6 ],
      "id_str" : "631823",
      "id" : 631823
    }, {
      "name" : "David Jacobs",
      "screen_name" : "djacobs",
      "indices" : [ 7, 15 ],
      "id_str" : "774842",
      "id" : 774842
    }, {
      "name" : "Mike Davidson",
      "screen_name" : "mikeindustries",
      "indices" : [ 16, 31 ],
      "id_str" : "74523",
      "id" : 74523
    }, {
      "name" : "Buster's Stellar.io",
      "screen_name" : "buster_stellar",
      "indices" : [ 68, 83 ],
      "id_str" : "1023497148",
      "id" : 1023497148
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288185298138066944",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.77801156036261, -122.4153253304242 ]
  },
  "id_str" : "288187415192014848",
  "in_reply_to_user_id" : 631823,
  "text" : "@couch @djacobs @mikeindustries That said, the short time of seeing @buster_stellar's retweets in my timeline has been an enjoyable thing.",
  "id" : 288187415192014848,
  "in_reply_to_status_id" : 288185298138066944,
  "created_at" : "Mon Jan 07 07:36:48 +0000 2013",
  "in_reply_to_screen_name" : "couch",
  "in_reply_to_user_id_str" : "631823",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Couch",
      "screen_name" : "couch",
      "indices" : [ 0, 6 ],
      "id_str" : "631823",
      "id" : 631823
    }, {
      "name" : "David Jacobs",
      "screen_name" : "djacobs",
      "indices" : [ 7, 15 ],
      "id_str" : "774842",
      "id" : 774842
    }, {
      "name" : "Mike Davidson",
      "screen_name" : "mikeindustries",
      "indices" : [ 16, 31 ],
      "id_str" : "74523",
      "id" : 74523
    }, {
      "name" : "wadpaw",
      "screen_name" : "wadpaw",
      "indices" : [ 54, 61 ],
      "id_str" : "789838819",
      "id" : 789838819
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288185298138066944",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.77802593265898, -122.4152472390358 ]
  },
  "id_str" : "288186845412610048",
  "in_reply_to_user_id" : 631823,
  "text" : "@couch @djacobs @mikeindustries I didn't even realize @wadpaw was one of \"them\".",
  "id" : 288186845412610048,
  "in_reply_to_status_id" : 288185298138066944,
  "created_at" : "Mon Jan 07 07:34:32 +0000 2013",
  "in_reply_to_screen_name" : "couch",
  "in_reply_to_user_id_str" : "631823",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "rands",
      "screen_name" : "rands",
      "indices" : [ 0, 6 ],
      "id_str" : "30923",
      "id" : 30923
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288054630892580864",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.77781782370706, -122.4152064856284 ]
  },
  "id_str" : "288186020573360128",
  "in_reply_to_user_id" : 30923,
  "text" : "@rands Or rather that monkeys are in charge.",
  "id" : 288186020573360128,
  "in_reply_to_status_id" : 288054630892580864,
  "created_at" : "Mon Jan 07 07:31:16 +0000 2013",
  "in_reply_to_screen_name" : "rands",
  "in_reply_to_user_id_str" : "30923",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Deacon 87",
      "screen_name" : "Deacon87",
      "indices" : [ 0, 9 ],
      "id_str" : "17628107",
      "id" : 17628107
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288183503131144193",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7811563273, -122.4119288175 ]
  },
  "id_str" : "288183886016573440",
  "in_reply_to_user_id" : 17628107,
  "text" : "@Deacon87 Me too. He's a curious mix of genius and grandpa.",
  "id" : 288183886016573440,
  "in_reply_to_status_id" : 288183503131144193,
  "created_at" : "Mon Jan 07 07:22:47 +0000 2013",
  "in_reply_to_screen_name" : "Deacon87",
  "in_reply_to_user_id_str" : "17628107",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Danielle Morrill",
      "screen_name" : "DanielleMorrill",
      "indices" : [ 0, 16 ],
      "id_str" : "7017692",
      "id" : 7017692
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288182363484200961",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.78352150819809, -122.4074847041389 ]
  },
  "id_str" : "288182766045106176",
  "in_reply_to_user_id" : 7017692,
  "text" : "@DanielleMorrill Sometimes you gotta trust your gut. Long term impact is the real metric anyway. Good luck!",
  "id" : 288182766045106176,
  "in_reply_to_status_id" : 288182363484200961,
  "created_at" : "Mon Jan 07 07:18:20 +0000 2013",
  "in_reply_to_screen_name" : "DanielleMorrill",
  "in_reply_to_user_id_str" : "7017692",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Danielle Morrill",
      "screen_name" : "DanielleMorrill",
      "indices" : [ 0, 16 ],
      "id_str" : "7017692",
      "id" : 7017692
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288181175829278720",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.78223819568547, -122.4060124532528 ]
  },
  "id_str" : "288181692877910016",
  "in_reply_to_user_id" : 7017692,
  "text" : "@DanielleMorrill Yup. And at Amazon. 90% of A/B tests have no statistical significance. Real meaning is difficult to find.",
  "id" : 288181692877910016,
  "in_reply_to_status_id" : 288181175829278720,
  "created_at" : "Mon Jan 07 07:14:04 +0000 2013",
  "in_reply_to_screen_name" : "DanielleMorrill",
  "in_reply_to_user_id_str" : "7017692",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.78205982174754, -122.4042901233485 ]
  },
  "id_str" : "288178991494463488",
  "text" : "What's the least used emoji. Is it 📯?",
  "id" : 288178991494463488,
  "created_at" : "Mon Jan 07 07:03:20 +0000 2013",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "todd sawicki",
      "screen_name" : "sawickipedia",
      "indices" : [ 0, 13 ],
      "id_str" : "1784841",
      "id" : 1784841
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "believe",
      "indices" : [ 80, 88 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288177499089805312",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.78206669978788, -122.4043067075113 ]
  },
  "id_str" : "288177966368829440",
  "in_reply_to_user_id" : 1784841,
  "text" : "@sawickipedia The singularity is coooool. Except for the robot revolution part. #believe",
  "id" : 288177966368829440,
  "in_reply_to_status_id" : 288177499089805312,
  "created_at" : "Mon Jan 07 06:59:15 +0000 2013",
  "in_reply_to_screen_name" : "sawickipedia",
  "in_reply_to_user_id_str" : "1784841",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kurt Revis",
      "screen_name" : "kurtrevis",
      "indices" : [ 0, 10 ],
      "id_str" : "56244113",
      "id" : 56244113
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288176856472113152",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.78202632241663, -122.4043423068156 ]
  },
  "id_str" : "288177651473055746",
  "in_reply_to_user_id" : 56244113,
  "text" : "@kurtrevis Actual Kindles have a wonky work around. iOS apps have to do a font size dance.",
  "id" : 288177651473055746,
  "in_reply_to_status_id" : 288176856472113152,
  "created_at" : "Mon Jan 07 06:58:00 +0000 2013",
  "in_reply_to_screen_name" : "kurtrevis",
  "in_reply_to_user_id_str" : "56244113",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "todd sawicki",
      "screen_name" : "sawickipedia",
      "indices" : [ 0, 13 ],
      "id_str" : "1784841",
      "id" : 1784841
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "winsallbets",
      "indices" : [ 53, 65 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288177048122454016",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7820530412836, -122.4042974493173 ]
  },
  "id_str" : "288177397445050368",
  "in_reply_to_user_id" : 1784841,
  "text" : "@sawickipedia I've got one foot in and one foot out. #winsallbets",
  "id" : 288177397445050368,
  "in_reply_to_status_id" : 288177048122454016,
  "created_at" : "Mon Jan 07 06:57:00 +0000 2013",
  "in_reply_to_screen_name" : "sawickipedia",
  "in_reply_to_user_id_str" : "1784841",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Danielle Morrill",
      "screen_name" : "DanielleMorrill",
      "indices" : [ 0, 16 ],
      "id_str" : "7017692",
      "id" : 7017692
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288174752659566592",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.78212181912204, -122.4042086633801 ]
  },
  "id_str" : "288176451310714880",
  "in_reply_to_user_id" : 7017692,
  "text" : "@DanielleMorrill Even most late A/B test results are the same.",
  "id" : 288176451310714880,
  "in_reply_to_status_id" : 288174752659566592,
  "created_at" : "Mon Jan 07 06:53:14 +0000 2013",
  "in_reply_to_screen_name" : "DanielleMorrill",
  "in_reply_to_user_id_str" : "7017692",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Deacon 87",
      "screen_name" : "Deacon87",
      "indices" : [ 0, 9 ],
      "id_str" : "17628107",
      "id" : 17628107
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288175530749091840",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.78211839086394, -122.4042091830765 ]
  },
  "id_str" : "288175931841990656",
  "in_reply_to_user_id" : 17628107,
  "text" : "@Deacon87 Are you a Kurzweil fan?",
  "id" : 288175931841990656,
  "in_reply_to_status_id" : 288175530749091840,
  "created_at" : "Mon Jan 07 06:51:10 +0000 2013",
  "in_reply_to_screen_name" : "Deacon87",
  "in_reply_to_user_id_str" : "17628107",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.78223503920084, -122.4040367783748 ]
  },
  "id_str" : "288174249917685760",
  "text" : "Ray Kurzweil is a lucid dreamer.",
  "id" : 288174249917685760,
  "created_at" : "Mon Jan 07 06:44:29 +0000 2013",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rose Broome",
      "screen_name" : "rosical",
      "indices" : [ 0, 8 ],
      "id_str" : "140145169",
      "id" : 140145169
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "subtweet",
      "indices" : [ 9, 18 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288171403776237569",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.78225372283961, -122.4040072663097 ]
  },
  "id_str" : "288173655354138624",
  "in_reply_to_user_id" : 140145169,
  "text" : "@rosical #subtweet",
  "id" : 288173655354138624,
  "in_reply_to_status_id" : 288171403776237569,
  "created_at" : "Mon Jan 07 06:42:08 +0000 2013",
  "in_reply_to_screen_name" : "rosical",
  "in_reply_to_user_id_str" : "140145169",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DeadWriter",
      "screen_name" : "DeadWriter",
      "indices" : [ 0, 11 ],
      "id_str" : "17660964",
      "id" : 17660964
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288169959287308288",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.78226875809771, -122.4039940228538 ]
  },
  "id_str" : "288171097915019265",
  "in_reply_to_user_id" : 17660964,
  "text" : "@DeadWriter How does he find them? I wanna do that.",
  "id" : 288171097915019265,
  "in_reply_to_status_id" : 288169959287308288,
  "created_at" : "Mon Jan 07 06:31:58 +0000 2013",
  "in_reply_to_screen_name" : "DeadWriter",
  "in_reply_to_user_id_str" : "17660964",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sylvain Carle",
      "screen_name" : "froginthevalley",
      "indices" : [ 0, 16 ],
      "id_str" : "657693",
      "id" : 657693
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288170489606729729",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7822696058486, -122.4039830245876 ]
  },
  "id_str" : "288170892272484354",
  "in_reply_to_user_id" : 657693,
  "text" : "@froginthevalley Yeah I filed an erroneous bug last week about this. iPhone-only.",
  "id" : 288170892272484354,
  "in_reply_to_status_id" : 288170489606729729,
  "created_at" : "Mon Jan 07 06:31:09 +0000 2013",
  "in_reply_to_screen_name" : "froginthevalley",
  "in_reply_to_user_id_str" : "657693",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sylvain Carle",
      "screen_name" : "froginthevalley",
      "indices" : [ 0, 16 ],
      "id_str" : "657693",
      "id" : 657693
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288169547956117504",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7822754586323, -122.4039603553142 ]
  },
  "id_str" : "288170103667834880",
  "in_reply_to_user_id" : 657693,
  "text" : "@froginthevalley compact and cropped all wonky. :)",
  "id" : 288170103667834880,
  "in_reply_to_status_id" : 288169547956117504,
  "created_at" : "Mon Jan 07 06:28:01 +0000 2013",
  "in_reply_to_screen_name" : "froginthevalley",
  "in_reply_to_user_id_str" : "657693",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ArielMeadowStallings",
      "screen_name" : "OffbeatAriel",
      "indices" : [ 0, 13 ],
      "id_str" : "14095370",
      "id" : 14095370
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hadacoupleglassestoo",
      "indices" : [ 43, 64 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288168873524596736",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.78223623120717, -122.4040268736205 ]
  },
  "id_str" : "288169561524690945",
  "in_reply_to_user_id" : 14095370,
  "text" : "@OffbeatAriel Watch out for that lamppost! #hadacoupleglassestoo",
  "id" : 288169561524690945,
  "in_reply_to_status_id" : 288168873524596736,
  "created_at" : "Mon Jan 07 06:25:52 +0000 2013",
  "in_reply_to_screen_name" : "OffbeatAriel",
  "in_reply_to_user_id_str" : "14095370",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sylvain Carle",
      "screen_name" : "froginthevalley",
      "indices" : [ 0, 16 ],
      "id_str" : "657693",
      "id" : 657693
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288168088824860673",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.78228036003068, -122.4039583358618 ]
  },
  "id_str" : "288169056035536896",
  "in_reply_to_user_id" : 657693,
  "text" : "@froginthevalley Does twitpic use ol' type.js? Card image is wonky. PS why are you using twitpic??",
  "id" : 288169056035536896,
  "in_reply_to_status_id" : 288168088824860673,
  "created_at" : "Mon Jan 07 06:23:51 +0000 2013",
  "in_reply_to_screen_name" : "froginthevalley",
  "in_reply_to_user_id_str" : "657693",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Guarraci",
      "screen_name" : "eismcc",
      "indices" : [ 0, 7 ],
      "id_str" : "13257392",
      "id" : 13257392
    }, {
      "name" : "GitHub",
      "screen_name" : "github",
      "indices" : [ 73, 80 ],
      "id_str" : "13334762",
      "id" : 13334762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288166719275536384",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.78225161027785, -122.4040172500367 ]
  },
  "id_str" : "288167158490464256",
  "in_reply_to_user_id" : 13257392,
  "text" : "@eismcc That *would* be awesome. If I were an author my book would be on @github and people would submit pull requests for my typos.",
  "id" : 288167158490464256,
  "in_reply_to_status_id" : 288166719275536384,
  "created_at" : "Mon Jan 07 06:16:19 +0000 2013",
  "in_reply_to_screen_name" : "eismcc",
  "in_reply_to_user_id_str" : "13257392",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luke Millar",
      "screen_name" : "ltm",
      "indices" : [ 0, 4 ],
      "id_str" : "14616067",
      "id" : 14616067
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288111291338465281",
  "geo" : {
  },
  "id_str" : "288166370229772288",
  "in_reply_to_user_id" : 14616067,
  "text" : "@ltm What are you gonna do?",
  "id" : 288166370229772288,
  "in_reply_to_status_id" : 288111291338465281,
  "created_at" : "Mon Jan 07 06:13:11 +0000 2013",
  "in_reply_to_screen_name" : "ltm",
  "in_reply_to_user_id_str" : "14616067",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Sposato",
      "screen_name" : "jonathansposato",
      "indices" : [ 0, 16 ],
      "id_str" : "37036797",
      "id" : 37036797
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288162096988958720",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.78225785022114, -122.4040155687914 ]
  },
  "id_str" : "288162458227593216",
  "in_reply_to_user_id" : 37036797,
  "text" : "@jonathansposato In that case you better get on SnapChat pronto.",
  "id" : 288162458227593216,
  "in_reply_to_status_id" : 288162096988958720,
  "created_at" : "Mon Jan 07 05:57:38 +0000 2013",
  "in_reply_to_screen_name" : "jonathansposato",
  "in_reply_to_user_id_str" : "37036797",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.78226368642702, -122.4040017292766 ]
  },
  "id_str" : "288161676979732481",
  "text" : "Do you highlight and note typos in Kindle books in case the author asks you to edit the next edition?",
  "id" : 288161676979732481,
  "created_at" : "Mon Jan 07 05:54:32 +0000 2013",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Sposato",
      "screen_name" : "jonathansposato",
      "indices" : [ 0, 16 ],
      "id_str" : "37036797",
      "id" : 37036797
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288157880723587072",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.78206933532795, -122.4042994269483 ]
  },
  "id_str" : "288158849658130432",
  "in_reply_to_user_id" : 37036797,
  "text" : "@jonathansposato I'm surprised. You should have at least 100x that number. Start live-blogging Downton Abbey perhaps? :)",
  "id" : 288158849658130432,
  "in_reply_to_status_id" : 288157880723587072,
  "created_at" : "Mon Jan 07 05:43:18 +0000 2013",
  "in_reply_to_screen_name" : "jonathansposato",
  "in_reply_to_user_id_str" : "37036797",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Allen",
      "screen_name" : "moustache",
      "indices" : [ 0, 10 ],
      "id_str" : "19783",
      "id" : 19783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288158086596788224",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.78226923603438, -122.4039934104451 ]
  },
  "id_str" : "288158563975716864",
  "in_reply_to_user_id" : 19783,
  "text" : "@moustache Hmm. Not on iPhone.",
  "id" : 288158563975716864,
  "in_reply_to_status_id" : 288158086596788224,
  "created_at" : "Mon Jan 07 05:42:10 +0000 2013",
  "in_reply_to_screen_name" : "moustache",
  "in_reply_to_user_id_str" : "19783",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "david reeves",
      "screen_name" : "dreeves",
      "indices" : [ 0, 8 ],
      "id_str" : "947851",
      "id" : 947851
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288157754516967424",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.78228237940913, -122.4039510001552 ]
  },
  "id_str" : "288158000395460609",
  "in_reply_to_user_id" : 947851,
  "text" : "@dreeves You should look his talks up on YouTube. He's a bit of a fanatic.",
  "id" : 288158000395460609,
  "in_reply_to_status_id" : 288157754516967424,
  "created_at" : "Mon Jan 07 05:39:55 +0000 2013",
  "in_reply_to_screen_name" : "dreeves",
  "in_reply_to_user_id_str" : "947851",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "david reeves",
      "screen_name" : "dreeves",
      "indices" : [ 0, 8 ],
      "id_str" : "947851",
      "id" : 947851
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288155966900424705",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7822605087, -122.4039845444 ]
  },
  "id_str" : "288156644494434304",
  "in_reply_to_user_id" : 947851,
  "text" : "@dreeves Not much yet. David Lynch's TM talks give me the creeps a bit. Not you?",
  "id" : 288156644494434304,
  "in_reply_to_status_id" : 288155966900424705,
  "created_at" : "Mon Jan 07 05:34:32 +0000 2013",
  "in_reply_to_screen_name" : "dreeves",
  "in_reply_to_user_id_str" : "947851",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brett R. Wilkes ༼ཽ༘༾",
      "screen_name" : "BrettRWilkes",
      "indices" : [ 0, 13 ],
      "id_str" : "43157011",
      "id" : 43157011
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288155817734193153",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.78226761863473, -122.4039800233192 ]
  },
  "id_str" : "288156454437937152",
  "in_reply_to_user_id" : 43157011,
  "text" : "@BrettRWilkes I'm on the Kindle iPhone app. Good to know that actual Kindles have a better solution though!",
  "id" : 288156454437937152,
  "in_reply_to_status_id" : 288155817734193153,
  "created_at" : "Mon Jan 07 05:33:47 +0000 2013",
  "in_reply_to_screen_name" : "BrettRWilkes",
  "in_reply_to_user_id_str" : "43157011",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Garcia",
      "screen_name" : "motherinternet",
      "indices" : [ 0, 15 ],
      "id_str" : "6280322",
      "id" : 6280322
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288154226645934081",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.78223984092461, -122.4040315076056 ]
  },
  "id_str" : "288156005710311424",
  "in_reply_to_user_id" : 6280322,
  "text" : "@motherinternet A curmudgeony review. Enjoining it so far myself. Have you read it?",
  "id" : 288156005710311424,
  "in_reply_to_status_id" : 288154226645934081,
  "created_at" : "Mon Jan 07 05:32:00 +0000 2013",
  "in_reply_to_screen_name" : "motherinternet",
  "in_reply_to_user_id_str" : "6280322",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.78209311419476, -122.4042556907363 ]
  },
  "id_str" : "288153300317122561",
  "text" : "What's your strategy for highlighting a Kindle passage that spans pages? Mine is to shrink the text to micro-sizes.",
  "id" : 288153300317122561,
  "created_at" : "Mon Jan 07 05:21:15 +0000 2013",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gavin Broughton",
      "screen_name" : "ukgav",
      "indices" : [ 0, 6 ],
      "id_str" : "232329387",
      "id" : 232329387
    }, {
      "name" : "Josh Miller",
      "screen_name" : "joshm",
      "indices" : [ 7, 13 ],
      "id_str" : "42559115",
      "id" : 42559115
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288145410776768512",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.78215911522826, -122.4041645832303 ]
  },
  "id_str" : "288151694070652929",
  "in_reply_to_user_id" : 232329387,
  "text" : "@ukgav @joshm Exactly. That's the whole point of this exploration. :)",
  "id" : 288151694070652929,
  "in_reply_to_status_id" : 288145410776768512,
  "created_at" : "Mon Jan 07 05:14:52 +0000 2013",
  "in_reply_to_screen_name" : "ukgav",
  "in_reply_to_user_id_str" : "232329387",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "thingsilearnedfromraykurzweil",
      "indices" : [ 79, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.78212045092572, -122.4042334312836 ]
  },
  "id_str" : "288150294318161920",
  "text" : "Hierarchical parallel pattern recognition of a hierarchically-organized world. #thingsilearnedfromraykurzweil",
  "id" : 288150294318161920,
  "created_at" : "Mon Jan 07 05:09:18 +0000 2013",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.78213858345615, -122.4041971584697 ]
  },
  "id_str" : "288146958504308736",
  "text" : "I'm surprised to learn that Ray Kurzweil practices Transcendental Meditation.",
  "id" : 288146958504308736,
  "created_at" : "Mon Jan 07 04:56:03 +0000 2013",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Miller",
      "screen_name" : "joshm",
      "indices" : [ 0, 6 ],
      "id_str" : "42559115",
      "id" : 42559115
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288143788243841024",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.78210185506779, -122.4042270654819 ]
  },
  "id_str" : "288144565112815616",
  "in_reply_to_user_id" : 42559115,
  "text" : "@joshm Interesting point. I'll think about that. And also... trends often span multiple URLs and large trends will appear multiple times.",
  "id" : 288144565112815616,
  "in_reply_to_status_id" : 288143788243841024,
  "created_at" : "Mon Jan 07 04:46:32 +0000 2013",
  "in_reply_to_screen_name" : "joshm",
  "in_reply_to_user_id_str" : "42559115",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hackweek",
      "indices" : [ 67, 76 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 97 ],
      "url" : "http://t.co/EXF0xdFV",
      "expanded_url" : "http://flic.kr/p/dJttz1",
      "display_url" : "flic.kr/p/dJttz1"
    } ]
  },
  "geo" : {
  },
  "id_str" : "288142793849843712",
  "text" : "8:36pm My \"personal trends\" data is starting to look more relevant #hackweek http://t.co/EXF0xdFV",
  "id" : 288142793849843712,
  "created_at" : "Mon Jan 07 04:39:30 +0000 2013",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carinna Tarvin",
      "screen_name" : "carinnatarvin",
      "indices" : [ 0, 14 ],
      "id_str" : "20833838",
      "id" : 20833838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288141476150538240",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.78220106456865, -122.4040803545407 ]
  },
  "id_str" : "288141616932347905",
  "in_reply_to_user_id" : 20833838,
  "text" : "@carinnatarvin Haha oops.",
  "id" : 288141616932347905,
  "in_reply_to_status_id" : 288141476150538240,
  "created_at" : "Mon Jan 07 04:34:49 +0000 2013",
  "in_reply_to_screen_name" : "carinnatarvin",
  "in_reply_to_user_id_str" : "20833838",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Klabnik",
      "screen_name" : "steveklabnik",
      "indices" : [ 3, 16 ],
      "id_str" : "22386062",
      "id" : 22386062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 123 ],
      "url" : "http://t.co/zmKwhTPK",
      "expanded_url" : "http://dealbook.nytimes.com/2012/12/10/hsbc-said-to-near-1-9-billion-settlement-over-money-laundering/",
      "display_url" : "dealbook.nytimes.com/2012/12/10/hsb…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "288140611918364672",
  "text" : "RT @steveklabnik: Please read the first sentence of this story. It's too long to tweet, but holy shit. http://t.co/zmKwhTPK",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 85, 105 ],
        "url" : "http://t.co/zmKwhTPK",
        "expanded_url" : "http://dealbook.nytimes.com/2012/12/10/hsbc-said-to-near-1-9-billion-settlement-over-money-laundering/",
        "display_url" : "dealbook.nytimes.com/2012/12/10/hsb…"
      } ]
    },
    "geo" : {
    },
    "id_str" : "287316230648524800",
    "text" : "Please read the first sentence of this story. It's too long to tweet, but holy shit. http://t.co/zmKwhTPK",
    "id" : 287316230648524800,
    "created_at" : "Fri Jan 04 21:55:02 +0000 2013",
    "user" : {
      "name" : "Steve Klabnik",
      "screen_name" : "steveklabnik",
      "protected" : false,
      "id_str" : "22386062",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2646866211/b68c6253cafbd9a43b0cd86bbecdcf2d_normal.jpeg",
      "id" : 22386062,
      "verified" : false
    }
  },
  "id" : 288140611918364672,
  "created_at" : "Mon Jan 07 04:30:49 +0000 2013",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carinna Tarvin",
      "screen_name" : "carinnatarvin",
      "indices" : [ 12, 26 ],
      "id_str" : "20833838",
      "id" : 20833838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 132 ],
      "url" : "http://t.co/FIEZ9sxV",
      "expanded_url" : "http://flic.kr/s/aHsjDwf641",
      "display_url" : "flic.kr/s/aHsjDwf641"
    } ]
  },
  "geo" : {
  },
  "id_str" : "288135174359760896",
  "text" : "Inspired by @carinnatarvin's Best of 2013 Flickr set, I made one too. Made lovingly in Flickr's iPhone app. Try http://t.co/FIEZ9sxV",
  "id" : 288135174359760896,
  "created_at" : "Mon Jan 07 04:09:13 +0000 2013",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carinna Tarvin",
      "screen_name" : "carinnatarvin",
      "indices" : [ 0, 14 ],
      "id_str" : "20833838",
      "id" : 20833838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288121300814266368",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7820442644762, -122.4043252241626 ]
  },
  "id_str" : "288127088056225793",
  "in_reply_to_user_id" : 20833838,
  "text" : "@carinnatarvin That was fun to look through! I wanna make one now too.",
  "id" : 288127088056225793,
  "in_reply_to_status_id" : 288121300814266368,
  "created_at" : "Mon Jan 07 03:37:05 +0000 2013",
  "in_reply_to_screen_name" : "carinnatarvin",
  "in_reply_to_user_id_str" : "20833838",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "rondiver",
      "screen_name" : "rondiver",
      "indices" : [ 0, 9 ],
      "id_str" : "12661782",
      "id" : 12661782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 58 ],
      "url" : "http://t.co/hjdl40NN",
      "expanded_url" : "http://wayoftheduck.com/fitbit-zip",
      "display_url" : "wayoftheduck.com/fitbit-zip"
    } ]
  },
  "in_reply_to_status_id_str" : "288109492246302720",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.77772322818205, -122.415212483371 ]
  },
  "id_str" : "288111491415166977",
  "in_reply_to_user_id" : 12661782,
  "text" : "@rondiver That said, my current fave: http://t.co/hjdl40NN",
  "id" : 288111491415166977,
  "in_reply_to_status_id" : 288109492246302720,
  "created_at" : "Mon Jan 07 02:35:07 +0000 2013",
  "in_reply_to_screen_name" : "rondiver",
  "in_reply_to_user_id_str" : "12661782",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "rondiver",
      "screen_name" : "rondiver",
      "indices" : [ 0, 9 ],
      "id_str" : "12661782",
      "id" : 12661782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288109492246302720",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.77781317327565, -122.415327318073 ]
  },
  "id_str" : "288111204994514944",
  "in_reply_to_user_id" : 12661782,
  "text" : "@rondiver Not really. I've used them all. It's like the days when I tried 5x to like Palm Pilots. Never stuck. Then the iPhone comes out.",
  "id" : 288111204994514944,
  "in_reply_to_status_id" : 288109492246302720,
  "created_at" : "Mon Jan 07 02:33:58 +0000 2013",
  "in_reply_to_screen_name" : "rondiver",
  "in_reply_to_user_id_str" : "12661782",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "notbadatall",
      "indices" : [ 50, 62 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.77777952031865, -122.4151922561661 ]
  },
  "id_str" : "288110777066463233",
  "text" : "Solo dinner at restaurant with Kindle wins again! #notbadatall",
  "id" : 288110777066463233,
  "created_at" : "Mon Jan 07 02:32:16 +0000 2013",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Bragger",
      "screen_name" : "kylebragger",
      "indices" : [ 0, 12 ],
      "id_str" : "2039761",
      "id" : 2039761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288107212335902720",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7778500028, -122.4152098256 ]
  },
  "id_str" : "288107968975732737",
  "in_reply_to_user_id" : 2039761,
  "text" : "@kylebragger Let's try again end of month? I'll be here permanently at that point!",
  "id" : 288107968975732737,
  "in_reply_to_status_id" : 288107212335902720,
  "created_at" : "Mon Jan 07 02:21:07 +0000 2013",
  "in_reply_to_screen_name" : "kylebragger",
  "in_reply_to_user_id_str" : "2039761",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Bragger",
      "screen_name" : "kylebragger",
      "indices" : [ 0, 12 ],
      "id_str" : "2039761",
      "id" : 2039761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288106669471326210",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7778579103317, -122.4150373578262 ]
  },
  "id_str" : "288106958454657024",
  "in_reply_to_user_id" : 2039761,
  "text" : "@kylebragger Tonight? :)",
  "id" : 288106958454657024,
  "in_reply_to_status_id" : 288106669471326210,
  "created_at" : "Mon Jan 07 02:17:06 +0000 2013",
  "in_reply_to_screen_name" : "kylebragger",
  "in_reply_to_user_id_str" : "2039761",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.77782969918572, -122.4152323735609 ]
  },
  "id_str" : "288106014656581632",
  "text" : "Who's out and about in SF tonight?",
  "id" : 288106014656581632,
  "created_at" : "Mon Jan 07 02:13:21 +0000 2013",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Miller",
      "screen_name" : "joshm",
      "indices" : [ 0, 6 ],
      "id_str" : "42559115",
      "id" : 42559115
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288080069157584896",
  "geo" : {
  },
  "id_str" : "288083634043359233",
  "in_reply_to_user_id" : 42559115,
  "text" : "@joshm Send me your ideas and maybe I can be your proxy hackweeker! :)",
  "id" : 288083634043359233,
  "in_reply_to_status_id" : 288080069157584896,
  "created_at" : "Mon Jan 07 00:44:25 +0000 2013",
  "in_reply_to_screen_name" : "joshm",
  "in_reply_to_user_id_str" : "42559115",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Torrez",
      "screen_name" : "torrez",
      "indices" : [ 0, 7 ],
      "id_str" : "11604",
      "id" : 11604
    }, {
      "name" : "David Jacobs",
      "screen_name" : "djacobs",
      "indices" : [ 8, 16 ],
      "id_str" : "774842",
      "id" : 774842
    }, {
      "name" : "Mike D. Stellar Feed",
      "screen_name" : "mike_stellar",
      "indices" : [ 108, 121 ],
      "id_str" : "474428523",
      "id" : 474428523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288074083910959107",
  "geo" : {
  },
  "id_str" : "288076765908332544",
  "in_reply_to_user_id" : 11604,
  "text" : "@torrez @djacobs I must not be paying very close attention. So they're just retweeting the same things that @mike_stellar does? Not good.",
  "id" : 288076765908332544,
  "in_reply_to_status_id" : 288074083910959107,
  "created_at" : "Mon Jan 07 00:17:07 +0000 2013",
  "in_reply_to_screen_name" : "torrez",
  "in_reply_to_user_id_str" : "11604",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Jacobs",
      "screen_name" : "djacobs",
      "indices" : [ 0, 8 ],
      "id_str" : "774842",
      "id" : 774842
    }, {
      "name" : "Mike D. Stellar Feed",
      "screen_name" : "mike_stellar",
      "indices" : [ 13, 26 ],
      "id_str" : "474428523",
      "id" : 474428523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288070867567648768",
  "geo" : {
  },
  "id_str" : "288073190184468480",
  "in_reply_to_user_id" : 774842,
  "text" : "@djacobs Oh, @mike_stellar is the only stellar bot I have run across… do you see multiple stellar bots with overlapping friend networks?",
  "id" : 288073190184468480,
  "in_reply_to_status_id" : 288070867567648768,
  "created_at" : "Mon Jan 07 00:02:55 +0000 2013",
  "in_reply_to_screen_name" : "djacobs",
  "in_reply_to_user_id_str" : "774842",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Jacobs",
      "screen_name" : "djacobs",
      "indices" : [ 0, 8 ],
      "id_str" : "774842",
      "id" : 774842
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288069423007404033",
  "geo" : {
  },
  "id_str" : "288070114371321858",
  "in_reply_to_user_id" : 774842,
  "text" : "@djacobs I do understand the interactions clutter, but it's a signal of its own in a way. Solve a problem = create new problems.",
  "id" : 288070114371321858,
  "in_reply_to_status_id" : 288069423007404033,
  "created_at" : "Sun Jan 06 23:50:42 +0000 2013",
  "in_reply_to_screen_name" : "djacobs",
  "in_reply_to_user_id_str" : "774842",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "drew olanoff",
      "screen_name" : "drew",
      "indices" : [ 0, 5 ],
      "id_str" : "10221",
      "id" : 10221
    }, {
      "name" : "Libby Brittain",
      "screen_name" : "libbybrittain",
      "indices" : [ 6, 20 ],
      "id_str" : "18749271",
      "id" : 18749271
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288068602899333120",
  "geo" : {
  },
  "id_str" : "288069014142476292",
  "in_reply_to_user_id" : 10221,
  "text" : "@drew @libbybrittain Create a twitter account that you want to RT from and email me buster@twitter.com. Also, you need a stellar.io account.",
  "id" : 288069014142476292,
  "in_reply_to_status_id" : 288068602899333120,
  "created_at" : "Sun Jan 06 23:46:19 +0000 2013",
  "in_reply_to_screen_name" : "drew",
  "in_reply_to_user_id_str" : "10221",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Miller",
      "screen_name" : "joshm",
      "indices" : [ 0, 6 ],
      "id_str" : "42559115",
      "id" : 42559115
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288068070705074177",
  "geo" : {
  },
  "id_str" : "288068370883018752",
  "in_reply_to_user_id" : 42559115,
  "text" : "@joshm Ok! Create a @josh_stellar (or something) twitter account, and email me at buster@twitter.com and I'll send you more instructions.",
  "id" : 288068370883018752,
  "in_reply_to_status_id" : 288068070705074177,
  "created_at" : "Sun Jan 06 23:43:46 +0000 2013",
  "in_reply_to_screen_name" : "joshm",
  "in_reply_to_user_id_str" : "42559115",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Jacobs",
      "screen_name" : "djacobs",
      "indices" : [ 0, 8 ],
      "id_str" : "774842",
      "id" : 774842
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288067300605693952",
  "geo" : {
  },
  "id_str" : "288067698074738688",
  "in_reply_to_user_id" : 774842,
  "text" : "@djacobs They do use stellar.io… just the RSS feed instead of the website. I'm trying it to see if it's good or not. An experiment.",
  "id" : 288067698074738688,
  "in_reply_to_status_id" : 288067300605693952,
  "created_at" : "Sun Jan 06 23:41:05 +0000 2013",
  "in_reply_to_screen_name" : "djacobs",
  "in_reply_to_user_id_str" : "774842",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luke Millar",
      "screen_name" : "ltm",
      "indices" : [ 0, 4 ],
      "id_str" : "14616067",
      "id" : 14616067
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288067059198357504",
  "geo" : {
  },
  "id_str" : "288067264434016256",
  "in_reply_to_user_id" : 14616067,
  "text" : "@ltm Check your work email.",
  "id" : 288067264434016256,
  "in_reply_to_status_id" : 288067059198357504,
  "created_at" : "Sun Jan 06 23:39:22 +0000 2013",
  "in_reply_to_screen_name" : "ltm",
  "in_reply_to_user_id_str" : "14616067",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luke Millar",
      "screen_name" : "ltm",
      "indices" : [ 0, 4 ],
      "id_str" : "14616067",
      "id" : 14616067
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288065561043279872",
  "geo" : {
  },
  "id_str" : "288066768633737216",
  "in_reply_to_user_id" : 14616067,
  "text" : "@ltm It is! The workaround here requires a stellar.io account, do you have one yet? If not I can send you an invite.",
  "id" : 288066768633737216,
  "in_reply_to_status_id" : 288065561043279872,
  "created_at" : "Sun Jan 06 23:37:24 +0000 2013",
  "in_reply_to_screen_name" : "ltm",
  "in_reply_to_user_id_str" : "14616067",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Davidson",
      "screen_name" : "mikeindustries",
      "indices" : [ 12, 27 ],
      "id_str" : "74523",
      "id" : 74523
    }, {
      "name" : "Mike D. Stellar Feed",
      "screen_name" : "mike_stellar",
      "indices" : [ 36, 49 ],
      "id_str" : "474428523",
      "id" : 474428523
    }, {
      "name" : "Buster's Stellar.io",
      "screen_name" : "buster_stellar",
      "indices" : [ 80, 95 ],
      "id_str" : "1023497148",
      "id" : 1023497148
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "288064867741622272",
  "text" : "Inspired by @mikeindustries and his @mike_stellar bot, I've created one for me: @buster_stellar. Who else wants one?",
  "id" : 288064867741622272,
  "created_at" : "Sun Jan 06 23:29:51 +0000 2013",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Bower",
      "screen_name" : "JohnMBower",
      "indices" : [ 0, 11 ],
      "id_str" : "352927399",
      "id" : 352927399
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288062086016299008",
  "geo" : {
  },
  "id_str" : "288064420632989696",
  "in_reply_to_user_id" : 352927399,
  "text" : "@JohnMBower By calibrating. For example, scoring an RT on a tweet by someone with 100 followers the same as 100 RTs by someone with 10,000.",
  "id" : 288064420632989696,
  "in_reply_to_status_id" : 288062086016299008,
  "created_at" : "Sun Jan 06 23:28:04 +0000 2013",
  "in_reply_to_screen_name" : "JohnMBower",
  "in_reply_to_user_id_str" : "352927399",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Goldman",
      "screen_name" : "goldman",
      "indices" : [ 0, 8 ],
      "id_str" : "291",
      "id" : 291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288061051063382017",
  "geo" : {
  },
  "id_str" : "288064108044099586",
  "in_reply_to_user_id" : 291,
  "text" : "@goldman Agreed. And the Discover tab is inching in that direction, but I like the idea of it still using a subtle variety of \"follow\".",
  "id" : 288064108044099586,
  "in_reply_to_status_id" : 288061051063382017,
  "created_at" : "Sun Jan 06 23:26:49 +0000 2013",
  "in_reply_to_screen_name" : "goldman",
  "in_reply_to_user_id_str" : "291",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cheri Roberts",
      "screen_name" : "CheriSpeak",
      "indices" : [ 0, 11 ],
      "id_str" : "558885462",
      "id" : 558885462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288054773326938112",
  "geo" : {
  },
  "id_str" : "288056914946949121",
  "in_reply_to_user_id" : 558885462,
  "text" : "@CheriSpeak How so?",
  "id" : 288056914946949121,
  "in_reply_to_status_id" : 288054773326938112,
  "created_at" : "Sun Jan 06 22:58:15 +0000 2013",
  "in_reply_to_screen_name" : "CheriSpeak",
  "in_reply_to_user_id_str" : "558885462",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Bower",
      "screen_name" : "JohnMBower",
      "indices" : [ 0, 11 ],
      "id_str" : "352927399",
      "id" : 352927399
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288054281477689345",
  "geo" : {
  },
  "id_str" : "288056807778304000",
  "in_reply_to_user_id" : 352927399,
  "text" : "@JohnMBower The difference would be that this is opt-in. You choose who you want to fuzzy follow. It wouldn't be very many people.",
  "id" : 288056807778304000,
  "in_reply_to_status_id" : 288054281477689345,
  "created_at" : "Sun Jan 06 22:57:49 +0000 2013",
  "in_reply_to_screen_name" : "JohnMBower",
  "in_reply_to_user_id_str" : "352927399",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hackweek",
      "indices" : [ 37, 46 ]
    }, {
      "text" : "hackweek",
      "indices" : [ 79, 88 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "288053790618296320",
  "text" : "Taking a short break from my primary #hackweek project to work on a small side #hackweek project.",
  "id" : 288053790618296320,
  "created_at" : "Sun Jan 06 22:45:50 +0000 2013",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Cox",
      "screen_name" : "acox",
      "indices" : [ 0, 5 ],
      "id_str" : "8756332",
      "id" : 8756332
    }, {
      "name" : "Lift",
      "screen_name" : "liftapp",
      "indices" : [ 6, 14 ],
      "id_str" : "353195232",
      "id" : 353195232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288047850171019264",
  "geo" : {
  },
  "id_str" : "288048001044320256",
  "in_reply_to_user_id" : 8756332,
  "text" : "@acox @liftapp is pretty great. I assume you've tried them?",
  "id" : 288048001044320256,
  "in_reply_to_status_id" : 288047850171019264,
  "created_at" : "Sun Jan 06 22:22:49 +0000 2013",
  "in_reply_to_screen_name" : "acox",
  "in_reply_to_user_id_str" : "8756332",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Cox",
      "screen_name" : "acox",
      "indices" : [ 0, 5 ],
      "id_str" : "8756332",
      "id" : 8756332
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288041804174073857",
  "geo" : {
  },
  "id_str" : "288046769999323136",
  "in_reply_to_user_id" : 8756332,
  "text" : "@acox Woah that was years ago. I think I did, and then the domain expired. What are you looking for?",
  "id" : 288046769999323136,
  "in_reply_to_status_id" : 288041804174073857,
  "created_at" : "Sun Jan 06 22:17:56 +0000 2013",
  "in_reply_to_screen_name" : "acox",
  "in_reply_to_user_id_str" : "8756332",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luke Millar",
      "screen_name" : "ltm",
      "indices" : [ 0, 4 ],
      "id_str" : "14616067",
      "id" : 14616067
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288022644085907457",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.77630131646564, -122.4180933269607 ]
  },
  "id_str" : "288027778085953536",
  "in_reply_to_user_id" : 14616067,
  "text" : "@ltm Thanks!",
  "id" : 288027778085953536,
  "in_reply_to_status_id" : 288022644085907457,
  "created_at" : "Sun Jan 06 21:02:28 +0000 2013",
  "in_reply_to_screen_name" : "ltm",
  "in_reply_to_user_id_str" : "14616067",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sunday",
      "indices" : [ 0, 7 ]
    }, {
      "text" : "timeshifted",
      "indices" : [ 8, 20 ]
    }, {
      "text" : "hackweek",
      "indices" : [ 21, 30 ]
    }, {
      "text" : "canaryinatimeline",
      "indices" : [ 31, 49 ]
    }, {
      "text" : "inbed",
      "indices" : [ 50, 56 ]
    }, {
      "text" : "pajamas",
      "indices" : [ 57, 65 ]
    }, {
      "text" : "hotel",
      "indices" : [ 66, 72 ]
    }, {
      "text" : "hungry",
      "indices" : [ 73, 80 ]
    }, {
      "text" : "needfood",
      "indices" : [ 81, 90 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "288019354711371777",
  "text" : "#sunday #timeshifted #hackweek #canaryinatimeline #inbed #pajamas #hotel #hungry #needfood",
  "id" : 288019354711371777,
  "created_at" : "Sun Jan 06 20:28:59 +0000 2013",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "yaqui núñez",
      "screen_name" : "yaqui",
      "indices" : [ 0, 6 ],
      "id_str" : "638283",
      "id" : 638283
    }, {
      "name" : "Branch",
      "screen_name" : "branch",
      "indices" : [ 40, 47 ],
      "id_str" : "494518813",
      "id" : 494518813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288017636690907136",
  "geo" : {
  },
  "id_str" : "288018006100029440",
  "in_reply_to_user_id" : 638283,
  "text" : "@yaqui Awesome. Yes, I need IDEAS. More @branch-ing.",
  "id" : 288018006100029440,
  "in_reply_to_status_id" : 288017636690907136,
  "created_at" : "Sun Jan 06 20:23:38 +0000 2013",
  "in_reply_to_screen_name" : "yaqui",
  "in_reply_to_user_id_str" : "638283",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "yaqui núñez",
      "screen_name" : "yaqui",
      "indices" : [ 0, 6 ],
      "id_str" : "638283",
      "id" : 638283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288017159567859712",
  "geo" : {
  },
  "id_str" : "288017455866060800",
  "in_reply_to_user_id" : 638283,
  "text" : "@yaqui In a couple days, yeah. Still taking it down quite often.",
  "id" : 288017455866060800,
  "in_reply_to_status_id" : 288017159567859712,
  "created_at" : "Sun Jan 06 20:21:27 +0000 2013",
  "in_reply_to_screen_name" : "yaqui",
  "in_reply_to_user_id_str" : "638283",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Logan Bowers",
      "screen_name" : "loganb",
      "indices" : [ 0, 7 ],
      "id_str" : "6072622",
      "id" : 6072622
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "longlivegooglereader",
      "indices" : [ 71, 92 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288016196589215744",
  "geo" : {
  },
  "id_str" : "288017277717204992",
  "in_reply_to_user_id" : 6072622,
  "text" : "@loganb Wasn't \"share\" the same as RT? I do remember liking it though. #longlivegooglereader",
  "id" : 288017277717204992,
  "in_reply_to_status_id" : 288016196589215744,
  "created_at" : "Sun Jan 06 20:20:44 +0000 2013",
  "in_reply_to_screen_name" : "loganb",
  "in_reply_to_user_id_str" : "6072622",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Monica Guzman",
      "screen_name" : "moniguzman",
      "indices" : [ 0, 11 ],
      "id_str" : "3452941",
      "id" : 3452941
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288014094731202560",
  "geo" : {
  },
  "id_str" : "288014506343399424",
  "in_reply_to_user_id" : 3452941,
  "text" : "@moniguzman They definitely could. But then again, if the food has a label, it's probably not *that* healthy.",
  "id" : 288014506343399424,
  "in_reply_to_status_id" : 288014094731202560,
  "created_at" : "Sun Jan 06 20:09:44 +0000 2013",
  "in_reply_to_screen_name" : "moniguzman",
  "in_reply_to_user_id_str" : "3452941",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/buster/status/288013478466306048/photo/1",
      "indices" : [ 99, 119 ],
      "url" : "http://t.co/8NagowaO",
      "media_url" : "http://pbs.twimg.com/media/A_86u5MCQAEuRSK.png",
      "id_str" : "288013478474694657",
      "id" : 288013478474694657,
      "media_url_https" : "https://pbs.twimg.com/media/A_86u5MCQAEuRSK.png",
      "sizes" : [ {
        "h" : 455,
        "resize" : "fit",
        "w" : 520
      }, {
        "h" : 455,
        "resize" : "fit",
        "w" : 520
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 298,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 455,
        "resize" : "fit",
        "w" : 520
      } ],
      "display_url" : "pic.twitter.com/8NagowaO"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "288013478466306048",
  "text" : "Here's a screenshot of some preliminary \"personal trends\" data based on 3 timelines I'm following. http://t.co/8NagowaO",
  "id" : 288013478466306048,
  "created_at" : "Sun Jan 06 20:05:39 +0000 2013",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Monica Guzman",
      "screen_name" : "moniguzman",
      "indices" : [ 0, 11 ],
      "id_str" : "3452941",
      "id" : 3452941
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288007410449252353",
  "geo" : {
  },
  "id_str" : "288008959850328064",
  "in_reply_to_user_id" : 3452941,
  "text" : "@moniguzman Versus the real things we should be measuring: nutrient density, glycemic load (how steeply glucose spikes), and fiber density.",
  "id" : 288008959850328064,
  "in_reply_to_status_id" : 288007410449252353,
  "created_at" : "Sun Jan 06 19:47:41 +0000 2013",
  "in_reply_to_screen_name" : "moniguzman",
  "in_reply_to_user_id_str" : "3452941",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Monica Guzman",
      "screen_name" : "moniguzman",
      "indices" : [ 0, 11 ],
      "id_str" : "3452941",
      "id" : 3452941
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288007410449252353",
  "geo" : {
  },
  "id_str" : "288007725445689344",
  "in_reply_to_user_id" : 3452941,
  "text" : "@moniguzman It's over-precise, in my opinion. A classic case of measuring the wrong thing because it is easily measured.",
  "id" : 288007725445689344,
  "in_reply_to_status_id" : 288007410449252353,
  "created_at" : "Sun Jan 06 19:42:47 +0000 2013",
  "in_reply_to_screen_name" : "moniguzman",
  "in_reply_to_user_id_str" : "3452941",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Ellin",
      "screen_name" : "brianellin",
      "indices" : [ 0, 11 ],
      "id_str" : "26123649",
      "id" : 26123649
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "288004359642562562",
  "geo" : {
  },
  "id_str" : "288005176869130241",
  "in_reply_to_user_id" : 26123649,
  "text" : "@brianellin Me too. But what if I could hand-pick a few people who I know follow a unique &amp; smart set of people, and see their best tweets?",
  "id" : 288005176869130241,
  "in_reply_to_status_id" : 288004359642562562,
  "created_at" : "Sun Jan 06 19:32:39 +0000 2013",
  "in_reply_to_screen_name" : "brianellin",
  "in_reply_to_user_id_str" : "26123649",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hugh MacLeod",
      "screen_name" : "gapingvoid",
      "indices" : [ 58, 69 ],
      "id_str" : "50193",
      "id" : 50193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 53 ],
      "url" : "http://t.co/unzI6dQj",
      "expanded_url" : "http://gapingvoid.com/2013/01/06/starting-points/",
      "display_url" : "gapingvoid.com/2013/01/06/sta…"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.77810376911921, -122.4150982931946 ]
  },
  "id_str" : "288001102979420160",
  "text" : "\"All points are starting points\" http://t.co/unzI6dQj /by @gapingvoid",
  "id" : 288001102979420160,
  "created_at" : "Sun Jan 06 19:16:28 +0000 2013",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 137 ],
      "url" : "http://t.co/RVEMaLr8",
      "expanded_url" : "http://on.branch.com/136N8cN#BD0DA4WIC4s",
      "display_url" : "on.branch.com/136N8cN#BD0DA4…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "288000591039430657",
  "text" : "What if we could \"fuzzy follow\" people... getting the best tweets that they *read* instead of the tweets they wrote? http://t.co/RVEMaLr8",
  "id" : 288000591039430657,
  "created_at" : "Sun Jan 06 19:14:26 +0000 2013",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cap Watkins",
      "screen_name" : "cap",
      "indices" : [ 0, 4 ],
      "id_str" : "2182141",
      "id" : 2182141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "287985188330426371",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.77818972317952, -122.4149466279716 ]
  },
  "id_str" : "287985880935854080",
  "in_reply_to_user_id" : 2182141,
  "text" : "@cap So it's gonna be controversial? Good!",
  "id" : 287985880935854080,
  "in_reply_to_status_id" : 287985188330426371,
  "created_at" : "Sun Jan 06 18:15:59 +0000 2013",
  "in_reply_to_screen_name" : "cap",
  "in_reply_to_user_id_str" : "2182141",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cap Watkins",
      "screen_name" : "cap",
      "indices" : [ 0, 4 ],
      "id_str" : "2182141",
      "id" : 2182141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "287984360894906368",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.77789417912079, -122.4151985377213 ]
  },
  "id_str" : "287984879633846272",
  "in_reply_to_user_id" : 2182141,
  "text" : "@cap Nice, let's see it!",
  "id" : 287984879633846272,
  "in_reply_to_status_id" : 287984360894906368,
  "created_at" : "Sun Jan 06 18:12:00 +0000 2013",
  "in_reply_to_screen_name" : "cap",
  "in_reply_to_user_id_str" : "2182141",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Monica Guzman",
      "screen_name" : "moniguzman",
      "indices" : [ 0, 11 ],
      "id_str" : "3452941",
      "id" : 3452941
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "287982477342027776",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.77789368126508, -122.4151733512973 ]
  },
  "id_str" : "287984437738762241",
  "in_reply_to_user_id" : 3452941,
  "text" : "@moniguzman I saw something about a skin sensor that could estimate calories in and out. I doubt it will be mass market for a while though.",
  "id" : 287984437738762241,
  "in_reply_to_status_id" : 287982477342027776,
  "created_at" : "Sun Jan 06 18:10:15 +0000 2013",
  "in_reply_to_screen_name" : "moniguzman",
  "in_reply_to_user_id_str" : "3452941",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sung Hu Kim",
      "screen_name" : "sunghu",
      "indices" : [ 3, 10 ],
      "id_str" : "11407672",
      "id" : 11407672
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 116 ],
      "url" : "http://t.co/ekf8yezH",
      "expanded_url" : "http://www.newyorker.com/online/blogs/culture/2013/01/video-the-art-of-pickpocketing.html",
      "display_url" : "newyorker.com/online/blogs/c…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "287979786452754433",
  "text" : "RT @sunghu: Amazing video of the world's greatest pickpocket showing his tricks and techniques: http://t.co/ekf8yezH",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 84, 104 ],
        "url" : "http://t.co/ekf8yezH",
        "expanded_url" : "http://www.newyorker.com/online/blogs/culture/2013/01/video-the-art-of-pickpocketing.html",
        "display_url" : "newyorker.com/online/blogs/c…"
      } ]
    },
    "geo" : {
    },
    "id_str" : "287962847382740992",
    "text" : "Amazing video of the world's greatest pickpocket showing his tricks and techniques: http://t.co/ekf8yezH",
    "id" : 287962847382740992,
    "created_at" : "Sun Jan 06 16:44:27 +0000 2013",
    "user" : {
      "name" : "Sung Hu Kim",
      "screen_name" : "sunghu",
      "protected" : false,
      "id_str" : "11407672",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/865738636/Sung_Hu_Kim_HQ_normal.jpg",
      "id" : 11407672,
      "verified" : false
    }
  },
  "id" : 287979786452754433,
  "created_at" : "Sun Jan 06 17:51:46 +0000 2013",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mario Sangiorgio",
      "screen_name" : "mariosangiorgio",
      "indices" : [ 0, 16 ],
      "id_str" : "244515103",
      "id" : 244515103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "287870430189088768",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.77777595008931, -122.4151250826413 ]
  },
  "id_str" : "287972406574870528",
  "in_reply_to_user_id" : 244515103,
  "text" : "@mariosangiorgio Yup exactly.",
  "id" : 287972406574870528,
  "in_reply_to_status_id" : 287870430189088768,
  "created_at" : "Sun Jan 06 17:22:26 +0000 2013",
  "in_reply_to_screen_name" : "mariosangiorgio",
  "in_reply_to_user_id_str" : "244515103",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hackweek",
      "indices" : [ 28, 37 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 98 ],
      "url" : "http://t.co/1dYjky4o",
      "expanded_url" : "http://flic.kr/p/dJ15fa",
      "display_url" : "flic.kr/p/dJ15fa"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.777, -122.417167 ]
  },
  "id_str" : "287785395192737792",
  "text" : "8:36pm Got pretty far on my #hackweek project, code name Canary in a Timeline http://t.co/1dYjky4o",
  "id" : 287785395192737792,
  "created_at" : "Sun Jan 06 04:59:19 +0000 2013",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Messina™",
      "screen_name" : "chrismessina",
      "indices" : [ 3, 16 ],
      "id_str" : "1186",
      "id" : 1186
    }, {
      "name" : "Sam Bates",
      "screen_name" : "samb8s",
      "indices" : [ 18, 25 ],
      "id_str" : "39796783",
      "id" : 39796783
    }, {
      "name" : "@buster",
      "screen_name" : "buster",
      "indices" : [ 26, 33 ],
      "id_str" : "2185",
      "id" : 2185
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FiscalCliff",
      "indices" : [ 34, 46 ]
    }, {
      "text" : "GANGNAMSTYLE",
      "indices" : [ 51, 64 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "287717886385061888",
  "text" : "RT @chrismessina: @samb8s @buster #FiscalCliff and #GANGNAMSTYLE are hashtags, so by the process of transitive elimination, hashtags had ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Sam Bates",
        "screen_name" : "samb8s",
        "indices" : [ 0, 7 ],
        "id_str" : "39796783",
        "id" : 39796783
      }, {
        "name" : "@buster",
        "screen_name" : "buster",
        "indices" : [ 8, 15 ],
        "id_str" : "2185",
        "id" : 2185
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FiscalCliff",
        "indices" : [ 16, 28 ]
      }, {
        "text" : "GANGNAMSTYLE",
        "indices" : [ 33, 46 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "287717037239828481",
    "geo" : {
    },
    "id_str" : "287717742755319808",
    "in_reply_to_user_id" : 39796783,
    "text" : "@samb8s @buster #FiscalCliff and #GANGNAMSTYLE are hashtags, so by the process of transitive elimination, hashtags had to win.",
    "id" : 287717742755319808,
    "in_reply_to_status_id" : 287717037239828481,
    "created_at" : "Sun Jan 06 00:30:30 +0000 2013",
    "in_reply_to_screen_name" : "samb8s",
    "in_reply_to_user_id_str" : "39796783",
    "user" : {
      "name" : "Chris Messina™",
      "screen_name" : "chrismessina",
      "protected" : false,
      "id_str" : "1186",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2966126873/c62b56c8de20c39dbbeca861aa5cfb0c_normal.jpeg",
      "id" : 1186,
      "verified" : false
    }
  },
  "id" : 287717886385061888,
  "created_at" : "Sun Jan 06 00:31:04 +0000 2013",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Messina™",
      "screen_name" : "chrismessina",
      "indices" : [ 116, 129 ],
      "id_str" : "1186",
      "id" : 1186
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 111 ],
      "url" : "http://t.co/3wxDjjIr",
      "expanded_url" : "http://www.theverge.com/2013/1/5/3840210/hashtag-word-of-the-year-american-dialect-society",
      "display_url" : "theverge.com/2013/1/5/38402…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "287715513403068417",
  "text" : "'Hashtag' named word of the year, beating out \"YOLO,\" \"Fiscal cliff,\" and \"Gangnam style.\" http://t.co/3wxDjjIr /cc @chrismessina",
  "id" : 287715513403068417,
  "created_at" : "Sun Jan 06 00:21:38 +0000 2013",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay Holler",
      "screen_name" : "jayholler",
      "indices" : [ 0, 10 ],
      "id_str" : "14110325",
      "id" : 14110325
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "287682913217155072",
  "geo" : {
  },
  "id_str" : "287684392145530880",
  "in_reply_to_user_id" : 14110325,
  "text" : "@jayholler Thanks! I've prototyped it before but it'll be fun to take it a couple steps further.",
  "id" : 287684392145530880,
  "in_reply_to_status_id" : 287682913217155072,
  "created_at" : "Sat Jan 05 22:17:58 +0000 2013",
  "in_reply_to_screen_name" : "jayholler",
  "in_reply_to_user_id_str" : "14110325",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Guarraci",
      "screen_name" : "eismcc",
      "indices" : [ 0, 7 ],
      "id_str" : "13257392",
      "id" : 13257392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "287681438562799616",
  "geo" : {
  },
  "id_str" : "287684303385669635",
  "in_reply_to_user_id" : 13257392,
  "text" : "@eismcc I'm gonna try and pull personal trends from your home timeline (see last few tweets).",
  "id" : 287684303385669635,
  "in_reply_to_status_id" : 287681438562799616,
  "created_at" : "Sat Jan 05 22:17:37 +0000 2013",
  "in_reply_to_screen_name" : "eismcc",
  "in_reply_to_user_id_str" : "13257392",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Guarraci",
      "screen_name" : "eismcc",
      "indices" : [ 0, 7 ],
      "id_str" : "13257392",
      "id" : 13257392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "287624102854926336",
  "geo" : {
  },
  "id_str" : "287680415072923648",
  "in_reply_to_user_id" : 13257392,
  "text" : "@eismcc What are you going to do this time?",
  "id" : 287680415072923648,
  "in_reply_to_status_id" : 287624102854926336,
  "created_at" : "Sat Jan 05 22:02:10 +0000 2013",
  "in_reply_to_screen_name" : "eismcc",
  "in_reply_to_user_id_str" : "13257392",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.branch.com\" rel=\"nofollow\">Branch Inc</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gina Trapani",
      "screen_name" : "ginatrapani",
      "indices" : [ 0, 12 ],
      "id_str" : "930061",
      "id" : 930061
    }, {
      "name" : "Anil Dash",
      "screen_name" : "anildash",
      "indices" : [ 13, 22 ],
      "id_str" : "36823",
      "id" : 36823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 139 ],
      "url" : "http://t.co/W8DStq3q",
      "expanded_url" : "http://branch.com/b/how-would-you-design-a-twitter-personal-trends-service?showsignin=true&inviter=Buster%20Benson",
      "display_url" : "branch.com/b/how-would-yo…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "287660788871725056",
  "in_reply_to_user_id" : 930061,
  "text" : "@ginatrapani @anildash I just added you to my branch about “How would you design a Twitter \"personal trends\" service?” http://t.co/W8DStq3q",
  "id" : 287660788871725056,
  "created_at" : "Sat Jan 05 20:44:11 +0000 2013",
  "in_reply_to_screen_name" : "ginatrapani",
  "in_reply_to_user_id_str" : "930061",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anil Dash",
      "screen_name" : "anildash",
      "indices" : [ 0, 9 ],
      "id_str" : "36823",
      "id" : 36823
    }, {
      "name" : "Gina Trapani",
      "screen_name" : "ginatrapani",
      "indices" : [ 10, 22 ],
      "id_str" : "930061",
      "id" : 930061
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "287659879483707392",
  "geo" : {
  },
  "id_str" : "287660069703790592",
  "in_reply_to_user_id" : 36823,
  "text" : "@anildash @ginatrapani That's partially why I want to do this, so that I can give you better feedback on how to build this into ThinkUp!",
  "id" : 287660069703790592,
  "in_reply_to_status_id" : 287659879483707392,
  "created_at" : "Sat Jan 05 20:41:19 +0000 2013",
  "in_reply_to_screen_name" : "anildash",
  "in_reply_to_user_id_str" : "36823",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mario Sangiorgio",
      "screen_name" : "mariosangiorgio",
      "indices" : [ 0, 16 ],
      "id_str" : "244515103",
      "id" : 244515103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "287653909865041920",
  "geo" : {
  },
  "id_str" : "287656857479307264",
  "in_reply_to_user_id" : 244515103,
  "text" : "@mariosangiorgio Not sure yet. Something attention-worthy, or at least more so than the average.",
  "id" : 287656857479307264,
  "in_reply_to_status_id" : 287653909865041920,
  "created_at" : "Sat Jan 05 20:28:33 +0000 2013",
  "in_reply_to_screen_name" : "mariosangiorgio",
  "in_reply_to_user_id_str" : "244515103",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zack Shapiro",
      "screen_name" : "ZackShapiro",
      "indices" : [ 0, 12 ],
      "id_str" : "15999465",
      "id" : 15999465
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "287656174164250624",
  "geo" : {
  },
  "id_str" : "287656556949032961",
  "in_reply_to_user_id" : 15999465,
  "text" : "@ZackShapiro I actually used them when I prototyped this a few months ago. Very cool API.",
  "id" : 287656556949032961,
  "in_reply_to_status_id" : 287656174164250624,
  "created_at" : "Sat Jan 05 20:27:22 +0000 2013",
  "in_reply_to_screen_name" : "ZackShapiro",
  "in_reply_to_user_id_str" : "15999465",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hackweek",
      "indices" : [ 82, 91 ]
    }, {
      "text" : "personaltrends",
      "indices" : [ 92, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "287653455311540225",
  "text" : "If anyone knows of existing implementations of this idea, send 'em my way please! #hackweek #personaltrends",
  "id" : 287653455311540225,
  "created_at" : "Sat Jan 05 20:15:02 +0000 2013",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hackweek",
      "indices" : [ 107, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "287652732364533760",
  "text" : "It should ping me when something important is happening in my timeline, maybe even before I see it myself. #hackweek",
  "id" : 287652732364533760,
  "created_at" : "Sat Jan 05 20:12:10 +0000 2013",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hackweek",
      "indices" : [ 3, 12 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "287652177848188928",
  "text" : "My #hackweek project (which I hope only takes a couple days) is to try to pull out personal trends from your home timeline.",
  "id" : 287652177848188928,
  "created_at" : "Sat Jan 05 20:09:58 +0000 2013",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 12, 20 ],
      "id_str" : "783214",
      "id" : 783214
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hackweek",
      "indices" : [ 21, 30 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "287651228626866176",
  "text" : "Starting my @twitter #hackweek project a couple days early.",
  "id" : 287651228626866176,
  "created_at" : "Sat Jan 05 20:06:11 +0000 2013",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Rainert",
      "screen_name" : "arainert",
      "indices" : [ 0, 9 ],
      "id_str" : "7482",
      "id" : 7482
    }, {
      "name" : "Bryce Roberts",
      "screen_name" : "bryce",
      "indices" : [ 10, 16 ],
      "id_str" : "6160742",
      "id" : 6160742
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "287626443087835137",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.77666744578212, -122.4180749449744 ]
  },
  "id_str" : "287632715916914688",
  "in_reply_to_user_id" : 7482,
  "text" : "@arainert @bryce Whenever Niko uses the toilet a Kermit the Frog pez dispenser flies down from the shelf to Darth Vader's theme song.",
  "id" : 287632715916914688,
  "in_reply_to_status_id" : 287626443087835137,
  "created_at" : "Sat Jan 05 18:52:38 +0000 2013",
  "in_reply_to_screen_name" : "arainert",
  "in_reply_to_user_id_str" : "7482",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Sarver",
      "screen_name" : "rsarver",
      "indices" : [ 82, 90 ],
      "id_str" : "795649",
      "id" : 795649
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 130 ],
      "url" : "http://t.co/TmnfuLZp",
      "expanded_url" : "http://www.buzzfeed.com/ryanhatesthis/the-54-best-animated-gifs-of-2012",
      "display_url" : "buzzfeed.com/ryanhatesthis/…"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.77770522846684, -122.4152490144962 ]
  },
  "id_str" : "287531707454857216",
  "text" : "54 best animated gifs of 2012, brought to you by the late night Twitter insomnia, @rsarver's question, and #6 http://t.co/TmnfuLZp",
  "id" : 287531707454857216,
  "created_at" : "Sat Jan 05 12:11:15 +0000 2013",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Strick v L",
      "screen_name" : "strickvl",
      "indices" : [ 0, 9 ],
      "id_str" : "14439930",
      "id" : 14439930
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 71 ],
      "url" : "http://t.co/EBjDeEMZ",
      "expanded_url" : "http://750words.com/help/request_help",
      "display_url" : "750words.com/help/request_h…"
    } ]
  },
  "in_reply_to_status_id_str" : "287525935681507328",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.77788786867026, -122.4151006541984 ]
  },
  "id_str" : "287526577305182209",
  "in_reply_to_user_id" : 14439930,
  "text" : "@strickvl Have you submitted a request for help to http://t.co/EBjDeEMZ? If not can you do that?",
  "id" : 287526577305182209,
  "in_reply_to_status_id" : 287525935681507328,
  "created_at" : "Sat Jan 05 11:50:52 +0000 2013",
  "in_reply_to_screen_name" : "strickvl",
  "in_reply_to_user_id_str" : "14439930",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Strick v L",
      "screen_name" : "strickvl",
      "indices" : [ 0, 9 ],
      "id_str" : "14439930",
      "id" : 14439930
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "287480151271436288",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.77786538213682, -122.4152465460026 ]
  },
  "id_str" : "287525394205274114",
  "in_reply_to_user_id" : 14439930,
  "text" : "@strickvl We try our best but don't have full time support. What's the problem?",
  "id" : 287525394205274114,
  "in_reply_to_status_id" : 287480151271436288,
  "created_at" : "Sat Jan 05 11:46:10 +0000 2013",
  "in_reply_to_screen_name" : "strickvl",
  "in_reply_to_user_id_str" : "14439930",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 56 ],
      "url" : "http://t.co/kZCVG9tm",
      "expanded_url" : "http://flic.kr/p/dHJfrB",
      "display_url" : "flic.kr/p/dHJfrB"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.771333, -122.424 ]
  },
  "id_str" : "287525090076278784",
  "text" : "8:36pm Dinner and good conversation http://t.co/kZCVG9tm",
  "id" : 287525090076278784,
  "created_at" : "Sat Jan 05 11:44:58 +0000 2013",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Claire Robertson",
      "screen_name" : "Loobylu",
      "indices" : [ 0, 8 ],
      "id_str" : "653333",
      "id" : 653333
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "287302799899914242",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.77663147994913, -122.4168716602897 ]
  },
  "id_str" : "287308300360499200",
  "in_reply_to_user_id" : 653333,
  "text" : "@Loobylu Ooh cool! Can you tweet the ones that make it to the blog too?",
  "id" : 287308300360499200,
  "in_reply_to_status_id" : 287302799899914242,
  "created_at" : "Fri Jan 04 21:23:31 +0000 2013",
  "in_reply_to_screen_name" : "Loobylu",
  "in_reply_to_user_id_str" : "653333",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "K. Thrills Jensen",
      "screen_name" : "kthorjensen",
      "indices" : [ 0, 12 ],
      "id_str" : "25319959",
      "id" : 25319959
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "287276447184343040",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.77698584157891, -122.4171476534508 ]
  },
  "id_str" : "287276781864624128",
  "in_reply_to_user_id" : 25319959,
  "text" : "@kthorjensen I think it might be n/2 cups.",
  "id" : 287276781864624128,
  "in_reply_to_status_id" : 287276447184343040,
  "created_at" : "Fri Jan 04 19:18:16 +0000 2013",
  "in_reply_to_screen_name" : "kthorjensen",
  "in_reply_to_user_id_str" : "25319959",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "josh",
      "screen_name" : "joshc",
      "indices" : [ 0, 6 ],
      "id_str" : "2015",
      "id" : 2015
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "287263888477659136",
  "geo" : {
  },
  "id_str" : "287264538234073088",
  "in_reply_to_user_id" : 2015,
  "text" : "@joshc It's still very buggy/unfinished… if you're not using the current one sure, or you might want to wait til it's a bit more stable.",
  "id" : 287264538234073088,
  "in_reply_to_status_id" : 287263888477659136,
  "created_at" : "Fri Jan 04 18:29:37 +0000 2013",
  "in_reply_to_screen_name" : "joshc",
  "in_reply_to_user_id_str" : "2015",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Guarraci",
      "screen_name" : "eismcc",
      "indices" : [ 0, 7 ],
      "id_str" : "13257392",
      "id" : 13257392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "287257059542589440",
  "geo" : {
  },
  "id_str" : "287264348378902528",
  "in_reply_to_user_id" : 13257392,
  "text" : "@eismcc And every iPhone thief should be charged the same as a kidney stealer.",
  "id" : 287264348378902528,
  "in_reply_to_status_id" : 287257059542589440,
  "created_at" : "Fri Jan 04 18:28:52 +0000 2013",
  "in_reply_to_screen_name" : "eismcc",
  "in_reply_to_user_id_str" : "13257392",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vivek Wadhwa",
      "screen_name" : "wadhwa",
      "indices" : [ 58, 65 ],
      "id_str" : "32718488",
      "id" : 32718488
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 53 ],
      "url" : "http://t.co/unfrsbHm",
      "expanded_url" : "http://m.washingtonpost.com/national/on-innovations/ethics-in-the-age-of-acceleration/2012/07/13/gJQAzVDUiW_story.html",
      "display_url" : "m.washingtonpost.com/national/on-in…"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7777840441, -122.4153050752 ]
  },
  "id_str" : "287255187842793472",
  "text" : "Ethics in an age of acceleration http://t.co/unfrsbHm /by @wadhwa",
  "id" : 287255187842793472,
  "created_at" : "Fri Jan 04 17:52:28 +0000 2013",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http://t.co/jj4Z6HjT",
      "expanded_url" : "http://wayoftheduck.com/starter-kit",
      "display_url" : "wayoftheduck.com/starter-kit"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.77777028817463, -122.4151975000769 ]
  },
  "id_str" : "287245473532768256",
  "text" : "Starter kit for a solar-powered 3D printer that can make enough $$ to buy parts, pick 'em up, and print its children. http://t.co/jj4Z6HjT",
  "id" : 287245473532768256,
  "created_at" : "Fri Jan 04 17:13:52 +0000 2013",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.77783793348057, -122.4152301527347 ]
  },
  "id_str" : "287142142105759744",
  "text" : "I'm convinced the new Kurzweil book was written for me. Recursion, pattern matching, identity, free will, robots, the future, and the brain!",
  "id" : 287142142105759744,
  "created_at" : "Fri Jan 04 10:23:16 +0000 2013",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.77805138326212, -122.4151720721779 ]
  },
  "id_str" : "287135732072583168",
  "text" : "Recursive replication is DNA. Recursive thinking is intelligence.",
  "id" : 287135732072583168,
  "created_at" : "Fri Jan 04 09:57:47 +0000 2013",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arjan Haring",
      "screen_name" : "arjanharing",
      "indices" : [ 0, 12 ],
      "id_str" : "14769627",
      "id" : 14769627
    }, {
      "name" : "Julia Galef",
      "screen_name" : "juliagalef",
      "indices" : [ 13, 24 ],
      "id_str" : "18691746",
      "id" : 18691746
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "287118033116356608",
  "geo" : {
  },
  "id_str" : "287119275209146368",
  "in_reply_to_user_id" : 14769627,
  "text" : "@arjanharing @juliagalef Thanks, Arjan, looking at it now. I wish I could just read the glossary and immediately be cured of cognitive bias.",
  "id" : 287119275209146368,
  "in_reply_to_status_id" : 287118033116356608,
  "created_at" : "Fri Jan 04 08:52:24 +0000 2013",
  "in_reply_to_screen_name" : "arjanharing",
  "in_reply_to_user_id_str" : "14769627",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Galef",
      "screen_name" : "juliagalef",
      "indices" : [ 0, 11 ],
      "id_str" : "18691746",
      "id" : 18691746
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http://t.co/1h1q58Ju",
      "expanded_url" : "http://en.wikipedia.org/wiki/List_of_cognitive_biases",
      "display_url" : "en.wikipedia.org/wiki/List_of_c…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "287117284164653056",
  "in_reply_to_user_id" : 18691746,
  "text" : "@juliagalef What's your favorite go-to list of cognitive biases and strategies to thwart them? Something simpler than http://t.co/1h1q58Ju",
  "id" : 287117284164653056,
  "created_at" : "Fri Jan 04 08:44:29 +0000 2013",
  "in_reply_to_screen_name" : "juliagalef",
  "in_reply_to_user_id_str" : "18691746",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alain de Botton",
      "screen_name" : "alaindebotton",
      "indices" : [ 3, 17 ],
      "id_str" : "19966557",
      "id" : 19966557
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "287109589269377025",
  "text" : "RT @alaindebotton: When trying to decode weird behaviour of others, think of the simple explanations and basic emotions: fear, envy, gui ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "286908248039251969",
    "text" : "When trying to decode weird behaviour of others, think of the simple explanations and basic emotions: fear, envy, guilt...",
    "id" : 286908248039251969,
    "created_at" : "Thu Jan 03 18:53:51 +0000 2013",
    "user" : {
      "name" : "Alain de Botton",
      "screen_name" : "alaindebotton",
      "protected" : false,
      "id_str" : "19966557",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1696438821/Cover_New__Book_normal.jpg",
      "id" : 19966557,
      "verified" : true
    }
  },
  "id" : 287109589269377025,
  "created_at" : "Fri Jan 04 08:13:54 +0000 2013",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anil Dash",
      "screen_name" : "anildash",
      "indices" : [ 0, 9 ],
      "id_str" : "36823",
      "id" : 36823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "287099598575661056",
  "geo" : {
  },
  "id_str" : "287104117292294144",
  "in_reply_to_user_id" : 36823,
  "text" : "@anildash Totally. Stoked for the ability to upload my entire Twitter archive too. So fun.",
  "id" : 287104117292294144,
  "in_reply_to_status_id" : 287099598575661056,
  "created_at" : "Fri Jan 04 07:52:10 +0000 2013",
  "in_reply_to_screen_name" : "anildash",
  "in_reply_to_user_id_str" : "36823",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ThinkUp",
      "screen_name" : "thinkup",
      "indices" : [ 7, 15 ],
      "id_str" : "100127476",
      "id" : 100127476
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 54 ],
      "url" : "http://t.co/oiKAuYFg",
      "expanded_url" : "http://bit.ly/TMzHtz",
      "display_url" : "bit.ly/TMzHtz"
    }, {
      "indices" : [ 118, 138 ],
      "url" : "http://t.co/hIvr4kzc",
      "expanded_url" : "http://bit.ly/TMzF5d",
      "display_url" : "bit.ly/TMzF5d"
    } ]
  },
  "geo" : {
  },
  "id_str" : "287099302277419009",
  "text" : "Got my @thinkup 2.0 beta running: http://t.co/oiKAuYFg and it has a TON of cool improvements over 1.1.1. Get it here! http://t.co/hIvr4kzc",
  "id" : 287099302277419009,
  "created_at" : "Fri Jan 04 07:33:02 +0000 2013",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anil Dash",
      "screen_name" : "anildash",
      "indices" : [ 0, 9 ],
      "id_str" : "36823",
      "id" : 36823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "287098062470537216",
  "geo" : {
  },
  "id_str" : "287098327735074817",
  "in_reply_to_user_id" : 36823,
  "text" : "@anildash Yay! Ran the CLI again and it just finished up. Last output: \"Completed insight generation for Buster Benson on facebook\".",
  "id" : 287098327735074817,
  "in_reply_to_status_id" : 287098062470537216,
  "created_at" : "Fri Jan 04 07:29:10 +0000 2013",
  "in_reply_to_screen_name" : "anildash",
  "in_reply_to_user_id_str" : "36823",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anil Dash",
      "screen_name" : "anildash",
      "indices" : [ 0, 9 ],
      "id_str" : "36823",
      "id" : 36823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "287096859594481664",
  "geo" : {
  },
  "id_str" : "287097158363148288",
  "in_reply_to_user_id" : 36823,
  "text" : "@anildash Not frustrated... just wanted to let you know. Thanks for continuing to make this more awesome.",
  "id" : 287097158363148288,
  "in_reply_to_status_id" : 287096859594481664,
  "created_at" : "Fri Jan 04 07:24:31 +0000 2013",
  "in_reply_to_screen_name" : "anildash",
  "in_reply_to_user_id_str" : "36823",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anil Dash",
      "screen_name" : "anildash",
      "indices" : [ 0, 9 ],
      "id_str" : "36823",
      "id" : 36823
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/buster/status/287096554442088451/photo/1",
      "indices" : [ 38, 58 ],
      "url" : "http://t.co/qFwzU5WN",
      "media_url" : "http://pbs.twimg.com/media/A_v4y5ACYAA5sB1.png",
      "id_str" : "287096554446282752",
      "id" : 287096554446282752,
      "media_url_https" : "https://pbs.twimg.com/media/A_v4y5ACYAA5sB1.png",
      "sizes" : [ {
        "h" : 212,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 375,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 496,
        "resize" : "fit",
        "w" : 794
      }, {
        "h" : 496,
        "resize" : "fit",
        "w" : 794
      } ],
      "display_url" : "pic.twitter.com/qFwzU5WN"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "287096222152536064",
  "geo" : {
  },
  "id_str" : "287096554442088451",
  "in_reply_to_user_id" : 36823,
  "text" : "@anildash Yup, I have. Still no dash. http://t.co/qFwzU5WN",
  "id" : 287096554442088451,
  "in_reply_to_status_id" : 287096222152536064,
  "created_at" : "Fri Jan 04 07:22:07 +0000 2013",
  "in_reply_to_screen_name" : "anildash",
  "in_reply_to_user_id_str" : "36823",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anil Dash",
      "screen_name" : "anildash",
      "indices" : [ 0, 9 ],
      "id_str" : "36823",
      "id" : 36823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "287095250416189440",
  "geo" : {
  },
  "id_str" : "287095970485919744",
  "in_reply_to_user_id" : 36823,
  "text" : "@anildash Hm, it just finished with \"Completed insight generation for buster on twitter\" and still no dashboard...",
  "id" : 287095970485919744,
  "in_reply_to_status_id" : 287095250416189440,
  "created_at" : "Fri Jan 04 07:19:48 +0000 2013",
  "in_reply_to_screen_name" : "anildash",
  "in_reply_to_user_id_str" : "36823",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anil Dash",
      "screen_name" : "anildash",
      "indices" : [ 0, 9 ],
      "id_str" : "36823",
      "id" : 36823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "287095250416189440",
  "geo" : {
  },
  "id_str" : "287095634085965824",
  "in_reply_to_user_id" : 36823,
  "text" : "@anildash Suspected that might be the case. The web crawler didn't do the trick but the CLI crawler seems to be doing a bunch of stuff now.",
  "id" : 287095634085965824,
  "in_reply_to_status_id" : 287095250416189440,
  "created_at" : "Fri Jan 04 07:18:27 +0000 2013",
  "in_reply_to_screen_name" : "anildash",
  "in_reply_to_user_id_str" : "36823",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 126 ],
      "url" : "http://t.co/ueRnYoyG",
      "expanded_url" : "http://bit.ly/ULSOGj",
      "display_url" : "bit.ly/ULSOGj"
    } ]
  },
  "geo" : {
  },
  "id_str" : "287094271088148480",
  "text" : "Just bought Ray Kurzweil's new book \"How to Create a Mind\" after watching his talk at Singularity Summit: http://t.co/ueRnYoyG",
  "id" : 287094271088148480,
  "created_at" : "Fri Jan 04 07:13:02 +0000 2013",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vivek Wadhwa",
      "screen_name" : "wadhwa",
      "indices" : [ 3, 10 ],
      "id_str" : "32718488",
      "id" : 32718488
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GoogleSca",
      "indices" : [ 126, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "287094006121381889",
  "text" : "RT @wadhwa: Kurzweil says that at Google, he will be working on advanced implementations of AI--will have unlimited resources #GoogleSca ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GoogleScale",
        "indices" : [ 114, 126 ]
      }, {
        "text" : "SingularityU",
        "indices" : [ 127, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "286893821944557568",
    "text" : "Kurzweil says that at Google, he will be working on advanced implementations of AI--will have unlimited resources #GoogleScale #SingularityU",
    "id" : 286893821944557568,
    "created_at" : "Thu Jan 03 17:56:32 +0000 2013",
    "user" : {
      "name" : "Vivek Wadhwa",
      "screen_name" : "wadhwa",
      "protected" : false,
      "id_str" : "32718488",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2662711934/ee1d3f2d0e823f6f0b6eadb88b3e039b_normal.jpeg",
      "id" : 32718488,
      "verified" : false
    }
  },
  "id" : 287094006121381889,
  "created_at" : "Fri Jan 04 07:11:59 +0000 2013",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Malin",
      "screen_name" : "mmalin",
      "indices" : [ 0, 7 ],
      "id_str" : "606727563",
      "id" : 606727563
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "287091194360655872",
  "geo" : {
  },
  "id_str" : "287091663531286529",
  "in_reply_to_user_id" : 606727563,
  "text" : "@mmalin Easiest revolution ever.",
  "id" : 287091663531286529,
  "in_reply_to_status_id" : 287091194360655872,
  "created_at" : "Fri Jan 04 07:02:41 +0000 2013",
  "in_reply_to_screen_name" : "mmalin",
  "in_reply_to_user_id_str" : "606727563",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Malin",
      "screen_name" : "mmalin",
      "indices" : [ 0, 7 ],
      "id_str" : "606727563",
      "id" : 606727563
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "287090667363115008",
  "geo" : {
  },
  "id_str" : "287090756508864512",
  "in_reply_to_user_id" : 606727563,
  "text" : "@mmalin What if that just teaches them how to be misleading? :)",
  "id" : 287090756508864512,
  "in_reply_to_status_id" : 287090667363115008,
  "created_at" : "Fri Jan 04 06:59:04 +0000 2013",
  "in_reply_to_screen_name" : "mmalin",
  "in_reply_to_user_id_str" : "606727563",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ThinkUp",
      "screen_name" : "thinkup",
      "indices" : [ 0, 8 ],
      "id_str" : "100127476",
      "id" : 100127476
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http://t.co/xnD8gV9t",
      "expanded_url" : "http://busterbenson.com/thinkup/",
      "display_url" : "busterbenson.com/thinkup/"
    } ]
  },
  "in_reply_to_status_id_str" : "286585099900817408",
  "geo" : {
  },
  "id_str" : "287090633783508992",
  "in_reply_to_user_id" : 100127476,
  "text" : "@thinkup I upgraded, connected accounts, &amp; ran the cron but still see a \"get started\" page instead of the dash: http://t.co/xnD8gV9t Ideas?",
  "id" : 287090633783508992,
  "in_reply_to_status_id" : 286585099900817408,
  "created_at" : "Fri Jan 04 06:58:35 +0000 2013",
  "in_reply_to_screen_name" : "thinkup",
  "in_reply_to_user_id_str" : "100127476",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "287080050807934976",
  "text" : "There are 4.1M articles in Wikipedia, more than we'll ever be able to read, much less remember. Watson can read &amp; memorize it in 3 seconds.",
  "id" : 287080050807934976,
  "created_at" : "Fri Jan 04 06:16:32 +0000 2013",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "287079179562930176",
  "text" : "Wikipedia isn't a free encyclopedia for humans, it's the \"ABC 123\" book for future baby computer brains.",
  "id" : 287079179562930176,
  "created_at" : "Fri Jan 04 06:13:04 +0000 2013",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 69 ],
      "url" : "http://t.co/y9N5J7YY",
      "expanded_url" : "http://flic.kr/p/dHkq7P",
      "display_url" : "flic.kr/p/dHkq7P"
    } ]
  },
  "geo" : {
  },
  "id_str" : "287066677521309696",
  "text" : "8:36pm Fiddling with work ideas in my hotel room http://t.co/y9N5J7YY",
  "id" : 287066677521309696,
  "created_at" : "Fri Jan 04 05:23:24 +0000 2013",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 49 ],
      "url" : "http://t.co/XZNlOTu6",
      "expanded_url" : "http://cinemagr.am/show/93114844",
      "display_url" : "cinemagr.am/show/93114844"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.77298768624176, -122.4153850375527 ]
  },
  "id_str" : "287052976374308864",
  "text" : "Ambient conversations at Una http://t.co/XZNlOTu6",
  "id" : 287052976374308864,
  "created_at" : "Fri Jan 04 04:28:57 +0000 2013",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "287050943575502848",
  "text" : "If the Tesla Model S is the iPhone of cars, what's the 4th gen Android? Actually, how about the Sidekick.",
  "id" : 287050943575502848,
  "created_at" : "Fri Jan 04 04:20:52 +0000 2013",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Walter Adamson",
      "screen_name" : "adamson",
      "indices" : [ 3, 11 ],
      "id_str" : "9616512",
      "id" : 9616512
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 103 ],
      "url" : "http://t.co/KettLbyM",
      "expanded_url" : "http://tech.fortune.cnn.com/2013/01/03/google-larry-page",
      "display_url" : "tech.fortune.cnn.com/2013/01/03/goo…"
    }, {
      "indices" : [ 114, 134 ],
      "url" : "http://t.co/h13c75EC",
      "expanded_url" : "http://tweetedtimes.com/ThePersuader/brains-like-planets",
      "display_url" : "tweetedtimes.com/ThePersuader/b…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "287049727898431488",
  "text" : "RT @adamson: Top story: The future according to Google's Larry Page - Fortune Tech http://t.co/KettLbyM, see more http://t.co/h13c75EC",
  "retweeted_status" : {
    "source" : "<a href=\"http://tweetedtimes.com\" rel=\"nofollow\">The Tweeted Times Mobile</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 70, 90 ],
        "url" : "http://t.co/KettLbyM",
        "expanded_url" : "http://tech.fortune.cnn.com/2013/01/03/google-larry-page",
        "display_url" : "tech.fortune.cnn.com/2013/01/03/goo…"
      }, {
        "indices" : [ 101, 121 ],
        "url" : "http://t.co/h13c75EC",
        "expanded_url" : "http://tweetedtimes.com/ThePersuader/brains-like-planets",
        "display_url" : "tweetedtimes.com/ThePersuader/b…"
      } ]
    },
    "geo" : {
    },
    "id_str" : "287040457446404097",
    "text" : "Top story: The future according to Google's Larry Page - Fortune Tech http://t.co/KettLbyM, see more http://t.co/h13c75EC",
    "id" : 287040457446404097,
    "created_at" : "Fri Jan 04 03:39:12 +0000 2013",
    "user" : {
      "name" : "Walter Adamson",
      "screen_name" : "adamson",
      "protected" : false,
      "id_str" : "9616512",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/90654394/Adamson-184X184_normal.JPG",
      "id" : 9616512,
      "verified" : false
    }
  },
  "id" : 287049727898431488,
  "created_at" : "Fri Jan 04 04:16:02 +0000 2013",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elon Musk",
      "screen_name" : "elonmusk",
      "indices" : [ 33, 42 ],
      "id_str" : "44196397",
      "id" : 44196397
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 80 ],
      "url" : "http://t.co/WjhTkBbj",
      "expanded_url" : "http://www.wired.co.uk/news/archive/2012-11/19/elon-musk-on-hyperloop",
      "display_url" : "wired.co.uk/news/archive/2…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "287039152292233216",
  "text" : "I really want to know more about @elonmusk’s Hyperloop idea http://t.co/WjhTkBbj",
  "id" : 287039152292233216,
  "created_at" : "Fri Jan 04 03:34:01 +0000 2013",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sarah kathleen peck",
      "screen_name" : "sarahkpeck",
      "indices" : [ 0, 11 ],
      "id_str" : "196745496",
      "id" : 196745496
    }, {
      "name" : "sha",
      "screen_name" : "shashashasha",
      "indices" : [ 12, 25 ],
      "id_str" : "3176751",
      "id" : 3176751
    }, {
      "name" : "Andi Hansen",
      "screen_name" : "vis_sys",
      "indices" : [ 26, 34 ],
      "id_str" : "845914094",
      "id" : 845914094
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "286993889724887040",
  "geo" : {
  },
  "id_str" : "287037802795921408",
  "in_reply_to_user_id" : 196745496,
  "text" : "@sarahkpeck @shashashasha @vis_sys That’s pretty neat. Is the list of micro-life pluses and minuses available anywhere?",
  "id" : 287037802795921408,
  "in_reply_to_status_id" : 286993889724887040,
  "created_at" : "Fri Jan 04 03:28:39 +0000 2013",
  "in_reply_to_screen_name" : "sarahkpeck",
  "in_reply_to_user_id_str" : "196745496",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Annalee Newitz",
      "screen_name" : "Annaleen",
      "indices" : [ 3, 12 ],
      "id_str" : "756475",
      "id" : 756475
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 108 ],
      "url" : "http://t.co/3ZhLGZfu",
      "expanded_url" : "http://www.slate.com/blogs/future_tense/2013/01/03/mark_lynas_environmentalist_who_opposed_gmos_admits_he_was_wrong.html",
      "display_url" : "slate.com/blogs/future_t…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "287035898598674432",
  "text" : "RT @Annaleen: This is a huge step forward for environmentalism. GMOs are not the enemy. http://t.co/3ZhLGZfu",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 74, 94 ],
        "url" : "http://t.co/3ZhLGZfu",
        "expanded_url" : "http://www.slate.com/blogs/future_tense/2013/01/03/mark_lynas_environmentalist_who_opposed_gmos_admits_he_was_wrong.html",
        "display_url" : "slate.com/blogs/future_t…"
      } ]
    },
    "geo" : {
    },
    "id_str" : "287004441687773184",
    "text" : "This is a huge step forward for environmentalism. GMOs are not the enemy. http://t.co/3ZhLGZfu",
    "id" : 287004441687773184,
    "created_at" : "Fri Jan 04 01:16:05 +0000 2013",
    "user" : {
      "name" : "Annalee Newitz",
      "screen_name" : "Annaleen",
      "protected" : false,
      "id_str" : "756475",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2381216127/7lycf0juxowmrx88i90m_normal.jpeg",
      "id" : 756475,
      "verified" : false
    }
  },
  "id" : 287035898598674432,
  "created_at" : "Fri Jan 04 03:21:05 +0000 2013",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Ellin",
      "screen_name" : "brianellin",
      "indices" : [ 0, 11 ],
      "id_str" : "26123649",
      "id" : 26123649
    }, {
      "name" : "Kate Taylor",
      "screen_name" : "purekate",
      "indices" : [ 12, 21 ],
      "id_str" : "15214830",
      "id" : 15214830
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "287031208062377985",
  "geo" : {
  },
  "id_str" : "287034757404061696",
  "in_reply_to_user_id" : 26123649,
  "text" : "@brianellin @purekate I’m here til Wed afternoon. Pick a day!",
  "id" : 287034757404061696,
  "in_reply_to_status_id" : 287031208062377985,
  "created_at" : "Fri Jan 04 03:16:33 +0000 2013",
  "in_reply_to_screen_name" : "brianellin",
  "in_reply_to_user_id_str" : "26123649",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.apple.com\" rel=\"nofollow\">iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Higgins",
      "screen_name" : "chrishiggins",
      "indices" : [ 42, 55 ],
      "id_str" : "12096622",
      "id" : 12096622
    }, {
      "name" : "The Magazine",
      "screen_name" : "TheMagazineApp",
      "indices" : [ 59, 74 ],
      "id_str" : "748478131",
      "id" : 748478131
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 95 ],
      "url" : "http://t.co/V5ChlT4f",
      "expanded_url" : "http://the-magazine.org/7/playing-to-lose",
      "display_url" : "the-magazine.org/7/playing-to-l…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "287033621301297152",
  "text" : "Competitive Tetris! \"Playing to Lose\" /by @chrishiggins in @TheMagazineApp http://t.co/V5ChlT4f",
  "id" : 287033621301297152,
  "created_at" : "Fri Jan 04 03:12:02 +0000 2013",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emily Olson",
      "screen_name" : "emilyolson",
      "indices" : [ 0, 11 ],
      "id_str" : "14097091",
      "id" : 14097091
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "287027666639548417",
  "geo" : {
  },
  "id_str" : "287029127695974400",
  "in_reply_to_user_id" : 14097091,
  "text" : "@emilyolson Ooh that sounds good. I’ll look it up.",
  "id" : 287029127695974400,
  "in_reply_to_status_id" : 287027666639548417,
  "created_at" : "Fri Jan 04 02:54:11 +0000 2013",
  "in_reply_to_screen_name" : "emilyolson",
  "in_reply_to_user_id_str" : "14097091",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kate Taylor",
      "screen_name" : "purekate",
      "indices" : [ 0, 9 ],
      "id_str" : "15214830",
      "id" : 15214830
    }, {
      "name" : "Brian Ellin",
      "screen_name" : "brianellin",
      "indices" : [ 70, 81 ],
      "id_str" : "26123649",
      "id" : 26123649
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "287027975461945344",
  "geo" : {
  },
  "id_str" : "287028913991974912",
  "in_reply_to_user_id" : 15214830,
  "text" : "@purekate In my opinion, yes. I like the whole feel of the place too. @brianellin tipped me off on it.",
  "id" : 287028913991974912,
  "in_reply_to_status_id" : 287027975461945344,
  "created_at" : "Fri Jan 04 02:53:20 +0000 2013",
  "in_reply_to_screen_name" : "purekate",
  "in_reply_to_user_id_str" : "15214830",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 115 ],
      "url" : "http://t.co/f8vHRCXy",
      "expanded_url" : "http://4sq.com/UkqJaP",
      "display_url" : "4sq.com/UkqJaP"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.772918, -122.415449 ]
  },
  "id_str" : "287027276762206208",
  "text" : "First thing I want to eat when I return to SF. What should I do next? (@ Una Pizza Napoletana) http://t.co/f8vHRCXy",
  "id" : 287027276762206208,
  "created_at" : "Fri Jan 04 02:46:50 +0000 2013",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ArielMeadowStallings",
      "screen_name" : "OffbeatAriel",
      "indices" : [ 0, 13 ],
      "id_str" : "14095370",
      "id" : 14095370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "286977794234269696",
  "geo" : {
  },
  "id_str" : "286982844016885760",
  "in_reply_to_user_id" : 14095370,
  "text" : "@OffbeatAriel I've heard Niko start doing the same.",
  "id" : 286982844016885760,
  "in_reply_to_status_id" : 286977794234269696,
  "created_at" : "Thu Jan 03 23:50:16 +0000 2013",
  "in_reply_to_screen_name" : "OffbeatAriel",
  "in_reply_to_user_id_str" : "14095370",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Hadfield",
      "screen_name" : "Cmdr_Hadfield",
      "indices" : [ 7, 21 ],
      "id_str" : "186154646",
      "id" : 186154646
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "286965969748893696",
  "text" : "Follow @Cmdr_Hadfield right now -- he's tweeting pictures of Earth from space as he orbits.",
  "id" : 286965969748893696,
  "created_at" : "Thu Jan 03 22:43:13 +0000 2013",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "William Shatner",
      "screen_name" : "WilliamShatner",
      "indices" : [ 23, 38 ],
      "id_str" : "15227791",
      "id" : 15227791
    }, {
      "name" : "Chris Hadfield",
      "screen_name" : "Cmdr_Hadfield",
      "indices" : [ 43, 57 ],
      "id_str" : "186154646",
      "id" : 186154646
    }, {
      "name" : "Raffi Krikorian",
      "screen_name" : "raffi",
      "indices" : [ 112, 118 ],
      "id_str" : "8285392",
      "id" : 8285392
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "omg",
      "indices" : [ 102, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 101 ],
      "url" : "http://t.co/moqtvBs9",
      "expanded_url" : "http://bit.ly/RvoL4Y",
      "display_url" : "bit.ly/RvoL4Y"
    } ]
  },
  "geo" : {
  },
  "id_str" : "286965303152357376",
  "text" : "Tweet exchange between @WilliamShatner and @Cmdr_Hadfield as he orbits in space! http://t.co/moqtvBs9 #omg /via @raffi",
  "id" : 286965303152357376,
  "created_at" : "Thu Jan 03 22:40:34 +0000 2013",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Bragger",
      "screen_name" : "kylebragger",
      "indices" : [ 0, 12 ],
      "id_str" : "2039761",
      "id" : 2039761
    }, {
      "name" : "Pasquale D'Silva?",
      "screen_name" : "pasql",
      "indices" : [ 13, 19 ],
      "id_str" : "187793",
      "id" : 187793
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "286911397902815232",
  "geo" : {
  },
  "id_str" : "286913531696250880",
  "in_reply_to_user_id" : 2039761,
  "text" : "@kylebragger @pasql Oooh, I think I just \"got\" Sets. Exciiiiting.",
  "id" : 286913531696250880,
  "in_reply_to_status_id" : 286911397902815232,
  "created_at" : "Thu Jan 03 19:14:51 +0000 2013",
  "in_reply_to_screen_name" : "kylebragger",
  "in_reply_to_user_id_str" : "2039761",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Swizec",
      "screen_name" : "Swizec",
      "indices" : [ 0, 7 ],
      "id_str" : "15353121",
      "id" : 15353121
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "286768942708568064",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.77783836384609, -122.4151709484619 ]
  },
  "id_str" : "286769896325525504",
  "in_reply_to_user_id" : 15353121,
  "text" : "@Swizec No, it's gotta be deliberate.",
  "id" : 286769896325525504,
  "in_reply_to_status_id" : 286768942708568064,
  "created_at" : "Thu Jan 03 09:44:05 +0000 2013",
  "in_reply_to_screen_name" : "Swizec",
  "in_reply_to_user_id_str" : "15353121",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 139 ],
      "url" : "https://t.co/UKLW7hVo",
      "expanded_url" : "https://github.com/busterbenson/public/blob/master/Beliefs.md",
      "display_url" : "github.com/busterbenson/p…"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7777776231877, -122.4152205911655 ]
  },
  "id_str" : "286768149595049987",
  "text" : "One of the most rewarding things with tracking beliefs is having a tangible reference to go back to when things shift https://t.co/UKLW7hVo",
  "id" : 286768149595049987,
  "created_at" : "Thu Jan 03 09:37:09 +0000 2013",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Bonner",
      "screen_name" : "seanbonner",
      "indices" : [ 0, 11 ],
      "id_str" : "765",
      "id" : 765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "286766782612639744",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.77771378961253, -122.4152650844177 ]
  },
  "id_str" : "286767612787036160",
  "in_reply_to_user_id" : 765,
  "text" : "@seanbonner Same here (though you've probably read more). I loved his free will book too. Gonna let it sink in and see where beliefs end up.",
  "id" : 286767612787036160,
  "in_reply_to_status_id" : 286766782612639744,
  "created_at" : "Thu Jan 03 09:35:01 +0000 2013",
  "in_reply_to_screen_name" : "seanbonner",
  "in_reply_to_user_id_str" : "765",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Bonner",
      "screen_name" : "seanbonner",
      "indices" : [ 0, 11 ],
      "id_str" : "765",
      "id" : 765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "286749063527927808",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.77777876065203, -122.4151991244962 ]
  },
  "id_str" : "286765994096091136",
  "in_reply_to_user_id" : 765,
  "text" : "@seanbonner Yeah Sam Harris is pretty rad. Thanks for the link. My mind is changing about a few things.",
  "id" : 286765994096091136,
  "in_reply_to_status_id" : 286749063527927808,
  "created_at" : "Thu Jan 03 09:28:35 +0000 2013",
  "in_reply_to_screen_name" : "seanbonner",
  "in_reply_to_user_id_str" : "765",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Harris",
      "screen_name" : "SamHarrisOrg",
      "indices" : [ 31, 44 ],
      "id_str" : "116994659",
      "id" : 116994659
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 139 ],
      "url" : "http://t.co/bXB1tH6v",
      "expanded_url" : "http://bit.ly/12ZwHzc",
      "display_url" : "bit.ly/12ZwHzc"
    } ]
  },
  "in_reply_to_status_id_str" : "286641445560020992",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.77786483076034, -122.4151267445157 ]
  },
  "id_str" : "286765373653676032",
  "in_reply_to_user_id" : 116994659,
  "text" : "Long, but pretty damn smart RT @SamHarrisOrg: My thoughts on guns in the aftermath of Newtown: \"The Riddle of the Gun\" http://t.co/bXB1tH6v",
  "id" : 286765373653676032,
  "in_reply_to_status_id" : 286641445560020992,
  "created_at" : "Thu Jan 03 09:26:07 +0000 2013",
  "in_reply_to_screen_name" : "SamHarrisOrg",
  "in_reply_to_user_id_str" : "116994659",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.77778525245882, -122.4152327560987 ]
  },
  "id_str" : "286757644109217792",
  "text" : "Whoever's in charge of my brain right now is easily annoyed apparently.",
  "id" : 286757644109217792,
  "created_at" : "Thu Jan 03 08:55:24 +0000 2013",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.apple.com\" rel=\"nofollow\">Safari on iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 134 ],
      "url" : "http://t.co/McteUKJD",
      "expanded_url" : "http://www.elephantjournal.com/2013/01/the-yinside-of-new-years-resolutions-bernie-clark/?utm_source=All&utm_campaign=Daily+Moment+of+Awake+in+the+Inbox+of+Your+Mind&utm_medium=email",
      "display_url" : "elephantjournal.com/2013/01/the-yi…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "286657982010363905",
  "text" : "\"This year, why not resolve to accept something about yourself that you will no longer try to change or improve?\" http://t.co/McteUKJD",
  "id" : 286657982010363905,
  "created_at" : "Thu Jan 03 02:19:23 +0000 2013",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 102 ],
      "url" : "http://t.co/pkqr97Rf",
      "expanded_url" : "http://flic.kr/p/dGWtVi",
      "display_url" : "flic.kr/p/dGWtVi"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 33.641333, -84.439167 ]
  },
  "id_str" : "286651200097640449",
  "text" : "8:36pm Connecting in Atlanta. Walking by a life-size touchscreen video game (ad?) http://t.co/pkqr97Rf",
  "id" : 286651200097640449,
  "created_at" : "Thu Jan 03 01:52:26 +0000 2013",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sara Mauskopf",
      "screen_name" : "sm",
      "indices" : [ 0, 3 ],
      "id_str" : "22273667",
      "id" : 22273667
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "286629319042822146",
  "geo" : {
  },
  "id_str" : "286632074385952769",
  "in_reply_to_user_id" : 22273667,
  "text" : "@sm Delaware doesn't have cheesesteak, will scapple do?",
  "id" : 286632074385952769,
  "in_reply_to_status_id" : 286629319042822146,
  "created_at" : "Thu Jan 03 00:36:26 +0000 2013",
  "in_reply_to_screen_name" : "sm",
  "in_reply_to_user_id_str" : "22273667",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Buddy Bump",
      "screen_name" : "bebumpersticker",
      "indices" : [ 0, 16 ],
      "id_str" : "438711168",
      "id" : 438711168
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "286607466836422656",
  "geo" : {
  },
  "id_str" : "286622165925781505",
  "in_reply_to_user_id" : 438711168,
  "text" : "@bebumpersticker Awesome to hear it. Let me know how it goes and if I can help with anything.",
  "id" : 286622165925781505,
  "in_reply_to_status_id" : 286607466836422656,
  "created_at" : "Wed Jan 02 23:57:04 +0000 2013",
  "in_reply_to_screen_name" : "bebumpersticker",
  "in_reply_to_user_id_str" : "438711168",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sara Mauskopf",
      "screen_name" : "sm",
      "indices" : [ 0, 3 ],
      "id_str" : "22273667",
      "id" : 22273667
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "286611022305964034",
  "geo" : {
  },
  "id_str" : "286622040973262848",
  "in_reply_to_user_id" : 22273667,
  "text" : "@sm My wife grew up in Wilmington DE, which sort of counts as Philly, right? Did you head back for the holidays this year?",
  "id" : 286622040973262848,
  "in_reply_to_status_id" : 286611022305964034,
  "created_at" : "Wed Jan 02 23:56:34 +0000 2013",
  "in_reply_to_screen_name" : "sm",
  "in_reply_to_user_id_str" : "22273667",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http://t.co/wo5rKbVR",
      "expanded_url" : "http://4sq.com/XjVpd3",
      "display_url" : "4sq.com/XjVpd3"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 39.87700745276243, -75.2424430847168 ]
  },
  "id_str" : "286610362256748544",
  "text" : "Sad to be leaving family for a week. Excited to be going back to work. (@ Philadelphia International Airport (PHL)) http://t.co/wo5rKbVR",
  "id" : 286610362256748544,
  "created_at" : "Wed Jan 02 23:10:09 +0000 2013",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Buddy Bump",
      "screen_name" : "bebumpersticker",
      "indices" : [ 0, 16 ],
      "id_str" : "438711168",
      "id" : 438711168
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "286601250567487488",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 39.87574426904125, -75.24087215153662 ]
  },
  "id_str" : "286606259749257217",
  "in_reply_to_user_id" : 438711168,
  "text" : "@bebumpersticker Cool! What inspired you?",
  "id" : 286606259749257217,
  "in_reply_to_status_id" : 286601250567487488,
  "created_at" : "Wed Jan 02 22:53:51 +0000 2013",
  "in_reply_to_screen_name" : "bebumpersticker",
  "in_reply_to_user_id_str" : "438711168",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagr.am\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 54 ],
      "url" : "http://t.co/hshXd3T5",
      "expanded_url" : "http://instagr.am/p/T_nLaZI0Jm/",
      "display_url" : "instagr.am/p/T_nLaZI0Jm/"
    } ]
  },
  "geo" : {
  },
  "id_str" : "286562494330306560",
  "text" : "Xmas Castle continues development http://t.co/hshXd3T5",
  "id" : 286562494330306560,
  "created_at" : "Wed Jan 02 19:59:57 +0000 2013",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rabbitrabbit",
      "indices" : [ 113, 126 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 112 ],
      "url" : "http://t.co/pSnxdXnA",
      "expanded_url" : "http://wayoftheduck.com/rabbit-rabbit",
      "display_url" : "wayoftheduck.com/rabbit-rabbit"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 39.7619325518, -75.508218267 ]
  },
  "id_str" : "286544221274521601",
  "text" : "Want me to remind you of your resolution on the 1st of every month this year? Join us here: http://t.co/pSnxdXnA #rabbitrabbit",
  "id" : 286544221274521601,
  "created_at" : "Wed Jan 02 18:47:20 +0000 2013",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carinna Tarvin",
      "screen_name" : "carinnatarvin",
      "indices" : [ 0, 14 ],
      "id_str" : "20833838",
      "id" : 20833838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "286541714146086912",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 39.76191394793582, -75.50821683620815 ]
  },
  "id_str" : "286542832662114305",
  "in_reply_to_user_id" : 20833838,
  "text" : "@carinnatarvin Hmm, good question. I think you should talk about at least one other thing to be safe.",
  "id" : 286542832662114305,
  "in_reply_to_status_id" : 286541714146086912,
  "created_at" : "Wed Jan 02 18:41:49 +0000 2013",
  "in_reply_to_screen_name" : "carinnatarvin",
  "in_reply_to_user_id_str" : "20833838",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carinna Tarvin",
      "screen_name" : "carinnatarvin",
      "indices" : [ 0, 14 ],
      "id_str" : "20833838",
      "id" : 20833838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "286541518653763585",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 39.76198018997885, -75.508593656193 ]
  },
  "id_str" : "286541886934622209",
  "in_reply_to_user_id" : 20833838,
  "text" : "@carinnatarvin Awesome, run with it! It's been enlightening to think about it as I watch tv in Delaware. Happy new year!",
  "id" : 286541886934622209,
  "in_reply_to_status_id" : 286541518653763585,
  "created_at" : "Wed Jan 02 18:38:04 +0000 2013",
  "in_reply_to_screen_name" : "carinnatarvin",
  "in_reply_to_user_id_str" : "20833838",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 139 ],
      "url" : "http://t.co/c3XHLohb",
      "expanded_url" : "http://en.m.wikipedia.org/wiki/Bechdel_test",
      "display_url" : "en.m.wikipedia.org/wiki/Bechdel_t…"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 39.7619828823, -75.5083442082 ]
  },
  "id_str" : "286525398848782336",
  "text" : "A work passes the Bechdel test if it features at least 2 women who talk to each other about something other than a man http://t.co/c3XHLohb",
  "id" : 286525398848782336,
  "created_at" : "Wed Jan 02 17:32:33 +0000 2013",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Ward",
      "screen_name" : "BenWard",
      "indices" : [ 0, 8 ],
      "id_str" : "12249",
      "id" : 12249
    }, {
      "name" : "Alex Duloz",
      "screen_name" : "alexduloz",
      "indices" : [ 9, 19 ],
      "id_str" : "380189226",
      "id" : 380189226
    }, {
      "name" : "Katy Watkins",
      "screen_name" : "_KatyWatkins",
      "indices" : [ 20, 33 ],
      "id_str" : "238824495",
      "id" : 238824495
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "286522602007187458",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 39.7624419209, -75.5083182315 ]
  },
  "id_str" : "286523857697923073",
  "in_reply_to_user_id" : 12249,
  "text" : "@BenWard @alexduloz @_katywatkins A google group would be enough to bootstrap I think.",
  "id" : 286523857697923073,
  "in_reply_to_status_id" : 286522602007187458,
  "created_at" : "Wed Jan 02 17:26:25 +0000 2013",
  "in_reply_to_screen_name" : "BenWard",
  "in_reply_to_user_id_str" : "12249",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Ward",
      "screen_name" : "BenWard",
      "indices" : [ 0, 8 ],
      "id_str" : "12249",
      "id" : 12249
    }, {
      "name" : "Alex Duloz",
      "screen_name" : "alexduloz",
      "indices" : [ 9, 19 ],
      "id_str" : "380189226",
      "id" : 380189226
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "286515080605073409",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 39.7619212026, -75.5082723053 ]
  },
  "id_str" : "286519524000407552",
  "in_reply_to_user_id" : 12249,
  "text" : "@BenWard @alexduloz I would be so into that.",
  "id" : 286519524000407552,
  "in_reply_to_status_id" : 286515080605073409,
  "created_at" : "Wed Jan 02 17:09:12 +0000 2013",
  "in_reply_to_screen_name" : "BenWard",
  "in_reply_to_user_id_str" : "12249",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Duloz",
      "screen_name" : "alexduloz",
      "indices" : [ 0, 10 ],
      "id_str" : "380189226",
      "id" : 380189226
    }, {
      "name" : "Ben Ward",
      "screen_name" : "BenWard",
      "indices" : [ 11, 19 ],
      "id_str" : "12249",
      "id" : 12249
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "286366604730699778",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 39.76191475782994, -75.50821792806596 ]
  },
  "id_str" : "286480244137918465",
  "in_reply_to_user_id" : 380189226,
  "text" : "@alexduloz @benward Exciting!",
  "id" : 286480244137918465,
  "in_reply_to_status_id" : 286366604730699778,
  "created_at" : "Wed Jan 02 14:33:07 +0000 2013",
  "in_reply_to_screen_name" : "alexduloz",
  "in_reply_to_user_id_str" : "380189226",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Monica Guzman",
      "screen_name" : "moniguzman",
      "indices" : [ 0, 11 ],
      "id_str" : "3452941",
      "id" : 3452941
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "286364856674836480",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 39.76211979057617, -75.50821948803542 ]
  },
  "id_str" : "286480151729020929",
  "in_reply_to_user_id" : 3452941,
  "text" : "@moniguzman I ran into the owner of this handle on my first day there and it wasn't his primary account... got lucky!",
  "id" : 286480151729020929,
  "in_reply_to_status_id" : 286364856674836480,
  "created_at" : "Wed Jan 02 14:32:45 +0000 2013",
  "in_reply_to_screen_name" : "moniguzman",
  "in_reply_to_user_id_str" : "3452941",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Monica Guzman",
      "screen_name" : "moniguzman",
      "indices" : [ 0, 11 ],
      "id_str" : "3452941",
      "id" : 3452941
    }, {
      "name" : "Jason Preston",
      "screen_name" : "jasonp",
      "indices" : [ 12, 19 ],
      "id_str" : "4131861",
      "id" : 4131861
    }, {
      "name" : "Kevin Kelly",
      "screen_name" : "kevin2kelly",
      "indices" : [ 61, 73 ],
      "id_str" : "1532061",
      "id" : 1532061
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "286364636238970881",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 39.762120503, -75.508207921 ]
  },
  "id_str" : "286479917326143488",
  "in_reply_to_user_id" : 3452941,
  "text" : "@moniguzman @jasonp Yes, it's from What Technology Wants, by @kevin2kelly and it's a great book.",
  "id" : 286479917326143488,
  "in_reply_to_status_id" : 286364636238970881,
  "created_at" : "Wed Jan 02 14:31:49 +0000 2013",
  "in_reply_to_screen_name" : "moniguzman",
  "in_reply_to_user_id_str" : "3452941",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Arrington",
      "screen_name" : "arrington",
      "indices" : [ 3, 13 ],
      "id_str" : "37570179",
      "id" : 37570179
    }, {
      "name" : "TechCrunch",
      "screen_name" : "TechCrunch",
      "indices" : [ 87, 98 ],
      "id_str" : "816653",
      "id" : 816653
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 82 ],
      "url" : "http://t.co/pMsstmHd",
      "expanded_url" : "http://techcrunch.com/2013/01/01/the-income-rich-take-one-for-the-team-thanks/",
      "display_url" : "techcrunch.com/2013/01/01/the…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "286359615065706496",
  "text" : "RT @arrington: The Income Rich Take One For The Team. Thanks! http://t.co/pMsstmHd via @techcrunch",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "TechCrunch",
        "screen_name" : "TechCrunch",
        "indices" : [ 72, 83 ],
        "id_str" : "816653",
        "id" : 816653
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 47, 67 ],
        "url" : "http://t.co/pMsstmHd",
        "expanded_url" : "http://techcrunch.com/2013/01/01/the-income-rich-take-one-for-the-team-thanks/",
        "display_url" : "techcrunch.com/2013/01/01/the…"
      } ]
    },
    "geo" : {
    },
    "id_str" : "286357560431366144",
    "text" : "The Income Rich Take One For The Team. Thanks! http://t.co/pMsstmHd via @techcrunch",
    "id" : 286357560431366144,
    "created_at" : "Wed Jan 02 06:25:37 +0000 2013",
    "user" : {
      "name" : "Michael Arrington",
      "screen_name" : "arrington",
      "protected" : false,
      "id_str" : "37570179",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2627517802/7qn56y8h9o38nfvqmh74_normal.png",
      "id" : 37570179,
      "verified" : true
    }
  },
  "id" : 286359615065706496,
  "created_at" : "Wed Jan 02 06:33:47 +0000 2013",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Monica Guzman",
      "screen_name" : "moniguzman",
      "indices" : [ 3, 14 ],
      "id_str" : "3452941",
      "id" : 3452941
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 81 ],
      "url" : "http://t.co/qinYyXOk",
      "expanded_url" : "http://bit.ly/Ul3o56",
      "display_url" : "bit.ly/Ul3o56"
    } ]
  },
  "geo" : {
  },
  "id_str" : "286358406816735234",
  "text" : "RT @moniguzman: Why is there no good synonym for technology? http://t.co/qinYyXOk",
  "retweeted_status" : {
    "source" : "<a href=\"http://ifttt.com\" rel=\"nofollow\">IFTTT</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 45, 65 ],
        "url" : "http://t.co/qinYyXOk",
        "expanded_url" : "http://bit.ly/Ul3o56",
        "display_url" : "bit.ly/Ul3o56"
      } ]
    },
    "geo" : {
    },
    "id_str" : "286356363557359616",
    "text" : "Why is there no good synonym for technology? http://t.co/qinYyXOk",
    "id" : 286356363557359616,
    "created_at" : "Wed Jan 02 06:20:51 +0000 2013",
    "user" : {
      "name" : "Monica Guzman",
      "screen_name" : "moniguzman",
      "protected" : false,
      "id_str" : "3452941",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2278622783/7bawi34jjnlztg26hljx_normal.jpeg",
      "id" : 3452941,
      "verified" : false
    }
  },
  "id" : 286358406816735234,
  "created_at" : "Wed Jan 02 06:28:59 +0000 2013",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Monica Guzman",
      "screen_name" : "moniguzman",
      "indices" : [ 0, 11 ],
      "id_str" : "3452941",
      "id" : 3452941
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "286356363557359616",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 39.76253760838934, -75.50810462528155 ]
  },
  "id_str" : "286358394812628992",
  "in_reply_to_user_id" : 3452941,
  "text" : "@moniguzman I like the anthropomorphicization (???) of technology: the Technium.",
  "id" : 286358394812628992,
  "in_reply_to_status_id" : 286356363557359616,
  "created_at" : "Wed Jan 02 06:28:56 +0000 2013",
  "in_reply_to_screen_name" : "moniguzman",
  "in_reply_to_user_id_str" : "3452941",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Levie",
      "screen_name" : "levie",
      "indices" : [ 3, 9 ],
      "id_str" : "914061",
      "id" : 914061
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "286330758380007426",
  "text" : "RT @levie: The US government's core competency at this point is averting self-created crises.",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "286329299714334720",
    "text" : "The US government's core competency at this point is averting self-created crises.",
    "id" : 286329299714334720,
    "created_at" : "Wed Jan 02 04:33:19 +0000 2013",
    "user" : {
      "name" : "Aaron Levie",
      "screen_name" : "levie",
      "protected" : false,
      "id_str" : "914061",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1626898956/twitter_normal.png",
      "id" : 914061,
      "verified" : false
    }
  },
  "id" : 286330758380007426,
  "created_at" : "Wed Jan 02 04:39:07 +0000 2013",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Raffi Krikorian",
      "screen_name" : "raffi",
      "indices" : [ 3, 9 ],
      "id_str" : "8285392",
      "id" : 8285392
    }, {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 57, 65 ],
      "id_str" : "783214",
      "id" : 783214
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 130 ],
      "url" : "http://t.co/FSu0ckfC",
      "expanded_url" : "http://blog.twitter.com/2013/01/celebrating-2013-in-global-town-square.html",
      "display_url" : "blog.twitter.com/2013/01/celebr…"
    } ]
  },
  "geo" : {
  },
  "id_str" : "286325844870320128",
  "text" : "RT @raffi: users sent almost 34k tweets / second through @twitter when tokyo hit midnight on new year's eve → http://t.co/FSu0ckfC http: ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Twitter",
        "screen_name" : "twitter",
        "indices" : [ 46, 54 ],
        "id_str" : "783214",
        "id" : 783214
      } ],
      "media" : [ {
        "expanded_url" : "http://twitter.com/raffi/status/286320673440276482/photo/1",
        "indices" : [ 120, 140 ],
        "url" : "http://t.co/6iAg9yqx",
        "media_url" : "http://pbs.twimg.com/media/A_k3IrDCIAEMXqO.png",
        "id_str" : "286320673448665089",
        "id" : 286320673448665089,
        "media_url_https" : "https://pbs.twimg.com/media/A_k3IrDCIAEMXqO.png",
        "sizes" : [ {
          "h" : 794,
          "resize" : "fit",
          "w" : 793
        }, {
          "h" : 794,
          "resize" : "fit",
          "w" : 793
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 601,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com/6iAg9yqx"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 99, 119 ],
        "url" : "http://t.co/FSu0ckfC",
        "expanded_url" : "http://blog.twitter.com/2013/01/celebrating-2013-in-global-town-square.html",
        "display_url" : "blog.twitter.com/2013/01/celebr…"
      } ]
    },
    "geo" : {
    },
    "id_str" : "286320673440276482",
    "text" : "users sent almost 34k tweets / second through @twitter when tokyo hit midnight on new year's eve → http://t.co/FSu0ckfC http://t.co/6iAg9yqx",
    "id" : 286320673440276482,
    "created_at" : "Wed Jan 02 03:59:03 +0000 2013",
    "user" : {
      "name" : "Raffi Krikorian",
      "screen_name" : "raffi",
      "protected" : false,
      "id_str" : "8285392",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1270234259/raffi-headshot-casual_normal.png",
      "id" : 8285392,
      "verified" : false
    }
  },
  "id" : 286325844870320128,
  "created_at" : "Wed Jan 02 04:19:35 +0000 2013",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Edward Harran",
      "screen_name" : "edwardharran",
      "indices" : [ 0, 13 ],
      "id_str" : "9013032",
      "id" : 9013032
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "286322033099407360",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 39.7624113551, -75.5083872937 ]
  },
  "id_str" : "286325292367224832",
  "in_reply_to_user_id" : 9013032,
  "text" : "@edwardharran So true!",
  "id" : 286325292367224832,
  "in_reply_to_status_id" : 286322033099407360,
  "created_at" : "Wed Jan 02 04:17:24 +0000 2013",
  "in_reply_to_screen_name" : "edwardharran",
  "in_reply_to_user_id_str" : "9013032",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 64 ],
      "url" : "http://t.co/BFN0qrTQ",
      "expanded_url" : "http://flic.kr/p/dGDThw",
      "display_url" : "flic.kr/p/dGDThw"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 39.762166, -75.5085 ]
  },
  "id_str" : "286289351896358912",
  "text" : "8:36pm Knows all the words to all the books http://t.co/BFN0qrTQ",
  "id" : 286289351896358912,
  "created_at" : "Wed Jan 02 01:54:35 +0000 2013",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Everett",
      "screen_name" : "Mr_Scribbles",
      "indices" : [ 28, 41 ],
      "id_str" : "13106032",
      "id" : 13106032
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 63 ],
      "url" : "http://t.co/6fcBx2dI",
      "expanded_url" : "http://www.wired.com/design/2012/12/365-superheroes/?pid=1756&viewall=true",
      "display_url" : "wired.com/design/2012/12…"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 39.7621709189, -75.5085211662 ]
  },
  "id_str" : "286277655567929344",
  "text" : "A superhero a day, drawn by @mr_scribbles: http://t.co/6fcBx2dI",
  "id" : 286277655567929344,
  "created_at" : "Wed Jan 02 01:08:06 +0000 2013",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Ward",
      "screen_name" : "BenWard",
      "indices" : [ 0, 8 ],
      "id_str" : "12249",
      "id" : 12249
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "286270693002326016",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 39.76189323761329, -75.50826367604884 ]
  },
  "id_str" : "286272931535917059",
  "in_reply_to_user_id" : 12249,
  "text" : "@BenWard Maybe you should fork it and find 30 new people to do the challenge? I'd love to participate in something like that.",
  "id" : 286272931535917059,
  "in_reply_to_status_id" : 286270693002326016,
  "created_at" : "Wed Jan 02 00:49:20 +0000 2013",
  "in_reply_to_screen_name" : "BenWard",
  "in_reply_to_user_id_str" : "12249",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Berkun",
      "screen_name" : "berkun",
      "indices" : [ 3, 10 ],
      "id_str" : "30495974",
      "id" : 30495974
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 72 ],
      "url" : "http://t.co/zosoJOxE",
      "expanded_url" : "http://bit.ly/Ujfji9",
      "display_url" : "bit.ly/Ujfji9"
    } ]
  },
  "geo" : {
  },
  "id_str" : "286257785954512898",
  "text" : "RT @berkun: List of unsolved problems in philosophy http://t.co/zosoJOxE - Ironically doesn't include the problem of assuming every prob ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://bufferapp.com\" rel=\"nofollow\">Buffer</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 40, 60 ],
        "url" : "http://t.co/zosoJOxE",
        "expanded_url" : "http://bit.ly/Ujfji9",
        "display_url" : "bit.ly/Ujfji9"
      } ]
    },
    "geo" : {
    },
    "id_str" : "286255881782427648",
    "text" : "List of unsolved problems in philosophy http://t.co/zosoJOxE - Ironically doesn't include the problem of assuming every problem is solvable",
    "id" : 286255881782427648,
    "created_at" : "Tue Jan 01 23:41:35 +0000 2013",
    "user" : {
      "name" : "Scott Berkun",
      "screen_name" : "berkun",
      "protected" : false,
      "id_str" : "30495974",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1650114946/gravatar_normal.png",
      "id" : 30495974,
      "verified" : false
    }
  },
  "id" : 286257785954512898,
  "created_at" : "Tue Jan 01 23:49:09 +0000 2013",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 42 ],
      "url" : "http://t.co/pzcmqmZs",
      "expanded_url" : "http://flic.kr/p/dGy1d5",
      "display_url" : "flic.kr/p/dGy1d5"
    } ]
  },
  "geo" : {
  },
  "id_str" : "286212312942120961",
  "text" : "Hidden View back yard http://t.co/pzcmqmZs",
  "id" : 286212312942120961,
  "created_at" : "Tue Jan 01 20:48:27 +0000 2013",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagr.am\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 63 ],
      "url" : "http://t.co/wTVjoqge",
      "expanded_url" : "http://instagr.am/p/T89uBfo0EP/",
      "display_url" : "instagr.am/p/T89uBfo0EP/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.9790270467, -76.6098354244 ]
  },
  "id_str" : "286189846811250689",
  "text" : "Hidden View dining room @ Hidden View Farm http://t.co/wTVjoqge",
  "id" : 286189846811250689,
  "created_at" : "Tue Jan 01 19:19:11 +0000 2013",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
} ]