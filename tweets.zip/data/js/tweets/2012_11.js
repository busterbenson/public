Grailbird.data.tweets_2012_11 = 
 [ {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "274736918871289856",
  "text" : "Who's making holiday or end of year cards? What are your tricks???",
  "id" : 274736918871289856,
  "created_at" : "2012-12-01 04:49:20 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 111 ],
      "url" : "http://t.co/NMFlcwVU",
      "expanded_url" : "http://instagr.am/p/Srk6sFI0Dc/",
      "display_url" : "instagr.am/p/Srk6sFI0Dc/"
    } ]
  },
  "geo" : { },
  "id_str" : "274735376722186240",
  "text" : "8:36pm Niko tried to go to sleep on the couch but he couldn't stop cracking up at the idea http://t.co/NMFlcwVU",
  "id" : 274735376722186240,
  "created_at" : "2012-12-01 04:43:12 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "heather quintal",
      "screen_name" : "heatherquintal",
      "indices" : [ 0, 15 ],
      "id_str" : "12761252",
      "id" : 12761252
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "274644089545322500",
  "geo" : { },
  "id_str" : "274656332156657664",
  "in_reply_to_user_id" : 12761252,
  "text" : "@heatherquintal I think technically yes they are the same but it's really about the attitude you have while making the wish. :)",
  "id" : 274656332156657664,
  "in_reply_to_status_id" : 274644089545322500,
  "created_at" : "2012-11-30 23:29:07 +0000",
  "in_reply_to_screen_name" : "heatherquintal",
  "in_reply_to_user_id_str" : "12761252",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Weiner",
      "screen_name" : "bweiner",
      "indices" : [ 0, 8 ],
      "id_str" : "787919",
      "id" : 787919
    }, {
      "name" : "kottke.org",
      "screen_name" : "kottke",
      "indices" : [ 80, 87 ],
      "id_str" : "14120215",
      "id" : 14120215
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "274623560495022081",
  "geo" : { },
  "id_str" : "274623773276266496",
  "in_reply_to_user_id" : 787919,
  "text" : "@bweiner You don't buy into the medium is the message, huh? Fair enough. :) /cc @kottke",
  "id" : 274623773276266496,
  "in_reply_to_status_id" : 274623560495022081,
  "created_at" : "2012-11-30 21:19:44 +0000",
  "in_reply_to_screen_name" : "bweiner",
  "in_reply_to_user_id_str" : "787919",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Weiner",
      "screen_name" : "bweiner",
      "indices" : [ 0, 8 ],
      "id_str" : "787919",
      "id" : 787919
    }, {
      "name" : "kottke.org",
      "screen_name" : "kottke",
      "indices" : [ 127, 134 ],
      "id_str" : "14120215",
      "id" : 14120215
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "274619782391791616",
  "geo" : { },
  "id_str" : "274621249492221952",
  "in_reply_to_user_id" : 787919,
  "text" : "@bweiner I don't think it's superficial at all. These tools help us express our identities, but don't contain it entirely. /cc @kottke",
  "id" : 274621249492221952,
  "in_reply_to_status_id" : 274619782391791616,
  "created_at" : "2012-11-30 21:09:42 +0000",
  "in_reply_to_screen_name" : "bweiner",
  "in_reply_to_user_id_str" : "787919",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kottke.org",
      "screen_name" : "kottke",
      "indices" : [ 23, 30 ],
      "id_str" : "14120215",
      "id" : 14120215
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 125 ],
      "url" : "http://t.co/t4OLNZ8O",
      "expanded_url" : "http://kottke.org/12/11/twitter-is-a-machine-for-continual-self-reinvention",
      "display_url" : "kottke.org/12/11/twitter-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "274611854322585602",
  "text" : "I like this theory. RT @kottke: Twitter is a machine for continual self-reinvention (and Facebook isn't) http://t.co/t4OLNZ8O",
  "id" : 274611854322585602,
  "created_at" : "2012-11-30 20:32:22 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Grover",
      "screen_name" : "samgrover",
      "indices" : [ 0, 10 ],
      "id_str" : "802112",
      "id" : 802112
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "274605395492876289",
  "geo" : { },
  "id_str" : "274609326168104960",
  "in_reply_to_user_id" : 802112,
  "text" : "@samgrover Haven't seen that in a long time... what was the theory?",
  "id" : 274609326168104960,
  "in_reply_to_status_id" : 274605395492876289,
  "created_at" : "2012-11-30 20:22:20 +0000",
  "in_reply_to_screen_name" : "samgrover",
  "in_reply_to_user_id_str" : "802112",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://bufferapp.com\" rel=\"nofollow\">Buffer</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "274605158871224320",
  "text" : "Acting competitively isn't the best way to win. It might be the safest short term play, but it hurts the long game.",
  "id" : 274605158871224320,
  "created_at" : "2012-11-30 20:05:46 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Williams",
      "screen_name" : "ev",
      "indices" : [ 3, 6 ],
      "id_str" : "20",
      "id" : 20
    }, {
      "name" : "Matt Haughey",
      "screen_name" : "mathowie",
      "indices" : [ 59, 68 ],
      "id_str" : "761975",
      "id" : 761975
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 92 ],
      "url" : "https://t.co/cVLWfD8K",
      "expanded_url" : "https://medium.com/i-m-h-o/52a20d7a17de",
      "display_url" : "medium.com/i-m-h-o/52a20d\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "274597798014500864",
  "text" : "RT @ev: Why I love Twitter and barely tolerate Facebook by @mathowie: \nhttps://t.co/cVLWfD8K",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Matt Haughey",
        "screen_name" : "mathowie",
        "indices" : [ 51, 60 ],
        "id_str" : "761975",
        "id" : 761975
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 63, 84 ],
        "url" : "https://t.co/cVLWfD8K",
        "expanded_url" : "https://medium.com/i-m-h-o/52a20d7a17de",
        "display_url" : "medium.com/i-m-h-o/52a20d\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "274591343408467968",
    "text" : "Why I love Twitter and barely tolerate Facebook by @mathowie: \nhttps://t.co/cVLWfD8K",
    "id" : 274591343408467968,
    "created_at" : "2012-11-30 19:10:52 +0000",
    "user" : {
      "name" : "Evan Williams",
      "screen_name" : "ev",
      "protected" : false,
      "id_str" : "20",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3669523083/741b9ae8a443ce0a81646314871d2c00_normal.jpeg",
      "id" : 20,
      "verified" : true
    }
  },
  "id" : 274597798014500864,
  "created_at" : "2012-11-30 19:36:31 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ciaran Lyons",
      "screen_name" : "crayonlions",
      "indices" : [ 4, 16 ],
      "id_str" : "231087644",
      "id" : 231087644
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "274588233122324480",
  "text" : "Pay @crayonlions $1 for complaining about a really bad infographic on Mashable.",
  "id" : 274588233122324480,
  "created_at" : "2012-11-30 18:58:31 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jack Danger",
      "screen_name" : "jackdanger",
      "indices" : [ 0, 11 ],
      "id_str" : "3496901",
      "id" : 3496901
    }, {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 28, 36 ],
      "id_str" : "783214",
      "id" : 783214
    }, {
      "name" : "Square",
      "screen_name" : "Square",
      "indices" : [ 65, 72 ],
      "id_str" : "93017945",
      "id" : 93017945
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "274583182987370496",
  "geo" : { },
  "id_str" : "274584677828931584",
  "in_reply_to_user_id" : 3496901,
  "text" : "@jackdanger Just started at @Twitter a couple months ago. I love @Square, too.",
  "id" : 274584677828931584,
  "in_reply_to_status_id" : 274583182987370496,
  "created_at" : "2012-11-30 18:44:23 +0000",
  "in_reply_to_screen_name" : "jackdanger",
  "in_reply_to_user_id_str" : "3496901",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zack Shapiro",
      "screen_name" : "ZackShapiro",
      "indices" : [ 12, 24 ],
      "id_str" : "15999465",
      "id" : 15999465
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 138 ],
      "url" : "https://t.co/zY95V90T",
      "expanded_url" : "https://github.com/zackshapiro/thoughts/blob/master/things-that-i-believe.md",
      "display_url" : "github.com/zackshapiro/th\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "274584334067982336",
  "text" : "Awesome! MT @ZackShapiro: After a day of edits and some more thought on it, here's my \"Things I believe to be true.\" https://t.co/zY95V90T",
  "id" : 274584334067982336,
  "created_at" : "2012-11-30 18:43:01 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jack Danger",
      "screen_name" : "jackdanger",
      "indices" : [ 0, 11 ],
      "id_str" : "3496901",
      "id" : 3496901
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "274571036626927616",
  "geo" : { },
  "id_str" : "274571807670009856",
  "in_reply_to_user_id" : 3496901,
  "text" : "@jackdanger Thanks!",
  "id" : 274571807670009856,
  "in_reply_to_status_id" : 274571036626927616,
  "created_at" : "2012-11-30 17:53:14 +0000",
  "in_reply_to_screen_name" : "jackdanger",
  "in_reply_to_user_id_str" : "3496901",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rand Fishkin",
      "screen_name" : "randfish",
      "indices" : [ 3, 12 ],
      "id_str" : "6527972",
      "id" : 6527972
    }, {
      "name" : "Zaarly",
      "screen_name" : "zaarly",
      "indices" : [ 21, 28 ],
      "id_str" : "254690342",
      "id" : 254690342
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 81 ],
      "url" : "https://t.co/WSatt1CX",
      "expanded_url" : "https://www.zaarly.com/adana",
      "display_url" : "zaarly.com/adana"
    } ]
  },
  "geo" : { },
  "id_str" : "274568678811504640",
  "text" : "RT @randfish: Sweet! @zaarly Seattle launches w/ folks like https://t.co/WSatt1CX (will bring you homebaked stuff) &amp; https://t.co/IO ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Zaarly",
        "screen_name" : "zaarly",
        "indices" : [ 7, 14 ],
        "id_str" : "254690342",
        "id" : 254690342
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 46, 67 ],
        "url" : "https://t.co/WSatt1CX",
        "expanded_url" : "https://www.zaarly.com/adana",
        "display_url" : "zaarly.com/adana"
      }, {
        "indices" : [ 107, 128 ],
        "url" : "https://t.co/IOinSLCi",
        "expanded_url" : "https://www.zaarly.com/nathankaiser",
        "display_url" : "zaarly.com/nathankaiser"
      } ]
    },
    "geo" : { },
    "id_str" : "274562842177454080",
    "text" : "Sweet! @zaarly Seattle launches w/ folks like https://t.co/WSatt1CX (will bring you homebaked stuff) &amp; https://t.co/IOinSLCi (distillery!)",
    "id" : 274562842177454080,
    "created_at" : "2012-11-30 17:17:37 +0000",
    "user" : {
      "name" : "Rand Fishkin",
      "screen_name" : "randfish",
      "protected" : false,
      "id_str" : "6527972",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1870530709/randfish-500px_normal.jpg",
      "id" : 6527972,
      "verified" : true
    }
  },
  "id" : 274568678811504640,
  "created_at" : "2012-11-30 17:40:48 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 50 ],
      "url" : "http://t.co/YN4HKVaw",
      "expanded_url" : "http://flic.kr/p/dxjZ2p",
      "display_url" : "flic.kr/p/dxjZ2p"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.608666, -122.306334 ]
  },
  "id_str" : "274372890009432064",
  "text" : "8:36pm Reading Cat in the Hat http://t.co/YN4HKVaw",
  "id" : 274372890009432064,
  "created_at" : "2012-11-30 04:42:49 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Gordon",
      "screen_name" : "JeremySF",
      "indices" : [ 0, 9 ],
      "id_str" : "19872718",
      "id" : 19872718
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "274349996806127616",
  "geo" : { },
  "id_str" : "274367488920268800",
  "in_reply_to_user_id" : 19872718,
  "text" : "@JeremySF I think so too but I'll report back after those said few hours.",
  "id" : 274367488920268800,
  "in_reply_to_status_id" : 274349996806127616,
  "created_at" : "2012-11-30 04:21:21 +0000",
  "in_reply_to_screen_name" : "JeremySF",
  "in_reply_to_user_id_str" : "19872718",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 57 ],
      "url" : "http://t.co/q6pwPaJo",
      "expanded_url" : "http://instagr.am/p/So8SXCo0Fl/",
      "display_url" : "instagr.am/p/So8SXCo0Fl/"
    } ]
  },
  "geo" : { },
  "id_str" : "274364411479748608",
  "text" : "Flying squirrels down the shoe aisle http://t.co/q6pwPaJo",
  "id" : 274364411479748608,
  "created_at" : "2012-11-30 04:09:07 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.branch.com\" rel=\"nofollow\">Branch Inc</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tully Hansen",
      "screen_name" : "tullyhansen",
      "indices" : [ 0, 12 ],
      "id_str" : "12341222",
      "id" : 12341222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 113 ],
      "url" : "http://t.co/pn3EFpIh",
      "expanded_url" : "http://branch.com/b/what-would-you-write-in-your-codex-vitae?showsignin=true&inviter=Buster%20Benson",
      "display_url" : "branch.com/b/what-would-y\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "274205468874928128",
  "in_reply_to_user_id" : 12341222,
  "text" : "@tullyhansen I just added you to my branch about \u201CWhat would you write in your codex vitae?\u201D http://t.co/pn3EFpIh",
  "id" : 274205468874928128,
  "created_at" : "2012-11-29 17:37:32 +0000",
  "in_reply_to_screen_name" : "tullyhansen",
  "in_reply_to_user_id_str" : "12341222",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tully Hansen",
      "screen_name" : "tullyhansen",
      "indices" : [ 0, 12 ],
      "id_str" : "12341222",
      "id" : 12341222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "274127060593684481",
  "geo" : { },
  "id_str" : "274205308115632128",
  "in_reply_to_user_id" : 12341222,
  "text" : "@tullyhansen Awesome. I'll invite you to the branch discussion about it in a second.",
  "id" : 274205308115632128,
  "in_reply_to_status_id" : 274127060593684481,
  "created_at" : "2012-11-29 17:36:54 +0000",
  "in_reply_to_screen_name" : "tullyhansen",
  "in_reply_to_user_id_str" : "12341222",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alena Dorokhina",
      "screen_name" : "AlenaDorokhina",
      "indices" : [ 0, 15 ],
      "id_str" : "490571707",
      "id" : 490571707
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "274171189541359616",
  "geo" : { },
  "id_str" : "274205060723003392",
  "in_reply_to_user_id" : 490571707,
  "text" : "@AlenaDorokhina You should! I just invited you to the branch discussion about it and would love to hear thoughts.",
  "id" : 274205060723003392,
  "in_reply_to_status_id" : 274171189541359616,
  "created_at" : "2012-11-29 17:35:55 +0000",
  "in_reply_to_screen_name" : "AlenaDorokhina",
  "in_reply_to_user_id_str" : "490571707",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.branch.com\" rel=\"nofollow\">Branch Inc</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alena Dorokhina",
      "screen_name" : "AlenaDorokhina",
      "indices" : [ 0, 15 ],
      "id_str" : "490571707",
      "id" : 490571707
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 116 ],
      "url" : "http://t.co/pn3EFpIh",
      "expanded_url" : "http://branch.com/b/what-would-you-write-in-your-codex-vitae?showsignin=true&inviter=Buster%20Benson",
      "display_url" : "branch.com/b/what-would-y\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "274204441270419456",
  "in_reply_to_user_id" : 490571707,
  "text" : "@Alenadorokhina I just added you to my branch about \u201CWhat would you write in your codex vitae?\u201D http://t.co/pn3EFpIh",
  "id" : 274204441270419456,
  "created_at" : "2012-11-29 17:33:27 +0000",
  "in_reply_to_screen_name" : "AlenaDorokhina",
  "in_reply_to_user_id_str" : "490571707",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DJ",
      "screen_name" : "Designbyjd",
      "indices" : [ 0, 11 ],
      "id_str" : "1673907438",
      "id" : 1673907438
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "274180871085514752",
  "geo" : { },
  "id_str" : "274204089406066690",
  "in_reply_to_user_id" : 262187645,
  "text" : "@designbyjd Great! I added you to the branch discussion about it. Check your dms.",
  "id" : 274204089406066690,
  "in_reply_to_status_id" : 274180871085514752,
  "created_at" : "2012-11-29 17:32:04 +0000",
  "in_reply_to_screen_name" : "jasondemeuse",
  "in_reply_to_user_id_str" : "262187645",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://bufferapp.com\" rel=\"nofollow\">Buffer</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robin Sloan",
      "screen_name" : "robinsloan",
      "indices" : [ 101, 112 ],
      "id_str" : "13919072",
      "id" : 13919072
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 96 ],
      "url" : "http://t.co/WUNWwRkw",
      "expanded_url" : "http://bit.ly/Tv8UDu",
      "display_url" : "bit.ly/Tv8UDu"
    } ]
  },
  "geo" : { },
  "id_str" : "274203221139021825",
  "text" : "What would you put in your codex vitae (everything you've learned in life)? http://t.co/WUNWwRkw /cc @robinsloan",
  "id" : 274203221139021825,
  "created_at" : "2012-11-29 17:28:37 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zack Shapiro",
      "screen_name" : "ZackShapiro",
      "indices" : [ 0, 12 ],
      "id_str" : "15999465",
      "id" : 15999465
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "274038957895983104",
  "geo" : { },
  "id_str" : "274049971739828224",
  "in_reply_to_user_id" : 15999465,
  "text" : "@ZackShapiro Do it! Adding you to a branch about it too.",
  "id" : 274049971739828224,
  "in_reply_to_status_id" : 274038957895983104,
  "created_at" : "2012-11-29 07:19:39 +0000",
  "in_reply_to_screen_name" : "ZackShapiro",
  "in_reply_to_user_id_str" : "15999465",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.branch.com\" rel=\"nofollow\">Branch Inc</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robin Sloan",
      "screen_name" : "robinsloan",
      "indices" : [ 0, 11 ],
      "id_str" : "13919072",
      "id" : 13919072
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 112 ],
      "url" : "http://t.co/pn3EFpIh",
      "expanded_url" : "http://branch.com/b/what-would-you-write-in-your-codex-vitae?showsignin=true&inviter=Buster%20Benson",
      "display_url" : "branch.com/b/what-would-y\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "274049152126697472",
  "in_reply_to_user_id" : 13919072,
  "text" : "@robinsloan I just added you to my branch about \u201CWhat would you write in your codex vitae?\u201D http://t.co/pn3EFpIh",
  "id" : 274049152126697472,
  "created_at" : "2012-11-29 07:16:24 +0000",
  "in_reply_to_screen_name" : "robinsloan",
  "in_reply_to_user_id_str" : "13919072",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Mederos",
      "screen_name" : "pvm",
      "indices" : [ 0, 4 ],
      "id_str" : "76852610",
      "id" : 76852610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "274023146573688832",
  "geo" : { },
  "id_str" : "274023738440298496",
  "in_reply_to_user_id" : 76852610,
  "text" : "@pvm If you do, let me know! Trying to start a trend here. :)",
  "id" : 274023738440298496,
  "in_reply_to_status_id" : 274023146573688832,
  "created_at" : "2012-11-29 05:35:25 +0000",
  "in_reply_to_screen_name" : "pvm",
  "in_reply_to_user_id_str" : "76852610",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 56 ],
      "url" : "http://t.co/LxG4KQAv",
      "expanded_url" : "http://bit.ly/V4GeO0",
      "display_url" : "bit.ly/V4GeO0"
    } ]
  },
  "geo" : { },
  "id_str" : "274021841440481281",
  "text" : "Just updated my public belief file: http://t.co/LxG4KQAv",
  "id" : 274021841440481281,
  "created_at" : "2012-11-29 05:27:52 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robin Sloan",
      "screen_name" : "robinsloan",
      "indices" : [ 26, 37 ],
      "id_str" : "13919072",
      "id" : 13919072
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 135 ],
      "url" : "http://t.co/tj8OEMhG",
      "expanded_url" : "http://bit.ly/Rk6Ijh",
      "display_url" : "bit.ly/Rk6Ijh"
    } ]
  },
  "geo" : { },
  "id_str" : "274021601723416576",
  "text" : "One of my fave ideas from @robinsloan's Penumbra was the idea of a Codex Vitae. I've sort of been working on mine: http://t.co/tj8OEMhG",
  "id" : 274021601723416576,
  "created_at" : "2012-11-29 05:26:55 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Gordon",
      "screen_name" : "JeremySF",
      "indices" : [ 29, 38 ],
      "id_str" : "19872718",
      "id" : 19872718
    }, {
      "name" : "Michael Sippey",
      "screen_name" : "sippey",
      "indices" : [ 43, 50 ],
      "id_str" : "4711",
      "id" : 4711
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 102 ],
      "url" : "http://t.co/uWQ5lDOl",
      "expanded_url" : "http://flic.kr/p/dxbMGQ",
      "display_url" : "flic.kr/p/dxbMGQ"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.613166, -122.385 ]
  },
  "id_str" : "274011493106855936",
  "text" : "8:36pm Reading \"Inspired\" on @jeremysf and @sippey's recommendation. Good so far! http://t.co/uWQ5lDOl",
  "id" : 274011493106855936,
  "created_at" : "2012-11-29 04:46:45 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/buster/status/274002355534577664/photo/1",
      "indices" : [ 111, 131 ],
      "url" : "http://t.co/sEGy4Dd9",
      "media_url" : "http://pbs.twimg.com/media/A81zsM3CQAAuCI2.jpg",
      "id_str" : "274002355542966272",
      "id" : 274002355542966272,
      "media_url_https" : "https://pbs.twimg.com/media/A81zsM3CQAAuCI2.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com/sEGy4Dd9"
    } ],
    "hashtags" : [ {
      "text" : "goodparenting",
      "indices" : [ 96, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "274002355534577664",
  "text" : "Bought a crappy $21 airport gift for Niko. But only because he loves even the crappiest things. #goodparenting http://t.co/sEGy4Dd9",
  "id" : 274002355534577664,
  "created_at" : "2012-11-29 04:10:27 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "k.",
      "screen_name" : "kstar",
      "indices" : [ 9, 15 ],
      "id_str" : "2038",
      "id" : 2038
    }, {
      "name" : "Sachin Agarwal",
      "screen_name" : "agarwal",
      "indices" : [ 30, 38 ],
      "id_str" : "15105000",
      "id" : 15105000
    }, {
      "name" : "Prasanna Srikhanta",
      "screen_name" : "prasanna",
      "indices" : [ 106, 115 ],
      "id_str" : "5626",
      "id" : 5626
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "273996391532072960",
  "text" : "Mine was @kstar. Hi Karen! RT @agarwal: Who is the first person you ever followed on Twitter? For me it's @prasanna",
  "id" : 273996391532072960,
  "created_at" : "2012-11-29 03:46:45 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jimmy Jacobson",
      "screen_name" : "jimmyjacobson",
      "indices" : [ 0, 14 ],
      "id_str" : "17545050",
      "id" : 17545050
    }, {
      "name" : "Patrick Moberg",
      "screen_name" : "patrickmoberg",
      "indices" : [ 15, 29 ],
      "id_str" : "4102571",
      "id" : 4102571
    }, {
      "name" : "Banters",
      "screen_name" : "bantersapp",
      "indices" : [ 30, 41 ],
      "id_str" : "151596299",
      "id" : 151596299
    }, {
      "name" : "Findings",
      "screen_name" : "findings",
      "indices" : [ 42, 51 ],
      "id_str" : "208197274",
      "id" : 208197274
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "273941428802027521",
  "geo" : { },
  "id_str" : "273969403966681088",
  "in_reply_to_user_id" : 17545050,
  "text" : "@jimmyjacobson @patrickmoberg @bantersapp @findings I haven't! Send me an example?",
  "id" : 273969403966681088,
  "in_reply_to_status_id" : 273941428802027521,
  "created_at" : "2012-11-29 01:59:30 +0000",
  "in_reply_to_screen_name" : "jimmyjacobson",
  "in_reply_to_user_id_str" : "17545050",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jimmy Jacobson",
      "screen_name" : "jimmyjacobson",
      "indices" : [ 0, 14 ],
      "id_str" : "17545050",
      "id" : 17545050
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 135 ],
      "url" : "http://t.co/RleNBCp9",
      "expanded_url" : "http://bit.ly/QnpTTa",
      "display_url" : "bit.ly/QnpTTa"
    } ]
  },
  "in_reply_to_status_id_str" : "273912582530818048",
  "geo" : { },
  "id_str" : "273912806435344385",
  "in_reply_to_user_id" : 17545050,
  "text" : "@jimmyjacobson Just happens to be my team now. I can definitely help with any questions. Wrote some ideas up here: http://t.co/RleNBCp9",
  "id" : 273912806435344385,
  "in_reply_to_status_id" : 273912582530818048,
  "created_at" : "2012-11-28 22:14:36 +0000",
  "in_reply_to_screen_name" : "jimmyjacobson",
  "in_reply_to_user_id_str" : "17545050",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jimmy Jacobson",
      "screen_name" : "jimmyjacobson",
      "indices" : [ 0, 14 ],
      "id_str" : "17545050",
      "id" : 17545050
    }, {
      "name" : "wedgies",
      "screen_name" : "wedgies",
      "indices" : [ 39, 47 ],
      "id_str" : "273796045",
      "id" : 273796045
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 135 ],
      "url" : "http://t.co/WWtqey07",
      "expanded_url" : "http://bit.ly/UIuaXQ",
      "display_url" : "bit.ly/UIuaXQ"
    } ]
  },
  "in_reply_to_status_id_str" : "273907100499984384",
  "geo" : { },
  "id_str" : "273911623767437312",
  "in_reply_to_user_id" : 17545050,
  "text" : "@jimmyjacobson Ooh, yeah, it's totally @wedgies. Have you thought about creating a Twitter Card for these surveys? http://t.co/WWtqey07",
  "id" : 273911623767437312,
  "in_reply_to_status_id" : 273907100499984384,
  "created_at" : "2012-11-28 22:09:54 +0000",
  "in_reply_to_screen_name" : "jimmyjacobson",
  "in_reply_to_user_id_str" : "17545050",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wall Street Journal",
      "screen_name" : "WSJ",
      "indices" : [ 24, 28 ],
      "id_str" : "3108351",
      "id" : 3108351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 108 ],
      "url" : "http://t.co/Y6n5Q0rt",
      "expanded_url" : "http://on.wsj.com/UWm1fa",
      "display_url" : "on.wsj.com/UWm1fa"
    }, {
      "indices" : [ 116, 136 ],
      "url" : "http://t.co/ylPwkvZE",
      "expanded_url" : "http://on.wsj.com/TrZ1Xh",
      "display_url" : "on.wsj.com/TrZ1Xh"
    } ]
  },
  "geo" : { },
  "id_str" : "273904731401891841",
  "text" : "Cool tweet poll idea RT @WSJ: Should the U.S. replace $1 notes with $1 coins? Vote YES: http://t.co/Y6n5Q0rt or NO: http://t.co/ylPwkvZE",
  "id" : 273904731401891841,
  "created_at" : "2012-11-28 21:42:31 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Smith",
      "screen_name" : "BuzzFeedBen",
      "indices" : [ 3, 15 ],
      "id_str" : "9532402",
      "id" : 9532402
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 86 ],
      "url" : "http://t.co/6VEeIVDA",
      "expanded_url" : "http://www.buzzfeed.com/daves4/the-best-memes-of-2012",
      "display_url" : "buzzfeed.com/daves4/the-bes\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "273894292693585920",
  "text" : "RT @BuzzFeedBen: 2012 is \"the year the meme went mega-mainstream\" http://t.co/6VEeIVDA",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 49, 69 ],
        "url" : "http://t.co/6VEeIVDA",
        "expanded_url" : "http://www.buzzfeed.com/daves4/the-best-memes-of-2012",
        "display_url" : "buzzfeed.com/daves4/the-bes\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "273849028586917888",
    "text" : "2012 is \"the year the meme went mega-mainstream\" http://t.co/6VEeIVDA",
    "id" : 273849028586917888,
    "created_at" : "2012-11-28 18:01:10 +0000",
    "user" : {
      "name" : "Ben Smith",
      "screen_name" : "BuzzFeedBen",
      "protected" : false,
      "id_str" : "9532402",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3308219203/61a1772ff3467946cb616997933100d5_normal.jpeg",
      "id" : 9532402,
      "verified" : true
    }
  },
  "id" : 273894292693585920,
  "created_at" : "2012-11-28 21:01:02 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.apple.com\" rel=\"nofollow\">Safari on iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GeekWire",
      "screen_name" : "geekwire",
      "indices" : [ 41, 50 ],
      "id_str" : "255784266",
      "id" : 255784266
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 72 ],
      "url" : "http://t.co/gM5fHKqH",
      "expanded_url" : "http://www.geekwire.com/2012/amazon-web-services-andy-jassy-build-paternal-service/#utm_source=GeekWire+Daily+Digest&utm_medium=email&utm_campaign=9c0c3e8c41-daily-digest-email",
      "display_url" : "geekwire.com/2012/amazon-we\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "273892011076112384",
  "text" : "I would hate to compete with Amazon /via @geekwire  http://t.co/gM5fHKqH",
  "id" : 273892011076112384,
  "created_at" : "2012-11-28 20:51:58 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vizify",
      "screen_name" : "vizify",
      "indices" : [ 9, 16 ],
      "id_str" : "295513152",
      "id" : 295513152
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http://t.co/l2bjO9iS",
      "expanded_url" : "http://ow.ly/fyaFi",
      "display_url" : "ow.ly/fyaFi"
    } ]
  },
  "geo" : { },
  "id_str" : "273887928000868352",
  "text" : "Woah. RT @vizify: Very neat: an album that mutates every time you listen to it, so it's never the same thing twice: http://t.co/l2bjO9iS",
  "id" : 273887928000868352,
  "created_at" : "2012-11-28 20:35:45 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Crocker",
      "screen_name" : "nickcrocker",
      "indices" : [ 0, 12 ],
      "id_str" : "30801469",
      "id" : 30801469
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "273887232413270016",
  "geo" : { },
  "id_str" : "273887596759875584",
  "in_reply_to_user_id" : 30801469,
  "text" : "@nickcrocker That made me laugh.",
  "id" : 273887596759875584,
  "in_reply_to_status_id" : 273887232413270016,
  "created_at" : "2012-11-28 20:34:26 +0000",
  "in_reply_to_screen_name" : "nickcrocker",
  "in_reply_to_user_id_str" : "30801469",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Wright",
      "screen_name" : "webwright",
      "indices" : [ 0, 10 ],
      "id_str" : "786818",
      "id" : 786818
    }, {
      "name" : "dustin curtis",
      "screen_name" : "dcurtis",
      "indices" : [ 39, 47 ],
      "id_str" : "9395832",
      "id" : 9395832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "273845021764091906",
  "geo" : { },
  "id_str" : "273845253553938433",
  "in_reply_to_user_id" : 786818,
  "text" : "@webwright Oh yeah, that IS weird. /cc @dcurtis",
  "id" : 273845253553938433,
  "in_reply_to_status_id" : 273845021764091906,
  "created_at" : "2012-11-28 17:46:10 +0000",
  "in_reply_to_screen_name" : "webwright",
  "in_reply_to_user_id_str" : "786818",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 35 ],
      "url" : "http://t.co/SpjyBjZP",
      "expanded_url" : "http://svbtle.com",
      "display_url" : "svbtle.com"
    } ]
  },
  "geo" : { },
  "id_str" : "273844027252670464",
  "text" : "Liking the new http://t.co/SpjyBjZP home page.",
  "id" : 273844027252670464,
  "created_at" : "2012-11-28 17:41:18 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NextTechBlog",
      "screen_name" : "NextTechBlog",
      "indices" : [ 32, 45 ],
      "id_str" : "386039091",
      "id" : 386039091
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "273840450719346689",
  "text" : "I love my favorite interests RT @NextTechBlog: New App Provides Real-Time Shared Streams Of Your Favorite Interests",
  "id" : 273840450719346689,
  "created_at" : "2012-11-28 17:27:05 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jane McGonigal",
      "screen_name" : "avantgame",
      "indices" : [ 0, 10 ],
      "id_str" : "681813",
      "id" : 681813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "273835992950116352",
  "geo" : { },
  "id_str" : "273838474736574464",
  "in_reply_to_user_id" : 681813,
  "text" : "@avantgame I am! And I already have. Loved it!",
  "id" : 273838474736574464,
  "in_reply_to_status_id" : 273835992950116352,
  "created_at" : "2012-11-28 17:19:14 +0000",
  "in_reply_to_screen_name" : "avantgame",
  "in_reply_to_user_id_str" : "681813",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"https://path.com/\" rel=\"nofollow\">Path</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http://t.co/d1xAO0xD",
      "expanded_url" : "http://path.com/p/5ao1C",
      "display_url" : "path.com/p/5ao1C"
    } ]
  },
  "geo" : { },
  "id_str" : "273829769773207552",
  "text" : "Finished it. Was a nerd's Da Vince Code. What should I r... \u2013 Reading Mr. Penumbra's 24-Hour Bookstore by Robin Sloan \u2014 http://t.co/d1xAO0xD",
  "id" : 273829769773207552,
  "created_at" : "2012-11-28 16:44:39 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "273712516855656449",
  "text" : "I'm tired. What should I do?",
  "id" : 273712516855656449,
  "created_at" : "2012-11-28 08:58:44 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nacho Soto",
      "screen_name" : "NachoSoto",
      "indices" : [ 0, 10 ],
      "id_str" : "43915380",
      "id" : 43915380
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "273696988451729408",
  "geo" : { },
  "id_str" : "273708090254299136",
  "in_reply_to_user_id" : 43915380,
  "text" : "@NachoSoto yup!",
  "id" : 273708090254299136,
  "in_reply_to_status_id" : 273696988451729408,
  "created_at" : "2012-11-28 08:41:08 +0000",
  "in_reply_to_screen_name" : "NachoSoto",
  "in_reply_to_user_id_str" : "43915380",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 67 ],
      "url" : "http://t.co/pA8FyZ5Q",
      "expanded_url" : "http://4sq.com/Tk1kYR",
      "display_url" : "4sq.com/Tk1kYR"
    } ]
  },
  "geo" : { },
  "id_str" : "273600961514196992",
  "text" : "I want a pizza. An Una Pizza Napoletana pizza. http://t.co/pA8FyZ5Q",
  "id" : 273600961514196992,
  "created_at" : "2012-11-28 01:35:27 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Fitzgerald",
      "screen_name" : "magicandrew",
      "indices" : [ 24, 36 ],
      "id_str" : "2139211",
      "id" : 2139211
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "twitterfiction",
      "indices" : [ 42, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 128 ],
      "url" : "http://t.co/47te2BoZ",
      "expanded_url" : "http://blog.twitter.com/2012/11/twitter-fiction-festival-selections.html",
      "display_url" : "blog.twitter.com/2012/11/twitte\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "273527116937719808",
  "text" : "This is pretty cool. RT @magicandrew: The #twitterfiction Festival showcase selections have been announced: http://t.co/47te2BoZ",
  "id" : 273527116937719808,
  "created_at" : "2012-11-27 20:42:01 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John W. Solomon",
      "screen_name" : "JohnWrede",
      "indices" : [ 0, 10 ],
      "id_str" : "125733",
      "id" : 125733
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "272946574395600896",
  "geo" : { },
  "id_str" : "273492668779225088",
  "in_reply_to_user_id" : 125733,
  "text" : "@JohnWrede I'm here til tomorrow! Get a drink tonight?",
  "id" : 273492668779225088,
  "in_reply_to_status_id" : 272946574395600896,
  "created_at" : "2012-11-27 18:25:08 +0000",
  "in_reply_to_screen_name" : "JohnWrede",
  "in_reply_to_user_id_str" : "125733",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Pierce",
      "screen_name" : "jonpierce",
      "indices" : [ 0, 10 ],
      "id_str" : "186923",
      "id" : 186923
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "273456629377282048",
  "geo" : { },
  "id_str" : "273487798403747840",
  "in_reply_to_user_id" : 186923,
  "text" : "@jonpierce Nice meeting you too!",
  "id" : 273487798403747840,
  "in_reply_to_status_id" : 273456629377282048,
  "created_at" : "2012-11-27 18:05:46 +0000",
  "in_reply_to_screen_name" : "jonpierce",
  "in_reply_to_user_id_str" : "186923",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lane Becker",
      "screen_name" : "monstro",
      "indices" : [ 0, 8 ],
      "id_str" : "4030",
      "id" : 4030
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "273461064514019329",
  "geo" : { },
  "id_str" : "273469574186426368",
  "in_reply_to_user_id" : 4030,
  "text" : "@monstro I knew you would. Can't wait to learn more about it!",
  "id" : 273469574186426368,
  "in_reply_to_status_id" : 273461064514019329,
  "created_at" : "2012-11-27 16:53:21 +0000",
  "in_reply_to_screen_name" : "monstro",
  "in_reply_to_user_id_str" : "4030",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lane Becker",
      "screen_name" : "monstro",
      "indices" : [ 0, 8 ],
      "id_str" : "4030",
      "id" : 4030
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "273448189724590080",
  "geo" : { },
  "id_str" : "273455897899048960",
  "in_reply_to_user_id" : 4030,
  "text" : "@monstro Woah. Congrats!",
  "id" : 273455897899048960,
  "in_reply_to_status_id" : 273448189724590080,
  "created_at" : "2012-11-27 15:59:01 +0000",
  "in_reply_to_screen_name" : "monstro",
  "in_reply_to_user_id_str" : "4030",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 70 ],
      "url" : "http://t.co/awc44JYy",
      "expanded_url" : "http://flic.kr/p/dwzyeX",
      "display_url" : "flic.kr/p/dwzyeX"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.765333, -122.413167 ]
  },
  "id_str" : "273297737678741504",
  "text" : "8:36pm Going away party for Swiss Joe and Dagmar! http://t.co/awc44JYy",
  "id" : 273297737678741504,
  "created_at" : "2012-11-27 05:30:32 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anti-Buster",
      "screen_name" : "busterbenson",
      "indices" : [ 0, 13 ],
      "id_str" : "1024917050",
      "id" : 1024917050
    }, {
      "name" : "Brian Ellin",
      "screen_name" : "brianellin",
      "indices" : [ 14, 25 ],
      "id_str" : "26123649",
      "id" : 26123649
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "273183407415099394",
  "in_reply_to_user_id" : 2185,
  "text" : "@busterbenson @brianellin The next step in the plan would be to tell you whether or not your emails + tweets were in iambic pentameter.",
  "id" : 273183407415099394,
  "created_at" : "2012-11-26 21:56:14 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Ellin",
      "screen_name" : "brianellin",
      "indices" : [ 0, 11 ],
      "id_str" : "26123649",
      "id" : 26123649
    }, {
      "name" : "Ben Ward",
      "screen_name" : "benward",
      "indices" : [ 12, 20 ],
      "id_str" : "12249",
      "id" : 12249
    }, {
      "name" : "Shortmail",
      "screen_name" : "shortmail",
      "indices" : [ 81, 91 ],
      "id_str" : "28839008",
      "id" : 28839008
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "273178036772425729",
  "geo" : { },
  "id_str" : "273182100570640384",
  "in_reply_to_user_id" : 26123649,
  "text" : "@brianellin @BenWard I actually searched for that very labs plugin this weekend. @Shortmail just doesn't do it for me.",
  "id" : 273182100570640384,
  "in_reply_to_status_id" : 273178036772425729,
  "created_at" : "2012-11-26 21:51:02 +0000",
  "in_reply_to_screen_name" : "brianellin",
  "in_reply_to_user_id_str" : "26123649",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dagmita",
      "screen_name" : "dagmita",
      "indices" : [ 0, 8 ],
      "id_str" : "6006232",
      "id" : 6006232
    }, {
      "name" : "Brian Ellin",
      "screen_name" : "brianellin",
      "indices" : [ 26, 37 ],
      "id_str" : "26123649",
      "id" : 26123649
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "273119487077801985",
  "geo" : { },
  "id_str" : "273143659518623744",
  "in_reply_to_user_id" : 6006232,
  "text" : "@dagmita Oh, awesome! /cc @brianellin",
  "id" : 273143659518623744,
  "in_reply_to_status_id" : 273119487077801985,
  "created_at" : "2012-11-26 19:18:17 +0000",
  "in_reply_to_screen_name" : "dagmita",
  "in_reply_to_user_id_str" : "6006232",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "stephanie",
      "screen_name" : "stephaniekaloi",
      "indices" : [ 0, 15 ],
      "id_str" : "158484689",
      "id" : 158484689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "273112488738951168",
  "geo" : { },
  "id_str" : "273113006068617216",
  "in_reply_to_user_id" : 158484689,
  "text" : "@stephaniekaloi I sort of want them. And can use Niko as an excuse perhaps.",
  "id" : 273113006068617216,
  "in_reply_to_status_id" : 273112488738951168,
  "created_at" : "2012-11-26 17:16:29 +0000",
  "in_reply_to_screen_name" : "stephaniekaloi",
  "in_reply_to_user_id_str" : "158484689",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "273112331293192192",
  "text" : "BREAKING: SF is foggy. And my plane, still on the runway in Seattle, is afraid.",
  "id" : 273112331293192192,
  "created_at" : "2012-11-26 17:13:48 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "stephanie",
      "screen_name" : "stephaniekaloi",
      "indices" : [ 0, 15 ],
      "id_str" : "158484689",
      "id" : 158484689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "273085594224181250",
  "geo" : { },
  "id_str" : "273109677498314752",
  "in_reply_to_user_id" : 158484689,
  "text" : "@stephaniekaloi Ooh that sounds neat! What does it do?",
  "id" : 273109677498314752,
  "in_reply_to_status_id" : 273085594224181250,
  "created_at" : "2012-11-26 17:03:15 +0000",
  "in_reply_to_screen_name" : "stephaniekaloi",
  "in_reply_to_user_id_str" : "158484689",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://mobile.twitter.com\" rel=\"nofollow\">Mobile Web</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russell Dicker",
      "screen_name" : "rdicker",
      "indices" : [ 3, 11 ],
      "id_str" : "958581",
      "id" : 958581
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 120 ],
      "url" : "http://t.co/vBluMpjX",
      "expanded_url" : "http://cliffmass.blogspot.com/2012/11/triple-rainbow.html",
      "display_url" : "cliffmass.blogspot.com/2012/11/triple\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "273055820051271680",
  "text" : "RT @rdicker: Cliff Mass ruins the magic of the triple rainbow with pesky (but fascinating) science. http://t.co/vBluMpjX",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.apple.com/\" rel=\"nofollow\">OS X</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 87, 107 ],
        "url" : "http://t.co/vBluMpjX",
        "expanded_url" : "http://cliffmass.blogspot.com/2012/11/triple-rainbow.html",
        "display_url" : "cliffmass.blogspot.com/2012/11/triple\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "272763576597508096",
    "text" : "Cliff Mass ruins the magic of the triple rainbow with pesky (but fascinating) science. http://t.co/vBluMpjX",
    "id" : 272763576597508096,
    "created_at" : "2012-11-25 18:07:59 +0000",
    "user" : {
      "name" : "Russell Dicker",
      "screen_name" : "rdicker",
      "protected" : false,
      "id_str" : "958581",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/628176689/image_normal.jpg",
      "id" : 958581,
      "verified" : false
    }
  },
  "id" : 273055820051271680,
  "created_at" : "2012-11-26 13:29:15 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amelia Greenhall",
      "screen_name" : "ameliagreenhall",
      "indices" : [ 0, 16 ],
      "id_str" : "246531241",
      "id" : 246531241
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "272919979643523072",
  "geo" : { },
  "id_str" : "272930643153915905",
  "in_reply_to_user_id" : 246531241,
  "text" : "@ameliagreenhall They're a bit disturbing, but in a good way.",
  "id" : 272930643153915905,
  "in_reply_to_status_id" : 272919979643523072,
  "created_at" : "2012-11-26 05:11:50 +0000",
  "in_reply_to_screen_name" : "ameliagreenhall",
  "in_reply_to_user_id_str" : "246531241",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 66 ],
      "url" : "http://t.co/bAPmUtSq",
      "expanded_url" : "http://instagr.am/p/SetYW7o0GW/",
      "display_url" : "instagr.am/p/SetYW7o0GW/"
    } ]
  },
  "geo" : { },
  "id_str" : "272924468643516418",
  "text" : "8:36pm \"Play ball with me in my room please!\" http://t.co/bAPmUtSq",
  "id" : 272924468643516418,
  "created_at" : "2012-11-26 04:47:18 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ArielMeadowStallings",
      "screen_name" : "OffbeatAriel",
      "indices" : [ 24, 37 ],
      "id_str" : "14095370",
      "id" : 14095370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 94 ],
      "url" : "http://t.co/jURuUqmc",
      "expanded_url" : "http://instagr.am/p/Seqnw7I0D6/",
      "display_url" : "instagr.am/p/Seqnw7I0D6/"
    } ]
  },
  "geo" : { },
  "id_str" : "272918451687919616",
  "text" : "Spinning Niko (taken by @OffbeatAriel at Tavi's bday party on Bainbridge) http://t.co/jURuUqmc",
  "id" : 272918451687919616,
  "created_at" : "2012-11-26 04:23:24 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erik Pavia",
      "screen_name" : "erikpavia",
      "indices" : [ 12, 22 ],
      "id_str" : "31325231",
      "id" : 31325231
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/buster/status/272911009721745408/photo/1",
      "indices" : [ 111, 131 ],
      "url" : "http://t.co/tKxpU77C",
      "media_url" : "http://pbs.twimg.com/media/A8mTHg5CAAACedq.jpg",
      "id_str" : "272911009730134016",
      "id" : 272911009730134016,
      "media_url_https" : "https://pbs.twimg.com/media/A8mTHg5CAAACedq.jpg",
      "sizes" : [ {
        "h" : 854,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1457,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 484,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1439
      } ],
      "display_url" : "pic.twitter.com/tKxpU77C"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 44 ],
      "url" : "http://t.co/B8t7jPNx",
      "expanded_url" : "http://erikpavia.tumblr.com/post/36238317073/my-life-by-months-visual",
      "display_url" : "erikpavia.tumblr.com/post/362383170\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "272911009721745408",
  "text" : "Inspired by @erikpavia (http://t.co/B8t7jPNx) put together a quick spreadsheet visualizing my life expectancy: http://t.co/tKxpU77C",
  "id" : 272911009721745408,
  "created_at" : "2012-11-26 03:53:51 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 47 ],
      "url" : "http://t.co/jQK7x3rC",
      "expanded_url" : "http://instagr.am/p/Sd478lo0Nc/",
      "display_url" : "instagr.am/p/Sd478lo0Nc/"
    } ]
  },
  "geo" : { },
  "id_str" : "272808790741614592",
  "text" : "Spooky ferry to Bainbridge http://t.co/jQK7x3rC",
  "id" : 272808790741614592,
  "created_at" : "2012-11-25 21:07:38 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fred Wilson",
      "screen_name" : "fredwilson",
      "indices" : [ 89, 100 ],
      "id_str" : "1000591",
      "id" : 1000591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 139 ],
      "url" : "http://t.co/9ylDOKn3",
      "expanded_url" : "http://www.avc.com/a_vc/2012/11/what-has-changed.html",
      "display_url" : "avc.com/a_vc/2012/11/w\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "272753993871151104",
  "text" : "Raising money for consumer web businesses is getting more difficult, for good reasons RT @fredwilson: What Has Changed http://t.co/9ylDOKn3",
  "id" : 272753993871151104,
  "created_at" : "2012-11-25 17:29:54 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niko Benson",
      "screen_name" : "nikobenson",
      "indices" : [ 3, 14 ],
      "id_str" : "142467448",
      "id" : 142467448
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "272614856065183745",
  "text" : "RT @nikobenson: Mama: Keep your eye on the ball!\nNiko: What!?\nMama: Keep your eye on the ball!\nNiko: *puts ball against his eye*",
  "retweeted_status" : {
    "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "272601950170796032",
    "text" : "Mama: Keep your eye on the ball!\nNiko: What!?\nMama: Keep your eye on the ball!\nNiko: *puts ball against his eye*",
    "id" : 272601950170796032,
    "created_at" : "2012-11-25 07:25:44 +0000",
    "user" : {
      "name" : "Niko Benson",
      "screen_name" : "nikobenson",
      "protected" : false,
      "id_str" : "142467448",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3620827215/753aea9d1e95a621cad25bce69860723_normal.jpeg",
      "id" : 142467448,
      "verified" : false
    }
  },
  "id" : 272614856065183745,
  "created_at" : "2012-11-25 08:17:01 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 71 ],
      "url" : "http://t.co/6cNhm9dW",
      "expanded_url" : "http://instagr.am/p/ScH0JUI0Gn/",
      "display_url" : "instagr.am/p/ScH0JUI0Gn/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.55847104, -122.28551 ]
  },
  "id_str" : "272560165142818816",
  "text" : "8:36pm Date night with the lovely wife @ La Medusa http://t.co/6cNhm9dW",
  "id" : 272560165142818816,
  "created_at" : "2012-11-25 04:39:41 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Sippey",
      "screen_name" : "sippey",
      "indices" : [ 0, 7 ],
      "id_str" : "4711",
      "id" : 4711
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "272219189547253761",
  "geo" : { },
  "id_str" : "272227723764715520",
  "in_reply_to_user_id" : 4711,
  "text" : "@sippey Loved that line.",
  "id" : 272227723764715520,
  "in_reply_to_status_id" : 272219189547253761,
  "created_at" : "2012-11-24 06:38:41 +0000",
  "in_reply_to_screen_name" : "sippey",
  "in_reply_to_user_id_str" : "4711",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cap Watkins",
      "screen_name" : "cap",
      "indices" : [ 0, 4 ],
      "id_str" : "2182141",
      "id" : 2182141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "272194279861006336",
  "geo" : { },
  "id_str" : "272227275385212928",
  "in_reply_to_user_id" : 2182141,
  "text" : "@cap The latter!",
  "id" : 272227275385212928,
  "in_reply_to_status_id" : 272194279861006336,
  "created_at" : "2012-11-24 06:36:54 +0000",
  "in_reply_to_screen_name" : "cap",
  "in_reply_to_user_id_str" : "2182141",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "April Schiller",
      "screen_name" : "the_april",
      "indices" : [ 0, 10 ],
      "id_str" : "16644937",
      "id" : 16644937
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "272205205825794048",
  "geo" : { },
  "id_str" : "272205734022893568",
  "in_reply_to_user_id" : 16644937,
  "text" : "@the_april Until I get bored of it.",
  "id" : 272205734022893568,
  "in_reply_to_status_id" : 272205205825794048,
  "created_at" : "2012-11-24 05:11:18 +0000",
  "in_reply_to_screen_name" : "the_april",
  "in_reply_to_user_id_str" : "16644937",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 66, 76 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 117 ],
      "url" : "http://t.co/eHrvS5BF",
      "expanded_url" : "http://instagr.am/p/SZi20zI0Bf/",
      "display_url" : "instagr.am/p/SZi20zI0Bf/"
    } ]
  },
  "geo" : { },
  "id_str" : "272197763024965633",
  "text" : "8:36pm Family movie times (Brave) with popcorn. Niko doesn't want @kellianne to turn into a bear http://t.co/eHrvS5BF",
  "id" : 272197763024965633,
  "created_at" : "2012-11-24 04:39:38 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niko Benson",
      "screen_name" : "nikobenson",
      "indices" : [ 3, 14 ],
      "id_str" : "142467448",
      "id" : 142467448
    }, {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 33, 43 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "272187769894359040",
  "text" : "RT @nikobenson: Watching Brave. \n@kellianne: \"It's violent!\"\nMe: \"I like it! I like it, mama.\"",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kellianne",
        "screen_name" : "kellianne",
        "indices" : [ 17, 27 ],
        "id_str" : "7362142",
        "id" : 7362142
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "272187659617701889",
    "in_reply_to_user_id" : 7362142,
    "text" : "Watching Brave. \n@kellianne: \"It's violent!\"\nMe: \"I like it! I like it, mama.\"",
    "id" : 272187659617701889,
    "created_at" : "2012-11-24 03:59:29 +0000",
    "in_reply_to_screen_name" : "kellianne",
    "in_reply_to_user_id_str" : "7362142",
    "user" : {
      "name" : "Niko Benson",
      "screen_name" : "nikobenson",
      "protected" : false,
      "id_str" : "142467448",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3620827215/753aea9d1e95a621cad25bce69860723_normal.jpeg",
      "id" : 142467448,
      "verified" : false
    }
  },
  "id" : 272187769894359040,
  "created_at" : "2012-11-24 03:59:56 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cap Watkins",
      "screen_name" : "cap",
      "indices" : [ 0, 4 ],
      "id_str" : "2182141",
      "id" : 2182141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "272184599436726272",
  "geo" : { },
  "id_str" : "272185241232343041",
  "in_reply_to_user_id" : 2182141,
  "text" : "@cap Me. I don't think they'll stick with a refresh button. I have no idea what their plans are but think they'll give up on it soon.",
  "id" : 272185241232343041,
  "in_reply_to_status_id" : 272184599436726272,
  "created_at" : "2012-11-24 03:49:53 +0000",
  "in_reply_to_screen_name" : "cap",
  "in_reply_to_user_id_str" : "2182141",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cap Watkins",
      "screen_name" : "cap",
      "indices" : [ 0, 4 ],
      "id_str" : "2182141",
      "id" : 2182141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "272183948036169728",
  "geo" : { },
  "id_str" : "272184434143424513",
  "in_reply_to_user_id" : 2182141,
  "text" : "@cap So you would take a friendly wager against my opinion that they'll implement it in the next year? :)",
  "id" : 272184434143424513,
  "in_reply_to_status_id" : 272183948036169728,
  "created_at" : "2012-11-24 03:46:40 +0000",
  "in_reply_to_screen_name" : "cap",
  "in_reply_to_user_id_str" : "2182141",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "dinnerinpajamas",
      "indices" : [ 93, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "272180639246204930",
  "text" : "At what time is it too late to change out of your pajamas? Pretty sure 7:30pm is way beyond. #dinnerinpajamas",
  "id" : 272180639246204930,
  "created_at" : "2012-11-24 03:31:35 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cap Watkins",
      "screen_name" : "cap",
      "indices" : [ 0, 4 ],
      "id_str" : "2182141",
      "id" : 2182141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "272173808264302592",
  "geo" : { },
  "id_str" : "272180115042074624",
  "in_reply_to_user_id" : 2182141,
  "text" : "@cap I'm skeptical that that's the reason. Twitter doesn't defend patents, it's now part of iPhone's SDK, and even Facebook's app uses it.",
  "id" : 272180115042074624,
  "in_reply_to_status_id" : 272173808264302592,
  "created_at" : "2012-11-24 03:29:30 +0000",
  "in_reply_to_screen_name" : "cap",
  "in_reply_to_user_id_str" : "2182141",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ArielMeadowStallings",
      "screen_name" : "OffbeatAriel",
      "indices" : [ 0, 13 ],
      "id_str" : "14095370",
      "id" : 14095370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "272160616691679233",
  "geo" : { },
  "id_str" : "272162611880136704",
  "in_reply_to_user_id" : 14095370,
  "text" : "@OffbeatAriel Great porn title for the nerd demographic?",
  "id" : 272162611880136704,
  "in_reply_to_status_id" : 272160616691679233,
  "created_at" : "2012-11-24 02:19:57 +0000",
  "in_reply_to_screen_name" : "OffbeatAriel",
  "in_reply_to_user_id_str" : "14095370",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "h2measure",
      "screen_name" : "h2measure",
      "indices" : [ 0, 10 ],
      "id_str" : "410359153",
      "id" : 410359153
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "272146419329138688",
  "geo" : { },
  "id_str" : "272149521709031424",
  "in_reply_to_user_id" : 410359153,
  "text" : "@h2measure Thanks! I'm still thinking about it so let me know if you have additional insight into making a good fitness function!",
  "id" : 272149521709031424,
  "in_reply_to_status_id" : 272146419329138688,
  "created_at" : "2012-11-24 01:27:56 +0000",
  "in_reply_to_screen_name" : "h2measure",
  "in_reply_to_user_id_str" : "410359153",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 81 ],
      "url" : "http://t.co/IktDLsMa",
      "expanded_url" : "http://m.techcrunch.com/2012/09/18/facebook-mobile-ad-network/",
      "display_url" : "m.techcrunch.com/2012/09/18/fac\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "272140503087202304",
  "text" : "New Facebook ads launch, now on non-Facebook sites and apps: http://t.co/IktDLsMa",
  "id" : 272140503087202304,
  "created_at" : "2012-11-24 00:52:06 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Derek Pangallo",
      "screen_name" : "derallo",
      "indices" : [ 0, 8 ],
      "id_str" : "16504159",
      "id" : 16504159
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "272138997806034944",
  "geo" : { },
  "id_str" : "272139372382539776",
  "in_reply_to_user_id" : 16504159,
  "text" : "@derallo It's Twitter's patent but don't enforce it. Pull to refresh is part of the iPhone SDK now for anyone to use.",
  "id" : 272139372382539776,
  "in_reply_to_status_id" : 272138997806034944,
  "created_at" : "2012-11-24 00:47:37 +0000",
  "in_reply_to_screen_name" : "derallo",
  "in_reply_to_user_id_str" : "16504159",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Instagram",
      "screen_name" : "instagram",
      "indices" : [ 64, 74 ],
      "id_str" : "180505807",
      "id" : 180505807
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http://t.co/Q5kACnvq",
      "expanded_url" : "http://bit.ly/XKnRWb",
      "display_url" : "bit.ly/XKnRWb"
    } ]
  },
  "geo" : { },
  "id_str" : "272134683167436800",
  "text" : "OH: \"I'm gonna Instagram the shit out of dinner\" - not alone RT @instagram: Record-breaking Thanksgiving on Instagram http://t.co/Q5kACnvq",
  "id" : 272134683167436800,
  "created_at" : "2012-11-24 00:28:59 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Instagram",
      "screen_name" : "instagram",
      "indices" : [ 12, 22 ],
      "id_str" : "180505807",
      "id" : 180505807
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "272132869911105537",
  "text" : "Why doesn't @Instagram have pull to refresh?",
  "id" : 272132869911105537,
  "created_at" : "2012-11-24 00:21:46 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Music Underscores Me",
      "screen_name" : "music___me",
      "indices" : [ 0, 11 ],
      "id_str" : "429173298",
      "id" : 429173298
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "272132197362851841",
  "geo" : { },
  "id_str" : "272132559863947264",
  "in_reply_to_user_id" : 429173298,
  "text" : "@music___me I agree that it's marvelous. I wish it's advantage in the market had lasted more than a year.",
  "id" : 272132559863947264,
  "in_reply_to_status_id" : 272132197362851841,
  "created_at" : "2012-11-24 00:20:32 +0000",
  "in_reply_to_screen_name" : "music___me",
  "in_reply_to_user_id_str" : "429173298",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Dean",
      "screen_name" : "dandean",
      "indices" : [ 0, 8 ],
      "id_str" : "9525212",
      "id" : 9525212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "272131943544532992",
  "geo" : { },
  "id_str" : "272132137967292416",
  "in_reply_to_user_id" : 9525212,
  "text" : "@dandean Awww. Now I'm sad.",
  "id" : 272132137967292416,
  "in_reply_to_status_id" : 272131943544532992,
  "created_at" : "2012-11-24 00:18:52 +0000",
  "in_reply_to_screen_name" : "dandean",
  "in_reply_to_user_id_str" : "9525212",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Music Underscores Me",
      "screen_name" : "music___me",
      "indices" : [ 0, 11 ],
      "id_str" : "429173298",
      "id" : 429173298
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "272131103756783616",
  "geo" : { },
  "id_str" : "272131937399889921",
  "in_reply_to_user_id" : 429173298,
  "text" : "@music___me iPhone.",
  "id" : 272131937399889921,
  "in_reply_to_status_id" : 272131103756783616,
  "created_at" : "2012-11-24 00:18:04 +0000",
  "in_reply_to_screen_name" : "music___me",
  "in_reply_to_user_id_str" : "429173298",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "272130771987361792",
  "text" : "Saw my Flip Video camera in a desk drawer today. Poor guy.",
  "id" : 272130771987361792,
  "created_at" : "2012-11-24 00:13:26 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luke Millar",
      "screen_name" : "ltm",
      "indices" : [ 0, 4 ],
      "id_str" : "14616067",
      "id" : 14616067
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "272112103337377792",
  "geo" : { },
  "id_str" : "272112478396235776",
  "in_reply_to_user_id" : 14616067,
  "text" : "@ltm Ha. No. But one of the first big realizations from the project was the difference between complaining and stating negative facts. :)",
  "id" : 272112478396235776,
  "in_reply_to_status_id" : 272112103337377792,
  "created_at" : "2012-11-23 23:00:45 +0000",
  "in_reply_to_screen_name" : "ltm",
  "in_reply_to_user_id_str" : "14616067",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luke Millar",
      "screen_name" : "ltm",
      "indices" : [ 0, 4 ],
      "id_str" : "14616067",
      "id" : 14616067
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "272097599979401217",
  "geo" : { },
  "id_str" : "272111364653330432",
  "in_reply_to_user_id" : 14616067,
  "text" : "@ltm I think it's been really successful. Of course, I complain about things quite a bit and often forget about it sometimes still.",
  "id" : 272111364653330432,
  "in_reply_to_status_id" : 272097599979401217,
  "created_at" : "2012-11-23 22:56:19 +0000",
  "in_reply_to_screen_name" : "ltm",
  "in_reply_to_user_id_str" : "14616067",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Riccardo",
      "screen_name" : "RifoItaly",
      "indices" : [ 0, 10 ],
      "id_str" : "50579403",
      "id" : 50579403
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "272095717496061954",
  "geo" : { },
  "id_str" : "272096392162463744",
  "in_reply_to_user_id" : 50579403,
  "text" : "@RifoItaly Too late! :)",
  "id" : 272096392162463744,
  "in_reply_to_status_id" : 272095717496061954,
  "created_at" : "2012-11-23 21:56:49 +0000",
  "in_reply_to_screen_name" : "RifoItaly",
  "in_reply_to_user_id_str" : "50579403",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Riccardo",
      "screen_name" : "RifoItaly",
      "indices" : [ 4, 14 ],
      "id_str" : "50579403",
      "id" : 50579403
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "272094192308727809",
  "text" : "Pay @RifoItaly $1 for expressing my annoyance with Paypal. Ha.",
  "id" : 272094192308727809,
  "created_at" : "2012-11-23 21:48:05 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 124 ],
      "url" : "https://t.co/SPLMSWYy",
      "expanded_url" : "https://venmo.com/i/busterbenson",
      "display_url" : "venmo.com/i/busterbenson"
    } ]
  },
  "geo" : { },
  "id_str" : "272091382221533185",
  "text" : "I've been annoyed with Paypal for way too long. Any chance Venmo could disrupt them? Crossing fingers. https://t.co/SPLMSWYy",
  "id" : 272091382221533185,
  "created_at" : "2012-11-23 21:36:55 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 41 ],
      "url" : "http://t.co/mDS4IWtm",
      "expanded_url" : "http://instagr.am/p/SW-ZBXo0B9/",
      "display_url" : "instagr.am/p/SW-ZBXo0B9/"
    } ]
  },
  "geo" : { },
  "id_str" : "271835661705830401",
  "text" : "8:36pm Pillow fight! http://t.co/mDS4IWtm",
  "id" : 271835661705830401,
  "created_at" : "2012-11-23 04:40:46 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 75 ],
      "url" : "http://t.co/G56d2g6r",
      "expanded_url" : "http://instagr.am/p/SWmaosI0Ea/",
      "display_url" : "instagr.am/p/SWmaosI0Ea/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.595253, -122.306605 ]
  },
  "id_str" : "271782985005666304",
  "text" : "Lounge singer and dancer @ How Pickle Got Out Of A Jam http://t.co/G56d2g6r",
  "id" : 271782985005666304,
  "created_at" : "2012-11-23 01:11:27 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robi Ganguly",
      "screen_name" : "rganguly",
      "indices" : [ 0, 9 ],
      "id_str" : "622663",
      "id" : 622663
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "271759248776638464",
  "geo" : { },
  "id_str" : "271766317676253184",
  "in_reply_to_user_id" : 622663,
  "text" : "@rganguly Happy thanksgiving to you too!",
  "id" : 271766317676253184,
  "in_reply_to_status_id" : 271759248776638464,
  "created_at" : "2012-11-23 00:05:13 +0000",
  "in_reply_to_screen_name" : "rganguly",
  "in_reply_to_user_id_str" : "622663",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 56 ],
      "url" : "http://t.co/gQAtkiBV",
      "expanded_url" : "http://instagr.am/p/SWaz4wI0Ek/",
      "display_url" : "instagr.am/p/SWaz4wI0Ek/"
    } ]
  },
  "geo" : { },
  "id_str" : "271757578030174208",
  "text" : "I'm thankful for this awesome shirt http://t.co/gQAtkiBV",
  "id" : 271757578030174208,
  "created_at" : "2012-11-22 23:30:30 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "271701022789996546",
  "text" : "Lazy wintery walks: 1\n\nEggnog and rum count: 1\n\nMy jam: Charlie Brown Holiday Hits\n\nThanksgiving: bring it",
  "id" : 271701022789996546,
  "created_at" : "2012-11-22 19:45:46 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 104 ],
      "url" : "http://t.co/QP8rs6Nf",
      "expanded_url" : "http://flic.kr/p/dvj1gh",
      "display_url" : "flic.kr/p/dvj1gh"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.608666, -122.306 ]
  },
  "id_str" : "271473436528898049",
  "text" : "8:36pm Battled over bathtime but now thinking about spreadsheets and thankful lists http://t.co/QP8rs6Nf",
  "id" : 271473436528898049,
  "created_at" : "2012-11-22 04:41:25 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Britt Selvitelle",
      "screen_name" : "bs",
      "indices" : [ 0, 3 ],
      "id_str" : "309073",
      "id" : 309073
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "271469251494293505",
  "geo" : { },
  "id_str" : "271471215745589249",
  "in_reply_to_user_id" : 309073,
  "text" : "@bs Exactly. Best pedometer ever.",
  "id" : 271471215745589249,
  "in_reply_to_status_id" : 271469251494293505,
  "created_at" : "2012-11-22 04:32:36 +0000",
  "in_reply_to_screen_name" : "bs",
  "in_reply_to_user_id_str" : "309073",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "271454440454778881",
  "text" : "How many tweets are identical to this one, letter by letter?",
  "id" : 271454440454778881,
  "created_at" : "2012-11-22 03:25:56 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 56 ],
      "url" : "http://t.co/yYHnYBS8",
      "expanded_url" : "http://toolong-didntread.com",
      "display_url" : "toolong-didntread.com"
    } ]
  },
  "geo" : { },
  "id_str" : "271453509277319169",
  "text" : "Just short enough to actually read \nhttp://t.co/yYHnYBS8",
  "id" : 271453509277319169,
  "created_at" : "2012-11-22 03:22:14 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tara Tiger Brown",
      "screen_name" : "tara",
      "indices" : [ 0, 5 ],
      "id_str" : "10959642",
      "id" : 10959642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "271441280280711168",
  "geo" : { },
  "id_str" : "271442405612453889",
  "in_reply_to_user_id" : 10959642,
  "text" : "@tara I think treat inflation is gonna hit us hard in the next 6 months.",
  "id" : 271442405612453889,
  "in_reply_to_status_id" : 271441280280711168,
  "created_at" : "2012-11-22 02:38:07 +0000",
  "in_reply_to_screen_name" : "tara",
  "in_reply_to_user_id_str" : "10959642",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tara Tiger Brown",
      "screen_name" : "tara",
      "indices" : [ 0, 5 ],
      "id_str" : "10959642",
      "id" : 10959642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "271435457076813824",
  "geo" : { },
  "id_str" : "271440348780298240",
  "in_reply_to_user_id" : 10959642,
  "text" : "@tara We use Kermit the Frog pez that flies in with the Star Wars theme. He's already gaming the system though.",
  "id" : 271440348780298240,
  "in_reply_to_status_id" : 271435457076813824,
  "created_at" : "2012-11-22 02:29:56 +0000",
  "in_reply_to_screen_name" : "tara",
  "in_reply_to_user_id_str" : "10959642",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Greg Schwartz",
      "screen_name" : "uxgreg",
      "indices" : [ 0, 7 ],
      "id_str" : "14819149",
      "id" : 14819149
    }, {
      "name" : "Will Lam",
      "screen_name" : "will_lam",
      "indices" : [ 8, 17 ],
      "id_str" : "16031604",
      "id" : 16031604
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "271375265563828224",
  "geo" : { },
  "id_str" : "271377518588723200",
  "in_reply_to_user_id" : 14819149,
  "text" : "@uxgreg @will_lam I think it does have a lean/normal body weight switch during set up. I am not 100% positive though.",
  "id" : 271377518588723200,
  "in_reply_to_status_id" : 271375265563828224,
  "created_at" : "2012-11-21 22:20:17 +0000",
  "in_reply_to_screen_name" : "uxgreg",
  "in_reply_to_user_id_str" : "14819149",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan King",
      "screen_name" : "rk",
      "indices" : [ 0, 3 ],
      "id_str" : "19853",
      "id" : 19853
    }, {
      "name" : "Ryan Freitas",
      "screen_name" : "ryanchris",
      "indices" : [ 4, 14 ],
      "id_str" : "13349",
      "id" : 13349
    }, {
      "name" : "Indefensible",
      "screen_name" : "indefensible",
      "indices" : [ 15, 28 ],
      "id_str" : "7243332",
      "id" : 7243332
    }, {
      "name" : "Joe Stump",
      "screen_name" : "joestump",
      "indices" : [ 29, 38 ],
      "id_str" : "4234581",
      "id" : 4234581
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "271362553886699520",
  "geo" : { },
  "id_str" : "271363987524964352",
  "in_reply_to_user_id" : 19853,
  "text" : "@rk @ryanchris @indefensible @joestump Boomerang should let you say \"send this reply in X days\".",
  "id" : 271363987524964352,
  "in_reply_to_status_id" : 271362553886699520,
  "created_at" : "2012-11-21 21:26:30 +0000",
  "in_reply_to_screen_name" : "rk",
  "in_reply_to_user_id_str" : "19853",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Stump",
      "screen_name" : "joestump",
      "indices" : [ 0, 9 ],
      "id_str" : "4234581",
      "id" : 4234581
    }, {
      "name" : "Indefensible",
      "screen_name" : "indefensible",
      "indices" : [ 10, 23 ],
      "id_str" : "7243332",
      "id" : 7243332
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "271353637509398529",
  "geo" : { },
  "id_str" : "271363791810351104",
  "in_reply_to_user_id" : 4234581,
  "text" : "@joestump @indefensible I set one up a couple weeks ago and love it. Wish there were slightly better rules around it though.",
  "id" : 271363791810351104,
  "in_reply_to_status_id" : 271353637509398529,
  "created_at" : "2012-11-21 21:25:44 +0000",
  "in_reply_to_screen_name" : "joestump",
  "in_reply_to_user_id_str" : "4234581",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Will Lam",
      "screen_name" : "will_lam",
      "indices" : [ 0, 9 ],
      "id_str" : "16031604",
      "id" : 16031604
    }, {
      "name" : "Greg Schwartz",
      "screen_name" : "uxgreg",
      "indices" : [ 10, 17 ],
      "id_str" : "14819149",
      "id" : 14819149
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "271334857941086208",
  "geo" : { },
  "id_str" : "271359467805884416",
  "in_reply_to_user_id" : 16031604,
  "text" : "@will_lam @uxgreg Aria is easier to setup, more accurate body fat % in my opinion, and has an open API.",
  "id" : 271359467805884416,
  "in_reply_to_status_id" : 271334857941086208,
  "created_at" : "2012-11-21 21:08:33 +0000",
  "in_reply_to_screen_name" : "will_lam",
  "in_reply_to_user_id_str" : "16031604",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Will Lam",
      "screen_name" : "will_lam",
      "indices" : [ 0, 9 ],
      "id_str" : "16031604",
      "id" : 16031604
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "271286511725584385",
  "geo" : { },
  "id_str" : "271287190456266752",
  "in_reply_to_user_id" : 16031604,
  "text" : "@will_lam Fitbit Aria. I had a Withings before but I like this one better.",
  "id" : 271287190456266752,
  "in_reply_to_status_id" : 271286511725584385,
  "created_at" : "2012-11-21 16:21:21 +0000",
  "in_reply_to_screen_name" : "will_lam",
  "in_reply_to_user_id_str" : "16031604",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 126 ],
      "url" : "http://t.co/ch6K29pf",
      "expanded_url" : "http://bit.ly/TPRg8V",
      "display_url" : "bit.ly/TPRg8V"
    } ]
  },
  "geo" : { },
  "id_str" : "271284661781659648",
  "text" : "As of this morning I've lost 7.8 lbs and just barely won my \"diet bet\" (lose 4% of my weight in 4 weeks). http://t.co/ch6K29pf",
  "id" : 271284661781659648,
  "created_at" : "2012-11-21 16:11:18 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Berkun",
      "screen_name" : "berkun",
      "indices" : [ 0, 7 ],
      "id_str" : "30495974",
      "id" : 30495974
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "271127619494359040",
  "in_reply_to_user_id" : 30495974,
  "text" : "@berkun But I agree that it's unknowable. How could it be any other way, really?",
  "id" : 271127619494359040,
  "created_at" : "2012-11-21 05:47:16 +0000",
  "in_reply_to_screen_name" : "berkun",
  "in_reply_to_user_id_str" : "30495974",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Berkun",
      "screen_name" : "berkun",
      "indices" : [ 0, 7 ],
      "id_str" : "30495974",
      "id" : 30495974
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "271127145248604160",
  "geo" : { },
  "id_str" : "271127413805678592",
  "in_reply_to_user_id" : 30495974,
  "text" : "@berkun From what I remember, he hedges his bets in the book. It's a dip if you get to the other side and it starts going up again.",
  "id" : 271127413805678592,
  "in_reply_to_status_id" : 271127145248604160,
  "created_at" : "2012-11-21 05:46:27 +0000",
  "in_reply_to_screen_name" : "berkun",
  "in_reply_to_user_id_str" : "30495974",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Berkun",
      "screen_name" : "berkun",
      "indices" : [ 0, 7 ],
      "id_str" : "30495974",
      "id" : 30495974
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 37 ],
      "url" : "http://t.co/fNxFjhCI",
      "expanded_url" : "http://bit.ly/10qOvRs",
      "display_url" : "bit.ly/10qOvRs"
    } ]
  },
  "in_reply_to_status_id_str" : "271125685832146944",
  "geo" : { },
  "id_str" : "271126340441341952",
  "in_reply_to_user_id" : 30495974,
  "text" : "@berkun The dip? http://t.co/fNxFjhCI",
  "id" : 271126340441341952,
  "in_reply_to_status_id" : 271125685832146944,
  "created_at" : "2012-11-21 05:42:11 +0000",
  "in_reply_to_screen_name" : "berkun",
  "in_reply_to_user_id_str" : "30495974",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 93 ],
      "url" : "http://t.co/Qv5sxvGI",
      "expanded_url" : "http://instagr.am/p/SR0Aaoo0Ng/",
      "display_url" : "instagr.am/p/SR0Aaoo0Ng/"
    } ]
  },
  "geo" : { },
  "id_str" : "271109706246914048",
  "text" : "8:36pm Still a top 5 sentence of all time (testing the overgram app too) http://t.co/Qv5sxvGI",
  "id" : 271109706246914048,
  "created_at" : "2012-11-21 04:36:05 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Maria Popova",
      "screen_name" : "brainpicker",
      "indices" : [ 3, 15 ],
      "id_str" : "9207632",
      "id" : 9207632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 112 ],
      "url" : "http://t.co/wOmTgU58",
      "expanded_url" : "http://j.mp/S5NbwK",
      "display_url" : "j.mp/S5NbwK"
    } ]
  },
  "geo" : { },
  "id_str" : "271106231375122432",
  "text" : "RT @brainpicker: Richard Feynman on the one sentence to be passed on to the next generation http://t.co/wOmTgU58",
  "retweeted_status" : {
    "source" : "<a href=\"http://bufferapp.com\" rel=\"nofollow\">Buffer</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 75, 95 ],
        "url" : "http://t.co/wOmTgU58",
        "expanded_url" : "http://j.mp/S5NbwK",
        "display_url" : "j.mp/S5NbwK"
      } ]
    },
    "geo" : { },
    "id_str" : "271101311292944384",
    "text" : "Richard Feynman on the one sentence to be passed on to the next generation http://t.co/wOmTgU58",
    "id" : 271101311292944384,
    "created_at" : "2012-11-21 04:02:44 +0000",
    "user" : {
      "name" : "Maria Popova",
      "screen_name" : "brainpicker",
      "protected" : false,
      "id_str" : "9207632",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/125575833/twitter_normal.jpg",
      "id" : 9207632,
      "verified" : true
    }
  },
  "id" : 271106231375122432,
  "created_at" : "2012-11-21 04:22:17 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://cir.ca/\" rel=\"nofollow\">Circa News</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 30 ],
      "url" : "http://t.co/vv3E4RLr",
      "expanded_url" : "http://cir.ca/s/AeE",
      "display_url" : "cir.ca/s/AeE"
    } ]
  },
  "geo" : { },
  "id_str" : "271084080509104128",
  "text" : "Exciting! http://t.co/vv3E4RLr",
  "id" : 271084080509104128,
  "created_at" : "2012-11-21 02:54:15 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niko Benson",
      "screen_name" : "nikobenson",
      "indices" : [ 49, 60 ],
      "id_str" : "142467448",
      "id" : 142467448
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "doingsomethingright",
      "indices" : [ 61, 81 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "271082984822669312",
  "text" : "\"Let's watch the Daily Show, Papa!\" - 2 year old @nikobenson #doingsomethingright",
  "id" : 271082984822669312,
  "created_at" : "2012-11-21 02:49:54 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Taylor Singletary",
      "screen_name" : "episod",
      "indices" : [ 0, 7 ],
      "id_str" : "819797",
      "id" : 819797
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/buster/status/271074654343540736/photo/1",
      "indices" : [ 21, 41 ],
      "url" : "http://t.co/I4g0ojDh",
      "media_url" : "http://pbs.twimg.com/media/A8MM9kACMAQnaBd.jpg",
      "id_str" : "271074654347735044",
      "id" : 271074654347735044,
      "media_url_https" : "https://pbs.twimg.com/media/A8MM9kACMAQnaBd.jpg",
      "sizes" : [ {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 1065,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com/I4g0ojDh"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "271072023936110592",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6079236018, -122.314593969 ]
  },
  "id_str" : "271074654343540736",
  "in_reply_to_user_id" : 819797,
  "text" : "@episod Here you go. http://t.co/I4g0ojDh",
  "id" : 271074654343540736,
  "in_reply_to_status_id" : 271072023936110592,
  "created_at" : "2012-11-21 02:16:49 +0000",
  "in_reply_to_screen_name" : "episod",
  "in_reply_to_user_id_str" : "819797",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http://t.co/fPHf3Wzc",
      "expanded_url" : "http://bit.ly/ScXnq4",
      "display_url" : "bit.ly/ScXnq4"
    } ]
  },
  "geo" : { },
  "id_str" : "271052613716418561",
  "text" : "\"You want to know how to paint a perfect painting? It's easy. Make yourself perfect and then just paint naturally.\" http://t.co/fPHf3Wzc",
  "id" : 271052613716418561,
  "created_at" : "2012-11-21 00:49:13 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Taylor Singletary",
      "screen_name" : "episod",
      "indices" : [ 0, 7 ],
      "id_str" : "819797",
      "id" : 819797
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "271003882564513792",
  "geo" : { },
  "id_str" : "271008286315270144",
  "in_reply_to_user_id" : 819797,
  "text" : "@episod What about a 140 character limit?",
  "id" : 271008286315270144,
  "in_reply_to_status_id" : 271003882564513792,
  "created_at" : "2012-11-20 21:53:05 +0000",
  "in_reply_to_screen_name" : "episod",
  "in_reply_to_user_id_str" : "819797",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "maggim",
      "screen_name" : "maggim",
      "indices" : [ 0, 7 ],
      "id_str" : "14290242",
      "id" : 14290242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "270970825467899905",
  "in_reply_to_user_id" : 14290242,
  "text" : "@maggim Just add a dollar a day to the rent check. :)",
  "id" : 270970825467899905,
  "created_at" : "2012-11-20 19:24:13 +0000",
  "in_reply_to_screen_name" : "maggim",
  "in_reply_to_user_id_str" : "14290242",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "maggim",
      "screen_name" : "maggim",
      "indices" : [ 0, 7 ],
      "id_str" : "14290242",
      "id" : 14290242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "270970402237456384",
  "geo" : { },
  "id_str" : "270970574875021312",
  "in_reply_to_user_id" : 14290242,
  "text" : "@maggim TweetBot is your app, then. They don't have promoted tweets, and do allow filters. Not sure if you can filter all hashtags though.",
  "id" : 270970574875021312,
  "in_reply_to_status_id" : 270970402237456384,
  "created_at" : "2012-11-20 19:23:14 +0000",
  "in_reply_to_screen_name" : "maggim",
  "in_reply_to_user_id_str" : "14290242",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"https://findings.com\" rel=\"nofollow\">Findings</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 9, 18 ],
      "id_str" : "761628",
      "id" : 761628
    }, {
      "name" : "Findings",
      "screen_name" : "findings",
      "indices" : [ 84, 93 ],
      "id_str" : "208197274",
      "id" : 208197274
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 116 ],
      "url" : "http://t.co/YX1Ds6EL",
      "expanded_url" : "http://fnd.gs/SOrZg1",
      "display_url" : "fnd.gs/SOrZg1"
    } ]
  },
  "geo" : { },
  "id_str" : "270965943281254402",
  "text" : "I'm with @rickwebb on Team Anti-False-Dichotomy-Between-Irony-And-Authenticity. via @findings - http://t.co/YX1Ds6EL",
  "id" : 270965943281254402,
  "created_at" : "2012-11-20 19:04:49 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Susannah Fox",
      "screen_name" : "SusannahFox",
      "indices" : [ 0, 12 ],
      "id_str" : "17843236",
      "id" : 17843236
    }, {
      "name" : "Emilio Ramirez",
      "screen_name" : "e_ramirez",
      "indices" : [ 13, 23 ],
      "id_str" : "1273564632",
      "id" : 1273564632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "270947990091485184",
  "geo" : { },
  "id_str" : "270948556465139712",
  "in_reply_to_user_id" : 17843236,
  "text" : "@SusannahFox @e_ramirez Yeah there's the dreaded 3-month drop off for tech-led motivation. If it's sustainable, then it's something unique.",
  "id" : 270948556465139712,
  "in_reply_to_status_id" : 270947990091485184,
  "created_at" : "2012-11-20 17:55:44 +0000",
  "in_reply_to_screen_name" : "SusannahFox",
  "in_reply_to_user_id_str" : "17843236",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Stump",
      "screen_name" : "joestump",
      "indices" : [ 0, 9 ],
      "id_str" : "4234581",
      "id" : 4234581
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "270946032433635329",
  "geo" : { },
  "id_str" : "270946353478238208",
  "in_reply_to_user_id" : 4234581,
  "text" : "@joestump Yeah there are a lot. But I think not as many.",
  "id" : 270946353478238208,
  "in_reply_to_status_id" : 270946032433635329,
  "created_at" : "2012-11-20 17:46:59 +0000",
  "in_reply_to_screen_name" : "joestump",
  "in_reply_to_user_id_str" : "4234581",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Stump",
      "screen_name" : "joestump",
      "indices" : [ 0, 9 ],
      "id_str" : "4234581",
      "id" : 4234581
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "270944935958695936",
  "geo" : { },
  "id_str" : "270945911830630400",
  "in_reply_to_user_id" : 4234581,
  "text" : "@joestump Wonder what that really means given Gallup's inaccurate poll record. 46% of people with landlines, maybe.",
  "id" : 270945911830630400,
  "in_reply_to_status_id" : 270944935958695936,
  "created_at" : "2012-11-20 17:45:13 +0000",
  "in_reply_to_screen_name" : "joestump",
  "in_reply_to_user_id_str" : "4234581",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Susannah Fox",
      "screen_name" : "SusannahFox",
      "indices" : [ 0, 12 ],
      "id_str" : "17843236",
      "id" : 17843236
    }, {
      "name" : "Emilio Ramirez",
      "screen_name" : "e_ramirez",
      "indices" : [ 13, 23 ],
      "id_str" : "1273564632",
      "id" : 1273564632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "270939354493501441",
  "geo" : { },
  "id_str" : "270942656773910529",
  "in_reply_to_user_id" : 17843236,
  "text" : "@SusannahFox @e_ramirez That's awesome. How long have they been into it? How did you introduce them to it?",
  "id" : 270942656773910529,
  "in_reply_to_status_id" : 270939354493501441,
  "created_at" : "2012-11-20 17:32:17 +0000",
  "in_reply_to_screen_name" : "SusannahFox",
  "in_reply_to_user_id_str" : "17843236",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emilio Ramirez",
      "screen_name" : "e_ramirez",
      "indices" : [ 0, 10 ],
      "id_str" : "1273564632",
      "id" : 1273564632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "270923049233154048",
  "geo" : { },
  "id_str" : "270929299891179520",
  "in_reply_to_user_id" : 21135674,
  "text" : "@e_ramirez Fitbit Zip!",
  "id" : 270929299891179520,
  "in_reply_to_status_id" : 270923049233154048,
  "created_at" : "2012-11-20 16:39:13 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tatiana grace",
      "screen_name" : "tatiana",
      "indices" : [ 0, 8 ],
      "id_str" : "18525171",
      "id" : 18525171
    }, {
      "name" : "Jay Holler",
      "screen_name" : "jayholler",
      "indices" : [ 9, 19 ],
      "id_str" : "14110325",
      "id" : 14110325
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 131 ],
      "url" : "http://t.co/5bhGOtVU",
      "expanded_url" : "http://www.livestrong.com/article/504576-eye-twitching-vitamin-deficiencies/",
      "display_url" : "livestrong.com/article/504576\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "270925398802563072",
  "geo" : { },
  "id_str" : "270928288325722112",
  "in_reply_to_user_id" : 18525171,
  "text" : "@tatiana @jayholler Just try whatever you feel like. Though I think eye twitching is unrelated to screen time. http://t.co/5bhGOtVU",
  "id" : 270928288325722112,
  "in_reply_to_status_id" : 270925398802563072,
  "created_at" : "2012-11-20 16:35:12 +0000",
  "in_reply_to_screen_name" : "tatiana",
  "in_reply_to_user_id_str" : "18525171",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tatiana grace",
      "screen_name" : "tatiana",
      "indices" : [ 0, 8 ],
      "id_str" : "18525171",
      "id" : 18525171
    }, {
      "name" : "Jay Holler",
      "screen_name" : "jayholler",
      "indices" : [ 9, 19 ],
      "id_str" : "14110325",
      "id" : 14110325
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 79 ],
      "url" : "http://t.co/M4YTVWEi",
      "expanded_url" : "http://branch.com/b/disconnect-saturdays",
      "display_url" : "branch.com/b/disconnect-s\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "270921082578558976",
  "geo" : { },
  "id_str" : "270923112177074176",
  "in_reply_to_user_id" : 18525171,
  "text" : "@tatiana @jayholler Here's a group of us talking about it: http://t.co/M4YTVWEi Join up and let us know if you give it a try.",
  "id" : 270923112177074176,
  "in_reply_to_status_id" : 270921082578558976,
  "created_at" : "2012-11-20 16:14:38 +0000",
  "in_reply_to_screen_name" : "tatiana",
  "in_reply_to_user_id_str" : "18525171",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "allofthem",
      "indices" : [ 70, 80 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "270774157770383360",
  "text" : "How many episodes of Girls should we watch with our new HBO Go login? #allofthem",
  "id" : 270774157770383360,
  "created_at" : "2012-11-20 06:22:44 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "girl jo",
      "screen_name" : "octavekitten",
      "indices" : [ 0, 13 ],
      "id_str" : "16366882",
      "id" : 16366882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "270757624490913792",
  "geo" : { },
  "id_str" : "270757886383255552",
  "in_reply_to_user_id" : 16366882,
  "text" : "@octavekitten Bear. I think.",
  "id" : 270757886383255552,
  "in_reply_to_status_id" : 270757624490913792,
  "created_at" : "2012-11-20 05:18:05 +0000",
  "in_reply_to_screen_name" : "octavekitten",
  "in_reply_to_user_id_str" : "16366882",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 109 ],
      "url" : "http://t.co/U8CCe5QE",
      "expanded_url" : "http://instagr.am/p/SPTbnTI0BA/",
      "display_url" : "instagr.am/p/SPTbnTI0BA/"
    } ]
  },
  "geo" : { },
  "id_str" : "270756223043911680",
  "text" : "8:36pm Niko's in bed he excitedly told me about these 3 things he's thankful for earlier http://t.co/U8CCe5QE",
  "id" : 270756223043911680,
  "created_at" : "2012-11-20 05:11:28 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://bufferapp.com\" rel=\"nofollow\">Buffer</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 37 ],
      "url" : "http://t.co/YsZJ4YGk",
      "expanded_url" : "http://bit.ly/UPFw7x",
      "display_url" : "bit.ly/UPFw7x"
    } ]
  },
  "geo" : { },
  "id_str" : "270739440379502592",
  "text" : "Dumb Ways to Die http://t.co/YsZJ4YGk",
  "id" : 270739440379502592,
  "created_at" : "2012-11-20 04:04:47 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Moody",
      "screen_name" : "notaustintexas",
      "indices" : [ 0, 15 ],
      "id_str" : "597623360",
      "id" : 597623360
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "270731138870415360",
  "geo" : { },
  "id_str" : "270733955387510784",
  "in_reply_to_user_id" : 597623360,
  "text" : "@notaustintexas Awesome. Thanks! We got one already. The Internet is quick!",
  "id" : 270733955387510784,
  "in_reply_to_status_id" : 270731138870415360,
  "created_at" : "2012-11-20 03:42:59 +0000",
  "in_reply_to_screen_name" : "notaustintexas",
  "in_reply_to_user_id_str" : "597623360",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "270729955703390208",
  "text" : "0 to HBO Go pass in 3 minutes. Thanks!",
  "id" : 270729955703390208,
  "created_at" : "2012-11-20 03:27:06 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "M. McGovern",
      "screen_name" : "mmcgovern",
      "indices" : [ 0, 10 ],
      "id_str" : "15856582",
      "id" : 15856582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "270726598406332416",
  "geo" : { },
  "id_str" : "270726765960368128",
  "in_reply_to_user_id" : 15856582,
  "text" : "@mmcgovern I appreciate that!",
  "id" : 270726765960368128,
  "in_reply_to_status_id" : 270726598406332416,
  "created_at" : "2012-11-20 03:14:25 +0000",
  "in_reply_to_screen_name" : "mmcgovern",
  "in_reply_to_user_id_str" : "15856582",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "270725942643666944",
  "text" : "Who has an HBO Go login that they'd be willing to share with a friendly internet stranger?",
  "id" : 270725942643666944,
  "created_at" : "2012-11-20 03:11:09 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Victor Mathieux",
      "screen_name" : "VictorMathieux",
      "indices" : [ 0, 15 ],
      "id_str" : "178841000",
      "id" : 178841000
    }, {
      "name" : "Garry Tan",
      "screen_name" : "garrytan",
      "indices" : [ 16, 25 ],
      "id_str" : "11768582",
      "id" : 11768582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "270707147057278978",
  "geo" : { },
  "id_str" : "270707413970190336",
  "in_reply_to_user_id" : 178841000,
  "text" : "@VictorMathieux @garrytan Man/woman vs him/herself.",
  "id" : 270707413970190336,
  "in_reply_to_status_id" : 270707147057278978,
  "created_at" : "2012-11-20 01:57:31 +0000",
  "in_reply_to_screen_name" : "VictorMathieux",
  "in_reply_to_user_id_str" : "178841000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Victor Mathieux",
      "screen_name" : "VictorMathieux",
      "indices" : [ 0, 15 ],
      "id_str" : "178841000",
      "id" : 178841000
    }, {
      "name" : "Garry Tan",
      "screen_name" : "garrytan",
      "indices" : [ 16, 25 ],
      "id_str" : "11768582",
      "id" : 11768582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "270697932305604608",
  "geo" : { },
  "id_str" : "270703512718036993",
  "in_reply_to_user_id" : 178841000,
  "text" : "@VictorMathieux @garrytan Even the path of victory through peace requires struggle, conflict, pain, and purpose.",
  "id" : 270703512718036993,
  "in_reply_to_status_id" : 270697932305604608,
  "created_at" : "2012-11-20 01:42:01 +0000",
  "in_reply_to_screen_name" : "VictorMathieux",
  "in_reply_to_user_id_str" : "178841000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Garry Tan",
      "screen_name" : "garrytan",
      "indices" : [ 3, 12 ],
      "id_str" : "11768582",
      "id" : 11768582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "270694246057660416",
  "text" : "RT @garrytan: Happiness is a byproduct of function, purpose, and conflict; those who seek happiness for itself seek victory without war. ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "270693560876167169",
    "text" : "Happiness is a byproduct of function, purpose, and conflict; those who seek happiness for itself seek victory without war. -W.S. Burroughs",
    "id" : 270693560876167169,
    "created_at" : "2012-11-20 01:02:28 +0000",
    "user" : {
      "name" : "Garry Tan",
      "screen_name" : "garrytan",
      "protected" : false,
      "id_str" : "11768582",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2673975033/965a165a093e7c0921b9d69d5d99bc41_normal.jpeg",
      "id" : 11768582,
      "verified" : false
    }
  },
  "id" : 270694246057660416,
  "created_at" : "2012-11-20 01:05:12 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://bufferapp.com\" rel=\"nofollow\">Buffer</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay Goldman",
      "screen_name" : "jaygoldman",
      "indices" : [ 71, 82 ],
      "id_str" : "861",
      "id" : 861
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 65 ],
      "url" : "http://t.co/oNIWE6oN",
      "expanded_url" : "http://bit.ly/XWmcLS",
      "display_url" : "bit.ly/XWmcLS"
    } ]
  },
  "geo" : { },
  "id_str" : "270691894948933632",
  "text" : "Awesome Bach visualization/auditorialization http://t.co/oNIWE6oN /via @jaygoldman",
  "id" : 270691894948933632,
  "created_at" : "2012-11-20 00:55:51 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zenobase",
      "screen_name" : "zenobase",
      "indices" : [ 0, 9 ],
      "id_str" : "556162919",
      "id" : 556162919
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 46 ],
      "url" : "http://t.co/t5YwKJOx",
      "expanded_url" : "http://bit.ly/RXJj6V",
      "display_url" : "bit.ly/RXJj6V"
    } ]
  },
  "in_reply_to_status_id_str" : "270658897604386816",
  "geo" : { },
  "id_str" : "270661902777081856",
  "in_reply_to_user_id" : 556162919,
  "text" : "@zenobase Wizard for Mac: http://t.co/t5YwKJOx (it's awesome)",
  "id" : 270661902777081856,
  "in_reply_to_status_id" : 270658897604386816,
  "created_at" : "2012-11-19 22:56:40 +0000",
  "in_reply_to_screen_name" : "zenobase",
  "in_reply_to_user_id_str" : "556162919",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Branch",
      "screen_name" : "branch",
      "indices" : [ 24, 31 ],
      "id_str" : "494518813",
      "id" : 494518813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 73 ],
      "url" : "http://t.co/2kpQj8n4",
      "expanded_url" : "http://branch.com/meet-groups",
      "display_url" : "branch.com/meet-groups"
    } ]
  },
  "geo" : { },
  "id_str" : "270635417039171584",
  "text" : "Excited to see this. RT @branch: Meet Branch Groups. http://t.co/2kpQj8n4",
  "id" : 270635417039171584,
  "created_at" : "2012-11-19 21:11:26 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andr\u00E9 Pinter\u23CE",
      "screen_name" : "endform",
      "indices" : [ 0, 8 ],
      "id_str" : "93731096",
      "id" : 93731096
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "270631500360318977",
  "geo" : { },
  "id_str" : "270633363717648385",
  "in_reply_to_user_id" : 93731096,
  "text" : "@endform Yeah, it's been rather shocking to the natives as well.",
  "id" : 270633363717648385,
  "in_reply_to_status_id" : 270631500360318977,
  "created_at" : "2012-11-19 21:03:16 +0000",
  "in_reply_to_screen_name" : "endform",
  "in_reply_to_user_id_str" : "93731096",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Music Underscores Me",
      "screen_name" : "music___me",
      "indices" : [ 0, 11 ],
      "id_str" : "429173298",
      "id" : 429173298
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "270624246579994624",
  "geo" : { },
  "id_str" : "270624988816609281",
  "in_reply_to_user_id" : 429173298,
  "text" : "@music___me Not yet. It'll be a couple weeks but I'll tweet it when it's available.",
  "id" : 270624988816609281,
  "in_reply_to_status_id" : 270624246579994624,
  "created_at" : "2012-11-19 20:29:59 +0000",
  "in_reply_to_screen_name" : "music___me",
  "in_reply_to_user_id_str" : "429173298",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://bufferapp.com\" rel=\"nofollow\">Buffer</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "quantifiedself",
      "indices" : [ 15, 30 ]
    } ],
    "urls" : [ {
      "indices" : [ 53, 73 ],
      "url" : "http://t.co/dnvWqTEC",
      "expanded_url" : "http://bit.ly/XWlYnW",
      "display_url" : "bit.ly/XWlYnW"
    } ]
  },
  "geo" : { },
  "id_str" : "270618935433506817",
  "text" : "Slides from my #quantifiedself talk in SF last week: http://t.co/dnvWqTEC",
  "id" : 270618935433506817,
  "created_at" : "2012-11-19 20:05:56 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://bufferapp.com\" rel=\"nofollow\">Buffer</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 60 ],
      "url" : "http://t.co/2Xwkwlc8",
      "expanded_url" : "http://bit.ly/XTQQFI",
      "display_url" : "bit.ly/XTQQFI"
    } ]
  },
  "geo" : { },
  "id_str" : "270590792777732096",
  "text" : "Thinking about how things fit together. http://t.co/2Xwkwlc8",
  "id" : 270590792777732096,
  "created_at" : "2012-11-19 18:14:06 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Branch",
      "screen_name" : "branch",
      "indices" : [ 0, 7 ],
      "id_str" : "494518813",
      "id" : 494518813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "270571747860963328",
  "in_reply_to_user_id" : 494518813,
  "text" : "@branch I wish the \"branch this\" link would keep the first 2-3 comments inline before branching to another page.",
  "id" : 270571747860963328,
  "created_at" : "2012-11-19 16:58:26 +0000",
  "in_reply_to_screen_name" : "branch",
  "in_reply_to_user_id_str" : "494518813",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sudama Adam Rice",
      "screen_name" : "sudama",
      "indices" : [ 0, 7 ],
      "id_str" : "3692",
      "id" : 3692
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "270403688214962176",
  "geo" : { },
  "id_str" : "270549899827871745",
  "in_reply_to_user_id" : 3692,
  "text" : "@sudama :( well the 100 pushups app also has a good set of pushup instructions...",
  "id" : 270549899827871745,
  "in_reply_to_status_id" : 270403688214962176,
  "created_at" : "2012-11-19 15:31:37 +0000",
  "in_reply_to_screen_name" : "sudama",
  "in_reply_to_user_id_str" : "3692",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stepa Mitaki",
      "screen_name" : "stepamitaki",
      "indices" : [ 0, 12 ],
      "id_str" : "16654164",
      "id" : 16654164
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "270477443394064384",
  "geo" : { },
  "id_str" : "270549438022443009",
  "in_reply_to_user_id" : 16654164,
  "text" : "@stepamitaki Looks great! Trying to collect stories and best practices from all variations. Send me everything!",
  "id" : 270549438022443009,
  "in_reply_to_status_id" : 270477443394064384,
  "created_at" : "2012-11-19 15:29:47 +0000",
  "in_reply_to_screen_name" : "stepamitaki",
  "in_reply_to_user_id_str" : "16654164",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://getprismatic.com\" rel=\"nofollow\">getprismatic.com</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Prismatic",
      "screen_name" : "Prismatic",
      "indices" : [ 120, 130 ],
      "id_str" : "229709694",
      "id" : 229709694
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 115 ],
      "url" : "http://t.co/LNhSPpAS",
      "expanded_url" : "http://prsm.tc/fAJOZ5",
      "display_url" : "prsm.tc/fAJOZ5"
    } ]
  },
  "geo" : { },
  "id_str" : "270408159796002816",
  "text" : "Anti-fragility: quality of those things in the world that grow stronger while under pressure.  http://t.co/LNhSPpAS via @prismatic",
  "id" : 270408159796002816,
  "created_at" : "2012-11-19 06:08:23 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 57 ],
      "url" : "http://t.co/jThUKk2k",
      "expanded_url" : "http://instagr.am/p/SMq63mI0Pl/",
      "display_url" : "instagr.am/p/SMq63mI0Pl/"
    } ]
  },
  "geo" : { },
  "id_str" : "270385544956084224",
  "text" : "8:36pm Reading In The Night Kitchen! http://t.co/jThUKk2k",
  "id" : 270385544956084224,
  "created_at" : "2012-11-19 04:38:32 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://bufferapp.com\" rel=\"nofollow\">Buffer</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 121 ],
      "url" : "http://t.co/2Xwkwlc8",
      "expanded_url" : "http://bit.ly/XTQQFI",
      "display_url" : "bit.ly/XTQQFI"
    } ]
  },
  "geo" : { },
  "id_str" : "270325892314697729",
  "text" : "Sort of jumbled thoughts on quality. \"The ultimate question for our own lives: person/universe fit\"\n\nhttp://t.co/2Xwkwlc8",
  "id" : 270325892314697729,
  "created_at" : "2012-11-19 00:41:29 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael S Galpert",
      "screen_name" : "msg",
      "indices" : [ 3, 7 ],
      "id_str" : "937961",
      "id" : 937961
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 46 ],
      "url" : "http://t.co/R5CQqZPG",
      "expanded_url" : "http://tmblr.co/Z0StbyXZSh5t",
      "display_url" : "tmblr.co/Z0StbyXZSh5t"
    } ]
  },
  "geo" : { },
  "id_str" : "270322945870688257",
  "text" : "RT @msg: Sharing Publicly http://t.co/R5CQqZPG",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tumblr.com/\" rel=\"nofollow\">Tumblr</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 17, 37 ],
        "url" : "http://t.co/R5CQqZPG",
        "expanded_url" : "http://tmblr.co/Z0StbyXZSh5t",
        "display_url" : "tmblr.co/Z0StbyXZSh5t"
      } ]
    },
    "geo" : { },
    "id_str" : "270321800800530432",
    "text" : "Sharing Publicly http://t.co/R5CQqZPG",
    "id" : 270321800800530432,
    "created_at" : "2012-11-19 00:25:14 +0000",
    "user" : {
      "name" : "Michael S Galpert",
      "screen_name" : "msg",
      "protected" : false,
      "id_str" : "937961",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3484865764/5e2b77911fa9aa1d1f315c0b9f100613_normal.jpeg",
      "id" : 937961,
      "verified" : false
    }
  },
  "id" : 270322945870688257,
  "created_at" : "2012-11-19 00:29:47 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "270284638348521472",
  "text" : "Curious when Niko will respond to my weekly 1-on-1 question for the 1st time about if he has any questions about life that I can answer.",
  "id" : 270284638348521472,
  "created_at" : "2012-11-18 21:57:34 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John W. Solomon",
      "screen_name" : "JohnWrede",
      "indices" : [ 0, 10 ],
      "id_str" : "125733",
      "id" : 125733
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "270282574486704128",
  "geo" : { },
  "id_str" : "270283451628929024",
  "in_reply_to_user_id" : 125733,
  "text" : "@JohnWrede I'd love to!",
  "id" : 270283451628929024,
  "in_reply_to_status_id" : 270282574486704128,
  "created_at" : "2012-11-18 21:52:51 +0000",
  "in_reply_to_screen_name" : "JohnWrede",
  "in_reply_to_user_id_str" : "125733",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 73 ],
      "url" : "http://t.co/l2DqKBUH",
      "expanded_url" : "http://instagr.am/p/SL8Z9yI0Dz/",
      "display_url" : "instagr.am/p/SL8Z9yI0Dz/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.615071, -122.354059 ]
  },
  "id_str" : "270283259089403906",
  "text" : "Choo-spotting weekly edition @ Old Spaghetti Factory http://t.co/l2DqKBUH",
  "id" : 270283259089403906,
  "created_at" : "2012-11-18 21:52:05 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Tallant",
      "screen_name" : "jtallant",
      "indices" : [ 0, 9 ],
      "id_str" : "193483681",
      "id" : 193483681
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "270278992735657984",
  "geo" : { },
  "id_str" : "270280726367326208",
  "in_reply_to_user_id" : 193483681,
  "text" : "@jtallant Thanks. We'll take a look.",
  "id" : 270280726367326208,
  "in_reply_to_status_id" : 270278992735657984,
  "created_at" : "2012-11-18 21:42:01 +0000",
  "in_reply_to_screen_name" : "jtallant",
  "in_reply_to_user_id_str" : "193483681",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John W. Solomon",
      "screen_name" : "JohnWrede",
      "indices" : [ 0, 10 ],
      "id_str" : "125733",
      "id" : 125733
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "270264318594019329",
  "geo" : { },
  "id_str" : "270271286205358082",
  "in_reply_to_user_id" : 125733,
  "text" : "@JohnWrede Not this week. Next!",
  "id" : 270271286205358082,
  "in_reply_to_status_id" : 270264318594019329,
  "created_at" : "2012-11-18 21:04:30 +0000",
  "in_reply_to_screen_name" : "JohnWrede",
  "in_reply_to_user_id_str" : "125733",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christine Corbett",
      "screen_name" : "corbett_inc",
      "indices" : [ 0, 12 ],
      "id_str" : "6066682",
      "id" : 6066682
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "270260024822079490",
  "geo" : { },
  "id_str" : "270260243097862144",
  "in_reply_to_user_id" : 143264018,
  "text" : "@corbett_inc Yup. Definitely not a new idea. But minus the religious connotations.",
  "id" : 270260243097862144,
  "in_reply_to_status_id" : 270260024822079490,
  "created_at" : "2012-11-18 20:20:37 +0000",
  "in_reply_to_screen_name" : "corbett",
  "in_reply_to_user_id_str" : "143264018",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 123 ],
      "url" : "http://t.co/kkVS2hfQ",
      "expanded_url" : "http://bit.ly/Q3vbaP",
      "display_url" : "bit.ly/Q3vbaP"
    } ]
  },
  "geo" : { },
  "id_str" : "270259214159589376",
  "text" : "Want to help explore the idea of disconnecting on Saturdays? Join this branch (I'll approve everyone): http://t.co/kkVS2hfQ",
  "id" : 270259214159589376,
  "created_at" : "2012-11-18 20:16:32 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "270259175412625408",
  "text" : "The idea: 1) Turn off your phone when you go to bed on Fri night. 2) Turn it back on when you wake on Sun.",
  "id" : 270259175412625408,
  "created_at" : "2012-11-18 20:16:23 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Britt Selvitelle",
      "screen_name" : "bs",
      "indices" : [ 0, 3 ],
      "id_str" : "309073",
      "id" : 309073
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "270258035044261888",
  "geo" : { },
  "id_str" : "270258490063347712",
  "in_reply_to_user_id" : 309073,
  "text" : "@bs I'd say that the main point is to focus on slower, bigger, creative things, and relationships. So, yeah.",
  "id" : 270258490063347712,
  "in_reply_to_status_id" : 270258035044261888,
  "created_at" : "2012-11-18 20:13:39 +0000",
  "in_reply_to_screen_name" : "bs",
  "in_reply_to_user_id_str" : "309073",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John W. Solomon",
      "screen_name" : "JohnWrede",
      "indices" : [ 0, 10 ],
      "id_str" : "125733",
      "id" : 125733
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 73 ],
      "url" : "http://t.co/kkVS2hfQ",
      "expanded_url" : "http://bit.ly/Q3vbaP",
      "display_url" : "bit.ly/Q3vbaP"
    } ]
  },
  "in_reply_to_status_id_str" : "270256917161603072",
  "geo" : { },
  "id_str" : "270257799764787200",
  "in_reply_to_user_id" : 125733,
  "text" : "@JohnWrede Can you tell me more about it? Join this: http://t.co/kkVS2hfQ",
  "id" : 270257799764787200,
  "in_reply_to_status_id" : 270256917161603072,
  "created_at" : "2012-11-18 20:10:55 +0000",
  "in_reply_to_screen_name" : "JohnWrede",
  "in_reply_to_user_id_str" : "125733",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Britt Selvitelle",
      "screen_name" : "bs",
      "indices" : [ 0, 3 ],
      "id_str" : "309073",
      "id" : 309073
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "270257161240719360",
  "geo" : { },
  "id_str" : "270257656915181569",
  "in_reply_to_user_id" : 309073,
  "text" : "@bs A) Not dying B) Feeling better at the end of the day.",
  "id" : 270257656915181569,
  "in_reply_to_status_id" : 270257161240719360,
  "created_at" : "2012-11-18 20:10:21 +0000",
  "in_reply_to_screen_name" : "bs",
  "in_reply_to_user_id_str" : "309073",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jen Joyce",
      "screen_name" : "knitpurl",
      "indices" : [ 0, 9 ],
      "id_str" : "17655771",
      "id" : 17655771
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "270254909004333057",
  "geo" : { },
  "id_str" : "270255434231861248",
  "in_reply_to_user_id" : 17655771,
  "text" : "@knitpurl Yeah, I guess it doesn't really work if you're in charge of building a community.",
  "id" : 270255434231861248,
  "in_reply_to_status_id" : 270254909004333057,
  "created_at" : "2012-11-18 20:01:31 +0000",
  "in_reply_to_screen_name" : "knitpurl",
  "in_reply_to_user_id_str" : "17655771",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"https://findings.com\" rel=\"nofollow\">Findings</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Findings",
      "screen_name" : "findings",
      "indices" : [ 98, 107 ],
      "id_str" : "208197274",
      "id" : 208197274
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 130 ],
      "url" : "http://t.co/3ctOJlKi",
      "expanded_url" : "http://fnd.gs/QnA0gH",
      "display_url" : "fnd.gs/QnA0gH"
    } ]
  },
  "geo" : { },
  "id_str" : "270254502442049536",
  "text" : "Our 1 day experiment of not using the internet was a success. Should we do it every Saturday? via @findings - http://t.co/3ctOJlKi",
  "id" : 270254502442049536,
  "created_at" : "2012-11-18 19:57:49 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emilio Ramirez",
      "screen_name" : "e_ramirez",
      "indices" : [ 0, 10 ],
      "id_str" : "1273564632",
      "id" : 1273564632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "270246017616711680",
  "geo" : { },
  "id_str" : "270247166948298752",
  "in_reply_to_user_id" : 21135674,
  "text" : "@e_ramirez Yeah, though they did turn off more than was required of them. How many people attended? Could you go thru each person's tweets?",
  "id" : 270247166948298752,
  "in_reply_to_status_id" : 270246017616711680,
  "created_at" : "2012-11-18 19:28:40 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emilio Ramirez",
      "screen_name" : "e_ramirez",
      "indices" : [ 0, 10 ],
      "id_str" : "1273564632",
      "id" : 1273564632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "270244918163812352",
  "geo" : { },
  "id_str" : "270245802704785410",
  "in_reply_to_user_id" : 21135674,
  "text" : "@e_ramirez You might be out of luck for the moment, I fear. I'll look into it.",
  "id" : 270245802704785410,
  "in_reply_to_status_id" : 270244918163812352,
  "created_at" : "2012-11-18 19:23:14 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 91 ],
      "url" : "http://t.co/UVNekTym",
      "expanded_url" : "http://flic.kr/p/du9xzR",
      "display_url" : "flic.kr/p/du9xzR"
    } ]
  },
  "geo" : { },
  "id_str" : "270086029048967168",
  "text" : "8:36pm Was watching Bladford on my first \"Saturday DisconnectDay\" ever http://t.co/UVNekTym",
  "id" : 270086029048967168,
  "created_at" : "2012-11-18 08:48:21 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "noah kagan",
      "screen_name" : "noahkagan",
      "indices" : [ 0, 10 ],
      "id_str" : "13737",
      "id" : 13737
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "269690855068139521",
  "geo" : { },
  "id_str" : "269691726229286912",
  "in_reply_to_user_id" : 13737,
  "text" : "@noahkagan Nope.",
  "id" : 269691726229286912,
  "in_reply_to_status_id" : 269690855068139521,
  "created_at" : "2012-11-17 06:41:32 +0000",
  "in_reply_to_screen_name" : "noahkagan",
  "in_reply_to_user_id_str" : "13737",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.apple.com\" rel=\"nofollow\">iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Ellin",
      "screen_name" : "brianellin",
      "indices" : [ 101, 112 ],
      "id_str" : "26123649",
      "id" : 26123649
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 134 ],
      "url" : "http://t.co/TCYkfjuH",
      "expanded_url" : "http://www.thesilenthistory.com",
      "display_url" : "thesilenthistory.com"
    } ]
  },
  "geo" : { },
  "id_str" : "269689501163593729",
  "text" : "Caught up on The Silent History. It's an awesome serial-novel-as-iPhone-app and story is great. /via @brianellin  http://t.co/TCYkfjuH",
  "id" : 269689501163593729,
  "created_at" : "2012-11-17 06:32:42 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 103 ],
      "url" : "http://t.co/skHyzbkX",
      "expanded_url" : "http://instagr.am/p/SHty3to0Ik/",
      "display_url" : "instagr.am/p/SHty3to0Ik/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.4436465828, -122.302594185 ]
  },
  "id_str" : "269688470325313536",
  "text" : "8:36pm Landed in Seattle. It's cold.  @ Seattle-Tacoma International Airport (SEA) http://t.co/skHyzbkX",
  "id" : 269688470325313536,
  "created_at" : "2012-11-17 06:28:36 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stewart Butterfield",
      "screen_name" : "stewart",
      "indices" : [ 0, 8 ],
      "id_str" : "5699",
      "id" : 5699
    }, {
      "name" : "Tom Coates",
      "screen_name" : "tomcoates",
      "indices" : [ 9, 19 ],
      "id_str" : "12514",
      "id" : 12514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "269644007091613696",
  "geo" : { },
  "id_str" : "269646509224644608",
  "in_reply_to_user_id" : 5699,
  "text" : "@stewart @tomcoates I think getting wasted cancels out their normal drunken kid brain state, doesn't it?",
  "id" : 269646509224644608,
  "in_reply_to_status_id" : 269644007091613696,
  "created_at" : "2012-11-17 03:41:52 +0000",
  "in_reply_to_screen_name" : "stewart",
  "in_reply_to_user_id_str" : "5699",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Wallerstein",
      "screen_name" : "bwallerstein",
      "indices" : [ 0, 13 ],
      "id_str" : "715148592",
      "id" : 715148592
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "269639300256239618",
  "geo" : { },
  "id_str" : "269641001784717312",
  "in_reply_to_user_id" : 715148592,
  "text" : "@bwallerstein I too disappointed some guys at a restaurant when I came to pick up my order for \"Buster\" yesterday.",
  "id" : 269641001784717312,
  "in_reply_to_status_id" : 269639300256239618,
  "created_at" : "2012-11-17 03:19:59 +0000",
  "in_reply_to_screen_name" : "bwallerstein",
  "in_reply_to_user_id_str" : "715148592",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Ellin",
      "screen_name" : "brianellin",
      "indices" : [ 0, 11 ],
      "id_str" : "26123649",
      "id" : 26123649
    }, {
      "name" : "Seth Bindernagel",
      "screen_name" : "binder",
      "indices" : [ 12, 19 ],
      "id_str" : "1249881",
      "id" : 1249881
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "269636889303187456",
  "geo" : { },
  "id_str" : "269637188801658880",
  "in_reply_to_user_id" : 26123649,
  "text" : "@brianellin @binder Plus, aerodynamics.",
  "id" : 269637188801658880,
  "in_reply_to_status_id" : 269636889303187456,
  "created_at" : "2012-11-17 03:04:50 +0000",
  "in_reply_to_screen_name" : "brianellin",
  "in_reply_to_user_id_str" : "26123649",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Ellin",
      "screen_name" : "brianellin",
      "indices" : [ 0, 11 ],
      "id_str" : "26123649",
      "id" : 26123649
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "269632094962073601",
  "geo" : { },
  "id_str" : "269632808593543168",
  "in_reply_to_user_id" : 26123649,
  "text" : "@brianellin I think that's a purchase that would come in handy on many an occasion.",
  "id" : 269632808593543168,
  "in_reply_to_status_id" : 269632094962073601,
  "created_at" : "2012-11-17 02:47:25 +0000",
  "in_reply_to_screen_name" : "brianellin",
  "in_reply_to_user_id_str" : "26123649",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/buster/status/269632054763868160/photo/1",
      "indices" : [ 122, 142 ],
      "url" : "http://t.co/V3x43i0f",
      "media_url" : "http://pbs.twimg.com/media/A73s7NzCUAAKoC9.jpg",
      "id_str" : "269632054772256768",
      "id" : 269632054772256768,
      "media_url_https" : "https://pbs.twimg.com/media/A73s7NzCUAAKoC9.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com/V3x43i0f"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "269632054763868160",
  "text" : "It's not yellow, cold, or big, but it is soft. &amp; plays into my narrative that we work in the tree outside his window. http://t.co/V3x43i0f",
  "id" : 269632054763868160,
  "created_at" : "2012-11-17 02:44:26 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jake Harding",
      "screen_name" : "JakeHarding",
      "indices" : [ 0, 12 ],
      "id_str" : "58502284",
      "id" : 58502284
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "269630465806319617",
  "geo" : { },
  "id_str" : "269630848674983936",
  "in_reply_to_user_id" : 58502284,
  "text" : "@JakeHarding That would be perfect!",
  "id" : 269630848674983936,
  "in_reply_to_status_id" : 269630465806319617,
  "created_at" : "2012-11-17 02:39:38 +0000",
  "in_reply_to_screen_name" : "JakeHarding",
  "in_reply_to_user_id_str" : "58502284",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Dary",
      "screen_name" : "chrisdary",
      "indices" : [ 3, 13 ],
      "id_str" : "15441990",
      "id" : 15441990
    }, {
      "name" : "Anti-Buster",
      "screen_name" : "busterbenson",
      "indices" : [ 15, 28 ],
      "id_str" : "1024917050",
      "id" : 1024917050
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "269625695288819712",
  "text" : "RT @chrisdary: @busterbenson It\u2019s a code. He wants to put big bird in \u201Cthe cooler\u201D. Your child is a republican.",
  "retweeted_status" : {
    "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Anti-Buster",
        "screen_name" : "busterbenson",
        "indices" : [ 0, 13 ],
        "id_str" : "1024917050",
        "id" : 1024917050
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "269624613036769281",
    "geo" : { },
    "id_str" : "269625394594975744",
    "in_reply_to_user_id" : 2185,
    "text" : "@busterbenson It\u2019s a code. He wants to put big bird in \u201Cthe cooler\u201D. Your child is a republican.",
    "id" : 269625394594975744,
    "in_reply_to_status_id" : 269624613036769281,
    "created_at" : "2012-11-17 02:17:58 +0000",
    "in_reply_to_screen_name" : "buster",
    "in_reply_to_user_id_str" : "2185",
    "user" : {
      "name" : "Chris Dary",
      "screen_name" : "chrisdary",
      "protected" : false,
      "id_str" : "15441990",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1301221689/190134_905827382768_26716007_46525090_4219490_n_normal.jpg",
      "id" : 15441990,
      "verified" : false
    }
  },
  "id" : 269625695288819712,
  "created_at" : "2012-11-17 02:19:09 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael A. Smith",
      "screen_name" : "michaelasmith",
      "indices" : [ 0, 14 ],
      "id_str" : "16609638",
      "id" : 16609638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "269624893941882880",
  "geo" : { },
  "id_str" : "269625215477239808",
  "in_reply_to_user_id" : 16609638,
  "text" : "@michaelasmith That might actually work. Now just need to find an airport store that sells those.",
  "id" : 269625215477239808,
  "in_reply_to_status_id" : 269624893941882880,
  "created_at" : "2012-11-17 02:17:15 +0000",
  "in_reply_to_screen_name" : "michaelasmith",
  "in_reply_to_user_id_str" : "16609638",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael A. Smith",
      "screen_name" : "michaelasmith",
      "indices" : [ 3, 17 ],
      "id_str" : "16609638",
      "id" : 16609638
    }, {
      "name" : "Anti-Buster",
      "screen_name" : "busterbenson",
      "indices" : [ 19, 32 ],
      "id_str" : "1024917050",
      "id" : 1024917050
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "269624975244263425",
  "text" : "RT @michaelasmith: @busterbenson A big-bird popsicle?",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Anti-Buster",
        "screen_name" : "busterbenson",
        "indices" : [ 0, 13 ],
        "id_str" : "1024917050",
        "id" : 1024917050
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "269624613036769281",
    "geo" : { },
    "id_str" : "269624893941882880",
    "in_reply_to_user_id" : 2185,
    "text" : "@busterbenson A big-bird popsicle?",
    "id" : 269624893941882880,
    "in_reply_to_status_id" : 269624613036769281,
    "created_at" : "2012-11-17 02:15:58 +0000",
    "in_reply_to_screen_name" : "buster",
    "in_reply_to_user_id_str" : "2185",
    "user" : {
      "name" : "Michael A. Smith",
      "screen_name" : "michaelasmith",
      "protected" : false,
      "id_str" : "16609638",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1342859557/3274_normal.jpg",
      "id" : 16609638,
      "verified" : false
    }
  },
  "id" : 269624975244263425,
  "created_at" : "2012-11-17 02:16:18 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "269624613036769281",
  "text" : "I asked Niko what kind of present he wanted me to bring back from SF. He said it has to be yellow, soft, cold, and really big. Ideas?",
  "id" : 269624613036769281,
  "created_at" : "2012-11-17 02:14:51 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Wood",
      "screen_name" : "brianwood",
      "indices" : [ 3, 13 ],
      "id_str" : "6477852",
      "id" : 6477852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 113 ],
      "url" : "http://t.co/NTffx3ia",
      "expanded_url" : "http://grist.org/news/if-youre-27-or-younger-youve-never-experienced-a-colder-than-average-month/#.UKbLWSW81QM.twitter",
      "display_url" : "grist.org/news/if-youre-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "269623540943310848",
  "text" : "RT @brianwood: If you\u2019re 27 or younger, you\u2019ve never experienced a colder-than-average month http://t.co/NTffx3ia",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 78, 98 ],
        "url" : "http://t.co/NTffx3ia",
        "expanded_url" : "http://grist.org/news/if-youre-27-or-younger-youve-never-experienced-a-colder-than-average-month/#.UKbLWSW81QM.twitter",
        "display_url" : "grist.org/news/if-youre-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "269582214138839040",
    "text" : "If you\u2019re 27 or younger, you\u2019ve never experienced a colder-than-average month http://t.co/NTffx3ia",
    "id" : 269582214138839040,
    "created_at" : "2012-11-16 23:26:23 +0000",
    "user" : {
      "name" : "Brian Wood",
      "screen_name" : "brianwood",
      "protected" : false,
      "id_str" : "6477852",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1776849855/Screen_Shot_2012-01-23_at_8.31.11_PM_normal.png",
      "id" : 6477852,
      "verified" : false
    }
  },
  "id" : 269623540943310848,
  "created_at" : "2012-11-17 02:10:36 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lettwinkiesdie",
      "indices" : [ 12, 27 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "269611446223130624",
  "text" : "I'm on team #lettwinkiesdie",
  "id" : 269611446223130624,
  "created_at" : "2012-11-17 01:22:32 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyler Stalder",
      "screen_name" : "tylerstalder",
      "indices" : [ 0, 13 ],
      "id_str" : "823408",
      "id" : 823408
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 56 ],
      "url" : "http://t.co/QSDeuBzo",
      "expanded_url" : "http://wizard.evanmiller.org/",
      "display_url" : "wizard.evanmiller.org"
    } ]
  },
  "in_reply_to_status_id_str" : "269609542067826688",
  "geo" : { },
  "id_str" : "269610772345262081",
  "in_reply_to_user_id" : 823408,
  "text" : "@tylerstalder Wizard, free version. http://t.co/QSDeuBzo",
  "id" : 269610772345262081,
  "in_reply_to_status_id" : 269609542067826688,
  "created_at" : "2012-11-17 01:19:51 +0000",
  "in_reply_to_screen_name" : "tylerstalder",
  "in_reply_to_user_id_str" : "823408",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Liene Verzemnieks",
      "screen_name" : "li3n3",
      "indices" : [ 10, 16 ],
      "id_str" : "498467901",
      "id" : 498467901
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/li3n3/status/269546342676828160/photo/1",
      "indices" : [ 120, 140 ],
      "url" : "http://t.co/vGbGNf9U",
      "media_url" : "http://pbs.twimg.com/media/A72e-HYCEAE46eu.jpg",
      "id_str" : "269546342681022465",
      "id" : 269546342681022465,
      "media_url_https" : "https://pbs.twimg.com/media/A72e-HYCEAE46eu.jpg",
      "sizes" : [ {
        "h" : 114,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 46,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 114,
        "resize" : "fit",
        "w" : 835
      }, {
        "h" : 114,
        "resize" : "fit",
        "w" : 835
      }, {
        "h" : 82,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com/vGbGNf9U"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 119 ],
      "url" : "http://t.co/3WM7QkQe",
      "expanded_url" : "http://750words.com/entries/share/2163248",
      "display_url" : "750words.com/entries/share/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "269553826678337536",
  "text" : "Woah!! RT @li3n3: Now this is just absurd: I wrote 772 words in 9 minutes (1000 day streak) (!!!): http://t.co/3WM7QkQe http://t.co/vGbGNf9U",
  "id" : 269553826678337536,
  "created_at" : "2012-11-16 21:33:35 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ciaran Lyons",
      "screen_name" : "crayonlions",
      "indices" : [ 0, 12 ],
      "id_str" : "231087644",
      "id" : 231087644
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "269414894783315968",
  "geo" : { },
  "id_str" : "269516282058129408",
  "in_reply_to_user_id" : 231087644,
  "text" : "@crayonlions Yes and that app is totally going to replace my other counter. Thanks!",
  "id" : 269516282058129408,
  "in_reply_to_status_id" : 269414894783315968,
  "created_at" : "2012-11-16 19:04:23 +0000",
  "in_reply_to_screen_name" : "crayonlions",
  "in_reply_to_user_id_str" : "231087644",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "erin moore",
      "screen_name" : "emoore",
      "indices" : [ 0, 7 ],
      "id_str" : "23640904",
      "id" : 23640904
    }, {
      "name" : "Brian Ellin",
      "screen_name" : "brianellin",
      "indices" : [ 8, 19 ],
      "id_str" : "26123649",
      "id" : 26123649
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "269336481460547584",
  "geo" : { },
  "id_str" : "269511325527461888",
  "in_reply_to_user_id" : 23640904,
  "text" : "@emoore @brianellin I endorse this idea.",
  "id" : 269511325527461888,
  "in_reply_to_status_id" : 269336481460547584,
  "created_at" : "2012-11-16 18:44:41 +0000",
  "in_reply_to_screen_name" : "emoore",
  "in_reply_to_user_id_str" : "23640904",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ash bhoopathy",
      "screen_name" : "ashbhoopathy",
      "indices" : [ 3, 16 ],
      "id_str" : "19888257",
      "id" : 19888257
    }, {
      "name" : "Harper",
      "screen_name" : "harper",
      "indices" : [ 18, 25 ],
      "id_str" : "1497",
      "id" : 1497
    }, {
      "name" : "Chirag Patel",
      "screen_name" : "patelc75",
      "indices" : [ 26, 35 ],
      "id_str" : "16320459",
      "id" : 16320459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http://t.co/8C2DS6Mx",
      "expanded_url" : "http://www.theatlantic.com/technology/archive/2012/11/when-the-nerds-go-marching-in/265325/",
      "display_url" : "theatlantic.com/technology/arc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "269498448401793024",
  "text" : "RT @ashbhoopathy: @harper @patelc75 Congrats again guys, you guys are more allstars of the campaign than Nate Silver: http://t.co/8C2DS6Mx",
  "retweeted_status" : {
    "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Harper",
        "screen_name" : "harper",
        "indices" : [ 0, 7 ],
        "id_str" : "1497",
        "id" : 1497
      }, {
        "name" : "Chirag Patel",
        "screen_name" : "patelc75",
        "indices" : [ 8, 17 ],
        "id_str" : "16320459",
        "id" : 16320459
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 100, 120 ],
        "url" : "http://t.co/8C2DS6Mx",
        "expanded_url" : "http://www.theatlantic.com/technology/archive/2012/11/when-the-nerds-go-marching-in/265325/",
        "display_url" : "theatlantic.com/technology/arc\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "269490744069332992",
    "in_reply_to_user_id" : 1497,
    "text" : "@harper @patelc75 Congrats again guys, you guys are more allstars of the campaign than Nate Silver: http://t.co/8C2DS6Mx",
    "id" : 269490744069332992,
    "created_at" : "2012-11-16 17:22:54 +0000",
    "in_reply_to_screen_name" : "harper",
    "in_reply_to_user_id_str" : "1497",
    "user" : {
      "name" : "ash bhoopathy",
      "screen_name" : "ashbhoopathy",
      "protected" : false,
      "id_str" : "19888257",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/691551057/22bba73_normal.jpg",
      "id" : 19888257,
      "verified" : false
    }
  },
  "id" : 269498448401793024,
  "created_at" : "2012-11-16 17:53:31 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "erin moore",
      "screen_name" : "emoore",
      "indices" : [ 0, 7 ],
      "id_str" : "23640904",
      "id" : 23640904
    }, {
      "name" : "Brian Ellin",
      "screen_name" : "brianellin",
      "indices" : [ 24, 35 ],
      "id_str" : "26123649",
      "id" : 26123649
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "269316864184815616",
  "geo" : { },
  "id_str" : "269331681272557569",
  "in_reply_to_user_id" : 23640904,
  "text" : "@emoore Hotel Biron, on @brianellin's recommendation. It was warm and cozy and had good art on the walls.",
  "id" : 269331681272557569,
  "in_reply_to_status_id" : 269316864184815616,
  "created_at" : "2012-11-16 06:50:51 +0000",
  "in_reply_to_screen_name" : "emoore",
  "in_reply_to_user_id_str" : "23640904",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ross Hill",
      "screen_name" : "rosshill",
      "indices" : [ 0, 9 ],
      "id_str" : "7092172",
      "id" : 7092172
    }, {
      "name" : "Fitbit",
      "screen_name" : "fitbit",
      "indices" : [ 67, 74 ],
      "id_str" : "17424053",
      "id" : 17424053
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "269329192150245376",
  "geo" : { },
  "id_str" : "269331218246553600",
  "in_reply_to_user_id" : 7092172,
  "text" : "@rosshill That's awesome. Still enjoying my setup. Make sure we're @fitbit friends when you set it up.",
  "id" : 269331218246553600,
  "in_reply_to_status_id" : 269329192150245376,
  "created_at" : "2012-11-16 06:49:01 +0000",
  "in_reply_to_screen_name" : "rosshill",
  "in_reply_to_user_id_str" : "7092172",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Foursquare",
      "screen_name" : "foursquare",
      "indices" : [ 46, 57 ],
      "id_str" : "14120151",
      "id" : 14120151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 123 ],
      "url" : "http://t.co/mh59cdYV",
      "expanded_url" : "http://4sq.com/TQG91T",
      "display_url" : "4sq.com/TQG91T"
    } ]
  },
  "geo" : { },
  "id_str" : "269306534381637633",
  "text" : "I just reached Level 3 of the \"Wino\" badge on @foursquare. I\u2019ve checked in at 10 different wine spots! http://t.co/mh59cdYV",
  "id" : 269306534381637633,
  "created_at" : "2012-11-16 05:10:55 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "that drew",
      "screen_name" : "thatdrew",
      "indices" : [ 3, 12 ],
      "id_str" : "1002913782",
      "id" : 1002913782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 117 ],
      "url" : "http://t.co/0XUwGdwO",
      "expanded_url" : "http://tcrn.ch/RGk9qo",
      "display_url" : "tcrn.ch/RGk9qo"
    } ]
  },
  "geo" : { },
  "id_str" : "269304728452743169",
  "text" : "RT @thatdrew: Ev Williams Takes To Medium To Discuss The True Purpose Of His New Publishing Tool http://t.co/0XUwGdwO",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 83, 103 ],
        "url" : "http://t.co/0XUwGdwO",
        "expanded_url" : "http://tcrn.ch/RGk9qo",
        "display_url" : "tcrn.ch/RGk9qo"
      } ]
    },
    "geo" : { },
    "id_str" : "269298814807048193",
    "text" : "Ev Williams Takes To Medium To Discuss The True Purpose Of His New Publishing Tool http://t.co/0XUwGdwO",
    "id" : 269298814807048193,
    "created_at" : "2012-11-16 04:40:15 +0000",
    "user" : {
      "name" : "drew olanoff",
      "screen_name" : "drew",
      "protected" : false,
      "id_str" : "10221",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000408023956/1710cffecc76204b31adeee75c2bbbe9_normal.jpeg",
      "id" : 10221,
      "verified" : false
    }
  },
  "id" : 269304728452743169,
  "created_at" : "2012-11-16 05:03:45 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 83 ],
      "url" : "http://t.co/B9cJXoOz",
      "expanded_url" : "http://instagr.am/p/SE8rxko0Cn/",
      "display_url" : "instagr.am/p/SE8rxko0Cn/"
    } ]
  },
  "geo" : { },
  "id_str" : "269298929139585026",
  "text" : "8:36pm Just left Ali and Todd's. Look at this zonked out dude. http://t.co/B9cJXoOz",
  "id" : 269298929139585026,
  "created_at" : "2012-11-16 04:40:42 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ali Berman",
      "screen_name" : "spangley",
      "indices" : [ 4, 13 ],
      "id_str" : "776429",
      "id" : 776429
    }, {
      "name" : "Todd Berman",
      "screen_name" : "tberman",
      "indices" : [ 18, 26 ],
      "id_str" : "15275073",
      "id" : 15275073
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lildude",
      "indices" : [ 29, 37 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 112 ],
      "url" : "http://t.co/mYiSWG6p",
      "expanded_url" : "http://instagr.am/p/SE51euo0Ao/",
      "display_url" : "instagr.am/p/SE51euo0Ao/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7546319182, -122.429736901 ]
  },
  "id_str" : "269292684596887553",
  "text" : "Met @spangley and @tberman's #lildude and even got him to laugh! So lovely.  @ Copacaberman http://t.co/mYiSWG6p",
  "id" : 269292684596887553,
  "created_at" : "2012-11-16 04:15:53 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Foursquare",
      "screen_name" : "foursquare",
      "indices" : [ 40, 51 ],
      "id_str" : "14120151",
      "id" : 14120151
    }, {
      "name" : "Dennis Crowley",
      "screen_name" : "dens",
      "indices" : [ 72, 77 ],
      "id_str" : "418",
      "id" : 418
    }, {
      "name" : "naveen",
      "screen_name" : "naveen",
      "indices" : [ 84, 91 ],
      "id_str" : "5215",
      "id" : 5215
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http://t.co/kGRpjDi8",
      "expanded_url" : "http://bit.ly/TMtehg",
      "display_url" : "bit.ly/TMtehg"
    } ]
  },
  "geo" : { },
  "id_str" : "269243443354669056",
  "text" : "Rad. Still getting better every day! RT @foursquare: 4 years ago today, @dens &amp; @naveen presented the 1st prototype http://t.co/kGRpjDi8",
  "id" : 269243443354669056,
  "created_at" : "2012-11-16 01:00:13 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "269230947327692800",
  "text" : "Update yr Twitter appz! Cards are now in the Discover tab and looking pretty sweet.",
  "id" : 269230947327692800,
  "created_at" : "2012-11-16 00:10:34 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://bufferapp.com\" rel=\"nofollow\">Buffer</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "that drew",
      "screen_name" : "thatdrew",
      "indices" : [ 113, 122 ],
      "id_str" : "1002913782",
      "id" : 1002913782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 123, 143 ],
      "url" : "http://t.co/0nUbIfax",
      "expanded_url" : "http://tcrn.ch/Wc1hns",
      "display_url" : "tcrn.ch/Wc1hns"
    } ]
  },
  "geo" : { },
  "id_str" : "269229377424879617",
  "text" : "\"Twitter Breathes More Life And Context Into Search, Discover And Apps With Media First, Headlines &amp; More\" - @thatdrew http://t.co/0nUbIfax",
  "id" : 269229377424879617,
  "created_at" : "2012-11-16 00:04:20 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dick costolo",
      "screen_name" : "dickc",
      "indices" : [ 3, 9 ],
      "id_str" : "6385432",
      "id" : 6385432
    }, {
      "name" : "Ricky Gervais",
      "screen_name" : "rickygervais",
      "indices" : [ 11, 24 ],
      "id_str" : "20015311",
      "id" : 20015311
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "269200205117792257",
  "text" : "RT @dickc: @rickygervais mother always told me that being verified on the INSIDE is what counts.",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ricky Gervais",
        "screen_name" : "rickygervais",
        "indices" : [ 0, 13 ],
        "id_str" : "20015311",
        "id" : 20015311
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "269183521388650496",
    "geo" : { },
    "id_str" : "269190153447276544",
    "in_reply_to_user_id" : 20015311,
    "text" : "@rickygervais mother always told me that being verified on the INSIDE is what counts.",
    "id" : 269190153447276544,
    "in_reply_to_status_id" : 269183521388650496,
    "created_at" : "2012-11-15 21:28:28 +0000",
    "in_reply_to_screen_name" : "rickygervais",
    "in_reply_to_user_id_str" : "20015311",
    "user" : {
      "name" : "dick costolo",
      "screen_name" : "dickc",
      "protected" : false,
      "id_str" : "6385432",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2370238025/6powh39olczriflspmnc_normal.jpeg",
      "id" : 6385432,
      "verified" : false
    }
  },
  "id" : 269200205117792257,
  "created_at" : "2012-11-15 22:08:25 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"https://findings.com\" rel=\"nofollow\">Findings</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Memoto",
      "screen_name" : "Memototeam",
      "indices" : [ 88, 99 ],
      "id_str" : "527334899",
      "id" : 527334899
    }, {
      "name" : "Findings",
      "screen_name" : "findings",
      "indices" : [ 104, 113 ],
      "id_str" : "208197274",
      "id" : 208197274
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http://t.co/6xbMonB8",
      "expanded_url" : "http://fnd.gs/W9ZmLy",
      "display_url" : "fnd.gs/W9ZmLy"
    } ]
  },
  "geo" : { },
  "id_str" : "269192653965520896",
  "text" : "\"In a few years just about everyone will have access to a wearable automatic camera.\" - @memototeam via @findings - http://t.co/6xbMonB8",
  "id" : 269192653965520896,
  "created_at" : "2012-11-15 21:38:24 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 51 ],
      "url" : "http://t.co/Up3QIGrZ",
      "expanded_url" : "http://instagr.am/p/SDwXDzo0J6/",
      "display_url" : "instagr.am/p/SDwXDzo0J6/"
    } ]
  },
  "geo" : { },
  "id_str" : "269131049311797248",
  "text" : "Bathtub time machine (2 years) http://t.co/Up3QIGrZ",
  "id" : 269131049311797248,
  "created_at" : "2012-11-15 17:33:37 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "clickhere",
      "indices" : [ 48, 58 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "269122024281104384",
  "text" : "Top 10 Spirit Animals of Successful Tricksters. #clickhere",
  "id" : 269122024281104384,
  "created_at" : "2012-11-15 16:57:45 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Muse",
      "screen_name" : "michaelmuse",
      "indices" : [ 3, 15 ],
      "id_str" : "14129087",
      "id" : 14129087
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 94 ],
      "url" : "http://t.co/v1Nt6fAF",
      "expanded_url" : "http://bit.ly/QIZO6J",
      "display_url" : "bit.ly/QIZO6J"
    } ]
  },
  "geo" : { },
  "id_str" : "269108321796096001",
  "text" : "RT @michaelmuse: Awesome defense of MTV not playing music videos anymore: http://t.co/v1Nt6fAF",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 57, 77 ],
        "url" : "http://t.co/v1Nt6fAF",
        "expanded_url" : "http://bit.ly/QIZO6J",
        "display_url" : "bit.ly/QIZO6J"
      } ]
    },
    "geo" : { },
    "id_str" : "269099092355981312",
    "text" : "Awesome defense of MTV not playing music videos anymore: http://t.co/v1Nt6fAF",
    "id" : 269099092355981312,
    "created_at" : "2012-11-15 15:26:37 +0000",
    "user" : {
      "name" : "Michael Muse",
      "screen_name" : "michaelmuse",
      "protected" : false,
      "id_str" : "14129087",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/344513261574916663/54e0600e7f3cd841d51c89707c5e1f49_normal.jpeg",
      "id" : 14129087,
      "verified" : false
    }
  },
  "id" : 269108321796096001,
  "created_at" : "2012-11-15 16:03:18 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sulthana",
      "screen_name" : "iSulthana",
      "indices" : [ 4, 14 ],
      "id_str" : "236199087",
      "id" : 236199087
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "269003182049472513",
  "text" : "Pay @iSulthana $1 for complaining about the suckiness of spreadsheets on mobile.",
  "id" : 269003182049472513,
  "created_at" : "2012-11-15 09:05:31 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emilio Ramirez",
      "screen_name" : "e_ramirez",
      "indices" : [ 0, 10 ],
      "id_str" : "1273564632",
      "id" : 1273564632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "268980429938384896",
  "geo" : { },
  "id_str" : "268980706317832192",
  "in_reply_to_user_id" : 21135674,
  "text" : "@e_ramirez I disagree that it works well. All the ease of input is lost. I think a mobile spreadsheet would have more multitouch actions.",
  "id" : 268980706317832192,
  "in_reply_to_status_id" : 268980429938384896,
  "created_at" : "2012-11-15 07:36:12 +0000",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "268978119585701889",
  "text" : "I love spreadsheets. As far as simplicity, speed of input, and flexibility are concerned... pretty much perfect. But they suck on mobile.",
  "id" : 268978119585701889,
  "created_at" : "2012-11-15 07:25:55 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Gomez",
      "screen_name" : "GomezJames",
      "indices" : [ 0, 11 ],
      "id_str" : "237491876",
      "id" : 237491876
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "268971991262957569",
  "geo" : { },
  "id_str" : "268974179766910976",
  "in_reply_to_user_id" : 237491876,
  "text" : "@GomezJames Having an alarm and an exact minute might actually make it easier. Then the photos don't have to be interesting...",
  "id" : 268974179766910976,
  "in_reply_to_status_id" : 268971991262957569,
  "created_at" : "2012-11-15 07:10:16 +0000",
  "in_reply_to_screen_name" : "GomezJames",
  "in_reply_to_user_id_str" : "237491876",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Gomez",
      "screen_name" : "GomezJames",
      "indices" : [ 0, 11 ],
      "id_str" : "237491876",
      "id" : 237491876
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "268968905790328832",
  "geo" : { },
  "id_str" : "268970066169712640",
  "in_reply_to_user_id" : 237491876,
  "text" : "@GomezJames I just post as soon as the movie's over.",
  "id" : 268970066169712640,
  "in_reply_to_status_id" : 268968905790328832,
  "created_at" : "2012-11-15 06:53:55 +0000",
  "in_reply_to_screen_name" : "GomezJames",
  "in_reply_to_user_id_str" : "237491876",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "j_jane",
      "screen_name" : "j_jane",
      "indices" : [ 0, 7 ],
      "id_str" : "16032262",
      "id" : 16032262
    }, {
      "name" : "Chris Sacca",
      "screen_name" : "sacca",
      "indices" : [ 8, 14 ],
      "id_str" : "586",
      "id" : 586
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "268967237413662720",
  "geo" : { },
  "id_str" : "268968585416802304",
  "in_reply_to_user_id" : 16032262,
  "text" : "@j_jane @sacca I tried that too but the first few months of sleep deprivation broke me and I fell off the wagon. Much respect to you.",
  "id" : 268968585416802304,
  "in_reply_to_status_id" : 268967237413662720,
  "created_at" : "2012-11-15 06:48:02 +0000",
  "in_reply_to_screen_name" : "j_jane",
  "in_reply_to_user_id_str" : "16032262",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "josh",
      "screen_name" : "joshc",
      "indices" : [ 0, 6 ],
      "id_str" : "2015",
      "id" : 2015
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "268961522133381120",
  "geo" : { },
  "id_str" : "268961887184637952",
  "in_reply_to_user_id" : 2015,
  "text" : "@joshc What would central command do that splinter cells can't?",
  "id" : 268961887184637952,
  "in_reply_to_status_id" : 268961522133381120,
  "created_at" : "2012-11-15 06:21:25 +0000",
  "in_reply_to_screen_name" : "joshc",
  "in_reply_to_user_id_str" : "2015",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "josh",
      "screen_name" : "joshc",
      "indices" : [ 0, 6 ],
      "id_str" : "2015",
      "id" : 2015
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "anarchyftw",
      "indices" : [ 114, 125 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "268960819209965568",
  "geo" : { },
  "id_str" : "268961199868215296",
  "in_reply_to_user_id" : 2015,
  "text" : "@joshc Yeah, but then I realized that it was more fun as a decentralized project. Everyone can make it their own. #anarchyftw",
  "id" : 268961199868215296,
  "in_reply_to_status_id" : 268960819209965568,
  "created_at" : "2012-11-15 06:18:41 +0000",
  "in_reply_to_screen_name" : "joshc",
  "in_reply_to_user_id_str" : "2015",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sara J Chippstar",
      "screen_name" : "iano",
      "indices" : [ 0, 5 ],
      "id_str" : "14409856",
      "id" : 14409856
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "268952285441302528",
  "geo" : { },
  "id_str" : "268952715336503296",
  "in_reply_to_user_id" : 14409856,
  "text" : "@iano It used to be.",
  "id" : 268952715336503296,
  "in_reply_to_status_id" : 268952285441302528,
  "created_at" : "2012-11-15 05:44:58 +0000",
  "in_reply_to_screen_name" : "iano",
  "in_reply_to_user_id_str" : "14409856",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jackson Latka",
      "screen_name" : "jacksonlatka",
      "indices" : [ 0, 13 ],
      "id_str" : "10022442",
      "id" : 10022442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "268951821534515200",
  "geo" : { },
  "id_str" : "268952614169894912",
  "in_reply_to_user_id" : 10022442,
  "text" : "@jacksonlatka That is a lot. I tried to do that when my son was born and failed. So well done!",
  "id" : 268952614169894912,
  "in_reply_to_status_id" : 268951821534515200,
  "created_at" : "2012-11-15 05:44:34 +0000",
  "in_reply_to_screen_name" : "jacksonlatka",
  "in_reply_to_user_id_str" : "10022442",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Liene Verzemnieks",
      "screen_name" : "li3n3",
      "indices" : [ 0, 6 ],
      "id_str" : "498467901",
      "id" : 498467901
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "268950174343258113",
  "geo" : { },
  "id_str" : "268950386893795329",
  "in_reply_to_user_id" : 498467901,
  "text" : "@li3n3 Yup, some things just stick. And some don't. It's a magical mystery to me still.",
  "id" : 268950386893795329,
  "in_reply_to_status_id" : 268950174343258113,
  "created_at" : "2012-11-15 05:35:43 +0000",
  "in_reply_to_screen_name" : "li3n3",
  "in_reply_to_user_id_str" : "498467901",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Liene Verzemnieks",
      "screen_name" : "li3n3",
      "indices" : [ 0, 6 ],
      "id_str" : "498467901",
      "id" : 498467901
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "268949696939167744",
  "geo" : { },
  "id_str" : "268949879513034752",
  "in_reply_to_user_id" : 498467901,
  "text" : "@li3n3 Yeah! Do it!",
  "id" : 268949879513034752,
  "in_reply_to_status_id" : 268949696939167744,
  "created_at" : "2012-11-15 05:33:42 +0000",
  "in_reply_to_screen_name" : "li3n3",
  "in_reply_to_user_id_str" : "498467901",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Liene Verzemnieks",
      "screen_name" : "li3n3",
      "indices" : [ 0, 6 ],
      "id_str" : "498467901",
      "id" : 498467901
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "268949357133451265",
  "geo" : { },
  "id_str" : "268949706594476033",
  "in_reply_to_user_id" : 498467901,
  "text" : "@li3n3 Yeah, that kind of thing should be a lot easier than it currently is. I'm sure someone will solve that in the next year or two tho.",
  "id" : 268949706594476033,
  "in_reply_to_status_id" : 268949357133451265,
  "created_at" : "2012-11-15 05:33:01 +0000",
  "in_reply_to_screen_name" : "li3n3",
  "in_reply_to_user_id_str" : "498467901",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcel Molina",
      "screen_name" : "noradio",
      "indices" : [ 0, 8 ],
      "id_str" : "3191321",
      "id" : 3191321
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "268948760002977792",
  "geo" : { },
  "id_str" : "268949161771167746",
  "in_reply_to_user_id" : 3191321,
  "text" : "@noradio Oh man, that's true. When I first started, posting photos to Twitter was tough. Now taking physical photos is tough. Crazy times.",
  "id" : 268949161771167746,
  "in_reply_to_status_id" : 268948760002977792,
  "created_at" : "2012-11-15 05:30:51 +0000",
  "in_reply_to_screen_name" : "noradio",
  "in_reply_to_user_id_str" : "3191321",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Liene Verzemnieks",
      "screen_name" : "li3n3",
      "indices" : [ 0, 6 ],
      "id_str" : "498467901",
      "id" : 498467901
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "268948421325508608",
  "geo" : { },
  "id_str" : "268948797386788866",
  "in_reply_to_user_id" : 498467901,
  "text" : "@li3n3 What do you mean easy to collect? With Instagram (or even just Twitter photos) it couldn't be easier.",
  "id" : 268948797386788866,
  "in_reply_to_status_id" : 268948421325508608,
  "created_at" : "2012-11-15 05:29:24 +0000",
  "in_reply_to_screen_name" : "li3n3",
  "in_reply_to_user_id_str" : "498467901",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcel Molina",
      "screen_name" : "noradio",
      "indices" : [ 0, 8 ],
      "id_str" : "3191321",
      "id" : 3191321
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "268948055737372674",
  "geo" : { },
  "id_str" : "268948575130628096",
  "in_reply_to_user_id" : 3191321,
  "text" : "@noradio Maybe do it every 12 years?",
  "id" : 268948575130628096,
  "in_reply_to_status_id" : 268948055737372674,
  "created_at" : "2012-11-15 05:28:31 +0000",
  "in_reply_to_screen_name" : "noradio",
  "in_reply_to_user_id_str" : "3191321",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcel Molina",
      "screen_name" : "noradio",
      "indices" : [ 0, 8 ],
      "id_str" : "3191321",
      "id" : 3191321
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "268946154975277056",
  "geo" : { },
  "id_str" : "268947355078885376",
  "in_reply_to_user_id" : 3191321,
  "text" : "@noradio That's awesome. Would you do it again?",
  "id" : 268947355078885376,
  "in_reply_to_status_id" : 268946154975277056,
  "created_at" : "2012-11-15 05:23:40 +0000",
  "in_reply_to_screen_name" : "noradio",
  "in_reply_to_user_id_str" : "3191321",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jana Kleitsch",
      "screen_name" : "janakphoto",
      "indices" : [ 0, 11 ],
      "id_str" : "72998610",
      "id" : 72998610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "268942940758474752",
  "geo" : { },
  "id_str" : "268943329373323265",
  "in_reply_to_user_id" : 72998610,
  "text" : "@janakphoto Thanks. Gonna fall asleep in my hotel room any second now...",
  "id" : 268943329373323265,
  "in_reply_to_status_id" : 268942940758474752,
  "created_at" : "2012-11-15 05:07:41 +0000",
  "in_reply_to_screen_name" : "janakphoto",
  "in_reply_to_user_id_str" : "72998610",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RyanK",
      "screen_name" : "RyanK",
      "indices" : [ 0, 6 ],
      "id_str" : "702043",
      "id" : 702043
    }, {
      "name" : "Chadwick Dahlquist",
      "screen_name" : "bugeats",
      "indices" : [ 30, 38 ],
      "id_str" : "9074342",
      "id" : 9074342
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 78 ],
      "url" : "https://t.co/Ozo9dqwS",
      "expanded_url" : "https://twitter.com/bugeats/statuses/810771610",
      "display_url" : "twitter.com/bugeats/status\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "268941673969623040",
  "geo" : { },
  "id_str" : "268942028132466688",
  "in_reply_to_user_id" : 702043,
  "text" : "@RyanK It was the minute that @bugeats used for a week. (https://t.co/Ozo9dqwS) It's as good a minute as any.",
  "id" : 268942028132466688,
  "in_reply_to_status_id" : 268941673969623040,
  "created_at" : "2012-11-15 05:02:30 +0000",
  "in_reply_to_screen_name" : "RyanK",
  "in_reply_to_user_id_str" : "702043",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ron Diver",
      "screen_name" : "rondiver",
      "indices" : [ 0, 9 ],
      "id_str" : "12661782",
      "id" : 12661782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "268941022334156800",
  "geo" : { },
  "id_str" : "268941470139027457",
  "in_reply_to_user_id" : 12661782,
  "text" : "@rondiver Maybe you should start paying for forgetfulness. :)",
  "id" : 268941470139027457,
  "in_reply_to_status_id" : 268941022334156800,
  "created_at" : "2012-11-15 05:00:17 +0000",
  "in_reply_to_screen_name" : "rondiver",
  "in_reply_to_user_id_str" : "12661782",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Becky Jewell",
      "screen_name" : "beckyjewell",
      "indices" : [ 0, 12 ],
      "id_str" : "26406166",
      "id" : 26406166
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "268940159238668288",
  "geo" : { },
  "id_str" : "268940639159320577",
  "in_reply_to_user_id" : 26406166,
  "text" : "@beckyjewell Thanks! I borrowed it from others but have found it to be one of the most rewarding little daily rituals.",
  "id" : 268940639159320577,
  "in_reply_to_status_id" : 268940159238668288,
  "created_at" : "2012-11-15 04:56:59 +0000",
  "in_reply_to_screen_name" : "beckyjewell",
  "in_reply_to_user_id_str" : "26406166",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ron Diver",
      "screen_name" : "rondiver",
      "indices" : [ 0, 9 ],
      "id_str" : "12661782",
      "id" : 12661782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 58 ],
      "url" : "http://t.co/fyS6pFNv",
      "expanded_url" : "http://wayoftheduck.com/1-for-you",
      "display_url" : "wayoftheduck.com/1-for-you"
    } ]
  },
  "in_reply_to_status_id_str" : "268939937267720193",
  "geo" : { },
  "id_str" : "268940227467415552",
  "in_reply_to_user_id" : 12661782,
  "text" : "@rondiver It's just a fun experiment: http://t.co/fyS6pFNv",
  "id" : 268940227467415552,
  "in_reply_to_status_id" : 268939937267720193,
  "created_at" : "2012-11-15 04:55:21 +0000",
  "in_reply_to_screen_name" : "rondiver",
  "in_reply_to_user_id_str" : "12661782",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 114 ],
      "url" : "https://t.co/KHcDDs9F",
      "expanded_url" : "https://twitter.com/search?q=8%3A36pm%20OR%20%228%3A36%20pm%22",
      "display_url" : "twitter.com/search?q=8%3A3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "268939900370440192",
  "text" : "And here are a bunch of other people who have been playing along for years. You should join: https://t.co/KHcDDs9F",
  "id" : 268939900370440192,
  "created_at" : "2012-11-15 04:54:03 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http://t.co/LuHmv0Jt",
      "expanded_url" : "http://www.geekwire.com/2012/day-rest-life/",
      "display_url" : "geekwire.com/2012/day-rest-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "268939373955936256",
  "text" : "For everyone that has no idea why I post a picture at 8:36pm every day, here's a post I wrote on the 4yr anniversary: http://t.co/LuHmv0Jt",
  "id" : 268939373955936256,
  "created_at" : "2012-11-15 04:51:58 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Reichhold",
      "screen_name" : "jreichhold",
      "indices" : [ 0, 11 ],
      "id_str" : "14934401",
      "id" : 14934401
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "268938501880438784",
  "geo" : { },
  "id_str" : "268938731241742336",
  "in_reply_to_user_id" : 14934401,
  "text" : "@jreichhold Yeah. Hey and you're down early!",
  "id" : 268938731241742336,
  "in_reply_to_status_id" : 268938501880438784,
  "created_at" : "2012-11-15 04:49:24 +0000",
  "in_reply_to_screen_name" : "jreichhold",
  "in_reply_to_user_id_str" : "14934401",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan",
      "screen_name" : "ressler",
      "indices" : [ 4, 12 ],
      "id_str" : "7191062",
      "id" : 7191062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "268938136032268288",
  "geo" : { },
  "id_str" : "268938518796046336",
  "in_reply_to_user_id" : 7191062,
  "text" : "Pay @ressler $1 for complaining about being sick. Good call.",
  "id" : 268938518796046336,
  "in_reply_to_status_id" : 268938136032268288,
  "created_at" : "2012-11-15 04:48:34 +0000",
  "in_reply_to_screen_name" : "ressler",
  "in_reply_to_user_id_str" : "7191062",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 77 ],
      "url" : "http://t.co/JJBEzyg3",
      "expanded_url" : "http://flic.kr/p/dtvk9y",
      "display_url" : "flic.kr/p/dtvk9y"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.773666, -122.421667 ]
  },
  "id_str" : "268938052162965504",
  "text" : "8:36pm Sick of being sick. Exhausted of being exhausted. http://t.co/JJBEzyg3",
  "id" : 268938052162965504,
  "created_at" : "2012-11-15 04:46:42 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robi Ganguly",
      "screen_name" : "rganguly",
      "indices" : [ 0, 9 ],
      "id_str" : "622663",
      "id" : 622663
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "268932118187479040",
  "geo" : { },
  "id_str" : "268933595559780352",
  "in_reply_to_user_id" : 622663,
  "text" : "@rganguly I have played it on and off throughout the beta, yeah. Not only was it gorgeous, but the game-building tech was amazing as well.",
  "id" : 268933595559780352,
  "in_reply_to_status_id" : 268932118187479040,
  "created_at" : "2012-11-15 04:29:00 +0000",
  "in_reply_to_screen_name" : "rganguly",
  "in_reply_to_user_id_str" : "622663",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glitch, the game",
      "screen_name" : "playglitch",
      "indices" : [ 53, 64 ],
      "id_str" : "103943240",
      "id" : 103943240
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 124, 144 ],
      "url" : "http://t.co/2cZauBdm",
      "expanded_url" : "http://www.glitch.com/closing/",
      "display_url" : "glitch.com/closing/"
    } ]
  },
  "geo" : { },
  "id_str" : "268925384119156736",
  "text" : "Much love, respect, &amp; sadness, Tiny Speckers. RT @playglitch: Sometimes you try your hardest and it still doesn't work. http://t.co/2cZauBdm",
  "id" : 268925384119156736,
  "created_at" : "2012-11-15 03:56:22 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bees",
      "screen_name" : "hallstorm",
      "indices" : [ 0, 10 ],
      "id_str" : "249876633",
      "id" : 249876633
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "268908009881739265",
  "geo" : { },
  "id_str" : "268910424467046403",
  "in_reply_to_user_id" : 249876633,
  "text" : "@hallstorm Yeah the database is apparently down. Thanks for letting me know! Submitted a ticket to my web host... hope it's fixed soon!",
  "id" : 268910424467046403,
  "in_reply_to_status_id" : 268908009881739265,
  "created_at" : "2012-11-15 02:56:55 +0000",
  "in_reply_to_screen_name" : "hallstorm",
  "in_reply_to_user_id_str" : "249876633",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Foursquare",
      "screen_name" : "foursquare",
      "indices" : [ 51, 62 ],
      "id_str" : "14120151",
      "id" : 14120151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 130 ],
      "url" : "http://t.co/DuWEGnPp",
      "expanded_url" : "http://4sq.com/TKey28",
      "display_url" : "4sq.com/TKey28"
    } ]
  },
  "geo" : { },
  "id_str" : "268907577088282625",
  "text" : "I just reached Level 4 of the \"Pizzaiolo\" badge on @foursquare. I\u2019ve checked in at 15 different pizza joints! http://t.co/DuWEGnPp",
  "id" : 268907577088282625,
  "created_at" : "2012-11-15 02:45:37 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bees",
      "screen_name" : "hallstorm",
      "indices" : [ 0, 10 ],
      "id_str" : "249876633",
      "id" : 249876633
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 44 ],
      "url" : "http://t.co/Bb1p0svp",
      "expanded_url" : "http://bit.ly/NxOJUj",
      "display_url" : "bit.ly/NxOJUj"
    } ]
  },
  "in_reply_to_status_id_str" : "268890524717572096",
  "geo" : { },
  "id_str" : "268895097452634113",
  "in_reply_to_user_id" : 249876633,
  "text" : "@hallstorm Still alive! http://t.co/Bb1p0svp (let me know if you're having any troubles getting there.)",
  "id" : 268895097452634113,
  "in_reply_to_status_id" : 268890524717572096,
  "created_at" : "2012-11-15 01:56:01 +0000",
  "in_reply_to_screen_name" : "hallstorm",
  "in_reply_to_user_id_str" : "249876633",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Williams",
      "screen_name" : "ev",
      "indices" : [ 3, 6 ],
      "id_str" : "20",
      "id" : 20
    }, {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 81, 89 ],
      "id_str" : "783214",
      "id" : 783214
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 69 ],
      "url" : "http://t.co/1jGoYBP5",
      "expanded_url" : "http://medium.com",
      "display_url" : "medium.com"
    } ]
  },
  "geo" : { },
  "id_str" : "268863694774091777",
  "text" : "RT @ev: Pssst...if you work Twitter: Register on http://t.co/1jGoYBP5 using your @twitter.com email, and you can post stuff. Thanks.",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Twitter",
        "screen_name" : "twitter",
        "indices" : [ 73, 81 ],
        "id_str" : "783214",
        "id" : 783214
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 41, 61 ],
        "url" : "http://t.co/1jGoYBP5",
        "expanded_url" : "http://medium.com",
        "display_url" : "medium.com"
      } ]
    },
    "geo" : { },
    "id_str" : "268835355103481856",
    "text" : "Pssst...if you work Twitter: Register on http://t.co/1jGoYBP5 using your @twitter.com email, and you can post stuff. Thanks.",
    "id" : 268835355103481856,
    "created_at" : "2012-11-14 21:58:38 +0000",
    "user" : {
      "name" : "Evan Williams",
      "screen_name" : "ev",
      "protected" : false,
      "id_str" : "20",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3669523083/741b9ae8a443ce0a81646314871d2c00_normal.jpeg",
      "id" : 20,
      "verified" : true
    }
  },
  "id" : 268863694774091777,
  "created_at" : "2012-11-14 23:51:14 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Victor Mathieux",
      "screen_name" : "VictorMathieux",
      "indices" : [ 4, 19 ],
      "id_str" : "178841000",
      "id" : 178841000
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 128 ],
      "url" : "http://t.co/hhC4enXB",
      "expanded_url" : "http://bit.ly/PmLlZ4",
      "display_url" : "bit.ly/PmLlZ4"
    } ]
  },
  "geo" : { },
  "id_str" : "268774932970872833",
  "text" : "Pay @VictorMathieux $2 for catching me drinking beer instead of red wine last night (my self-imposed rules: http://t.co/hhC4enXB)",
  "id" : 268774932970872833,
  "created_at" : "2012-11-14 17:58:32 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Explore",
      "screen_name" : "Explorer",
      "indices" : [ 3, 12 ],
      "id_str" : "498328279",
      "id" : 498328279
    }, {
      "name" : "Alex Tabarrok",
      "screen_name" : "ATabarrok",
      "indices" : [ 121, 131 ],
      "id_str" : "287309941",
      "id" : 287309941
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "268754232969134080",
  "text" : "RT @Explorer: \"Teaching today is like a stage play. Online education makes teaching more like a movie.\" A must-read from @atabarrok http ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://bufferapp.com\" rel=\"nofollow\">Buffer</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Alex Tabarrok",
        "screen_name" : "ATabarrok",
        "indices" : [ 107, 117 ],
        "id_str" : "287309941",
        "id" : 287309941
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 138 ],
        "url" : "http://t.co/eW93nQmY",
        "expanded_url" : "http://j.mp/UGG8vV",
        "display_url" : "j.mp/UGG8vV"
      } ]
    },
    "geo" : { },
    "id_str" : "268753440627372032",
    "text" : "\"Teaching today is like a stage play. Online education makes teaching more like a movie.\" A must-read from @atabarrok http://t.co/eW93nQmY",
    "id" : 268753440627372032,
    "created_at" : "2012-11-14 16:33:08 +0000",
    "user" : {
      "name" : "Explore",
      "screen_name" : "Explorer",
      "protected" : false,
      "id_str" : "498328279",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2170469012/twitter_avatar_r_normal.png",
      "id" : 498328279,
      "verified" : false
    }
  },
  "id" : 268754232969134080,
  "created_at" : "2012-11-14 16:36:17 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Rieger",
      "screen_name" : "bryanrieger",
      "indices" : [ 3, 15 ],
      "id_str" : "755367",
      "id" : 755367
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "268750901806780417",
  "text" : "RT @bryanrieger: \"Everyone takes the limits of his own vision for the limits of the world.\" \u2013 Arthur Schopenhauer",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "268403193489276928",
    "text" : "\"Everyone takes the limits of his own vision for the limits of the world.\" \u2013 Arthur Schopenhauer",
    "id" : 268403193489276928,
    "created_at" : "2012-11-13 17:21:22 +0000",
    "user" : {
      "name" : "Bryan Rieger",
      "screen_name" : "bryanrieger",
      "protected" : false,
      "id_str" : "755367",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1549751975/avatar_normal.png",
      "id" : 755367,
      "verified" : false
    }
  },
  "id" : 268750901806780417,
  "created_at" : "2012-11-14 16:23:02 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emilio Ramirez",
      "screen_name" : "e_ramirez",
      "indices" : [ 3, 13 ],
      "id_str" : "1273564632",
      "id" : 1273564632
    }, {
      "name" : "Misfit Wearables",
      "screen_name" : "MisfitWearables",
      "indices" : [ 91, 107 ],
      "id_str" : "389732460",
      "id" : 389732460
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "quanfitiedself",
      "indices" : [ 23, 38 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 129 ],
      "url" : "http://t.co/GiQFsiPb",
      "expanded_url" : "http://www.indiegogo.com/misfitshine",
      "display_url" : "indiegogo.com/misfitshine"
    } ]
  },
  "geo" : { },
  "id_str" : "268750031249620992",
  "text" : "RT @e_ramirez: Another #quanfitiedself device enters the ring. Excited to see the Shine by @MisfitWearables: http://t.co/GiQFsiPb",
  "retweeted_status" : {
    "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Misfit Wearables",
        "screen_name" : "MisfitWearables",
        "indices" : [ 76, 92 ],
        "id_str" : "389732460",
        "id" : 389732460
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "quanfitiedself",
        "indices" : [ 8, 23 ]
      } ],
      "urls" : [ {
        "indices" : [ 94, 114 ],
        "url" : "http://t.co/GiQFsiPb",
        "expanded_url" : "http://www.indiegogo.com/misfitshine",
        "display_url" : "indiegogo.com/misfitshine"
      } ]
    },
    "geo" : { },
    "id_str" : "268742758334885888",
    "text" : "Another #quanfitiedself device enters the ring. Excited to see the Shine by @MisfitWearables: http://t.co/GiQFsiPb",
    "id" : 268742758334885888,
    "created_at" : "2012-11-14 15:50:41 +0000",
    "user" : {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "protected" : false,
      "id_str" : "21135674",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1777379809/391870_10100894712944981_10004982_63155096_635581352_n_normal.jpg",
      "id" : 21135674,
      "verified" : false
    }
  },
  "id" : 268750031249620992,
  "created_at" : "2012-11-14 16:19:35 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Victor Mathieux",
      "screen_name" : "VictorMathieux",
      "indices" : [ 62, 77 ],
      "id_str" : "178841000",
      "id" : 178841000
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 109 ],
      "url" : "http://t.co/MSMeWNw7",
      "expanded_url" : "http://instagr.am/p/R_5gCpo0Kq/",
      "display_url" : "instagr.am/p/R_5gCpo0Kq/"
    } ]
  },
  "geo" : { },
  "id_str" : "268589067699118080",
  "text" : "8:36pm Back in my cool yellow hotel after meeting the awesome @VictorMathieux of everest http://t.co/MSMeWNw7",
  "id" : 268589067699118080,
  "created_at" : "2012-11-14 05:39:58 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Camille Fournier",
      "screen_name" : "skamille",
      "indices" : [ 0, 9 ],
      "id_str" : "24257941",
      "id" : 24257941
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "268549590909845506",
  "geo" : { },
  "id_str" : "268550328885055488",
  "in_reply_to_user_id" : 24257941,
  "text" : "@skamille Just a little thing called Tweeter.",
  "id" : 268550328885055488,
  "in_reply_to_status_id" : 268549590909845506,
  "created_at" : "2012-11-14 03:06:02 +0000",
  "in_reply_to_screen_name" : "skamille",
  "in_reply_to_user_id_str" : "24257941",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Self Aware ROOMBA",
      "screen_name" : "SelfAwareROOMBA",
      "indices" : [ 3, 19 ],
      "id_str" : "620654544",
      "id" : 620654544
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "268549715258392577",
  "text" : "RT @SelfAwareROOMBA: ROOMBA is a long way from pizza.",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "268540287247339521",
    "text" : "ROOMBA is a long way from pizza.",
    "id" : 268540287247339521,
    "created_at" : "2012-11-14 02:26:08 +0000",
    "user" : {
      "name" : "Self Aware ROOMBA",
      "screen_name" : "SelfAwareROOMBA",
      "protected" : false,
      "id_str" : "620654544",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2347821270/roomba_normal.jpg",
      "id" : 620654544,
      "verified" : false
    }
  },
  "id" : 268549715258392577,
  "created_at" : "2012-11-14 03:03:36 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Fuchs",
      "screen_name" : "jfuchs",
      "indices" : [ 0, 7 ],
      "id_str" : "1026",
      "id" : 1026
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "268462136450228226",
  "geo" : { },
  "id_str" : "268462662835400705",
  "in_reply_to_user_id" : 1026,
  "text" : "@jfuchs Really sorry! There soon!",
  "id" : 268462662835400705,
  "in_reply_to_status_id" : 268462136450228226,
  "created_at" : "2012-11-13 21:17:41 +0000",
  "in_reply_to_screen_name" : "jfuchs",
  "in_reply_to_user_id_str" : "1026",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Fuchs",
      "screen_name" : "jfuchs",
      "indices" : [ 0, 7 ],
      "id_str" : "1026",
      "id" : 1026
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "268461917780189184",
  "geo" : { },
  "id_str" : "268462077818056704",
  "in_reply_to_user_id" : 1026,
  "text" : "@jfuchs I can be there at 1:45. Will that work?",
  "id" : 268462077818056704,
  "in_reply_to_status_id" : 268461917780189184,
  "created_at" : "2012-11-13 21:15:21 +0000",
  "in_reply_to_screen_name" : "jfuchs",
  "in_reply_to_user_id_str" : "1026",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Fuchs",
      "screen_name" : "jfuchs",
      "indices" : [ 0, 7 ],
      "id_str" : "1026",
      "id" : 1026
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "268459449105121280",
  "geo" : { },
  "id_str" : "268461740373733377",
  "in_reply_to_user_id" : 1026,
  "text" : "@jfuchs Shoot, I somehow lost track of the thread! What time did we say?",
  "id" : 268461740373733377,
  "in_reply_to_status_id" : 268459449105121280,
  "created_at" : "2012-11-13 21:14:01 +0000",
  "in_reply_to_screen_name" : "jfuchs",
  "in_reply_to_user_id_str" : "1026",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Torrez",
      "screen_name" : "torrez",
      "indices" : [ 0, 7 ],
      "id_str" : "11604",
      "id" : 11604
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "268216038481612801",
  "geo" : { },
  "id_str" : "268216682231758848",
  "in_reply_to_user_id" : 11604,
  "text" : "@torrez Not sure but it was recorded and will probably be online at some point. I'll let you know!",
  "id" : 268216682231758848,
  "in_reply_to_status_id" : 268216038481612801,
  "created_at" : "2012-11-13 05:00:14 +0000",
  "in_reply_to_screen_name" : "torrez",
  "in_reply_to_user_id_str" : "11604",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rose Broome",
      "screen_name" : "rosical",
      "indices" : [ 44, 52 ],
      "id_str" : "140145169",
      "id" : 140145169
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "quantifiedself",
      "indices" : [ 22, 37 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 92 ],
      "url" : "http://t.co/VA97ARmJ",
      "expanded_url" : "http://instagr.am/p/R9PT5Jo0PB/",
      "display_url" : "instagr.am/p/R9PT5Jo0PB/"
    } ]
  },
  "geo" : { },
  "id_str" : "268213931913400320",
  "text" : "8:36pm I was doing my #quantifiedself talk. @rosical took this. Thanks! http://t.co/VA97ARmJ",
  "id" : 268213931913400320,
  "created_at" : "2012-11-13 04:49:19 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "quantifiedself",
      "indices" : [ 46, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 129 ],
      "url" : "http://t.co/f44t2GGU",
      "expanded_url" : "http://instagr.am/p/R9Jvqvo0Kh/",
      "display_url" : "instagr.am/p/R9Jvqvo0Kh/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.79412, -122.3943 ]
  },
  "id_str" : "268201498880667648",
  "text" : "2,789 bananas were used in the making of this #quantifiedself meetu @ Quantified Self Meetup - San Francisco http://t.co/f44t2GGU",
  "id" : 268201498880667648,
  "created_at" : "2012-11-13 03:59:54 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Yeh",
      "screen_name" : "chrisyeh",
      "indices" : [ 3, 12 ],
      "id_str" : "7589582",
      "id" : 7589582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 121 ],
      "url" : "http://t.co/ISEeHV82",
      "expanded_url" : "http://bit.ly/ZylhzI",
      "display_url" : "bit.ly/ZylhzI"
    } ]
  },
  "geo" : { },
  "id_str" : "268178064993832960",
  "text" : "RT @chrisyeh: Each year, 1,000 companies get a 1st VC round; 5 go on to be billion-dollar companies: http://t.co/ISEeHV82",
  "retweeted_status" : {
    "source" : "<a href=\"http://bitly.com\" rel=\"nofollow\">bitly</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 87, 107 ],
        "url" : "http://t.co/ISEeHV82",
        "expanded_url" : "http://bit.ly/ZylhzI",
        "display_url" : "bit.ly/ZylhzI"
      } ]
    },
    "geo" : { },
    "id_str" : "268169984063193088",
    "text" : "Each year, 1,000 companies get a 1st VC round; 5 go on to be billion-dollar companies: http://t.co/ISEeHV82",
    "id" : 268169984063193088,
    "created_at" : "2012-11-13 01:54:41 +0000",
    "user" : {
      "name" : "Chris Yeh",
      "screen_name" : "chrisyeh",
      "protected" : false,
      "id_str" : "7589582",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/329359468/cheskin_headshot_normal.jpg",
      "id" : 7589582,
      "verified" : false
    }
  },
  "id" : 268178064993832960,
  "created_at" : "2012-11-13 02:26:47 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Crocker",
      "screen_name" : "nickcrocker",
      "indices" : [ 0, 12 ],
      "id_str" : "30801469",
      "id" : 30801469
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "268173418246045696",
  "geo" : { },
  "id_str" : "268175943108022272",
  "in_reply_to_user_id" : 30801469,
  "text" : "@nickcrocker I wanna read it! Is it in the app?",
  "id" : 268175943108022272,
  "in_reply_to_status_id" : 268173418246045696,
  "created_at" : "2012-11-13 02:18:21 +0000",
  "in_reply_to_screen_name" : "nickcrocker",
  "in_reply_to_user_id_str" : "30801469",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://bufferapp.com\" rel=\"nofollow\">Buffer</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Clay Shirky",
      "screen_name" : "cshirky",
      "indices" : [ 80, 88 ],
      "id_str" : "6141832",
      "id" : 6141832
    }, {
      "name" : "Carinna Tarvin",
      "screen_name" : "carinnatarvin",
      "indices" : [ 114, 128 ],
      "id_str" : "20833838",
      "id" : 20833838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 109 ],
      "url" : "http://t.co/XwXTtlNq",
      "expanded_url" : "http://bit.ly/Tvt3a2",
      "display_url" : "bit.ly/Tvt3a2"
    } ]
  },
  "geo" : { },
  "id_str" : "268082092921991168",
  "text" : "Here come massively open online classes. \"Napster, Udacity, and the Academy\" by @cshirky http://t.co/XwXTtlNq /cc @carinnatarvin",
  "id" : 268082092921991168,
  "created_at" : "2012-11-12 20:05:26 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jacob",
      "screen_name" : "fat",
      "indices" : [ 109, 113 ],
      "id_str" : "16521996",
      "id" : 16521996
    }, {
      "name" : "Svbtle Feed",
      "screen_name" : "SvbtleFeed",
      "indices" : [ 119, 130 ],
      "id_str" : "1352847072",
      "id" : 1352847072
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 104 ],
      "url" : "http://t.co/YMYhjBrS",
      "expanded_url" : "http://byfat.xxx/deep-emo-shit",
      "display_url" : "byfat.xxx/deep-emo-shit"
    } ]
  },
  "geo" : { },
  "id_str" : "268071265653370880",
  "text" : "Good stuff: \"\u2026the 'uglier way' Freud was talking about would be for me javascript.\" http://t.co/YMYhjBrS /by @fat /via @SvbtleFeed",
  "id" : 268071265653370880,
  "created_at" : "2012-11-12 19:22:24 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "quantifiedself",
      "indices" : [ 60, 75 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 107 ],
      "url" : "http://t.co/KLGksrEZ",
      "expanded_url" : "http://bit.ly/RPlD2T",
      "display_url" : "bit.ly/RPlD2T"
    } ]
  },
  "geo" : { },
  "id_str" : "268058429241823232",
  "text" : "Gonna share my latest self-tracking strategies at tonight's #quantifiedself SF meetup: http://t.co/KLGksrEZ (you should come!)",
  "id" : 268058429241823232,
  "created_at" : "2012-11-12 18:31:24 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "danariely",
      "screen_name" : "danariely",
      "indices" : [ 3, 13 ],
      "id_str" : "17997789",
      "id" : 17997789
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 98 ],
      "url" : "http://t.co/Ru6MprxQ",
      "expanded_url" : "http://wtim.es/SHruog",
      "display_url" : "wtim.es/SHruog"
    } ]
  },
  "geo" : { },
  "id_str" : "268040090293514240",
  "text" : "RT @danariely: Asking Dan Ariely: Does self-interest really motivate people?: http://t.co/Ru6MprxQ",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 63, 83 ],
        "url" : "http://t.co/Ru6MprxQ",
        "expanded_url" : "http://wtim.es/SHruog",
        "display_url" : "wtim.es/SHruog"
      } ]
    },
    "geo" : { },
    "id_str" : "268024557292634112",
    "text" : "Asking Dan Ariely: Does self-interest really motivate people?: http://t.co/Ru6MprxQ",
    "id" : 268024557292634112,
    "created_at" : "2012-11-12 16:16:48 +0000",
    "user" : {
      "name" : "danariely",
      "screen_name" : "danariely",
      "protected" : false,
      "id_str" : "17997789",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3079991122/885ba5efe97fcfd916001b8374d0d75c_normal.jpeg",
      "id" : 17997789,
      "verified" : false
    }
  },
  "id" : 268040090293514240,
  "created_at" : "2012-11-12 17:18:32 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "noah kagan",
      "screen_name" : "noahkagan",
      "indices" : [ 0, 10 ],
      "id_str" : "13737",
      "id" : 13737
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "268035543449890816",
  "geo" : { },
  "id_str" : "268038815812308992",
  "in_reply_to_user_id" : 13737,
  "text" : "@noahkagan In SF this week (you're in NY?). Niko my son. :) I was just trolling, don't mind me.",
  "id" : 268038815812308992,
  "in_reply_to_status_id" : 268035543449890816,
  "created_at" : "2012-11-12 17:13:28 +0000",
  "in_reply_to_screen_name" : "noahkagan",
  "in_reply_to_user_id_str" : "13737",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "danariely",
      "screen_name" : "danariely",
      "indices" : [ 3, 13 ],
      "id_str" : "17997789",
      "id" : 17997789
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 114 ],
      "url" : "http://t.co/33ZrDjEf",
      "expanded_url" : "http://wtim.es/SHri8q",
      "display_url" : "wtim.es/SHri8q"
    } ]
  },
  "geo" : { },
  "id_str" : "268038552590368768",
  "text" : "RT @danariely: How rational are we? Dan Ariely on emotion, reason, and making wise decisions: http://t.co/33ZrDjEf",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 79, 99 ],
        "url" : "http://t.co/33ZrDjEf",
        "expanded_url" : "http://wtim.es/SHri8q",
        "display_url" : "wtim.es/SHri8q"
      } ]
    },
    "geo" : { },
    "id_str" : "268024262336577536",
    "text" : "How rational are we? Dan Ariely on emotion, reason, and making wise decisions: http://t.co/33ZrDjEf",
    "id" : 268024262336577536,
    "created_at" : "2012-11-12 16:15:38 +0000",
    "user" : {
      "name" : "danariely",
      "screen_name" : "danariely",
      "protected" : false,
      "id_str" : "17997789",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3079991122/885ba5efe97fcfd916001b8374d0d75c_normal.jpeg",
      "id" : 17997789,
      "verified" : false
    }
  },
  "id" : 268038552590368768,
  "created_at" : "2012-11-12 17:12:25 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "noah kagan",
      "screen_name" : "noahkagan",
      "indices" : [ 0, 10 ],
      "id_str" : "13737",
      "id" : 13737
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "268020574230548480",
  "geo" : { },
  "id_str" : "268034236450234368",
  "in_reply_to_user_id" : 13737,
  "text" : "@noahkagan I'm gonna tell Niko to bugger off next time I see him.",
  "id" : 268034236450234368,
  "in_reply_to_status_id" : 268020574230548480,
  "created_at" : "2012-11-12 16:55:16 +0000",
  "in_reply_to_screen_name" : "noahkagan",
  "in_reply_to_user_id_str" : "13737",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim O'Reilly",
      "screen_name" : "timoreilly",
      "indices" : [ 3, 14 ],
      "id_str" : "2384071",
      "id" : 2384071
    }, {
      "name" : "Ron M Zettlemoyer",
      "screen_name" : "ronmichael",
      "indices" : [ 19, 30 ],
      "id_str" : "807851",
      "id" : 807851
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "268029801506422784",
  "text" : "RT @timoreilly: RT @ronmichael: So who is the unnamed software development company behind Romney's failed Orca tool?",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ron M Zettlemoyer",
        "screen_name" : "ronmichael",
        "indices" : [ 3, 14 ],
        "id_str" : "807851",
        "id" : 807851
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "268018313748172800",
    "text" : "RT @ronmichael: So who is the unnamed software development company behind Romney's failed Orca tool?",
    "id" : 268018313748172800,
    "created_at" : "2012-11-12 15:52:00 +0000",
    "user" : {
      "name" : "Tim O'Reilly",
      "screen_name" : "timoreilly",
      "protected" : false,
      "id_str" : "2384071",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2823681988/f4f6f2bed8ab4d5a48dea4b9ea85d5f1_normal.jpeg",
      "id" : 2384071,
      "verified" : true
    }
  },
  "id" : 268029801506422784,
  "created_at" : "2012-11-12 16:37:39 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 121 ],
      "url" : "http://t.co/llJepAEN",
      "expanded_url" : "http://4sq.com/Rx13Tn",
      "display_url" : "4sq.com/Rx13Tn"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.4436465828, -122.3025941849 ]
  },
  "id_str" : "267973863068037120",
  "text" : "Headed to SF for the week. Good morning. (@ Seattle-Tacoma International Airport (SEA) w/ 13 others) http://t.co/llJepAEN",
  "id" : 267973863068037120,
  "created_at" : "2012-11-12 12:55:22 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anti-Buster",
      "screen_name" : "busterbenson",
      "indices" : [ 0, 13 ],
      "id_str" : "1024917050",
      "id" : 1024917050
    }, {
      "name" : "Randall Munroe",
      "screen_name" : "xkcd",
      "indices" : [ 31, 36 ],
      "id_str" : "21146468",
      "id" : 21146468
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 130 ],
      "url" : "http://t.co/EEr0AbOF",
      "expanded_url" : "http://xkcd.com/1133",
      "display_url" : "xkcd.com/1133"
    } ]
  },
  "geo" : { },
  "id_str" : "267969449263509505",
  "in_reply_to_user_id" : 2185,
  "text" : "@busterbenson: Another awesome @xkcd comic. Makes me want a writing tool limited to 1,000 most common words.  http://t.co/EEr0AbOF",
  "id" : 267969449263509505,
  "created_at" : "2012-11-12 12:37:49 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ajay Mathur",
      "screen_name" : "june5",
      "indices" : [ 13, 19 ],
      "id_str" : "14491225",
      "id" : 14491225
    }, {
      "name" : "Anti-Buster",
      "screen_name" : "busterbenson",
      "indices" : [ 31, 44 ],
      "id_str" : "1024917050",
      "id" : 1024917050
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "267963275105406976",
  "text" : "Right on! MT @june5: Following @busterbenson I will pay \u00A31 to the 1st to catch me complaining or talking ill abt someone behind their back.",
  "id" : 267963275105406976,
  "created_at" : "2012-11-12 12:13:17 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aimee",
      "screen_name" : "LilHossler",
      "indices" : [ 0, 11 ],
      "id_str" : "123116307",
      "id" : 123116307
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "livinthedream",
      "indices" : [ 67, 81 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "267877696221085696",
  "geo" : { },
  "id_str" : "267878574499975169",
  "in_reply_to_user_id" : 123116307,
  "text" : "@LilHossler Thanks! I've always wanted an illustrated profile pic. #livinthedream",
  "id" : 267878574499975169,
  "in_reply_to_status_id" : 267877696221085696,
  "created_at" : "2012-11-12 06:36:43 +0000",
  "in_reply_to_screen_name" : "LilHossler",
  "in_reply_to_user_id_str" : "123116307",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ingopixel",
      "screen_name" : "ingopixel",
      "indices" : [ 52, 62 ],
      "id_str" : "7943892",
      "id" : 7943892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 110 ],
      "url" : "http://t.co/lzwomNct",
      "expanded_url" : "http://flic.kr/p/dsDrZx",
      "display_url" : "flic.kr/p/dsDrZx"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.608666, -122.306 ]
  },
  "id_str" : "267857191007039488",
  "text" : "8:36pm Back home after exciting birthday times with @ingopixel &amp; friends &amp; family http://t.co/lzwomNct",
  "id" : 267857191007039488,
  "created_at" : "2012-11-12 05:11:45 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ingopixel",
      "screen_name" : "ingopixel",
      "indices" : [ 16, 26 ],
      "id_str" : "7943892",
      "id" : 7943892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 67 ],
      "url" : "http://t.co/clHgHY4W",
      "expanded_url" : "http://instagr.am/p/R6Y9wdI0Oi/",
      "display_url" : "instagr.am/p/R6Y9wdI0Oi/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.4756800876, -122.128074158 ]
  },
  "id_str" : "267812747780161536",
  "text" : "Pizza party for @ingopixel's bday! @ Chez Wurl http://t.co/clHgHY4W",
  "id" : 267812747780161536,
  "created_at" : "2012-11-12 02:15:09 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ron Diver",
      "screen_name" : "rondiver",
      "indices" : [ 0, 9 ],
      "id_str" : "12661782",
      "id" : 12661782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "267704630866223105",
  "geo" : { },
  "id_str" : "267704976690786304",
  "in_reply_to_user_id" : 12661782,
  "text" : "@rondiver Interesting. That makes sense. Why not use something like Instapaper?",
  "id" : 267704976690786304,
  "in_reply_to_status_id" : 267704630866223105,
  "created_at" : "2012-11-11 19:06:54 +0000",
  "in_reply_to_screen_name" : "rondiver",
  "in_reply_to_user_id_str" : "12661782",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ron Diver",
      "screen_name" : "rondiver",
      "indices" : [ 0, 9 ],
      "id_str" : "12661782",
      "id" : 12661782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "267697452285571074",
  "geo" : { },
  "id_str" : "267702244441481216",
  "in_reply_to_user_id" : 12661782,
  "text" : "@rondiver You want your favorites to be emailed to you? Why?",
  "id" : 267702244441481216,
  "in_reply_to_status_id" : 267697452285571074,
  "created_at" : "2012-11-11 18:56:03 +0000",
  "in_reply_to_screen_name" : "rondiver",
  "in_reply_to_user_id_str" : "12661782",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ron Diver",
      "screen_name" : "rondiver",
      "indices" : [ 0, 9 ],
      "id_str" : "12661782",
      "id" : 12661782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "267689895600979969",
  "geo" : { },
  "id_str" : "267691942522003456",
  "in_reply_to_user_id" : 12661782,
  "text" : "@rondiver I do love ifttt but the story was a bit more complicated than that. For example, there's no rule against importing faves.",
  "id" : 267691942522003456,
  "in_reply_to_status_id" : 267689895600979969,
  "created_at" : "2012-11-11 18:15:07 +0000",
  "in_reply_to_screen_name" : "rondiver",
  "in_reply_to_user_id_str" : "12661782",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Monica Guzman",
      "screen_name" : "moniguzman",
      "indices" : [ 3, 14 ],
      "id_str" : "3452941",
      "id" : 3452941
    }, {
      "name" : "The Seattle Times",
      "screen_name" : "seattletimes",
      "indices" : [ 121, 134 ],
      "id_str" : "14352556",
      "id" : 14352556
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 116 ],
      "url" : "http://t.co/eMMrUFbG",
      "expanded_url" : "http://blogs.seattletimes.com/monica-guzman/2012/11/09/have-you-seen-the-wizard-searching-for-a-street-art-curiosity/#.UJ_ZOqSrJ-E.twitter",
      "display_url" : "blogs.seattletimes.com/monica-guzman/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "267689856572985344",
  "text" : "RT @moniguzman: Have you seen this wizard on telephone poles around Seattle? Here's the story:  http://t.co/eMMrUFbG via @seattletimes",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Seattle Times",
        "screen_name" : "seattletimes",
        "indices" : [ 105, 118 ],
        "id_str" : "14352556",
        "id" : 14352556
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 80, 100 ],
        "url" : "http://t.co/eMMrUFbG",
        "expanded_url" : "http://blogs.seattletimes.com/monica-guzman/2012/11/09/have-you-seen-the-wizard-searching-for-a-street-art-curiosity/#.UJ_ZOqSrJ-E.twitter",
        "display_url" : "blogs.seattletimes.com/monica-guzman/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "267673304968617984",
    "text" : "Have you seen this wizard on telephone poles around Seattle? Here's the story:  http://t.co/eMMrUFbG via @seattletimes",
    "id" : 267673304968617984,
    "created_at" : "2012-11-11 17:01:03 +0000",
    "user" : {
      "name" : "Monica Guzman",
      "screen_name" : "moniguzman",
      "protected" : false,
      "id_str" : "3452941",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2278622783/7bawi34jjnlztg26hljx_normal.jpeg",
      "id" : 3452941,
      "verified" : false
    }
  },
  "id" : 267689856572985344,
  "created_at" : "2012-11-11 18:06:49 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ron Diver",
      "screen_name" : "rondiver",
      "indices" : [ 0, 9 ],
      "id_str" : "12661782",
      "id" : 12661782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "267685859069927424",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6086551324, -122.3060695735 ]
  },
  "id_str" : "267689286676135936",
  "in_reply_to_user_id" : 12661782,
  "text" : "@rondiver I don't think there is one.",
  "id" : 267689286676135936,
  "in_reply_to_status_id" : 267685859069927424,
  "created_at" : "2012-11-11 18:04:34 +0000",
  "in_reply_to_screen_name" : "rondiver",
  "in_reply_to_user_id_str" : "12661782",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 40 ],
      "url" : "http://t.co/optGEYaw",
      "expanded_url" : "http://instagr.am/p/R4Eb71I0HN/",
      "display_url" : "instagr.am/p/R4Eb71I0HN/"
    } ]
  },
  "geo" : { },
  "id_str" : "267486367515287552",
  "text" : "8:36pm Niko + Poppy http://t.co/optGEYaw",
  "id" : 267486367515287552,
  "created_at" : "2012-11-11 04:38:14 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "josh",
      "screen_name" : "joshc",
      "indices" : [ 0, 6 ],
      "id_str" : "2015",
      "id" : 2015
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "267470596340867072",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6086483431, -122.3060445116 ]
  },
  "id_str" : "267470914613030912",
  "in_reply_to_user_id" : 2015,
  "text" : "@joshc So true.",
  "id" : 267470914613030912,
  "in_reply_to_status_id" : 267470596340867072,
  "created_at" : "2012-11-11 03:36:50 +0000",
  "in_reply_to_screen_name" : "joshc",
  "in_reply_to_user_id_str" : "2015",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Hall",
      "screen_name" : "Hallicious",
      "indices" : [ 0, 11 ],
      "id_str" : "16233090",
      "id" : 16233090
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "267434410427695104",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6086320421, -122.3060033873 ]
  },
  "id_str" : "267438899536732160",
  "in_reply_to_user_id" : 16233090,
  "text" : "@Hallicious Interesting! Which 5 things?",
  "id" : 267438899536732160,
  "in_reply_to_status_id" : 267434410427695104,
  "created_at" : "2012-11-11 01:29:37 +0000",
  "in_reply_to_screen_name" : "Hallicious",
  "in_reply_to_user_id_str" : "16233090",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dustin curtis",
      "screen_name" : "dcurtis",
      "indices" : [ 1, 9 ],
      "id_str" : "9395832",
      "id" : 9395832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "267415604049371136",
  "text" : ".@dcurtis Depending on what \"unlimited\" really is, I would design and build a neighborhood, city, country, planet, or universe.",
  "id" : 267415604049371136,
  "created_at" : "2012-11-10 23:57:03 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dustin curtis",
      "screen_name" : "dcurtis",
      "indices" : [ 3, 11 ],
      "id_str" : "9395832",
      "id" : 9395832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "267415148694740994",
  "text" : "RT @dcurtis: If you had unlimited resources, unlimited time, unlimited support, and unlimited freedom, what would you choose to work on?",
  "retweeted_status" : {
    "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "267392685743157248",
    "text" : "If you had unlimited resources, unlimited time, unlimited support, and unlimited freedom, what would you choose to work on?",
    "id" : 267392685743157248,
    "created_at" : "2012-11-10 22:25:58 +0000",
    "user" : {
      "name" : "dustin curtis",
      "screen_name" : "dcurtis",
      "protected" : false,
      "id_str" : "9395832",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3586312198/4f90d52a9416842731420c9e3cb1ec9f_normal.png",
      "id" : 9395832,
      "verified" : false
    }
  },
  "id" : 267415148694740994,
  "created_at" : "2012-11-10 23:55:14 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Rainert",
      "screen_name" : "arainert",
      "indices" : [ 0, 9 ],
      "id_str" : "7482",
      "id" : 7482
    }, {
      "name" : "dustin curtis",
      "screen_name" : "dcurtis",
      "indices" : [ 10, 18 ],
      "id_str" : "9395832",
      "id" : 9395832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "267414486435102721",
  "geo" : { },
  "id_str" : "267415087080423425",
  "in_reply_to_user_id" : 7482,
  "text" : "@arainert @dcurtis And I wrote half a novel about that question in college. :)",
  "id" : 267415087080423425,
  "in_reply_to_status_id" : 267414486435102721,
  "created_at" : "2012-11-10 23:54:59 +0000",
  "in_reply_to_screen_name" : "arainert",
  "in_reply_to_user_id_str" : "7482",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://bufferapp.com\" rel=\"nofollow\">Buffer</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emilio Ramirez",
      "screen_name" : "e_ramirez",
      "indices" : [ 116, 126 ],
      "id_str" : "1273564632",
      "id" : 1273564632
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "quantifiedself",
      "indices" : [ 96, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 95 ],
      "url" : "http://t.co/CN1jHdeI",
      "expanded_url" : "http://bit.ly/Xtg8ui",
      "display_url" : "bit.ly/Xtg8ui"
    } ]
  },
  "geo" : { },
  "id_str" : "267409670988242945",
  "text" : "Draft and request for feedback on this sorta weird Self-Tracking Challenge http://t.co/CN1jHdeI #quantifiedself /cc @e_ramirez",
  "id" : 267409670988242945,
  "created_at" : "2012-11-10 23:33:28 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http://t.co/pI6PUlkd",
      "expanded_url" : "http://bit.ly/ZkEuES",
      "display_url" : "bit.ly/ZkEuES"
    } ]
  },
  "geo" : { },
  "id_str" : "267349453990662144",
  "text" : "The \"national popular vote\" idea is about halfway to having a 270 vote majority, replacing the way electoral votes work http://t.co/pI6PUlkd",
  "id" : 267349453990662144,
  "created_at" : "2012-11-10 19:34:11 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jad Abumrad",
      "screen_name" : "JadAbumrad",
      "indices" : [ 3, 14 ],
      "id_str" : "135316691",
      "id" : 135316691
    }, {
      "name" : "Chris Berube",
      "screen_name" : "ChrisBerube",
      "indices" : [ 113, 125 ],
      "id_str" : "22650632",
      "id" : 22650632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "267338979593048064",
  "text" : "RT @JadAbumrad: David Patraeus's mistress's husband might have written to the NYT Ethicist for advice. Wow. (via @ChrisBerube) http://t. ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://itunes.apple.com/us/app/read-it-later-pro/id309601447?mt=8&uo=4\" rel=\"nofollow\">Pocket for iOS</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Chris Berube",
        "screen_name" : "ChrisBerube",
        "indices" : [ 97, 109 ],
        "id_str" : "22650632",
        "id" : 22650632
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 111, 131 ],
        "url" : "http://t.co/3eA4dwLp",
        "expanded_url" : "http://gawker.com/5959398/did-paula-broadwells-cuckolded-husband-write-a-letter-to-chuck-klosterman-aka-the-new-york-times-ethicist",
        "display_url" : "gawker.com/5959398/did-pa\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "267338720586395648",
    "text" : "David Patraeus's mistress's husband might have written to the NYT Ethicist for advice. Wow. (via @ChrisBerube) http://t.co/3eA4dwLp",
    "id" : 267338720586395648,
    "created_at" : "2012-11-10 18:51:32 +0000",
    "user" : {
      "name" : "Jad Abumrad",
      "screen_name" : "JadAbumrad",
      "protected" : false,
      "id_str" : "135316691",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1529014082/Jad-Pic2_normal.jpg",
      "id" : 135316691,
      "verified" : true
    }
  },
  "id" : 267338979593048064,
  "created_at" : "2012-11-10 18:52:34 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin",
      "screen_name" : "demortes",
      "indices" : [ 0, 9 ],
      "id_str" : "14047359",
      "id" : 14047359
    }, {
      "name" : "Liene Verzemnieks",
      "screen_name" : "li3n3",
      "indices" : [ 17, 23 ],
      "id_str" : "498467901",
      "id" : 498467901
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "267331870079975424",
  "geo" : { },
  "id_str" : "267337919965052928",
  "in_reply_to_user_id" : 14047359,
  "text" : "@demortes Giving @li3n3 a badge would be demeaning at this point, I believe.",
  "id" : 267337919965052928,
  "in_reply_to_status_id" : 267331870079975424,
  "created_at" : "2012-11-10 18:48:21 +0000",
  "in_reply_to_screen_name" : "demortes",
  "in_reply_to_user_id_str" : "14047359",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "that drew",
      "screen_name" : "thatdrew",
      "indices" : [ 3, 12 ],
      "id_str" : "1002913782",
      "id" : 1002913782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 112 ],
      "url" : "http://t.co/V8Gqpabz",
      "expanded_url" : "http://tcrn.ch/ROT7gb",
      "display_url" : "tcrn.ch/ROT7gb"
    } ]
  },
  "geo" : { },
  "id_str" : "267320318266310656",
  "text" : "RT @thatdrew: Crazy Like A Fox: Donate To Charity And Have Your Twitter Name Tattooed On Me http://t.co/V8Gqpabz",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 78, 98 ],
        "url" : "http://t.co/V8Gqpabz",
        "expanded_url" : "http://tcrn.ch/ROT7gb",
        "display_url" : "tcrn.ch/ROT7gb"
      } ]
    },
    "geo" : { },
    "id_str" : "267311511410716672",
    "text" : "Crazy Like A Fox: Donate To Charity And Have Your Twitter Name Tattooed On Me http://t.co/V8Gqpabz",
    "id" : 267311511410716672,
    "created_at" : "2012-11-10 17:03:25 +0000",
    "user" : {
      "name" : "drew olanoff",
      "screen_name" : "drew",
      "protected" : false,
      "id_str" : "10221",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000408023956/1710cffecc76204b31adeee75c2bbbe9_normal.jpeg",
      "id" : 10221,
      "verified" : false
    }
  },
  "id" : 267320318266310656,
  "created_at" : "2012-11-10 17:38:25 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Seth Priebatsch",
      "screen_name" : "sethpriebatsch",
      "indices" : [ 3, 18 ],
      "id_str" : "28465863",
      "id" : 28465863
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 118 ],
      "url" : "http://t.co/kjuMnnb1",
      "expanded_url" : "http://www.smbc-comics.com/index.php?db=comics&id=2790",
      "display_url" : "smbc-comics.com/index.php?db=c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "267317269640646657",
  "text" : "RT @sethpriebatsch: This could easily by my favorite explanation of the creation of the universe: http://t.co/kjuMnnb1",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 78, 98 ],
        "url" : "http://t.co/kjuMnnb1",
        "expanded_url" : "http://www.smbc-comics.com/index.php?db=comics&id=2790",
        "display_url" : "smbc-comics.com/index.php?db=c\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "267316325645434880",
    "text" : "This could easily by my favorite explanation of the creation of the universe: http://t.co/kjuMnnb1",
    "id" : 267316325645434880,
    "created_at" : "2012-11-10 17:22:33 +0000",
    "user" : {
      "name" : "Seth Priebatsch",
      "screen_name" : "sethpriebatsch",
      "protected" : false,
      "id_str" : "28465863",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1376423656/Screen_shot_2011-05-31_at_1.58.00_PM_normal.png",
      "id" : 28465863,
      "verified" : false
    }
  },
  "id" : 267317269640646657,
  "created_at" : "2012-11-10 17:26:18 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marshall Haas",
      "screen_name" : "MarshallHaas",
      "indices" : [ 0, 13 ],
      "id_str" : "1268491417",
      "id" : 1268491417
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "267310698458140672",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6086389134, -122.3061443401 ]
  },
  "id_str" : "267312480013918208",
  "in_reply_to_user_id" : 19028099,
  "text" : "@MarshallHaas Not sure. I'm seeing at least 100 DM threads in Tweetbot.",
  "id" : 267312480013918208,
  "in_reply_to_status_id" : 267310698458140672,
  "created_at" : "2012-11-10 17:07:16 +0000",
  "in_reply_to_screen_name" : "marshal",
  "in_reply_to_user_id_str" : "19028099",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marshall Haas",
      "screen_name" : "MarshallHaas",
      "indices" : [ 0, 13 ],
      "id_str" : "1268491417",
      "id" : 1268491417
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "267309415022096384",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6085972554, -122.306158757 ]
  },
  "id_str" : "267310113512099840",
  "in_reply_to_user_id" : 19028099,
  "text" : "@MarshallHaas They're still there if you or the other person hasn't deleted them. Have you tried the API?",
  "id" : 267310113512099840,
  "in_reply_to_status_id" : 267309415022096384,
  "created_at" : "2012-11-10 16:57:52 +0000",
  "in_reply_to_screen_name" : "marshal",
  "in_reply_to_user_id_str" : "19028099",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachel Maddow MSNBC",
      "screen_name" : "maddow",
      "indices" : [ 46, 53 ],
      "id_str" : "16129920",
      "id" : 16129920
    }, {
      "name" : "Stephen Colbert",
      "screen_name" : "StephenAtHome",
      "indices" : [ 59, 73 ],
      "id_str" : "16303106",
      "id" : 16303106
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6086279331, -122.306087427 ]
  },
  "id_str" : "267309573751332864",
  "text" : "\"Right now, the facts have a liberal bias.\" - @Maddow with @StephenAtHome",
  "id" : 267309573751332864,
  "created_at" : "2012-11-10 16:55:43 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Explore",
      "screen_name" : "Explorer",
      "indices" : [ 3, 12 ],
      "id_str" : "498328279",
      "id" : 498328279
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 127 ],
      "url" : "http://t.co/Z7lRwq3e",
      "expanded_url" : "http://j.mp/QmkFN1",
      "display_url" : "j.mp/QmkFN1"
    } ]
  },
  "geo" : { },
  "id_str" : "267288711690063872",
  "text" : "RT @Explorer: PJ Harvey\u2019s guide to songwriting \u2013 also true of writing and just about any creative endeavor http://t.co/Z7lRwq3e",
  "retweeted_status" : {
    "source" : "<a href=\"http://bufferapp.com\" rel=\"nofollow\">Buffer</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 113 ],
        "url" : "http://t.co/Z7lRwq3e",
        "expanded_url" : "http://j.mp/QmkFN1",
        "display_url" : "j.mp/QmkFN1"
      } ]
    },
    "geo" : { },
    "id_str" : "267287776179920896",
    "text" : "PJ Harvey\u2019s guide to songwriting \u2013 also true of writing and just about any creative endeavor http://t.co/Z7lRwq3e",
    "id" : 267287776179920896,
    "created_at" : "2012-11-10 15:29:06 +0000",
    "user" : {
      "name" : "Explore",
      "screen_name" : "Explorer",
      "protected" : false,
      "id_str" : "498328279",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2170469012/twitter_avatar_r_normal.png",
      "id" : 498328279,
      "verified" : false
    }
  },
  "id" : 267288711690063872,
  "created_at" : "2012-11-10 15:32:49 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Liene Verzemnieks",
      "screen_name" : "li3n3",
      "indices" : [ 16, 22 ],
      "id_str" : "498467901",
      "id" : 498467901
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 69 ],
      "url" : "http://t.co/UXCU3B0z",
      "expanded_url" : "http://750words.com",
      "display_url" : "750words.com"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6086539437, -122.3059162167 ]
  },
  "id_str" : "267285060921741312",
  "text" : "Holy smokes! RT @li3n3: Today: 993 day streak on http://t.co/UXCU3B0z. Barring catastrophe, next Friday is 1000 days in a row.",
  "id" : 267285060921741312,
  "created_at" : "2012-11-10 15:18:19 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 84 ],
      "url" : "http://t.co/VjoWmqsv",
      "expanded_url" : "http://flic.kr/p/ds4oXd",
      "display_url" : "flic.kr/p/ds4oXd"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.605333, -122.325167 ]
  },
  "id_str" : "267127222412931072",
  "text" : "8:36pm Niko wants to keep partying but the party is almost over http://t.co/VjoWmqsv",
  "id" : 267127222412931072,
  "created_at" : "2012-11-10 04:51:07 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Stump",
      "screen_name" : "joestump",
      "indices" : [ 3, 12 ],
      "id_str" : "4234581",
      "id" : 4234581
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "267084764102676480",
  "text" : "RT @joestump: If you're doing product/customer development, be cognizant of Survivorship Bias.",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.echofon.com/\" rel=\"nofollow\">Echofon</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "267083920313565184",
    "text" : "If you're doing product/customer development, be cognizant of Survivorship Bias.",
    "id" : 267083920313565184,
    "created_at" : "2012-11-10 01:59:03 +0000",
    "user" : {
      "name" : "Joe Stump",
      "screen_name" : "joestump",
      "protected" : false,
      "id_str" : "4234581",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3551565860/c9d9fd9531f7d3ed8ea5ae08bf16cc64_normal.jpeg",
      "id" : 4234581,
      "verified" : false
    }
  },
  "id" : 267084764102676480,
  "created_at" : "2012-11-10 02:02:24 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "drew modrov",
      "screen_name" : "drewmodrov",
      "indices" : [ 0, 11 ],
      "id_str" : "128965943",
      "id" : 128965943
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "267061306903904256",
  "geo" : { },
  "id_str" : "267061947248304128",
  "in_reply_to_user_id" : 128965943,
  "text" : "@drewmodrov I don't think so\u2026 it's just a fact. I intentionally tried not to complain in this statement. What do you think?",
  "id" : 267061947248304128,
  "in_reply_to_status_id" : 267061306903904256,
  "created_at" : "2012-11-10 00:31:44 +0000",
  "in_reply_to_screen_name" : "drewmodrov",
  "in_reply_to_user_id_str" : "128965943",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julius Tarng ",
      "screen_name" : "tarngerine",
      "indices" : [ 0, 11 ],
      "id_str" : "15665038",
      "id" : 15665038
    }, {
      "name" : "Patrick Moberg",
      "screen_name" : "patrickmoberg",
      "indices" : [ 71, 85 ],
      "id_str" : "4102571",
      "id" : 4102571
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "267058184823398400",
  "geo" : { },
  "id_str" : "267059870728073216",
  "in_reply_to_user_id" : 15665038,
  "text" : "@tarngerine Cool, thanks! Just \"left you a note\" through your website, @patrickmoberg! Your illustrations are awesome.",
  "id" : 267059870728073216,
  "in_reply_to_status_id" : 267058184823398400,
  "created_at" : "2012-11-10 00:23:29 +0000",
  "in_reply_to_screen_name" : "tarngerine",
  "in_reply_to_user_id_str" : "15665038",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sick",
      "indices" : [ 37, 42 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6109670118, -122.3444052789 ]
  },
  "id_str" : "267044190184161280",
  "text" : "Tweeter heads, I don't feel so good. #sick",
  "id" : 267044190184161280,
  "created_at" : "2012-11-09 23:21:11 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julius Tarng ",
      "screen_name" : "tarngerine",
      "indices" : [ 0, 11 ],
      "id_str" : "15665038",
      "id" : 15665038
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 87 ],
      "url" : "http://t.co/depgv4gb",
      "expanded_url" : "http://branch.com/company",
      "display_url" : "branch.com/company"
    } ]
  },
  "geo" : { },
  "id_str" : "267039129605390339",
  "in_reply_to_user_id" : 15665038,
  "text" : "@tarngerine Did you do the illustrations on the Branch about page? http://t.co/depgv4gb And if so, do you do commissions?",
  "id" : 267039129605390339,
  "created_at" : "2012-11-09 23:01:04 +0000",
  "in_reply_to_screen_name" : "tarngerine",
  "in_reply_to_user_id_str" : "15665038",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://bufferapp.com\" rel=\"nofollow\">Buffer</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http://t.co/X8LF1t1E",
      "expanded_url" : "http://bit.ly/Tgbrip",
      "display_url" : "bit.ly/Tgbrip"
    } ]
  },
  "geo" : { },
  "id_str" : "266994870441365504",
  "text" : "\"The People's Bailout\" lets anyone buy debt for pennies on the dollar and abolish it. Interested to know more about it. http://t.co/X8LF1t1E",
  "id" : 266994870441365504,
  "created_at" : "2012-11-09 20:05:12 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 3, 11 ],
      "id_str" : "783214",
      "id" : 783214
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 118 ],
      "url" : "http://t.co/myCE73mK",
      "expanded_url" : "http://www.youtube.com/watch?v=uCE3w0FmBsA&feature=plcp",
      "display_url" : "youtube.com/watch?v=uCE3w0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "266973172367237120",
  "text" : "RT @twitter: Here's our new cartoon video on how to dress up your profile with photos and images: http://t.co/myCE73mK Give it a go!",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 85, 105 ],
        "url" : "http://t.co/myCE73mK",
        "expanded_url" : "http://www.youtube.com/watch?v=uCE3w0FmBsA&feature=plcp",
        "display_url" : "youtube.com/watch?v=uCE3w0\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "266937428437237760",
    "text" : "Here's our new cartoon video on how to dress up your profile with photos and images: http://t.co/myCE73mK Give it a go!",
    "id" : 266937428437237760,
    "created_at" : "2012-11-09 16:16:57 +0000",
    "user" : {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "protected" : false,
      "id_str" : "783214",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2284174758/v65oai7fxn47qv9nectx_normal.png",
      "id" : 783214,
      "verified" : true
    }
  },
  "id" : 266973172367237120,
  "created_at" : "2012-11-09 18:38:59 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kimberley",
      "screen_name" : "xaotica",
      "indices" : [ 0, 8 ],
      "id_str" : "13983",
      "id" : 13983
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "266951579909885952",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.612109928, -122.3438574121 ]
  },
  "id_str" : "266954661171453952",
  "in_reply_to_user_id" : 13983,
  "text" : "@xaotica And racism.",
  "id" : 266954661171453952,
  "in_reply_to_status_id" : 266951579909885952,
  "created_at" : "2012-11-09 17:25:25 +0000",
  "in_reply_to_screen_name" : "xaotica",
  "in_reply_to_user_id_str" : "13983",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "girl jo",
      "screen_name" : "octavekitten",
      "indices" : [ 0, 13 ],
      "id_str" : "16366882",
      "id" : 16366882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "266954221889409024",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.612096419, -122.3435670518 ]
  },
  "id_str" : "266954570310221824",
  "in_reply_to_user_id" : 16366882,
  "text" : "@octavekitten You should give it a try! I'm also considering \"no phone or internet\" Saturdays. Could be a fun experiment.",
  "id" : 266954570310221824,
  "in_reply_to_status_id" : 266954221889409024,
  "created_at" : "2012-11-09 17:25:03 +0000",
  "in_reply_to_screen_name" : "octavekitten",
  "in_reply_to_user_id_str" : "16366882",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "girl jo",
      "screen_name" : "octavekitten",
      "indices" : [ 0, 13 ],
      "id_str" : "16366882",
      "id" : 16366882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "266936597906350081",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6121983272, -122.3444633778 ]
  },
  "id_str" : "266953889306263552",
  "in_reply_to_user_id" : 16366882,
  "text" : "@octavekitten I've tried them all but none have ever stuck. I've had more success with making browser full screen and only 1 tab at a time.",
  "id" : 266953889306263552,
  "in_reply_to_status_id" : 266936597906350081,
  "created_at" : "2012-11-09 17:22:21 +0000",
  "in_reply_to_screen_name" : "octavekitten",
  "in_reply_to_user_id_str" : "16366882",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keith Boykin",
      "screen_name" : "keithboykin",
      "indices" : [ 3, 15 ],
      "id_str" : "21728303",
      "id" : 21728303
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "266948481963405312",
  "text" : "RT @keithboykin: \"What saved Boehner\u2019s majority wasn\u2019t the will of the people but the power of redistricting. \" - Ezra Klein http://t.co ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 108, 128 ],
        "url" : "http://t.co/xeb1xOkq",
        "expanded_url" : "http://www.washingtonpost.com/blogs/ezra-klein/wp/2012/11/09/house-democrats-got-more-votes-than-house-republicans-yet-boehner-says-hes-got-a-mandate/",
        "display_url" : "washingtonpost.com/blogs/ezra-kle\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "266936512770359298",
    "text" : "\"What saved Boehner\u2019s majority wasn\u2019t the will of the people but the power of redistricting. \" - Ezra Klein http://t.co/xeb1xOkq",
    "id" : 266936512770359298,
    "created_at" : "2012-11-09 16:13:18 +0000",
    "user" : {
      "name" : "Keith Boykin",
      "screen_name" : "keithboykin",
      "protected" : false,
      "id_str" : "21728303",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3050546301/6cd8735c845ea4475cd343213b812efe_normal.jpeg",
      "id" : 21728303,
      "verified" : false
    }
  },
  "id" : 266948481963405312,
  "created_at" : "2012-11-09 17:00:52 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Deval Delivala",
      "screen_name" : "devalad",
      "indices" : [ 0, 8 ],
      "id_str" : "57700233",
      "id" : 57700233
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "266804520351326209",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6088215132, -122.3059641292 ]
  },
  "id_str" : "266817358922932224",
  "in_reply_to_user_id" : 57700233,
  "text" : "@devalad Thank you! He keeps asking when we're moving to San Francisco so hopefully you'll be able to see him in person again soon!",
  "id" : 266817358922932224,
  "in_reply_to_status_id" : 266804520351326209,
  "created_at" : "2012-11-09 08:19:50 +0000",
  "in_reply_to_screen_name" : "devalad",
  "in_reply_to_user_id_str" : "57700233",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "multitudeofdrops",
      "indices" : [ 12, 29 ]
    } ],
    "urls" : [ {
      "indices" : [ 50, 70 ],
      "url" : "http://t.co/5nq19t3P",
      "expanded_url" : "http://instagr.am/p/RzN7ONo0Og/",
      "display_url" : "instagr.am/p/RzN7ONo0Og/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.611399928, -122.333879471 ]
  },
  "id_str" : "266803350652211201",
  "text" : "8:36pm Team #multitudeofdrops @ Regal Meridian 16 http://t.co/5nq19t3P",
  "id" : 266803350652211201,
  "created_at" : "2012-11-09 07:24:10 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 83 ],
      "url" : "http://t.co/5LIjILJP",
      "expanded_url" : "http://4sq.com/TwufYv",
      "display_url" : "4sq.com/TwufYv"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.611399928, -122.3338794708 ]
  },
  "id_str" : "266754998946390016",
  "text" : "Cloud Atlas! (@ Regal Meridian 16 for Cloud Atlas w/ 2 others) http://t.co/5LIjILJP",
  "id" : 266754998946390016,
  "created_at" : "2012-11-09 04:12:02 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://bufferapp.com\" rel=\"nofollow\">Buffer</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dustin curtis",
      "screen_name" : "dcurtis",
      "indices" : [ 1, 9 ],
      "id_str" : "9395832",
      "id" : 9395832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 94 ],
      "url" : "http://t.co/seyLxqKv",
      "expanded_url" : "http://bit.ly/Tc8kbd",
      "display_url" : "bit.ly/Tc8kbd"
    } ]
  },
  "geo" : { },
  "id_str" : "266753028261023745",
  "text" : ".@dcurtis is on fire with the amazing posts lately. On how to make magic: http://t.co/seyLxqKv",
  "id" : 266753028261023745,
  "created_at" : "2012-11-09 04:04:12 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "harryh",
      "screen_name" : "harryh",
      "indices" : [ 0, 7 ],
      "id_str" : "4558",
      "id" : 4558
    }, {
      "name" : "Anil Dash",
      "screen_name" : "anildash",
      "indices" : [ 8, 17 ],
      "id_str" : "36823",
      "id" : 36823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "266740678829162496",
  "geo" : { },
  "id_str" : "266741712725110785",
  "in_reply_to_user_id" : 4558,
  "text" : "@harryh @anildash I agree with Harry. I only have to remember my own shell-shockedness in 2000 and 2004 to relate a tiny bit.",
  "id" : 266741712725110785,
  "in_reply_to_status_id" : 266740678829162496,
  "created_at" : "2012-11-09 03:19:14 +0000",
  "in_reply_to_screen_name" : "harryh",
  "in_reply_to_user_id_str" : "4558",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://bufferapp.com\" rel=\"nofollow\">Buffer</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachel Maddow MSNBC",
      "screen_name" : "maddow",
      "indices" : [ 40, 47 ],
      "id_str" : "16129920",
      "id" : 16129920
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Truth",
      "indices" : [ 0, 6 ]
    } ],
    "urls" : [ {
      "indices" : [ 7, 27 ],
      "url" : "http://t.co/DcYXFiIg",
      "expanded_url" : "http://bit.ly/Tbvezx",
      "display_url" : "bit.ly/Tbvezx"
    } ]
  },
  "geo" : { },
  "id_str" : "266737699581472768",
  "text" : "#Truth http://t.co/DcYXFiIg [video] /by @maddow",
  "id" : 266737699581472768,
  "created_at" : "2012-11-09 03:03:17 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eli Tucker",
      "screen_name" : "etucker",
      "indices" : [ 0, 8 ],
      "id_str" : "5559292",
      "id" : 5559292
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 51 ],
      "url" : "http://t.co/EyF5ASPf",
      "expanded_url" : "http://twitter.com",
      "display_url" : "twitter.com"
    } ]
  },
  "in_reply_to_status_id_str" : "266719617559457792",
  "geo" : { },
  "id_str" : "266726344975581185",
  "in_reply_to_user_id" : 5559292,
  "text" : "@etucker Email me at buster at http://t.co/EyF5ASPf if you have questions about it or want to explore further...",
  "id" : 266726344975581185,
  "in_reply_to_status_id" : 266719617559457792,
  "created_at" : "2012-11-09 02:18:10 +0000",
  "in_reply_to_screen_name" : "etucker",
  "in_reply_to_user_id_str" : "5559292",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eli Tucker",
      "screen_name" : "etucker",
      "indices" : [ 0, 8 ],
      "id_str" : "5559292",
      "id" : 5559292
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "266719617559457792",
  "geo" : { },
  "id_str" : "266726189509533696",
  "in_reply_to_user_id" : 5559292,
  "text" : "@etucker A few are, but usually for video players generally. The requirements are a bit stricter tho since it reqs scaling+performance.",
  "id" : 266726189509533696,
  "in_reply_to_status_id" : 266719617559457792,
  "created_at" : "2012-11-09 02:17:33 +0000",
  "in_reply_to_screen_name" : "etucker",
  "in_reply_to_user_id_str" : "5559292",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eli Tucker",
      "screen_name" : "etucker",
      "indices" : [ 0, 8 ],
      "id_str" : "5559292",
      "id" : 5559292
    }, {
      "name" : "Vizify",
      "screen_name" : "vizify",
      "indices" : [ 83, 90 ],
      "id_str" : "295513152",
      "id" : 295513152
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "266713130678247424",
  "geo" : { },
  "id_str" : "266718311692255233",
  "in_reply_to_user_id" : 5559292,
  "text" : "@etucker Ooh, awesome! Looks great! Any questions or thoughts for improvement? /cc @vizify",
  "id" : 266718311692255233,
  "in_reply_to_status_id" : 266713130678247424,
  "created_at" : "2012-11-09 01:46:15 +0000",
  "in_reply_to_screen_name" : "etucker",
  "in_reply_to_user_id_str" : "5559292",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://bufferapp.com\" rel=\"nofollow\">Buffer</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http://t.co/bSdCU6IL",
      "expanded_url" : "http://nyti.ms/VJcw6E",
      "display_url" : "nyti.ms/VJcw6E"
    } ]
  },
  "geo" : { },
  "id_str" : "266705428904292352",
  "text" : "Why analyze voting trends by race? I think phone operating system or favorite reality tv show would be more meaningful. http://t.co/bSdCU6IL",
  "id" : 266705428904292352,
  "created_at" : "2012-11-09 00:55:04 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://bufferapp.com\" rel=\"nofollow\">Buffer</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "266698130177794048",
  "text" : "I should be able to \"follow\" or \"like\" anything that has mass or energy. Can someone submit a pull request to the universe to fix that?",
  "id" : 266698130177794048,
  "created_at" : "2012-11-09 00:26:03 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Anderegg",
      "screen_name" : "NickAnderegg",
      "indices" : [ 0, 13 ],
      "id_str" : "95100239",
      "id" : 95100239
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 34 ],
      "url" : "http://t.co/ZC85lhnI",
      "expanded_url" : "http://bit.ly/RLeXRM",
      "display_url" : "bit.ly/RLeXRM"
    }, {
      "indices" : [ 37, 57 ],
      "url" : "http://t.co/enkm4hDV",
      "expanded_url" : "http://bit.ly/RLeW0c",
      "display_url" : "bit.ly/RLeW0c"
    } ]
  },
  "in_reply_to_status_id_str" : "266660956904488960",
  "geo" : { },
  "id_str" : "266661124794105856",
  "in_reply_to_user_id" : 95100239,
  "text" : "@NickAnderegg http://t.co/ZC85lhnI / http://t.co/enkm4hDV",
  "id" : 266661124794105856,
  "in_reply_to_status_id" : 266660956904488960,
  "created_at" : "2012-11-08 21:59:01 +0000",
  "in_reply_to_screen_name" : "NickAnderegg",
  "in_reply_to_user_id_str" : "95100239",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alyce Bolton",
      "screen_name" : "alycebh",
      "indices" : [ 0, 8 ],
      "id_str" : "5972492",
      "id" : 5972492
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "266632813674131456",
  "geo" : { },
  "id_str" : "266633328034205696",
  "in_reply_to_user_id" : 5972492,
  "text" : "@alycebh I generally pay with cash. But since this was my 1st time using Square, I wasn't sure if it was user error or not. I had tip guilt.",
  "id" : 266633328034205696,
  "in_reply_to_status_id" : 266632813674131456,
  "created_at" : "2012-11-08 20:08:33 +0000",
  "in_reply_to_screen_name" : "alycebh",
  "in_reply_to_user_id_str" : "5972492",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan King",
      "screen_name" : "rk",
      "indices" : [ 0, 3 ],
      "id_str" : "19853",
      "id" : 19853
    }, {
      "name" : "alex choi \u2744",
      "screen_name" : "xc",
      "indices" : [ 51, 54 ],
      "id_str" : "26233",
      "id" : 26233
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "266631895469678594",
  "geo" : { },
  "id_str" : "266632724704542720",
  "in_reply_to_user_id" : 19853,
  "text" : "@rk I'll look for it next time. Also, according to @xc sounds like it might not be enabled for Starbucks.",
  "id" : 266632724704542720,
  "in_reply_to_status_id" : 266631895469678594,
  "created_at" : "2012-11-08 20:06:10 +0000",
  "in_reply_to_screen_name" : "rk",
  "in_reply_to_user_id_str" : "19853",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Jacobs",
      "screen_name" : "djacobs",
      "indices" : [ 4, 12 ],
      "id_str" : "774842",
      "id" : 774842
    }, {
      "name" : "Square Wallet",
      "screen_name" : "SquareWallet",
      "indices" : [ 42, 55 ],
      "id_str" : "361502914",
      "id" : 361502914
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "266631666368397312",
  "text" : "Pay @djacobs $1 for being complainy about @SquareWallet's lack of a tip feature.",
  "id" : 266631666368397312,
  "created_at" : "2012-11-08 20:01:57 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Jacobs",
      "screen_name" : "djacobs",
      "indices" : [ 0, 8 ],
      "id_str" : "774842",
      "id" : 774842
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "266630719743348737",
  "geo" : { },
  "id_str" : "266631148954857472",
  "in_reply_to_user_id" : 774842,
  "text" : "@djacobs You're really trying to get to $10, huh? I think this is more of a comment than a complaint, but you can make the call.",
  "id" : 266631148954857472,
  "in_reply_to_status_id" : 266630719743348737,
  "created_at" : "2012-11-08 19:59:54 +0000",
  "in_reply_to_screen_name" : "djacobs",
  "in_reply_to_user_id_str" : "774842",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "josh",
      "screen_name" : "joshc",
      "indices" : [ 0, 6 ],
      "id_str" : "2015",
      "id" : 2015
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "266609510456631296",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6118568099, -122.3480257359 ]
  },
  "id_str" : "266612257356660737",
  "in_reply_to_user_id" : 2015,
  "text" : "@joshc Hm you're right. I usually pay with cash and tip the change. Cause I hate change.",
  "id" : 266612257356660737,
  "in_reply_to_status_id" : 266609510456631296,
  "created_at" : "2012-11-08 18:44:50 +0000",
  "in_reply_to_screen_name" : "joshc",
  "in_reply_to_user_id_str" : "2015",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 124 ],
      "url" : "http://t.co/QFKGgnBs",
      "expanded_url" : "http://4sq.com/Z7klSG",
      "display_url" : "4sq.com/Z7klSG"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.609071, -122.339888 ]
  },
  "id_str" : "266607970014617600",
  "text" : "Just \"paid with Square\". Cool but not clear how to leave a tip. Sorry! (@ Starbucks w/ 3 others) [pic]: http://t.co/QFKGgnBs",
  "id" : 266607970014617600,
  "created_at" : "2012-11-08 18:27:48 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Foursquare",
      "screen_name" : "foursquare",
      "indices" : [ 52, 63 ],
      "id_str" : "14120151",
      "id" : 14120151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 131 ],
      "url" : "http://t.co/OnRE7b5l",
      "expanded_url" : "http://4sq.com/WGJw0T",
      "display_url" : "4sq.com/WGJw0T"
    } ]
  },
  "geo" : { },
  "id_str" : "266607962389377024",
  "text" : "I just reached Level 8 of the \"Fresh Brew\" badge on @foursquare. I\u2019ve checked in at 35 different coffee shops! http://t.co/OnRE7b5l",
  "id" : 266607962389377024,
  "created_at" : "2012-11-08 18:27:46 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Jacobs",
      "screen_name" : "djacobs",
      "indices" : [ 0, 8 ],
      "id_str" : "774842",
      "id" : 774842
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "266535001087164416",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6086685391, -122.3059782342 ]
  },
  "id_str" : "266558107927326722",
  "in_reply_to_user_id" : 774842,
  "text" : "@djacobs Yeah! Actually I'm surprised I didn't complain about a lot more!",
  "id" : 266558107927326722,
  "in_reply_to_status_id" : 266535001087164416,
  "created_at" : "2012-11-08 15:09:39 +0000",
  "in_reply_to_screen_name" : "djacobs",
  "in_reply_to_user_id_str" : "774842",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Jacobs",
      "screen_name" : "djacobs",
      "indices" : [ 4, 12 ],
      "id_str" : "774842",
      "id" : 774842
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "266535001087164416",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6086819273, -122.3058715939 ]
  },
  "id_str" : "266557898371518464",
  "in_reply_to_user_id" : 774842,
  "text" : "Pay @djacobs $1 for complaining about the psychopaths.",
  "id" : 266557898371518464,
  "in_reply_to_status_id" : 266535001087164416,
  "created_at" : "2012-11-08 15:08:50 +0000",
  "in_reply_to_screen_name" : "djacobs",
  "in_reply_to_user_id_str" : "774842",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Willo O'Brien",
      "screen_name" : "WilloToons",
      "indices" : [ 0, 11 ],
      "id_str" : "1099629326",
      "id" : 1099629326
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "266462426260721664",
  "geo" : { },
  "id_str" : "266463430133821440",
  "in_reply_to_user_id" : 772386,
  "text" : "@WilloToons Awesome, Willo! I need to do this too.",
  "id" : 266463430133821440,
  "in_reply_to_status_id" : 266462426260721664,
  "created_at" : "2012-11-08 08:53:27 +0000",
  "in_reply_to_screen_name" : "WilloLovesYou",
  "in_reply_to_user_id_str" : "772386",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alicetiara",
      "screen_name" : "alicetiara",
      "indices" : [ 16, 27 ],
      "id_str" : "784078",
      "id" : 784078
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http://t.co/t6lOxmoM",
      "expanded_url" : "http://www.patheos.com/blogs/lovejoyfeminism/2012/10/how-i-lost-faith-in-the-pro-life-movement.html",
      "display_url" : "patheos.com/blogs/lovejoyf\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6086068526, -122.3061341142 ]
  },
  "id_str" : "266456549239709696",
  "text" : "Really good! RT @alicetiara: GREAT post from woman who used to be pro-life on inconsistencies in anti-abortion politics http://t.co/t6lOxmoM",
  "id" : 266456549239709696,
  "created_at" : "2012-11-08 08:26:06 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Coates",
      "screen_name" : "tomcoates",
      "indices" : [ 0, 10 ],
      "id_str" : "12514",
      "id" : 12514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "266448223584006144",
  "geo" : { },
  "id_str" : "266448742142586880",
  "in_reply_to_user_id" : 12514,
  "text" : "@tomcoates Crazytalk. I still think everyone lives in my computer except for a few days in Austin every year. I'll email you.",
  "id" : 266448742142586880,
  "in_reply_to_status_id" : 266448223584006144,
  "created_at" : "2012-11-08 07:55:05 +0000",
  "in_reply_to_screen_name" : "tomcoates",
  "in_reply_to_user_id_str" : "12514",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Coates",
      "screen_name" : "tomcoates",
      "indices" : [ 0, 10 ],
      "id_str" : "12514",
      "id" : 12514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "266447902572965888",
  "geo" : { },
  "id_str" : "266448150712172544",
  "in_reply_to_user_id" : 12514,
  "text" : "@tomcoates We should! Are you really in SF? I'm there next week. And about every other week.",
  "id" : 266448150712172544,
  "in_reply_to_status_id" : 266447902572965888,
  "created_at" : "2012-11-08 07:52:44 +0000",
  "in_reply_to_screen_name" : "tomcoates",
  "in_reply_to_user_id_str" : "12514",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Coates",
      "screen_name" : "tomcoates",
      "indices" : [ 0, 10 ],
      "id_str" : "12514",
      "id" : 12514
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "beenburned",
      "indices" : [ 125, 136 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "266445796935872512",
  "geo" : { },
  "id_str" : "266447777540759552",
  "in_reply_to_user_id" : 12514,
  "text" : "@tomcoates Totally. I've come to terms with SV-style phony-ness. It's the liars, cheats, and psychopaths that boil my blood. #beenburned",
  "id" : 266447777540759552,
  "in_reply_to_status_id" : 266445796935872512,
  "created_at" : "2012-11-08 07:51:15 +0000",
  "in_reply_to_screen_name" : "tomcoates",
  "in_reply_to_user_id_str" : "12514",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Coates",
      "screen_name" : "tomcoates",
      "indices" : [ 0, 10 ],
      "id_str" : "12514",
      "id" : 12514
    }, {
      "name" : "Kevin Marks",
      "screen_name" : "kevinmarks",
      "indices" : [ 11, 22 ],
      "id_str" : "57203",
      "id" : 57203
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "266444062561824768",
  "geo" : { },
  "id_str" : "266444918355017729",
  "in_reply_to_user_id" : 12514,
  "text" : "@tomcoates @kevinmarks Incidentally, that's also why I think the liberals and conservatives in the US should get a divorce and move on.",
  "id" : 266444918355017729,
  "in_reply_to_status_id" : 266444062561824768,
  "created_at" : "2012-11-08 07:39:53 +0000",
  "in_reply_to_screen_name" : "tomcoates",
  "in_reply_to_user_id_str" : "12514",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Coates",
      "screen_name" : "tomcoates",
      "indices" : [ 0, 10 ],
      "id_str" : "12514",
      "id" : 12514
    }, {
      "name" : "Kevin Marks",
      "screen_name" : "kevinmarks",
      "indices" : [ 11, 22 ],
      "id_str" : "57203",
      "id" : 57203
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "brushyourshoulders",
      "indices" : [ 119, 138 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "266444062561824768",
  "geo" : { },
  "id_str" : "266444748410200065",
  "in_reply_to_user_id" : 12514,
  "text" : "@tomcoates @kevinmarks That's what you've been doing. It's easier to build stuff if you aren't fighting a culture war. #brushyourshoulders",
  "id" : 266444748410200065,
  "in_reply_to_status_id" : 266444062561824768,
  "created_at" : "2012-11-08 07:39:12 +0000",
  "in_reply_to_screen_name" : "tomcoates",
  "in_reply_to_user_id_str" : "12514",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Coates",
      "screen_name" : "tomcoates",
      "indices" : [ 0, 10 ],
      "id_str" : "12514",
      "id" : 12514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "266442802731298816",
  "geo" : { },
  "id_str" : "266443303690575873",
  "in_reply_to_user_id" : 12514,
  "text" : "@tomcoates I fear the core is rotten and content myself on a part of the peel where all the people I like are doing cool stuff.",
  "id" : 266443303690575873,
  "in_reply_to_status_id" : 266442802731298816,
  "created_at" : "2012-11-08 07:33:28 +0000",
  "in_reply_to_screen_name" : "tomcoates",
  "in_reply_to_user_id_str" : "12514",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Coates",
      "screen_name" : "tomcoates",
      "indices" : [ 0, 10 ],
      "id_str" : "12514",
      "id" : 12514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "266440948110721025",
  "geo" : { },
  "id_str" : "266442378150309888",
  "in_reply_to_user_id" : 12514,
  "text" : "@tomcoates I agree. But it's painful to watch bc there's a grain of truth in it. Reminds me of real life and validates my judgments a bit.",
  "id" : 266442378150309888,
  "in_reply_to_status_id" : 266440948110721025,
  "created_at" : "2012-11-08 07:29:47 +0000",
  "in_reply_to_screen_name" : "tomcoates",
  "in_reply_to_user_id_str" : "12514",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "266440498586193923",
  "text" : "I'll go on the record and say that Startup Silicon Valley is pretty entertaining. Being a phony is part of the culture\u2026 like it or not.",
  "id" : 266440498586193923,
  "created_at" : "2012-11-08 07:22:19 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Coates",
      "screen_name" : "tomcoates",
      "indices" : [ 0, 10 ],
      "id_str" : "12514",
      "id" : 12514
    }, {
      "name" : "Kevin Marks",
      "screen_name" : "kevinmarks",
      "indices" : [ 11, 22 ],
      "id_str" : "57203",
      "id" : 57203
    }, {
      "name" : "Matt Biddulph",
      "screen_name" : "mattb",
      "indices" : [ 23, 29 ],
      "id_str" : "12530",
      "id" : 12530
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "266428633260900353",
  "geo" : { },
  "id_str" : "266429963165659137",
  "in_reply_to_user_id" : 12514,
  "text" : "@tomcoates @kevinmarks @mattb Some of them are surprisingly like my ideas.",
  "id" : 266429963165659137,
  "in_reply_to_status_id" : 266428633260900353,
  "created_at" : "2012-11-08 06:40:27 +0000",
  "in_reply_to_screen_name" : "tomcoates",
  "in_reply_to_user_id_str" : "12514",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Coates",
      "screen_name" : "tomcoates",
      "indices" : [ 0, 10 ],
      "id_str" : "12514",
      "id" : 12514
    }, {
      "name" : "Kevin Marks",
      "screen_name" : "kevinmarks",
      "indices" : [ 11, 22 ],
      "id_str" : "57203",
      "id" : 57203
    }, {
      "name" : "Matt Biddulph",
      "screen_name" : "mattb",
      "indices" : [ 23, 29 ],
      "id_str" : "12530",
      "id" : 12530
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "266427462345437184",
  "geo" : { },
  "id_str" : "266428478008745985",
  "in_reply_to_user_id" : 12514,
  "text" : "@tomcoates @kevinmarks @mattb I think it's the episode where multiple timelines of the Doctor meet, get amnesia, and fight with each other.",
  "id" : 266428478008745985,
  "in_reply_to_status_id" : 266427462345437184,
  "created_at" : "2012-11-08 06:34:33 +0000",
  "in_reply_to_screen_name" : "tomcoates",
  "in_reply_to_user_id_str" : "12514",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Biddulph",
      "screen_name" : "mattb",
      "indices" : [ 0, 6 ],
      "id_str" : "12530",
      "id" : 12530
    }, {
      "name" : "Tom Coates",
      "screen_name" : "tomcoates",
      "indices" : [ 7, 17 ],
      "id_str" : "12514",
      "id" : 12514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "266425745885241345",
  "geo" : { },
  "id_str" : "266426448192094208",
  "in_reply_to_user_id" : 12530,
  "text" : "@mattb @tomcoates Tom, don't listen to him. It's just like Doctor Who but with better lighting and makeup.",
  "id" : 266426448192094208,
  "in_reply_to_status_id" : 266425745885241345,
  "created_at" : "2012-11-08 06:26:29 +0000",
  "in_reply_to_screen_name" : "mattb",
  "in_reply_to_user_id_str" : "12530",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Coates",
      "screen_name" : "tomcoates",
      "indices" : [ 0, 10 ],
      "id_str" : "12514",
      "id" : 12514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "266425323648868353",
  "geo" : { },
  "id_str" : "266426099054030848",
  "in_reply_to_user_id" : 12514,
  "text" : "@tomcoates They're so cute and British. And/or gay. And/or in togas.",
  "id" : 266426099054030848,
  "in_reply_to_status_id" : 266425323648868353,
  "created_at" : "2012-11-08 06:25:06 +0000",
  "in_reply_to_screen_name" : "tomcoates",
  "in_reply_to_user_id_str" : "12514",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Coates",
      "screen_name" : "tomcoates",
      "indices" : [ 0, 10 ],
      "id_str" : "12514",
      "id" : 12514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "266424828477730816",
  "geo" : { },
  "id_str" : "266425163824902144",
  "in_reply_to_user_id" : 12514,
  "text" : "@tomcoates What, are you jealous? They've even been to SXSW, they're legit.",
  "id" : 266425163824902144,
  "in_reply_to_status_id" : 266424828477730816,
  "created_at" : "2012-11-08 06:21:23 +0000",
  "in_reply_to_screen_name" : "tomcoates",
  "in_reply_to_user_id_str" : "12514",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Coates",
      "screen_name" : "tomcoates",
      "indices" : [ 0, 10 ],
      "id_str" : "12514",
      "id" : 12514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "266424375874551808",
  "geo" : { },
  "id_str" : "266424707744677888",
  "in_reply_to_user_id" : 12514,
  "text" : "@tomcoates I'm enjoying it. One day I want to move to Silicon Valley and totally like change the world and make a difference.",
  "id" : 266424707744677888,
  "in_reply_to_status_id" : 266424375874551808,
  "created_at" : "2012-11-08 06:19:34 +0000",
  "in_reply_to_screen_name" : "tomcoates",
  "in_reply_to_user_id_str" : "12514",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Coates",
      "screen_name" : "tomcoates",
      "indices" : [ 0, 10 ],
      "id_str" : "12514",
      "id" : 12514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "266424194114392064",
  "geo" : { },
  "id_str" : "266424284967235584",
  "in_reply_to_user_id" : 12514,
  "text" : "@tomcoates I dare you.",
  "id" : 266424284967235584,
  "in_reply_to_status_id" : 266424194114392064,
  "created_at" : "2012-11-08 06:17:54 +0000",
  "in_reply_to_screen_name" : "tomcoates",
  "in_reply_to_user_id_str" : "12514",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave McClure",
      "screen_name" : "davemcclure",
      "indices" : [ 24, 36 ],
      "id_str" : "1081",
      "id" : 1081
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "siliconvalley",
      "indices" : [ 109, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "266421850790297600",
  "text" : "Cool, they name dropped @davemcclure in first 30 seconds! I'm sure everyone tweeted this weeks ago\u2026 oh well. #siliconvalley",
  "id" : 266421850790297600,
  "created_at" : "2012-11-08 06:08:13 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "266420291343900672",
  "text" : "Totally, like, watching Startup Silicon Valley now (it was free on iTunes).",
  "id" : 266420291343900672,
  "created_at" : "2012-11-08 06:02:01 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "amanda likes coffee",
      "screen_name" : "amandafiles",
      "indices" : [ 0, 12 ],
      "id_str" : "16371088",
      "id" : 16371088
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "266401225451372544",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6085701101, -122.3062590914 ]
  },
  "id_str" : "266401987891970049",
  "in_reply_to_user_id" : 16371088,
  "text" : "@amandafiles Does that mean he'll get super powers?",
  "id" : 266401987891970049,
  "in_reply_to_status_id" : 266401225451372544,
  "created_at" : "2012-11-08 04:49:18 +0000",
  "in_reply_to_screen_name" : "amandafiles",
  "in_reply_to_user_id_str" : "16371088",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "parentingrules",
      "indices" : [ 88, 103 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 124 ],
      "url" : "http://t.co/wfWAyh7O",
      "expanded_url" : "http://instagr.am/p/RwWnxWo0IZ/",
      "display_url" : "instagr.am/p/RwWnxWo0IZ/"
    } ]
  },
  "geo" : { },
  "id_str" : "266400447328296961",
  "text" : "8:36pm I asked Niko to kiss his pet rock 5 times if he wanted me to get him more water. #parentingrules http://t.co/wfWAyh7O",
  "id" : 266400447328296961,
  "created_at" : "2012-11-08 04:43:10 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Levie",
      "screen_name" : "levie",
      "indices" : [ 1, 7 ],
      "id_str" : "914061",
      "id" : 914061
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "266370437385187329",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6086633048, -122.3060901092 ]
  },
  "id_str" : "266377298180190208",
  "in_reply_to_user_id" : 914061,
  "text" : ".@levie When it's data about opinions, opinions can change data (so can data). Pundits were trying to change the numbers, not report them.",
  "id" : 266377298180190208,
  "in_reply_to_status_id" : 266370437385187329,
  "created_at" : "2012-11-08 03:11:11 +0000",
  "in_reply_to_screen_name" : "levie",
  "in_reply_to_user_id_str" : "914061",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Cottrell",
      "screen_name" : "rgcottrell",
      "indices" : [ 0, 11 ],
      "id_str" : "752553",
      "id" : 752553
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "266323188873584640",
  "geo" : { },
  "id_str" : "266344950319419393",
  "in_reply_to_user_id" : 752553,
  "text" : "@rgcottrell Okay, approved you. Will take a couple hours to take affect, I think\u2026 but try it tomorrow and let me know if it works!",
  "id" : 266344950319419393,
  "in_reply_to_status_id" : 266323188873584640,
  "created_at" : "2012-11-08 01:02:39 +0000",
  "in_reply_to_screen_name" : "rgcottrell",
  "in_reply_to_user_id_str" : "752553",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://bufferapp.com\" rel=\"nofollow\">Buffer</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 54 ],
      "url" : "http://t.co/6qMCwgoL",
      "expanded_url" : "http://bit.ly/T4z8tU",
      "display_url" : "bit.ly/T4z8tU"
    } ]
  },
  "geo" : { },
  "id_str" : "266343040925458434",
  "text" : "Finally got my own Nikogram page: http://t.co/6qMCwgoL",
  "id" : 266343040925458434,
  "created_at" : "2012-11-08 00:55:04 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Cottrell",
      "screen_name" : "rgcottrell",
      "indices" : [ 0, 11 ],
      "id_str" : "752553",
      "id" : 752553
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 92 ],
      "url" : "http://t.co/WWtqey07",
      "expanded_url" : "http://bit.ly/UIuaXQ",
      "display_url" : "bit.ly/UIuaXQ"
    } ]
  },
  "in_reply_to_status_id_str" : "266320046710726656",
  "geo" : { },
  "id_str" : "266321443577532417",
  "in_reply_to_user_id" : 752553,
  "text" : "@rgcottrell If you submit it and let me know, I can approve it for you. http://t.co/WWtqey07",
  "id" : 266321443577532417,
  "in_reply_to_status_id" : 266320046710726656,
  "created_at" : "2012-11-07 23:29:14 +0000",
  "in_reply_to_screen_name" : "rgcottrell",
  "in_reply_to_user_id_str" : "752553",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dustin curtis",
      "screen_name" : "dcurtis",
      "indices" : [ 3, 11 ],
      "id_str" : "9395832",
      "id" : 9395832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 44 ],
      "url" : "http://t.co/Rl98dxUD",
      "expanded_url" : "http://dcurt.is/the-best",
      "display_url" : "dcurt.is/the-best"
    } ]
  },
  "geo" : { },
  "id_str" : "266308650434457600",
  "text" : "RT @dcurtis: The Best \n\nhttp://t.co/Rl98dxUD",
  "retweeted_status" : {
    "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 11, 31 ],
        "url" : "http://t.co/Rl98dxUD",
        "expanded_url" : "http://dcurt.is/the-best",
        "display_url" : "dcurt.is/the-best"
      } ]
    },
    "geo" : { },
    "id_str" : "266304841092046849",
    "text" : "The Best \n\nhttp://t.co/Rl98dxUD",
    "id" : 266304841092046849,
    "created_at" : "2012-11-07 22:23:16 +0000",
    "user" : {
      "name" : "dustin curtis",
      "screen_name" : "dcurtis",
      "protected" : false,
      "id_str" : "9395832",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3586312198/4f90d52a9416842731420c9e3cb1ec9f_normal.png",
      "id" : 9395832,
      "verified" : false
    }
  },
  "id" : 266308650434457600,
  "created_at" : "2012-11-07 22:38:24 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://bufferapp.com\" rel=\"nofollow\">Buffer</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sylvain Carle",
      "screen_name" : "froginthevalley",
      "indices" : [ 45, 61 ],
      "id_str" : "657693",
      "id" : 657693
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 83 ],
      "url" : "http://t.co/8HCKvON6",
      "expanded_url" : "http://bit.ly/RWUuYo",
      "display_url" : "bit.ly/RWUuYo"
    } ]
  },
  "geo" : { },
  "id_str" : "266298472469245952",
  "text" : "\"Tips and tricks for better Twitter Cards\" - @froginthevalley  http://t.co/8HCKvON6",
  "id" : 266298472469245952,
  "created_at" : "2012-11-07 21:57:58 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "girl jo",
      "screen_name" : "octavekitten",
      "indices" : [ 0, 13 ],
      "id_str" : "16366882",
      "id" : 16366882
    }, {
      "name" : "Pickle and Jam",
      "screen_name" : "pickleandjam",
      "indices" : [ 14, 27 ],
      "id_str" : "599601895",
      "id" : 599601895
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "266296831254855680",
  "geo" : { },
  "id_str" : "266297133563527169",
  "in_reply_to_user_id" : 16366882,
  "text" : "@octavekitten @pickleandjam 2nd!",
  "id" : 266297133563527169,
  "in_reply_to_status_id" : 266296831254855680,
  "created_at" : "2012-11-07 21:52:38 +0000",
  "in_reply_to_screen_name" : "octavekitten",
  "in_reply_to_user_id_str" : "16366882",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Fuchs",
      "screen_name" : "jfuchs",
      "indices" : [ 0, 7 ],
      "id_str" : "1026",
      "id" : 1026
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 67 ],
      "url" : "http://t.co/SFCxnNLW",
      "expanded_url" : "http://4sq.com/U9Rw34",
      "display_url" : "4sq.com/U9Rw34"
    } ]
  },
  "in_reply_to_status_id_str" : "266288663313412096",
  "geo" : { },
  "id_str" : "266295794561339392",
  "in_reply_to_user_id" : 1026,
  "text" : "@jfuchs In that case, let's meet at Ma'velous: http://t.co/SFCxnNLW",
  "id" : 266295794561339392,
  "in_reply_to_status_id" : 266288663313412096,
  "created_at" : "2012-11-07 21:47:19 +0000",
  "in_reply_to_screen_name" : "jfuchs",
  "in_reply_to_user_id_str" : "1026",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kickstarter",
      "screen_name" : "kickstarter",
      "indices" : [ 44, 56 ],
      "id_str" : "16186995",
      "id" : 16186995
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 116 ],
      "url" : "http://t.co/53TZv9xk",
      "expanded_url" : "http://kck.st/YLrKrB",
      "display_url" : "kck.st/YLrKrB"
    } ]
  },
  "geo" : { },
  "id_str" : "266291473216057344",
  "text" : "I just backed my friends' new food truck on @Kickstarter. You should too if you like tastiness. http://t.co/53TZv9xk",
  "id" : 266291473216057344,
  "created_at" : "2012-11-07 21:30:09 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Kottke",
      "screen_name" : "jkottke",
      "indices" : [ 0, 8 ],
      "id_str" : "1305941",
      "id" : 1305941
    }, {
      "name" : "Anil Dash",
      "screen_name" : "anildash",
      "indices" : [ 9, 18 ],
      "id_str" : "36823",
      "id" : 36823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "266286968957202432",
  "geo" : { },
  "id_str" : "266287582965534720",
  "in_reply_to_user_id" : 1305941,
  "text" : "@jkottke @anildash What, nothing interesting was tweeted between 6 and 7pm?",
  "id" : 266287582965534720,
  "in_reply_to_status_id" : 266286968957202432,
  "created_at" : "2012-11-07 21:14:41 +0000",
  "in_reply_to_screen_name" : "jkottke",
  "in_reply_to_user_id_str" : "1305941",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Fuchs",
      "screen_name" : "jfuchs",
      "indices" : [ 0, 7 ],
      "id_str" : "1026",
      "id" : 1026
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "266283823359221760",
  "geo" : { },
  "id_str" : "266286846349283328",
  "in_reply_to_user_id" : 1026,
  "text" : "@jfuchs Around 1pm? If you wanted to come to the Twitter office I could give you a tour.",
  "id" : 266286846349283328,
  "in_reply_to_status_id" : 266283823359221760,
  "created_at" : "2012-11-07 21:11:46 +0000",
  "in_reply_to_screen_name" : "jfuchs",
  "in_reply_to_user_id_str" : "1026",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Fuchs",
      "screen_name" : "jfuchs",
      "indices" : [ 0, 7 ],
      "id_str" : "1026",
      "id" : 1026
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "266280667300630528",
  "geo" : { },
  "id_str" : "266282132014526464",
  "in_reply_to_user_id" : 1026,
  "text" : "@jfuchs Sure! I'm in SF next week\u2026 and the office is near Civic Center\u2026 are you anywhere near there?",
  "id" : 266282132014526464,
  "in_reply_to_status_id" : 266280667300630528,
  "created_at" : "2012-11-07 20:53:02 +0000",
  "in_reply_to_screen_name" : "jfuchs",
  "in_reply_to_user_id_str" : "1026",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aatish Bhatia",
      "screen_name" : "aatishb",
      "indices" : [ 3, 11 ],
      "id_str" : "300735398",
      "id" : 300735398
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "natesilverfacts",
      "indices" : [ 103, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "266277141413519360",
  "text" : "RT @aatishb: Nate Silver knows how many times the cannonballs will fly before they are forever banned. #natesilverfacts",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "natesilverfacts",
        "indices" : [ 90, 106 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "266251308397391872",
    "text" : "Nate Silver knows how many times the cannonballs will fly before they are forever banned. #natesilverfacts",
    "id" : 266251308397391872,
    "created_at" : "2012-11-07 18:50:33 +0000",
    "user" : {
      "name" : "Aatish Bhatia",
      "screen_name" : "aatishb",
      "protected" : false,
      "id_str" : "300735398",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3004047290/1fb4826dac2a09c3431bf19a21c0d669_normal.jpeg",
      "id" : 300735398,
      "verified" : false
    }
  },
  "id" : 266277141413519360,
  "created_at" : "2012-11-07 20:33:12 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "gavin gourley",
      "screen_name" : "summitandolive",
      "indices" : [ 0, 15 ],
      "id_str" : "38113339",
      "id" : 38113339
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "266267264477704195",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6122993206, -122.3450377398 ]
  },
  "id_str" : "266268435162476544",
  "in_reply_to_user_id" : 38113339,
  "text" : "@summitandolive Yeah, it's a good book. Worth reading.",
  "id" : 266268435162476544,
  "in_reply_to_status_id" : 266267264477704195,
  "created_at" : "2012-11-07 19:58:36 +0000",
  "in_reply_to_screen_name" : "summitandolive",
  "in_reply_to_user_id_str" : "38113339",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 134 ],
      "url" : "http://t.co/GrxQEDQA",
      "expanded_url" : "http://engineering.twitter.com/2012/11/bolstering-our-infrastructure.html?utm_source=dlvr.it&utm_medium=twitter&m=1",
      "display_url" : "engineering.twitter.com/2012/11/bolste\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6124540408, -122.3448855363 ]
  },
  "id_str" : "266268293361459201",
  "text" : "If you're an engineer and like what this post is talking about, you should apply to work here. Lmk if I can help! http://t.co/GrxQEDQA",
  "id" : 266268293361459201,
  "created_at" : "2012-11-07 19:58:02 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "266237511087570945",
  "text" : "I don't know how I would've survived election night without TweetDeck. I have columns for all followers, close friends, coworkers, etc.",
  "id" : 266237511087570945,
  "created_at" : "2012-11-07 17:55:43 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http://t.co/yG8fGzn0",
      "expanded_url" : "http://bit.ly/TL9GMb",
      "display_url" : "bit.ly/TL9GMb"
    } ]
  },
  "geo" : { },
  "id_str" : "266236912019324928",
  "text" : "The new version of TweetDeck is great for power users. Advanced search columns, list support, and keyboard shortcuts: http://t.co/yG8fGzn0",
  "id" : 266236912019324928,
  "created_at" : "2012-11-07 17:53:20 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 53 ],
      "url" : "https://t.co/6ZUzg359",
      "expanded_url" : "https://twitter.com/BarackObama/status/266031293945503744",
      "display_url" : "twitter.com/BarackObama/st\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6086558868, -122.3059900292 ]
  },
  "id_str" : "266209283350360064",
  "text" : "Woah hey lots of retweets here: https://t.co/6ZUzg359",
  "id" : 266209283350360064,
  "created_at" : "2012-11-07 16:03:33 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe McCarthy",
      "screen_name" : "gumption",
      "indices" : [ 3, 12 ],
      "id_str" : "2061681",
      "id" : 2061681
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "266200359972773888",
  "text" : "RT @gumption: Breaking: to the surprise of pundits, numbers continue to be best system of determining which of two things is larger http ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 138 ],
        "url" : "http://t.co/UwpBII5x",
        "expanded_url" : "http://xkcd.com/1131/",
        "display_url" : "xkcd.com/1131/"
      } ]
    },
    "geo" : { },
    "id_str" : "266190809882316800",
    "text" : "Breaking: to the surprise of pundits, numbers continue to be best system of determining which of two things is larger http://t.co/UwpBII5x",
    "id" : 266190809882316800,
    "created_at" : "2012-11-07 14:50:09 +0000",
    "user" : {
      "name" : "Joe McCarthy",
      "screen_name" : "gumption",
      "protected" : false,
      "id_str" : "2061681",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1196599888/Joe-small-200x200_normal.jpg",
      "id" : 2061681,
      "verified" : false
    }
  },
  "id" : 266200359972773888,
  "created_at" : "2012-11-07 15:28:06 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Few",
      "screen_name" : "jfew",
      "indices" : [ 0, 5 ],
      "id_str" : "2067141",
      "id" : 2067141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "266083257051914240",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6086096419, -122.3060446742 ]
  },
  "id_str" : "266083519128817664",
  "in_reply_to_user_id" : 2067141,
  "text" : "@jfew Darn. Still crossing fingers then.",
  "id" : 266083519128817664,
  "in_reply_to_status_id" : 266083257051914240,
  "created_at" : "2012-11-07 07:43:49 +0000",
  "in_reply_to_screen_name" : "jfew",
  "in_reply_to_user_id_str" : "2067141",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Few",
      "screen_name" : "jfew",
      "indices" : [ 0, 5 ],
      "id_str" : "2067141",
      "id" : 2067141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "266077401128251393",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6086119656, -122.3060088885 ]
  },
  "id_str" : "266082033678311425",
  "in_reply_to_user_id" : 2067141,
  "text" : "@jfew Where do you see that??",
  "id" : 266082033678311425,
  "in_reply_to_status_id" : 266077401128251393,
  "created_at" : "2012-11-07 07:37:55 +0000",
  "in_reply_to_screen_name" : "jfew",
  "in_reply_to_user_id_str" : "2067141",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twitter Comms",
      "screen_name" : "twittercomms",
      "indices" : [ 3, 16 ],
      "id_str" : "234489024",
      "id" : 234489024
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 112 ],
      "url" : "http://t.co/1cHv0Kx7",
      "expanded_url" : "http://blog.twitter.com/2012/11/election-night-2012.html",
      "display_url" : "blog.twitter.com/2012/11/electi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "266081431481090048",
  "text" : "RT @twittercomms: Election Day wrap-up: 31MM Tweets, with a peak of 327,452 TPM. Read more: http://t.co/1cHv0Kx7",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 74, 94 ],
        "url" : "http://t.co/1cHv0Kx7",
        "expanded_url" : "http://blog.twitter.com/2012/11/election-night-2012.html",
        "display_url" : "blog.twitter.com/2012/11/electi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "266078034396848128",
    "text" : "Election Day wrap-up: 31MM Tweets, with a peak of 327,452 TPM. Read more: http://t.co/1cHv0Kx7",
    "id" : 266078034396848128,
    "created_at" : "2012-11-07 07:22:01 +0000",
    "user" : {
      "name" : "Twitter Comms",
      "screen_name" : "twittercomms",
      "protected" : false,
      "id_str" : "234489024",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2284174874/h8zi79wfvlih4tcuh41y_normal.png",
      "id" : 234489024,
      "verified" : true
    }
  },
  "id" : 266081431481090048,
  "created_at" : "2012-11-07 07:35:31 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Freitas",
      "screen_name" : "ryanchris",
      "indices" : [ 3, 13 ],
      "id_str" : "13349",
      "id" : 13349
    }, {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 25, 33 ],
      "id_str" : "783214",
      "id" : 783214
    }, {
      "name" : "Nate Silver",
      "screen_name" : "fivethirtyeight",
      "indices" : [ 38, 54 ],
      "id_str" : "16017475",
      "id" : 16017475
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "266077182303035392",
  "text" : "RT @ryanchris: If I have @twitter and @fivethirtyeight, why should I ever watch election night coverage again?",
  "retweeted_status" : {
    "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Twitter",
        "screen_name" : "twitter",
        "indices" : [ 10, 18 ],
        "id_str" : "783214",
        "id" : 783214
      }, {
        "name" : "Nate Silver",
        "screen_name" : "fivethirtyeight",
        "indices" : [ 23, 39 ],
        "id_str" : "16017475",
        "id" : 16017475
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "266077111276687360",
    "text" : "If I have @twitter and @fivethirtyeight, why should I ever watch election night coverage again?",
    "id" : 266077111276687360,
    "created_at" : "2012-11-07 07:18:21 +0000",
    "user" : {
      "name" : "Ryan Freitas",
      "screen_name" : "ryanchris",
      "protected" : false,
      "id_str" : "13349",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1321493001/medium_normal.jpg",
      "id" : 13349,
      "verified" : false
    }
  },
  "id" : 266077182303035392,
  "created_at" : "2012-11-07 07:18:38 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "266072479544537088",
  "text" : "Wow. Great. Speech.",
  "id" : 266072479544537088,
  "created_at" : "2012-11-07 06:59:57 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Marks",
      "screen_name" : "kevinmarks",
      "indices" : [ 0, 11 ],
      "id_str" : "57203",
      "id" : 57203
    }, {
      "name" : "Jane McGonigal",
      "screen_name" : "avantgame",
      "indices" : [ 12, 22 ],
      "id_str" : "681813",
      "id" : 681813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "266070371093082112",
  "geo" : { },
  "id_str" : "266071566482292736",
  "in_reply_to_user_id" : 57203,
  "text" : "@kevinmarks @avantgame Ah, yeah.",
  "id" : 266071566482292736,
  "in_reply_to_status_id" : 266070371093082112,
  "created_at" : "2012-11-07 06:56:19 +0000",
  "in_reply_to_screen_name" : "kevinmarks",
  "in_reply_to_user_id_str" : "57203",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jane McGonigal",
      "screen_name" : "avantgame",
      "indices" : [ 0, 10 ],
      "id_str" : "681813",
      "id" : 681813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 75 ],
      "url" : "http://t.co/iTEhMjiH",
      "expanded_url" : "http://nyti.ms/PCAjm2",
      "display_url" : "nyti.ms/PCAjm2"
    } ]
  },
  "in_reply_to_status_id_str" : "266068072606076928",
  "geo" : { },
  "id_str" : "266068524848533504",
  "in_reply_to_user_id" : 681813,
  "text" : "@avantgame I don't think NC was a swing state, was it? http://t.co/iTEhMjiH",
  "id" : 266068524848533504,
  "in_reply_to_status_id" : 266068072606076928,
  "created_at" : "2012-11-07 06:44:14 +0000",
  "in_reply_to_screen_name" : "avantgame",
  "in_reply_to_user_id_str" : "681813",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "266066338735353856",
  "text" : "Did Obama really sweep the swing states?",
  "id" : 266066338735353856,
  "created_at" : "2012-11-07 06:35:33 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Sarver",
      "screen_name" : "rsarver",
      "indices" : [ 3, 11 ],
      "id_str" : "795649",
      "id" : 795649
    }, {
      "name" : "Nate Silver",
      "screen_name" : "fivethirtyeight",
      "indices" : [ 18, 34 ],
      "id_str" : "16017475",
      "id" : 16017475
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "266064563219345409",
  "text" : "RT @rsarver: Wow. @fivethirtyeight called 50 out of 50 states. Hopefully this is going to change the next election for pundits http://t. ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nate Silver",
        "screen_name" : "fivethirtyeight",
        "indices" : [ 5, 21 ],
        "id_str" : "16017475",
        "id" : 16017475
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 134 ],
        "url" : "http://t.co/ENBj7v8p",
        "expanded_url" : "http://fivethirtyeight.blogs.nytimes.com/",
        "display_url" : "fivethirtyeight.blogs.nytimes.com"
      } ]
    },
    "geo" : { },
    "id_str" : "266060712563060736",
    "text" : "Wow. @fivethirtyeight called 50 out of 50 states. Hopefully this is going to change the next election for pundits http://t.co/ENBj7v8p",
    "id" : 266060712563060736,
    "created_at" : "2012-11-07 06:13:11 +0000",
    "user" : {
      "name" : "Ryan Sarver",
      "screen_name" : "rsarver",
      "protected" : false,
      "id_str" : "795649",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3015419114/3dc096c48ef6167d1b26fd0d6b01814d_normal.jpeg",
      "id" : 795649,
      "verified" : false
    }
  },
  "id" : 266064563219345409,
  "created_at" : "2012-11-07 06:28:29 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Kalucki",
      "screen_name" : "jkalucki",
      "indices" : [ 94, 103 ],
      "id_str" : "12863272",
      "id" : 12863272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 125 ],
      "url" : "https://t.co/t6XVWIBo",
      "expanded_url" : "https://twitter.com/jkalucki/status/266045418448773120",
      "display_url" : "twitter.com/jkalucki/statu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "266061336511918080",
  "text" : "Tweets during the 2008 election peaked at 229 tweets/sec. 0.0006% of tonight's election. /via @jkalucki https://t.co/t6XVWIBo",
  "id" : 266061336511918080,
  "created_at" : "2012-11-07 06:15:40 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "harryh",
      "screen_name" : "harryh",
      "indices" : [ 0, 7 ],
      "id_str" : "4558",
      "id" : 4558
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "266057306410721280",
  "geo" : { },
  "id_str" : "266058095724199936",
  "in_reply_to_user_id" : 4558,
  "text" : "@harryh Agreed and also think the shitballs crazy stuff goes way beyond state initiative systems.",
  "id" : 266058095724199936,
  "in_reply_to_status_id" : 266057306410721280,
  "created_at" : "2012-11-07 06:02:47 +0000",
  "in_reply_to_screen_name" : "harryh",
  "in_reply_to_user_id_str" : "4558",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "harryh",
      "screen_name" : "harryh",
      "indices" : [ 0, 7 ],
      "id_str" : "4558",
      "id" : 4558
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "266055620896100352",
  "geo" : { },
  "id_str" : "266056475292606464",
  "in_reply_to_user_id" : 4558,
  "text" : "@harryh I've been swayed to agree with you there now. There is never a perfect initiative though, it's a battle over gray areas.",
  "id" : 266056475292606464,
  "in_reply_to_status_id" : 266055620896100352,
  "created_at" : "2012-11-07 05:56:21 +0000",
  "in_reply_to_screen_name" : "harryh",
  "in_reply_to_user_id_str" : "4558",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Renee DiResta",
      "screen_name" : "noUpside",
      "indices" : [ 0, 9 ],
      "id_str" : "24254084",
      "id" : 24254084
    }, {
      "name" : "harryh",
      "screen_name" : "harryh",
      "indices" : [ 10, 17 ],
      "id_str" : "4558",
      "id" : 4558
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 137 ],
      "url" : "http://t.co/3vMBxxSr",
      "expanded_url" : "http://nyti.ms/RTQSq6",
      "display_url" : "nyti.ms/RTQSq6"
    } ]
  },
  "in_reply_to_status_id_str" : "266055208705093633",
  "geo" : { },
  "id_str" : "266055908369502209",
  "in_reply_to_user_id" : 24254084,
  "text" : "@noUpside @harryh You may be right. I didn't research it since I didn't vote in CA. I just like Mark Bittman's idea: http://t.co/3vMBxxSr",
  "id" : 266055908369502209,
  "in_reply_to_status_id" : 266055208705093633,
  "created_at" : "2012-11-07 05:54:06 +0000",
  "in_reply_to_screen_name" : "noUpside",
  "in_reply_to_user_id_str" : "24254084",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "harryh",
      "screen_name" : "harryh",
      "indices" : [ 0, 7 ],
      "id_str" : "4558",
      "id" : 4558
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "266053458828873728",
  "geo" : { },
  "id_str" : "266054897349304321",
  "in_reply_to_user_id" : 4558,
  "text" : "@harryh There's still a lot we don't know about GMOs, and it's not unreasonable to want more insight. Esp since big agra is so evil.",
  "id" : 266054897349304321,
  "in_reply_to_status_id" : 266053458828873728,
  "created_at" : "2012-11-07 05:50:05 +0000",
  "in_reply_to_screen_name" : "harryh",
  "in_reply_to_user_id_str" : "4558",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Cottrell",
      "screen_name" : "rgcottrell",
      "indices" : [ 0, 11 ],
      "id_str" : "752553",
      "id" : 752553
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "266052449834528768",
  "geo" : { },
  "id_str" : "266053128330293248",
  "in_reply_to_user_id" : 752553,
  "text" : "@rgcottrell I couldn't help bragging. Because it IS so interesting.",
  "id" : 266053128330293248,
  "in_reply_to_status_id" : 266052449834528768,
  "created_at" : "2012-11-07 05:43:03 +0000",
  "in_reply_to_screen_name" : "rgcottrell",
  "in_reply_to_user_id_str" : "752553",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "harryh",
      "screen_name" : "harryh",
      "indices" : [ 0, 7 ],
      "id_str" : "4558",
      "id" : 4558
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "266051406073569280",
  "geo" : { },
  "id_str" : "266052301763002368",
  "in_reply_to_user_id" : 4558,
  "text" : "@harryh The analogy holds but is misleading. The trend is that facts matter, and it's important to put data front and center.",
  "id" : 266052301763002368,
  "in_reply_to_status_id" : 266051406073569280,
  "created_at" : "2012-11-07 05:39:46 +0000",
  "in_reply_to_screen_name" : "harryh",
  "in_reply_to_user_id_str" : "4558",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Crocker",
      "screen_name" : "nickcrocker",
      "indices" : [ 0, 12 ],
      "id_str" : "30801469",
      "id" : 30801469
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "266050643599450112",
  "geo" : { },
  "id_str" : "266051646344290304",
  "in_reply_to_user_id" : 30801469,
  "text" : "@nickcrocker Mostly confidential for now\u2026 I bet there will be lots of data shared tomorrow though.",
  "id" : 266051646344290304,
  "in_reply_to_status_id" : 266050643599450112,
  "created_at" : "2012-11-07 05:37:10 +0000",
  "in_reply_to_screen_name" : "nickcrocker",
  "in_reply_to_user_id_str" : "30801469",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "harryh",
      "screen_name" : "harryh",
      "indices" : [ 0, 7 ],
      "id_str" : "4558",
      "id" : 4558
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "266049864155144192",
  "geo" : { },
  "id_str" : "266051026417770498",
  "in_reply_to_user_id" : 4558,
  "text" : "@harryh Now you're just trolling. :)",
  "id" : 266051026417770498,
  "in_reply_to_status_id" : 266049864155144192,
  "created_at" : "2012-11-07 05:34:42 +0000",
  "in_reply_to_screen_name" : "harryh",
  "in_reply_to_user_id_str" : "4558",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twitter Engineering",
      "screen_name" : "TwitterEng",
      "indices" : [ 19, 30 ],
      "id_str" : "6844292",
      "id" : 6844292
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hifive",
      "indices" : [ 131, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "266048301147750400",
  "text" : "I've been watching @twittereng internal site analytics all night -- a SUPER interesting view into the back stage of the hive mind. #hifive",
  "id" : 266048301147750400,
  "created_at" : "2012-11-07 05:23:52 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "phew",
      "indices" : [ 69, 74 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "266043623437631489",
  "text" : "Nate Silver's not worried about the popular vote\u2026 then neither am I. #phew",
  "id" : 266043623437631489,
  "created_at" : "2012-11-07 05:05:17 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twitter Government",
      "screen_name" : "gov",
      "indices" : [ 3, 7 ],
      "id_str" : "222953824",
      "id" : 222953824
    }, {
      "name" : "Barack Obama",
      "screen_name" : "BarackObama",
      "indices" : [ 27, 39 ],
      "id_str" : "813286",
      "id" : 813286
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Election2012",
      "indices" : [ 58, 71 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "266040783977713664",
  "text" : "RT @gov: Networks' call of @BarackObama reelection spiked #Election2012-related Tweets to 327,453 per minute at 11:19p EST.",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Barack Obama",
        "screen_name" : "BarackObama",
        "indices" : [ 18, 30 ],
        "id_str" : "813286",
        "id" : 813286
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Election2012",
        "indices" : [ 49, 62 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "266040234934939649",
    "text" : "Networks' call of @BarackObama reelection spiked #Election2012-related Tweets to 327,453 per minute at 11:19p EST.",
    "id" : 266040234934939649,
    "created_at" : "2012-11-07 04:51:49 +0000",
    "user" : {
      "name" : "Twitter Government",
      "screen_name" : "gov",
      "protected" : false,
      "id_str" : "222953824",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2284291316/xu1u3i11ugj03en53ujr_normal.png",
      "id" : 222953824,
      "verified" : true
    }
  },
  "id" : 266040783977713664,
  "created_at" : "2012-11-07 04:54:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barack Obama",
      "screen_name" : "BarackObama",
      "indices" : [ 3, 15 ],
      "id_str" : "813286",
      "id" : 813286
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/BarackObama/status/266031293945503744/photo/1",
      "indices" : [ 34, 54 ],
      "url" : "http://t.co/bAJE6Vom",
      "media_url" : "http://pbs.twimg.com/media/A7EiDWcCYAAZT1D.jpg",
      "id_str" : "266031293949698048",
      "id" : 266031293949698048,
      "media_url_https" : "https://pbs.twimg.com/media/A7EiDWcCYAAZT1D.jpg",
      "sizes" : [ {
        "h" : 532,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 399,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 532,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com/bAJE6Vom"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "266038333526917122",
  "text" : "RT @BarackObama: Four more years. http://t.co/bAJE6Vom",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http://twitter.com/BarackObama/status/266031293945503744/photo/1",
        "indices" : [ 17, 37 ],
        "url" : "http://t.co/bAJE6Vom",
        "media_url" : "http://pbs.twimg.com/media/A7EiDWcCYAAZT1D.jpg",
        "id_str" : "266031293949698048",
        "id" : 266031293949698048,
        "media_url_https" : "https://pbs.twimg.com/media/A7EiDWcCYAAZT1D.jpg",
        "sizes" : [ {
          "h" : 532,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 399,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 532,
          "resize" : "fit",
          "w" : 800
        } ],
        "display_url" : "pic.twitter.com/bAJE6Vom"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "266031293945503744",
    "text" : "Four more years. http://t.co/bAJE6Vom",
    "id" : 266031293945503744,
    "created_at" : "2012-11-07 04:16:18 +0000",
    "user" : {
      "name" : "Barack Obama",
      "screen_name" : "BarackObama",
      "protected" : false,
      "id_str" : "813286",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3221742532/5ceae8f2b72a1a8b012d2f5960fb46be_normal.jpeg",
      "id" : 813286,
      "verified" : true
    }
  },
  "id" : 266038333526917122,
  "created_at" : "2012-11-07 04:44:16 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 73 ],
      "url" : "http://t.co/jDw60Tmd",
      "expanded_url" : "http://flic.kr/p/drm5AK",
      "display_url" : "flic.kr/p/drm5AK"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.608666, -122.306 ]
  },
  "id_str" : "266038123291623424",
  "text" : "8:36pm OBAMA WINS! Photo taken with my third screen. http://t.co/jDw60Tmd",
  "id" : 266038123291623424,
  "created_at" : "2012-11-07 04:43:26 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dick costolo",
      "screen_name" : "dickc",
      "indices" : [ 26, 32 ],
      "id_str" : "6385432",
      "id" : 6385432
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6086572698, -122.30608508 ]
  },
  "id_str" : "266036866363584513",
  "text" : "Many tweets were made. RT @dickc: Wow. The tweets they are many. Incredible.",
  "id" : 266036866363584513,
  "created_at" : "2012-11-07 04:38:26 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "election2012",
      "indices" : [ 8, 21 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "266032384871366657",
  "text" : "Stoked! #election2012",
  "id" : 266032384871366657,
  "created_at" : "2012-11-07 04:20:37 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elizabeth Bear",
      "screen_name" : "matociquala",
      "indices" : [ 3, 15 ],
      "id_str" : "15837189",
      "id" : 15837189
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "266030632990289921",
  "text" : "RT @matociquala: So if Nate Silver's math works... do you suppose all those OTHER scientists might be on to something?",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "266024709672538113",
    "text" : "So if Nate Silver's math works... do you suppose all those OTHER scientists might be on to something?",
    "id" : 266024709672538113,
    "created_at" : "2012-11-07 03:50:07 +0000",
    "user" : {
      "name" : "Elizabeth Bear",
      "screen_name" : "matociquala",
      "protected" : false,
      "id_str" : "15837189",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3244413078/d7fa9acad6ec4b22eca35b7cd3f09585_normal.jpeg",
      "id" : 15837189,
      "verified" : false
    }
  },
  "id" : 266030632990289921,
  "created_at" : "2012-11-07 04:13:40 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 29 ],
      "url" : "http://t.co/70NmvlpL",
      "expanded_url" : "http://live.comedycentral.com",
      "display_url" : "live.comedycentral.com"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6086231554, -122.3060840742 ]
  },
  "id_str" : "266028841548517377",
  "text" : "Finally: http://t.co/70NmvlpL",
  "id" : 266028841548517377,
  "created_at" : "2012-11-07 04:06:33 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anil Dash",
      "screen_name" : "anildash",
      "indices" : [ 3, 12 ],
      "id_str" : "36823",
      "id" : 36823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "266024396240613376",
  "text" : "RT @anildash: To the rational right: The anti-science, anti-fact bubble in your party is why you feel such despair tonight. That's what  ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "266021841380986880",
    "text" : "To the rational right: The anti-science, anti-fact bubble in your party is why you feel such despair tonight. That's what you should fight.",
    "id" : 266021841380986880,
    "created_at" : "2012-11-07 03:38:44 +0000",
    "user" : {
      "name" : "Anil Dash",
      "screen_name" : "anildash",
      "protected" : false,
      "id_str" : "36823",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3588056222/0d62af265381d6b5861371e86d0bff23_normal.jpeg",
      "id" : 36823,
      "verified" : true
    }
  },
  "id" : 266024396240613376,
  "created_at" : "2012-11-07 03:48:53 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "razortight",
      "indices" : [ 0, 11 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "266019334965583873",
  "text" : "#razortight, right.",
  "id" : 266019334965583873,
  "created_at" : "2012-11-07 03:28:46 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "266018652686516225",
  "text" : "Wisconsin for Obama! With New Hampshire, that pretty much seals the deal.",
  "id" : 266018652686516225,
  "created_at" : "2012-11-07 03:26:03 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twitter Government",
      "screen_name" : "gov",
      "indices" : [ 3, 7 ],
      "id_str" : "222953824",
      "id" : 222953824
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "election2012",
      "indices" : [ 112, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "266016802956529666",
  "text" : "RT @gov: With 20 million tweets, Election Day just became the most tweeted about event in US political history. #election2012",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "election2012",
        "indices" : [ 103, 116 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "266016146204000256",
    "text" : "With 20 million tweets, Election Day just became the most tweeted about event in US political history. #election2012",
    "id" : 266016146204000256,
    "created_at" : "2012-11-07 03:16:06 +0000",
    "user" : {
      "name" : "Twitter Government",
      "screen_name" : "gov",
      "protected" : false,
      "id_str" : "222953824",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2284291316/xu1u3i11ugj03en53ujr_normal.png",
      "id" : 222953824,
      "verified" : true
    }
  },
  "id" : 266016802956529666,
  "created_at" : "2012-11-07 03:18:42 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "266013008390656000",
  "text" : "Elizabeth Warren! Yes!",
  "id" : 266013008390656000,
  "created_at" : "2012-11-07 03:03:38 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "266010616152588289",
  "text" : "Is Ohio counting votes slowly on purpose? They just don't want to give up all the attention for another 3.5 years?",
  "id" : 266010616152588289,
  "created_at" : "2012-11-07 02:54:07 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nate Silver",
      "screen_name" : "fivethirtyeight",
      "indices" : [ 3, 19 ],
      "id_str" : "16017475",
      "id" : 16017475
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "266006073062858752",
  "text" : "RT @fivethirtyeight: On The Wall, The Writing.",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "266004354929160192",
    "text" : "On The Wall, The Writing.",
    "id" : 266004354929160192,
    "created_at" : "2012-11-07 02:29:14 +0000",
    "user" : {
      "name" : "Nate Silver",
      "screen_name" : "fivethirtyeight",
      "protected" : false,
      "id_str" : "16017475",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000188475595/9048bff5190578d8e2c558dca3606fbb_normal.png",
      "id" : 16017475,
      "verified" : true
    }
  },
  "id" : 266006073062858752,
  "created_at" : "2012-11-07 02:36:04 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Sarver",
      "screen_name" : "rsarver",
      "indices" : [ 0, 8 ],
      "id_str" : "795649",
      "id" : 795649
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "arithmetic",
      "indices" : [ 109, 120 ]
    }, {
      "text" : "factsmatter",
      "indices" : [ 121, 133 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "265996434598412289",
  "geo" : { },
  "id_str" : "266000418851676163",
  "in_reply_to_user_id" : 795649,
  "text" : "@rsarver We've rediscovered the usefulness of math + facts to counter punditry, with help from Bill Clinton. #arithmetic #factsmatter",
  "id" : 266000418851676163,
  "in_reply_to_status_id" : 265996434598412289,
  "created_at" : "2012-11-07 02:13:36 +0000",
  "in_reply_to_screen_name" : "rsarver",
  "in_reply_to_user_id_str" : "795649",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "265976527672455168",
  "text" : "Numbers!",
  "id" : 265976527672455168,
  "created_at" : "2012-11-07 00:38:40 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.branch.com\" rel=\"nofollow\">Branch Inc</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Maser",
      "screen_name" : "mmaser",
      "indices" : [ 0, 7 ],
      "id_str" : "14109423",
      "id" : 14109423
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 57 ],
      "url" : "http://t.co/IbBXdcl1",
      "expanded_url" : "http://branch.com/b/election-2012-live-blog-amongst-friends?showsignin=true&inviter=Buster%20Benson",
      "display_url" : "branch.com/b/election-201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "265957480956317697",
  "in_reply_to_user_id" : 14109423,
  "text" : "@mmaser I just added you to a branch http://t.co/IbBXdcl1",
  "id" : 265957480956317697,
  "created_at" : "2012-11-06 23:22:59 +0000",
  "in_reply_to_screen_name" : "mmaser",
  "in_reply_to_user_id_str" : "14109423",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Hopkins",
      "screen_name" : "stevehopkins",
      "indices" : [ 0, 13 ],
      "id_str" : "8074932",
      "id" : 8074932
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "265952228928532481",
  "geo" : { },
  "id_str" : "265954895763488768",
  "in_reply_to_user_id" : 8074932,
  "text" : "@stevehopkins Thanks, Steve!",
  "id" : 265954895763488768,
  "in_reply_to_status_id" : 265952228928532481,
  "created_at" : "2012-11-06 23:12:43 +0000",
  "in_reply_to_screen_name" : "stevehopkins",
  "in_reply_to_user_id_str" : "8074932",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Daily Show",
      "screen_name" : "TheDailyShow",
      "indices" : [ 26, 39 ],
      "id_str" : "158414847",
      "id" : 158414847
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http://t.co/0RkmBP2D",
      "expanded_url" : "http://live.comedycentral.com/",
      "display_url" : "live.comedycentral.com"
    } ]
  },
  "geo" : { },
  "id_str" : "265923711348117504",
  "text" : "What I'll be watching. RT @TheDailyShow: Tune in for our LIVE election night coverage! Stream it on the World Wide Web! http://t.co/0RkmBP2D",
  "id" : 265923711348117504,
  "created_at" : "2012-11-06 21:08:48 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 3, 13 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "265922076609744897",
  "text" : "RT @kellianne: My dentist asked how I was feeling before she took 2 wisdom teeth out of my face.  I said, \"Pink Floyd parking lot, 1994\".",
  "retweeted_status" : {
    "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "265921859990745088",
    "text" : "My dentist asked how I was feeling before she took 2 wisdom teeth out of my face.  I said, \"Pink Floyd parking lot, 1994\".",
    "id" : 265921859990745088,
    "created_at" : "2012-11-06 21:01:26 +0000",
    "user" : {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "protected" : false,
      "id_str" : "7362142",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3058433557/056b99ecb9df9b6b9b382b2470b6ee82_normal.jpeg",
      "id" : 7362142,
      "verified" : false
    }
  },
  "id" : 265922076609744897,
  "created_at" : "2012-11-06 21:02:18 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katherine Smith",
      "screen_name" : "katherinesmith",
      "indices" : [ 0, 15 ],
      "id_str" : "8497382",
      "id" : 8497382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "265896434455412738",
  "geo" : { },
  "id_str" : "265898758380855297",
  "in_reply_to_user_id" : 8497382,
  "text" : "@katherinesmith I'm open to changing my mind. The data and stories I've seen so far lead me to this current opinion.",
  "id" : 265898758380855297,
  "in_reply_to_status_id" : 265896434455412738,
  "created_at" : "2012-11-06 19:29:38 +0000",
  "in_reply_to_screen_name" : "katherinesmith",
  "in_reply_to_user_id_str" : "8497382",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katherine Smith",
      "screen_name" : "katherinesmith",
      "indices" : [ 0, 15 ],
      "id_str" : "8497382",
      "id" : 8497382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "265894864099622913",
  "geo" : { },
  "id_str" : "265895186918428672",
  "in_reply_to_user_id" : 8497382,
  "text" : "@katherinesmith Then I encourage you to vote against it.",
  "id" : 265895186918428672,
  "in_reply_to_status_id" : 265894864099622913,
  "created_at" : "2012-11-06 19:15:27 +0000",
  "in_reply_to_screen_name" : "katherinesmith",
  "in_reply_to_user_id_str" : "8497382",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katherine Smith",
      "screen_name" : "katherinesmith",
      "indices" : [ 0, 15 ],
      "id_str" : "8497382",
      "id" : 8497382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "265893369358716928",
  "geo" : { },
  "id_str" : "265893709781037056",
  "in_reply_to_user_id" : 8497382,
  "text" : "@katherinesmith There are no final answers\u2026 just attempts to improve a system that isn't doing great right now. I'm open to alternatives.",
  "id" : 265893709781037056,
  "in_reply_to_status_id" : 265893369358716928,
  "created_at" : "2012-11-06 19:09:35 +0000",
  "in_reply_to_screen_name" : "katherinesmith",
  "in_reply_to_user_id_str" : "8497382",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katherine Smith",
      "screen_name" : "katherinesmith",
      "indices" : [ 0, 15 ],
      "id_str" : "8497382",
      "id" : 8497382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "265892376290140161",
  "geo" : { },
  "id_str" : "265893022590455808",
  "in_reply_to_user_id" : 8497382,
  "text" : "@katherinesmith I personally think it's a good idea. A lot of my smart teacher friends also voted for it. It'll probably lose though.",
  "id" : 265893022590455808,
  "in_reply_to_status_id" : 265892376290140161,
  "created_at" : "2012-11-06 19:06:51 +0000",
  "in_reply_to_screen_name" : "katherinesmith",
  "in_reply_to_user_id_str" : "8497382",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katherine Smith",
      "screen_name" : "katherinesmith",
      "indices" : [ 0, 15 ],
      "id_str" : "8497382",
      "id" : 8497382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "265891582614581248",
  "geo" : { },
  "id_str" : "265891721357979648",
  "in_reply_to_user_id" : 8497382,
  "text" : "@katherinesmith And there's a lot of failing going on right now.",
  "id" : 265891721357979648,
  "in_reply_to_status_id" : 265891582614581248,
  "created_at" : "2012-11-06 19:01:41 +0000",
  "in_reply_to_screen_name" : "katherinesmith",
  "in_reply_to_user_id_str" : "8497382",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katherine Smith",
      "screen_name" : "katherinesmith",
      "indices" : [ 0, 15 ],
      "id_str" : "8497382",
      "id" : 8497382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "265891206477787137",
  "geo" : { },
  "id_str" : "265891332202041344",
  "in_reply_to_user_id" : 8497382,
  "text" : "@katherinesmith I'd vote for that too. It wasn't on the ballot.",
  "id" : 265891332202041344,
  "in_reply_to_status_id" : 265891206477787137,
  "created_at" : "2012-11-06 19:00:08 +0000",
  "in_reply_to_screen_name" : "katherinesmith",
  "in_reply_to_user_id_str" : "8497382",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katherine Smith",
      "screen_name" : "katherinesmith",
      "indices" : [ 0, 15 ],
      "id_str" : "8497382",
      "id" : 8497382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "265890605157212160",
  "geo" : { },
  "id_str" : "265891064320258051",
  "in_reply_to_user_id" : 8497382,
  "text" : "@katherinesmith Freedom to try new things, iterate faster, etc.",
  "id" : 265891064320258051,
  "in_reply_to_status_id" : 265890605157212160,
  "created_at" : "2012-11-06 18:59:04 +0000",
  "in_reply_to_screen_name" : "katherinesmith",
  "in_reply_to_user_id_str" : "8497382",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "election2012",
      "indices" : [ 79, 92 ]
    } ],
    "urls" : [ {
      "indices" : [ 58, 78 ],
      "url" : "http://t.co/PBVaNq6J",
      "expanded_url" : "http://bit.ly/UgVMnh",
      "display_url" : "bit.ly/UgVMnh"
    } ]
  },
  "geo" : { },
  "id_str" : "265889655633895424",
  "text" : "Facebook has a real-time voting map with some cool stats: http://t.co/PBVaNq6J #election2012",
  "id" : 265889655633895424,
  "created_at" : "2012-11-06 18:53:28 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katherine Smith",
      "screen_name" : "katherinesmith",
      "indices" : [ 0, 15 ],
      "id_str" : "8497382",
      "id" : 8497382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "265884183073808384",
  "geo" : { },
  "id_str" : "265885719757729792",
  "in_reply_to_user_id" : 8497382,
  "text" : "@katherinesmith I voted for them because I want public schools to innovate faster. Standardized tests don't measure everything.",
  "id" : 265885719757729792,
  "in_reply_to_status_id" : 265884183073808384,
  "created_at" : "2012-11-06 18:37:50 +0000",
  "in_reply_to_screen_name" : "katherinesmith",
  "in_reply_to_user_id_str" : "8497382",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://bufferapp.com\" rel=\"nofollow\">Buffer</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "election2012",
      "indices" : [ 95, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "265882406060425216",
  "text" : "I voted for Obama, gays, pot, and charter schools. Lots of forward progress on the line today. #election2012",
  "id" : 265882406060425216,
  "created_at" : "2012-11-06 18:24:40 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Savage",
      "screen_name" : "fakedansavage",
      "indices" : [ 3, 17 ],
      "id_str" : "313091751",
      "id" : 313091751
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/fakedansavage/status/265864513985851392/photo/1",
      "indices" : [ 37, 57 ],
      "url" : "http://t.co/vdG5j4pb",
      "media_url" : "http://pbs.twimg.com/media/A7CKXerCMAArmiw.jpg",
      "id_str" : "265864513990045696",
      "id" : 265864513990045696,
      "media_url_https" : "https://pbs.twimg.com/media/A7CKXerCMAArmiw.jpg",
      "sizes" : [ {
        "h" : 379,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 647,
        "resize" : "fit",
        "w" : 580
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 647,
        "resize" : "fit",
        "w" : 580
      }, {
        "h" : 647,
        "resize" : "fit",
        "w" : 580
      } ],
      "display_url" : "pic.twitter.com/vdG5j4pb"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "265866399119966208",
  "text" : "RT @fakedansavage: In Nate We Trust. http://t.co/vdG5j4pb",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http://twitter.com/fakedansavage/status/265864513985851392/photo/1",
        "indices" : [ 18, 38 ],
        "url" : "http://t.co/vdG5j4pb",
        "media_url" : "http://pbs.twimg.com/media/A7CKXerCMAArmiw.jpg",
        "id_str" : "265864513990045696",
        "id" : 265864513990045696,
        "media_url_https" : "https://pbs.twimg.com/media/A7CKXerCMAArmiw.jpg",
        "sizes" : [ {
          "h" : 379,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 647,
          "resize" : "fit",
          "w" : 580
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 647,
          "resize" : "fit",
          "w" : 580
        }, {
          "h" : 647,
          "resize" : "fit",
          "w" : 580
        } ],
        "display_url" : "pic.twitter.com/vdG5j4pb"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "265864513985851392",
    "text" : "In Nate We Trust. http://t.co/vdG5j4pb",
    "id" : 265864513985851392,
    "created_at" : "2012-11-06 17:13:34 +0000",
    "user" : {
      "name" : "Dan Savage",
      "screen_name" : "fakedansavage",
      "protected" : false,
      "id_str" : "313091751",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000182121153/eaf8eff2a020c0190411dcd3faf3be65_normal.jpeg",
      "id" : 313091751,
      "verified" : true
    }
  },
  "id" : 265866399119966208,
  "created_at" : "2012-11-06 17:21:03 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://bufferapp.com\" rel=\"nofollow\">Buffer</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "265847630746226690",
  "text" : "There are gonna be a lotta tweets today.",
  "id" : 265847630746226690,
  "created_at" : "2012-11-06 16:06:29 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Election",
      "indices" : [ 6, 15 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6085689664, -122.3059546576 ]
  },
  "id_str" : "265807946515091456",
  "text" : "Happy #Election Day, tweeter heads!",
  "id" : 265807946515091456,
  "created_at" : "2012-11-06 13:28:47 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Werner Vogels",
      "screen_name" : "Werner",
      "indices" : [ 3, 10 ],
      "id_str" : "113963",
      "id" : 113963
    }, {
      "name" : "Katie Jacobs Stanton",
      "screen_name" : "KatieS",
      "indices" : [ 52, 59 ],
      "id_str" : "94143715",
      "id" : 94143715
    }, {
      "name" : "Ralph Gilles",
      "screen_name" : "RalphGilles",
      "indices" : [ 90, 102 ],
      "id_str" : "551458376",
      "id" : 551458376
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/KatieS/status/264147515606192129/photo/1",
      "indices" : [ 103, 123 ],
      "url" : "http://t.co/Cf5wbN1L",
      "media_url" : "http://pbs.twimg.com/media/A6pwxBRCUAAiWDl.png",
      "id_str" : "264147515610386432",
      "id" : 264147515610386432,
      "media_url_https" : "https://pbs.twimg.com/media/A6pwxBRCUAAiWDl.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 244,
        "resize" : "fit",
        "w" : 467
      }, {
        "h" : 178,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 244,
        "resize" : "fit",
        "w" : 467
      }, {
        "h" : 244,
        "resize" : "fit",
        "w" : 467
      } ],
      "display_url" : "pic.twitter.com/Cf5wbN1L"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "265718169098928129",
  "text" : "RT @Werner: When a Chrysler VP responds to Trump RT @KatieS Best. Twitter. Moment. Bravo, @RalphGilles http://t.co/Cf5wbN1L",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Katie Jacobs Stanton",
        "screen_name" : "KatieS",
        "indices" : [ 40, 47 ],
        "id_str" : "94143715",
        "id" : 94143715
      }, {
        "name" : "Ralph Gilles",
        "screen_name" : "RalphGilles",
        "indices" : [ 78, 90 ],
        "id_str" : "551458376",
        "id" : 551458376
      } ],
      "media" : [ {
        "expanded_url" : "http://twitter.com/KatieS/status/264147515606192129/photo/1",
        "indices" : [ 91, 111 ],
        "url" : "http://t.co/Cf5wbN1L",
        "media_url" : "http://pbs.twimg.com/media/A6pwxBRCUAAiWDl.png",
        "id_str" : "264147515610386432",
        "id" : 264147515610386432,
        "media_url_https" : "https://pbs.twimg.com/media/A6pwxBRCUAAiWDl.png",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 244,
          "resize" : "fit",
          "w" : 467
        }, {
          "h" : 178,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 244,
          "resize" : "fit",
          "w" : 467
        }, {
          "h" : 244,
          "resize" : "fit",
          "w" : 467
        } ],
        "display_url" : "pic.twitter.com/Cf5wbN1L"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "264176063041642497",
    "text" : "When a Chrysler VP responds to Trump RT @KatieS Best. Twitter. Moment. Bravo, @RalphGilles http://t.co/Cf5wbN1L",
    "id" : 264176063041642497,
    "created_at" : "2012-11-02 01:24:16 +0000",
    "user" : {
      "name" : "Werner Vogels",
      "screen_name" : "Werner",
      "protected" : false,
      "id_str" : "113963",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000411275310/5f3e0f4eff901089a2a136459e27f217_normal.jpeg",
      "id" : 113963,
      "verified" : false
    }
  },
  "id" : 265718169098928129,
  "created_at" : "2012-11-06 07:32:02 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ali Berman",
      "screen_name" : "spangley",
      "indices" : [ 0, 9 ],
      "id_str" : "776429",
      "id" : 776429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "265679083126542336",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6247392402, -122.3546203119 ]
  },
  "id_str" : "265690019384147968",
  "in_reply_to_user_id" : 776429,
  "text" : "@spangley I am glad don't stop believing is the overplayed one out of those choices. Imagine hearing any other song sung 1,000,000x.",
  "id" : 265690019384147968,
  "in_reply_to_status_id" : 265679083126542336,
  "created_at" : "2012-11-06 05:40:11 +0000",
  "in_reply_to_screen_name" : "spangley",
  "in_reply_to_user_id_str" : "776429",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ali Berman",
      "screen_name" : "spangley",
      "indices" : [ 0, 9 ],
      "id_str" : "776429",
      "id" : 776429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "265672770204094464",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6119529922, -122.3065016606 ]
  },
  "id_str" : "265677170213548033",
  "in_reply_to_user_id" : 776429,
  "text" : "@spangley I can cosign but curious what the better Journey songs are.",
  "id" : 265677170213548033,
  "in_reply_to_status_id" : 265672770204094464,
  "created_at" : "2012-11-06 04:49:08 +0000",
  "in_reply_to_screen_name" : "spangley",
  "in_reply_to_user_id_str" : "776429",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nate Silver 2.0",
      "screen_name" : "fivethirtynate",
      "indices" : [ 3, 18 ],
      "id_str" : "922238588",
      "id" : 922238588
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "265676701642665985",
  "text" : "RT @fivethirtynate: The Forecast and the Nowcast meet. I glimpse boundless realms in their penumbra. Meta-Romney holds a strong lead in  ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/#!/download/ipad\" rel=\"nofollow\">Twitter for iPad</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "265672351696441345",
    "text" : "The Forecast and the Nowcast meet. I glimpse boundless realms in their penumbra. Meta-Romney holds a strong lead in the infrared states.",
    "id" : 265672351696441345,
    "created_at" : "2012-11-06 04:29:59 +0000",
    "user" : {
      "name" : "Nate Silver 2.0",
      "screen_name" : "fivethirtynate",
      "protected" : false,
      "id_str" : "922238588",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2799403489/3e831177b2360f3b21c4c2912b89dffa_normal.jpeg",
      "id" : 922238588,
      "verified" : false
    }
  },
  "id" : 265676701642665985,
  "created_at" : "2012-11-06 04:47:16 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 67 ],
      "url" : "http://t.co/C7nsRugr",
      "expanded_url" : "http://instagr.am/p/RrMaoQI0Mr/",
      "display_url" : "instagr.am/p/RrMaoQI0Mr/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.61506695, -122.32813046 ]
  },
  "id_str" : "265674189200031744",
  "text" : "8:36pm \"Say muppets!\" @ Ristorante Machiavelli http://t.co/C7nsRugr",
  "id" : 265674189200031744,
  "created_at" : "2012-11-06 04:37:17 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://bufferapp.com\" rel=\"nofollow\">Buffer</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 68 ],
      "url" : "http://t.co/eyOjw4U8",
      "expanded_url" : "http://bit.ly/QiGcGu",
      "display_url" : "bit.ly/QiGcGu"
    } ]
  },
  "geo" : { },
  "id_str" : "265618317266538497",
  "text" : "Siri gets her ass kicked by Google Voice Search http://t.co/eyOjw4U8",
  "id" : 265618317266538497,
  "created_at" : "2012-11-06 00:55:16 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6101255241, -122.3400817789 ]
  },
  "id_str" : "265616240985378816",
  "text" : "I think I'm color dyslexic. I can never remember if I'm red or blue. Blue, right? What's the mental trick I missed out on?",
  "id" : 265616240985378816,
  "created_at" : "2012-11-06 00:47:01 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian Chan",
      "screen_name" : "chanian",
      "indices" : [ 3, 11 ],
      "id_str" : "22891211",
      "id" : 22891211
    }, {
      "name" : "jacob",
      "screen_name" : "fat",
      "indices" : [ 65, 69 ],
      "id_str" : "16521996",
      "id" : 16521996
    }, {
      "name" : "Dave Gamache",
      "screen_name" : "dhg",
      "indices" : [ 71, 75 ],
      "id_str" : "17346623",
      "id" : 17346623
    }, {
      "name" : "Connor Sears",
      "screen_name" : "connors",
      "indices" : [ 76, 84 ],
      "id_str" : "1523501",
      "id" : 1523501
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "265607681052651520",
  "text" : "RT @chanian: Having little iOS dev experience, Ratchet (new from @fat, @dhg @connors) looks like a fantastic mobile prototyping tool htt ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "jacob",
        "screen_name" : "fat",
        "indices" : [ 52, 56 ],
        "id_str" : "16521996",
        "id" : 16521996
      }, {
        "name" : "Dave Gamache",
        "screen_name" : "dhg",
        "indices" : [ 58, 62 ],
        "id_str" : "17346623",
        "id" : 17346623
      }, {
        "name" : "Connor Sears",
        "screen_name" : "connors",
        "indices" : [ 63, 71 ],
        "id_str" : "1523501",
        "id" : 1523501
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 120, 140 ],
        "url" : "http://t.co/ZiwSezV2",
        "expanded_url" : "http://maker.github.com/ratchet/",
        "display_url" : "maker.github.com/ratchet/"
      } ]
    },
    "geo" : { },
    "id_str" : "265600188662571008",
    "text" : "Having little iOS dev experience, Ratchet (new from @fat, @dhg @connors) looks like a fantastic mobile prototyping tool http://t.co/ZiwSezV2",
    "id" : 265600188662571008,
    "created_at" : "2012-11-05 23:43:14 +0000",
    "user" : {
      "name" : "Ian Chan",
      "screen_name" : "chanian",
      "protected" : false,
      "id_str" : "22891211",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2467844172/image_normal.jpg",
      "id" : 22891211,
      "verified" : false
    }
  },
  "id" : 265607681052651520,
  "created_at" : "2012-11-06 00:13:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christine Corbett",
      "screen_name" : "corbett_inc",
      "indices" : [ 0, 12 ],
      "id_str" : "6066682",
      "id" : 6066682
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "265592199763337216",
  "geo" : { },
  "id_str" : "265592433256050688",
  "in_reply_to_user_id" : 143264018,
  "text" : "@corbett_inc Where are your thoughts? Where is your mind?",
  "id" : 265592433256050688,
  "in_reply_to_status_id" : 265592199763337216,
  "created_at" : "2012-11-05 23:12:25 +0000",
  "in_reply_to_screen_name" : "corbett",
  "in_reply_to_user_id_str" : "143264018",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "265581378198990849",
  "text" : "Thinking of putting an auto-responder on my email that just says to find me on Twitter. Would that be crazy? I have unread email from Aug.",
  "id" : 265581378198990849,
  "created_at" : "2012-11-05 22:28:29 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Miller",
      "screen_name" : "joshm",
      "indices" : [ 0, 6 ],
      "id_str" : "42559115",
      "id" : 42559115
    }, {
      "name" : "Branch",
      "screen_name" : "branch",
      "indices" : [ 7, 14 ],
      "id_str" : "494518813",
      "id" : 494518813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http://t.co/0d4vLk65",
      "expanded_url" : "http://bit.ly/XeBATI",
      "display_url" : "bit.ly/XeBATI"
    } ]
  },
  "geo" : { },
  "id_str" : "265567854227750913",
  "in_reply_to_user_id" : 42559115,
  "text" : "@joshm @branch I'm trying to invite people to my branch, but they say that the invites aren't working. Known bug? RE: http://t.co/0d4vLk65",
  "id" : 265567854227750913,
  "created_at" : "2012-11-05 21:34:45 +0000",
  "in_reply_to_screen_name" : "joshm",
  "in_reply_to_user_id_str" : "42559115",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.branch.com\" rel=\"nofollow\">Branch Inc</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Maser",
      "screen_name" : "mmaser",
      "indices" : [ 0, 7 ],
      "id_str" : "14109423",
      "id" : 14109423
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 57 ],
      "url" : "http://t.co/IbBXdcl1",
      "expanded_url" : "http://branch.com/b/election-2012-live-blog-amongst-friends?showsignin=true&inviter=Buster%20Benson",
      "display_url" : "branch.com/b/election-201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "265538889199013888",
  "in_reply_to_user_id" : 14109423,
  "text" : "@mmaser I just added you to a branch http://t.co/IbBXdcl1",
  "id" : 265538889199013888,
  "created_at" : "2012-11-05 19:39:39 +0000",
  "in_reply_to_screen_name" : "mmaser",
  "in_reply_to_user_id_str" : "14109423",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.branch.com\" rel=\"nofollow\">Branch Inc</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Vance",
      "screen_name" : "ryanvance",
      "indices" : [ 0, 10 ],
      "id_str" : "16461070",
      "id" : 16461070
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 60 ],
      "url" : "http://t.co/IbBXdcl1",
      "expanded_url" : "http://branch.com/b/election-2012-live-blog-amongst-friends?showsignin=true&inviter=Buster%20Benson",
      "display_url" : "branch.com/b/election-201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "265538790184079360",
  "in_reply_to_user_id" : 16461070,
  "text" : "@ryanvance I just added you to a branch http://t.co/IbBXdcl1",
  "id" : 265538790184079360,
  "created_at" : "2012-11-05 19:39:15 +0000",
  "in_reply_to_screen_name" : "ryanvance",
  "in_reply_to_user_id_str" : "16461070",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brennan Novak",
      "screen_name" : "brennannovak",
      "indices" : [ 0, 13 ],
      "id_str" : "17958179",
      "id" : 17958179
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "265504113444405248",
  "geo" : { },
  "id_str" : "265506338472345600",
  "in_reply_to_user_id" : 17958179,
  "text" : "@brennannovak I want to set up my house with video cameras and microphones now.",
  "id" : 265506338472345600,
  "in_reply_to_status_id" : 265504113444405248,
  "created_at" : "2012-11-05 17:30:18 +0000",
  "in_reply_to_screen_name" : "brennannovak",
  "in_reply_to_user_id_str" : "17958179",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joel Bez",
      "screen_name" : "lejoe",
      "indices" : [ 133, 139 ],
      "id_str" : "2129311",
      "id" : 2129311
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 127 ],
      "url" : "http://t.co/itE1iMNy",
      "expanded_url" : "http://bit.ly/SnSMjk",
      "display_url" : "bit.ly/SnSMjk"
    } ]
  },
  "geo" : { },
  "id_str" : "265502891316498433",
  "text" : "This TED talk about how babies learn words and how to record everything about your life, is crazy amazing: http://t.co/itE1iMNy /via @lejoe",
  "id" : 265502891316498433,
  "created_at" : "2012-11-05 17:16:36 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://bufferapp.com\" rel=\"nofollow\">Buffer</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "quantifiedself",
      "indices" : [ 72, 87 ]
    } ],
    "urls" : [ {
      "indices" : [ 51, 71 ],
      "url" : "http://t.co/PM1E9MSi",
      "expanded_url" : "http://bit.ly/SLgSrV",
      "display_url" : "bit.ly/SLgSrV"
    } ]
  },
  "geo" : { },
  "id_str" : "265492892494221312",
  "text" : "From the weekend: \"What I'm tracking now, and why\" http://t.co/PM1E9MSi #quantifiedself",
  "id" : 265492892494221312,
  "created_at" : "2012-11-05 16:36:52 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Natalie Angier",
      "screen_name" : "angier58",
      "indices" : [ 3, 12 ],
      "id_str" : "17372928",
      "id" : 17372928
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "265478493637337088",
  "text" : "RT @angier58: Vote, people, please! no matter what color your state. This is an election where the popular vote will resonate for the ne ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "265472031838064641",
    "text" : "Vote, people, please! no matter what color your state. This is an election where the popular vote will resonate for the next four years.",
    "id" : 265472031838064641,
    "created_at" : "2012-11-05 15:13:59 +0000",
    "user" : {
      "name" : "Natalie Angier",
      "screen_name" : "angier58",
      "protected" : false,
      "id_str" : "17372928",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/102654695/Natalie_Angier_photo2_normal.jpg",
      "id" : 17372928,
      "verified" : false
    }
  },
  "id" : 265478493637337088,
  "created_at" : "2012-11-05 15:39:39 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6086850977, -122.3059341219 ]
  },
  "id_str" : "265476613062393856",
  "text" : "Me to Niko: \"Are you going to vote for Thomas or Percy?\" Niko: \"Percy!\"",
  "id" : 265476613062393856,
  "created_at" : "2012-11-05 15:32:11 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Sippey",
      "screen_name" : "sippey",
      "indices" : [ 0, 7 ],
      "id_str" : "4711",
      "id" : 4711
    }, {
      "name" : "Katie Jacobs Stanton",
      "screen_name" : "KatieS",
      "indices" : [ 8, 15 ],
      "id_str" : "94143715",
      "id" : 94143715
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cosign",
      "indices" : [ 16, 23 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "265318923736588289",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6086195093, -122.3061354553 ]
  },
  "id_str" : "265321309393780737",
  "in_reply_to_user_id" : 4711,
  "text" : "@sippey @katies #cosign",
  "id" : 265321309393780737,
  "in_reply_to_status_id" : 265318923736588289,
  "created_at" : "2012-11-05 05:15:04 +0000",
  "in_reply_to_screen_name" : "sippey",
  "in_reply_to_user_id_str" : "4711",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "harryh",
      "screen_name" : "harryh",
      "indices" : [ 10, 17 ],
      "id_str" : "4558",
      "id" : 4558
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 58 ],
      "url" : "http://t.co/jmAgbAKK",
      "expanded_url" : "http://www.datapointed.net/visualizations/math/factorization/animated-diagrams/",
      "display_url" : "datapointed.net/visualizations\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6086033168, -122.3061527674 ]
  },
  "id_str" : "265320107822157824",
  "text" : "Truly. RT @harryh: This is beautiful: http://t.co/jmAgbAKK",
  "id" : 265320107822157824,
  "created_at" : "2012-11-05 05:10:17 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 105 ],
      "url" : "http://t.co/h1OD0VVQ",
      "expanded_url" : "http://instagr.am/p/RoqVvuI0C9/",
      "display_url" : "instagr.am/p/RoqVvuI0C9/"
    } ]
  },
  "geo" : { },
  "id_str" : "265317935671824385",
  "text" : "8:36pm Reading Cat in the Hat triggers story time parts of my own childhood memories http://t.co/h1OD0VVQ",
  "id" : 265317935671824385,
  "created_at" : "2012-11-05 05:01:39 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tldr",
      "indices" : [ 0, 5 ]
    } ],
    "urls" : [ {
      "indices" : [ 26, 46 ],
      "url" : "http://t.co/kekePEKF",
      "expanded_url" : "http://www.nytimes.com/2012/11/04/magazine/in-praise-of-the-hashtag.html?pagewanted=2&_r=0&smid=tw-share",
      "display_url" : "nytimes.com/2012/11/04/mag\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6086245951, -122.3060534098 ]
  },
  "id_str" : "265308262428180481",
  "text" : "#tldr hashtags are cool.\n\nhttp://t.co/kekePEKF",
  "id" : 265308262428180481,
  "created_at" : "2012-11-05 04:23:13 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Neil Diamond",
      "screen_name" : "NeilDiamond",
      "indices" : [ 3, 15 ],
      "id_str" : "18753325",
      "id" : 18753325
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OFACulver",
      "indices" : [ 111, 121 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "265305082348834816",
  "text" : "RT @NeilDiamond: Working the phones for Obama...  If I call you, don't hang up. It's really me and I need you. #OFACulver http://t.co/e7 ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http://twitter.com/NeilDiamond/status/265300433738821632/photo/1",
        "indices" : [ 105, 125 ],
        "url" : "http://t.co/e7oquoid",
        "media_url" : "http://pbs.twimg.com/media/A66JVsACcAMhIG2.jpg",
        "id_str" : "265300433743015939",
        "id" : 265300433743015939,
        "media_url_https" : "https://pbs.twimg.com/media/A66JVsACcAMhIG2.jpg",
        "sizes" : [ {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com/e7oquoid"
      } ],
      "hashtags" : [ {
        "text" : "OFACulver",
        "indices" : [ 94, 104 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "265300433738821632",
    "text" : "Working the phones for Obama...  If I call you, don't hang up. It's really me and I need you. #OFACulver http://t.co/e7oquoid",
    "id" : 265300433738821632,
    "created_at" : "2012-11-05 03:52:07 +0000",
    "user" : {
      "name" : "Neil Diamond",
      "screen_name" : "NeilDiamond",
      "protected" : false,
      "id_str" : "18753325",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1652298799/image_normal.png",
      "id" : 18753325,
      "verified" : true
    }
  },
  "id" : 265305082348834816,
  "created_at" : "2012-11-05 04:10:35 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonah Peretti",
      "screen_name" : "peretti",
      "indices" : [ 10, 18 ],
      "id_str" : "879521",
      "id" : 879521
    }, {
      "name" : "Dennis Crowley",
      "screen_name" : "dens",
      "indices" : [ 46, 51 ],
      "id_str" : "418",
      "id" : 418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 131 ],
      "url" : "http://t.co/kGozEGWD",
      "expanded_url" : "http://www.fastcompany.com/3002575/why-foursquares-dennis-crowley-obsessively-changes-location",
      "display_url" : "fastcompany.com/3002575/why-fo\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6087958226, -122.3061862496 ]
  },
  "id_str" : "265289082459009024",
  "text" : "Agree! RT @peretti: Very smart interview with @dens about how Foursquare adapts to change - he's the real deal http://t.co/kGozEGWD",
  "id" : 265289082459009024,
  "created_at" : "2012-11-05 03:07:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://bufferapp.com\" rel=\"nofollow\">Buffer</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 111 ],
      "url" : "http://t.co/VEf85npS",
      "expanded_url" : "http://bit.ly/SKjt2G",
      "display_url" : "bit.ly/SKjt2G"
    } ]
  },
  "geo" : { },
  "id_str" : "265255902779678720",
  "text" : "If you're in the mood to track your mood over time, Expereal is pretty awesome and pretty: http://t.co/VEf85npS",
  "id" : 265255902779678720,
  "created_at" : "2012-11-05 00:55:10 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian G. Fay",
      "screen_name" : "brianfay",
      "indices" : [ 0, 9 ],
      "id_str" : "15257124",
      "id" : 15257124
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "265249052881461248",
  "geo" : { },
  "id_str" : "265251777459404800",
  "in_reply_to_user_id" : 15257124,
  "text" : "@brianfay Thank you.",
  "id" : 265251777459404800,
  "in_reply_to_status_id" : 265249052881461248,
  "created_at" : "2012-11-05 00:38:46 +0000",
  "in_reply_to_screen_name" : "brianfay",
  "in_reply_to_user_id_str" : "15257124",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.rdio.com\" rel=\"nofollow\">Rdio</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rdio",
      "screen_name" : "Rdio",
      "indices" : [ 102, 107 ],
      "id_str" : "54205414",
      "id" : 54205414
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 96 ],
      "url" : "http://t.co/dVj4DHA9",
      "expanded_url" : "http://rd.io/x/QFvDK7Tqqg",
      "display_url" : "rd.io/x/QFvDK7Tqqg"
    } ]
  },
  "geo" : { },
  "id_str" : "265251477486977024",
  "text" : "Green Light Go by Modeselektor is my jam with Niko on this overcast Sunday: http://t.co/dVj4DHA9 /via @Rdio",
  "id" : 265251477486977024,
  "created_at" : "2012-11-05 00:37:35 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nir Eyal",
      "screen_name" : "nireyal",
      "indices" : [ 0, 8 ],
      "id_str" : "14097392",
      "id" : 14097392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "265246381416013825",
  "geo" : { },
  "id_str" : "265249364618907648",
  "in_reply_to_user_id" : 14097392,
  "text" : "@nireyal Absolutely. busterbenson@gmail.com or join our branch!",
  "id" : 265249364618907648,
  "in_reply_to_status_id" : 265246381416013825,
  "created_at" : "2012-11-05 00:29:11 +0000",
  "in_reply_to_screen_name" : "nireyal",
  "in_reply_to_user_id_str" : "14097392",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe A Hand",
      "screen_name" : "joeahand",
      "indices" : [ 3, 12 ],
      "id_str" : "191122681",
      "id" : 191122681
    }, {
      "name" : "Anti-Buster",
      "screen_name" : "busterbenson",
      "indices" : [ 14, 27 ],
      "id_str" : "1024917050",
      "id" : 1024917050
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "265245761946652672",
  "text" : "RT @joeahand: @busterbenson it's addicting! Each day I get closer to that 500 day mark. Just about 70 days left. It's exciting.",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/#!/download/ipad\" rel=\"nofollow\">Twitter for iPad</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Anti-Buster",
        "screen_name" : "busterbenson",
        "indices" : [ 0, 13 ],
        "id_str" : "1024917050",
        "id" : 1024917050
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "265234455529144321",
    "geo" : { },
    "id_str" : "265245644019617792",
    "in_reply_to_user_id" : 2185,
    "text" : "@busterbenson it's addicting! Each day I get closer to that 500 day mark. Just about 70 days left. It's exciting.",
    "id" : 265245644019617792,
    "in_reply_to_status_id" : 265234455529144321,
    "created_at" : "2012-11-05 00:14:24 +0000",
    "in_reply_to_screen_name" : "buster",
    "in_reply_to_user_id_str" : "2185",
    "user" : {
      "name" : "Joe A Hand",
      "screen_name" : "joeahand",
      "protected" : false,
      "id_str" : "191122681",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1766627700/image1326991976_normal.png",
      "id" : 191122681,
      "verified" : false
    }
  },
  "id" : 265245761946652672,
  "created_at" : "2012-11-05 00:14:52 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 29 ],
      "url" : "http://t.co/UXCU3B0z",
      "expanded_url" : "http://750words.com",
      "display_url" : "750words.com"
    } ]
  },
  "geo" : { },
  "id_str" : "265234455529144321",
  "text" : "Usage of http://t.co/UXCU3B0z continues to surprise me. 2300 people are writing 750+ words every day, and 86 people have 500+ day streaks.",
  "id" : 265234455529144321,
  "created_at" : "2012-11-04 23:29:56 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Branch",
      "screen_name" : "branch",
      "indices" : [ 16, 23 ],
      "id_str" : "494518813",
      "id" : 494518813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 95 ],
      "url" : "http://t.co/ShbpIFTn",
      "expanded_url" : "http://on.branch.com/YqKCfe",
      "display_url" : "on.branch.com/YqKCfe"
    } ]
  },
  "geo" : { },
  "id_str" : "265232175601971200",
  "text" : "New question on @branch: \"What are you tracking about your life, and why?\" http://t.co/ShbpIFTn",
  "id" : 265232175601971200,
  "created_at" : "2012-11-04 23:20:53 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Raffi Krikorian",
      "screen_name" : "raffi",
      "indices" : [ 0, 6 ],
      "id_str" : "8285392",
      "id" : 8285392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "265228359632556032",
  "geo" : { },
  "id_str" : "265229544867373056",
  "in_reply_to_user_id" : 8285392,
  "text" : "@raffi The quote about the task of defining what to build being difficult to slice up also rang true.",
  "id" : 265229544867373056,
  "in_reply_to_status_id" : 265228359632556032,
  "created_at" : "2012-11-04 23:10:25 +0000",
  "in_reply_to_screen_name" : "raffi",
  "in_reply_to_user_id_str" : "8285392",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://bufferapp.com\" rel=\"nofollow\">Buffer</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 120 ],
      "url" : "http://t.co/nTHMMKyU",
      "expanded_url" : "http://bit.ly/SK3uSq",
      "display_url" : "bit.ly/SK3uSq"
    } ]
  },
  "geo" : { },
  "id_str" : "265225293491494912",
  "text" : "Every time I return to Medium, it's gotten a lot better. \"What Ev Learned Building Medium (So Far)\" http://t.co/nTHMMKyU",
  "id" : 265225293491494912,
  "created_at" : "2012-11-04 22:53:32 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 54 ],
      "url" : "http://t.co/WQbYzUOc",
      "expanded_url" : "http://instagr.am/p/Rn_Dl3o0Jd/",
      "display_url" : "instagr.am/p/Rn_Dl3o0Jd/"
    } ]
  },
  "geo" : { },
  "id_str" : "265222597661306881",
  "text" : "Niko's daycare class on Halloween http://t.co/WQbYzUOc",
  "id" : 265222597661306881,
  "created_at" : "2012-11-04 22:42:49 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Cottrell",
      "screen_name" : "rgcottrell",
      "indices" : [ 0, 11 ],
      "id_str" : "752553",
      "id" : 752553
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "265203137177059328",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6151301107, -122.3545444665 ]
  },
  "id_str" : "265205792574160897",
  "in_reply_to_user_id" : 752553,
  "text" : "@rgcottrell Two choos, even.",
  "id" : 265205792574160897,
  "in_reply_to_status_id" : 265203137177059328,
  "created_at" : "2012-11-04 21:36:02 +0000",
  "in_reply_to_screen_name" : "rgcottrell",
  "in_reply_to_user_id_str" : "752553",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 111 ],
      "url" : "http://t.co/hc0fOluS",
      "expanded_url" : "http://4sq.com/TsqJQR",
      "display_url" : "4sq.com/TsqJQR"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.615071, -122.354059 ]
  },
  "id_str" : "265197879784792064",
  "text" : "Choo-spotting. And they now all seem to know Niko's name. (@ Old Spaghetti Factory) [pic]: http://t.co/hc0fOluS",
  "id" : 265197879784792064,
  "created_at" : "2012-11-04 21:04:36 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard's Old A/c",
      "screen_name" : "ricmacnz",
      "indices" : [ 0, 9 ],
      "id_str" : "588669460",
      "id" : 588669460
    }, {
      "name" : "Fitbit",
      "screen_name" : "fitbit",
      "indices" : [ 75, 82 ],
      "id_str" : "17424053",
      "id" : 17424053
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 123 ],
      "url" : "http://t.co/hjdl40NN",
      "expanded_url" : "http://wayoftheduck.com/fitbit-zip",
      "display_url" : "wayoftheduck.com/fitbit-zip"
    } ]
  },
  "in_reply_to_status_id_str" : "265192796019892224",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6152177521, -122.3546127779 ]
  },
  "id_str" : "265197024218071041",
  "in_reply_to_user_id" : 105895323,
  "text" : "@ricmacnz Mostly just Numbers and Wizard (both Mac apps). I do use the new @fitbit Zip too, like this: http://t.co/hjdl40NN",
  "id" : 265197024218071041,
  "in_reply_to_status_id" : 265192796019892224,
  "created_at" : "2012-11-04 21:01:12 +0000",
  "in_reply_to_screen_name" : "ricmac",
  "in_reply_to_user_id_str" : "105895323",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Roberts",
      "screen_name" : "jeffjohnroberts",
      "indices" : [ 3, 19 ],
      "id_str" : "17925409",
      "id" : 17925409
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 115 ],
      "url" : "http://t.co/DwSwunrH",
      "expanded_url" : "http://bit.ly/SqCXbT",
      "display_url" : "bit.ly/SqCXbT"
    } ]
  },
  "geo" : { },
  "id_str" : "265185276475891713",
  "text" : "RT @jeffjohnroberts: Twitter is now flagging tweets that are zapped by DMCA copyright notices: http://t.co/DwSwunrH",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 74, 94 ],
        "url" : "http://t.co/DwSwunrH",
        "expanded_url" : "http://bit.ly/SqCXbT",
        "display_url" : "bit.ly/SqCXbT"
      } ]
    },
    "geo" : { },
    "id_str" : "265156446877011968",
    "text" : "Twitter is now flagging tweets that are zapped by DMCA copyright notices: http://t.co/DwSwunrH",
    "id" : 265156446877011968,
    "created_at" : "2012-11-04 18:19:57 +0000",
    "user" : {
      "name" : "Jeff Roberts",
      "screen_name" : "jeffjohnroberts",
      "protected" : false,
      "id_str" : "17925409",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/608568472/11853_857916900499_801720_49148058_6132539_n_normal.jpg",
      "id" : 17925409,
      "verified" : false
    }
  },
  "id" : 265185276475891713,
  "created_at" : "2012-11-04 20:14:31 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://bufferapp.com\" rel=\"nofollow\">Buffer</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Medium",
      "screen_name" : "Medium",
      "indices" : [ 36, 43 ],
      "id_str" : "571202103",
      "id" : 571202103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 64 ],
      "url" : "http://t.co/PM1E9MSi",
      "expanded_url" : "http://bit.ly/SLgSrV",
      "display_url" : "bit.ly/SLgSrV"
    } ]
  },
  "geo" : { },
  "id_str" : "265182949383757824",
  "text" : "\"What I\u2019m tracking now, and why\" on @medium http://t.co/PM1E9MSi",
  "id" : 265182949383757824,
  "created_at" : "2012-11-04 20:05:16 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"https://findings.com\" rel=\"nofollow\">Findings</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 117 ],
      "url" : "http://t.co/hxpyRh5X",
      "expanded_url" : "http://findings.com",
      "display_url" : "findings.com"
    }, {
      "indices" : [ 120, 140 ],
      "url" : "http://t.co/JRcdt89M",
      "expanded_url" : "http://fnd.gs/VLWdBk",
      "display_url" : "fnd.gs/VLWdBk"
    } ]
  },
  "geo" : { },
  "id_str" : "265179321667317761",
  "text" : "\"The default state of any new idea is failure. It\u2019s the fight against inertia that matters.\" via http://t.co/hxpyRh5X - http://t.co/JRcdt89M",
  "id" : 265179321667317761,
  "created_at" : "2012-11-04 19:50:51 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://bufferapp.com\" rel=\"nofollow\">Buffer</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 77 ],
      "url" : "http://t.co/hMYkAcHe",
      "expanded_url" : "http://bit.ly/SIVz7G",
      "display_url" : "bit.ly/SIVz7G"
    } ]
  },
  "geo" : { },
  "id_str" : "265150301089189889",
  "text" : "\u201CBehavior change is an intuition pump\" - Way of the Duck http://t.co/hMYkAcHe",
  "id" : 265150301089189889,
  "created_at" : "2012-11-04 17:55:32 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nate Silver",
      "screen_name" : "fivethirtyeight",
      "indices" : [ 3, 19 ],
      "id_str" : "16017475",
      "id" : 16017475
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http://t.co/AVlagOjq",
      "expanded_url" : "http://fivethirtyeight.blogs.nytimes.com/",
      "display_url" : "fivethirtyeight.blogs.nytimes.com"
    } ]
  },
  "geo" : { },
  "id_str" : "264968006071885824",
  "text" : "RT @fivethirtyeight: Lots of polls but little change in tonight's 538 forecast. Obama 84% to win Electoral College. http://t.co/AVlagOjq",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 95, 115 ],
        "url" : "http://t.co/AVlagOjq",
        "expanded_url" : "http://fivethirtyeight.blogs.nytimes.com/",
        "display_url" : "fivethirtyeight.blogs.nytimes.com"
      } ]
    },
    "geo" : { },
    "id_str" : "264959389897723905",
    "text" : "Lots of polls but little change in tonight's 538 forecast. Obama 84% to win Electoral College. http://t.co/AVlagOjq",
    "id" : 264959389897723905,
    "created_at" : "2012-11-04 05:16:55 +0000",
    "user" : {
      "name" : "Nate Silver",
      "screen_name" : "fivethirtyeight",
      "protected" : false,
      "id_str" : "16017475",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000188475595/9048bff5190578d8e2c558dca3606fbb_normal.png",
      "id" : 16017475,
      "verified" : true
    }
  },
  "id" : 264968006071885824,
  "created_at" : "2012-11-04 05:51:10 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "d i g i t t a n t e",
      "screen_name" : "digittante",
      "indices" : [ 0, 11 ],
      "id_str" : "8144682",
      "id" : 8144682
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "264951275597221888",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6085874533, -122.3061905178 ]
  },
  "id_str" : "264953582602825728",
  "in_reply_to_user_id" : 8144682,
  "text" : "@digittante Not necessarily. Where does the world need the most help?",
  "id" : 264953582602825728,
  "in_reply_to_status_id" : 264951275597221888,
  "created_at" : "2012-11-04 04:53:51 +0000",
  "in_reply_to_screen_name" : "digittante",
  "in_reply_to_user_id_str" : "8144682",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Goldenberg",
      "screen_name" : "mattgoldenberg",
      "indices" : [ 0, 15 ],
      "id_str" : "16918922",
      "id" : 16918922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "264935355885686784",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6086062416, -122.3061473162 ]
  },
  "id_str" : "264937873516683264",
  "in_reply_to_user_id" : 16918922,
  "text" : "@mattgoldenberg Great thoughts! Care to join the branch?",
  "id" : 264937873516683264,
  "in_reply_to_status_id" : 264935355885686784,
  "created_at" : "2012-11-04 03:51:26 +0000",
  "in_reply_to_screen_name" : "mattgoldenberg",
  "in_reply_to_user_id_str" : "16918922",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 61 ],
      "url" : "http://t.co/FZ7ui2A8",
      "expanded_url" : "http://instagr.am/p/Rl8W40I0DC/",
      "display_url" : "instagr.am/p/Rl8W40I0DC/"
    } ]
  },
  "geo" : { },
  "id_str" : "264935103824805889",
  "text" : "8:36pm \"When I took the moon for a walk\" http://t.co/FZ7ui2A8",
  "id" : 264935103824805889,
  "created_at" : "2012-11-04 03:40:25 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Wallin",
      "screen_name" : "joewallin",
      "indices" : [ 0, 10 ],
      "id_str" : "14857106",
      "id" : 14857106
    }, {
      "name" : "Dave Schappell",
      "screen_name" : "daveschappell",
      "indices" : [ 11, 25 ],
      "id_str" : "820661",
      "id" : 820661
    }, {
      "name" : "Andy Sack",
      "screen_name" : "AndySack",
      "indices" : [ 26, 35 ],
      "id_str" : "39362168",
      "id" : 39362168
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "264900601018740738",
  "geo" : { },
  "id_str" : "264906610302939136",
  "in_reply_to_user_id" : 14857106,
  "text" : "@joewallin @daveschappell @andysack yeah but you got keep mixing things up to fully appreciate the best things in life, right?",
  "id" : 264906610302939136,
  "in_reply_to_status_id" : 264900601018740738,
  "created_at" : "2012-11-04 01:47:12 +0000",
  "in_reply_to_screen_name" : "joewallin",
  "in_reply_to_user_id_str" : "14857106",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "girl jo",
      "screen_name" : "octavekitten",
      "indices" : [ 0, 13 ],
      "id_str" : "16366882",
      "id" : 16366882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "264901143329656832",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6086268854, -122.3061445915 ]
  },
  "id_str" : "264903202942644225",
  "in_reply_to_user_id" : 16366882,
  "text" : "@octavekitten I love that place.",
  "id" : 264903202942644225,
  "in_reply_to_status_id" : 264901143329656832,
  "created_at" : "2012-11-04 01:33:39 +0000",
  "in_reply_to_screen_name" : "octavekitten",
  "in_reply_to_user_id_str" : "16366882",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alex choi \u2744",
      "screen_name" : "xc",
      "indices" : [ 0, 3 ],
      "id_str" : "26233",
      "id" : 26233
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "264899022161051648",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6085998741, -122.3061701418 ]
  },
  "id_str" : "264902393404194816",
  "in_reply_to_user_id" : 26233,
  "text" : "@xc 3-4 cups throughout the day",
  "id" : 264902393404194816,
  "in_reply_to_status_id" : 264899022161051648,
  "created_at" : "2012-11-04 01:30:26 +0000",
  "in_reply_to_screen_name" : "xc",
  "in_reply_to_user_id_str" : "26233",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6086046733, -122.3061210384 ]
  },
  "id_str" : "264897656369852416",
  "text" : "Today is the first day in maybe 3 million years that I didn't drink any caffeine. Should I continue the 1 day streak?",
  "id" : 264897656369852416,
  "created_at" : "2012-11-04 01:11:37 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jane McGonigal",
      "screen_name" : "avantgame",
      "indices" : [ 3, 13 ],
      "id_str" : "681813",
      "id" : 681813
    }, {
      "name" : "Anti-Buster",
      "screen_name" : "busterbenson",
      "indices" : [ 15, 28 ],
      "id_str" : "1024917050",
      "id" : 1024917050
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "264836077146226688",
  "text" : "RT @avantgame: @busterbenson exactly. don't know whether to marvel at hypocrisy of outrage? OR (optimistically) possibility to see reali ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Anti-Buster",
        "screen_name" : "busterbenson",
        "indices" : [ 0, 13 ],
        "id_str" : "1024917050",
        "id" : 1024917050
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "264820912161951744",
    "geo" : { },
    "id_str" : "264821728994283521",
    "in_reply_to_user_id" : 2185,
    "text" : "@busterbenson exactly. don't know whether to marvel at hypocrisy of outrage? OR (optimistically) possibility to see reality we are global 1%",
    "id" : 264821728994283521,
    "in_reply_to_status_id" : 264820912161951744,
    "created_at" : "2012-11-03 20:09:54 +0000",
    "in_reply_to_screen_name" : "buster",
    "in_reply_to_user_id_str" : "2185",
    "user" : {
      "name" : "Jane McGonigal",
      "screen_name" : "avantgame",
      "protected" : false,
      "id_str" : "681813",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000116152853/47c4501ee2d80e97b423129fe0db016a_normal.jpeg",
      "id" : 681813,
      "verified" : false
    }
  },
  "id" : 264836077146226688,
  "created_at" : "2012-11-03 21:06:55 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jane McGonigal",
      "screen_name" : "avantgame",
      "indices" : [ 0, 10 ],
      "id_str" : "681813",
      "id" : 681813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "264821859797848064",
  "geo" : { },
  "id_str" : "264835481152413696",
  "in_reply_to_user_id" : 681813,
  "text" : "@avantgame That was exactly my thought too. I approve of the logic, and wonder if we can make it stick for a wider range of situations...",
  "id" : 264835481152413696,
  "in_reply_to_status_id" : 264821859797848064,
  "created_at" : "2012-11-03 21:04:33 +0000",
  "in_reply_to_screen_name" : "avantgame",
  "in_reply_to_user_id_str" : "681813",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6086130069, -122.3061042166 ]
  },
  "id_str" : "264820912161951744",
  "text" : "Cancel a marathon bc it requires resources better allocated to the recovery. What happens if you extend that logic to the whole world?",
  "id" : 264820912161951744,
  "created_at" : "2012-11-03 20:06:40 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles Mudede",
      "screen_name" : "mudede",
      "indices" : [ 3, 10 ],
      "id_str" : "33412856",
      "id" : 33412856
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "264817784033271808",
  "text" : "RT @mudede: The great thing about a kind mirror is you never believe it.",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "264817418851991552",
    "text" : "The great thing about a kind mirror is you never believe it.",
    "id" : 264817418851991552,
    "created_at" : "2012-11-03 19:52:47 +0000",
    "user" : {
      "name" : "Charles Mudede",
      "screen_name" : "mudede",
      "protected" : false,
      "id_str" : "33412856",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1005741619/l_9523fb95b5434e7f93d4c3c476ca5d4e_normal.jpg",
      "id" : 33412856,
      "verified" : false
    }
  },
  "id" : 264817784033271808,
  "created_at" : "2012-11-03 19:54:14 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ronen V Private",
      "screen_name" : "Ronen",
      "indices" : [ 0, 6 ],
      "id_str" : "15080315",
      "id" : 15080315
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "264782462993965057",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6087239897, -122.3059753609 ]
  },
  "id_str" : "264804306128105472",
  "in_reply_to_user_id" : 1206581,
  "text" : "@ronen Hm... you're right. Still a big deal though.",
  "id" : 264804306128105472,
  "in_reply_to_status_id" : 264782462993965057,
  "created_at" : "2012-11-03 19:00:41 +0000",
  "in_reply_to_screen_name" : "RonenV",
  "in_reply_to_user_id_str" : "1206581",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 115 ],
      "url" : "http://t.co/OEBkmOWw",
      "expanded_url" : "http://www.huffingtonpost.com/mobileweb/2012/11/02/george-lucas-donate-4-billion_n_2067145.html",
      "display_url" : "huffingtonpost.com/mobileweb/2012\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6086735766, -122.30613956 ]
  },
  "id_str" : "264780330819534848",
  "text" : "This is awesome. George Lucas is donating all $4B from sale to a new foundation for education. http://t.co/OEBkmOWw",
  "id" : 264780330819534848,
  "created_at" : "2012-11-03 17:25:24 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Morrissey",
      "screen_name" : "bmorrissey",
      "indices" : [ 3, 14 ],
      "id_str" : "1318301",
      "id" : 1318301
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "264778019049189376",
  "text" : "RT @bmorrissey: Like how Nate Silver is directly taking on critics. Basically calls the 'it's a tossup' crowd dishonest here. http://t.c ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://itunes.apple.com/us/app/nytimes/id284862083?mt=8&uo=4\" rel=\"nofollow\">NYTimes on iOS</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 110, 130 ],
        "url" : "http://t.co/KZfuJcY2",
        "expanded_url" : "http://nyti.ms/U6UJX5",
        "display_url" : "nyti.ms/U6UJX5"
      } ]
    },
    "geo" : { },
    "id_str" : "264754370443366400",
    "text" : "Like how Nate Silver is directly taking on critics. Basically calls the 'it's a tossup' crowd dishonest here. http://t.co/KZfuJcY2",
    "id" : 264754370443366400,
    "created_at" : "2012-11-03 15:42:15 +0000",
    "user" : {
      "name" : "Brian Morrissey",
      "screen_name" : "bmorrissey",
      "protected" : false,
      "id_str" : "1318301",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000399699114/2aff7e6db242cd55dbf498f56c6e0c31_normal.jpeg",
      "id" : 1318301,
      "verified" : false
    }
  },
  "id" : 264778019049189376,
  "created_at" : "2012-11-03 17:16:13 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mkarp",
      "screen_name" : "mkarp",
      "indices" : [ 3, 9 ],
      "id_str" : "18135478",
      "id" : 18135478
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 56 ],
      "url" : "http://t.co/xpdAdrPo",
      "expanded_url" : "http://nyti.ms/KqZ0NZ",
      "display_url" : "nyti.ms/KqZ0NZ"
    } ]
  },
  "geo" : { },
  "id_str" : "264625333293154305",
  "text" : "RT @mkarp: G.O.P. Nightmare Charts: http://t.co/xpdAdrPo",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 25, 45 ],
        "url" : "http://t.co/xpdAdrPo",
        "expanded_url" : "http://nyti.ms/KqZ0NZ",
        "display_url" : "nyti.ms/KqZ0NZ"
      } ]
    },
    "geo" : { },
    "id_str" : "205572288073039872",
    "text" : "G.O.P. Nightmare Charts: http://t.co/xpdAdrPo",
    "id" : 205572288073039872,
    "created_at" : "2012-05-24 08:13:47 +0000",
    "user" : {
      "name" : "mkarp",
      "screen_name" : "mkarp",
      "protected" : false,
      "id_str" : "18135478",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1616921937/MBK_normal.jpg",
      "id" : 18135478,
      "verified" : false
    }
  },
  "id" : 264625333293154305,
  "created_at" : "2012-11-03 07:09:30 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 64 ],
      "url" : "http://t.co/Un1hir75",
      "expanded_url" : "http://instagr.am/p/Rjtoe7I0Nl/",
      "display_url" : "instagr.am/p/Rjtoe7I0Nl/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.61533432, -122.326127887 ]
  },
  "id_str" : "264621238155096065",
  "text" : "Aimee has flashlight fingers @ Capitol Club http://t.co/Un1hir75",
  "id" : 264621238155096065,
  "created_at" : "2012-11-03 06:53:14 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.apple.com\" rel=\"nofollow\">Safari on iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 97 ],
      "url" : "http://t.co/YoTPX5ed",
      "expanded_url" : "http://www.nytimes.com/interactive/2012/11/02/us/politics/paths-to-the-white-house.html",
      "display_url" : "nytimes.com/interactive/20\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "264597022043156480",
  "text" : "Bookmark this page for election night bingo (ps awesome info graphic inside) http://t.co/YoTPX5ed",
  "id" : 264597022043156480,
  "created_at" : "2012-11-03 05:17:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 88 ],
      "url" : "http://t.co/m4jkTtj3",
      "expanded_url" : "http://flic.kr/p/dqadZH",
      "display_url" : "flic.kr/p/dqadZH"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.443833, -122.300667 ]
  },
  "id_str" : "264595572319739905",
  "text" : "8:36pm Just landed in Seattle. Headed to Capitol Club for blackout! http://t.co/m4jkTtj3",
  "id" : 264595572319739905,
  "created_at" : "2012-11-03 05:11:15 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "A.S. Breuer",
      "screen_name" : "asbreuer",
      "indices" : [ 0, 9 ],
      "id_str" : "358563517",
      "id" : 358563517
    }, {
      "name" : "April Schiller",
      "screen_name" : "the_april",
      "indices" : [ 10, 20 ],
      "id_str" : "16644937",
      "id" : 16644937
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "264549155773493249",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.6155836625, -122.3827910592 ]
  },
  "id_str" : "264555862469787648",
  "in_reply_to_user_id" : 358563517,
  "text" : "@asbreuer @the_april I see a favorited tweet from 1,172 days ago. Sorry, Andreas.",
  "id" : 264555862469787648,
  "in_reply_to_status_id" : 264549155773493249,
  "created_at" : "2012-11-03 02:33:27 +0000",
  "in_reply_to_screen_name" : "asbreuer",
  "in_reply_to_user_id_str" : "358563517",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian Chan",
      "screen_name" : "chanian",
      "indices" : [ 0, 8 ],
      "id_str" : "22891211",
      "id" : 22891211
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "264517957579853824",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7612407553, -122.422765325 ]
  },
  "id_str" : "264518515124498432",
  "in_reply_to_user_id" : 22891211,
  "text" : "@chanian You were probably just trying to pad your follower lead on me.",
  "id" : 264518515124498432,
  "in_reply_to_status_id" : 264517957579853824,
  "created_at" : "2012-11-03 00:05:03 +0000",
  "in_reply_to_screen_name" : "chanian",
  "in_reply_to_user_id_str" : "22891211",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://bufferapp.com\" rel=\"nofollow\">Buffer</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ff",
      "indices" : [ 8, 11 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 96 ],
      "url" : "http://t.co/4hoXXVTo",
      "expanded_url" : "http://bit.ly/RByIcp",
      "display_url" : "bit.ly/RByIcp"
    } ]
  },
  "geo" : { },
  "id_str" : "264510517744386048",
  "text" : "Why not #ff my whole team, cause we are building really cool stuff for you: http://t.co/4hoXXVTo",
  "id" : 264510517744386048,
  "created_at" : "2012-11-02 23:33:16 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Cottrell",
      "screen_name" : "rgcottrell",
      "indices" : [ 0, 11 ],
      "id_str" : "752553",
      "id" : 752553
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "264487781529702400",
  "geo" : { },
  "id_str" : "264488847461711873",
  "in_reply_to_user_id" : 752553,
  "text" : "@rgcottrell Awesome!",
  "id" : 264488847461711873,
  "in_reply_to_status_id" : 264487781529702400,
  "created_at" : "2012-11-02 22:07:09 +0000",
  "in_reply_to_screen_name" : "rgcottrell",
  "in_reply_to_user_id_str" : "752553",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Cottrell",
      "screen_name" : "rgcottrell",
      "indices" : [ 0, 11 ],
      "id_str" : "752553",
      "id" : 752553
    }, {
      "name" : "Sean Cook",
      "screen_name" : "theSeanCook",
      "indices" : [ 32, 44 ],
      "id_str" : "38895958",
      "id" : 38895958
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 121 ],
      "url" : "https://t.co/IaQ83fCY",
      "expanded_url" : "https://dev.twitter.com/blog/reverse-auth-enabled-by-default",
      "display_url" : "dev.twitter.com/blog/reverse-a\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7765680545, -122.4169736254 ]
  },
  "id_str" : "264459717336780800",
  "in_reply_to_user_id" : 752553,
  "text" : "@rgcottrell this is for you: RT @theSeanCook: Reverse Auth: enabled by default | Twitter Developers https://t.co/IaQ83fCY",
  "id" : 264459717336780800,
  "created_at" : "2012-11-02 20:11:24 +0000",
  "in_reply_to_screen_name" : "rgcottrell",
  "in_reply_to_user_id_str" : "752553",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u2729 evonne heyning \u221E",
      "screen_name" : "amoration",
      "indices" : [ 0, 10 ],
      "id_str" : "5447732",
      "id" : 5447732
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "264452634801491968",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7766239557, -122.4170160222 ]
  },
  "id_str" : "264458143344517120",
  "in_reply_to_user_id" : 5447732,
  "text" : "@amoration I would disagree.",
  "id" : 264458143344517120,
  "in_reply_to_status_id" : 264452634801491968,
  "created_at" : "2012-11-02 20:05:09 +0000",
  "in_reply_to_screen_name" : "amoration",
  "in_reply_to_user_id_str" : "5447732",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helen Jane",
      "screen_name" : "helenjane",
      "indices" : [ 0, 10 ],
      "id_str" : "798542",
      "id" : 798542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "264444156431171584",
  "geo" : { },
  "id_str" : "264449171547885568",
  "in_reply_to_user_id" : 798542,
  "text" : "@helenjane Avoid and generate at the same time?",
  "id" : 264449171547885568,
  "in_reply_to_status_id" : 264444156431171584,
  "created_at" : "2012-11-02 19:29:30 +0000",
  "in_reply_to_screen_name" : "helenjane",
  "in_reply_to_user_id_str" : "798542",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://bufferapp.com\" rel=\"nofollow\">Buffer</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "264443086376161280",
  "text" : "Our brains aren't designed to seek truth, they're designed to seek effectiveness.",
  "id" : 264443086376161280,
  "created_at" : "2012-11-02 19:05:19 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tumblr.com/\" rel=\"nofollow\">Tumblr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 95 ],
      "url" : "http://t.co/udDsz1Gt",
      "expanded_url" : "http://tmblr.co/ZQJvayWSfnRc",
      "display_url" : "tmblr.co/ZQJvayWSfnRc"
    } ]
  },
  "geo" : { },
  "id_str" : "264429306279768064",
  "text" : "1993 InfoWorld article about my father's work on object-oriented databases http://t.co/udDsz1Gt",
  "id" : 264429306279768064,
  "created_at" : "2012-11-02 18:10:34 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jacqueline wolven",
      "screen_name" : "jackiewolven",
      "indices" : [ 0, 13 ],
      "id_str" : "7413172",
      "id" : 7413172
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "264422705783255041",
  "geo" : { },
  "id_str" : "264427969165025281",
  "in_reply_to_user_id" : 7413172,
  "text" : "@jackiewolven That would be fine too. :) The point is, this relationship is probably beyond being repairable.",
  "id" : 264427969165025281,
  "in_reply_to_status_id" : 264422705783255041,
  "created_at" : "2012-11-02 18:05:15 +0000",
  "in_reply_to_screen_name" : "jackiewolven",
  "in_reply_to_user_id_str" : "7413172",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jacqueline wolven",
      "screen_name" : "jackiewolven",
      "indices" : [ 0, 13 ],
      "id_str" : "7413172",
      "id" : 7413172
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "264421004389007360",
  "geo" : { },
  "id_str" : "264422417047359488",
  "in_reply_to_user_id" : 7413172,
  "text" : "@jackiewolven Only if people don't want to do it. I think if we do it sooner rather than later, we'd all still be able to be friends.",
  "id" : 264422417047359488,
  "in_reply_to_status_id" : 264421004389007360,
  "created_at" : "2012-11-02 17:43:11 +0000",
  "in_reply_to_screen_name" : "jackiewolven",
  "in_reply_to_user_id_str" : "7413172",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ron Diver",
      "screen_name" : "rondiver",
      "indices" : [ 0, 9 ],
      "id_str" : "12661782",
      "id" : 12661782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "264406181278273537",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7763977417, -122.4167774835 ]
  },
  "id_str" : "264407809855193088",
  "in_reply_to_user_id" : 12661782,
  "text" : "@rondiver Only as much as current govs are corps. For example they couldn't fire you. And don't have to pay you.",
  "id" : 264407809855193088,
  "in_reply_to_status_id" : 264406181278273537,
  "created_at" : "2012-11-02 16:45:08 +0000",
  "in_reply_to_screen_name" : "rondiver",
  "in_reply_to_user_id_str" : "12661782",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7763999212, -122.4167674424 ]
  },
  "id_str" : "264405786615246848",
  "text" : "If our government were a marriage I think both sides would be ready for a divorce. It'll be tough on the kids but better in the long run.",
  "id" : 264405786615246848,
  "created_at" : "2012-11-02 16:37:06 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lauren Hoffman",
      "screen_name" : "L_Hoff",
      "indices" : [ 0, 7 ],
      "id_str" : "20035911",
      "id" : 20035911
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "264403297341956096",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7763972765, -122.4167665636 ]
  },
  "id_str" : "264405423006838785",
  "in_reply_to_user_id" : 20035911,
  "text" : "@L_Hoff Like that but with shared geographic boundaries. A virtual country in a way, that one would opt in to.",
  "id" : 264405423006838785,
  "in_reply_to_status_id" : 264403297341956096,
  "created_at" : "2012-11-02 16:35:39 +0000",
  "in_reply_to_screen_name" : "L_Hoff",
  "in_reply_to_user_id_str" : "20035911",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://bufferapp.com\" rel=\"nofollow\">Buffer</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "264402235373535232",
  "text" : "Are there any fringe political discussions about splitting the US into 2 countries that occupy the same space but have different govs?",
  "id" : 264402235373535232,
  "created_at" : "2012-11-02 16:22:59 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nate Silver",
      "screen_name" : "fivethirtyeight",
      "indices" : [ 23, 39 ],
      "id_str" : "16017475",
      "id" : 16017475
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 116 ],
      "url" : "http://t.co/DzuAjK3O",
      "expanded_url" : "http://fivethirtyeight.blogs.nytimes.com/",
      "display_url" : "fivethirtyeight.blogs.nytimes.com"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7847796183, -122.404288341 ]
  },
  "id_str" : "264392095408721921",
  "text" : "Data &gt; headlines RT @fivethirtyeight: Obama remains at 80.8% to win in today's 538 forecast. http://t.co/DzuAjK3O",
  "id" : 264392095408721921,
  "created_at" : "2012-11-02 15:42:42 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "teamsilver",
      "indices" : [ 7, 18 ]
    }, {
      "text" : "teamfox",
      "indices" : [ 21, 29 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 135 ],
      "url" : "http://t.co/wlcRO8zX",
      "expanded_url" : "http://pandodaily.com/2012/11/02/foxy-nate-silver-and-why-old-media-hedgehogs-could-soon-be-old-news/",
      "display_url" : "pandodaily.com/2012/11/02/fox\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7856206233, -122.4043439102 ]
  },
  "id_str" : "264385545172570114",
  "text" : "I'm on #teamsilver / #teamfox \"Hedgehogs are more easily seduced by clear narratives. Foxes are more data-driven.\" http://t.co/wlcRO8zX",
  "id" : 264385545172570114,
  "created_at" : "2012-11-02 15:16:40 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ted Rheingold",
      "screen_name" : "tedr",
      "indices" : [ 0, 5 ],
      "id_str" : "997",
      "id" : 997
    }, {
      "name" : "Dave Schappell",
      "screen_name" : "daveschappell",
      "indices" : [ 116, 130 ],
      "id_str" : "820661",
      "id" : 820661
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "264232259438120960",
  "geo" : { },
  "id_str" : "264234130491965440",
  "in_reply_to_user_id" : 997,
  "text" : "@tedr In my 10+ years of tech I've never used LinkedIn to hire or be hired. They seem easily disruptable to me. /cc @daveschappell",
  "id" : 264234130491965440,
  "in_reply_to_status_id" : 264232259438120960,
  "created_at" : "2012-11-02 05:15:00 +0000",
  "in_reply_to_screen_name" : "tedr",
  "in_reply_to_user_id_str" : "997",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Schappell",
      "screen_name" : "daveschappell",
      "indices" : [ 0, 14 ],
      "id_str" : "820661",
      "id" : 820661
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "264229399442903041",
  "geo" : { },
  "id_str" : "264229906077065216",
  "in_reply_to_user_id" : 820661,
  "text" : "@daveschappell I don't get how they make any money at all. Who's giving it to them? Don't make me look it up. :)",
  "id" : 264229906077065216,
  "in_reply_to_status_id" : 264229399442903041,
  "created_at" : "2012-11-02 04:58:13 +0000",
  "in_reply_to_screen_name" : "daveschappell",
  "in_reply_to_user_id_str" : "820661",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 35 ],
      "url" : "http://t.co/meWaoUeq",
      "expanded_url" : "http://bit.ly/Yb4S4v",
      "display_url" : "bit.ly/Yb4S4v"
    } ]
  },
  "geo" : { },
  "id_str" : "264223630894968833",
  "text" : "Today's score: http://t.co/meWaoUeq",
  "id" : 264223630894968833,
  "created_at" : "2012-11-02 04:33:17 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 40 ],
      "url" : "http://t.co/Vc22zwOc",
      "expanded_url" : "http://instagr.am/p/Rg1vUBI0BU/",
      "display_url" : "instagr.am/p/Rg1vUBI0BU/"
    } ]
  },
  "geo" : { },
  "id_str" : "264216968167555072",
  "text" : "8:36pm FaceTime-ing http://t.co/Vc22zwOc",
  "id" : 264216968167555072,
  "created_at" : "2012-11-02 04:06:48 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 0, 9 ],
      "id_str" : "761628",
      "id" : 761628
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "264139320011665408",
  "geo" : { },
  "id_str" : "264139622928498690",
  "in_reply_to_user_id" : 761628,
  "text" : "@RickWebb I'm an advisor so let me know if you want in. :)",
  "id" : 264139622928498690,
  "in_reply_to_status_id" : 264139320011665408,
  "created_at" : "2012-11-01 22:59:28 +0000",
  "in_reply_to_screen_name" : "RickWebb",
  "in_reply_to_user_id_str" : "761628",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 0, 9 ],
      "id_str" : "761628",
      "id" : 761628
    }, {
      "name" : "Apptentive",
      "screen_name" : "apptentive",
      "indices" : [ 14, 25 ],
      "id_str" : "267925827",
      "id" : 267925827
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "264138912698601473",
  "geo" : { },
  "id_str" : "264139239338418176",
  "in_reply_to_user_id" : 761628,
  "text" : "@RickWebb Has @apptentive gone yet? You should definitely check them out.",
  "id" : 264139239338418176,
  "in_reply_to_status_id" : 264138912698601473,
  "created_at" : "2012-11-01 22:57:56 +0000",
  "in_reply_to_screen_name" : "RickWebb",
  "in_reply_to_user_id_str" : "761628",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alicia Morga",
      "screen_name" : "AliciaMorga",
      "indices" : [ 30, 42 ],
      "id_str" : "19053875",
      "id" : 19053875
    }, {
      "name" : "gottaFeeling",
      "screen_name" : "gottafeelingApp",
      "indices" : [ 55, 71 ],
      "id_str" : "219092435",
      "id" : 219092435
    }, {
      "name" : "Alicia Morga",
      "screen_name" : "AliciaMorga",
      "indices" : [ 90, 102 ],
      "id_str" : "19053875",
      "id" : 19053875
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "264097928094826496",
  "geo" : { },
  "id_str" : "264110011226132481",
  "in_reply_to_user_id" : 19053875,
  "text" : "Super excited to finally meet @AliciaMorga, creator of @GottaFeelingApp and much more! RT @AliciaMorga Tweeting from Twitter... So meta!",
  "id" : 264110011226132481,
  "in_reply_to_status_id" : 264097928094826496,
  "created_at" : "2012-11-01 21:01:48 +0000",
  "in_reply_to_screen_name" : "AliciaMorga",
  "in_reply_to_user_id_str" : "19053875",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Poynter",
      "screen_name" : "Poynter",
      "indices" : [ 3, 11 ],
      "id_str" : "8383592",
      "id" : 8383592
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nyt",
      "indices" : [ 132, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 131 ],
      "url" : "http://t.co/ZD1X0fJR",
      "expanded_url" : "http://journ.us/UkXjmG",
      "display_url" : "journ.us/UkXjmG"
    } ]
  },
  "geo" : { },
  "id_str" : "264043199650213888",
  "text" : "RT @Poynter: If books titles were written like New York Times headlines, here is what would line your shelves: http://t.co/ZD1X0fJR #nyt ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.hootsuite.com\" rel=\"nofollow\">HootSuite</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "nytbooks",
        "indices" : [ 119, 128 ]
      } ],
      "urls" : [ {
        "indices" : [ 98, 118 ],
        "url" : "http://t.co/ZD1X0fJR",
        "expanded_url" : "http://journ.us/UkXjmG",
        "display_url" : "journ.us/UkXjmG"
      } ]
    },
    "geo" : { },
    "id_str" : "264035824423809024",
    "text" : "If books titles were written like New York Times headlines, here is what would line your shelves: http://t.co/ZD1X0fJR #nytbooks",
    "id" : 264035824423809024,
    "created_at" : "2012-11-01 16:07:00 +0000",
    "user" : {
      "name" : "Poynter",
      "screen_name" : "Poynter",
      "protected" : false,
      "id_str" : "8383592",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/432476699/poynter_profile_normal.jpg",
      "id" : 8383592,
      "verified" : true
    }
  },
  "id" : 264043199650213888,
  "created_at" : "2012-11-01 16:36:19 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/instagram/id389801252?mt=8&uo=4\" rel=\"nofollow\">Instagram on iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 36, 46 ],
      "id_str" : "7362142",
      "id" : 7362142
    }, {
      "name" : "Niko Benson",
      "screen_name" : "nikobenson",
      "indices" : [ 47, 58 ],
      "id_str" : "142467448",
      "id" : 142467448
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 31 ],
      "url" : "http://t.co/LAmQQXjs",
      "expanded_url" : "http://instagr.am/p/ReG7xkOFQV/",
      "display_url" : "instagr.am/p/ReG7xkOFQV/"
    } ]
  },
  "geo" : { },
  "id_str" : "263906321768800256",
  "text" : "These two. http://t.co/LAmQQXjs /cc @kellianne @nikobenson",
  "id" : 263906321768800256,
  "created_at" : "2012-11-01 07:32:24 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
} ]