Grailbird.data.tweets_2011_07 = 
 [ {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.551333, -122.319834 ]
  },
  "id_str" : "97875471622094848",
  "text" : "8:36pm Feeling blessed at a beautiful wedding of friends http://flic.kr/p/a8VsR3",
  "id" : 97875471622094848,
  "created_at" : "Mon Aug 01 03:45:05 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.5514904833, -122.319561 ]
  },
  "id_str" : "97826949799489536",
  "text" : "Congrats Brett and Lucy!   @ Georgetown Ballroom http://instagr.am/p/JB91T/",
  "id" : 97826949799489536,
  "created_at" : "Mon Aug 01 00:32:17 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Harrison",
      "screen_name" : "sourjayne",
      "indices" : [ 0, 10 ],
      "id_str" : "4981271",
      "id" : 4981271
    }, {
      "name" : "Rdio",
      "screen_name" : "Rdio",
      "indices" : [ 106, 111 ],
      "id_str" : "54205414",
      "id" : 54205414
    }, {
      "name" : "Trammell",
      "screen_name" : "trammell",
      "indices" : [ 112, 121 ],
      "id_str" : "666073",
      "id" : 666073
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "97770975906627584",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.60608816, -122.3228321 ]
  },
  "id_str" : "97773012438368256",
  "in_reply_to_user_id" : 4981271,
  "text" : "@sourjayne I've often wanted to know the same thing! Listened to some Otis myself as a result too. :) /cc @rdio @trammell",
  "id" : 97773012438368256,
  "in_reply_to_status_id" : 97770975906627584,
  "created_at" : "Sun Jul 31 20:57:57 +0000 2011",
  "in_reply_to_screen_name" : "sourjayne",
  "in_reply_to_user_id_str" : "4981271",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mary Specht",
      "screen_name" : "designmary",
      "indices" : [ 0, 11 ],
      "id_str" : "7357082",
      "id" : 7357082
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "97758289017839617",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.60608816, -122.3228321 ]
  },
  "id_str" : "97772366763016193",
  "in_reply_to_user_id" : 7357082,
  "text" : "@designmary I'm glad you like it! Let me know if it affects your inbox at all in the next couple days. Or, I guess I can just look myself!",
  "id" : 97772366763016193,
  "in_reply_to_status_id" : 97758289017839617,
  "created_at" : "Sun Jul 31 20:55:23 +0000 2011",
  "in_reply_to_screen_name" : "designmary",
  "in_reply_to_user_id_str" : "7357082",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Casey Beck",
      "screen_name" : "csybck",
      "indices" : [ 0, 7 ],
      "id_str" : "41390798",
      "id" : 41390798
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 118 ],
      "url" : "http://t.co/dGgAAou",
      "expanded_url" : "http://bud.ge",
      "display_url" : "bud.ge"
    } ]
  },
  "in_reply_to_status_id_str" : "97711113034137600",
  "geo" : {
  },
  "id_str" : "97717306704134145",
  "in_reply_to_user_id" : 41390798,
  "text" : "@csybck Awesome! I'm working on a new app that might be able to help. If interested, sign up here: http://t.co/dGgAAou",
  "id" : 97717306704134145,
  "in_reply_to_status_id" : 97711113034137600,
  "created_at" : "Sun Jul 31 17:16:36 +0000 2011",
  "in_reply_to_screen_name" : "csybck",
  "in_reply_to_user_id_str" : "41390798",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emilio Ramirez",
      "screen_name" : "e_ramirez",
      "indices" : [ 0, 10 ],
      "id_str" : "1273564632",
      "id" : 1273564632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "96001841011228674",
  "geo" : {
  },
  "id_str" : "97550406841937920",
  "in_reply_to_user_id" : 21135674,
  "text" : "@e_ramirez I meant to say yes to this! What could be challenging for you at this point?  I think something programming related. :)",
  "id" : 97550406841937920,
  "in_reply_to_status_id" : 96001841011228674,
  "created_at" : "Sun Jul 31 06:13:24 +0000 2011",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "97546428292927488",
  "text" : "@GoalsGamified Want to try it (or something else, if this is already a habit) for another week? I'm testing a new product I'm building.",
  "id" : 97546428292927488,
  "created_at" : "Sun Jul 31 05:57:35 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "katrina panovich",
      "screen_name" : "katrina_",
      "indices" : [ 0, 9 ],
      "id_str" : "9381242",
      "id" : 9381242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "95628606532886528",
  "geo" : {
  },
  "id_str" : "97546265411321857",
  "in_reply_to_user_id" : 9381242,
  "text" : "@katrina_ Want to try again for a week? I'll keep trying to improve the reminder system.",
  "id" : 97546265411321857,
  "in_reply_to_status_id" : 95628606532886528,
  "created_at" : "Sun Jul 31 05:56:56 +0000 2011",
  "in_reply_to_screen_name" : "katrina_",
  "in_reply_to_user_id_str" : "9381242",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Skotzko",
      "screen_name" : "askotzko",
      "indices" : [ 0, 9 ],
      "id_str" : "15391002",
      "id" : 15391002
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "95638652461391872",
  "geo" : {
  },
  "id_str" : "97546175099572224",
  "in_reply_to_user_id" : 15391002,
  "text" : "@askotzko Wanna try another week of meditation reminders? I'm slowly building a product around it and need volunteers!",
  "id" : 97546175099572224,
  "in_reply_to_status_id" : 95638652461391872,
  "created_at" : "Sun Jul 31 05:56:35 +0000 2011",
  "in_reply_to_screen_name" : "askotzko",
  "in_reply_to_user_id_str" : "15391002",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carrie-Anne Gallo",
      "screen_name" : "CazMinx",
      "indices" : [ 0, 8 ],
      "id_str" : "20905374",
      "id" : 20905374
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "95744779559763968",
  "geo" : {
  },
  "id_str" : "97546014520643584",
  "in_reply_to_user_id" : 20905374,
  "text" : "@CazMinx Any interest in hopping on the reminder wagon again? We can try something else\u2026 I'm trying to learn how to make it more useful.",
  "id" : 97546014520643584,
  "in_reply_to_status_id" : 95744779559763968,
  "created_at" : "Sun Jul 31 05:55:56 +0000 2011",
  "in_reply_to_screen_name" : "CazMinx",
  "in_reply_to_user_id_str" : "20905374",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.605, -122.3225 ]
  },
  "id_str" : "97513942095626240",
  "text" : "8:36pm Bye bye hobo http://flic.kr/p/a8yTqE",
  "id" : 97513942095626240,
  "created_at" : "Sun Jul 31 03:48:30 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MICHELLE",
      "screen_name" : "itsninson",
      "indices" : [ 0, 10 ],
      "id_str" : "124363227",
      "id" : 124363227
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "97433972820279296",
  "geo" : {
  },
  "id_str" : "97434250307047425",
  "in_reply_to_user_id" : 124363227,
  "text" : "@itsninson Okay, great!  Have him tweet me when he gets back. I'll save a slot.",
  "id" : 97434250307047425,
  "in_reply_to_status_id" : 97433972820279296,
  "created_at" : "Sat Jul 30 22:31:50 +0000 2011",
  "in_reply_to_screen_name" : "itsninson",
  "in_reply_to_user_id_str" : "124363227",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MICHELLE",
      "screen_name" : "itsninson",
      "indices" : [ 0, 10 ],
      "id_str" : "124363227",
      "id" : 124363227
    }, {
      "name" : "Casey Beck",
      "screen_name" : "csybck",
      "indices" : [ 36, 43 ],
      "id_str" : "41390798",
      "id" : 41390798
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "97426449342013440",
  "geo" : {
  },
  "id_str" : "97427862650490881",
  "in_reply_to_user_id" : 124363227,
  "text" : "@itsninson Oh yeah, what is it? /cc @csybck",
  "id" : 97427862650490881,
  "in_reply_to_status_id" : 97426449342013440,
  "created_at" : "Sat Jul 30 22:06:27 +0000 2011",
  "in_reply_to_screen_name" : "itsninson",
  "in_reply_to_user_id_str" : "124363227",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Davis",
      "screen_name" : "lawrencekslive",
      "indices" : [ 0, 15 ],
      "id_str" : "810644",
      "id" : 810644
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "97383975449923584",
  "geo" : {
  },
  "id_str" : "97384388286877696",
  "in_reply_to_user_id" : 120282027,
  "text" : "@lawrencekslive Yeah, that makes sense. In fact, there's a different path if you know someone that knows the answer. Skip Google/Twitter.",
  "id" : 97384388286877696,
  "in_reply_to_status_id" : 97383975449923584,
  "created_at" : "Sat Jul 30 19:13:42 +0000 2011",
  "in_reply_to_screen_name" : "JoshD",
  "in_reply_to_user_id_str" : "120282027",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "97382853096116224",
  "text" : "Want to know something? 1st, try your brain. 2nd, try Google. 3rd, try Twitter. 4th... good ol' experimentation and trial/error.",
  "id" : 97382853096116224,
  "created_at" : "Sat Jul 30 19:07:36 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Khomenko",
      "screen_name" : "akhomenko",
      "indices" : [ 0, 10 ],
      "id_str" : "46498656",
      "id" : 46498656
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "97352431431712768",
  "geo" : {
  },
  "id_str" : "97382187187449856",
  "in_reply_to_user_id" : 46498656,
  "text" : "@akhomenko Thanks for the links! That is exactly what I was looking for.",
  "id" : 97382187187449856,
  "in_reply_to_status_id" : 97352431431712768,
  "created_at" : "Sat Jul 30 19:04:57 +0000 2011",
  "in_reply_to_screen_name" : "akhomenko",
  "in_reply_to_user_id_str" : "46498656",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Beau Gunderson",
      "screen_name" : "beaugunderson",
      "indices" : [ 0, 14 ],
      "id_str" : "5746882",
      "id" : 5746882
    }, {
      "name" : "david reeves",
      "screen_name" : "dreeves",
      "indices" : [ 15, 23 ],
      "id_str" : "947851",
      "id" : 947851
    }, {
      "name" : "23andMe",
      "screen_name" : "23andMe",
      "indices" : [ 123, 131 ],
      "id_str" : "14738561",
      "id" : 14738561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "97370030030864384",
  "geo" : {
  },
  "id_str" : "97371374250770433",
  "in_reply_to_user_id" : 5746882,
  "text" : "@beaugunderson @dreeves Just the raw data? Or with interpretations? Send me any previous work you're willing to share! /cc @23andme",
  "id" : 97371374250770433,
  "in_reply_to_status_id" : 97370030030864384,
  "created_at" : "Sat Jul 30 18:21:59 +0000 2011",
  "in_reply_to_screen_name" : "beaugunderson",
  "in_reply_to_user_id_str" : "5746882",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Schappell",
      "screen_name" : "daveschappell",
      "indices" : [ 0, 14 ],
      "id_str" : "820661",
      "id" : 820661
    }, {
      "name" : "TeachStreet.com",
      "screen_name" : "teachstreet",
      "indices" : [ 74, 86 ],
      "id_str" : "15026968",
      "id" : 15026968
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "97360679895449600",
  "geo" : {
  },
  "id_str" : "97361173116239872",
  "in_reply_to_user_id" : 820661,
  "text" : "@daveschappell You'd only know if you were working every Saturday too! Go @teachstreet Go!  :)",
  "id" : 97361173116239872,
  "in_reply_to_status_id" : 97360679895449600,
  "created_at" : "Sat Jul 30 17:41:27 +0000 2011",
  "in_reply_to_screen_name" : "daveschappell",
  "in_reply_to_user_id_str" : "820661",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "97351788256165888",
  "text" : "I wonder how many times this water I'm drinking has been pee'd out by something in the history of the world?",
  "id" : 97351788256165888,
  "created_at" : "Sat Jul 30 17:04:09 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 134 ],
      "url" : "http://t.co/6RJqP59",
      "expanded_url" : "http://zenhabits.net/ignite/",
      "display_url" : "zenhabits.net/ignite/"
    } ]
  },
  "geo" : {
  },
  "id_str" : "97344829972955136",
  "text" : "\"Most people don\u2019t believe you can do work you love because they\u2019re constantly around people who hate their jobs.\" http://t.co/6RJqP59",
  "id" : 97344829972955136,
  "created_at" : "Sat Jul 30 16:36:30 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "23andMe",
      "screen_name" : "23andMe",
      "indices" : [ 46, 54 ],
      "id_str" : "14738561",
      "id" : 14738561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "97341914482868224",
  "text" : "Has anyone seen or heard of anyone taking the @23andme data and publishing it into interesting stats/charts/etc? Looking for inspiration.",
  "id" : 97341914482868224,
  "created_at" : "Sat Jul 30 16:24:55 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "97148932253167617",
  "text" : "8:36pm Kellianne is *very* excited about using FaceTime http://flic.kr/p/a8hz4f",
  "id" : 97148932253167617,
  "created_at" : "Sat Jul 30 03:38:05 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Budge",
      "screen_name" : "budge",
      "indices" : [ 0, 6 ],
      "id_str" : "286384512",
      "id" : 286384512
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "97042811026800641",
  "geo" : {
  },
  "id_str" : "97042985149140992",
  "in_reply_to_user_id" : 286384512,
  "text" : "@budge Yes please! I can barely touch my toes!",
  "id" : 97042985149140992,
  "in_reply_to_status_id" : 97042811026800641,
  "created_at" : "Fri Jul 29 20:37:05 +0000 2011",
  "in_reply_to_screen_name" : "budge",
  "in_reply_to_user_id_str" : "286384512",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Swizec",
      "screen_name" : "Swizec",
      "indices" : [ 0, 7 ],
      "id_str" : "15353121",
      "id" : 15353121
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "97018304723550208",
  "geo" : {
  },
  "id_str" : "97018427482451968",
  "in_reply_to_user_id" : 15353121,
  "text" : "@Swizec Haha, yes, most likely.  :)",
  "id" : 97018427482451968,
  "in_reply_to_status_id" : 97018304723550208,
  "created_at" : "Fri Jul 29 18:59:30 +0000 2011",
  "in_reply_to_screen_name" : "Swizec",
  "in_reply_to_user_id_str" : "15353121",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Slavin(public)",
      "screen_name" : "slavin_fpo",
      "indices" : [ 0, 11 ],
      "id_str" : "17561826",
      "id" : 17561826
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "96930716767625216",
  "geo" : {
  },
  "id_str" : "96995755285413890",
  "in_reply_to_user_id" : 17561826,
  "text" : "@slavin_fpo Your TED talk just blew my mind. Thanks for doing that.",
  "id" : 96995755285413890,
  "in_reply_to_status_id" : 96930716767625216,
  "created_at" : "Fri Jul 29 17:29:24 +0000 2011",
  "in_reply_to_screen_name" : "slavin_fpo",
  "in_reply_to_user_id_str" : "17561826",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Salinsky",
      "screen_name" : "AlexSalinsky",
      "indices" : [ 0, 13 ],
      "id_str" : "134531474",
      "id" : 134531474
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "96966703191302144",
  "geo" : {
  },
  "id_str" : "96986180272394241",
  "in_reply_to_user_id" : 134531474,
  "text" : "@AlexSalinsky Yes, several epiphanies that will be tied into a new project we're working on. Thank you so much for the help.",
  "id" : 96986180272394241,
  "in_reply_to_status_id" : 96966703191302144,
  "created_at" : "Fri Jul 29 16:51:21 +0000 2011",
  "in_reply_to_screen_name" : "AlexSalinsky",
  "in_reply_to_user_id_str" : "134531474",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.604833, -122.322334 ]
  },
  "id_str" : "96821791149932545",
  "text" : "8:36pm Was putting Niko to bed. Now pondering data models and being distracted by this new Miranda July clip http://flic.kr/p/a7ZZ22",
  "id" : 96821791149932545,
  "created_at" : "Fri Jul 29 05:58:08 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gamification",
      "indices" : [ 39, 52 ]
    }, {
      "text" : "healthmonth",
      "indices" : [ 77, 89 ]
    } ],
    "urls" : [ {
      "indices" : [ 54, 73 ],
      "url" : "http://t.co/ttDcp9v",
      "expanded_url" : "http://mashable.com/2011/07/28/gamification/",
      "display_url" : "mashable.com/2011/07/28/gam\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.61483645, -122.32597517 ]
  },
  "id_str" : "96774638549479424",
  "text" : "I love representing the \"good\" side of #gamification: http://t.co/ttDcp9v Go #healthmonth!",
  "id" : 96774638549479424,
  "created_at" : "Fri Jul 29 02:50:46 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Schappell",
      "screen_name" : "daveschappell",
      "indices" : [ 0, 14 ],
      "id_str" : "820661",
      "id" : 820661
    }, {
      "name" : "Jen S. McCabe",
      "screen_name" : "jensmccabe",
      "indices" : [ 26, 37 ],
      "id_str" : "14258044",
      "id" : 14258044
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "96661593567395840",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.60478365, -122.32293891 ]
  },
  "id_str" : "96665287914561536",
  "in_reply_to_user_id" : 820661,
  "text" : "@daveschappell Ha! Thanks @jensmccabe for outing me! Though, actually I was arguing for no light help since I always kept mine off. :)",
  "id" : 96665287914561536,
  "in_reply_to_status_id" : 96661593567395840,
  "created_at" : "Thu Jul 28 19:36:15 +0000 2011",
  "in_reply_to_screen_name" : "daveschappell",
  "in_reply_to_user_id_str" : "820661",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "about.me",
      "screen_name" : "aboutdotme",
      "indices" : [ 3, 14 ],
      "id_str" : "115304519",
      "id" : 115304519
    }, {
      "name" : "Andia Winslow",
      "screen_name" : "AndiaWinslow",
      "indices" : [ 37, 50 ],
      "id_str" : "58258969",
      "id" : 58258969
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "96601001963958272",
  "text" : "RT @aboutdotme: Awesome content from @AndiaWinslow at http://about.me/andiawinslow - videos, blog and more!",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andia Winslow",
        "screen_name" : "AndiaWinslow",
        "indices" : [ 21, 34 ],
        "id_str" : "58258969",
        "id" : 58258969
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "96599296119549953",
    "text" : "Awesome content from @AndiaWinslow at http://about.me/andiawinslow - videos, blog and more!",
    "id" : 96599296119549953,
    "created_at" : "Thu Jul 28 15:14:01 +0000 2011",
    "user" : {
      "name" : "about.me",
      "screen_name" : "aboutdotme",
      "protected" : false,
      "id_str" : "115304519",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3703853180/e94d47ffb829d0214779cb97cb62a3ff_normal.png",
      "id" : 115304519,
      "verified" : false
    }
  },
  "id" : 96601001963958272,
  "created_at" : "Thu Jul 28 15:20:48 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Habit Labs",
      "screen_name" : "habitlabs",
      "indices" : [ 22, 32 ],
      "id_str" : "250986038",
      "id" : 250986038
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.605, -122.3225 ]
  },
  "id_str" : "96445370908938240",
  "text" : "8:36pm Working on the @habitlabs new member manual. Getting to be all idealistic and loving it! http://flic.kr/p/a7Lxo7",
  "id" : 96445370908938240,
  "created_at" : "Thu Jul 28 05:02:22 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "hi koo girl",
      "screen_name" : "haikugirl",
      "indices" : [ 0, 10 ],
      "id_str" : "580262124",
      "id" : 580262124
    }, {
      "name" : "\u262E \u05D4\u05DC\u05DC",
      "screen_name" : "hillel",
      "indices" : [ 115, 122 ],
      "id_str" : "3640341",
      "id" : 3640341
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "96320618575826944",
  "geo" : {
  },
  "id_str" : "96320854828388352",
  "in_reply_to_user_id" : 12761252,
  "text" : "@haikugirl I've seen people get confused about Google as auth at this point. I use all on 750words.com though. /cc @hillel",
  "id" : 96320854828388352,
  "in_reply_to_status_id" : 96320618575826944,
  "created_at" : "Wed Jul 27 20:47:36 +0000 2011",
  "in_reply_to_screen_name" : "heatherquintal",
  "in_reply_to_user_id_str" : "12761252",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "hi koo girl",
      "screen_name" : "haikugirl",
      "indices" : [ 0, 10 ],
      "id_str" : "580262124",
      "id" : 580262124
    }, {
      "name" : "\u262E \u05D4\u05DC\u05DC",
      "screen_name" : "hillel",
      "indices" : [ 106, 113 ],
      "id_str" : "3640341",
      "id" : 3640341
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "96310881973055488",
  "geo" : {
  },
  "id_str" : "96320273254584320",
  "in_reply_to_user_id" : 3640341,
  "text" : "@haikugirl Downsides: Facebook Connect goes down, and people close those accounts and get locked out. /cc @hillel",
  "id" : 96320273254584320,
  "in_reply_to_status_id" : 96310881973055488,
  "created_at" : "Wed Jul 27 20:45:17 +0000 2011",
  "in_reply_to_screen_name" : "hillel",
  "in_reply_to_user_id_str" : "3640341",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "hi koo girl",
      "screen_name" : "haikugirl",
      "indices" : [ 0, 10 ],
      "id_str" : "580262124",
      "id" : 580262124
    }, {
      "name" : "\u262E \u05D4\u05DC\u05DC",
      "screen_name" : "hillel",
      "indices" : [ 129, 136 ],
      "id_str" : "3640341",
      "id" : 3640341
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "96310881973055488",
  "geo" : {
  },
  "id_str" : "96320023278256128",
  "in_reply_to_user_id" : 3640341,
  "text" : "@haikugirl You *can* get the email from the Facebook login if you ask for the right permission. I am pro-FB or Twitter-only. /cc @hillel",
  "id" : 96320023278256128,
  "in_reply_to_status_id" : 96310881973055488,
  "created_at" : "Wed Jul 27 20:44:17 +0000 2011",
  "in_reply_to_screen_name" : "hillel",
  "in_reply_to_user_id_str" : "3640341",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thor Muller",
      "screen_name" : "tempo",
      "indices" : [ 0, 6 ],
      "id_str" : "5814",
      "id" : 5814
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "96109516755709952",
  "geo" : {
  },
  "id_str" : "96110765324513280",
  "in_reply_to_user_id" : 5814,
  "text" : "@tempo Can't\u2026 breathe\u2026 go\u2026 back!\u2026 Save\u2026 yourself\u2026 oh wait, no it's fine, just a fish bone. Let's party!",
  "id" : 96110765324513280,
  "in_reply_to_status_id" : 96109516755709952,
  "created_at" : "Wed Jul 27 06:52:46 +0000 2011",
  "in_reply_to_screen_name" : "tempo",
  "in_reply_to_user_id_str" : "5814",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GitHub",
      "screen_name" : "github",
      "indices" : [ 44, 51 ],
      "id_str" : "13334762",
      "id" : 13334762
    }, {
      "name" : "Jen S. McCabe",
      "screen_name" : "jensmccabe",
      "indices" : [ 128, 139 ],
      "id_str" : "14258044",
      "id" : 14258044
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "96108660647927808",
  "text" : "Checking in company philosophy+axioms in to @github as \"company source code\" feels like the nerdy future I want to live in. /cc @jensmccabe",
  "id" : 96108660647927808,
  "created_at" : "Wed Jul 27 06:44:24 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "lia bulaong",
      "screen_name" : "lia",
      "indices" : [ 0, 4 ],
      "id_str" : "15484730",
      "id" : 15484730
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "96099961875333120",
  "geo" : {
  },
  "id_str" : "96106090013532160",
  "in_reply_to_user_id" : 15484730,
  "text" : "@lia I have 100s of Indonesian followers too who don't realize I'm not going to sponsor them on Health Month so they can get a 4sq badge. :)",
  "id" : 96106090013532160,
  "in_reply_to_status_id" : 96099961875333120,
  "created_at" : "Wed Jul 27 06:34:12 +0000 2011",
  "in_reply_to_screen_name" : "lia",
  "in_reply_to_user_id_str" : "15484730",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 32, 42 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.605, -122.322667 ]
  },
  "id_str" : "96063516427026432",
  "text" : "8:36pm Doing the happy dance as @Kellianne sets up her new MacBook Air! http://flic.kr/p/a7sXpJ",
  "id" : 96063516427026432,
  "created_at" : "Wed Jul 27 03:45:01 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.fitbit.com\" rel=\"nofollow\">Fitbit</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fitstats",
      "indices" : [ 21, 30 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "95992465802264576",
  "text" : "My avg. daily fitbit #fitstats for last week: 7,302 steps and 3.7 miles traveled. http://www.fitbit.com/user/229KX2",
  "id" : 95992465802264576,
  "created_at" : "Tue Jul 26 23:02:41 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tara Tiger Brown",
      "screen_name" : "tara",
      "indices" : [ 0, 5 ],
      "id_str" : "10959642",
      "id" : 10959642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "95936100920602624",
  "geo" : {
  },
  "id_str" : "95937142827655169",
  "in_reply_to_user_id" : 10959642,
  "text" : "@tara That's just part of the fun of having autonomy. Keep searching! Viva la search!",
  "id" : 95937142827655169,
  "in_reply_to_status_id" : 95936100920602624,
  "created_at" : "Tue Jul 26 19:22:51 +0000 2011",
  "in_reply_to_screen_name" : "tara",
  "in_reply_to_user_id_str" : "10959642",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tara Tiger Brown",
      "screen_name" : "tara",
      "indices" : [ 0, 5 ],
      "id_str" : "10959642",
      "id" : 10959642
    }, {
      "name" : "Derek Sivers",
      "screen_name" : "sivers",
      "indices" : [ 28, 35 ],
      "id_str" : "2206131",
      "id" : 2206131
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "95371118029971456",
  "geo" : {
  },
  "id_str" : "95932508700557313",
  "in_reply_to_user_id" : 10959642,
  "text" : "@tara Thank you! I'm a huge @sivers fan and just read his latest book, \"Anything You Want\". A must read.",
  "id" : 95932508700557313,
  "in_reply_to_status_id" : 95371118029971456,
  "created_at" : "Tue Jul 26 19:04:27 +0000 2011",
  "in_reply_to_screen_name" : "tara",
  "in_reply_to_user_id_str" : "10959642",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Riad Djemili",
      "screen_name" : "riadd",
      "indices" : [ 0, 6 ],
      "id_str" : "15610427",
      "id" : 15610427
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "95908492262649856",
  "geo" : {
  },
  "id_str" : "95929405775417344",
  "in_reply_to_user_id" : 15610427,
  "text" : "@riadd So true. I require at least a good 4 hour block to get anything meaningful done. Maybe mix up the work environment a bit?",
  "id" : 95929405775417344,
  "in_reply_to_status_id" : 95908492262649856,
  "created_at" : "Tue Jul 26 18:52:07 +0000 2011",
  "in_reply_to_screen_name" : "riadd",
  "in_reply_to_user_id_str" : "15610427",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenene",
      "screen_name" : "JeneneC",
      "indices" : [ 0, 8 ],
      "id_str" : "16272471",
      "id" : 16272471
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "95910916486471680",
  "geo" : {
  },
  "id_str" : "95929278885146624",
  "in_reply_to_user_id" : 16272471,
  "text" : "@JeneneC Meetings are definitely a best-work killer.  Can you get out of any of them? Or make them shorter?",
  "id" : 95929278885146624,
  "in_reply_to_status_id" : 95910916486471680,
  "created_at" : "Tue Jul 26 18:51:37 +0000 2011",
  "in_reply_to_screen_name" : "JeneneC",
  "in_reply_to_user_id_str" : "16272471",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Dean",
      "screen_name" : "dandean",
      "indices" : [ 0, 8 ],
      "id_str" : "9525212",
      "id" : 9525212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "95912776664481792",
  "geo" : {
  },
  "id_str" : "95929131367284736",
  "in_reply_to_user_id" : 9525212,
  "text" : "@dandean Oh man, yes. I feel your pain.",
  "id" : 95929131367284736,
  "in_reply_to_status_id" : 95912776664481792,
  "created_at" : "Tue Jul 26 18:51:01 +0000 2011",
  "in_reply_to_screen_name" : "dandean",
  "in_reply_to_user_id_str" : "9525212",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eden Mabee",
      "screen_name" : "Kymele",
      "indices" : [ 0, 7 ],
      "id_str" : "305079904",
      "id" : 305079904
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "95916433904635904",
  "geo" : {
  },
  "id_str" : "95928957798592512",
  "in_reply_to_user_id" : 305079904,
  "text" : "@Kymele That's one of the more difficult problems to solve. Maybe take a long walk?",
  "id" : 95928957798592512,
  "in_reply_to_status_id" : 95916433904635904,
  "created_at" : "Tue Jul 26 18:50:20 +0000 2011",
  "in_reply_to_screen_name" : "Kymele",
  "in_reply_to_user_id_str" : "305079904",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6051228585, -122.3226013854 ]
  },
  "id_str" : "95907606006206464",
  "text" : "Today, what would it take for you to do the best work you've ever done?",
  "id" : 95907606006206464,
  "created_at" : "Tue Jul 26 17:25:29 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ron Diver",
      "screen_name" : "rondiver",
      "indices" : [ 0, 9 ],
      "id_str" : "12661782",
      "id" : 12661782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "95719762046357505",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6051228585, -122.3226013854 ]
  },
  "id_str" : "95719948294426625",
  "in_reply_to_user_id" : 12661782,
  "text" : "@rondiver To cult follower? 3.4%",
  "id" : 95719948294426625,
  "in_reply_to_status_id" : 95719762046357505,
  "created_at" : "Tue Jul 26 04:59:48 +0000 2011",
  "in_reply_to_screen_name" : "rondiver",
  "in_reply_to_user_id_str" : "12661782",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sommar",
      "screen_name" : "Sommar",
      "indices" : [ 0, 7 ],
      "id_str" : "80323",
      "id" : 80323
    }, {
      "name" : "about.me",
      "screen_name" : "aboutdotme",
      "indices" : [ 79, 90 ],
      "id_str" : "115304519",
      "id" : 115304519
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "95707571373096960",
  "geo" : {
  },
  "id_str" : "95709838507651072",
  "in_reply_to_user_id" : 80323,
  "text" : "@Sommar Thank you! I wish you could reserve your \"visitor #\" forever. :) \n\nPS. @aboutdotme, a way to find friends pages would be awesome.",
  "id" : 95709838507651072,
  "in_reply_to_status_id" : 95707571373096960,
  "created_at" : "Tue Jul 26 04:19:38 +0000 2011",
  "in_reply_to_screen_name" : "Sommar",
  "in_reply_to_user_id_str" : "80323",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "about.me",
      "screen_name" : "aboutdotme",
      "indices" : [ 0, 11 ],
      "id_str" : "115304519",
      "id" : 115304519
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "95706028884230144",
  "geo" : {
  },
  "id_str" : "95706648135479296",
  "in_reply_to_user_id" : 115304519,
  "text" : "@aboutdotme True. I guess it doesn't quite trump my personal homepage\u2026 yet. :)",
  "id" : 95706648135479296,
  "in_reply_to_status_id" : 95706028884230144,
  "created_at" : "Tue Jul 26 04:06:57 +0000 2011",
  "in_reply_to_screen_name" : "aboutdotme",
  "in_reply_to_user_id_str" : "115304519",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niko Benson",
      "screen_name" : "nikobenson",
      "indices" : [ 15, 26 ],
      "id_str" : "142467448",
      "id" : 142467448
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.605, -122.322834 ]
  },
  "id_str" : "95700520982949888",
  "text" : "8:36pm Calming @nikobenson down after an exciting last minute photo shoot http://flic.kr/p/a76Wcp",
  "id" : 95700520982949888,
  "created_at" : "Tue Jul 26 03:42:36 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Uber Seattle",
      "screen_name" : "Uber_Seattle",
      "indices" : [ 22, 35 ],
      "id_str" : "318316365",
      "id" : 318316365
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.5753218731, -122.3133917418 ]
  },
  "id_str" : "95649689185165312",
  "text" : "Super stoked to catch @uber_seattle during a secret test today. Best cab experience ever! Especially with a baby in the rain.",
  "id" : 95649689185165312,
  "created_at" : "Tue Jul 26 00:20:37 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "95592655458811904",
  "text" : "@GoalsGamified That's awesome! Do you find any patterns on days that you stay up later?\n\nMy walking habit is going strong. Sunny days help!",
  "id" : 95592655458811904,
  "created_at" : "Mon Jul 25 20:33:59 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "rands",
      "screen_name" : "rands",
      "indices" : [ 3, 9 ],
      "id_str" : "30923",
      "id" : 30923
    }, {
      "name" : "Jim Coudal",
      "screen_name" : "Coudal",
      "indices" : [ 67, 74 ],
      "id_str" : "1008591",
      "id" : 1008591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 65 ],
      "url" : "http://t.co/9rWZGGx",
      "expanded_url" : "http://j.mp/qBixFh",
      "display_url" : "j.mp/qBixFh"
    } ]
  },
  "geo" : {
  },
  "id_str" : "95584463324577792",
  "text" : "RT @rands: Before and after shots of joggers: http://t.co/9rWZGGx (@coudal)",
  "retweeted_status" : {
    "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jim Coudal",
        "screen_name" : "Coudal",
        "indices" : [ 56, 63 ],
        "id_str" : "1008591",
        "id" : 1008591
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 35, 54 ],
        "url" : "http://t.co/9rWZGGx",
        "expanded_url" : "http://j.mp/qBixFh",
        "display_url" : "j.mp/qBixFh"
      } ]
    },
    "geo" : {
    },
    "id_str" : "95575811058442240",
    "text" : "Before and after shots of joggers: http://t.co/9rWZGGx (@coudal)",
    "id" : 95575811058442240,
    "created_at" : "Mon Jul 25 19:27:03 +0000 2011",
    "user" : {
      "name" : "rands",
      "screen_name" : "rands",
      "protected" : false,
      "id_str" : "30923",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2886028302/d9137f9df14bafdb1144d6b6c16259c1_normal.png",
      "id" : 30923,
      "verified" : false
    }
  },
  "id" : 95584463324577792,
  "created_at" : "Mon Jul 25 20:01:26 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Salinsky",
      "screen_name" : "AlexSalinsky",
      "indices" : [ 0, 13 ],
      "id_str" : "134531474",
      "id" : 134531474
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "91144674697412608",
  "geo" : {
  },
  "id_str" : "95572507733655552",
  "in_reply_to_user_id" : 134531474,
  "text" : "@AlexSalinsky Just checking in on you and the side project. Have you been able to find time to work on it the last week or so?",
  "id" : 95572507733655552,
  "in_reply_to_status_id" : 91144674697412608,
  "created_at" : "Mon Jul 25 19:13:56 +0000 2011",
  "in_reply_to_screen_name" : "AlexSalinsky",
  "in_reply_to_user_id_str" : "134531474",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "95572199108386816",
  "text" : "@GoalsGamified How's that bedtime habit holding up?",
  "id" : 95572199108386816,
  "created_at" : "Mon Jul 25 19:12:42 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "katrina panovich",
      "screen_name" : "katrina_",
      "indices" : [ 0, 9 ],
      "id_str" : "9381242",
      "id" : 9381242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "91235783423438848",
  "geo" : {
  },
  "id_str" : "95572015490150400",
  "in_reply_to_user_id" : 9381242,
  "text" : "@katrina_ Checking in to see if you've been able to get any yoga in this last week or so.",
  "id" : 95572015490150400,
  "in_reply_to_status_id" : 91235783423438848,
  "created_at" : "Mon Jul 25 19:11:58 +0000 2011",
  "in_reply_to_screen_name" : "katrina_",
  "in_reply_to_user_id_str" : "9381242",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carrie-Anne Gallo",
      "screen_name" : "CazMinx",
      "indices" : [ 0, 8 ],
      "id_str" : "20905374",
      "id" : 20905374
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "89959484759351296",
  "geo" : {
  },
  "id_str" : "95571522965602304",
  "in_reply_to_user_id" : 20905374,
  "text" : "@CazMinx Checking in to see if you've been able to get on that treadmill lately. Any progress? Back to sitting in front of the heater? :)",
  "id" : 95571522965602304,
  "in_reply_to_status_id" : 89959484759351296,
  "created_at" : "Mon Jul 25 19:10:01 +0000 2011",
  "in_reply_to_screen_name" : "CazMinx",
  "in_reply_to_user_id_str" : "20905374",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Oliver",
      "screen_name" : "MikeOliver",
      "indices" : [ 0, 11 ],
      "id_str" : "993801636",
      "id" : 993801636
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "91115377320407040",
  "geo" : {
  },
  "id_str" : "95571144966537217",
  "in_reply_to_user_id" : 12866,
  "text" : "@mikeoliver How's the coffee-drinking going?  Still making progress?  Need more reminders? :)",
  "id" : 95571144966537217,
  "in_reply_to_status_id" : 91115377320407040,
  "created_at" : "Mon Jul 25 19:08:31 +0000 2011",
  "in_reply_to_screen_name" : "mkolvr",
  "in_reply_to_user_id_str" : "12866",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mozart",
      "screen_name" : "mgspeaks",
      "indices" : [ 0, 9 ],
      "id_str" : "217657761",
      "id" : 217657761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "89868587203952640",
  "geo" : {
  },
  "id_str" : "95570929274470400",
  "in_reply_to_user_id" : 217657761,
  "text" : "@mgspeaks Just checking in after a week and a half to see how the nirvanaHQ and basecamp work is going. Any progress to report?",
  "id" : 95570929274470400,
  "in_reply_to_status_id" : 89868587203952640,
  "created_at" : "Mon Jul 25 19:07:39 +0000 2011",
  "in_reply_to_screen_name" : "mgspeaks",
  "in_reply_to_user_id_str" : "217657761",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rafael Regales",
      "screen_name" : "bmorerican",
      "indices" : [ 0, 11 ],
      "id_str" : "23912695",
      "id" : 23912695
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "90940977354780672",
  "geo" : {
  },
  "id_str" : "95569777099145216",
  "in_reply_to_user_id" : 23912695,
  "text" : "@bmorerican Hi! Just checking in after a week and a half to see if you've been able to hop on that ol' stationary bike at all.",
  "id" : 95569777099145216,
  "in_reply_to_status_id" : 90940977354780672,
  "created_at" : "Mon Jul 25 19:03:05 +0000 2011",
  "in_reply_to_screen_name" : "bmorerican",
  "in_reply_to_user_id_str" : "23912695",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jackie ",
      "screen_name" : "PatchworkJackie",
      "indices" : [ 0, 16 ],
      "id_str" : "241515860",
      "id" : 241515860
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "91485072858955776",
  "geo" : {
  },
  "id_str" : "95569370557853696",
  "in_reply_to_user_id" : 241515860,
  "text" : "@PatchworkJackie Hello! Just checking in to see how your soda drinking is holding up 1.5 weeks after we last spoke. Any progress?",
  "id" : 95569370557853696,
  "in_reply_to_status_id" : 91485072858955776,
  "created_at" : "Mon Jul 25 19:01:28 +0000 2011",
  "in_reply_to_screen_name" : "PatchworkJackie",
  "in_reply_to_user_id_str" : "241515860",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Skotzko",
      "screen_name" : "askotzko",
      "indices" : [ 0, 9 ],
      "id_str" : "15391002",
      "id" : 15391002
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "91323698086281216",
  "geo" : {
  },
  "id_str" : "95569077715738624",
  "in_reply_to_user_id" : 15391002,
  "text" : "@askotzko Hey there. Just checking in to see how meditation went the last 1.5 weeks. How many times did you find time to do it?",
  "id" : 95569077715738624,
  "in_reply_to_status_id" : 91323698086281216,
  "created_at" : "Mon Jul 25 19:00:18 +0000 2011",
  "in_reply_to_screen_name" : "askotzko",
  "in_reply_to_user_id_str" : "15391002",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.605166, -122.322667 ]
  },
  "id_str" : "95345125315715072",
  "text" : "8:36pm An evening with Charlotte! http://flic.kr/p/a6PBUs",
  "id" : 95345125315715072,
  "created_at" : "Mon Jul 25 04:10:23 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kingsley Marshall",
      "screen_name" : "kingsleydc",
      "indices" : [ 0, 11 ],
      "id_str" : "41832398",
      "id" : 41832398
    }, {
      "name" : "Laurence Eastment",
      "screen_name" : "LaurenceEast",
      "indices" : [ 12, 25 ],
      "id_str" : "120473102",
      "id" : 120473102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "95167292299677696",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.605009957, -122.322809457 ]
  },
  "id_str" : "95323035778822144",
  "in_reply_to_user_id" : 41832398,
  "text" : "@kingsleydc @laurenceeast Ha! Thank you, I think.",
  "id" : 95323035778822144,
  "in_reply_to_status_id" : 95167292299677696,
  "created_at" : "Mon Jul 25 02:42:37 +0000 2011",
  "in_reply_to_screen_name" : "kingsleydc",
  "in_reply_to_user_id_str" : "41832398",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Neilson",
      "screen_name" : "TheCulprit",
      "indices" : [ 3, 14 ],
      "id_str" : "6726182",
      "id" : 6726182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "95179812137746432",
  "text" : "RT @TheCulprit: Some numbers, like the US debt, are SO big that they need to be pictures. Warning: May cause depression. http://www.wtfn ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "95178657135468544",
    "text" : "Some numbers, like the US debt, are SO big that they need to be pictures. Warning: May cause depression. http://www.wtfnoway.com/",
    "id" : 95178657135468544,
    "created_at" : "Sun Jul 24 17:08:54 +0000 2011",
    "user" : {
      "name" : "Scott Neilson",
      "screen_name" : "TheCulprit",
      "protected" : false,
      "id_str" : "6726182",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2163966743/Scott_Neilson_headshot_128x128_normal.jpg",
      "id" : 6726182,
      "verified" : false
    }
  },
  "id" : 95179812137746432,
  "created_at" : "Sun Jul 24 17:13:30 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lynn Collette",
      "screen_name" : "sfposhy",
      "indices" : [ 0, 8 ],
      "id_str" : "268453413",
      "id" : 268453413
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "95143644142637056",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.60680079, -122.32304209 ]
  },
  "id_str" : "95160517089427456",
  "in_reply_to_user_id" : 268453413,
  "text" : "@sfposhy Hey that's where I grew up. I get more culture shock from going there than anywhere else in the world. It's a weird weird place.",
  "id" : 95160517089427456,
  "in_reply_to_status_id" : 95143644142637056,
  "created_at" : "Sun Jul 24 15:56:49 +0000 2011",
  "in_reply_to_screen_name" : "sfposhy",
  "in_reply_to_user_id_str" : "268453413",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charlotte Maberly",
      "screen_name" : "CMaberly",
      "indices" : [ 0, 9 ],
      "id_str" : "128375612",
      "id" : 128375612
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "95009006069878785",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6058632976, -122.3247778995 ]
  },
  "id_str" : "95019348103659520",
  "in_reply_to_user_id" : 128375612,
  "text" : "@CMaberly Yay! What's his name, how heavy, et cetera! Congrats!",
  "id" : 95019348103659520,
  "in_reply_to_status_id" : 95009006069878785,
  "created_at" : "Sun Jul 24 06:35:52 +0000 2011",
  "in_reply_to_screen_name" : "CMaberly",
  "in_reply_to_user_id_str" : "128375612",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.605833, -122.324834 ]
  },
  "id_str" : "94976558414041088",
  "text" : "8:36pm On my way to meet Scott http://flic.kr/p/a6qejR",
  "id" : 94976558414041088,
  "created_at" : "Sun Jul 24 03:45:50 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Budge Testing",
      "screen_name" : "busterbudge",
      "indices" : [ 0, 12 ],
      "id_str" : "287508962",
      "id" : 287508962
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "94853185948237825",
  "geo" : {
  },
  "id_str" : "94853578853842944",
  "in_reply_to_user_id" : 287508962,
  "text" : "@busterbudge Not bad! Not bad at all!",
  "id" : 94853578853842944,
  "in_reply_to_status_id" : 94853185948237825,
  "created_at" : "Sat Jul 23 19:37:10 +0000 2011",
  "in_reply_to_screen_name" : "busterbudge",
  "in_reply_to_user_id_str" : "287508962",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Davis",
      "screen_name" : "lawrencekslive",
      "indices" : [ 0, 15 ],
      "id_str" : "810644",
      "id" : 810644
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "94809183001653249",
  "geo" : {
  },
  "id_str" : "94826061069692929",
  "in_reply_to_user_id" : 120282027,
  "text" : "@lawrencekslive Cool, thanks for the tip! And for the kind words!",
  "id" : 94826061069692929,
  "in_reply_to_status_id" : 94809183001653249,
  "created_at" : "Sat Jul 23 17:47:49 +0000 2011",
  "in_reply_to_screen_name" : "JoshD",
  "in_reply_to_user_id_str" : "120282027",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Klout",
      "screen_name" : "klout",
      "indices" : [ 0, 6 ],
      "id_str" : "15134782",
      "id" : 15134782
    }, {
      "name" : "Spotify",
      "screen_name" : "Spotify",
      "indices" : [ 36, 44 ],
      "id_str" : "17230018",
      "id" : 17230018
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "94808288402735104",
  "in_reply_to_user_id" : 15134782,
  "text" : "@klout When trying to claim my free @Spotify account, it always says \"You've already received the maximum allowed qty of this item\" Ideas?",
  "id" : 94808288402735104,
  "created_at" : "Sat Jul 23 16:37:12 +0000 2011",
  "in_reply_to_screen_name" : "klout",
  "in_reply_to_user_id_str" : "15134782",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 3, 13 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6050734027, -122.3226251586 ]
  },
  "id_str" : "94691155970756608",
  "text" : "RT @kellianne: I just watched several takes of a pivotal movie scene through my door's peep hole.  Excited that my front door is in a film!",
  "id" : 94691155970756608,
  "created_at" : "Sat Jul 23 08:51:45 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "94677444031823872",
  "text" : "Home sweet movie set  @ The Broadmore http://instagr.am/p/ITHy0/",
  "id" : 94677444031823872,
  "created_at" : "Sat Jul 23 07:57:16 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Foursquare",
      "screen_name" : "foursquare",
      "indices" : [ 38, 49 ],
      "id_str" : "14120151",
      "id" : 14120151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "94619695449260032",
  "text" : "I just unlocked the \"Foodie\" badge on @foursquare! http://4sq.com/nwXTNW",
  "id" : 94619695449260032,
  "created_at" : "Sat Jul 23 04:07:48 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.606, -122.3235 ]
  },
  "id_str" : "94612409418924032",
  "text" : "8:36pm Date night! What's happening later on y'all? Our sitter wants us to stay out late! http://flic.kr/p/a69LvD",
  "id" : 94612409418924032,
  "created_at" : "Sat Jul 23 03:38:50 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6170123598, -122.319116592 ]
  },
  "id_str" : "94534194658684929",
  "text" : "Perfect park day  @ Cal Anderson Park http://instagr.am/p/IQ6dU/",
  "id" : 94534194658684929,
  "created_at" : "Fri Jul 22 22:28:03 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Foursquare",
      "screen_name" : "foursquare",
      "indices" : [ 45, 56 ],
      "id_str" : "14120151",
      "id" : 14120151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "94530103064793088",
  "text" : "I just unlocked the \"excELLENt fan\" badge on @foursquare! http://4sq.com/rcwSK7",
  "id" : 94530103064793088,
  "created_at" : "Fri Jul 22 22:11:47 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Galen Ward",
      "screen_name" : "galenward",
      "indices" : [ 0, 10 ],
      "id_str" : "2854761",
      "id" : 2854761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "94488438165864448",
  "geo" : {
  },
  "id_str" : "94489376746242048",
  "in_reply_to_user_id" : 2854761,
  "text" : "@galenward Wow, perfect timing with that link. Thanks!",
  "id" : 94489376746242048,
  "in_reply_to_status_id" : 94488438165864448,
  "created_at" : "Fri Jul 22 19:29:57 +0000 2011",
  "in_reply_to_screen_name" : "galenward",
  "in_reply_to_user_id_str" : "2854761",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aubrey Sabala",
      "screen_name" : "Aubs",
      "indices" : [ 0, 5 ],
      "id_str" : "2781",
      "id" : 2781
    }, {
      "name" : "daisy barringer",
      "screen_name" : "daisy",
      "indices" : [ 6, 12 ],
      "id_str" : "7390862",
      "id" : 7390862
    }, {
      "name" : "BodyMedia",
      "screen_name" : "BodyMedia",
      "indices" : [ 121, 131 ],
      "id_str" : "50522496",
      "id" : 50522496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "94463387819450368",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6050196418, -122.3232063161 ]
  },
  "id_str" : "94473490937282560",
  "in_reply_to_user_id" : 2781,
  "text" : "@Aubs @daisy Okay that review cracked me up. I can't believe the review didn't have sex stats though. PS I want one. /cc @bodymedia",
  "id" : 94473490937282560,
  "in_reply_to_status_id" : 94463387819450368,
  "created_at" : "Fri Jul 22 18:26:50 +0000 2011",
  "in_reply_to_screen_name" : "Aubs",
  "in_reply_to_user_id_str" : "2781",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "k.",
      "screen_name" : "kstar",
      "indices" : [ 0, 6 ],
      "id_str" : "2038",
      "id" : 2038
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "94305784086802433",
  "geo" : {
  },
  "id_str" : "94306072000598016",
  "in_reply_to_user_id" : 2038,
  "text" : "@kstar Yes! Or at least tell us your anonymous pen name.",
  "id" : 94306072000598016,
  "in_reply_to_status_id" : 94305784086802433,
  "created_at" : "Fri Jul 22 07:21:34 +0000 2011",
  "in_reply_to_screen_name" : "kstar",
  "in_reply_to_user_id_str" : "2038",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Geidt",
      "screen_name" : "austingeidt",
      "indices" : [ 0, 12 ],
      "id_str" : "18745330",
      "id" : 18745330
    }, {
      "name" : "Uber Seattle",
      "screen_name" : "Uber_Seattle",
      "indices" : [ 64, 77 ],
      "id_str" : "318316365",
      "id" : 318316365
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "94305504578383872",
  "in_reply_to_user_id" : 18745330,
  "text" : "@austingeidt I've had your song stuck in my head all night! /cc @uber_seattle",
  "id" : 94305504578383872,
  "created_at" : "Fri Jul 22 07:19:19 +0000 2011",
  "in_reply_to_screen_name" : "austingeidt",
  "in_reply_to_user_id_str" : "18745330",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tara Tiger Brown",
      "screen_name" : "tara",
      "indices" : [ 0, 5 ],
      "id_str" : "10959642",
      "id" : 10959642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "94265218825330689",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6050621778, -122.3226380094 ]
  },
  "id_str" : "94270322756423681",
  "in_reply_to_user_id" : 10959642,
  "text" : "@tara That's why I love blogs. Very few places in the world allow you to have your entire say, and then let others have their entire says.",
  "id" : 94270322756423681,
  "in_reply_to_status_id" : 94265218825330689,
  "created_at" : "Fri Jul 22 04:59:31 +0000 2011",
  "in_reply_to_screen_name" : "tara",
  "in_reply_to_user_id_str" : "10959642",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.604833, -122.321667 ]
  },
  "id_str" : "94250320913375232",
  "text" : "8:36pm A good day! And now I read this entertaining post-modern comic about comics while my subconscious mulls http://flic.kr/p/a5TZdi",
  "id" : 94250320913375232,
  "created_at" : "Fri Jul 22 03:40:02 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ron Diver",
      "screen_name" : "rondiver",
      "indices" : [ 123, 132 ],
      "id_str" : "12661782",
      "id" : 12661782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 117 ],
      "url" : "http://t.co/8GPm98P",
      "expanded_url" : "http://venturehacks.com/articles/passion-market",
      "display_url" : "venturehacks.com/articles/passi\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "94091047851925504",
  "text" : "\"The best companies are the ones where the product is an extension of the founders' personality.\" http://t.co/8GPm98P /via @rondiver",
  "id" : 94091047851925504,
  "created_at" : "Thu Jul 21 17:07:08 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.614333, -122.318834 ]
  },
  "id_str" : "93888335394779138",
  "text" : "8:36pm Late family dinner at Quinn's http://flic.kr/p/a5F1um",
  "id" : 93888335394779138,
  "created_at" : "Thu Jul 21 03:41:38 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Neville",
      "screen_name" : "thinksomandy",
      "indices" : [ 0, 13 ],
      "id_str" : "453577645",
      "id" : 453577645
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "93783449223180288",
  "geo" : {
  },
  "id_str" : "93786068603772928",
  "in_reply_to_user_id" : 16572103,
  "text" : "@thinksomandy Thank you! And yes, as I suspected, it is good to hear. :)",
  "id" : 93786068603772928,
  "in_reply_to_status_id" : 93783449223180288,
  "created_at" : "Wed Jul 20 20:55:15 +0000 2011",
  "in_reply_to_screen_name" : "furiouslymandy",
  "in_reply_to_user_id_str" : "16572103",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "April Schiller",
      "screen_name" : "the_april",
      "indices" : [ 0, 10 ],
      "id_str" : "16644937",
      "id" : 16644937
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "93779424012550145",
  "geo" : {
  },
  "id_str" : "93780006475534336",
  "in_reply_to_user_id" : 16644937,
  "text" : "@the_april You CAN make big change happen, I know it!",
  "id" : 93780006475534336,
  "in_reply_to_status_id" : 93779424012550145,
  "created_at" : "Wed Jul 20 20:31:10 +0000 2011",
  "in_reply_to_screen_name" : "the_april",
  "in_reply_to_user_id_str" : "16644937",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "maggim",
      "screen_name" : "maggim",
      "indices" : [ 0, 7 ],
      "id_str" : "14290242",
      "id" : 14290242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "93777098220650496",
  "geo" : {
  },
  "id_str" : "93779937600876544",
  "in_reply_to_user_id" : 14290242,
  "text" : "@maggim It WILL get better.",
  "id" : 93779937600876544,
  "in_reply_to_status_id" : 93777098220650496,
  "created_at" : "Wed Jul 20 20:30:54 +0000 2011",
  "in_reply_to_screen_name" : "maggim",
  "in_reply_to_user_id_str" : "14290242",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amelia Greenhall",
      "screen_name" : "ameliagreenhall",
      "indices" : [ 0, 16 ],
      "id_str" : "246531241",
      "id" : 246531241
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "93710911860248576",
  "geo" : {
  },
  "id_str" : "93777207234797568",
  "in_reply_to_user_id" : 246531241,
  "text" : "@ameliagreenhall I haven't heard of Pokey before! Listening now, and it's quite enjoyable. Thank you. How was the show?",
  "id" : 93777207234797568,
  "in_reply_to_status_id" : 93710911860248576,
  "created_at" : "Wed Jul 20 20:20:03 +0000 2011",
  "in_reply_to_screen_name" : "ameliagreenhall",
  "in_reply_to_user_id_str" : "246531241",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fred Oliveira",
      "screen_name" : "f",
      "indices" : [ 0, 2 ],
      "id_str" : "5511",
      "id" : 5511
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "93776087464673280",
  "geo" : {
  },
  "id_str" : "93776991555305473",
  "in_reply_to_user_id" : 5511,
  "text" : "@f Thanks! It got me thinking too. :) Strange to think about how long we go through life trying to hear certain words.",
  "id" : 93776991555305473,
  "in_reply_to_status_id" : 93776087464673280,
  "created_at" : "Wed Jul 20 20:19:11 +0000 2011",
  "in_reply_to_screen_name" : "f",
  "in_reply_to_user_id_str" : "5511",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "93775542255501312",
  "text" : "What do you most need to hear right now?",
  "id" : 93775542255501312,
  "created_at" : "Wed Jul 20 20:13:26 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vijayendra Mohanty",
      "screen_name" : "vimoh",
      "indices" : [ 0, 6 ],
      "id_str" : "3336",
      "id" : 3336
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "93772846102360064",
  "geo" : {
  },
  "id_str" : "93773711139811329",
  "in_reply_to_user_id" : 3336,
  "text" : "@vimoh You're very welcome! How did you discover it?",
  "id" : 93773711139811329,
  "in_reply_to_status_id" : 93772846102360064,
  "created_at" : "Wed Jul 20 20:06:09 +0000 2011",
  "in_reply_to_screen_name" : "vimoh",
  "in_reply_to_user_id_str" : "3336",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ingopixel",
      "screen_name" : "ingopixel",
      "indices" : [ 0, 10 ],
      "id_str" : "7943892",
      "id" : 7943892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "93569042308284416",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6049651729, -122.3228348365 ]
  },
  "id_str" : "93569963524235264",
  "in_reply_to_user_id" : 7943892,
  "text" : "@ingopixel I have no problem going into epiphany debt. My epiphany credit card has good interest! Always gets me through the holidays.",
  "id" : 93569963524235264,
  "in_reply_to_status_id" : 93569042308284416,
  "created_at" : "Wed Jul 20 06:36:32 +0000 2011",
  "in_reply_to_screen_name" : "ingopixel",
  "in_reply_to_user_id_str" : "7943892",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.605468642, -122.3228347563 ]
  },
  "id_str" : "93561711696674817",
  "text" : "The thing I am working on has been dealing out epiphanies quite liberally these last couple months. Life is beautiful (and cheesy).",
  "id" : 93561711696674817,
  "created_at" : "Wed Jul 20 06:03:45 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.618166, -122.3475 ]
  },
  "id_str" : "93525791874363393",
  "text" : "8:36pm Just got some food, heading back to office http://flic.kr/p/a5kpPD",
  "id" : 93525791874363393,
  "created_at" : "Wed Jul 20 03:41:01 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DocMara",
      "screen_name" : "DocMara",
      "indices" : [ 0, 8 ],
      "id_str" : "12830942",
      "id" : 12830942
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "93517229982887936",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6182051238, -122.3475338352 ]
  },
  "id_str" : "93518819515052032",
  "in_reply_to_user_id" : 12830942,
  "text" : "@DocMara Straight up. And probably wrong. :)",
  "id" : 93518819515052032,
  "in_reply_to_status_id" : 93517229982887936,
  "created_at" : "Wed Jul 20 03:13:18 +0000 2011",
  "in_reply_to_screen_name" : "DocMara",
  "in_reply_to_user_id_str" : "12830942",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andres Moran",
      "screen_name" : "DreMoran",
      "indices" : [ 0, 9 ],
      "id_str" : "8461972",
      "id" : 8461972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "93518021854904321",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6182051238, -122.3475338352 ]
  },
  "id_str" : "93518711813718016",
  "in_reply_to_user_id" : 8461972,
  "text" : "@DreMoran So true. And we have a 5% chance of succeeding at that. Is it possible to increase odds in any way?",
  "id" : 93518711813718016,
  "in_reply_to_status_id" : 93518021854904321,
  "created_at" : "Wed Jul 20 03:12:53 +0000 2011",
  "in_reply_to_screen_name" : "DreMoran",
  "in_reply_to_user_id_str" : "8461972",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "93515877785407488",
  "text" : "95% of advice from others is irrelevant. It might be right/wrong, but just by chance. Including this: Make your own advice and stick to it.",
  "id" : 93515877785407488,
  "created_at" : "Wed Jul 20 03:01:37 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.fitbit.com\" rel=\"nofollow\">Fitbit</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fitstats",
      "indices" : [ 21, 30 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "93455762080276480",
  "text" : "My avg. daily fitbit #fitstats for last week: 6,139 steps and 3 miles traveled. http://www.fitbit.com/user/229KX2",
  "id" : 93455762080276480,
  "created_at" : "Tue Jul 19 23:02:44 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sara Jensen",
      "screen_name" : "sarajensen",
      "indices" : [ 3, 14 ],
      "id_str" : "22135588",
      "id" : 22135588
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "93369364664950784",
  "text" : "RT @sarajensen: Mama said there'd be days like this. http://bit.ly/qRKvD5",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.typepad.com/\" rel=\"nofollow\">TypePad</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "93344246400159744",
    "text" : "Mama said there'd be days like this. http://bit.ly/qRKvD5",
    "id" : 93344246400159744,
    "created_at" : "Tue Jul 19 15:39:37 +0000 2011",
    "user" : {
      "name" : "Sara Jensen",
      "screen_name" : "sarajensen",
      "protected" : false,
      "id_str" : "22135588",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3394787864/a5f316bc68153b4e451509d74a1740fe_normal.jpeg",
      "id" : 22135588,
      "verified" : false
    }
  },
  "id" : 93369364664950784,
  "created_at" : "Tue Jul 19 17:19:25 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sara Jensen",
      "screen_name" : "sarajensen",
      "indices" : [ 0, 11 ],
      "id_str" : "22135588",
      "id" : 22135588
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "93344246400159744",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6065545, -122.32318133 ]
  },
  "id_str" : "93353549265764352",
  "in_reply_to_user_id" : 22135588,
  "text" : "@sarajensen Oh my. Heartbreaking and lovely and awe-inspiring how you tell it. She's so lucky to have you.",
  "id" : 93353549265764352,
  "in_reply_to_status_id" : 93344246400159744,
  "created_at" : "Tue Jul 19 16:16:35 +0000 2011",
  "in_reply_to_screen_name" : "sarajensen",
  "in_reply_to_user_id_str" : "22135588",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tara Tiger Brown",
      "screen_name" : "tara",
      "indices" : [ 0, 5 ],
      "id_str" : "10959642",
      "id" : 10959642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "93208381212463105",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.60708063, -122.32305759 ]
  },
  "id_str" : "93215419023896576",
  "in_reply_to_user_id" : 10959642,
  "text" : "@tara It's difficult to be original these days. But worth it!",
  "id" : 93215419023896576,
  "in_reply_to_status_id" : 93208381212463105,
  "created_at" : "Tue Jul 19 07:07:42 +0000 2011",
  "in_reply_to_screen_name" : "tara",
  "in_reply_to_user_id_str" : "10959642",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Garry Tan",
      "screen_name" : "garrytan",
      "indices" : [ 3, 12 ],
      "id_str" : "11768582",
      "id" : 11768582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "93201506358132736",
  "text" : "RT @garrytan: You are not running out of time http://rahulbijlani.com/essays/you-are-not-running-out-of-time-essay/",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Tweetie for Mac</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "93187722704994304",
    "text" : "You are not running out of time http://rahulbijlani.com/essays/you-are-not-running-out-of-time-essay/",
    "id" : 93187722704994304,
    "created_at" : "Tue Jul 19 05:17:39 +0000 2011",
    "user" : {
      "name" : "Garry Tan",
      "screen_name" : "garrytan",
      "protected" : false,
      "id_str" : "11768582",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2673975033/965a165a093e7c0921b9d69d5d99bc41_normal.jpeg",
      "id" : 11768582,
      "verified" : false
    }
  },
  "id" : 93201506358132736,
  "created_at" : "Tue Jul 19 06:12:25 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tara Tiger Brown",
      "screen_name" : "tara",
      "indices" : [ 0, 5 ],
      "id_str" : "10959642",
      "id" : 10959642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 81 ],
      "url" : "http://t.co/Vs0CgGb",
      "expanded_url" : "http://habitlabs.com",
      "display_url" : "habitlabs.com"
    } ]
  },
  "in_reply_to_status_id_str" : "93188519467565056",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6050392583, -122.3225624658 ]
  },
  "id_str" : "93201213834801153",
  "in_reply_to_user_id" : 10959642,
  "text" : "@tara Not us! Ours sorta sucks, but is functional minimalist: http://t.co/Vs0CgGb",
  "id" : 93201213834801153,
  "in_reply_to_status_id" : 93188519467565056,
  "created_at" : "Tue Jul 19 06:11:15 +0000 2011",
  "in_reply_to_screen_name" : "tara",
  "in_reply_to_user_id_str" : "10959642",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ario Jafarzadeh",
      "screen_name" : "ario",
      "indices" : [ 62, 67 ],
      "id_str" : "294",
      "id" : 294
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 50 ],
      "url" : "http://t.co/JXowrGz",
      "expanded_url" : "http://vimeo.com/24715531",
      "display_url" : "vimeo.com/24715531"
    } ]
  },
  "geo" : {
  },
  "id_str" : "93182405896179715",
  "text" : "Words of wisdom from Ira Glass http://t.co/JXowrGz /via & thx @ario",
  "id" : 93182405896179715,
  "created_at" : "Tue Jul 19 04:56:31 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.605166, -122.322667 ]
  },
  "id_str" : "93167510656004097",
  "text" : "8:36pm Drawing. We'll see how long this lasts. My hand already hurts. http://flic.kr/p/a52wfR",
  "id" : 93167510656004097,
  "created_at" : "Tue Jul 19 03:57:20 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charlie Park",
      "screen_name" : "charliepark",
      "indices" : [ 0, 12 ],
      "id_str" : "3225381",
      "id" : 3225381
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "93142662751862785",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6049840333, -122.32302746 ]
  },
  "id_str" : "93150702808997888",
  "in_reply_to_user_id" : 3225381,
  "text" : "@charliepark I'll check them out. Thanks!",
  "id" : 93150702808997888,
  "in_reply_to_status_id" : 93142662751862785,
  "created_at" : "Tue Jul 19 02:50:32 +0000 2011",
  "in_reply_to_screen_name" : "charliepark",
  "in_reply_to_user_id_str" : "3225381",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charlie Park",
      "screen_name" : "charliepark",
      "indices" : [ 0, 12 ],
      "id_str" : "3225381",
      "id" : 3225381
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "93140198698917888",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.605003173, -122.322889847 ]
  },
  "id_str" : "93141512010993664",
  "in_reply_to_user_id" : 3225381,
  "text" : "@charliepark I haven't! Is there something in particular that you'd recommend I start with?",
  "id" : 93141512010993664,
  "in_reply_to_status_id" : 93140198698917888,
  "created_at" : "Tue Jul 19 02:14:01 +0000 2011",
  "in_reply_to_screen_name" : "charliepark",
  "in_reply_to_user_id_str" : "3225381",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6050436286, -122.3226807714 ]
  },
  "id_str" : "93124380888014848",
  "text" : "Not that I have any time, but I've always wanted to write a comic book/drawing series. Who has tips and tricks?",
  "id" : 93124380888014848,
  "created_at" : "Tue Jul 19 01:05:57 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amy Jo Kim",
      "screen_name" : "amyjokim",
      "indices" : [ 0, 9 ],
      "id_str" : "780991",
      "id" : 780991
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "93070482387124225",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.61464479, -122.3196347 ]
  },
  "id_str" : "93070931618050049",
  "in_reply_to_user_id" : 780991,
  "text" : "@amyjokim Ah good point.",
  "id" : 93070931618050049,
  "in_reply_to_status_id" : 93070482387124225,
  "created_at" : "Mon Jul 18 21:33:33 +0000 2011",
  "in_reply_to_screen_name" : "amyjokim",
  "in_reply_to_user_id_str" : "780991",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amy Jo Kim",
      "screen_name" : "amyjokim",
      "indices" : [ 3, 12 ],
      "id_str" : "780991",
      "id" : 780991
    }, {
      "name" : "Anti-Buster",
      "screen_name" : "busterbenson",
      "indices" : [ 14, 27 ],
      "id_str" : "1024917050",
      "id" : 1024917050
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "93069784266194944",
  "text" : "RT @amyjokim: @busterbenson any of those things AS LONG AS you're connecting with other people. That's a BIG part of the smoke break.",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Anti-Buster",
        "screen_name" : "busterbenson",
        "indices" : [ 0, 13 ],
        "id_str" : "1024917050",
        "id" : 1024917050
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "93029050725040129",
    "geo" : {
    },
    "id_str" : "93065441966166016",
    "in_reply_to_user_id" : 2185,
    "text" : "@busterbenson any of those things AS LONG AS you're connecting with other people. That's a BIG part of the smoke break.",
    "id" : 93065441966166016,
    "in_reply_to_status_id" : 93029050725040129,
    "created_at" : "Mon Jul 18 21:11:45 +0000 2011",
    "in_reply_to_screen_name" : "buster",
    "in_reply_to_user_id_str" : "2185",
    "user" : {
      "name" : "Amy Jo Kim",
      "screen_name" : "amyjokim",
      "protected" : false,
      "id_str" : "780991",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1789001732/ajk-headshot2_normal.jpg",
      "id" : 780991,
      "verified" : false
    }
  },
  "id" : 93069784266194944,
  "created_at" : "Mon Jul 18 21:29:00 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amy Jo Kim",
      "screen_name" : "amyjokim",
      "indices" : [ 0, 9 ],
      "id_str" : "780991",
      "id" : 780991
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "93065441966166016",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6148846683, -122.319979395 ]
  },
  "id_str" : "93069661607956480",
  "in_reply_to_user_id" : 780991,
  "text" : "@amyjokim Interesting! So maybe the breaks should be for the whole team at once, or in groups? Social always comes back into the picture. :)",
  "id" : 93069661607956480,
  "in_reply_to_status_id" : 93065441966166016,
  "created_at" : "Mon Jul 18 21:28:31 +0000 2011",
  "in_reply_to_screen_name" : "amyjokim",
  "in_reply_to_user_id_str" : "780991",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 88 ],
      "url" : "http://t.co/iSKcoEz",
      "expanded_url" : "http://blog.habitlabs.com/post/7769773161/the-new-smoke-break",
      "display_url" : "blog.habitlabs.com/post/776977316\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "93033432111779841",
  "text" : "Here are some of the ideas you came up with for the new smoke break: http://t.co/iSKcoEz (please continue to add suggestions)",
  "id" : 93033432111779841,
  "created_at" : "Mon Jul 18 19:04:33 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Susannah Fox",
      "screen_name" : "SusannahFox",
      "indices" : [ 0, 12 ],
      "id_str" : "17843236",
      "id" : 17843236
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "93030417925541888",
  "geo" : {
  },
  "id_str" : "93030705805787137",
  "in_reply_to_user_id" : 17843236,
  "text" : "@SusannahFox Ha, that's a great one! Do you take the stairs back too?",
  "id" : 93030705805787137,
  "in_reply_to_status_id" : 93030417925541888,
  "created_at" : "Mon Jul 18 18:53:43 +0000 2011",
  "in_reply_to_screen_name" : "SusannahFox",
  "in_reply_to_user_id_str" : "17843236",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "93029050725040129",
  "text" : "What are the best things you can do on a 5-minute work break? ie. pushups, drink water, walk outside, stretch...",
  "id" : 93029050725040129,
  "created_at" : "Mon Jul 18 18:47:08 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andres Moran",
      "screen_name" : "DreMoran",
      "indices" : [ 0, 9 ],
      "id_str" : "8461972",
      "id" : 8461972
    }, {
      "name" : "Jen S. McCabe",
      "screen_name" : "jensmccabe",
      "indices" : [ 111, 122 ],
      "id_str" : "14258044",
      "id" : 14258044
    }, {
      "name" : "Emilio Ramirez",
      "screen_name" : "e_ramirez",
      "indices" : [ 123, 133 ],
      "id_str" : "1273564632",
      "id" : 1273564632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "93021237068042240",
  "geo" : {
  },
  "id_str" : "93022360650792960",
  "in_reply_to_user_id" : 8461972,
  "text" : "@DreMoran Interesting article! I wish they had also tested \"I am\"/\"I have\". Language is weird and awesome. /cc @jensmccabe @e_ramirez",
  "id" : 93022360650792960,
  "in_reply_to_status_id" : 93021237068042240,
  "created_at" : "Mon Jul 18 18:20:33 +0000 2011",
  "in_reply_to_screen_name" : "DreMoran",
  "in_reply_to_user_id_str" : "8461972",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emilio Ramirez",
      "screen_name" : "e_ramirez",
      "indices" : [ 0, 10 ],
      "id_str" : "1273564632",
      "id" : 1273564632
    }, {
      "name" : "Jen S. McCabe",
      "screen_name" : "jensmccabe",
      "indices" : [ 11, 22 ],
      "id_str" : "14258044",
      "id" : 14258044
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "93019660257198080",
  "geo" : {
  },
  "id_str" : "93020217827008514",
  "in_reply_to_user_id" : 21135674,
  "text" : "@e_ramirez @jensmccabe Exactly. It puts you in the shoes of your future self that has already overcome the obstacles.",
  "id" : 93020217827008514,
  "in_reply_to_status_id" : 93019660257198080,
  "created_at" : "Mon Jul 18 18:12:02 +0000 2011",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jen S. McCabe",
      "screen_name" : "jensmccabe",
      "indices" : [ 0, 11 ],
      "id_str" : "14258044",
      "id" : 14258044
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "93019175005593600",
  "geo" : {
  },
  "id_str" : "93019984384634880",
  "in_reply_to_user_id" : 14258044,
  "text" : "@jensmccabe It's a statement you can make at the point of success. I think it's more powerful than intent, it's about being the success.",
  "id" : 93019984384634880,
  "in_reply_to_status_id" : 93019175005593600,
  "created_at" : "Mon Jul 18 18:11:07 +0000 2011",
  "in_reply_to_screen_name" : "jensmccabe",
  "in_reply_to_user_id_str" : "14258044",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jen S. McCabe",
      "screen_name" : "jensmccabe",
      "indices" : [ 0, 11 ],
      "id_str" : "14258044",
      "id" : 14258044
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "93018051213148160",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6050871867, -122.322852805 ]
  },
  "id_str" : "93018515681980416",
  "in_reply_to_user_id" : 14258044,
  "text" : "@jensmccabe I think a success statement should be in the present tense, ie: \"I am able able to make it to 3pm without drinking a soda.\"",
  "id" : 93018515681980416,
  "in_reply_to_status_id" : 93018051213148160,
  "created_at" : "Mon Jul 18 18:05:17 +0000 2011",
  "in_reply_to_screen_name" : "jensmccabe",
  "in_reply_to_user_id_str" : "14258044",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ingopixel",
      "screen_name" : "ingopixel",
      "indices" : [ 0, 10 ],
      "id_str" : "7943892",
      "id" : 7943892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "92825493149204480",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.60653162, -122.3231666 ]
  },
  "id_str" : "92827420201193473",
  "in_reply_to_user_id" : 7943892,
  "text" : "@ingopixel Haha okay I get it. Beautiful, smart, and tasty. Go Pixels!",
  "id" : 92827420201193473,
  "in_reply_to_status_id" : 92825493149204480,
  "created_at" : "Mon Jul 18 05:25:56 +0000 2011",
  "in_reply_to_screen_name" : "ingopixel",
  "in_reply_to_user_id_str" : "7943892",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ingopixel",
      "screen_name" : "ingopixel",
      "indices" : [ 0, 10 ],
      "id_str" : "7943892",
      "id" : 7943892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "92821826148892672",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6051640105, -122.3225296565 ]
  },
  "id_str" : "92825375708676096",
  "in_reply_to_user_id" : 7943892,
  "text" : "@ingopixel PS happy anniversary!",
  "id" : 92825375708676096,
  "in_reply_to_status_id" : 92821826148892672,
  "created_at" : "Mon Jul 18 05:17:48 +0000 2011",
  "in_reply_to_screen_name" : "ingopixel",
  "in_reply_to_user_id_str" : "7943892",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ingopixel",
      "screen_name" : "ingopixel",
      "indices" : [ 0, 10 ],
      "id_str" : "7943892",
      "id" : 7943892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "92821826148892672",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6050834078, -122.3225111839 ]
  },
  "id_str" : "92825151443451904",
  "in_reply_to_user_id" : 7943892,
  "text" : "@ingopixel What's the logic behind that? You know I do love a good cephalopod but you both seem less camouflagey! :)",
  "id" : 92825151443451904,
  "in_reply_to_status_id" : 92821826148892672,
  "created_at" : "Mon Jul 18 05:16:55 +0000 2011",
  "in_reply_to_screen_name" : "ingopixel",
  "in_reply_to_user_id_str" : "7943892",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.605166, -122.322834 ]
  },
  "id_str" : "92800484141838336",
  "text" : "8:36pm We are tired and waiting for food to come to our door http://flic.kr/p/a4EHPk",
  "id" : 92800484141838336,
  "created_at" : "Mon Jul 18 03:38:54 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 101 ],
      "url" : "http://t.co/GnWM4GW",
      "expanded_url" : "http://omis.me/2011/07/17/paul-smith/",
      "display_url" : "omis.me/2011/07/17/pau\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "92744339112992768",
  "text" : "This interview with Paul Smith just makes me love him even more. What a cool guy. http://t.co/GnWM4GW",
  "id" : 92744339112992768,
  "created_at" : "Sun Jul 17 23:55:48 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "girl jo",
      "screen_name" : "octavekitten",
      "indices" : [ 0, 13 ],
      "id_str" : "16366882",
      "id" : 16366882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "92122050046607360",
  "geo" : {
  },
  "id_str" : "92309098309222400",
  "in_reply_to_user_id" : 16366882,
  "text" : "@octavekitten That's my new lock screen image. Thank you!",
  "id" : 92309098309222400,
  "in_reply_to_status_id" : 92122050046607360,
  "created_at" : "Sat Jul 16 19:06:18 +0000 2011",
  "in_reply_to_screen_name" : "octavekitten",
  "in_reply_to_user_id_str" : "16366882",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.612, -122.317167 ]
  },
  "id_str" : "92164534130843648",
  "text" : "8:36pm Showing off my fancy new baby monitor http://flic.kr/p/a48LT1",
  "id" : 92164534130843648,
  "created_at" : "Sat Jul 16 09:31:51 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "girl jo",
      "screen_name" : "octavekitten",
      "indices" : [ 0, 13 ],
      "id_str" : "16366882",
      "id" : 16366882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "92120232826646528",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6144416356, -122.3180144322 ]
  },
  "id_str" : "92121796106657792",
  "in_reply_to_user_id" : 16366882,
  "text" : "@octavekitten Yes but it may have convinced her to make the switch. What do you think?",
  "id" : 92121796106657792,
  "in_reply_to_status_id" : 92120232826646528,
  "created_at" : "Sat Jul 16 06:42:02 +0000 2011",
  "in_reply_to_screen_name" : "octavekitten",
  "in_reply_to_user_id_str" : "16366882",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6142930093, -122.317872047 ]
  },
  "id_str" : "92119916282527744",
  "text" : "My hot blonde wife  @ Vermillion Gallery & Wine Bar http://instagr.am/p/Hw29r/",
  "id" : 92119916282527744,
  "created_at" : "Sat Jul 16 06:34:34 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amber Rae",
      "screen_name" : "heyamberrae",
      "indices" : [ 0, 12 ],
      "id_str" : "15019184",
      "id" : 15019184
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "92046274404155392",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.605022444, -122.323051925 ]
  },
  "id_str" : "92046488330440704",
  "in_reply_to_user_id" : 15019184,
  "text" : "@heyamberrae Okay, gimme a day, I'll need to dig it up!",
  "id" : 92046488330440704,
  "in_reply_to_status_id" : 92046274404155392,
  "created_at" : "Sat Jul 16 01:42:47 +0000 2011",
  "in_reply_to_screen_name" : "heyamberrae",
  "in_reply_to_user_id_str" : "15019184",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amber Rae",
      "screen_name" : "heyamberrae",
      "indices" : [ 0, 12 ],
      "id_str" : "15019184",
      "id" : 15019184
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "92045350860365824",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.605022444, -122.323051925 ]
  },
  "id_str" : "92046158356164608",
  "in_reply_to_user_id" : 15019184,
  "text" : "@heyamberrae I have a document somewhere outlining the basic process if you wanna see it.",
  "id" : 92046158356164608,
  "in_reply_to_status_id" : 92045350860365824,
  "created_at" : "Sat Jul 16 01:41:28 +0000 2011",
  "in_reply_to_screen_name" : "heyamberrae",
  "in_reply_to_user_id_str" : "15019184",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amber Rae",
      "screen_name" : "heyamberrae",
      "indices" : [ 0, 12 ],
      "id_str" : "15019184",
      "id" : 15019184
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "92045350860365824",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.605022444, -122.323051925 ]
  },
  "id_str" : "92046023899353088",
  "in_reply_to_user_id" : 15019184,
  "text" : "@heyamberrae The actual legal process only takes an hour. Figuring out who else needs to be notified & waiting for them takes a couple mos.",
  "id" : 92046023899353088,
  "in_reply_to_status_id" : 92045350860365824,
  "created_at" : "Sat Jul 16 01:40:56 +0000 2011",
  "in_reply_to_screen_name" : "heyamberrae",
  "in_reply_to_user_id_str" : "15019184",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "samantha",
      "screen_name" : "samantham",
      "indices" : [ 0, 10 ],
      "id_str" : "1771141",
      "id" : 1771141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "92016520154189824",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6048913868, -122.3228638476 ]
  },
  "id_str" : "92017074989305856",
  "in_reply_to_user_id" : 1771141,
  "text" : "@samantham Well he *was* wearing your cape. Maybe along with super powers it comes with a fear of chickens?",
  "id" : 92017074989305856,
  "in_reply_to_status_id" : 92016520154189824,
  "created_at" : "Fri Jul 15 23:45:54 +0000 2011",
  "in_reply_to_screen_name" : "samantham",
  "in_reply_to_user_id_str" : "1771141",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "92006095840743424",
  "text" : "Before the race, Niko and Lillia meeting their chickens http://instagr.am/p/HvIAo/",
  "id" : 92006095840743424,
  "created_at" : "Fri Jul 15 23:02:17 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "josh",
      "screen_name" : "joshc",
      "indices" : [ 1, 7 ],
      "id_str" : "2015",
      "id" : 2015
    }, {
      "name" : "samantha",
      "screen_name" : "samantham",
      "indices" : [ 8, 18 ],
      "id_str" : "1771141",
      "id" : 1771141
    }, {
      "name" : "Foursquare",
      "screen_name" : "foursquare",
      "indices" : [ 53, 64 ],
      "id_str" : "14120151",
      "id" : 14120151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "91752176241737728",
  "geo" : {
  },
  "id_str" : "91758298138816512",
  "in_reply_to_user_id" : 2015,
  "text" : ".@joshc @samantham I've been trying to figure out my @foursquare user # for a while! It's 237. Who can beat that? 236 people, I guess.",
  "id" : 91758298138816512,
  "in_reply_to_status_id" : 91752176241737728,
  "created_at" : "Fri Jul 15 06:37:37 +0000 2011",
  "in_reply_to_screen_name" : "joshc",
  "in_reply_to_user_id_str" : "2015",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Lisagor",
      "screen_name" : "lonelysandwich",
      "indices" : [ 3, 18 ],
      "id_str" : "2735631",
      "id" : 2735631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "91720295353823232",
  "text" : "RT @lonelysandwich: I'm trying a new cleanse where I only eat seaweed and drink ginger ale and I'm calling it the Mesozoic Diet because\u2014 ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "91709684645498880",
    "text" : "I'm trying a new cleanse where I only eat seaweed and drink ginger ale and I'm calling it the Mesozoic Diet because\u2014you know\u2014why not.",
    "id" : 91709684645498880,
    "created_at" : "Fri Jul 15 03:24:27 +0000 2011",
    "user" : {
      "name" : "Adam Lisagor",
      "screen_name" : "lonelysandwich",
      "protected" : false,
      "id_str" : "2735631",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/559086400/dmitiri_110Nc_p9_normal.jpg",
      "id" : 2735631,
      "verified" : true
    }
  },
  "id" : 91720295353823232,
  "created_at" : "Fri Jul 15 04:06:37 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bbt",
      "indices" : [ 51, 55 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.605, -122.322667 ]
  },
  "id_str" : "91713429873758210",
  "text" : "8:36pm Left Bastille Day at Corson Building before #bbt and staring at ceiling willing myself for work shift #2 http://flic.kr/p/a3PBY1",
  "id" : 91713429873758210,
  "created_at" : "Fri Jul 15 03:39:20 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rafael Regales",
      "screen_name" : "bmorerican",
      "indices" : [ 0, 11 ],
      "id_str" : "23912695",
      "id" : 23912695
    }, {
      "name" : "Instagram",
      "screen_name" : "instagram",
      "indices" : [ 29, 39 ],
      "id_str" : "180505807",
      "id" : 180505807
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "91697570514092032",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6104699745, -122.3263087521 ]
  },
  "id_str" : "91704696988909568",
  "in_reply_to_user_id" : 23912695,
  "text" : "@bmorerican If only they had @instagram back then! The pictures would've been so good.",
  "id" : 91704696988909568,
  "in_reply_to_status_id" : 91697570514092032,
  "created_at" : "Fri Jul 15 03:04:38 +0000 2011",
  "in_reply_to_screen_name" : "bmorerican",
  "in_reply_to_user_id_str" : "23912695",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.551888, -122.320287067 ]
  },
  "id_str" : "91687072548651010",
  "text" : "Child abuse during chicken races  @ The Corson Building http://instagr.am/p/HrHwO/",
  "id" : 91687072548651010,
  "created_at" : "Fri Jul 15 01:54:36 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "91628752940965888",
  "text" : "Sometimes I get a text and then the iPhone hijacks me to Twitter thread and I tweet instead. There should be a way to stop outgoing SMS.",
  "id" : 91628752940965888,
  "created_at" : "Thu Jul 14 22:02:51 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "91611207471087616",
  "text" : "New idea: A Gmail plugin that scans my inbox for any new friend requests and approves all from people I've friended before, then archives.",
  "id" : 91611207471087616,
  "created_at" : "Thu Jul 14 20:53:08 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ioan Mitrea",
      "screen_name" : "awarenesss",
      "indices" : [ 0, 11 ],
      "id_str" : "18603224",
      "id" : 18603224
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "91596312306393088",
  "geo" : {
  },
  "id_str" : "91596469034942464",
  "in_reply_to_user_id" : 18603224,
  "text" : "@awarenesss The transcript of the talk is still there.. and happy to do it again if there's any interest!",
  "id" : 91596469034942464,
  "in_reply_to_status_id" : 91596312306393088,
  "created_at" : "Thu Jul 14 19:54:34 +0000 2011",
  "in_reply_to_screen_name" : "awarenesss",
  "in_reply_to_user_id_str" : "18603224",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "josh",
      "screen_name" : "joshc",
      "indices" : [ 0, 6 ],
      "id_str" : "2015",
      "id" : 2015
    }, {
      "name" : "Monica Guzman",
      "screen_name" : "moniguzman",
      "indices" : [ 7, 18 ],
      "id_str" : "3452941",
      "id" : 3452941
    }, {
      "name" : "Marco Arment",
      "screen_name" : "marcoarment",
      "indices" : [ 127, 139 ],
      "id_str" : "14231571",
      "id" : 14231571
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "91353964070699008",
  "geo" : {
  },
  "id_str" : "91594248977268736",
  "in_reply_to_user_id" : 2015,
  "text" : "@joshc @moniguzman I'm tempted to write a companion piece called \"disown your identity\". Ownership is overrated: delegate! /cc @marcoarment",
  "id" : 91594248977268736,
  "in_reply_to_status_id" : 91353964070699008,
  "created_at" : "Thu Jul 14 19:45:45 +0000 2011",
  "in_reply_to_screen_name" : "joshc",
  "in_reply_to_user_id_str" : "2015",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Coleman",
      "screen_name" : "aarondcoleman",
      "indices" : [ 0, 14 ],
      "id_str" : "1379965428",
      "id" : 1379965428
    }, {
      "name" : "Emilio Ramirez",
      "screen_name" : "e_ramirez",
      "indices" : [ 70, 80 ],
      "id_str" : "1273564632",
      "id" : 1273564632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "91588313680580608",
  "geo" : {
  },
  "id_str" : "91588697543282688",
  "in_reply_to_user_id" : 9609062,
  "text" : "@aarondcoleman It was fun! Thanks for participating! I'm a big fan of @e_ramirez and the work you're all doing. Keep it up!",
  "id" : 91588697543282688,
  "in_reply_to_status_id" : 91588313680580608,
  "created_at" : "Thu Jul 14 19:23:41 +0000 2011",
  "in_reply_to_screen_name" : "aaronc",
  "in_reply_to_user_id_str" : "9609062",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Namesake",
      "screen_name" : "Namesake",
      "indices" : [ 16, 25 ],
      "id_str" : "140496824",
      "id" : 140496824
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 71 ],
      "url" : "http://t.co/GoniVrJ",
      "expanded_url" : "http://namesake.com/conversation/andrewskotzko/todays-namesake-conversation-is-with-busterbenson-founder-of-healthmonthcom-locavore-and-750words-were-talking-about-how-to-use-games-to-create-an-awesome-life-and-how-to-build-businesses-around-meaningful-purposes-dont-miss-this-one",
      "display_url" : "namesake.com/conversation/a\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "91568471749574657",
  "text" : "Talk with me on @namesake, for the next hour or so: http://t.co/GoniVrJ",
  "id" : 91568471749574657,
  "created_at" : "Thu Jul 14 18:03:19 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Namesake",
      "screen_name" : "Namesake",
      "indices" : [ 34, 43 ],
      "id_str" : "140496824",
      "id" : 140496824
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gamification",
      "indices" : [ 97, 110 ]
    }, {
      "text" : "health",
      "indices" : [ 111, 118 ]
    }, {
      "text" : "entrepreneurship",
      "indices" : [ 119, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 96 ],
      "url" : "http://t.co/U6bQJqk",
      "expanded_url" : "http://namesake.com",
      "display_url" : "namesake.com"
    } ]
  },
  "geo" : {
  },
  "id_str" : "91567613372665856",
  "text" : "I'm going to be a guest in a live @namesake conversation in about 5 minutes! http://t.co/U6bQJqk #gamification #health #entrepreneurship",
  "id" : 91567613372665856,
  "created_at" : "Thu Jul 14 17:59:54 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ReadWrite",
      "screen_name" : "RWW",
      "indices" : [ 3, 7 ],
      "id_str" : "4641021",
      "id" : 4641021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "91517520858722305",
  "text" : "RT @RWW: Finally! Music Streaming Service Spotify Arrives in the U.S. http://rww.to/oCHeAh",
  "retweeted_status" : {
    "source" : "<a href=\"http://mt-hacks.com/twittertools.html\" rel=\"nofollow\">Tools Plugin for Movable Type</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "91512598075412483",
    "text" : "Finally! Music Streaming Service Spotify Arrives in the U.S. http://rww.to/oCHeAh",
    "id" : 91512598075412483,
    "created_at" : "Thu Jul 14 14:21:18 +0000 2011",
    "user" : {
      "name" : "ReadWrite",
      "screen_name" : "RWW",
      "protected" : false,
      "id_str" : "4641021",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2750899250/294d9c7b13ba263c7c3f634a487d468d_normal.jpeg",
      "id" : 4641021,
      "verified" : true
    }
  },
  "id" : 91517520858722305,
  "created_at" : "Thu Jul 14 14:40:51 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marian Schembari",
      "screen_name" : "MarianSchembari",
      "indices" : [ 0, 16 ],
      "id_str" : "63984606",
      "id" : 63984606
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "91418395198758912",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6049917594, -122.322938635 ]
  },
  "id_str" : "91515764661694465",
  "in_reply_to_user_id" : 63984606,
  "text" : "@MarianSchembari Why thank you! Still a lot of work to be done with 750, but the basic idea is a much needed one in my day as well!",
  "id" : 91515764661694465,
  "in_reply_to_status_id" : 91418395198758912,
  "created_at" : "Thu Jul 14 14:33:53 +0000 2011",
  "in_reply_to_screen_name" : "MarianSchembari",
  "in_reply_to_user_id_str" : "63984606",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Santangelo",
      "screen_name" : "endquote",
      "indices" : [ 0, 9 ],
      "id_str" : "408",
      "id" : 408
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "91376381585391616",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6071355022, -122.3208211467 ]
  },
  "id_str" : "91381648318398464",
  "in_reply_to_user_id" : 408,
  "text" : "@endquote Nah, I let it expire since I didn't have plans for it anytime soon.",
  "id" : 91381648318398464,
  "in_reply_to_status_id" : 91376381585391616,
  "created_at" : "Thu Jul 14 05:40:57 +0000 2011",
  "in_reply_to_screen_name" : "endquote",
  "in_reply_to_user_id_str" : "408",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.605, -122.323 ]
  },
  "id_str" : "91350948982697985",
  "text" : "8:36pm People are filming a movie in our apartment building and seemingly camping in our parking lot http://flic.kr/p/a3uCjP",
  "id" : 91350948982697985,
  "created_at" : "Thu Jul 14 03:38:58 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Merholz",
      "screen_name" : "peterme",
      "indices" : [ 3, 11 ],
      "id_str" : "1154",
      "id" : 1154
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "91331222864801793",
  "text" : "RT @peterme: We spent 15 years learning that the web is not an isolated channel but part of a larger context. Will we need to relearn th ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "91329833052807168",
    "text" : "We spent 15 years learning that the web is not an isolated channel but part of a larger context. Will we need to relearn that for mobile?",
    "id" : 91329833052807168,
    "created_at" : "Thu Jul 14 02:15:03 +0000 2011",
    "user" : {
      "name" : "Peter Merholz",
      "screen_name" : "peterme",
      "protected" : false,
      "id_str" : "1154",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1455186198/peterme_100_normal.jpg",
      "id" : 1154,
      "verified" : false
    }
  },
  "id" : 91331222864801793,
  "created_at" : "Thu Jul 14 02:20:35 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Salinsky",
      "screen_name" : "AlexSalinsky",
      "indices" : [ 0, 13 ],
      "id_str" : "134531474",
      "id" : 134531474
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "91144674697412608",
  "geo" : {
  },
  "id_str" : "91330802553602050",
  "in_reply_to_user_id" : 134531474,
  "text" : "@AlexSalinsky This ends my week of reminders, but I will follow up a week from today to see how next week goes. What did you think about it?",
  "id" : 91330802553602050,
  "in_reply_to_status_id" : 91144674697412608,
  "created_at" : "Thu Jul 14 02:18:54 +0000 2011",
  "in_reply_to_screen_name" : "AlexSalinsky",
  "in_reply_to_user_id_str" : "134531474",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Salinsky",
      "screen_name" : "AlexSalinsky",
      "indices" : [ 0, 13 ],
      "id_str" : "134531474",
      "id" : 134531474
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "91144674697412608",
  "geo" : {
  },
  "id_str" : "91330701097574400",
  "in_reply_to_user_id" : 134531474,
  "text" : "@AlexSalinsky Speaking of, how did your secret project go yesterday and today?",
  "id" : 91330701097574400,
  "in_reply_to_status_id" : 91144674697412608,
  "created_at" : "Thu Jul 14 02:18:30 +0000 2011",
  "in_reply_to_screen_name" : "AlexSalinsky",
  "in_reply_to_user_id_str" : "134531474",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Salinsky",
      "screen_name" : "AlexSalinsky",
      "indices" : [ 0, 13 ],
      "id_str" : "134531474",
      "id" : 134531474
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "91144674697412608",
  "geo" : {
  },
  "id_str" : "91330607916912640",
  "in_reply_to_user_id" : 134531474,
  "text" : "@AlexSalinsky That sounds quite interesting. Let me know when you have something to share!",
  "id" : 91330607916912640,
  "in_reply_to_status_id" : 91144674697412608,
  "created_at" : "Thu Jul 14 02:18:08 +0000 2011",
  "in_reply_to_screen_name" : "AlexSalinsky",
  "in_reply_to_user_id_str" : "134531474",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "91330142705684480",
  "text" : "@GoalsGamified If you want, I will follow up a week from today to see how next week goes. What did you think about the reminders in general?",
  "id" : 91330142705684480,
  "created_at" : "Thu Jul 14 02:16:17 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "91330074921537536",
  "text" : "@GoalsGamified Did you go to bed early enough last night, thus completing a week-long streak? (alas, this is my last reminder for now...)",
  "id" : 91330074921537536,
  "created_at" : "Thu Jul 14 02:16:01 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "91329796826607616",
  "text" : "@GoalsGamified Yeah, I did a lot of walking last week thanks to a challenge from a friend.  :)",
  "id" : 91329796826607616,
  "created_at" : "Thu Jul 14 02:14:55 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "katrina panovich",
      "screen_name" : "katrina_",
      "indices" : [ 0, 9 ],
      "id_str" : "9381242",
      "id" : 9381242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "91329518287077377",
  "in_reply_to_user_id" : 9381242,
  "text" : "@katrina_ If you want, I will follow up a week from today to see how next week goes. What did you think about the reminders in general?",
  "id" : 91329518287077377,
  "created_at" : "Thu Jul 14 02:13:48 +0000 2011",
  "in_reply_to_screen_name" : "katrina_",
  "in_reply_to_user_id_str" : "9381242",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "katrina panovich",
      "screen_name" : "katrina_",
      "indices" : [ 0, 9 ],
      "id_str" : "9381242",
      "id" : 9381242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "91235783423438848",
  "geo" : {
  },
  "id_str" : "91329350795935744",
  "in_reply_to_user_id" : 9381242,
  "text" : "@katrina_ Awesome! It's today and tomorrow that count. Yesterday, not so much. Let me know if you do yoga today!",
  "id" : 91329350795935744,
  "in_reply_to_status_id" : 91235783423438848,
  "created_at" : "Thu Jul 14 02:13:08 +0000 2011",
  "in_reply_to_screen_name" : "katrina_",
  "in_reply_to_user_id_str" : "9381242",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carrie-Anne Gallo",
      "screen_name" : "CazMinx",
      "indices" : [ 0, 8 ],
      "id_str" : "20905374",
      "id" : 20905374
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "91328307160821760",
  "in_reply_to_user_id" : 20905374,
  "text" : "@cazminx This ends my week of reminders, but I will follow up a week from today to see how next week goes. What did you think about it?",
  "id" : 91328307160821760,
  "created_at" : "Thu Jul 14 02:08:59 +0000 2011",
  "in_reply_to_screen_name" : "CazMinx",
  "in_reply_to_user_id_str" : "20905374",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carrie-Anne Gallo",
      "screen_name" : "CazMinx",
      "indices" : [ 0, 8 ],
      "id_str" : "20905374",
      "id" : 20905374
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "91328148423184384",
  "in_reply_to_user_id" : 20905374,
  "text" : "@cazminx Hi! Have you treadmilled in the last couple days? If not, what are the chances it might happen today?",
  "id" : 91328148423184384,
  "created_at" : "Thu Jul 14 02:08:22 +0000 2011",
  "in_reply_to_screen_name" : "CazMinx",
  "in_reply_to_user_id_str" : "20905374",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Oliver",
      "screen_name" : "MikeOliver",
      "indices" : [ 0, 11 ],
      "id_str" : "993801636",
      "id" : 993801636
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "91327334958907392",
  "in_reply_to_user_id" : 12866,
  "text" : "@mikeoliver This ends my week of reminders, but I will follow up a week from today to see how next week goes. What did you think about it?",
  "id" : 91327334958907392,
  "created_at" : "Thu Jul 14 02:05:08 +0000 2011",
  "in_reply_to_screen_name" : "mkolvr",
  "in_reply_to_user_id_str" : "12866",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Oliver",
      "screen_name" : "MikeOliver",
      "indices" : [ 0, 11 ],
      "id_str" : "993801636",
      "id" : 993801636
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "90932906637275136",
  "geo" : {
  },
  "id_str" : "91327219942686720",
  "in_reply_to_user_id" : 12866,
  "text" : "@mikeoliver 1 coffee! Holy smokes. Well done. How did an all-water dinner go? And how is today going?",
  "id" : 91327219942686720,
  "in_reply_to_status_id" : 90932906637275136,
  "created_at" : "Thu Jul 14 02:04:40 +0000 2011",
  "in_reply_to_screen_name" : "mkolvr",
  "in_reply_to_user_id_str" : "12866",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mozart",
      "screen_name" : "mgspeaks",
      "indices" : [ 0, 9 ],
      "id_str" : "217657761",
      "id" : 217657761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "91326759852720129",
  "in_reply_to_user_id" : 217657761,
  "text" : "@mgspeaks This ends my week of reminders, but I will follow up a week from today to see how next week goes. What did you think about it?",
  "id" : 91326759852720129,
  "created_at" : "Thu Jul 14 02:02:50 +0000 2011",
  "in_reply_to_screen_name" : "mgspeaks",
  "in_reply_to_user_id_str" : "217657761",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mozart",
      "screen_name" : "mgspeaks",
      "indices" : [ 0, 9 ],
      "id_str" : "217657761",
      "id" : 217657761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "91326619498725377",
  "in_reply_to_user_id" : 217657761,
  "text" : "@mgspeaks Did you get any time today to check out NirvanaHQ and Basecamp yet? If not, how about right now?",
  "id" : 91326619498725377,
  "created_at" : "Thu Jul 14 02:02:17 +0000 2011",
  "in_reply_to_screen_name" : "mgspeaks",
  "in_reply_to_user_id_str" : "217657761",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rafael Regales",
      "screen_name" : "bmorerican",
      "indices" : [ 0, 11 ],
      "id_str" : "23912695",
      "id" : 23912695
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "90940977354780672",
  "geo" : {
  },
  "id_str" : "91325782638592001",
  "in_reply_to_user_id" : 23912695,
  "text" : "@bmorerican This ends my week of reminders, but I will follow up a week from today to see how next week goes. What did you think about it?",
  "id" : 91325782638592001,
  "in_reply_to_status_id" : 90940977354780672,
  "created_at" : "Thu Jul 14 01:58:58 +0000 2011",
  "in_reply_to_screen_name" : "bmorerican",
  "in_reply_to_user_id_str" : "23912695",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rafael Regales",
      "screen_name" : "bmorerican",
      "indices" : [ 0, 11 ],
      "id_str" : "23912695",
      "id" : 23912695
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "90940977354780672",
  "geo" : {
  },
  "id_str" : "91325603244023808",
  "in_reply_to_user_id" : 23912695,
  "text" : "@bmorerican Naps are healthy too! :) Let's prepare today to get on the stationary bike tomorrow!",
  "id" : 91325603244023808,
  "in_reply_to_status_id" : 90940977354780672,
  "created_at" : "Thu Jul 14 01:58:15 +0000 2011",
  "in_reply_to_screen_name" : "bmorerican",
  "in_reply_to_user_id_str" : "23912695",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jackie ",
      "screen_name" : "PatchworkJackie",
      "indices" : [ 0, 16 ],
      "id_str" : "241515860",
      "id" : 241515860
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "90907351833522176",
  "geo" : {
  },
  "id_str" : "91325137764352000",
  "in_reply_to_user_id" : 241515860,
  "text" : "@PatchworkJackie Also, this ends my week of reminders. What did you think about it?",
  "id" : 91325137764352000,
  "in_reply_to_status_id" : 90907351833522176,
  "created_at" : "Thu Jul 14 01:56:24 +0000 2011",
  "in_reply_to_screen_name" : "PatchworkJackie",
  "in_reply_to_user_id_str" : "241515860",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jackie ",
      "screen_name" : "PatchworkJackie",
      "indices" : [ 0, 16 ],
      "id_str" : "241515860",
      "id" : 241515860
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "91324801762861056",
  "in_reply_to_user_id" : 241515860,
  "text" : "@patchworkjackie Any ideas on a better way to treat the cravings? Also, how did today go?",
  "id" : 91324801762861056,
  "created_at" : "Thu Jul 14 01:55:04 +0000 2011",
  "in_reply_to_screen_name" : "PatchworkJackie",
  "in_reply_to_user_id_str" : "241515860",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Skotzko",
      "screen_name" : "askotzko",
      "indices" : [ 0, 9 ],
      "id_str" : "15391002",
      "id" : 15391002
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "91323698086281216",
  "geo" : {
  },
  "id_str" : "91324471532732416",
  "in_reply_to_user_id" : 15391002,
  "text" : "@askotzko How often did you meditate before this week, compared to now? And do you think it will continue? I will ask again in a week!",
  "id" : 91324471532732416,
  "in_reply_to_status_id" : 91323698086281216,
  "created_at" : "Thu Jul 14 01:53:45 +0000 2011",
  "in_reply_to_screen_name" : "askotzko",
  "in_reply_to_user_id_str" : "15391002",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Skotzko",
      "screen_name" : "askotzko",
      "indices" : [ 0, 9 ],
      "id_str" : "15391002",
      "id" : 15391002
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "90890994467348480",
  "geo" : {
  },
  "id_str" : "91323540632121344",
  "in_reply_to_user_id" : 15391002,
  "text" : "@askotzko Also, this ends my week of reminders. What did you think about it?",
  "id" : 91323540632121344,
  "in_reply_to_status_id" : 90890994467348480,
  "created_at" : "Thu Jul 14 01:50:03 +0000 2011",
  "in_reply_to_screen_name" : "askotzko",
  "in_reply_to_user_id_str" : "15391002",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Skotzko",
      "screen_name" : "askotzko",
      "indices" : [ 0, 9 ],
      "id_str" : "15391002",
      "id" : 15391002
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "90890994467348480",
  "geo" : {
  },
  "id_str" : "91323355130634241",
  "in_reply_to_user_id" : 15391002,
  "text" : "@askotzko Definitely looking forward to tomorrow. Did you do any meditation today yet?",
  "id" : 91323355130634241,
  "in_reply_to_status_id" : 90890994467348480,
  "created_at" : "Thu Jul 14 01:49:19 +0000 2011",
  "in_reply_to_screen_name" : "askotzko",
  "in_reply_to_user_id_str" : "15391002",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 0, 10 ],
      "id_str" : "7362142",
      "id" : 7362142
    }, {
      "name" : "Visually",
      "screen_name" : "Visually",
      "indices" : [ 131, 140 ],
      "id_str" : "273197054",
      "id" : 273197054
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 126 ],
      "url" : "http://t.co/EJk1iAj",
      "expanded_url" : "http://twitter.visual.ly/twitter/infographic?type=faceoff&username1=busterbenson&username2=kellianne&left%5Bgender%5D=male&left%5BhairColor%5D=4d330a&left%5BhairStyle%5D=1-11&left%5BeyeColor%5D=green&left%5BskinColor%5D=e1cfc2&left%5Baccessory%5D=beard&right%5Bgender%5D=female&right%5BhairColor%5D=9a1d1d&right%5BhairStyle%5D=2-2&right%5BeyeColor%5D=blue&right%5BskinColor%5D=eee7c8&right%5Baccessory%5D=&template=twitter&access_token%5Boauth_token%5D=2185-LTlmHualYRLOpCLxyqahGtQBeHanFTKV5KrvlOmoA&access_token%5Boauth_token_secret%5D=OB1jwSxA51k95fFVuVsBQc5hzJ0f8D7H78ACulcCl8&rand=0.33526578499004245",
      "display_url" : "twitter.visual.ly/twitter/infogr\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "91318228533526528",
  "in_reply_to_user_id" : 7362142,
  "text" : "@kellianne We've been twitterized and apparently we're both foodies? And I'm kicking your butt at Twitter. http://t.co/EJk1iAj /by @visually",
  "id" : 91318228533526528,
  "created_at" : "Thu Jul 14 01:28:56 +0000 2011",
  "in_reply_to_screen_name" : "kellianne",
  "in_reply_to_user_id_str" : "7362142",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicole Lazzaro",
      "screen_name" : "NicoleLazzaro",
      "indices" : [ 3, 17 ],
      "id_str" : "7315732",
      "id" : 7315732
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gbconf",
      "indices" : [ 108, 115 ]
    }, {
      "text" : "mbconf",
      "indices" : [ 116, 123 ]
    }, {
      "text" : "vb",
      "indices" : [ 124, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "91281195396112384",
  "text" : "RT @NicoleLazzaro: Skinner Boxes are unsustainable forms of engagement because in the end they are not fun. #gbconf #mbconf #vb",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "gbconf",
        "indices" : [ 89, 96 ]
      }, {
        "text" : "mbconf",
        "indices" : [ 97, 104 ]
      }, {
        "text" : "vb",
        "indices" : [ 105, 108 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "91279402012385280",
    "text" : "Skinner Boxes are unsustainable forms of engagement because in the end they are not fun. #gbconf #mbconf #vb",
    "id" : 91279402012385280,
    "created_at" : "Wed Jul 13 22:54:39 +0000 2011",
    "user" : {
      "name" : "Nicole Lazzaro",
      "screen_name" : "NicoleLazzaro",
      "protected" : false,
      "id_str" : "7315732",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1775837490/NicoleWithHat_squarecropped22636_normal.jpg",
      "id" : 7315732,
      "verified" : false
    }
  },
  "id" : 91281195396112384,
  "created_at" : "Wed Jul 13 23:01:47 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 0, 9 ],
      "id_str" : "761628",
      "id" : 761628
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "91268201970794496",
  "geo" : {
  },
  "id_str" : "91268510478630912",
  "in_reply_to_user_id" : 761628,
  "text" : "@RickWebb I'm curious what the latency of point changes are. I've been super-active on Twitter for a week and my score only changed today.",
  "id" : 91268510478630912,
  "in_reply_to_status_id" : 91268201970794496,
  "created_at" : "Wed Jul 13 22:11:23 +0000 2011",
  "in_reply_to_screen_name" : "RickWebb",
  "in_reply_to_user_id_str" : "761628",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 0, 9 ],
      "id_str" : "761628",
      "id" : 761628
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "91266190063845377",
  "geo" : {
  },
  "id_str" : "91266528242171904",
  "in_reply_to_user_id" : 761628,
  "text" : "@RickWebb Nope. It was 63 before and after, but I'll check back tomorrow to see if it has changed. It should, right? Not sure what helps.",
  "id" : 91266528242171904,
  "in_reply_to_status_id" : 91266190063845377,
  "created_at" : "Wed Jul 13 22:03:30 +0000 2011",
  "in_reply_to_screen_name" : "RickWebb",
  "in_reply_to_user_id_str" : "761628",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Klout",
      "screen_name" : "klout",
      "indices" : [ 20, 26 ],
      "id_str" : "15134782",
      "id" : 15134782
    }, {
      "name" : "Foursquare",
      "screen_name" : "foursquare",
      "indices" : [ 40, 51 ],
      "id_str" : "14120151",
      "id" : 14120151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 86 ],
      "url" : "http://t.co/6jGlOmM",
      "expanded_url" : "http://klout.com/busterbenson?n=tw&v=connect_foursquare",
      "display_url" : "klout.com/busterbenson?n\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "91251380743966720",
  "text" : "I just connected my @klout account with @foursquare. Pretty nifty. http://t.co/6jGlOmM",
  "id" : 91251380743966720,
  "created_at" : "Wed Jul 13 21:03:19 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Dawson",
      "screen_name" : "jeffybrite",
      "indices" : [ 0, 11 ],
      "id_str" : "35402650",
      "id" : 35402650
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "91238553543122944",
  "geo" : {
  },
  "id_str" : "91240177766375424",
  "in_reply_to_user_id" : 35402650,
  "text" : "@jeffybrite I haven't! But just ordered it. Thanks for the rec. It's definitely right up my alley.",
  "id" : 91240177766375424,
  "in_reply_to_status_id" : 91238553543122944,
  "created_at" : "Wed Jul 13 20:18:48 +0000 2011",
  "in_reply_to_screen_name" : "jeffybrite",
  "in_reply_to_user_id_str" : "35402650",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amy Jo Kim",
      "screen_name" : "amyjokim",
      "indices" : [ 3, 12 ],
      "id_str" : "780991",
      "id" : 780991
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "puzzles",
      "indices" : [ 118, 126 ]
    }, {
      "text" : "neuroscience",
      "indices" : [ 127, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "91226174679810048",
  "text" : "RT @amyjokim: Why does it\u00A0feel so good when we suddenly see something that we didn\u2019t see before? http://bit.ly/oeE3uu #puzzles #neuroscience",
  "retweeted_status" : {
    "source" : "<a href=\"http://bitly.com\" rel=\"nofollow\">bitly</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "puzzles",
        "indices" : [ 104, 112 ]
      }, {
        "text" : "neuroscience",
        "indices" : [ 113, 126 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "91224974236463104",
    "text" : "Why does it\u00A0feel so good when we suddenly see something that we didn\u2019t see before? http://bit.ly/oeE3uu #puzzles #neuroscience",
    "id" : 91224974236463104,
    "created_at" : "Wed Jul 13 19:18:23 +0000 2011",
    "user" : {
      "name" : "Amy Jo Kim",
      "screen_name" : "amyjokim",
      "protected" : false,
      "id_str" : "780991",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1789001732/ajk-headshot2_normal.jpg",
      "id" : 780991,
      "verified" : false
    }
  },
  "id" : 91226174679810048,
  "created_at" : "Wed Jul 13 19:23:09 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "fredtrotter",
      "screen_name" : "fredtrotter",
      "indices" : [ 122, 134 ],
      "id_str" : "16971428",
      "id" : 16971428
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 117 ],
      "url" : "http://t.co/PUYgcXS",
      "expanded_url" : "http://radar.oreilly.com/2011/07/programmable-self-quantified-self.html",
      "display_url" : "radar.oreilly.com/2011/07/progra\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "91214257672306688",
  "text" : "If you want to know my thoughts on motivation/change, read this article on the programmable self! http://t.co/PUYgcXS /by @fredtrotter",
  "id" : 91214257672306688,
  "created_at" : "Wed Jul 13 18:35:48 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.605, -122.322667 ]
  },
  "id_str" : "91008704928956416",
  "text" : "8:36pm Spent quite a while trying to force someone to sleep http://flic.kr/p/a3dzUR",
  "id" : 91008704928956416,
  "created_at" : "Wed Jul 13 04:59:00 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amy Jo Kim",
      "screen_name" : "amyjokim",
      "indices" : [ 0, 9 ],
      "id_str" : "780991",
      "id" : 780991
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "90947403062067201",
  "geo" : {
  },
  "id_str" : "90950558676037632",
  "in_reply_to_user_id" : 780991,
  "text" : "@amyjokim I totally agree!  :)",
  "id" : 90950558676037632,
  "in_reply_to_status_id" : 90947403062067201,
  "created_at" : "Wed Jul 13 01:07:57 +0000 2011",
  "in_reply_to_screen_name" : "amyjokim",
  "in_reply_to_user_id_str" : "780991",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andres Moran",
      "screen_name" : "DreMoran",
      "indices" : [ 0, 9 ],
      "id_str" : "8461972",
      "id" : 8461972
    }, {
      "name" : "Emilio Ramirez",
      "screen_name" : "e_ramirez",
      "indices" : [ 10, 20 ],
      "id_str" : "1273564632",
      "id" : 1273564632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "90936663253073920",
  "geo" : {
  },
  "id_str" : "90938943545163778",
  "in_reply_to_user_id" : 8461972,
  "text" : "@DreMoran @e_ramirez I would get killed by his fast-moving feet, for sure. But I'd probably still accept the challenge. :)",
  "id" : 90938943545163778,
  "in_reply_to_status_id" : 90936663253073920,
  "created_at" : "Wed Jul 13 00:21:48 +0000 2011",
  "in_reply_to_screen_name" : "DreMoran",
  "in_reply_to_user_id_str" : "8461972",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emilio Ramirez",
      "screen_name" : "e_ramirez",
      "indices" : [ 0, 10 ],
      "id_str" : "1273564632",
      "id" : 1273564632
    }, {
      "name" : "Fitbit",
      "screen_name" : "fitbit",
      "indices" : [ 115, 122 ],
      "id_str" : "17424053",
      "id" : 17424053
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "90920141184970752",
  "geo" : {
  },
  "id_str" : "90933825558937600",
  "in_reply_to_user_id" : 21135674,
  "text" : "@e_ramirez Whew! Thanks for the challenge, that was great. And dang, 63 miles! What % of that is at your desk? /cc @fitbit",
  "id" : 90933825558937600,
  "in_reply_to_status_id" : 90920141184970752,
  "created_at" : "Wed Jul 13 00:01:28 +0000 2011",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.fitbit.com\" rel=\"nofollow\">Fitbit</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fitstats",
      "indices" : [ 21, 30 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "90919350910992384",
  "text" : "My avg. daily fitbit #fitstats for last week: 7,232 steps and 3.6 miles traveled. http://www.fitbit.com/user/229KX2",
  "id" : 90919350910992384,
  "created_at" : "Tue Jul 12 23:03:57 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Salinsky",
      "screen_name" : "AlexSalinsky",
      "indices" : [ 0, 13 ],
      "id_str" : "134531474",
      "id" : 134531474
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "90093076718161920",
  "geo" : {
  },
  "id_str" : "90892766263001088",
  "in_reply_to_user_id" : 134531474,
  "text" : "@AlexSalinsky Web-based? Mobile? Tweet yr education? Am I close? Oh, and sorry for slacking or reminding. How's the 20-minutes going today?",
  "id" : 90892766263001088,
  "in_reply_to_status_id" : 90093076718161920,
  "created_at" : "Tue Jul 12 21:18:18 +0000 2011",
  "in_reply_to_screen_name" : "AlexSalinsky",
  "in_reply_to_user_id_str" : "134531474",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "90892311818539008",
  "text" : "@GoalsGamified Oops, I fell off the reminder wagon! How is your nightly bedtime streak going?",
  "id" : 90892311818539008,
  "created_at" : "Tue Jul 12 21:16:30 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "katrina panovich",
      "screen_name" : "katrina_",
      "indices" : [ 0, 9 ],
      "id_str" : "9381242",
      "id" : 9381242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "89372232459104257",
  "geo" : {
  },
  "id_str" : "90891584970829824",
  "in_reply_to_user_id" : 9381242,
  "text" : "@katrina_ It's time to do yoga! Yeah? How 'bout it?",
  "id" : 90891584970829824,
  "in_reply_to_status_id" : 89372232459104257,
  "created_at" : "Tue Jul 12 21:13:37 +0000 2011",
  "in_reply_to_screen_name" : "katrina_",
  "in_reply_to_user_id_str" : "9381242",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Skotzko",
      "screen_name" : "askotzko",
      "indices" : [ 0, 9 ],
      "id_str" : "15391002",
      "id" : 15391002
    }, {
      "name" : "Namesake",
      "screen_name" : "Namesake",
      "indices" : [ 54, 63 ],
      "id_str" : "140496824",
      "id" : 140496824
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "90886663575846912",
  "geo" : {
  },
  "id_str" : "90890725717315585",
  "in_reply_to_user_id" : 15391002,
  "text" : "@askotzko Well done! And, I enjoyed the Jason Goldman @namesake this morning.",
  "id" : 90890725717315585,
  "in_reply_to_status_id" : 90886663575846912,
  "created_at" : "Tue Jul 12 21:10:12 +0000 2011",
  "in_reply_to_screen_name" : "askotzko",
  "in_reply_to_user_id_str" : "15391002",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carrie-Anne Gallo",
      "screen_name" : "CazMinx",
      "indices" : [ 0, 8 ],
      "id_str" : "20905374",
      "id" : 20905374
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "89959484759351296",
  "geo" : {
  },
  "id_str" : "90890036538638336",
  "in_reply_to_user_id" : 20905374,
  "text" : "@CazMinx However, my duties as tweet reminder have suffered. Any chance of treadmilling today or in the near future?",
  "id" : 90890036538638336,
  "in_reply_to_status_id" : 89959484759351296,
  "created_at" : "Tue Jul 12 21:07:28 +0000 2011",
  "in_reply_to_screen_name" : "CazMinx",
  "in_reply_to_user_id_str" : "20905374",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carrie-Anne Gallo",
      "screen_name" : "CazMinx",
      "indices" : [ 0, 8 ],
      "id_str" : "20905374",
      "id" : 20905374
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "89959484759351296",
  "geo" : {
  },
  "id_str" : "90889688470142977",
  "in_reply_to_user_id" : 20905374,
  "text" : "@CazMinx I agree with the method of doing measurable short-term goals that are fun. C25K sounds awesome.",
  "id" : 90889688470142977,
  "in_reply_to_status_id" : 89959484759351296,
  "created_at" : "Tue Jul 12 21:06:05 +0000 2011",
  "in_reply_to_screen_name" : "CazMinx",
  "in_reply_to_user_id_str" : "20905374",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Oliver",
      "screen_name" : "MikeOliver",
      "indices" : [ 0, 11 ],
      "id_str" : "993801636",
      "id" : 993801636
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "88808675803803648",
  "geo" : {
  },
  "id_str" : "90888711721598976",
  "in_reply_to_user_id" : 12866,
  "text" : "@mikeoliver No worries on slipping a day or so, I slipped in my reminder duties as well! Now we're even. How is today going so far?",
  "id" : 90888711721598976,
  "in_reply_to_status_id" : 88808675803803648,
  "created_at" : "Tue Jul 12 21:02:12 +0000 2011",
  "in_reply_to_screen_name" : "mkolvr",
  "in_reply_to_user_id_str" : "12866",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mozart",
      "screen_name" : "mgspeaks",
      "indices" : [ 0, 9 ],
      "id_str" : "217657761",
      "id" : 217657761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "89868587203952640",
  "geo" : {
  },
  "id_str" : "90888364173172736",
  "in_reply_to_user_id" : 217657761,
  "text" : "@mgspeaks Oops, I fell off the reminder wagon. Have you visited your favorite neighborhood project management app today?",
  "id" : 90888364173172736,
  "in_reply_to_status_id" : 89868587203952640,
  "created_at" : "Tue Jul 12 21:00:49 +0000 2011",
  "in_reply_to_screen_name" : "mgspeaks",
  "in_reply_to_user_id_str" : "217657761",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rafael Regales",
      "screen_name" : "bmorerican",
      "indices" : [ 0, 11 ],
      "id_str" : "23912695",
      "id" : 23912695
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "90072536175489024",
  "geo" : {
  },
  "id_str" : "90887731965739009",
  "in_reply_to_user_id" : 23912695,
  "text" : "@bmorerican Oops, I fell off the reminder wagon. Any treadmillery in the last couple days?  If not, today's your lucky day to tread!",
  "id" : 90887731965739009,
  "in_reply_to_status_id" : 90072536175489024,
  "created_at" : "Tue Jul 12 20:58:18 +0000 2011",
  "in_reply_to_screen_name" : "bmorerican",
  "in_reply_to_user_id_str" : "23912695",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jackie ",
      "screen_name" : "PatchworkJackie",
      "indices" : [ 0, 16 ],
      "id_str" : "241515860",
      "id" : 241515860
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "89538650248974337",
  "geo" : {
  },
  "id_str" : "90886881092452352",
  "in_reply_to_user_id" : 241515860,
  "text" : "@PatchworkJackie Oops, I fell off the reminder wagon for 2 days. How did your soda wagon fare? And how is it so far today?",
  "id" : 90886881092452352,
  "in_reply_to_status_id" : 89538650248974337,
  "created_at" : "Tue Jul 12 20:54:55 +0000 2011",
  "in_reply_to_screen_name" : "PatchworkJackie",
  "in_reply_to_user_id_str" : "241515860",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Skotzko",
      "screen_name" : "askotzko",
      "indices" : [ 0, 9 ],
      "id_str" : "15391002",
      "id" : 15391002
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "89522859088691201",
  "geo" : {
  },
  "id_str" : "90886560798621696",
  "in_reply_to_user_id" : 15391002,
  "text" : "@askotzko Oops, I fell off the reminder wagon for 2 days. How did your meditating wagon fare? Also, I see meditation in your near future.",
  "id" : 90886560798621696,
  "in_reply_to_status_id" : 89522859088691201,
  "created_at" : "Tue Jul 12 20:53:39 +0000 2011",
  "in_reply_to_screen_name" : "askotzko",
  "in_reply_to_user_id_str" : "15391002",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 49 ],
      "url" : "http://t.co/vgJCjlc",
      "expanded_url" : "http://lifepath.me/busterbenson",
      "display_url" : "lifepath.me/busterbenson"
    } ]
  },
  "geo" : {
  },
  "id_str" : "90851187418607616",
  "text" : "Uh oh, my life is 46.5% over. http://t.co/vgJCjlc (nicely done project, btw... will fill it out a bit more soon.)",
  "id" : 90851187418607616,
  "created_at" : "Tue Jul 12 18:33:05 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6065, -122.333667 ]
  },
  "id_str" : "90821448372985856",
  "text" : "8:36pm from last night. Got to see a great old friend from back in the day and her family. http://flic.kr/p/a331SF",
  "id" : 90821448372985856,
  "created_at" : "Tue Jul 12 16:34:55 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dustin curtis",
      "screen_name" : "dcurtis",
      "indices" : [ 0, 8 ],
      "id_str" : "9395832",
      "id" : 9395832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "89962919521034240",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.60679668, -122.32281255 ]
  },
  "id_str" : "90582017124737024",
  "in_reply_to_user_id" : 9395832,
  "text" : "@dcurtis I agree that it's stupid. But also found that the scaling up happened a lot more quickly than advertised.",
  "id" : 90582017124737024,
  "in_reply_to_status_id" : 89962919521034240,
  "created_at" : "Tue Jul 12 00:43:30 +0000 2011",
  "in_reply_to_screen_name" : "dcurtis",
  "in_reply_to_user_id_str" : "9395832",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Oberkirch",
      "screen_name" : "brianoberkirch",
      "indices" : [ 0, 15 ],
      "id_str" : "1293",
      "id" : 1293
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "90539452325314560",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6050378567, -122.3227849178 ]
  },
  "id_str" : "90577687617339393",
  "in_reply_to_user_id" : 1293,
  "text" : "@brianoberkirch Wait, that means you were in Seattle and didn't say hi! :) What were you here for?",
  "id" : 90577687617339393,
  "in_reply_to_status_id" : 90539452325314560,
  "created_at" : "Tue Jul 12 00:26:18 +0000 2011",
  "in_reply_to_screen_name" : "brianoberkirch",
  "in_reply_to_user_id_str" : "1293",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fitbit",
      "screen_name" : "fitbit",
      "indices" : [ 0, 7 ],
      "id_str" : "17424053",
      "id" : 17424053
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "90450102333865984",
  "geo" : {
  },
  "id_str" : "90453946954555392",
  "in_reply_to_user_id" : 17424053,
  "text" : "@fitbit Mac.",
  "id" : 90453946954555392,
  "in_reply_to_status_id" : 90450102333865984,
  "created_at" : "Mon Jul 11 16:14:36 +0000 2011",
  "in_reply_to_screen_name" : "fitbit",
  "in_reply_to_user_id_str" : "17424053",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.605, -122.322334 ]
  },
  "id_str" : "90264346562789377",
  "text" : "8:36pm Jimmy James and Michelle and their sausage hands! http://flic.kr/p/a2znt7",
  "id" : 90264346562789377,
  "created_at" : "Mon Jul 11 03:41:11 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6111250179, -122.3185954721 ]
  },
  "id_str" : "90195900625993728",
  "text" : "New word: ridylliculous. I hope to be able to use it soon.",
  "id" : 90195900625993728,
  "created_at" : "Sun Jul 10 23:09:13 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6054790309, -122.3244994904 ]
  },
  "id_str" : "90184869447081985",
  "text" : "I'm confused. Do consequences lead us to ideas of right and wrong or does right and wrong lead us to ideas of consequences?",
  "id" : 90184869447081985,
  "created_at" : "Sun Jul 10 22:25:23 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fitbit",
      "screen_name" : "fitbit",
      "indices" : [ 0, 7 ],
      "id_str" : "17424053",
      "id" : 17424053
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "90181230833827840",
  "in_reply_to_user_id" : 17424053,
  "text" : "@fitbit Is there any way to solve the problem of my Fitbit not syncing unless I disconnect and reconnect the dock every couple days?",
  "id" : 90181230833827840,
  "created_at" : "Sun Jul 10 22:10:55 +0000 2011",
  "in_reply_to_screen_name" : "fitbit",
  "in_reply_to_user_id_str" : "17424053",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "90105701808078848",
  "text" : "@GoalsGamified Yeah, probably can't sustain this amount of work, but I'm loving it and learning a lot about people. Give it a try!",
  "id" : 90105701808078848,
  "created_at" : "Sun Jul 10 17:10:48 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "chris dixon",
      "screen_name" : "cdixon",
      "indices" : [ 3, 10 ],
      "id_str" : "2529971",
      "id" : 2529971
    }, {
      "name" : "MG Siegler",
      "screen_name" : "parislemon",
      "indices" : [ 55, 66 ],
      "id_str" : "652193",
      "id" : 652193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 128 ],
      "url" : "http://t.co/5SBdXzv",
      "expanded_url" : "http://tcrn.ch/nQEMAK",
      "display_url" : "tcrn.ch/nQEMAK"
    } ]
  },
  "geo" : {
  },
  "id_str" : "90076946943324161",
  "text" : "RT @cdixon: Good coverage of mobile OS patent drama by @parislemon.  Most important story in tech right now. http://t.co/5SBdXzv",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "MG Siegler",
        "screen_name" : "parislemon",
        "indices" : [ 43, 54 ],
        "id_str" : "652193",
        "id" : 652193
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 97, 116 ],
        "url" : "http://t.co/5SBdXzv",
        "expanded_url" : "http://tcrn.ch/nQEMAK",
        "display_url" : "tcrn.ch/nQEMAK"
      } ]
    },
    "geo" : {
    },
    "id_str" : "90070556581433344",
    "text" : "Good coverage of mobile OS patent drama by @parislemon.  Most important story in tech right now. http://t.co/5SBdXzv",
    "id" : 90070556581433344,
    "created_at" : "Sun Jul 10 14:51:08 +0000 2011",
    "user" : {
      "name" : "chris dixon",
      "screen_name" : "cdixon",
      "protected" : false,
      "id_str" : "2529971",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2874406524/5ecf4e7907cbb226d8337704dd752dd5_normal.jpeg",
      "id" : 2529971,
      "verified" : true
    }
  },
  "id" : 90076946943324161,
  "created_at" : "Sun Jul 10 15:16:32 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Garry Tan",
      "screen_name" : "garrytan",
      "indices" : [ 17, 26 ],
      "id_str" : "11768582",
      "id" : 11768582
    }, {
      "name" : "eric gruber",
      "screen_name" : "Glitch",
      "indices" : [ 97, 104 ],
      "id_str" : "717043",
      "id" : 717043
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 129 ],
      "url" : "http://t.co/38TAwdS",
      "expanded_url" : "http://glitch.com/blog/2011/07/08/keita-takahashi-joins-glitch/",
      "display_url" : "glitch.com/blog/2011/07/0\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.60664951, -122.32278418 ]
  },
  "id_str" : "89961464152076289",
  "text" : "Wow! Perfect! RT @garrytan: Keita Takahashi, creator of Katamari Damacy and Noby Noby Boy, joins @Glitch Wow! http://t.co/38TAwdS",
  "id" : 89961464152076289,
  "created_at" : "Sun Jul 10 07:37:39 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jacqueline Hughes",
      "screen_name" : "JacquelinesLife",
      "indices" : [ 0, 16 ],
      "id_str" : "114284807",
      "id" : 114284807
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "89896079767764992",
  "geo" : {
  },
  "id_str" : "89947433135652865",
  "in_reply_to_user_id" : 114284807,
  "text" : "@JacquelinesLife Not yet, but maybe eventually. Mostly I just want to hear what the positive future sounds like from people.",
  "id" : 89947433135652865,
  "in_reply_to_status_id" : 89896079767764992,
  "created_at" : "Sun Jul 10 06:41:53 +0000 2011",
  "in_reply_to_screen_name" : "JacquelinesLife",
  "in_reply_to_user_id_str" : "114284807",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ingopixel",
      "screen_name" : "ingopixel",
      "indices" : [ 0, 10 ],
      "id_str" : "7943892",
      "id" : 7943892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "89938248117395456",
  "geo" : {
  },
  "id_str" : "89938634391818240",
  "in_reply_to_user_id" : 7943892,
  "text" : "@ingopixel Haha, love it. Can we get an update every 10 minutes? Who knew cats had an attention span?",
  "id" : 89938634391818240,
  "in_reply_to_status_id" : 89938248117395456,
  "created_at" : "Sun Jul 10 06:06:56 +0000 2011",
  "in_reply_to_screen_name" : "ingopixel",
  "in_reply_to_user_id_str" : "7943892",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 105 ],
      "url" : "http://t.co/JX3CmUk",
      "expanded_url" : "http://www.youtube.com/watch?v=_V4q-zb2iI4",
      "display_url" : "youtube.com/watch?v=_V4q-z\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "89906258689273857",
  "text" : "If you haven't seen Talking Funny, watch it here on the youtubes: pt 1 starting here: http://t.co/JX3CmUk",
  "id" : 89906258689273857,
  "created_at" : "Sun Jul 10 03:58:17 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 34, 42 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.605166, -122.322667 ]
  },
  "id_str" : "89901708569886720",
  "text" : "8:36pm Watching the Talking Funny @YouTube series with Seinfeld, Chris Rock, Ricky Gervais, and Louis CK. Hilarious. http://flic.kr/p/a2d9AN",
  "id" : 89901708569886720,
  "created_at" : "Sun Jul 10 03:40:12 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kaitlyn Shapiro",
      "screen_name" : "annelessing",
      "indices" : [ 0, 12 ],
      "id_str" : "230268499",
      "id" : 230268499
    }, {
      "name" : "NaNoWriMo",
      "screen_name" : "NaNoWriMo",
      "indices" : [ 102, 112 ],
      "id_str" : "8984102",
      "id" : 8984102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "89883862464856064",
  "geo" : {
  },
  "id_str" : "89884225297317888",
  "in_reply_to_user_id" : 230268499,
  "text" : "@annelessing That's insanely great. So you're choosing August for yours? Have you done it before? /cc @nanowrimo",
  "id" : 89884225297317888,
  "in_reply_to_status_id" : 89883862464856064,
  "created_at" : "Sun Jul 10 02:30:43 +0000 2011",
  "in_reply_to_screen_name" : "annelessing",
  "in_reply_to_user_id_str" : "230268499",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sydney",
      "screen_name" : "sydmarkle",
      "indices" : [ 0, 10 ],
      "id_str" : "2665",
      "id" : 2665
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "89883577088622593",
  "geo" : {
  },
  "id_str" : "89883896556158977",
  "in_reply_to_user_id" : 2665,
  "text" : "@sydmarkle Have you tried healthmonth.com? These questions are inspired by my attempt at building some new features for it.",
  "id" : 89883896556158977,
  "in_reply_to_status_id" : 89883577088622593,
  "created_at" : "Sun Jul 10 02:29:25 +0000 2011",
  "in_reply_to_screen_name" : "sydmarkle",
  "in_reply_to_user_id_str" : "2665",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kaitlyn Shapiro",
      "screen_name" : "annelessing",
      "indices" : [ 0, 12 ],
      "id_str" : "230268499",
      "id" : 230268499
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "campnano",
      "indices" : [ 26, 35 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "89883030512087040",
  "geo" : {
  },
  "id_str" : "89883306333708288",
  "in_reply_to_user_id" : 230268499,
  "text" : "@annelessing Whoa! What's #campnano all about? It's hardly Novemberish around here these days.",
  "id" : 89883306333708288,
  "in_reply_to_status_id" : 89883030512087040,
  "created_at" : "Sun Jul 10 02:27:04 +0000 2011",
  "in_reply_to_screen_name" : "annelessing",
  "in_reply_to_user_id_str" : "230268499",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Derek Shanahooligan",
      "screen_name" : "dshanahan",
      "indices" : [ 0, 10 ],
      "id_str" : "992071682",
      "id" : 992071682
    }, {
      "name" : "Foodtree",
      "screen_name" : "foodtree",
      "indices" : [ 20, 29 ],
      "id_str" : "55010291",
      "id" : 55010291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "89879510853500929",
  "geo" : {
  },
  "id_str" : "89881494100779008",
  "in_reply_to_user_id" : 6579512,
  "text" : "@dshanahan Awesome! @foodtree looks very cool... gonna check it out.  It's your thing?",
  "id" : 89881494100779008,
  "in_reply_to_status_id" : 89879510853500929,
  "created_at" : "Sun Jul 10 02:19:52 +0000 2011",
  "in_reply_to_screen_name" : "dshan",
  "in_reply_to_user_id_str" : "6579512",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sydney",
      "screen_name" : "sydmarkle",
      "indices" : [ 0, 10 ],
      "id_str" : "2665",
      "id" : 2665
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "89877814047801345",
  "geo" : {
  },
  "id_str" : "89879190396080128",
  "in_reply_to_user_id" : 2665,
  "text" : "@sydmarkle I like that! Now, how far are you from that? What's the main obstacle?",
  "id" : 89879190396080128,
  "in_reply_to_status_id" : 89877814047801345,
  "created_at" : "Sun Jul 10 02:10:43 +0000 2011",
  "in_reply_to_screen_name" : "sydmarkle",
  "in_reply_to_user_id_str" : "2665",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "89876927606833152",
  "text" : "Mine is, \"I can do 10 pullups, Niko's sleeping through the night without me, and I have a demo-able new mobile app.\"",
  "id" : 89876927606833152,
  "created_at" : "Sun Jul 10 02:01:44 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "89876653374840833",
  "text" : "What would you say about your life a month from now if you were able to do everything you want to do?",
  "id" : 89876653374840833,
  "created_at" : "Sun Jul 10 02:00:38 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carrie-Anne Gallo",
      "screen_name" : "CazMinx",
      "indices" : [ 0, 8 ],
      "id_str" : "20905374",
      "id" : 20905374
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "89872493816459265",
  "geo" : {
  },
  "id_str" : "89873695430025216",
  "in_reply_to_user_id" : 20905374,
  "text" : "@CazMinx Ha, I know how that goes. So what inspired you to do C25K in the first place?",
  "id" : 89873695430025216,
  "in_reply_to_status_id" : 89872493816459265,
  "created_at" : "Sun Jul 10 01:48:53 +0000 2011",
  "in_reply_to_screen_name" : "CazMinx",
  "in_reply_to_user_id_str" : "20905374",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Salinsky",
      "screen_name" : "AlexSalinsky",
      "indices" : [ 0, 13 ],
      "id_str" : "134531474",
      "id" : 134531474
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "89160490894360576",
  "geo" : {
  },
  "id_str" : "89870733769048064",
  "in_reply_to_user_id" : 134531474,
  "text" : "@AlexSalinsky How's that secret project going today? Think you can get 20 minutes in before the end of the night?",
  "id" : 89870733769048064,
  "in_reply_to_status_id" : 89160490894360576,
  "created_at" : "Sun Jul 10 01:37:07 +0000 2011",
  "in_reply_to_screen_name" : "AlexSalinsky",
  "in_reply_to_user_id_str" : "134531474",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "89870455833501696",
  "text" : "@GoalsGamified 3 days is definitely a streak. Congrats! Right now I'm trying to figure out if this kind of reminder system works. Thoughts?",
  "id" : 89870455833501696,
  "created_at" : "Sun Jul 10 01:36:01 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "katrina panovich",
      "screen_name" : "katrina_",
      "indices" : [ 0, 9 ],
      "id_str" : "9381242",
      "id" : 9381242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "89372232459104257",
  "geo" : {
  },
  "id_str" : "89870119467098112",
  "in_reply_to_user_id" : 9381242,
  "text" : "@katrina_ Didn't hear from you yesterday. How often do you normally do yoga, and how often do you want to do it? What's the main obstacle?",
  "id" : 89870119467098112,
  "in_reply_to_status_id" : 89372232459104257,
  "created_at" : "Sun Jul 10 01:34:40 +0000 2011",
  "in_reply_to_screen_name" : "katrina_",
  "in_reply_to_user_id_str" : "9381242",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mozart",
      "screen_name" : "mgspeaks",
      "indices" : [ 0, 9 ],
      "id_str" : "217657761",
      "id" : 217657761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "89868587203952640",
  "geo" : {
  },
  "id_str" : "89869486773112832",
  "in_reply_to_user_id" : 217657761,
  "text" : "@mgspeaks My biggest productivity improvement is letting myself take breaks/days off when I'm burned out. Then, tracking my work.",
  "id" : 89869486773112832,
  "in_reply_to_status_id" : 89868587203952640,
  "created_at" : "Sun Jul 10 01:32:10 +0000 2011",
  "in_reply_to_screen_name" : "mgspeaks",
  "in_reply_to_user_id_str" : "217657761",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mozart",
      "screen_name" : "mgspeaks",
      "indices" : [ 0, 9 ],
      "id_str" : "217657761",
      "id" : 217657761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "89868514051096576",
  "geo" : {
  },
  "id_str" : "89869298859900928",
  "in_reply_to_user_id" : 217657761,
  "text" : "@mgspeaks Right now, I am keeping all of the threads in a Google Doc. :)",
  "id" : 89869298859900928,
  "in_reply_to_status_id" : 89868514051096576,
  "created_at" : "Sun Jul 10 01:31:25 +0000 2011",
  "in_reply_to_screen_name" : "mgspeaks",
  "in_reply_to_user_id_str" : "217657761",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carrie-Anne Gallo",
      "screen_name" : "CazMinx",
      "indices" : [ 0, 8 ],
      "id_str" : "20905374",
      "id" : 20905374
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "89627421309026304",
  "geo" : {
  },
  "id_str" : "89868777512124416",
  "in_reply_to_user_id" : 20905374,
  "text" : "@CazMinx I wish I was motivated enough to do yoga. How did it go yesterday? What's the plan today? Treadmill? Yoga? Heater sitting? :)",
  "id" : 89868777512124416,
  "in_reply_to_status_id" : 89627421309026304,
  "created_at" : "Sun Jul 10 01:29:20 +0000 2011",
  "in_reply_to_screen_name" : "CazMinx",
  "in_reply_to_user_id_str" : "20905374",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Oliver",
      "screen_name" : "MikeOliver",
      "indices" : [ 0, 11 ],
      "id_str" : "993801636",
      "id" : 993801636
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "89677890333065216",
  "geo" : {
  },
  "id_str" : "89868130700103681",
  "in_reply_to_user_id" : 12866,
  "text" : "@mikeoliver Well staying strong at 3 is pretty awesome too.  50% impr. maintained! Good luck going for 2 today... lemme know how it goes.",
  "id" : 89868130700103681,
  "in_reply_to_status_id" : 89677890333065216,
  "created_at" : "Sun Jul 10 01:26:46 +0000 2011",
  "in_reply_to_screen_name" : "mkolvr",
  "in_reply_to_user_id_str" : "12866",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mozart",
      "screen_name" : "mgspeaks",
      "indices" : [ 0, 9 ],
      "id_str" : "217657761",
      "id" : 217657761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "89541736195563521",
  "geo" : {
  },
  "id_str" : "89867742391439362",
  "in_reply_to_user_id" : 217657761,
  "text" : "@mgspeaks Sorry for the confusing message yesterday, Got some info mixed up. Did you get a chance to check the software yesterday or today?",
  "id" : 89867742391439362,
  "in_reply_to_status_id" : 89541736195563521,
  "created_at" : "Sun Jul 10 01:25:14 +0000 2011",
  "in_reply_to_screen_name" : "mgspeaks",
  "in_reply_to_user_id_str" : "217657761",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rafael Regales",
      "screen_name" : "bmorerican",
      "indices" : [ 0, 11 ],
      "id_str" : "23912695",
      "id" : 23912695
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "89136483264507904",
  "geo" : {
  },
  "id_str" : "89867483657416704",
  "in_reply_to_user_id" : 23912695,
  "text" : "@bmorerican Walking is pretty awesome too. I am lucky to be able to walk to work. Okay, how's the bike looking today?",
  "id" : 89867483657416704,
  "in_reply_to_status_id" : 89136483264507904,
  "created_at" : "Sun Jul 10 01:24:12 +0000 2011",
  "in_reply_to_screen_name" : "bmorerican",
  "in_reply_to_user_id_str" : "23912695",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jackie ",
      "screen_name" : "PatchworkJackie",
      "indices" : [ 0, 16 ],
      "id_str" : "241515860",
      "id" : 241515860
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "89538650248974337",
  "geo" : {
  },
  "id_str" : "89867137895776256",
  "in_reply_to_user_id" : 241515860,
  "text" : "@PatchworkJackie Twizzlers... there's some fruit in there, right? :/ In any case, great job! How is today going so far?",
  "id" : 89867137895776256,
  "in_reply_to_status_id" : 89538650248974337,
  "created_at" : "Sun Jul 10 01:22:49 +0000 2011",
  "in_reply_to_screen_name" : "PatchworkJackie",
  "in_reply_to_user_id_str" : "241515860",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Skotzko",
      "screen_name" : "askotzko",
      "indices" : [ 0, 9 ],
      "id_str" : "15391002",
      "id" : 15391002
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "89522859088691201",
  "geo" : {
  },
  "id_str" : "89866800984104961",
  "in_reply_to_user_id" : 15391002,
  "text" : "@askotzko I'm glad that worked! What numbers are you crunching, that's one of my favorite hobbies. \n\nPS. It's meditate o'clock!",
  "id" : 89866800984104961,
  "in_reply_to_status_id" : 89522859088691201,
  "created_at" : "Sun Jul 10 01:21:29 +0000 2011",
  "in_reply_to_screen_name" : "askotzko",
  "in_reply_to_user_id_str" : "15391002",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carinna Tarvin",
      "screen_name" : "carinnatarvin",
      "indices" : [ 0, 14 ],
      "id_str" : "20833838",
      "id" : 20833838
    }, {
      "name" : "ingopixel",
      "screen_name" : "ingopixel",
      "indices" : [ 15, 25 ],
      "id_str" : "7943892",
      "id" : 7943892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 88 ],
      "url" : "http://t.co/GLo6CKt",
      "expanded_url" : "http://www.whfoods.com/genpage.php?tname=foodspice&dbid=5",
      "display_url" : "whfoods.com/genpage.php?tn\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "89817445547786240",
  "geo" : {
  },
  "id_str" : "89822071491805184",
  "in_reply_to_user_id" : 20833838,
  "text" : "@carinnatarvin @ingopixel What? Blasphemy. Avocados are all awesome. http://t.co/GLo6CKt",
  "id" : 89822071491805184,
  "in_reply_to_status_id" : 89817445547786240,
  "created_at" : "Sat Jul 09 22:23:45 +0000 2011",
  "in_reply_to_screen_name" : "carinnatarvin",
  "in_reply_to_user_id_str" : "20833838",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave McClure",
      "screen_name" : "davemcclure",
      "indices" : [ 39, 51 ],
      "id_str" : "1081",
      "id" : 1081
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "89547625736581121",
  "text" : "I like that. Gets truer by the day. RT @davemcclure: quotable me: \"We stand on the shoulders of midgets, not giants. (LOTS of midgets)",
  "id" : 89547625736581121,
  "created_at" : "Sat Jul 09 04:13:12 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Loving",
      "screen_name" : "adamloving",
      "indices" : [ 0, 11 ],
      "id_str" : "809641",
      "id" : 809641
    }, {
      "name" : "Klout",
      "screen_name" : "klout",
      "indices" : [ 55, 61 ],
      "id_str" : "15134782",
      "id" : 15134782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "89544101258723328",
  "geo" : {
  },
  "id_str" : "89544408340496384",
  "in_reply_to_user_id" : 809641,
  "text" : "@adamloving Me too. And it's probably going to help my @klout too!  Haha.",
  "id" : 89544408340496384,
  "in_reply_to_status_id" : 89544101258723328,
  "created_at" : "Sat Jul 09 04:00:25 +0000 2011",
  "in_reply_to_screen_name" : "adamloving",
  "in_reply_to_user_id_str" : "809641",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Loving",
      "screen_name" : "adamloving",
      "indices" : [ 0, 11 ],
      "id_str" : "809641",
      "id" : 809641
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "89543657685909504",
  "geo" : {
  },
  "id_str" : "89543850305126401",
  "in_reply_to_user_id" : 809641,
  "text" : "@adamloving Yes, but I'm also following up with each person who answered for a week to see if the social loops work/are interesting.",
  "id" : 89543850305126401,
  "in_reply_to_status_id" : 89543657685909504,
  "created_at" : "Sat Jul 09 03:58:12 +0000 2011",
  "in_reply_to_screen_name" : "adamloving",
  "in_reply_to_user_id_str" : "809641",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Loving",
      "screen_name" : "adamloving",
      "indices" : [ 0, 11 ],
      "id_str" : "809641",
      "id" : 809641
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 115 ],
      "url" : "http://t.co/IBjsXK1",
      "expanded_url" : "http://busterbenson.com/thinkup/post/?t=88725528424624128&n=twitter",
      "display_url" : "busterbenson.com/thinkup/post/?\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "89541845666897920",
  "geo" : {
  },
  "id_str" : "89542794217140224",
  "in_reply_to_user_id" : 809641,
  "text" : "@adamloving I've been asking qs on Twitter to gauge interest on a few ideas I'm working on (ie: http://t.co/IBjsXK1). Budge = new app.",
  "id" : 89542794217140224,
  "in_reply_to_status_id" : 89541845666897920,
  "created_at" : "Sat Jul 09 03:54:00 +0000 2011",
  "in_reply_to_screen_name" : "adamloving",
  "in_reply_to_user_id_str" : "809641",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mozart",
      "screen_name" : "mgspeaks",
      "indices" : [ 0, 9 ],
      "id_str" : "217657761",
      "id" : 217657761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "89541736195563521",
  "geo" : {
  },
  "id_str" : "89542183744577537",
  "in_reply_to_user_id" : 217657761,
  "text" : "@mgspeaks Ah, I just meant to only spend a few minutes with it instead of getting fully into the depths, if that helped justify it.",
  "id" : 89542183744577537,
  "in_reply_to_status_id" : 89541736195563521,
  "created_at" : "Sat Jul 09 03:51:34 +0000 2011",
  "in_reply_to_screen_name" : "mgspeaks",
  "in_reply_to_user_id_str" : "217657761",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mozart",
      "screen_name" : "mgspeaks",
      "indices" : [ 0, 9 ],
      "id_str" : "217657761",
      "id" : 217657761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "89541240357519360",
  "geo" : {
  },
  "id_str" : "89541386264776704",
  "in_reply_to_user_id" : 217657761,
  "text" : "@mgspeaks If 20 minutes is too tough to justify, try 10! Or 5!",
  "id" : 89541386264776704,
  "in_reply_to_status_id" : 89541240357519360,
  "created_at" : "Sat Jul 09 03:48:24 +0000 2011",
  "in_reply_to_screen_name" : "mgspeaks",
  "in_reply_to_user_id_str" : "217657761",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rafael Regales",
      "screen_name" : "bmorerican",
      "indices" : [ 0, 11 ],
      "id_str" : "23912695",
      "id" : 23912695
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "89540812395909120",
  "geo" : {
  },
  "id_str" : "89541089475829760",
  "in_reply_to_user_id" : 23912695,
  "text" : "@bmorerican Well, if you have time for a break, you should try it for just 5 minutes! The brain works better when heart rate is up!",
  "id" : 89541089475829760,
  "in_reply_to_status_id" : 89540812395909120,
  "created_at" : "Sat Jul 09 03:47:13 +0000 2011",
  "in_reply_to_screen_name" : "bmorerican",
  "in_reply_to_user_id_str" : "23912695",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.605166, -122.322667 ]
  },
  "id_str" : "89538957641134080",
  "text" : "8:36pm Questions on Twitter are the new minimum viable product. Learning exciting stuff! http://flic.kr/p/a1Vkbs",
  "id" : 89538957641134080,
  "created_at" : "Sat Jul 09 03:38:45 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jackie ",
      "screen_name" : "PatchworkJackie",
      "indices" : [ 0, 16 ],
      "id_str" : "241515860",
      "id" : 241515860
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "89530572992544768",
  "geo" : {
  },
  "id_str" : "89531977702719489",
  "in_reply_to_user_id" : 241515860,
  "text" : "@PatchworkJackie PS. Well done on the movie-theater resist. That's some sweet ninja soda avoidance moves you've got.",
  "id" : 89531977702719489,
  "in_reply_to_status_id" : 89530572992544768,
  "created_at" : "Sat Jul 09 03:11:01 +0000 2011",
  "in_reply_to_screen_name" : "PatchworkJackie",
  "in_reply_to_user_id_str" : "241515860",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jackie ",
      "screen_name" : "PatchworkJackie",
      "indices" : [ 0, 16 ],
      "id_str" : "241515860",
      "id" : 241515860
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "89530572992544768",
  "geo" : {
  },
  "id_str" : "89530815331053569",
  "in_reply_to_user_id" : 241515860,
  "text" : "@PatchworkJackie If you have a Whole Foods or Trader Joe's, definitely look for Dry Soda. I'll eat my hat if you don't like it. :)",
  "id" : 89530815331053569,
  "in_reply_to_status_id" : 89530572992544768,
  "created_at" : "Sat Jul 09 03:06:24 +0000 2011",
  "in_reply_to_screen_name" : "PatchworkJackie",
  "in_reply_to_user_id_str" : "241515860",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Salinsky",
      "screen_name" : "AlexSalinsky",
      "indices" : [ 0, 13 ],
      "id_str" : "134531474",
      "id" : 134531474
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "89160490894360576",
  "geo" : {
  },
  "id_str" : "89526630762029057",
  "in_reply_to_user_id" : 134531474,
  "text" : "@AlexSalinsky Something about health education? Am I close? Also... did you find your 20 minutes for secret plotting today?",
  "id" : 89526630762029057,
  "in_reply_to_status_id" : 89160490894360576,
  "created_at" : "Sat Jul 09 02:49:46 +0000 2011",
  "in_reply_to_screen_name" : "AlexSalinsky",
  "in_reply_to_user_id_str" : "134531474",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "89526366181142528",
  "text" : "@goalsgamified If you're on the east coast, I hope you're in bed already. If you're on the west coast, you have 2 hours to get ready!  :)",
  "id" : 89526366181142528,
  "created_at" : "Sat Jul 09 02:48:43 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "katrina panovich",
      "screen_name" : "katrina_",
      "indices" : [ 0, 9 ],
      "id_str" : "9381242",
      "id" : 9381242
    }, {
      "name" : "Marianne Elliott",
      "screen_name" : "zenpeacekeeper",
      "indices" : [ 99, 114 ],
      "id_str" : "35667496",
      "id" : 35667496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 95 ],
      "url" : "http://t.co/F74DU3l",
      "expanded_url" : "http://marianne-elliott.com/courses/30-days-of-yoga/",
      "display_url" : "marianne-elliott.com/courses/30-day\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "89372232459104257",
  "geo" : {
  },
  "id_str" : "89526005043183617",
  "in_reply_to_user_id" : 9381242,
  "text" : "@katrina_ & have you done at least 1 min of yoga yet today? & have you seen http://t.co/F74DU3l by @zenpeacekeeper? My wife raved about it.",
  "id" : 89526005043183617,
  "in_reply_to_status_id" : 89372232459104257,
  "created_at" : "Sat Jul 09 02:47:17 +0000 2011",
  "in_reply_to_screen_name" : "katrina_",
  "in_reply_to_user_id_str" : "9381242",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "katrina panovich",
      "screen_name" : "katrina_",
      "indices" : [ 0, 9 ],
      "id_str" : "9381242",
      "id" : 9381242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "89372232459104257",
  "geo" : {
  },
  "id_str" : "89525573063413761",
  "in_reply_to_user_id" : 9381242,
  "text" : "@katrina_ Well, let's see if some outside pressure helps at all. What is your preferred yogic environment?",
  "id" : 89525573063413761,
  "in_reply_to_status_id" : 89372232459104257,
  "created_at" : "Sat Jul 09 02:45:34 +0000 2011",
  "in_reply_to_screen_name" : "katrina_",
  "in_reply_to_user_id_str" : "9381242",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carrie-Anne Gallo",
      "screen_name" : "CazMinx",
      "indices" : [ 0, 8 ],
      "id_str" : "20905374",
      "id" : 20905374
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "89248776841199616",
  "geo" : {
  },
  "id_str" : "89525057906409472",
  "in_reply_to_user_id" : 20905374,
  "text" : "@CazMinx Also, it serves the same function of heating you up that sitting next to heater does. Did you run for at least 1 minute today yet?",
  "id" : 89525057906409472,
  "in_reply_to_status_id" : 89248776841199616,
  "created_at" : "Sat Jul 09 02:43:31 +0000 2011",
  "in_reply_to_screen_name" : "CazMinx",
  "in_reply_to_user_id_str" : "20905374",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carrie-Anne Gallo",
      "screen_name" : "CazMinx",
      "indices" : [ 0, 8 ],
      "id_str" : "20905374",
      "id" : 20905374
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "89248776841199616",
  "geo" : {
  },
  "id_str" : "89524861831094272",
  "in_reply_to_user_id" : 20905374,
  "text" : "@CazMinx The key (for me) to motivating to run is to not try to motivate. Just put on shoes in robot-like manner and hop on treadmill. :)",
  "id" : 89524861831094272,
  "in_reply_to_status_id" : 89248776841199616,
  "created_at" : "Sat Jul 09 02:42:45 +0000 2011",
  "in_reply_to_screen_name" : "CazMinx",
  "in_reply_to_user_id_str" : "20905374",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Oliver",
      "screen_name" : "MikeOliver",
      "indices" : [ 0, 11 ],
      "id_str" : "993801636",
      "id" : 993801636
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "89239759049854976",
  "geo" : {
  },
  "id_str" : "89524546767564800",
  "in_reply_to_user_id" : 12866,
  "text" : "@mikeoliver Nicely done! Do you like drinking water? How does it feel to be hydrated? And how many coffees did you have today? Less than 3?",
  "id" : 89524546767564800,
  "in_reply_to_status_id" : 89239759049854976,
  "created_at" : "Sat Jul 09 02:41:29 +0000 2011",
  "in_reply_to_screen_name" : "mkolvr",
  "in_reply_to_user_id_str" : "12866",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mozart",
      "screen_name" : "mgspeaks",
      "indices" : [ 0, 9 ],
      "id_str" : "217657761",
      "id" : 217657761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "88748373141749761",
  "geo" : {
  },
  "id_str" : "89524253011099648",
  "in_reply_to_user_id" : 217657761,
  "text" : "@mgspeaks How was your day? Did you stroll down to the neighborhood project management software sites and say hello?",
  "id" : 89524253011099648,
  "in_reply_to_status_id" : 88748373141749761,
  "created_at" : "Sat Jul 09 02:40:19 +0000 2011",
  "in_reply_to_screen_name" : "mgspeaks",
  "in_reply_to_user_id_str" : "217657761",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rafael Regales",
      "screen_name" : "bmorerican",
      "indices" : [ 0, 11 ],
      "id_str" : "23912695",
      "id" : 23912695
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "89172348250497026",
  "geo" : {
  },
  "id_str" : "89523849481293824",
  "in_reply_to_user_id" : 23912695,
  "text" : "@bmorerican I just watched all 5 seasons of the new Doctor Who... but it's not quite as highbrow. :) Did you get on the bike today?",
  "id" : 89523849481293824,
  "in_reply_to_status_id" : 89172348250497026,
  "created_at" : "Sat Jul 09 02:38:43 +0000 2011",
  "in_reply_to_screen_name" : "bmorerican",
  "in_reply_to_user_id_str" : "23912695",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jackie ",
      "screen_name" : "PatchworkJackie",
      "indices" : [ 0, 16 ],
      "id_str" : "241515860",
      "id" : 241515860
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "89162967299530752",
  "geo" : {
  },
  "id_str" : "89523610372411392",
  "in_reply_to_user_id" : 241515860,
  "text" : "@PatchworkJackie How did today go, on a scale of soda to awesome?",
  "id" : 89523610372411392,
  "in_reply_to_status_id" : 89162967299530752,
  "created_at" : "Sat Jul 09 02:37:46 +0000 2011",
  "in_reply_to_screen_name" : "PatchworkJackie",
  "in_reply_to_user_id_str" : "241515860",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Skotzko",
      "screen_name" : "askotzko",
      "indices" : [ 0, 9 ],
      "id_str" : "15391002",
      "id" : 15391002
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "89343155186565120",
  "geo" : {
  },
  "id_str" : "89522758219857920",
  "in_reply_to_user_id" : 15391002,
  "text" : "@askotzko Yeah, a Twitter question is the new MVP these days. Did you meditate today yet? If not, now's the time!",
  "id" : 89522758219857920,
  "in_reply_to_status_id" : 89343155186565120,
  "created_at" : "Sat Jul 09 02:34:23 +0000 2011",
  "in_reply_to_screen_name" : "askotzko",
  "in_reply_to_user_id_str" : "15391002",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Case",
      "screen_name" : "Case",
      "indices" : [ 0, 5 ],
      "id_str" : "409",
      "id" : 409
    }, {
      "name" : "Ali Berman",
      "screen_name" : "spangley",
      "indices" : [ 6, 15 ],
      "id_str" : "776429",
      "id" : 776429
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "89378805516468225",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6049951989, -122.3230236511 ]
  },
  "id_str" : "89396942840397824",
  "in_reply_to_user_id" : 409,
  "text" : "@Case @spangley It was the best crashed date with new friends I ever had! :)",
  "id" : 89396942840397824,
  "in_reply_to_status_id" : 89378805516468225,
  "created_at" : "Fri Jul 08 18:14:26 +0000 2011",
  "in_reply_to_screen_name" : "Case",
  "in_reply_to_user_id_str" : "409",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "noah kagan",
      "screen_name" : "noahkagan",
      "indices" : [ 3, 13 ],
      "id_str" : "13737",
      "id" : 13737
    }, {
      "name" : "Andrew Chen",
      "screen_name" : "andrewchen",
      "indices" : [ 16, 27 ],
      "id_str" : "3283901",
      "id" : 3283901
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 94 ],
      "url" : "http://t.co/bDoxcq2",
      "expanded_url" : "http://bit.ly/nKr0Ja",
      "display_url" : "bit.ly/nKr0Ja"
    } ]
  },
  "geo" : {
  },
  "id_str" : "89363832920739840",
  "text" : "RT @noahkagan: .@andrewchen is my favorite preacher.  Simple is Marketable http://t.co/bDoxcq2",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andrew Chen",
        "screen_name" : "andrewchen",
        "indices" : [ 1, 12 ],
        "id_str" : "3283901",
        "id" : 3283901
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 60, 79 ],
        "url" : "http://t.co/bDoxcq2",
        "expanded_url" : "http://bit.ly/nKr0Ja",
        "display_url" : "bit.ly/nKr0Ja"
      } ]
    },
    "geo" : {
    },
    "id_str" : "89359135245737984",
    "text" : ".@andrewchen is my favorite preacher.  Simple is Marketable http://t.co/bDoxcq2",
    "id" : 89359135245737984,
    "created_at" : "Fri Jul 08 15:44:12 +0000 2011",
    "user" : {
      "name" : "noah kagan",
      "screen_name" : "noahkagan",
      "protected" : false,
      "id_str" : "13737",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/14964642/Photo_21_normal.jpg",
      "id" : 13737,
      "verified" : false
    }
  },
  "id" : 89363832920739840,
  "created_at" : "Fri Jul 08 16:02:52 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Werner Vogels",
      "screen_name" : "Werner",
      "indices" : [ 3, 10 ],
      "id_str" : "113963",
      "id" : 113963
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "89363266257694720",
  "text" : "RT @Werner: scaling data systems in real life has humbled me. I would not dare criticize an architecture that the holds social graphs of ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "89358983718125568",
    "text" : "scaling data systems in real life has humbled me. I would not dare criticize an architecture that the holds social graphs of 750M and works",
    "id" : 89358983718125568,
    "created_at" : "Fri Jul 08 15:43:36 +0000 2011",
    "user" : {
      "name" : "Werner Vogels",
      "screen_name" : "Werner",
      "protected" : false,
      "id_str" : "113963",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1622235036/twitterava_normal.jpg",
      "id" : 113963,
      "verified" : false
    }
  },
  "id" : 89363266257694720,
  "created_at" : "Fri Jul 08 16:00:37 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Foundora",
      "screen_name" : "Foundora",
      "indices" : [ 125, 134 ],
      "id_str" : "148789825",
      "id" : 148789825
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 119 ],
      "url" : "http://t.co/xa4gQc1",
      "expanded_url" : "http://bit.ly/rbwGi7",
      "display_url" : "bit.ly/rbwGi7"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.60662943, -122.32282495 ]
  },
  "id_str" : "89345506018463745",
  "text" : "Who is the most influential person to you right now? Not necessarily the most obvious guess, right? http://t.co/xa4gQc1 /via @foundora",
  "id" : 89345506018463745,
  "created_at" : "Fri Jul 08 14:50:03 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Gauld",
      "screen_name" : "tomgauld",
      "indices" : [ 0, 9 ],
      "id_str" : "46090073",
      "id" : 46090073
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "89312318302851072",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6050452283, -122.3228355492 ]
  },
  "id_str" : "89328523998806018",
  "in_reply_to_user_id" : 46090073,
  "text" : "@tomgauld I love your handwriting font. Any plans on sharing or selling it?",
  "id" : 89328523998806018,
  "in_reply_to_status_id" : 89312318302851072,
  "created_at" : "Fri Jul 08 13:42:34 +0000 2011",
  "in_reply_to_screen_name" : "tomgauld",
  "in_reply_to_user_id_str" : "46090073",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ali Berman",
      "screen_name" : "spangley",
      "indices" : [ 0, 9 ],
      "id_str" : "776429",
      "id" : 776429
    }, {
      "name" : "Eric Case",
      "screen_name" : "Case",
      "indices" : [ 62, 67 ],
      "id_str" : "409",
      "id" : 409
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "89183297237819392",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6050625619, -122.3225427513 ]
  },
  "id_str" : "89185070233042946",
  "in_reply_to_user_id" : 776429,
  "text" : "@spangley Yes! That was a very important and awesome day! /cc @case",
  "id" : 89185070233042946,
  "in_reply_to_status_id" : 89183297237819392,
  "created_at" : "Fri Jul 08 04:12:32 +0000 2011",
  "in_reply_to_screen_name" : "spangley",
  "in_reply_to_user_id_str" : "776429",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.605, -122.322667 ]
  },
  "id_str" : "89179904800862209",
  "text" : "8:36pm Super excited to re-watch Grizzly Man with Kellianne http://flic.kr/p/a1DAUY",
  "id" : 89179904800862209,
  "created_at" : "Fri Jul 08 03:52:00 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carrie-Anne Gallo",
      "screen_name" : "CazMinx",
      "indices" : [ 0, 8 ],
      "id_str" : "20905374",
      "id" : 20905374
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "89156762200055808",
  "geo" : {
  },
  "id_str" : "89174370643214336",
  "in_reply_to_user_id" : 20905374,
  "text" : "@CazMinx True, polercise sounds like more fun! Maybe you need a good treadmill mix tape. Do you have any ideas for what would motivate?",
  "id" : 89174370643214336,
  "in_reply_to_status_id" : 89156762200055808,
  "created_at" : "Fri Jul 08 03:30:01 +0000 2011",
  "in_reply_to_screen_name" : "CazMinx",
  "in_reply_to_user_id_str" : "20905374",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Skotzko",
      "screen_name" : "askotzko",
      "indices" : [ 0, 9 ],
      "id_str" : "15391002",
      "id" : 15391002
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "89157909455437826",
  "geo" : {
  },
  "id_str" : "89168297106485248",
  "in_reply_to_user_id" : 15391002,
  "text" : "@askotzko Awesome. I'm just testing a few ideas about what motivates people, via Twitter. It's easier than building first. :)",
  "id" : 89168297106485248,
  "in_reply_to_status_id" : 89157909455437826,
  "created_at" : "Fri Jul 08 03:05:53 +0000 2011",
  "in_reply_to_screen_name" : "askotzko",
  "in_reply_to_user_id_str" : "15391002",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jackie ",
      "screen_name" : "PatchworkJackie",
      "indices" : [ 0, 16 ],
      "id_str" : "241515860",
      "id" : 241515860
    }, {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 34, 44 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 140 ],
      "url" : "http://t.co/NTbVjip",
      "expanded_url" : "http://www.drysoda.com/",
      "display_url" : "drysoda.com"
    } ]
  },
  "in_reply_to_status_id_str" : "89162967299530752",
  "geo" : {
  },
  "id_str" : "89165299898793985",
  "in_reply_to_user_id" : 241515860,
  "text" : "@PatchworkJackie It was a fave of @kellianne's while she was pregnant. Halfway b/t a cocktail and a soda, but healthier! http://t.co/NTbVjip",
  "id" : 89165299898793985,
  "in_reply_to_status_id" : 89162967299530752,
  "created_at" : "Fri Jul 08 02:53:58 +0000 2011",
  "in_reply_to_screen_name" : "PatchworkJackie",
  "in_reply_to_user_id_str" : "241515860",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jackie ",
      "screen_name" : "PatchworkJackie",
      "indices" : [ 0, 16 ],
      "id_str" : "241515860",
      "id" : 241515860
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "89156990785421312",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6095495617, -122.3253548346 ]
  },
  "id_str" : "89161528745525248",
  "in_reply_to_user_id" : 241515860,
  "text" : "@PatchworkJackie Kombucha is a lot stranger than tea. It's bubbly like soda too. How about Dry Soda? That's tasty.",
  "id" : 89161528745525248,
  "in_reply_to_status_id" : 89156990785421312,
  "created_at" : "Fri Jul 08 02:38:59 +0000 2011",
  "in_reply_to_screen_name" : "PatchworkJackie",
  "in_reply_to_user_id_str" : "241515860",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6095495617, -122.3253548346 ]
  },
  "id_str" : "89161028612530176",
  "text" : "Question: given a reasonable range of door key sizes, how many unique key possibilities are there? Order of magnitude-wise.",
  "id" : 89161028612530176,
  "created_at" : "Fri Jul 08 02:37:00 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jackie ",
      "screen_name" : "PatchworkJackie",
      "indices" : [ 0, 16 ],
      "id_str" : "241515860",
      "id" : 241515860
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "89146500487184384",
  "geo" : {
  },
  "id_str" : "89146744339841024",
  "in_reply_to_user_id" : 241515860,
  "text" : "@PatchworkJackie Where do you usually buy the soda? Do they sell Kombucha? It's an acquired taste but definitely healthy for you.",
  "id" : 89146744339841024,
  "in_reply_to_status_id" : 89146500487184384,
  "created_at" : "Fri Jul 08 01:40:14 +0000 2011",
  "in_reply_to_screen_name" : "PatchworkJackie",
  "in_reply_to_user_id_str" : "241515860",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jackie ",
      "screen_name" : "PatchworkJackie",
      "indices" : [ 0, 16 ],
      "id_str" : "241515860",
      "id" : 241515860
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "89135983760637952",
  "geo" : {
  },
  "id_str" : "89137395546603520",
  "in_reply_to_user_id" : 241515860,
  "text" : "@PatchworkJackie Awesome! Well done. Do you have a replacement habit for soda? What do you drink instead?",
  "id" : 89137395546603520,
  "in_reply_to_status_id" : 89135983760637952,
  "created_at" : "Fri Jul 08 01:03:05 +0000 2011",
  "in_reply_to_screen_name" : "PatchworkJackie",
  "in_reply_to_user_id_str" : "241515860",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rafael Regales",
      "screen_name" : "bmorerican",
      "indices" : [ 0, 11 ],
      "id_str" : "23912695",
      "id" : 23912695
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "89136483264507904",
  "geo" : {
  },
  "id_str" : "89137068420235264",
  "in_reply_to_user_id" : 23912695,
  "text" : "@bmorerican Okay, when are you gonna try to do it next?  Tomorrow or Saturday? Also, what's your favorite show on right now?",
  "id" : 89137068420235264,
  "in_reply_to_status_id" : 89136483264507904,
  "created_at" : "Fri Jul 08 01:01:47 +0000 2011",
  "in_reply_to_screen_name" : "bmorerican",
  "in_reply_to_user_id_str" : "23912695",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Salinsky",
      "screen_name" : "AlexSalinsky",
      "indices" : [ 0, 13 ],
      "id_str" : "134531474",
      "id" : 134531474
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "89060243555876864",
  "geo" : {
  },
  "id_str" : "89120223839531008",
  "in_reply_to_user_id" : 134531474,
  "text" : "@AlexSalinsky Have you done your 20 minutes of mystery side project work today yet? Any hints on what kind of side project it is?",
  "id" : 89120223839531008,
  "in_reply_to_status_id" : 89060243555876864,
  "created_at" : "Thu Jul 07 23:54:51 +0000 2011",
  "in_reply_to_screen_name" : "AlexSalinsky",
  "in_reply_to_user_id_str" : "134531474",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "89120001533030400",
  "text" : "@GoalsGamified Okay, today can be 2 days in a row for going to bed before 10. What do you do if you're not sleepy yet?",
  "id" : 89120001533030400,
  "created_at" : "Thu Jul 07 23:53:58 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carrie-Anne Gallo",
      "screen_name" : "CazMinx",
      "indices" : [ 0, 8 ],
      "id_str" : "20905374",
      "id" : 20905374
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "88804177689575424",
  "geo" : {
  },
  "id_str" : "89119471268147200",
  "in_reply_to_user_id" : 20905374,
  "text" : "@CazMinx Good work on getting on the treadmill yesterday. How about 2 days in a row? And do you have a 5k in mind yet?",
  "id" : 89119471268147200,
  "in_reply_to_status_id" : 88804177689575424,
  "created_at" : "Thu Jul 07 23:51:52 +0000 2011",
  "in_reply_to_screen_name" : "CazMinx",
  "in_reply_to_user_id_str" : "20905374",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Oliver",
      "screen_name" : "MikeOliver",
      "indices" : [ 0, 11 ],
      "id_str" : "993801636",
      "id" : 993801636
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "88808675803803648",
  "geo" : {
  },
  "id_str" : "89119290560749569",
  "in_reply_to_user_id" : 12866,
  "text" : "@mikeoliver Were you able to resist the coffees so far today? And how many glasses of water have you drunk so far?",
  "id" : 89119290560749569,
  "in_reply_to_status_id" : 88808675803803648,
  "created_at" : "Thu Jul 07 23:51:09 +0000 2011",
  "in_reply_to_screen_name" : "mkolvr",
  "in_reply_to_user_id_str" : "12866",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mozart",
      "screen_name" : "mgspeaks",
      "indices" : [ 0, 9 ],
      "id_str" : "217657761",
      "id" : 217657761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "88748373141749761",
  "geo" : {
  },
  "id_str" : "89119089003479040",
  "in_reply_to_user_id" : 217657761,
  "text" : "@mgspeaks Time to check nirvanaHQ and basecamp! What kind of projects are you managing in there?",
  "id" : 89119089003479040,
  "in_reply_to_status_id" : 88748373141749761,
  "created_at" : "Thu Jul 07 23:50:21 +0000 2011",
  "in_reply_to_screen_name" : "mgspeaks",
  "in_reply_to_user_id_str" : "217657761",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rafael Regales",
      "screen_name" : "bmorerican",
      "indices" : [ 0, 11 ],
      "id_str" : "23912695",
      "id" : 23912695
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "88756698537406464",
  "geo" : {
  },
  "id_str" : "89118850674737152",
  "in_reply_to_user_id" : 23912695,
  "text" : "@bmorerican Stationary bike day! Have you done it yet? How long do you usually go for & do you listen to a music or anything while riding?",
  "id" : 89118850674737152,
  "in_reply_to_status_id" : 88756698537406464,
  "created_at" : "Thu Jul 07 23:49:24 +0000 2011",
  "in_reply_to_screen_name" : "bmorerican",
  "in_reply_to_user_id_str" : "23912695",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jackie ",
      "screen_name" : "PatchworkJackie",
      "indices" : [ 0, 16 ],
      "id_str" : "241515860",
      "id" : 241515860
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "88728684571279361",
  "geo" : {
  },
  "id_str" : "89118488723075072",
  "in_reply_to_user_id" : 241515860,
  "text" : "@PatchworkJackie Have you gone all day so far without any soda? How many times have you successfully resisted?",
  "id" : 89118488723075072,
  "in_reply_to_status_id" : 88728684571279361,
  "created_at" : "Thu Jul 07 23:47:58 +0000 2011",
  "in_reply_to_screen_name" : "PatchworkJackie",
  "in_reply_to_user_id_str" : "241515860",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Skotzko",
      "screen_name" : "askotzko",
      "indices" : [ 0, 9 ],
      "id_str" : "15391002",
      "id" : 15391002
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "88727242401787904",
  "geo" : {
  },
  "id_str" : "89118259915390976",
  "in_reply_to_user_id" : 15391002,
  "text" : "@askotzko It's time to meditate! Let me know when you've done it (or if you already have).",
  "id" : 89118259915390976,
  "in_reply_to_status_id" : 88727242401787904,
  "created_at" : "Thu Jul 07 23:47:03 +0000 2011",
  "in_reply_to_screen_name" : "askotzko",
  "in_reply_to_user_id_str" : "15391002",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u24D5\u24E3",
      "screen_name" : "folktrash",
      "indices" : [ 51, 61 ],
      "id_str" : "15265271",
      "id" : 15265271
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 45 ],
      "url" : "http://t.co/YobHdq0",
      "expanded_url" : "http://theoatmeal.com/comics/wwddd",
      "display_url" : "theoatmeal.com/comics/wwddd"
    } ]
  },
  "geo" : {
  },
  "id_str" : "89082731434221569",
  "text" : "What would Don Draper do? http://t.co/YobHdq0 /via @folktrash",
  "id" : 89082731434221569,
  "created_at" : "Thu Jul 07 21:25:52 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thomas Knoll",
      "screen_name" : "thomasknoll",
      "indices" : [ 0, 12 ],
      "id_str" : "2874",
      "id" : 2874
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "89075568385064960",
  "geo" : {
  },
  "id_str" : "89081771907481602",
  "in_reply_to_user_id" : 2874,
  "text" : "@thomasknoll Ah, that's an interesting one. Know of any official hug studies?",
  "id" : 89081771907481602,
  "in_reply_to_status_id" : 89075568385064960,
  "created_at" : "Thu Jul 07 21:22:04 +0000 2011",
  "in_reply_to_screen_name" : "thomasknoll",
  "in_reply_to_user_id_str" : "2874",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laura Gluhanich",
      "screen_name" : "LauraGlu",
      "indices" : [ 0, 9 ],
      "id_str" : "9428232",
      "id" : 9428232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "89075327950794752",
  "geo" : {
  },
  "id_str" : "89081281069068290",
  "in_reply_to_user_id" : 9428232,
  "text" : "@LauraGlu This is very true. :) Actually, I'm just trying to see if my friends give me different ideas than I would come up with myself.",
  "id" : 89081281069068290,
  "in_reply_to_status_id" : 89075327950794752,
  "created_at" : "Thu Jul 07 21:20:07 +0000 2011",
  "in_reply_to_screen_name" : "LauraGlu",
  "in_reply_to_user_id_str" : "9428232",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carinna Tarvin",
      "screen_name" : "carinnatarvin",
      "indices" : [ 0, 14 ],
      "id_str" : "20833838",
      "id" : 20833838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "89063975182016513",
  "geo" : {
  },
  "id_str" : "89068064582279168",
  "in_reply_to_user_id" : 20833838,
  "text" : "@carinnatarvin No fair, you know my weaknesses!",
  "id" : 89068064582279168,
  "in_reply_to_status_id" : 89063975182016513,
  "created_at" : "Thu Jul 07 20:27:36 +0000 2011",
  "in_reply_to_screen_name" : "carinnatarvin",
  "in_reply_to_user_id_str" : "20833838",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "shehab hamad",
      "screen_name" : "shehabhamad",
      "indices" : [ 0, 12 ],
      "id_str" : "8485792",
      "id" : 8485792
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "89054734874460160",
  "geo" : {
  },
  "id_str" : "89056211244302336",
  "in_reply_to_user_id" : 8485792,
  "text" : "@shehabhamad I've been tempted a couple times. Do you think Paleo is the best diet out there? Do you combine it with CrossFit too?",
  "id" : 89056211244302336,
  "in_reply_to_status_id" : 89054734874460160,
  "created_at" : "Thu Jul 07 19:40:30 +0000 2011",
  "in_reply_to_screen_name" : "shehabhamad",
  "in_reply_to_user_id_str" : "8485792",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Meyers",
      "screen_name" : "jeremymeyers",
      "indices" : [ 0, 13 ],
      "id_str" : "16818880",
      "id" : 16818880
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "89054107343659009",
  "geo" : {
  },
  "id_str" : "89054657611186177",
  "in_reply_to_user_id" : 16818880,
  "text" : "@jeremymeyers Good advice! Luckily, I don't drink any soda at all. I do drink a lot of coffee though. What are your thoughts on that?",
  "id" : 89054657611186177,
  "in_reply_to_status_id" : 89054107343659009,
  "created_at" : "Thu Jul 07 19:34:19 +0000 2011",
  "in_reply_to_screen_name" : "jeremymeyers",
  "in_reply_to_user_id_str" : "16818880",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Jacobs",
      "screen_name" : "djacobs",
      "indices" : [ 0, 8 ],
      "id_str" : "774842",
      "id" : 774842
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "89053134130917377",
  "geo" : {
  },
  "id_str" : "89054503290146818",
  "in_reply_to_user_id" : 774842,
  "text" : "@djacobs I like that. Actually, my productivity maxes out at about 6 hours of work, but it sometimes takes a while to get started.",
  "id" : 89054503290146818,
  "in_reply_to_status_id" : 89053134130917377,
  "created_at" : "Thu Jul 07 19:33:42 +0000 2011",
  "in_reply_to_screen_name" : "djacobs",
  "in_reply_to_user_id_str" : "774842",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "girl jo",
      "screen_name" : "octavekitten",
      "indices" : [ 0, 13 ],
      "id_str" : "16366882",
      "id" : 16366882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "89053046956498944",
  "geo" : {
  },
  "id_str" : "89053216528019457",
  "in_reply_to_user_id" : 16366882,
  "text" : "@octavekitten All of the above. :) But maybe diet first, exercise second, and mental third.",
  "id" : 89053216528019457,
  "in_reply_to_status_id" : 89053046956498944,
  "created_at" : "Thu Jul 07 19:28:36 +0000 2011",
  "in_reply_to_screen_name" : "octavekitten",
  "in_reply_to_user_id_str" : "16366882",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "89052701144522752",
  "text" : "I want to be a little healthier than I currently am. If you know me at all, do you have any ideas for what should I do differently?",
  "id" : 89052701144522752,
  "created_at" : "Thu Jul 07 19:26:33 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "89031165717123072",
  "text" : "@GoalsGamified Ooh, that's a good one. I like it.  Did you get to bed before 10pm last night by chance?",
  "id" : 89031165717123072,
  "created_at" : "Thu Jul 07 18:00:58 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "katrina panovich",
      "screen_name" : "katrina_",
      "indices" : [ 0, 9 ],
      "id_str" : "9381242",
      "id" : 9381242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "88926212768014336",
  "geo" : {
  },
  "id_str" : "89030807305465856",
  "in_reply_to_user_id" : 9381242,
  "text" : "@katrina_ I can take one more! What's the habit you'd like to remind you about for a week?",
  "id" : 89030807305465856,
  "in_reply_to_status_id" : 88926212768014336,
  "created_at" : "Thu Jul 07 17:59:33 +0000 2011",
  "in_reply_to_screen_name" : "katrina_",
  "in_reply_to_user_id_str" : "9381242",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.604, -122.333834 ]
  },
  "id_str" : "88835595362762752",
  "text" : "8:36pm Was talking shop at Fado's with some new people http://flic.kr/p/a1jD52",
  "id" : 88835595362762752,
  "created_at" : "Thu Jul 07 05:03:51 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "indices" : [ 3, 15 ],
      "id_str" : "113436175",
      "id" : 113436175
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 80 ],
      "url" : "http://t.co/9qRGFKO",
      "expanded_url" : "http://1.usa.gov/pssAFO",
      "display_url" : "1.usa.gov/pssAFO"
    } ]
  },
  "geo" : {
  },
  "id_str" : "88834779973292033",
  "text" : "RT @jesseclee44: Full transcript of Obama Twitter town hall: http://t.co/9qRGFKO",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 44, 63 ],
        "url" : "http://t.co/9qRGFKO",
        "expanded_url" : "http://1.usa.gov/pssAFO",
        "display_url" : "1.usa.gov/pssAFO"
      } ]
    },
    "geo" : {
    },
    "id_str" : "88718421809827841",
    "text" : "Full transcript of Obama Twitter town hall: http://t.co/9qRGFKO",
    "id" : 88718421809827841,
    "created_at" : "Wed Jul 06 21:18:14 +0000 2011",
    "user" : {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "protected" : false,
      "id_str" : "113436175",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1366014303/wedding_profile4_cropped_normal.png",
      "id" : 113436175,
      "verified" : true
    }
  },
  "id" : 88834779973292033,
  "created_at" : "Thu Jul 07 05:00:36 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Oliver",
      "screen_name" : "MikeOliver",
      "indices" : [ 0, 11 ],
      "id_str" : "993801636",
      "id" : 993801636
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "88789858163765249",
  "geo" : {
  },
  "id_str" : "88797442979528705",
  "in_reply_to_user_id" : 12866,
  "text" : "@mikeoliver Great! Any particular kind of caffeine or all of them? Have you had any caffeine today? If so, how much?",
  "id" : 88797442979528705,
  "in_reply_to_status_id" : 88789858163765249,
  "created_at" : "Thu Jul 07 02:32:14 +0000 2011",
  "in_reply_to_screen_name" : "mkolvr",
  "in_reply_to_user_id_str" : "12866",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carrie-Anne Gallo",
      "screen_name" : "CazMinx",
      "indices" : [ 0, 8 ],
      "id_str" : "20905374",
      "id" : 20905374
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "88795176058892290",
  "geo" : {
  },
  "id_str" : "88795760925212672",
  "in_reply_to_user_id" : 20905374,
  "text" : "@CazMinx Will do! Have you gotten on the treadmill yet today?",
  "id" : 88795760925212672,
  "in_reply_to_status_id" : 88795176058892290,
  "created_at" : "Thu Jul 07 02:25:33 +0000 2011",
  "in_reply_to_screen_name" : "CazMinx",
  "in_reply_to_user_id_str" : "20905374",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Dole",
      "screen_name" : "adamdole",
      "indices" : [ 0, 9 ],
      "id_str" : "14789168",
      "id" : 14789168
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "88794066388660224",
  "geo" : {
  },
  "id_str" : "88794289844400128",
  "in_reply_to_user_id" : 14789168,
  "text" : "@adamdole 100% agree.  That was an ideal lifecycle. I think many feedbacks loops die at the data stage, before emotional relevance.",
  "id" : 88794289844400128,
  "in_reply_to_status_id" : 88794066388660224,
  "created_at" : "Thu Jul 07 02:19:43 +0000 2011",
  "in_reply_to_screen_name" : "adamdole",
  "in_reply_to_user_id_str" : "14789168",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emilio Ramirez",
      "screen_name" : "e_ramirez",
      "indices" : [ 0, 10 ],
      "id_str" : "1273564632",
      "id" : 1273564632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "88782877021581312",
  "geo" : {
  },
  "id_str" : "88783309785673730",
  "in_reply_to_user_id" : 21135674,
  "text" : "@e_ramirez So you take it on faith that it's true for now? Do you know how Fowler has responded? Has he shared the actual math publicly?",
  "id" : 88783309785673730,
  "in_reply_to_status_id" : 88782877021581312,
  "created_at" : "Thu Jul 07 01:36:05 +0000 2011",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emilio Ramirez",
      "screen_name" : "e_ramirez",
      "indices" : [ 0, 10 ],
      "id_str" : "1273564632",
      "id" : 1273564632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "88781984280743936",
  "geo" : {
  },
  "id_str" : "88782411361566721",
  "in_reply_to_user_id" : 21135674,
  "text" : "@e_ramirez Of course, but the study is science, and does need to have truth to it beyond what emotionally resonates with us, right?",
  "id" : 88782411361566721,
  "in_reply_to_status_id" : 88781984280743936,
  "created_at" : "Thu Jul 07 01:32:31 +0000 2011",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 139 ],
      "url" : "http://t.co/tD9QxQn",
      "expanded_url" : "http://www.wired.com/magazine/2011/06/ff_feedbackloop/all/1",
      "display_url" : "wired.com/magazine/2011/\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "88782264531566593",
  "text" : "Lifecycle of a feedback loop: \n\n1) action\n2) data\n3) emotional relevance\n4) related epiphany/consequence\n5) new action\n\nhttp://t.co/tD9QxQn",
  "id" : 88782264531566593,
  "created_at" : "Thu Jul 07 01:31:56 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emilio Ramirez",
      "screen_name" : "e_ramirez",
      "indices" : [ 0, 10 ],
      "id_str" : "1273564632",
      "id" : 1273564632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 113 ],
      "url" : "http://t.co/xsKF7Ml",
      "expanded_url" : "http://www.slate.com/id/2298208/pagenum/all/",
      "display_url" : "slate.com/id/2298208/pag\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "88780426201677824",
  "in_reply_to_user_id" : 21135674,
  "text" : "@e_ramirez Have you seen this article, potentially debunking Fowler's social contagion study? http://t.co/xsKF7Ml Thoughts?",
  "id" : 88780426201677824,
  "created_at" : "Thu Jul 07 01:24:37 +0000 2011",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Namesake",
      "screen_name" : "Namesake",
      "indices" : [ 13, 22 ],
      "id_str" : "140496824",
      "id" : 140496824
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 122 ],
      "url" : "http://t.co/jXy3lQU",
      "expanded_url" : "http://nmsk.co/oZZwBk",
      "display_url" : "nmsk.co/oZZwBk"
    } ]
  },
  "geo" : {
  },
  "id_str" : "88775551334088705",
  "text" : "Who is using @namesake? Just really checked it out today, and it looks awesome. Here's an invite link: http://t.co/jXy3lQU",
  "id" : 88775551334088705,
  "created_at" : "Thu Jul 07 01:05:15 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harry Kautzman II",
      "screen_name" : "hrrkii",
      "indices" : [ 0, 7 ],
      "id_str" : "18666865",
      "id" : 18666865
    }, {
      "name" : "david reeves",
      "screen_name" : "dreeves",
      "indices" : [ 8, 16 ],
      "id_str" : "947851",
      "id" : 947851
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "88720392046395393",
  "geo" : {
  },
  "id_str" : "88771404199247873",
  "in_reply_to_user_id" : 18666865,
  "text" : "@hrrkii @dreeves Dang, sounds like fun! Invite me next time!  :)",
  "id" : 88771404199247873,
  "in_reply_to_status_id" : 88720392046395393,
  "created_at" : "Thu Jul 07 00:48:46 +0000 2011",
  "in_reply_to_screen_name" : "hrrkii",
  "in_reply_to_user_id_str" : "18666865",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rafael Regales",
      "screen_name" : "bmorerican",
      "indices" : [ 0, 11 ],
      "id_str" : "23912695",
      "id" : 23912695
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "88756698537406464",
  "geo" : {
  },
  "id_str" : "88760931076685824",
  "in_reply_to_user_id" : 23912695,
  "text" : "@bmorerican Great. I'll check in tomorrow then to see how it's going.",
  "id" : 88760931076685824,
  "in_reply_to_status_id" : 88756698537406464,
  "created_at" : "Thu Jul 07 00:07:09 +0000 2011",
  "in_reply_to_screen_name" : "bmorerican",
  "in_reply_to_user_id_str" : "23912695",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mozart",
      "screen_name" : "mgspeaks",
      "indices" : [ 0, 9 ],
      "id_str" : "217657761",
      "id" : 217657761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "88748373141749761",
  "geo" : {
  },
  "id_str" : "88756282407919616",
  "in_reply_to_user_id" : 217657761,
  "text" : "@mgspeaks Participating in this low-tech reminder project is, in a round-about way, very helpful in its own way.  :)",
  "id" : 88756282407919616,
  "in_reply_to_status_id" : 88748373141749761,
  "created_at" : "Wed Jul 06 23:48:41 +0000 2011",
  "in_reply_to_screen_name" : "mgspeaks",
  "in_reply_to_user_id_str" : "217657761",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mozart",
      "screen_name" : "mgspeaks",
      "indices" : [ 0, 9 ],
      "id_str" : "217657761",
      "id" : 217657761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "88746879021617152",
  "geo" : {
  },
  "id_str" : "88747570486198272",
  "in_reply_to_user_id" : 217657761,
  "text" : "@mgspeaks Okay, got it now. I'll help you remember to check it out for the next week!",
  "id" : 88747570486198272,
  "in_reply_to_status_id" : 88746879021617152,
  "created_at" : "Wed Jul 06 23:14:04 +0000 2011",
  "in_reply_to_screen_name" : "mgspeaks",
  "in_reply_to_user_id_str" : "217657761",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u24D5\u24E3",
      "screen_name" : "folktrash",
      "indices" : [ 0, 10 ],
      "id_str" : "15265271",
      "id" : 15265271
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "88726425867268096",
  "geo" : {
  },
  "id_str" : "88745771477901313",
  "in_reply_to_user_id" : 15265271,
  "text" : "@folktrash It can be a private habit too if you just want me to vaguely remind you of things without knowing what they are.  :)",
  "id" : 88745771477901313,
  "in_reply_to_status_id" : 88726425867268096,
  "created_at" : "Wed Jul 06 23:06:55 +0000 2011",
  "in_reply_to_screen_name" : "folktrash",
  "in_reply_to_user_id_str" : "15265271",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mozart",
      "screen_name" : "mgspeaks",
      "indices" : [ 0, 9 ],
      "id_str" : "217657761",
      "id" : 217657761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "88730895082717184",
  "geo" : {
  },
  "id_str" : "88731607413952513",
  "in_reply_to_user_id" : 217657761,
  "text" : "@mgspeaks Cool, what's the software called.  Did you build it yourself? How do you use it?",
  "id" : 88731607413952513,
  "in_reply_to_status_id" : 88730895082717184,
  "created_at" : "Wed Jul 06 22:10:38 +0000 2011",
  "in_reply_to_screen_name" : "mgspeaks",
  "in_reply_to_user_id_str" : "217657761",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rafael Regales",
      "screen_name" : "bmorerican",
      "indices" : [ 0, 11 ],
      "id_str" : "23912695",
      "id" : 23912695
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "88729571221966848",
  "geo" : {
  },
  "id_str" : "88730229677371392",
  "in_reply_to_user_id" : 23912695,
  "text" : "@bmorerican Awesome. What do you do for workouts? And how often do you want to do it this week?",
  "id" : 88730229677371392,
  "in_reply_to_status_id" : 88729571221966848,
  "created_at" : "Wed Jul 06 22:05:09 +0000 2011",
  "in_reply_to_screen_name" : "bmorerican",
  "in_reply_to_user_id_str" : "23912695",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jackie ",
      "screen_name" : "PatchworkJackie",
      "indices" : [ 0, 16 ],
      "id_str" : "241515860",
      "id" : 241515860
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "88728684571279361",
  "geo" : {
  },
  "id_str" : "88728967749705728",
  "in_reply_to_user_id" : 241515860,
  "text" : "@PatchworkJackie Well done so far today! I think you can go a whole week without soda. Starting today.",
  "id" : 88728967749705728,
  "in_reply_to_status_id" : 88728684571279361,
  "created_at" : "Wed Jul 06 22:00:09 +0000 2011",
  "in_reply_to_screen_name" : "PatchworkJackie",
  "in_reply_to_user_id_str" : "241515860",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Skotzko",
      "screen_name" : "askotzko",
      "indices" : [ 0, 9 ],
      "id_str" : "15391002",
      "id" : 15391002
    }, {
      "name" : "Namesake",
      "screen_name" : "Namesake",
      "indices" : [ 60, 69 ],
      "id_str" : "140496824",
      "id" : 140496824
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "88727638453133313",
  "geo" : {
  },
  "id_str" : "88728105870557185",
  "in_reply_to_user_id" : 15391002,
  "text" : "@askotzko Yeah, what do I need to do to be a convo guest on @namesake? Sounds interesting. And how long have you been meditating?",
  "id" : 88728105870557185,
  "in_reply_to_status_id" : 88727638453133313,
  "created_at" : "Wed Jul 06 21:56:43 +0000 2011",
  "in_reply_to_screen_name" : "askotzko",
  "in_reply_to_user_id_str" : "15391002",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Skotzko",
      "screen_name" : "askotzko",
      "indices" : [ 0, 9 ],
      "id_str" : "15391002",
      "id" : 15391002
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "88727242401787904",
  "geo" : {
  },
  "id_str" : "88727391274405888",
  "in_reply_to_user_id" : 15391002,
  "text" : "@askotzko I've tried NSR and like it. But my practice is rather nonexistent. Maybe I'll do it for a week too!",
  "id" : 88727391274405888,
  "in_reply_to_status_id" : 88727242401787904,
  "created_at" : "Wed Jul 06 21:53:53 +0000 2011",
  "in_reply_to_screen_name" : "askotzko",
  "in_reply_to_user_id_str" : "15391002",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jackie ",
      "screen_name" : "PatchworkJackie",
      "indices" : [ 0, 16 ],
      "id_str" : "241515860",
      "id" : 241515860
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "88726414425198592",
  "geo" : {
  },
  "id_str" : "88727242422751232",
  "in_reply_to_user_id" : 241515860,
  "text" : "@PatchworkJackie Excellent.  I'll remind you for the next week.  Stop drinking soda! How many did you have today?",
  "id" : 88727242422751232,
  "in_reply_to_status_id" : 88726414425198592,
  "created_at" : "Wed Jul 06 21:53:17 +0000 2011",
  "in_reply_to_screen_name" : "PatchworkJackie",
  "in_reply_to_user_id_str" : "241515860",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Skotzko",
      "screen_name" : "askotzko",
      "indices" : [ 0, 9 ],
      "id_str" : "15391002",
      "id" : 15391002
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "88725629633175552",
  "geo" : {
  },
  "id_str" : "88727118749511680",
  "in_reply_to_user_id" : 15391002,
  "text" : "@askotzko Got it. I'll be asking you about it every day for a week. Good luck! What kind of meditation do you do?",
  "id" : 88727118749511680,
  "in_reply_to_status_id" : 88725629633175552,
  "created_at" : "Wed Jul 06 21:52:48 +0000 2011",
  "in_reply_to_screen_name" : "askotzko",
  "in_reply_to_user_id_str" : "15391002",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6208846966, -122.3395366862 ]
  },
  "id_str" : "88725528424624128",
  "text" : "Is anyone trying to start or end a habit and would like me to remind them to stay on track for the next week?",
  "id" : 88725528424624128,
  "created_at" : "Wed Jul 06 21:46:29 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emilio Ramirez",
      "screen_name" : "e_ramirez",
      "indices" : [ 0, 10 ],
      "id_str" : "1273564632",
      "id" : 1273564632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "88657313111617536",
  "geo" : {
  },
  "id_str" : "88672731138236416",
  "in_reply_to_user_id" : 21135674,
  "text" : "@e_ramirez I accept, as long as you also beat your distance record this week. :)",
  "id" : 88672731138236416,
  "in_reply_to_status_id" : 88657313111617536,
  "created_at" : "Wed Jul 06 18:16:41 +0000 2011",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.605833, -122.321667 ]
  },
  "id_str" : "88451998126587904",
  "text" : "8:36pm I'm getting the abridged version of Friday Night Lights while Niko stays up late http://flic.kr/p/9ZZnBH",
  "id" : 88451998126587904,
  "created_at" : "Wed Jul 06 03:39:34 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emilio Ramirez",
      "screen_name" : "e_ramirez",
      "indices" : [ 0, 10 ],
      "id_str" : "1273564632",
      "id" : 1273564632
    }, {
      "name" : "Fitbit",
      "screen_name" : "fitbit",
      "indices" : [ 73, 80 ],
      "id_str" : "17424053",
      "id" : 17424053
    }, {
      "name" : "navee",
      "screen_name" : "navee",
      "indices" : [ 81, 87 ],
      "id_str" : "7780252",
      "id" : 7780252
    }, {
      "name" : "Hugo Campos",
      "screen_name" : "HugoOC",
      "indices" : [ 88, 95 ],
      "id_str" : "2672931",
      "id" : 2672931
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "88391704914309121",
  "geo" : {
  },
  "id_str" : "88439933504733184",
  "in_reply_to_user_id" : 21135674,
  "text" : "@e_ramirez I respond well to public challenges and pretty charts. :) /cc @fitbit @navee @hugooc",
  "id" : 88439933504733184,
  "in_reply_to_status_id" : 88391704914309121,
  "created_at" : "Wed Jul 06 02:51:37 +0000 2011",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "88430518881886208",
  "text" : "How you search determines what you'll find.",
  "id" : 88430518881886208,
  "created_at" : "Wed Jul 06 02:14:13 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.fitbit.com\" rel=\"nofollow\">Fitbit</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fitstats",
      "indices" : [ 21, 30 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "88382742659739648",
  "text" : "My avg. daily fitbit #fitstats for last week: 6,032 steps and 3.7 miles traveled. http://www.fitbit.com/user/229KX2",
  "id" : 88382742659739648,
  "created_at" : "Tue Jul 05 23:04:22 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Wilson",
      "screen_name" : "chrilson",
      "indices" : [ 0, 9 ],
      "id_str" : "12919902",
      "id" : 12919902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "88189883088257024",
  "geo" : {
  },
  "id_str" : "88335961880141824",
  "in_reply_to_user_id" : 12919902,
  "text" : "@chrilson Thanks, Chris!",
  "id" : 88335961880141824,
  "in_reply_to_status_id" : 88189883088257024,
  "created_at" : "Tue Jul 05 19:58:29 +0000 2011",
  "in_reply_to_screen_name" : "chrilson",
  "in_reply_to_user_id_str" : "12919902",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "88322788481445889",
  "text" : "Has anyone installed a secure server on a Heroku app? I'm using Thawte and running into all kinds of problems. Tips / tricks?",
  "id" : 88322788481445889,
  "created_at" : "Tue Jul 05 19:06:08 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Haughey",
      "screen_name" : "mathowie",
      "indices" : [ 0, 9 ],
      "id_str" : "761975",
      "id" : 761975
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "88309958629785601",
  "geo" : {
  },
  "id_str" : "88322148086726656",
  "in_reply_to_user_id" : 761975,
  "text" : "@mathowie Yeah, seems like a Microsoft move.  Google Live Plus Blogs Server 2010.",
  "id" : 88322148086726656,
  "in_reply_to_status_id" : 88309958629785601,
  "created_at" : "Tue Jul 05 19:03:35 +0000 2011",
  "in_reply_to_screen_name" : "mathowie",
  "in_reply_to_user_id_str" : "761975",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.637833, -122.327167 ]
  },
  "id_str" : "88092759365390337",
  "text" : "8:36pm Pi\u00F1ata time http://flic.kr/p/9ZE9Ye",
  "id" : 88092759365390337,
  "created_at" : "Tue Jul 05 03:52:05 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "88049591974494209",
  "text" : "4th! http://instagr.am/p/G-7iR/",
  "id" : 88049591974494209,
  "created_at" : "Tue Jul 05 01:00:33 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6065, -122.323167 ]
  },
  "id_str" : "87727834830864385",
  "text" : "8:36pm This afternoon's entertainment for babies and adults http://flic.kr/p/9Zizvi",
  "id" : 87727834830864385,
  "created_at" : "Mon Jul 04 03:42:00 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6156816315, -122.319159508 ]
  },
  "id_str" : "87644566282440704",
  "text" : "Don't leave me!  @ Bobby Morris Playfield http://instagr.am/p/G5vhq/",
  "id" : 87644566282440704,
  "created_at" : "Sun Jul 03 22:11:07 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "87364717143785472",
  "text" : "8:36pm Burned out by the day and reading Siver's Anything You Want http://flic.kr/p/9YYfMg",
  "id" : 87364717143785472,
  "created_at" : "Sun Jul 03 03:39:06 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Paris Review",
      "screen_name" : "parisreview",
      "indices" : [ 3, 15 ],
      "id_str" : "71256932",
      "id" : 71256932
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "87302252435484672",
  "text" : "RT @parisreview: Nabokov was the master of the self interview. On the anniversary of Nabokov's death: http://tpr.ly/lAFKdL",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Tweetie for Mac</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "87225362454556672",
    "text" : "Nabokov was the master of the self interview. On the anniversary of Nabokov's death: http://tpr.ly/lAFKdL",
    "id" : 87225362454556672,
    "created_at" : "Sat Jul 02 18:25:21 +0000 2011",
    "user" : {
      "name" : "The Paris Review",
      "screen_name" : "parisreview",
      "protected" : false,
      "id_str" : "71256932",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1153656782/birdhead__2010-10-27__normal.jpg",
      "id" : 71256932,
      "verified" : true
    }
  },
  "id" : 87302252435484672,
  "created_at" : "Sat Jul 02 23:30:53 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Visnu Pitiyanuvath",
      "screen_name" : "visnup",
      "indices" : [ 0, 7 ],
      "id_str" : "6121912",
      "id" : 6121912
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "87255539410681856",
  "geo" : {
  },
  "id_str" : "87268025065144320",
  "in_reply_to_user_id" : 6121912,
  "text" : "@visnup Tumblr does, and you're right, it's the best option.",
  "id" : 87268025065144320,
  "in_reply_to_status_id" : 87255539410681856,
  "created_at" : "Sat Jul 02 21:14:53 +0000 2011",
  "in_reply_to_screen_name" : "visnup",
  "in_reply_to_user_id_str" : "6121912",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.605166, -122.3225 ]
  },
  "id_str" : "87002485377597440",
  "text" : "8:36pm Book club at our house! http://flic.kr/p/9YK693",
  "id" : 87002485377597440,
  "created_at" : "Sat Jul 02 03:39:43 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "girl jo",
      "screen_name" : "octavekitten",
      "indices" : [ 0, 13 ],
      "id_str" : "16366882",
      "id" : 16366882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "86903442089590785",
  "geo" : {
  },
  "id_str" : "86946436427685888",
  "in_reply_to_user_id" : 16366882,
  "text" : "@octavekitten We're raising him right off the bat to be the Mozart of buskers.",
  "id" : 86946436427685888,
  "in_reply_to_status_id" : 86903442089590785,
  "created_at" : "Fri Jul 01 23:57:00 +0000 2011",
  "in_reply_to_screen_name" : "octavekitten",
  "in_reply_to_user_id_str" : "16366882",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 44 ],
      "url" : "http://t.co/3mKAKZk",
      "expanded_url" : "http://www.youtube.com/watch?v=3nyul01llhE&feature=youtube_gdata_player",
      "display_url" : "youtube.com/watch?v=3nyul0\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6141811, -122.3194308164 ]
  },
  "id_str" : "86903147238400000",
  "text" : "The music video version: http://t.co/3mKAKZk",
  "id" : 86903147238400000,
  "created_at" : "Fri Jul 01 21:04:59 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "86897726154997760",
  "text" : "Sporty rocker dude? http://instagr.am/p/GvxWU/",
  "id" : 86897726154997760,
  "created_at" : "Fri Jul 01 20:43:27 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "healthmonth",
      "indices" : [ 89, 101 ]
    }, {
      "text" : "750words",
      "indices" : [ 102, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 69, 88 ],
      "url" : "http://t.co/5Xq48s2",
      "expanded_url" : "http://www.ted.com/talks/matt_cutts_try_something_new_for_30_days.html",
      "display_url" : "ted.com/talks/matt_cut\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "86845211178844161",
  "text" : "The \"Try something new for 30 days\" TED talk is my kind of manifesto.http://t.co/5Xq48s2 #healthmonth #750words",
  "id" : 86845211178844161,
  "created_at" : "Fri Jul 01 17:14:46 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jane McGonigal",
      "screen_name" : "avantgame",
      "indices" : [ 0, 10 ],
      "id_str" : "681813",
      "id" : 681813
    }, {
      "name" : "Susannah Fox",
      "screen_name" : "SusannahFox",
      "indices" : [ 113, 125 ],
      "id_str" : "17843236",
      "id" : 17843236
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "86798711870603264",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6049653833, -122.32306321 ]
  },
  "id_str" : "86800702860574720",
  "in_reply_to_user_id" : 681813,
  "text" : "@avantgame I'd *love* to hear your thoughts on it after trying it out a bit. Inspired by many of your ideas. /cc @susannahfox",
  "id" : 86800702860574720,
  "in_reply_to_status_id" : 86798711870603264,
  "created_at" : "Fri Jul 01 14:17:54 +0000 2011",
  "in_reply_to_screen_name" : "avantgame",
  "in_reply_to_user_id_str" : "681813",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Susannah Fox",
      "screen_name" : "SusannahFox",
      "indices" : [ 36, 48 ],
      "id_str" : "17843236",
      "id" : 17843236
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 105 ],
      "url" : "http://t.co/pkcDPP0",
      "expanded_url" : "http://bit.ly/jpnKag",
      "display_url" : "bit.ly/jpnKag"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6049764767, -122.3230088511 ]
  },
  "id_str" : "86797075018289152",
  "text" : "Thanks for the great honest review! @SusannahFox: I'm playing Health Month, the game: http://t.co/pkcDPP0 (quick - sign up for July!)",
  "id" : 86797075018289152,
  "created_at" : "Fri Jul 01 14:03:29 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 90 ],
      "url" : "http://t.co/QsOq8h0",
      "expanded_url" : "http://gizmo.do/iPMqlA",
      "display_url" : "gizmo.do/iPMqlA"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6050365733, -122.3230230867 ]
  },
  "id_str" : "86787409685135360",
  "text" : "Woah. Is this real? Scientists Create First Memory Expansion for Brain http://t.co/QsOq8h0 /via @zamland",
  "id" : 86787409685135360,
  "created_at" : "Fri Jul 01 13:25:05 +0000 2011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
} ]