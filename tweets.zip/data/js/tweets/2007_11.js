Grailbird.data.tweets_2007_11 = 
 [ {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "441623822",
  "text" : "Staying at the Standard, it's awesome!",
  "id" : 441623822,
  "created_at" : "Sun Nov 25 05:22:55 +0000 2007",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "433404782",
  "text" : "I just realized I can watch Lost on my iPhone as I'm flying to Orange County!",
  "id" : 433404782,
  "created_at" : "Wed Nov 21 23:22:59 +0000 2007",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "406312272",
  "text" : "My house is too cold... I'm gonna spend the day at the gym.",
  "id" : 406312272,
  "created_at" : "Sun Nov 11 20:29:32 +0000 2007",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "401968762",
  "text" : "I love the interview with Eggers and Roderick in this week's Stranger.",
  "id" : 401968762,
  "created_at" : "Fri Nov 09 20:55:36 +0000 2007",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "390601162",
  "text" : "All shakey from slow weights... can barely type!",
  "id" : 390601162,
  "created_at" : "Mon Nov 05 21:02:36 +0000 2007",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "386851022",
  "text" : "My eye is twitching.",
  "id" : 386851022,
  "created_at" : "Sun Nov 04 04:53:54 +0000 2007",
  "user" : {
    "name" : "Buster Benson",
    "screen_name" : "busterbenson",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
} ]