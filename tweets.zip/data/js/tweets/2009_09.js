Grailbird.data.tweets_2009_09 = 
 [ {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "4512256399",
  "text" : "8:36pm Subwaying it to somewhere to hang out with LBJ-M http://flic.kr/p/73SvAj",
  "id" : 4512256399,
  "created_at" : "Thu Oct 01 00:52:33 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "4484697880",
  "text" : "8:36pm Dinner with Marla at Cafe Mogador talking about going to every yoga studio in NYC http://flic.kr/p/73xLtB",
  "id" : 4484697880,
  "created_at" : "Wed Sep 30 00:39:13 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "4476068376",
  "text" : "My house is officially on the market. Know any potentially interested friends? It's a perfect bachelor pad in the city. http://bit.ly/2ObCOD",
  "id" : 4476068376,
  "created_at" : "Tue Sep 29 18:11:22 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ali Davis",
      "screen_name" : "Ali_Davis",
      "indices" : [ 0, 10 ],
      "id_str" : "18995147",
      "id" : 18995147
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "4437314337",
  "geo" : {
  },
  "id_str" : "4475733890",
  "in_reply_to_user_id" : 18995147,
  "text" : "@Ali_Davis Yeah, it was a busy and awesome day!  You did a great job MC'ing.  :)  Hope to see you again next time you're in Sea-town.",
  "id" : 4475733890,
  "in_reply_to_status_id" : 4437314337,
  "created_at" : "Tue Sep 29 17:56:25 +0000 2009",
  "in_reply_to_screen_name" : "Ali_Davis",
  "in_reply_to_user_id_str" : "18995147",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "4459167293",
  "text" : "8:36pm Wandering around NYC on a beautiful night http://flic.kr/p/73htFX",
  "id" : 4459167293,
  "created_at" : "Tue Sep 29 01:48:42 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jealous",
      "indices" : [ 56, 64 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "4459164657",
  "text" : "Rick has a sweet pad. Right in the middle of Soho even. #jealous http://flic.kr/p/73mrGC",
  "id" : 4459164657,
  "created_at" : "Tue Sep 29 01:48:36 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "4453940358",
  "text" : "Holy shit. We're moving in. (@ L'Hotel de Webb in NYC) http://bit.ly/HcTx6",
  "id" : 4453940358,
  "created_at" : "Mon Sep 28 22:04:38 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "&y",
      "screen_name" : "andypixel",
      "indices" : [ 0, 10 ],
      "id_str" : "10015122",
      "id" : 10015122
    }, {
      "name" : "Foursquare",
      "screen_name" : "foursquare",
      "indices" : [ 22, 33 ],
      "id_str" : "14120151",
      "id" : 14120151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "4450868289",
  "geo" : {
  },
  "id_str" : "4452560744",
  "in_reply_to_user_id" : 10015122,
  "text" : "@andypixel I'm 237 on @foursquare. That's gotta hurt.",
  "id" : 4452560744,
  "in_reply_to_status_id" : 4450868289,
  "created_at" : "Mon Sep 28 21:02:29 +0000 2009",
  "in_reply_to_screen_name" : "andypixel",
  "in_reply_to_user_id_str" : "10015122",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Foursquare",
      "screen_name" : "foursquare",
      "indices" : [ 38, 49 ],
      "id_str" : "14120151",
      "id" : 14120151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "4451973568",
  "text" : "I just unlocked the \"Newbie\" badge on @foursquare! http://bit.ly/B9QNo",
  "id" : 4451973568,
  "created_at" : "Mon Sep 28 20:36:12 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "4451971423",
  "text" : "Here for 9 days! But do plan on leaving the airport. Let's hang out! (@ Jetblue @ JFK in NYC) http://bit.ly/ldJ5v",
  "id" : 4451971423,
  "created_at" : "Mon Sep 28 20:36:06 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "4444027746",
  "text" : "Someone buy our place while we're gone, okay? (@ Seattle-Tacoma International Airport in Seattle) http://bit.ly/VkWtO",
  "id" : 4444027746,
  "created_at" : "Mon Sep 28 14:44:48 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 23, 33 ],
      "id_str" : "7362142",
      "id" : 7362142
    }, {
      "name" : "Megan Welling",
      "screen_name" : "MeganWelling",
      "indices" : [ 35, 48 ],
      "id_str" : "26166039",
      "id" : 26166039
    }, {
      "name" : "Carinna Tarvin",
      "screen_name" : "carinnatarvin",
      "indices" : [ 54, 68 ],
      "id_str" : "20833838",
      "id" : 20833838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "4434173735",
  "text" : "8:36pm Free pizza with @kellianne, @meganwelling, and @carinnatarvin post-storage help http://flic.kr/p/72ZTYx",
  "id" : 4434173735,
  "created_at" : "Mon Sep 28 03:39:19 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian",
      "screen_name" : "paperwalrus",
      "indices" : [ 0, 12 ],
      "id_str" : "18666298",
      "id" : 18666298
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "4426953209",
  "geo" : {
  },
  "id_str" : "4427072355",
  "in_reply_to_user_id" : 18666298,
  "text" : "@paperwalrus No, we saw it and liked it, but not enough for the price.",
  "id" : 4427072355,
  "in_reply_to_status_id" : 4426953209,
  "created_at" : "Sun Sep 27 22:09:35 +0000 2009",
  "in_reply_to_screen_name" : "paperwalrus",
  "in_reply_to_user_id_str" : "18666298",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "4423256575",
  "text" : "Attempting to remove as many traces of life at my house before the photographer takes pictures for my listing. 3 hours is not enough!",
  "id" : 4423256575,
  "created_at" : "Sun Sep 27 19:09:55 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "4409288863",
  "text" : "8:36pm Congrats to Brangien and Daniel! http://flic.kr/p/72EV7Z",
  "id" : 4409288863,
  "created_at" : "Sun Sep 27 03:38:00 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "4405487923",
  "text" : "Setting up the photo mirror for Daniel and Brangien's wedding extravaganza! http://flic.kr/p/72CFRt",
  "id" : 4405487923,
  "created_at" : "Sun Sep 27 00:18:32 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "4401526382",
  "text" : "Apparently our beautiful loft goes on the market tomorrow. Anyone want it?",
  "id" : 4401526382,
  "created_at" : "Sat Sep 26 20:42:35 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "4388274475",
  "text" : "New challenge: to go from zero to selling this house in 45 days. Any tips?",
  "id" : 4388274475,
  "created_at" : "Sat Sep 26 05:47:51 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "4385965201",
  "text" : "8:36pm At Daniel & Brangien's rehearsal dinner bowling party after some exciting house hunting http://flic.kr/p/72qoHB",
  "id" : 4385965201,
  "created_at" : "Sat Sep 26 03:38:12 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "4361289596",
  "text" : "8:36pm Watched Jennifer's Body. Good but also bad. http://flic.kr/p/72hgSG",
  "id" : 4361289596,
  "created_at" : "Fri Sep 25 04:47:33 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 47, 57 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "4356830050",
  "text" : "Weirdest house ever, but I think I like it! RT @kellianne Our latest house crush has the weirdest location, ever.  http://flic.kr/p/72eSP7",
  "id" : 4356830050,
  "created_at" : "Fri Sep 25 01:14:23 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 64, 67 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "4347526146",
  "text" : "It's a play all songs on shuffle, and no skipping, kind of day. #fb",
  "id" : 4347526146,
  "created_at" : "Thu Sep 24 17:59:16 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Galen Ward",
      "screen_name" : "galenward",
      "indices" : [ 0, 10 ],
      "id_str" : "2854761",
      "id" : 2854761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "4330347783",
  "geo" : {
  },
  "id_str" : "4347484583",
  "in_reply_to_user_id" : 2854761,
  "text" : "@galenward Yeah, we should hang out. I'm working in a studio above Vain if you wanna get a happy hour drink sometime.",
  "id" : 4347484583,
  "in_reply_to_status_id" : 4330347783,
  "created_at" : "Thu Sep 24 17:57:18 +0000 2009",
  "in_reply_to_screen_name" : "galenward",
  "in_reply_to_user_id_str" : "2854761",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "4333611003",
  "text" : "8:36pm House-hunting and number crunching like a maniac http://flic.kr/p/71Xxnv",
  "id" : 4333611003,
  "created_at" : "Thu Sep 24 03:37:19 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "4320249829",
  "text" : "\"We see you here more than we see the mayor!\" me: \"It takes the mayor a while to get ready.\" (@ Bedlam Coffee) http://bit.ly/ERuE5",
  "id" : 4320249829,
  "created_at" : "Wed Sep 23 17:20:40 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "4307178878",
  "text" : "8:36pm About to have some damn good French cuisine with my damn good wife http://flic.kr/p/71GCPV",
  "id" : 4307178878,
  "created_at" : "Wed Sep 23 03:39:54 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 138, 141 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "4305414728",
  "text" : "Did you know that it's pretty much impossible to get a mortgage now if you've been self-employed &lt; 2 yrs, no matter how much you make? #fb",
  "id" : 4305414728,
  "created_at" : "Wed Sep 23 02:21:51 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "4164159478",
  "text" : "8:36pm Getting tax information together for mortgage broker. http://flic.kr/p/71qhRg",
  "id" : 4164159478,
  "created_at" : "Tue Sep 22 03:39:25 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "4139092360",
  "text" : "8:36pm Walking to Whole Foods before Mad Men at the Dickers' http://flic.kr/p/71aYWm",
  "id" : 4139092360,
  "created_at" : "Mon Sep 21 03:39:23 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 0, 9 ],
      "id_str" : "761628",
      "id" : 761628
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "4128463725",
  "in_reply_to_user_id" : 761628,
  "text" : "@RickWebb: Oh man, me too. That's gotta be a bug, right?",
  "id" : 4128463725,
  "created_at" : "Sun Sep 20 18:32:12 +0000 2009",
  "in_reply_to_screen_name" : "RickWebb",
  "in_reply_to_user_id_str" : "761628",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "4127954617",
  "text" : "Online house shopping is the new online dating. Or, everything I needed to know about buying a house I learned on Nerve Personals.",
  "id" : 4127954617,
  "created_at" : "Sun Sep 20 18:04:49 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "4116942323",
  "text" : "8:36pm Movie-marathon continues with The Lives of Others after a day of house-shopping misses http://flic.kr/p/6ZQx2d",
  "id" : 4116942323,
  "created_at" : "Sun Sep 20 03:39:08 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Galen Ward",
      "screen_name" : "galenward",
      "indices" : [ 0, 10 ],
      "id_str" : "2854761",
      "id" : 2854761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "4107001798",
  "in_reply_to_user_id" : 2854761,
  "text" : "@galenward I'm using Estately to help house shop... that site is SLICK! Meeting with Larry Cragun to look at our first place today.",
  "id" : 4107001798,
  "created_at" : "Sat Sep 19 18:12:06 +0000 2009",
  "in_reply_to_screen_name" : "galenward",
  "in_reply_to_user_id_str" : "2854761",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "4095361265",
  "text" : "8:36pm Watched our inaugurial first movie on new projection setup. Rocket Science was awkward to the max! http://flic.kr/p/6ZzxXo",
  "id" : 4095361265,
  "created_at" : "Sat Sep 19 03:36:51 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 104, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "4085007454",
  "text" : "Anyone know how to find a 3-pronged AC adapter that would work with this? My projector needs a new one. #fb http://flic.kr/p/6ZqdFM",
  "id" : 4085007454,
  "created_at" : "Fri Sep 18 18:40:35 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "4071006993",
  "text" : "8:36pm Too dark at Bathtub Gin. http://flic.kr/p/6ZmbLA",
  "id" : 4071006993,
  "created_at" : "Fri Sep 18 03:39:55 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Via Tribunali",
      "screen_name" : "ViaTribunali",
      "indices" : [ 35, 48 ],
      "id_str" : "70575805",
      "id" : 70575805
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "4068597652",
  "text" : "Got my pizza money. Pizza party at @viatribunali anyone?",
  "id" : 4068597652,
  "created_at" : "Fri Sep 18 01:40:47 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "4068235776",
  "text" : "Trying to get my $500 of pizza money.",
  "id" : 4068235776,
  "created_at" : "Fri Sep 18 01:23:44 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "4046486207",
  "text" : "8:36pm Running out of energy, ready for Kellianne to get off work so we can eat! http://flic.kr/p/6Z3D5g",
  "id" : 4046486207,
  "created_at" : "Thu Sep 17 03:39:42 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Santangelo",
      "screen_name" : "endquote",
      "indices" : [ 0, 9 ],
      "id_str" : "408",
      "id" : 408
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "4046076866",
  "geo" : {
  },
  "id_str" : "4046424704",
  "in_reply_to_user_id" : 408,
  "text" : "@endquote Are you talking about desktop, iPhone, or other app?  I just email them to Flickr's special 2twitter email address. Works well.",
  "id" : 4046424704,
  "in_reply_to_status_id" : 4046076866,
  "created_at" : "Thu Sep 17 03:36:21 +0000 2009",
  "in_reply_to_screen_name" : "endquote",
  "in_reply_to_user_id_str" : "408",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "4021755823",
  "text" : "8:36pm Wrapping up at work before heading home for dinner. Busy day! http://flic.kr/p/6YRJV5",
  "id" : 4021755823,
  "created_at" : "Wed Sep 16 03:42:45 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 63, 73 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "4008281903",
  "text" : "Mayoral discounts start next week. Watch your rear view mirror @kellianne! (@ Bedlam Coffee in Seattle) http://bit.ly/ERuE5",
  "id" : 4008281903,
  "created_at" : "Tue Sep 15 16:58:44 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "3997115044",
  "text" : "8:36pm Kellianne goes out of her way to take her 8:36pm picture as I stand beneath Queen City Grill sign http://flic.kr/p/6YvD4g",
  "id" : 3997115044,
  "created_at" : "Tue Sep 15 03:39:17 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "fierceflawless",
      "screen_name" : "fierceflawless",
      "indices" : [ 3, 18 ],
      "id_str" : "4540",
      "id" : 4540
    }, {
      "name" : "Kanye",
      "screen_name" : "Kanye",
      "indices" : [ 22, 28 ],
      "id_str" : "6675592",
      "id" : 6675592
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "3996980102",
  "text" : "RT @fierceflawless RT @Kanye: YO PATRICK SWAYZE I KNO U JUS DIED&ALL&IMA LET U FINISH BUT MICHAEL JACKSONS DEATH WAS BY FAR BEST ONE DISYEAR",
  "id" : 3996980102,
  "created_at" : "Tue Sep 15 03:32:08 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Croft",
      "screen_name" : "jcroft",
      "indices" : [ 0, 7 ],
      "id_str" : "25993",
      "id" : 25993
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "3986458951",
  "geo" : {
  },
  "id_str" : "3986647990",
  "in_reply_to_user_id" : 25993,
  "text" : "@jcroft Haha, yup, that's me! (http://bit.ly/N0VCz)",
  "id" : 3986647990,
  "in_reply_to_status_id" : 3986458951,
  "created_at" : "Mon Sep 14 19:28:33 +0000 2009",
  "in_reply_to_screen_name" : "jcroft",
  "in_reply_to_user_id_str" : "25993",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "3972353191",
  "text" : "8:36pm At Crush with Camille and Chris. Yum! http://flic.kr/p/6YcsNH",
  "id" : 3972353191,
  "created_at" : "Mon Sep 14 03:38:29 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "comehungryleavehappythatIHOP",
      "indices" : [ 0, 29 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "3952879906",
  "text" : "#comehungryleavehappythatIHOP/OHIOisnotandeverydecadeoccurencebutIlovemyfriendshi!",
  "id" : 3952879906,
  "created_at" : "Sun Sep 13 10:57:31 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "3950222437",
  "text" : "Soul night http://flic.kr/p/6XXbFf",
  "id" : 3950222437,
  "created_at" : "Sun Sep 13 06:10:59 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "3948054972",
  "text" : "8:36pm Getting a bottle of wine and going to Samantha's Chateau for pre-Soul Night preparatory time http://flic.kr/p/6XRymX",
  "id" : 3948054972,
  "created_at" : "Sun Sep 13 03:39:53 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "3930111912",
  "text" : "I should've stayed out! I have being out and about jealousy, which is rare, but might result in more goings out tomorrow. Good night!",
  "id" : 3930111912,
  "created_at" : "Sat Sep 12 07:09:36 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "3927335500",
  "text" : "8:36pm Closing out at Presse, heading to Pixel's http://flic.kr/p/6XzLbB",
  "id" : 3927335500,
  "created_at" : "Sat Sep 12 03:39:04 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carinna Tarvin",
      "screen_name" : "carinnatarvin",
      "indices" : [ 0, 14 ],
      "id_str" : "20833838",
      "id" : 20833838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "3924811820",
  "in_reply_to_user_id" : 20833838,
  "text" : "@carinnatarvin Start your shenanigans at Cal Anderson and then move the shenanigans to the Pixels!",
  "id" : 3924811820,
  "created_at" : "Sat Sep 12 01:38:03 +0000 2009",
  "in_reply_to_screen_name" : "carinnatarvin",
  "in_reply_to_user_id_str" : "20833838",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "3904148190",
  "text" : "8:36pm Meeting Kellianne at Tavolata http://flic.kr/p/6XkMbz",
  "id" : 3904148190,
  "created_at" : "Fri Sep 11 03:39:00 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Foodista",
      "screen_name" : "foodista",
      "indices" : [ 52, 61 ],
      "id_str" : "15380717",
      "id" : 15380717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "3893479468",
  "text" : "I love Foodista.  More integrations coming soon! RT @foodista: New blog post: Locavore and Foodista http://bit.ly/6ooOq",
  "id" : 3893479468,
  "created_at" : "Thu Sep 10 18:54:43 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Locavore (LocalDirt)",
      "screen_name" : "enjoy_locavore",
      "indices" : [ 3, 18 ],
      "id_str" : "21413857",
      "id" : 21413857
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "3874010568",
  "text" : "RT @enjoy_locavore: Excited to see Locavore featured on the App Store's new \"Go Green\" essentials page. http://bit.ly/t285R",
  "id" : 3874010568,
  "created_at" : "Wed Sep 09 23:07:03 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://birdfeedapp.com\" rel=\"nofollow\">Birdfeed</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leonard",
      "screen_name" : "lhl",
      "indices" : [ 0, 4 ],
      "id_str" : "12513",
      "id" : 12513
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "3854769902",
  "geo" : {
  },
  "id_str" : "3865809207",
  "in_reply_to_user_id" : 12513,
  "text" : "@lhl If you wanna get rid of it, name a price!",
  "id" : 3865809207,
  "in_reply_to_status_id" : 3854769902,
  "created_at" : "Wed Sep 09 16:04:21 +0000 2009",
  "in_reply_to_screen_name" : "lhl",
  "in_reply_to_user_id_str" : "12513",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "3856177286",
  "text" : "8:36pm At our fave Ballard restaurant having quality time before bday party http://flic.kr/p/6WTm9y",
  "id" : 3856177286,
  "created_at" : "Wed Sep 09 03:38:45 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kris Krüg",
      "screen_name" : "kk",
      "indices" : [ 0, 3 ],
      "id_str" : "13669",
      "id" : 13669
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "3853989588",
  "geo" : {
  },
  "id_str" : "3854179880",
  "in_reply_to_user_id" : 13669,
  "text" : "@kk Hmm hadn't thought of that but might give it a try! Birthday boy or his dad?",
  "id" : 3854179880,
  "in_reply_to_status_id" : 3853989588,
  "created_at" : "Wed Sep 09 01:52:52 +0000 2009",
  "in_reply_to_screen_name" : "kk",
  "in_reply_to_user_id_str" : "13669",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leonard",
      "screen_name" : "lhl",
      "indices" : [ 0, 4 ],
      "id_str" : "12513",
      "id" : 12513
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "3848210791",
  "geo" : {
  },
  "id_str" : "3854048939",
  "in_reply_to_user_id" : 12513,
  "text" : "@lhl Got a spare Wacom tablet lying around? Those things are expensivo!",
  "id" : 3854048939,
  "in_reply_to_status_id" : 3848210791,
  "created_at" : "Wed Sep 09 01:46:34 +0000 2009",
  "in_reply_to_screen_name" : "lhl",
  "in_reply_to_user_id_str" : "12513",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 100, 103 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "3853968692",
  "text" : "Heading to Ballard to attend my wife's high school boyfriend's birthday party and meet his parents. #fb",
  "id" : 3853968692,
  "created_at" : "Wed Sep 09 01:42:41 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "senoraj",
      "screen_name" : "senoraj",
      "indices" : [ 0, 8 ],
      "id_str" : "13443292",
      "id" : 13443292
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "3832299050",
  "geo" : {
  },
  "id_str" : "3832435704",
  "in_reply_to_user_id" : 13443292,
  "text" : "@senoraj Facebook has really granular permissions. You can specify exactly who sees what.  http://bit.ly/13R774 (try the \"customize\" option)",
  "id" : 3832435704,
  "in_reply_to_status_id" : 3832299050,
  "created_at" : "Tue Sep 08 03:01:37 +0000 2009",
  "in_reply_to_screen_name" : "senoraj",
  "in_reply_to_user_id_str" : "13443292",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "3827987237",
  "text" : "My new desktop: Automator pulls images from Flickr's Interesting page daily. They're small, so pixelated, but look neat. Lotsa color.",
  "id" : 3827987237,
  "created_at" : "Mon Sep 07 23:02:25 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Harrison",
      "screen_name" : "sourjayne",
      "indices" : [ 0, 10 ],
      "id_str" : "4981271",
      "id" : 4981271
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "3824515235",
  "geo" : {
  },
  "id_str" : "3825424079",
  "in_reply_to_user_id" : 4981271,
  "text" : "@sourjayne Um... not sure really, I just want to be able to draw whatever's in my head. Which tend to be animals, mazes, and buttons.",
  "id" : 3825424079,
  "in_reply_to_status_id" : 3824515235,
  "created_at" : "Mon Sep 07 20:34:09 +0000 2009",
  "in_reply_to_screen_name" : "sourjayne",
  "in_reply_to_user_id_str" : "4981271",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JeSuisJuba",
      "screen_name" : "jesuisjuba",
      "indices" : [ 0, 11 ],
      "id_str" : "47478936",
      "id" : 47478936
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "3824197011",
  "geo" : {
  },
  "id_str" : "3824237912",
  "in_reply_to_user_id" : 47478936,
  "text" : "@jesuisjuba Awesome, I'll check those out.  Thanks for the tips!",
  "id" : 3824237912,
  "in_reply_to_status_id" : 3824197011,
  "created_at" : "Mon Sep 07 19:26:14 +0000 2009",
  "in_reply_to_screen_name" : "jesuisjuba",
  "in_reply_to_user_id_str" : "47478936",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "brian papenfuss",
      "screen_name" : "spookbrian",
      "indices" : [ 0, 11 ],
      "id_str" : "15451513",
      "id" : 15451513
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "3824104863",
  "geo" : {
  },
  "id_str" : "3824217993",
  "in_reply_to_user_id" : 15451513,
  "text" : "@spookbrian No, I don't know him, but his work looks great. Does he teach at all?",
  "id" : 3824217993,
  "in_reply_to_status_id" : 3824104863,
  "created_at" : "Mon Sep 07 19:25:05 +0000 2009",
  "in_reply_to_screen_name" : "spookbrian",
  "in_reply_to_user_id_str" : "15451513",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "D. Keith Robinson",
      "screen_name" : "dkr",
      "indices" : [ 0, 4 ],
      "id_str" : "10877",
      "id" : 10877
    }, {
      "name" : "Sarah Harrison",
      "screen_name" : "sourjayne",
      "indices" : [ 19, 29 ],
      "id_str" : "4981271",
      "id" : 4981271
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "3823901816",
  "geo" : {
  },
  "id_str" : "3823950695",
  "in_reply_to_user_id" : 10877,
  "text" : "@dkr Yeah, me too. @sourjayne, teach us!  I'll be your best friend.",
  "id" : 3823950695,
  "in_reply_to_status_id" : 3823901816,
  "created_at" : "Mon Sep 07 19:09:47 +0000 2009",
  "in_reply_to_screen_name" : "dkr",
  "in_reply_to_user_id_str" : "10877",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "3823799070",
  "text" : "I want to learn how to draw in Illustrator or whatever kids are using today. Who knows how to do this? Rec me good books, classes, etc pls!",
  "id" : 3823799070,
  "created_at" : "Mon Sep 07 19:01:03 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "3822193317",
  "text" : "Barack's speech for kids starting school inspired me to study harder as well http://bit.ly/3R5uIL",
  "id" : 3822193317,
  "created_at" : "Mon Sep 07 17:29:20 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "3811653229",
  "text" : "8:36pm Just braved the whipping wind to come home but now need food and entertainment! http://flic.kr/p/6Waehk",
  "id" : 3811653229,
  "created_at" : "Mon Sep 07 03:40:43 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Megan Welling",
      "screen_name" : "MeganWelling",
      "indices" : [ 0, 13 ],
      "id_str" : "26166039",
      "id" : 26166039
    }, {
      "name" : "Brian",
      "screen_name" : "paperwalrus",
      "indices" : [ 16, 28 ],
      "id_str" : "18666298",
      "id" : 18666298
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "3805721400",
  "geo" : {
  },
  "id_str" : "3808576669",
  "in_reply_to_user_id" : 26166039,
  "text" : "@meganwelling & @paperwalrus Okay, when's our first run? Wanna stick to Myrtle Edwards or try something new?",
  "id" : 3808576669,
  "in_reply_to_status_id" : 3805721400,
  "created_at" : "Mon Sep 07 00:41:43 +0000 2009",
  "in_reply_to_screen_name" : "MeganWelling",
  "in_reply_to_user_id_str" : "26166039",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Goldberg",
      "screen_name" : "bostonsteamer",
      "indices" : [ 0, 14 ],
      "id_str" : "2029651",
      "id" : 2029651
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "3806955044",
  "geo" : {
  },
  "id_str" : "3806996770",
  "in_reply_to_user_id" : 2029651,
  "text" : "@bostonsteamer Awesome! Many congratulations to you and Vanessa!",
  "id" : 3806996770,
  "in_reply_to_status_id" : 3806955044,
  "created_at" : "Sun Sep 06 23:02:27 +0000 2009",
  "in_reply_to_screen_name" : "bostonsteamer",
  "in_reply_to_user_id_str" : "2029651",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Megan Welling",
      "screen_name" : "MeganWelling",
      "indices" : [ 0, 13 ],
      "id_str" : "26166039",
      "id" : 26166039
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "3805155225",
  "geo" : {
  },
  "id_str" : "3805219769",
  "in_reply_to_user_id" : 26166039,
  "text" : "@MeganWelling Maybe we should make a goal to run X number of miles in a Y days. Maybe 50 in 1 month? 25? Baby steps or big steps?",
  "id" : 3805219769,
  "in_reply_to_status_id" : 3805155225,
  "created_at" : "Sun Sep 06 21:11:37 +0000 2009",
  "in_reply_to_screen_name" : "MeganWelling",
  "in_reply_to_user_id_str" : "26166039",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "3804655691",
  "text" : "Paul Ekman and the Dalai Lama on how to forgive a person without condoning their actions: http://bit.ly/3uoBxw",
  "id" : 3804655691,
  "created_at" : "Sun Sep 06 20:36:58 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "3804514905",
  "text" : "@bjorn00000 I've read his book Emotions Revealed... very enlightening!  Curious about Emotional Awareness also.",
  "id" : 3804514905,
  "created_at" : "Sun Sep 06 20:28:17 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen Johnson",
      "screen_name" : "Karen_L_Johnson",
      "indices" : [ 0, 16 ],
      "id_str" : "25254414",
      "id" : 25254414
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "3793741880",
  "geo" : {
  },
  "id_str" : "3802382546",
  "in_reply_to_user_id" : 25254414,
  "text" : "@karen_l_johnson I liked it! I see how it could be interpreted slightly racist. I'm half-Japanese, and think cultural differences are cool.",
  "id" : 3802382546,
  "in_reply_to_status_id" : 3793741880,
  "created_at" : "Sun Sep 06 18:16:27 +0000 2009",
  "in_reply_to_screen_name" : "Karen_L_Johnson",
  "in_reply_to_user_id_str" : "25254414",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "3801822077",
  "text" : "@bjorn00000 I love Paul Ekman! His facial expression studies are awesome! If I'm lying, I believe my lies.",
  "id" : 3801822077,
  "created_at" : "Sun Sep 06 17:42:39 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Infinite Summer",
      "screen_name" : "infinitesummer",
      "indices" : [ 0, 15 ],
      "id_str" : "38263896",
      "id" : 38263896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "3788695293",
  "in_reply_to_user_id" : 38263896,
  "text" : "@infinitesummer Feature idea: provide spoiler line archive so those of us who have fallen behind can know where to stop reading the blog.",
  "id" : 3788695293,
  "created_at" : "Sun Sep 06 00:19:09 +0000 2009",
  "in_reply_to_screen_name" : "infinitesummer",
  "in_reply_to_user_id_str" : "38263896",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "3774259719",
  "text" : "Called our own bluff at Purple Dot. Tamarind Tree was just a few blocks further.",
  "id" : 3774259719,
  "created_at" : "Sat Sep 05 05:40:25 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/devices\" rel=\"nofollow\">txt</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Megan Welling",
      "screen_name" : "MeganWelling",
      "indices" : [ 0, 13 ],
      "id_str" : "26166039",
      "id" : 26166039
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "3773518765",
  "in_reply_to_user_id" : 26166039,
  "text" : "@meganwelling One more time and you get 10% off!",
  "id" : 3773518765,
  "created_at" : "Sat Sep 05 04:43:30 +0000 2009",
  "in_reply_to_screen_name" : "MeganWelling",
  "in_reply_to_user_id_str" : "26166039",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "3773356068",
  "text" : "Finally read the whole Ragin' Asian article from SW and now just want to walk to Purple Dot for baked spaghetti. Well half of me wants to.",
  "id" : 3773356068,
  "created_at" : "Sat Sep 05 04:32:49 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infsum",
      "indices" : [ 79, 86 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "3772492169",
  "text" : "8:36pm Reading water-wrinkled page 429 of Infinite Jest trying to jump back on #infsum. It is getting good again. http://flic.kr/p/6VzUQt",
  "id" : 3772492169,
  "created_at" : "Sat Sep 05 03:39:39 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "3749812221",
  "text" : "8:36pm Feeling slightly Ill but about head out to Samantha's happening! http://flic.kr/p/6VqCyj",
  "id" : 3749812221,
  "created_at" : "Fri Sep 04 03:55:08 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "3727425491",
  "text" : "8:36pm At Lava with Leonard Lin http://flic.kr/p/6VbxLb",
  "id" : 3727425491,
  "created_at" : "Thu Sep 03 04:38:10 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "3704183909",
  "text" : "8:36pm Working late on really cool stuff http://flic.kr/p/6UQeaH",
  "id" : 3704183909,
  "created_at" : "Wed Sep 02 03:37:58 +0000 2009",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SeattleAthleticClub",
      "screen_name" : "SACDT",
      "indices" : [ 0, 6 ],
      "id_str" : "18228022",
      "id" : 18228022
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "3698842890",
  "in_reply_to_user_id" : 18228022,
  "text" : "@SACDT Send me an email at busterbenson@gmail.com.  Thanks!",
  "id" : 3698842890,
  "created_at" : "Tue Sep 01 22:55:12 +0000 2009",
  "in_reply_to_screen_name" : "SACDT",
  "in_reply_to_user_id_str" : "18228022",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/app/twitter/id333903271?mt=8\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SeattleAthleticClub",
      "screen_name" : "SACDT",
      "indices" : [ 0, 6 ],
      "id_str" : "18228022",
      "id" : 18228022
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "3698378880",
  "in_reply_to_user_id" : 18228022,
  "text" : "@SACDT I can't direct message reply to you, but yes I'd be interested in a free appointment with a trainer if you are offering.",
  "id" : 3698378880,
  "created_at" : "Tue Sep 01 22:30:36 +0000 2009",
  "in_reply_to_screen_name" : "SACDT",
  "in_reply_to_user_id_str" : "18228022",
  "user" : {
    "name" : "@buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/2838651436/77b0889c446d55a0faddda6c5fd0ed85_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
} ]