Grailbird.data.tweets_2013_09 = 
[ {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Morning News",
      "screen_name" : "TheMorningNews",
      "indices" : [ 3, 18 ],
      "id_str" : "16539190",
      "id" : 16539190
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "380062530682359808",
  "text" : "RT @TheMorningNews: It's quite common for an individual to have multiple genomes. Some people...have genomes that came from other... http:/\u2026",
  "retweeted_status" : {
    "source" : "<a href=\"http://dlvr.it\" rel=\"nofollow\">dlvr.it</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 135 ],
        "url" : "http://t.co/bmIVnqNQGY",
        "expanded_url" : "http://tmne.ws/3zgwCs",
        "display_url" : "tmne.ws/3zgwCs"
      } ]
    },
    "geo" : { },
    "id_str" : "380062065932505089",
    "text" : "It's quite common for an individual to have multiple genomes. Some people...have genomes that came from other... http://t.co/bmIVnqNQGY",
    "id" : 380062065932505089,
    "created_at" : "2013-09-17 20:13:52 +0000",
    "user" : {
      "name" : "The Morning News",
      "screen_name" : "TheMorningNews",
      "protected" : false,
      "id_str" : "16539190",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2874633077/d338f787e09282765a8259599da44b97_normal.png",
      "id" : 16539190,
      "verified" : false
    }
  },
  "id" : 380062530682359808,
  "created_at" : "2013-09-17 20:15:43 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Sandquist",
      "screen_name" : "jeffsand",
      "indices" : [ 0, 9 ],
      "id_str" : "229523",
      "id" : 229523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "380019216671186944",
  "geo" : { },
  "id_str" : "380030574653493249",
  "in_reply_to_user_id" : 229523,
  "text" : "@jeffsand Excited to work with you!",
  "id" : 380030574653493249,
  "in_reply_to_status_id" : 380019216671186944,
  "created_at" : "2013-09-17 18:08:44 +0000",
  "in_reply_to_screen_name" : "jeffsand",
  "in_reply_to_user_id_str" : "229523",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim O'Reilly",
      "screen_name" : "timoreilly",
      "indices" : [ 3, 14 ],
      "id_str" : "2384071",
      "id" : 2384071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "380015248259825664",
  "text" : "RT @timoreilly: I'm delighted by the response to my post about growing a great company, w/ the counterintuitive title \"How I Failed\" http:/\u2026",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http://t.co/oRbzZBsBj7",
        "expanded_url" : "http://linkd.in/15YsiS3",
        "display_url" : "linkd.in/15YsiS3"
      } ]
    },
    "geo" : { },
    "id_str" : "378631191378661377",
    "text" : "I'm delighted by the response to my post about growing a great company, w/ the counterintuitive title \"How I Failed\" http://t.co/oRbzZBsBj7",
    "id" : 378631191378661377,
    "created_at" : "2013-09-13 21:28:05 +0000",
    "user" : {
      "name" : "Tim O'Reilly",
      "screen_name" : "timoreilly",
      "protected" : false,
      "id_str" : "2384071",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2823681988/f4f6f2bed8ab4d5a48dea4b9ea85d5f1_normal.jpeg",
      "id" : 2384071,
      "verified" : true
    }
  },
  "id" : 380015248259825664,
  "created_at" : "2013-09-17 17:07:50 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.goodreads.com\" rel=\"nofollow\">Goodreads</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http://t.co/fniqa8P9V7",
      "expanded_url" : "http://bit.ly/18vfbYr",
      "display_url" : "bit.ly/18vfbYr"
    } ]
  },
  "geo" : { },
  "id_str" : "380005618481762304",
  "text" : "5 of 5 stars to Antifragile by Nassim Nicholas Taleb http://t.co/fniqa8P9V7",
  "id" : 380005618481762304,
  "created_at" : "2013-09-17 16:29:34 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nassim N. Taleb",
      "screen_name" : "nntaleb",
      "indices" : [ 83, 91 ],
      "id_str" : "381289719",
      "id" : 381289719
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "380004558807642112",
  "text" : "\"The best way to verify if you are alive is by checking if you like variations.\" - @nntaleb in Antifragile",
  "id" : 380004558807642112,
  "created_at" : "2013-09-17 16:25:21 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Bodge",
      "screen_name" : "mikebodge",
      "indices" : [ 0, 10 ],
      "id_str" : "19344531",
      "id" : 19344531
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "379969111700541440",
  "geo" : { },
  "id_str" : "379972898674331648",
  "in_reply_to_user_id" : 19344531,
  "text" : "@mikebodge Me!",
  "id" : 379972898674331648,
  "in_reply_to_status_id" : 379969111700541440,
  "created_at" : "2013-09-17 14:19:33 +0000",
  "in_reply_to_screen_name" : "mikebodge",
  "in_reply_to_user_id_str" : "19344531",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jessica Scheibach",
      "screen_name" : "jshy",
      "indices" : [ 0, 5 ],
      "id_str" : "804659",
      "id" : 804659
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "379833890677874688",
  "geo" : { },
  "id_str" : "379835275322482688",
  "in_reply_to_user_id" : 804659,
  "text" : "@jshy I say give in! It's what the kids are all doing these days.",
  "id" : 379835275322482688,
  "in_reply_to_status_id" : 379833890677874688,
  "created_at" : "2013-09-17 05:12:41 +0000",
  "in_reply_to_screen_name" : "jshy",
  "in_reply_to_user_id_str" : "804659",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nina Davuluri",
      "screen_name" : "DavuluriNina",
      "indices" : [ 3, 16 ],
      "id_str" : "1872316580",
      "id" : 1872316580
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "379832084665102336",
  "text" : "RT @DavuluriNina: Haters gonna hate. I am Miss America 2014.",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "379651101445726208",
    "text" : "Haters gonna hate. I am Miss America 2014.",
    "id" : 379651101445726208,
    "created_at" : "2013-09-16 17:00:50 +0000",
    "user" : {
      "name" : "Nina Davuluri",
      "screen_name" : "DavuluriNina",
      "protected" : false,
      "id_str" : "1872316580",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000467361604/b0f60b150a2874fcf902ebc29f2354ba_normal.jpeg",
      "id" : 1872316580,
      "verified" : false
    }
  },
  "id" : 379832084665102336,
  "created_at" : "2013-09-17 05:00:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Gordon",
      "screen_name" : "JeremySF",
      "indices" : [ 59, 68 ],
      "id_str" : "19872718",
      "id" : 19872718
    }, {
      "name" : "Buster",
      "screen_name" : "buster",
      "indices" : [ 70, 77 ],
      "id_str" : "2185",
      "id" : 2185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "379829209293549568",
  "geo" : { },
  "id_str" : "379831748600684545",
  "in_reply_to_user_id" : 19872718,
  "text" : "Suggestions for coolest bath toy ever for a 3-year-old? RT @JeremySF: @buster +1 on more bath toys.",
  "id" : 379831748600684545,
  "in_reply_to_status_id" : 379829209293549568,
  "created_at" : "2013-09-17 04:58:40 +0000",
  "in_reply_to_screen_name" : "JeremySF",
  "in_reply_to_user_id_str" : "19872718",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u028E\u01DD\u029E\u0254\u0131\u0265 \u0287\u0287\u0250\u026F",
      "screen_name" : "matthickey",
      "indices" : [ 0, 11 ],
      "id_str" : "8710082",
      "id" : 8710082
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "379829485287116800",
  "geo" : { },
  "id_str" : "379830403986489345",
  "in_reply_to_user_id" : 8710082,
  "text" : "@matthickey I'm picturing rusty saws and scrap metal.",
  "id" : 379830403986489345,
  "in_reply_to_status_id" : 379829485287116800,
  "created_at" : "2013-09-17 04:53:19 +0000",
  "in_reply_to_screen_name" : "matthickey",
  "in_reply_to_user_id_str" : "8710082",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alisa Bonsignore",
      "screen_name" : "clearwriter",
      "indices" : [ 0, 12 ],
      "id_str" : "17029915",
      "id" : 17029915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "379829023590727680",
  "geo" : { },
  "id_str" : "379830097902989312",
  "in_reply_to_user_id" : 17029915,
  "text" : "@clearwriter Yeah, and the switch happened so quickly! My emotions take hours to shift gears these days.",
  "id" : 379830097902989312,
  "in_reply_to_status_id" : 379829023590727680,
  "created_at" : "2013-09-17 04:52:06 +0000",
  "in_reply_to_screen_name" : "clearwriter",
  "in_reply_to_user_id_str" : "17029915",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jessica Scheibach",
      "screen_name" : "jshy",
      "indices" : [ 0, 5 ],
      "id_str" : "804659",
      "id" : 804659
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nostalgia",
      "indices" : [ 128, 138 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "379829002208178177",
  "geo" : { },
  "id_str" : "379829658516086784",
  "in_reply_to_user_id" : 804659,
  "text" : "@jshy It's been a while since I totally gave into my rage like Niko can. I sorta miss burn all bridges take no survivors anger. #nostalgia",
  "id" : 379829658516086784,
  "in_reply_to_status_id" : 379829002208178177,
  "created_at" : "2013-09-17 04:50:22 +0000",
  "in_reply_to_screen_name" : "jshy",
  "in_reply_to_user_id_str" : "804659",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "379828035014238208",
  "geo" : { },
  "id_str" : "379828603602468864",
  "in_reply_to_user_id" : 2185,
  "text" : "Basically boiled down to playing with more toys in the bath, which is totally reasonable. Just excited to have had a successful negotiation.",
  "id" : 379828603602468864,
  "in_reply_to_status_id" : 379828035014238208,
  "created_at" : "2013-09-17 04:46:10 +0000",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "379828035014238208",
  "text" : "Post-meltdown I asked Niko if he had ideas on how to make bath time more fun / less tantrum-y &amp; for the first time he actually did!",
  "id" : 379828035014238208,
  "created_at" : "2013-09-17 04:43:55 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Isaac Hepworth",
      "screen_name" : "isaach",
      "indices" : [ 3, 10 ],
      "id_str" : "7852612",
      "id" : 7852612
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http://t.co/3Qchk4ZLON",
      "expanded_url" : "http://thehundreds.com/blog/2013/09/09/at-twitter/",
      "display_url" : "thehundreds.com/blog/2013/09/0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "379827151521857536",
  "text" : "RT @isaach: some nice pictures from behind the scenes at Twitter HQ http://t.co/3Qchk4ZLON",
  "retweeted_status" : {
    "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 56, 78 ],
        "url" : "http://t.co/3Qchk4ZLON",
        "expanded_url" : "http://thehundreds.com/blog/2013/09/09/at-twitter/",
        "display_url" : "thehundreds.com/blog/2013/09/0\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "379716323288576000",
    "text" : "some nice pictures from behind the scenes at Twitter HQ http://t.co/3Qchk4ZLON",
    "id" : 379716323288576000,
    "created_at" : "2013-09-16 21:20:00 +0000",
    "user" : {
      "name" : "Isaac Hepworth",
      "screen_name" : "isaach",
      "protected" : false,
      "id_str" : "7852612",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2581404026/image_normal.jpg",
      "id" : 7852612,
      "verified" : false
    }
  },
  "id" : 379827151521857536,
  "created_at" : "2013-09-17 04:40:24 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "William Morgan",
      "screen_name" : "wm",
      "indices" : [ 1, 4 ],
      "id_str" : "15504330",
      "id" : 15504330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "379815890646093826",
  "geo" : { },
  "id_str" : "379826696079175680",
  "in_reply_to_user_id" : 15504330,
  "text" : ".@wm The beautiful thing about children is that they can remind us of how we used to be filled with pure rage.",
  "id" : 379826696079175680,
  "in_reply_to_status_id" : 379815890646093826,
  "created_at" : "2013-09-17 04:38:35 +0000",
  "in_reply_to_screen_name" : "wm",
  "in_reply_to_user_id_str" : "15504330",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 54 ],
      "url" : "http://t.co/X88LvteQHy",
      "expanded_url" : "http://flic.kr/p/fUiKKG",
      "display_url" : "flic.kr/p/fUiKKG"
    } ]
  },
  "geo" : { },
  "id_str" : "379812222631178240",
  "text" : "8:36pm Scream into the tub time http://t.co/X88LvteQHy",
  "id" : 379812222631178240,
  "created_at" : "2013-09-17 03:41:05 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Brault",
      "screen_name" : "adambrault",
      "indices" : [ 16, 27 ],
      "id_str" : "1568",
      "id" : 1568
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 67 ],
      "url" : "https://t.co/UXgAnvKxcW",
      "expanded_url" : "https://speakerdeck.com/adambrault/people-first",
      "display_url" : "speakerdeck.com/adambrault/peo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "379748982454374400",
  "text" : "Amazing talk by @adambrault: \"People First\" https://t.co/UXgAnvKxcW",
  "id" : 379748982454374400,
  "created_at" : "2013-09-16 23:29:47 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Pell",
      "screen_name" : "davepell",
      "indices" : [ 3, 12 ],
      "id_str" : "224",
      "id" : 224
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "379685986927509504",
  "text" : "RT @davepell: Google acquired Bump. If they incorporate it into Google Glass, I'll be able to share my contact information with a head-butt.",
  "retweeted_status" : {
    "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "379685697818750976",
    "text" : "Google acquired Bump. If they incorporate it into Google Glass, I'll be able to share my contact information with a head-butt.",
    "id" : 379685697818750976,
    "created_at" : "2013-09-16 19:18:19 +0000",
    "user" : {
      "name" : "Dave Pell",
      "screen_name" : "davepell",
      "protected" : false,
      "id_str" : "224",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1131225374/twTitle-1_normal.jpg",
      "id" : 224,
      "verified" : false
    }
  },
  "id" : 379685986927509504,
  "created_at" : "2013-09-16 19:19:28 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "girl jo",
      "screen_name" : "octavekitten",
      "indices" : [ 0, 13 ],
      "id_str" : "16366882",
      "id" : 16366882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "379679160425148416",
  "geo" : { },
  "id_str" : "379679462717005824",
  "in_reply_to_user_id" : 16366882,
  "text" : "@octavekitten Hopefully something comes of it. Sorry to hear this is happening\u2026 such a cruel thing to do.",
  "id" : 379679462717005824,
  "in_reply_to_status_id" : 379679160425148416,
  "created_at" : "2013-09-16 18:53:32 +0000",
  "in_reply_to_screen_name" : "octavekitten",
  "in_reply_to_user_id_str" : "16366882",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "girl jo",
      "screen_name" : "octavekitten",
      "indices" : [ 0, 13 ],
      "id_str" : "16366882",
      "id" : 16366882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 66 ],
      "url" : "https://t.co/EjrSecz2MP",
      "expanded_url" : "https://support.twitter.com/forms/abusiveuser",
      "display_url" : "support.twitter.com/forms/abusiveu\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "379677485446615040",
  "geo" : { },
  "id_str" : "379678971001991168",
  "in_reply_to_user_id" : 16366882,
  "text" : "@octavekitten Definitely report the abuse. https://t.co/EjrSecz2MP",
  "id" : 379678971001991168,
  "in_reply_to_status_id" : 379677485446615040,
  "created_at" : "2013-09-16 18:51:35 +0000",
  "in_reply_to_screen_name" : "octavekitten",
  "in_reply_to_user_id_str" : "16366882",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Baio",
      "screen_name" : "waxpancake",
      "indices" : [ 3, 14 ],
      "id_str" : "13461",
      "id" : 13461
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http://t.co/EH00c284Ts",
      "expanded_url" : "http://www.theguardian.com/culture/2013/sep/13/russell-brand-gq-awards-hugo-boss",
      "display_url" : "theguardian.com/culture/2013/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "379646940805214208",
  "text" : "RT @waxpancake: This Russell Brand essay is the best. http://t.co/EH00c284Ts The crazy thing is that he speaks exactly like this.",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 38, 60 ],
        "url" : "http://t.co/EH00c284Ts",
        "expanded_url" : "http://www.theguardian.com/culture/2013/sep/13/russell-brand-gq-awards-hugo-boss",
        "display_url" : "theguardian.com/culture/2013/s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "379434199226130432",
    "text" : "This Russell Brand essay is the best. http://t.co/EH00c284Ts The crazy thing is that he speaks exactly like this.",
    "id" : 379434199226130432,
    "created_at" : "2013-09-16 02:38:57 +0000",
    "user" : {
      "name" : "Andy Baio",
      "screen_name" : "waxpancake",
      "protected" : false,
      "id_str" : "13461",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2722964270/4abc9d219d7bab89df50106c26e3a812_normal.png",
      "id" : 13461,
      "verified" : false
    }
  },
  "id" : 379646940805214208,
  "created_at" : "2013-09-16 16:44:18 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ArielMeadowStallings",
      "screen_name" : "OffbeatAriel",
      "indices" : [ 0, 13 ],
      "id_str" : "14095370",
      "id" : 14095370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "379475350826135552",
  "geo" : { },
  "id_str" : "379477596020305921",
  "in_reply_to_user_id" : 14095370,
  "text" : "@OffbeatAriel Ha. That's when my import script broke. Don't worry, my high output has remained high! Just need to backfill...",
  "id" : 379477596020305921,
  "in_reply_to_status_id" : 379475350826135552,
  "created_at" : "2013-09-16 05:31:23 +0000",
  "in_reply_to_screen_name" : "OffbeatAriel",
  "in_reply_to_user_id_str" : "14095370",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ted Rheingold",
      "screen_name" : "tedr",
      "indices" : [ 0, 5 ],
      "id_str" : "997",
      "id" : 997
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "379475402978115584",
  "geo" : { },
  "id_str" : "379477318751629312",
  "in_reply_to_user_id" : 997,
  "text" : "@tedr My first reply also provided a good example. :) Bug filed.",
  "id" : 379477318751629312,
  "in_reply_to_status_id" : 379475402978115584,
  "created_at" : "2013-09-16 05:30:17 +0000",
  "in_reply_to_screen_name" : "tedr",
  "in_reply_to_user_id_str" : "997",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ted Rheingold",
      "screen_name" : "tedr",
      "indices" : [ 0, 5 ],
      "id_str" : "997",
      "id" : 997
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "379470359637917697",
  "geo" : { },
  "id_str" : "379473241137356800",
  "in_reply_to_user_id" : 997,
  "text" : "@tedr Send me a screenshot? I can file a bug.",
  "id" : 379473241137356800,
  "in_reply_to_status_id" : 379470359637917697,
  "created_at" : "2013-09-16 05:14:05 +0000",
  "in_reply_to_screen_name" : "tedr",
  "in_reply_to_user_id_str" : "997",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 54 ],
      "url" : "http://t.co/ddcYDnBpGN",
      "expanded_url" : "http://busterbenson.com",
      "display_url" : "busterbenson.com"
    }, {
      "indices" : [ 79, 101 ],
      "url" : "http://t.co/ANI9MlzCc5",
      "expanded_url" : "http://flic.kr/p/fTdG3A",
      "display_url" : "flic.kr/p/fTdG3A"
    } ]
  },
  "geo" : { },
  "id_str" : "379469747089575936",
  "text" : "8:36pm Just messing around with http://t.co/ddcYDnBpGN. Added embedded tweets. http://t.co/ANI9MlzCc5",
  "id" : 379469747089575936,
  "created_at" : "2013-09-16 05:00:12 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carinna Tarvin",
      "screen_name" : "carinnatarvin",
      "indices" : [ 0, 14 ],
      "id_str" : "20833838",
      "id" : 20833838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "379336368557531136",
  "geo" : { },
  "id_str" : "379370154171187200",
  "in_reply_to_user_id" : 20833838,
  "text" : "@carinnatarvin Love it! Keep collecting evidence for my side! :)",
  "id" : 379370154171187200,
  "in_reply_to_status_id" : 379336368557531136,
  "created_at" : "2013-09-15 22:24:27 +0000",
  "in_reply_to_screen_name" : "carinnatarvin",
  "in_reply_to_user_id_str" : "20833838",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "josh",
      "screen_name" : "joshc",
      "indices" : [ 0, 6 ],
      "id_str" : "2015",
      "id" : 2015
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "379100962985480194",
  "geo" : { },
  "id_str" : "379109774257684480",
  "in_reply_to_user_id" : 2015,
  "text" : "@joshc Before or after you sip it?",
  "id" : 379109774257684480,
  "in_reply_to_status_id" : 379100962985480194,
  "created_at" : "2013-09-15 05:09:48 +0000",
  "in_reply_to_screen_name" : "joshc",
  "in_reply_to_user_id_str" : "2015",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 48 ],
      "url" : "http://t.co/ykHmRnI9hh",
      "expanded_url" : "http://flic.kr/p/fRYScu",
      "display_url" : "flic.kr/p/fRYScu"
    } ]
  },
  "geo" : { },
  "id_str" : "379091435091681280",
  "text" : "8:36pm Playing Wild Thing http://t.co/ykHmRnI9hh",
  "id" : 379091435091681280,
  "created_at" : "2013-09-15 03:56:55 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Fox",
      "screen_name" : "heychrisfox",
      "indices" : [ 0, 12 ],
      "id_str" : "9354282",
      "id" : 9354282
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "379001189456547840",
  "geo" : { },
  "id_str" : "379001489093447680",
  "in_reply_to_user_id" : 9354282,
  "text" : "@heychrisfox It's been stable... people seem to be okay with the idea.",
  "id" : 379001489093447680,
  "in_reply_to_status_id" : 379001189456547840,
  "created_at" : "2013-09-14 21:59:31 +0000",
  "in_reply_to_screen_name" : "heychrisfox",
  "in_reply_to_user_id_str" : "9354282",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Norbert Mocsnik",
      "screen_name" : "norbert_m",
      "indices" : [ 0, 10 ],
      "id_str" : "5759322",
      "id" : 5759322
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "378975534010859520",
  "geo" : { },
  "id_str" : "378985556597673984",
  "in_reply_to_user_id" : 5759322,
  "text" : "@norbert_m Not really. This is my one project that grows despite tremendous neglect.",
  "id" : 378985556597673984,
  "in_reply_to_status_id" : 378975534010859520,
  "created_at" : "2013-09-14 20:56:12 +0000",
  "in_reply_to_screen_name" : "norbert_m",
  "in_reply_to_user_id_str" : "5759322",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cool",
      "indices" : [ 130, 135 ]
    } ],
    "urls" : [ {
      "indices" : [ 45, 67 ],
      "url" : "http://t.co/qjUH5AFHun",
      "expanded_url" : "http://750words.com",
      "display_url" : "750words.com"
    } ]
  },
  "geo" : { },
  "id_str" : "378971332228022272",
  "text" : "I just did \"select count(*) from people;\" on http://t.co/qjUH5AFHun and got: 191531! That's sort of crazy for a fun side project. #cool",
  "id" : 378971332228022272,
  "created_at" : "2013-09-14 19:59:41 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Sarver",
      "screen_name" : "rsarver",
      "indices" : [ 11, 19 ],
      "id_str" : "795649",
      "id" : 795649
    }, {
      "name" : "Medium",
      "screen_name" : "Medium",
      "indices" : [ 46, 53 ],
      "id_str" : "571202103",
      "id" : 571202103
    }, {
      "name" : "Evan Williams",
      "screen_name" : "ev",
      "indices" : [ 79, 82 ],
      "id_str" : "20",
      "id" : 20
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http://t.co/gPiCUUTAGR",
      "expanded_url" : "http://techcrunch.com/2013/09/14/twitter-co-founder-evan-williams-lays-out-his-vision-for-medium/",
      "display_url" : "techcrunch.com/2013/09/14/twi\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "378902372656762880",
  "geo" : { },
  "id_str" : "378909760692563968",
  "in_reply_to_user_id" : 795649,
  "text" : "Me too. RT @rsarver: I'm excited to see where @Medium goes \"Twitter Co-Founder @Ev Lays Out Plan For Future Of Media\" http://t.co/gPiCUUTAGR",
  "id" : 378909760692563968,
  "in_reply_to_status_id" : 378902372656762880,
  "created_at" : "2013-09-14 15:55:01 +0000",
  "in_reply_to_screen_name" : "rsarver",
  "in_reply_to_user_id_str" : "795649",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 36, 46 ],
      "id_str" : "7362142",
      "id" : 7362142
    }, {
      "name" : "Ali Berman",
      "screen_name" : "spangley",
      "indices" : [ 74, 83 ],
      "id_str" : "776429",
      "id" : 776429
    }, {
      "name" : "Lane Collins",
      "screen_name" : "lane",
      "indices" : [ 88, 93 ],
      "id_str" : "541",
      "id" : 541
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lildude",
      "indices" : [ 7, 15 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http://t.co/6ZgNUQfTO2",
      "expanded_url" : "http://flic.kr/p/fQDBjb",
      "display_url" : "flic.kr/p/fQDBjb"
    } ]
  },
  "geo" : { },
  "id_str" : "378728203785093120",
  "text" : "8:36pm #lildude and Niko sitting on @kellianne post delicious dinner with @spangley and @lane http://t.co/6ZgNUQfTO2",
  "id" : 378728203785093120,
  "created_at" : "2013-09-14 03:53:34 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erika Hall",
      "screen_name" : "mulegirl",
      "indices" : [ 16, 25 ],
      "id_str" : "2391",
      "id" : 2391
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http://t.co/OpuFqq55Gn",
      "expanded_url" : "http://www.abookapart.com/products/just-enough-research",
      "display_url" : "abookapart.com/products/just-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "378577727961321472",
  "text" : "Excited to read @mulegirl's new book, \"Just Enough Research\". Currently loaded on my Kindle for the BART ride home: http://t.co/OpuFqq55Gn",
  "id" : 378577727961321472,
  "created_at" : "2013-09-13 17:55:38 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "378561052373307394",
  "text" : "Nothing like a nice quiet breakfast to start the day.",
  "id" : 378561052373307394,
  "created_at" : "2013-09-13 16:49:22 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http://t.co/K3XIYGHsFG",
      "expanded_url" : "http://instagram.com/p/eMVHjRo0Ef/",
      "display_url" : "instagram.com/p/eMVHjRo0Ef/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.783283028, -122.407135947 ]
  },
  "id_str" : "378424232184922112",
  "text" : "8:36pm Late:36 because we had a fun dinner with Cameron and Amanda but forgot to take a picture then\u2026 http://t.co/K3XIYGHsFG",
  "id" : 378424232184922112,
  "created_at" : "2013-09-13 07:45:42 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Singer",
      "screen_name" : "singy",
      "indices" : [ 0, 6 ],
      "id_str" : "15310552",
      "id" : 15310552
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "378387651780300800",
  "geo" : { },
  "id_str" : "378409264521289728",
  "in_reply_to_user_id" : 15310552,
  "text" : "@singy Condolences to you and your family. Sad times.",
  "id" : 378409264521289728,
  "in_reply_to_status_id" : 378387651780300800,
  "created_at" : "2013-09-13 06:46:13 +0000",
  "in_reply_to_screen_name" : "singy",
  "in_reply_to_user_id_str" : "15310552",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Reeve S. Thompson ",
      "screen_name" : "Reeve",
      "indices" : [ 0, 6 ],
      "id_str" : "9317922",
      "id" : 9317922
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "pumpkineater",
      "indices" : [ 7, 20 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "378405603376246784",
  "geo" : { },
  "id_str" : "378407011899015169",
  "in_reply_to_user_id" : 9317922,
  "text" : "@Reeve #pumpkineater",
  "id" : 378407011899015169,
  "in_reply_to_status_id" : 378405603376246784,
  "created_at" : "2013-09-13 06:37:16 +0000",
  "in_reply_to_screen_name" : "Reeve",
  "in_reply_to_user_id_str" : "9317922",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://vine.co\" rel=\"nofollow\">Vine - Make a Scene</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "soccerpachinko",
      "indices" : [ 13, 28 ]
    } ],
    "urls" : [ {
      "indices" : [ 29, 52 ],
      "url" : "https://t.co/4mmpYq0OIR",
      "expanded_url" : "https://vine.co/v/hnav61KiHYe",
      "display_url" : "vine.co/v/hnav61KiHYe"
    } ]
  },
  "geo" : { },
  "id_str" : "378405364775256064",
  "text" : "8 at a time! #soccerpachinko https://t.co/4mmpYq0OIR",
  "id" : 378405364775256064,
  "created_at" : "2013-09-13 06:30:44 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://vine.co\" rel=\"nofollow\">Vine - Make a Scene</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 39 ],
      "url" : "https://t.co/FviVo8CRyj",
      "expanded_url" : "https://vine.co/v/hnaeOlXQq1a",
      "display_url" : "vine.co/v/hnaeOlXQq1a"
    } ]
  },
  "geo" : { },
  "id_str" : "378401178784370688",
  "text" : "Soccer pachinko https://t.co/FviVo8CRyj",
  "id" : 378401178784370688,
  "created_at" : "2013-09-13 06:14:06 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "378326391072104448",
  "text" : "Mmmmm cashews.",
  "id" : 378326391072104448,
  "created_at" : "2013-09-13 01:16:55 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "April Schiller",
      "screen_name" : "the_april",
      "indices" : [ 0, 10 ],
      "id_str" : "16644937",
      "id" : 16644937
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "378292242479194112",
  "geo" : { },
  "id_str" : "378293276366761985",
  "in_reply_to_user_id" : 16644937,
  "text" : "@the_april I &lt;3 apples!",
  "id" : 378293276366761985,
  "in_reply_to_status_id" : 378292242479194112,
  "created_at" : "2013-09-12 23:05:20 +0000",
  "in_reply_to_screen_name" : "the_april",
  "in_reply_to_user_id_str" : "16644937",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Crocker",
      "screen_name" : "nickcrocker",
      "indices" : [ 0, 12 ],
      "id_str" : "30801469",
      "id" : 30801469
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "378286324374962176",
  "geo" : { },
  "id_str" : "378287067010043905",
  "in_reply_to_user_id" : 30801469,
  "text" : "@nickcrocker Wouldn't the slippery slope argument imply that if I skip lunch then I might start skipping all meals? Sounds dangerous.",
  "id" : 378287067010043905,
  "in_reply_to_status_id" : 378286324374962176,
  "created_at" : "2013-09-12 22:40:39 +0000",
  "in_reply_to_screen_name" : "nickcrocker",
  "in_reply_to_user_id_str" : "30801469",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "378279763854376961",
  "text" : "I'm hungry. Should I have a late lunch or wait for dinner?",
  "id" : 378279763854376961,
  "created_at" : "2013-09-12 22:11:38 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 3, 11 ],
      "id_str" : "783214",
      "id" : 783214
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "378262680101875712",
  "text" : "RT @twitter: We\u2019ve confidentially submitted an S-1 to the SEC for a planned IPO. This Tweet does not constitute an offer of any securities \u2026",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "378261932148416512",
    "text" : "We\u2019ve confidentially submitted an S-1 to the SEC for a planned IPO. This Tweet does not constitute an offer of any securities for sale.",
    "id" : 378261932148416512,
    "created_at" : "2013-09-12 21:00:47 +0000",
    "user" : {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "protected" : false,
      "id_str" : "783214",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2284174758/v65oai7fxn47qv9nectx_normal.png",
      "id" : 783214,
      "verified" : true
    }
  },
  "id" : 378262680101875712,
  "created_at" : "2013-09-12 21:03:45 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leo Babauta",
      "screen_name" : "zen_habits",
      "indices" : [ 19, 30 ],
      "id_str" : "15859268",
      "id" : 15859268
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "378242771951161344",
  "text" : "Finally met Leo of @zen_habits. A++ Would meet again!",
  "id" : 378242771951161344,
  "created_at" : "2013-09-12 19:44:38 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nassim N. Taleb",
      "screen_name" : "nntaleb",
      "indices" : [ 55, 63 ],
      "id_str" : "381289719",
      "id" : 381289719
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "378200166312189952",
  "geo" : { },
  "id_str" : "378200909613772800",
  "in_reply_to_user_id" : 381289719,
  "text" : "Trying to reduce variability often multiplies risk. RT @nntaleb: Our central problem is the unshakable conflation of variability and risk.",
  "id" : 378200909613772800,
  "in_reply_to_status_id" : 378200166312189952,
  "created_at" : "2013-09-12 16:58:18 +0000",
  "in_reply_to_screen_name" : "nntaleb",
  "in_reply_to_user_id_str" : "381289719",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "378195145478262785",
  "text" : "My new doctor wears a bow tie. His advice is therefore 50% more authoritative.",
  "id" : 378195145478262785,
  "created_at" : "2013-09-12 16:35:23 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mandy Brown",
      "screen_name" : "aworkinglibrary",
      "indices" : [ 3, 19 ],
      "id_str" : "11133442",
      "id" : 11133442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http://t.co/Btv4SNQ9aC",
      "expanded_url" : "http://www.garann.com/dev/2013/how-to-blog-about-code-and-give-zero-fucks/",
      "display_url" : "garann.com/dev/2013/how-t\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "378158418227253249",
  "text" : "RT @aworkinglibrary: How to blog about code and give zero fucks: http://t.co/Btv4SNQ9aC",
  "retweeted_status" : {
    "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 44, 66 ],
        "url" : "http://t.co/Btv4SNQ9aC",
        "expanded_url" : "http://www.garann.com/dev/2013/how-to-blog-about-code-and-give-zero-fucks/",
        "display_url" : "garann.com/dev/2013/how-t\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "378151108671438848",
    "text" : "How to blog about code and give zero fucks: http://t.co/Btv4SNQ9aC",
    "id" : 378151108671438848,
    "created_at" : "2013-09-12 13:40:24 +0000",
    "user" : {
      "name" : "Mandy Brown",
      "screen_name" : "aworkinglibrary",
      "protected" : false,
      "id_str" : "11133442",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2919538988/9aeb1ced2ce1134c5eb38038b4c38f3a_normal.jpeg",
      "id" : 11133442,
      "verified" : false
    }
  },
  "id" : 378158418227253249,
  "created_at" : "2013-09-12 14:09:27 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amazing Data",
      "screen_name" : "DataIsAmazing",
      "indices" : [ 3, 17 ],
      "id_str" : "1675352647",
      "id" : 1675352647
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/DataIsAmazing/status/377549623344521216/photo/1",
      "indices" : [ 94, 116 ],
      "url" : "http://t.co/vT4BvlIlTb",
      "media_url" : "http://pbs.twimg.com/media/BT1TYb-IMAA2iAp.jpg",
      "id_str" : "377549623059296256",
      "id" : 377549623059296256,
      "media_url_https" : "https://pbs.twimg.com/media/BT1TYb-IMAA2iAp.jpg",
      "sizes" : [ {
        "h" : 221,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1800,
        "resize" : "fit",
        "w" : 2764
      }, {
        "h" : 667,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 391,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com/vT4BvlIlTb"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "378106436154171392",
  "text" : "RT @DataIsAmazing: The position of every known piece of space debris currently orbiting earth http://t.co/vT4BvlIlTb",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http://twitter.com/DataIsAmazing/status/377549623344521216/photo/1",
        "indices" : [ 75, 97 ],
        "url" : "http://t.co/vT4BvlIlTb",
        "media_url" : "http://pbs.twimg.com/media/BT1TYb-IMAA2iAp.jpg",
        "id_str" : "377549623059296256",
        "id" : 377549623059296256,
        "media_url_https" : "https://pbs.twimg.com/media/BT1TYb-IMAA2iAp.jpg",
        "sizes" : [ {
          "h" : 221,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1800,
          "resize" : "fit",
          "w" : 2764
        }, {
          "h" : 667,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 391,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com/vT4BvlIlTb"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "377549623344521216",
    "text" : "The position of every known piece of space debris currently orbiting earth http://t.co/vT4BvlIlTb",
    "id" : 377549623344521216,
    "created_at" : "2013-09-10 21:50:19 +0000",
    "user" : {
      "name" : "Amazing Data",
      "screen_name" : "DataIsAmazing",
      "protected" : false,
      "id_str" : "1675352647",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000434919091/2ef80a646c9ff153baed1c853fa13523_normal.jpeg",
      "id" : 1675352647,
      "verified" : false
    }
  },
  "id" : 378106436154171392,
  "created_at" : "2013-09-12 10:42:53 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wifeymaterial",
      "indices" : [ 74, 88 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "378103895639093248",
  "text" : "Kellianne just chased some raccoons out of our house at 3 in the morning. #wifeymaterial",
  "id" : 378103895639093248,
  "created_at" : "2013-09-12 10:32:48 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sharon",
      "screen_name" : "sharon",
      "indices" : [ 35, 42 ],
      "id_str" : "260",
      "id" : 260
    }, {
      "name" : "Ian McKellar",
      "screen_name" : "ian",
      "indices" : [ 47, 51 ],
      "id_str" : "259",
      "id" : 259
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http://t.co/Tlan00OLRd",
      "expanded_url" : "http://flic.kr/p/fPNvUL",
      "display_url" : "flic.kr/p/fPNvUL"
    } ]
  },
  "geo" : { },
  "id_str" : "378010864911011840",
  "text" : "8:36pm Dinner at Lanesplitter with @sharon and @ian http://t.co/Tlan00OLRd",
  "id" : 378010864911011840,
  "created_at" : "2013-09-12 04:23:07 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael A. Smith",
      "screen_name" : "michaelasmith",
      "indices" : [ 0, 14 ],
      "id_str" : "16609638",
      "id" : 16609638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "377970306247192576",
  "geo" : { },
  "id_str" : "377973900224626689",
  "in_reply_to_user_id" : 16609638,
  "text" : "@michaelasmith Oh yeah that too!",
  "id" : 377973900224626689,
  "in_reply_to_status_id" : 377970306247192576,
  "created_at" : "2013-09-12 01:56:14 +0000",
  "in_reply_to_screen_name" : "michaelasmith",
  "in_reply_to_user_id_str" : "16609638",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael A. Smith",
      "screen_name" : "michaelasmith",
      "indices" : [ 0, 14 ],
      "id_str" : "16609638",
      "id" : 16609638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "377969595887259650",
  "geo" : { },
  "id_str" : "377969921600143361",
  "in_reply_to_user_id" : 16609638,
  "text" : "@michaelasmith What makes you think so?",
  "id" : 377969921600143361,
  "in_reply_to_status_id" : 377969595887259650,
  "created_at" : "2013-09-12 01:40:26 +0000",
  "in_reply_to_screen_name" : "michaelasmith",
  "in_reply_to_user_id_str" : "16609638",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "377969740783702016",
  "text" : "I wonder what the oldest still active string of DNA, oldest still in print sentence, and oldest still running line of code are.",
  "id" : 377969740783702016,
  "created_at" : "2013-09-12 01:39:43 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tothedeath",
      "indices" : [ 74, 85 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "377969003244695552",
  "text" : "DNA vs books vs software in the battle for ultimate information survival. #tothedeath",
  "id" : 377969003244695552,
  "created_at" : "2013-09-12 01:36:47 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Hedlund",
      "screen_name" : "marcprecipice",
      "indices" : [ 3, 17 ],
      "id_str" : "226976689",
      "id" : 226976689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "377896573377585152",
  "text" : "RT @marcprecipice: \"If you had spent more time with your family, do you think you\u2019d regret not having progressed as far...?\" http://t.co/oP\u2026",
  "retweeted_status" : {
    "source" : "<a href=\"http://itunes.apple.com/us/app/newsblur/id463981119?mt=8&uo=4\" rel=\"nofollow\">NewsBlur on iOS</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 106, 128 ],
        "url" : "http://t.co/oPp0pnTp5N",
        "expanded_url" : "http://www.humansofnewyork.com/post/60942607020",
        "display_url" : "humansofnewyork.com/post/609426070\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "377846429618016256",
    "text" : "\"If you had spent more time with your family, do you think you\u2019d regret not having progressed as far...?\" http://t.co/oPp0pnTp5N",
    "id" : 377846429618016256,
    "created_at" : "2013-09-11 17:29:43 +0000",
    "user" : {
      "name" : "Marc Hedlund",
      "screen_name" : "marcprecipice",
      "protected" : false,
      "id_str" : "226976689",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2321403275/b546axjksj5f7z194wjm_normal.jpeg",
      "id" : 226976689,
      "verified" : false
    }
  },
  "id" : 377896573377585152,
  "created_at" : "2013-09-11 20:48:58 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Raffi Krikorian",
      "screen_name" : "raffi",
      "indices" : [ 3, 9 ],
      "id_str" : "8285392",
      "id" : 8285392
    }, {
      "name" : "Lady Gaga",
      "screen_name" : "ladygaga",
      "indices" : [ 23, 32 ],
      "id_str" : "14230524",
      "id" : 14230524
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/raffi/status/377481543108665344/photo/1",
      "indices" : [ 93, 115 ],
      "url" : "http://t.co/PFlcLYhS4X",
      "media_url" : "http://pbs.twimg.com/media/BT0VdqaCIAA1SNs.jpg",
      "id_str" : "377481543112859648",
      "id" : 377481543112859648,
      "media_url_https" : "https://pbs.twimg.com/media/BT0VdqaCIAA1SNs.jpg",
      "sizes" : [ {
        "h" : 553,
        "resize" : "fit",
        "w" : 553
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 553,
        "resize" : "fit",
        "w" : 553
      }, {
        "h" : 553,
        "resize" : "fit",
        "w" : 553
      } ],
      "display_url" : "pic.twitter.com/PFlcLYhS4X"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "377885450746486784",
  "text" : "RT @raffi: ask \"what's @ladygaga saying?\", and siri pulls up her most recent tweets in iOS 7 http://t.co/PFlcLYhS4X",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Lady Gaga",
        "screen_name" : "ladygaga",
        "indices" : [ 12, 21 ],
        "id_str" : "14230524",
        "id" : 14230524
      } ],
      "media" : [ {
        "expanded_url" : "http://twitter.com/raffi/status/377481543108665344/photo/1",
        "indices" : [ 82, 104 ],
        "url" : "http://t.co/PFlcLYhS4X",
        "media_url" : "http://pbs.twimg.com/media/BT0VdqaCIAA1SNs.jpg",
        "id_str" : "377481543112859648",
        "id" : 377481543112859648,
        "media_url_https" : "https://pbs.twimg.com/media/BT0VdqaCIAA1SNs.jpg",
        "sizes" : [ {
          "h" : 553,
          "resize" : "fit",
          "w" : 553
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 553,
          "resize" : "fit",
          "w" : 553
        }, {
          "h" : 553,
          "resize" : "fit",
          "w" : 553
        } ],
        "display_url" : "pic.twitter.com/PFlcLYhS4X"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "377481543108665344",
    "text" : "ask \"what's @ladygaga saying?\", and siri pulls up her most recent tweets in iOS 7 http://t.co/PFlcLYhS4X",
    "id" : 377481543108665344,
    "created_at" : "2013-09-10 17:19:47 +0000",
    "user" : {
      "name" : "Raffi Krikorian",
      "screen_name" : "raffi",
      "protected" : false,
      "id_str" : "8285392",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1270234259/raffi-headshot-casual_normal.png",
      "id" : 8285392,
      "verified" : false
    }
  },
  "id" : 377885450746486784,
  "created_at" : "2013-09-11 20:04:47 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Stubblebine",
      "screen_name" : "tonystubblebine",
      "indices" : [ 0, 16 ],
      "id_str" : "17",
      "id" : 17
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "377844525445566464",
  "geo" : { },
  "id_str" : "377848520943751168",
  "in_reply_to_user_id" : 17,
  "text" : "@tonystubblebine Don't let them push you around. You're the boss.",
  "id" : 377848520943751168,
  "in_reply_to_status_id" : 377844525445566464,
  "created_at" : "2013-09-11 17:38:02 +0000",
  "in_reply_to_screen_name" : "tonystubblebine",
  "in_reply_to_user_id_str" : "17",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Craig Mod",
      "screen_name" : "craigmod",
      "indices" : [ 53, 62 ],
      "id_str" : "1835951",
      "id" : 1835951
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "377550926866706432",
  "text" : "Gadgets should focus on non-accelerometer sensors RT @craigmod: As expected, iPhone becoming the fitbit/Nike+/jawbone Up replacement device.",
  "id" : 377550926866706432,
  "created_at" : "2013-09-10 21:55:30 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay Holler",
      "screen_name" : "jayholler",
      "indices" : [ 0, 10 ],
      "id_str" : "14110325",
      "id" : 14110325
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "377471854585192448",
  "geo" : { },
  "id_str" : "377472134009737217",
  "in_reply_to_user_id" : 14110325,
  "text" : "@jayholler There should be! Looks like something went wrong on this tweet though... it's not loading the image for me.",
  "id" : 377472134009737217,
  "in_reply_to_status_id" : 377471854585192448,
  "created_at" : "2013-09-10 16:42:24 +0000",
  "in_reply_to_screen_name" : "jayholler",
  "in_reply_to_user_id_str" : "14110325",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "brynn evans",
      "screen_name" : "brynn",
      "indices" : [ 3, 9 ],
      "id_str" : "8708232",
      "id" : 8708232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http://t.co/fhyVXLWJh1",
      "expanded_url" : "http://blog.kissmetrics.com/single-startup-metric/",
      "display_url" : "blog.kissmetrics.com/single-startup\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377471821202726912",
  "text" : "RT @brynn: How to use a single metric to run your startup. What would you choose? http://t.co/fhyVXLWJh1",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 71, 93 ],
        "url" : "http://t.co/fhyVXLWJh1",
        "expanded_url" : "http://blog.kissmetrics.com/single-startup-metric/",
        "display_url" : "blog.kissmetrics.com/single-startup\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "377464482693255168",
    "text" : "How to use a single metric to run your startup. What would you choose? http://t.co/fhyVXLWJh1",
    "id" : 377464482693255168,
    "created_at" : "2013-09-10 16:12:00 +0000",
    "user" : {
      "name" : "brynn evans",
      "screen_name" : "brynn",
      "protected" : false,
      "id_str" : "8708232",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3235301745/7ce13bc08bef282d36596b9ca0c6dc7a_normal.jpeg",
      "id" : 8708232,
      "verified" : false
    }
  },
  "id" : 377471821202726912,
  "created_at" : "2013-09-10 16:41:09 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 52 ],
      "url" : "http://t.co/cCf6x4LYel",
      "expanded_url" : "http://flic.kr/p/fNzPPp",
      "display_url" : "flic.kr/p/fNzPPp"
    } ]
  },
  "geo" : { },
  "id_str" : "377469054338215936",
  "text" : "New Twitter sign looking good http://t.co/cCf6x4LYel",
  "id" : 377469054338215936,
  "created_at" : "2013-09-10 16:30:10 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Pullara",
      "screen_name" : "sampullara",
      "indices" : [ 3, 14 ],
      "id_str" : "668473",
      "id" : 668473
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https://t.co/J586EvZy7n",
      "expanded_url" : "https://www.usenix.org/blog/my-daughters-high-school-programming-teacher",
      "display_url" : "usenix.org/blog/my-daught\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "377310819349831680",
  "text" : "RT @sampullara: A hard to read account of a young girl ready to learn to program only to be harassed https://t.co/J586EvZy7n",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 85, 108 ],
        "url" : "https://t.co/J586EvZy7n",
        "expanded_url" : "https://www.usenix.org/blog/my-daughters-high-school-programming-teacher",
        "display_url" : "usenix.org/blog/my-daught\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "377309303553552384",
    "text" : "A hard to read account of a young girl ready to learn to program only to be harassed https://t.co/J586EvZy7n",
    "id" : 377309303553552384,
    "created_at" : "2013-09-10 05:55:22 +0000",
    "user" : {
      "name" : "Sam Pullara",
      "screen_name" : "sampullara",
      "protected" : false,
      "id_str" : "668473",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2932636652/dc1afcf49447e1464ef851be0a6eea8c_normal.jpeg",
      "id" : 668473,
      "verified" : false
    }
  },
  "id" : 377310819349831680,
  "created_at" : "2013-09-10 06:01:24 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kc",
      "screen_name" : "kris",
      "indices" : [ 0, 5 ],
      "id_str" : "115734106",
      "id" : 115734106
    }, {
      "name" : "Doug Bowman",
      "screen_name" : "stop",
      "indices" : [ 6, 11 ],
      "id_str" : "949521",
      "id" : 949521
    }, {
      "name" : "Brian Ellin",
      "screen_name" : "brianellin",
      "indices" : [ 12, 23 ],
      "id_str" : "26123649",
      "id" : 26123649
    }, {
      "name" : "Michael Ducker",
      "screen_name" : "miradu",
      "indices" : [ 24, 31 ],
      "id_str" : "1530531",
      "id" : 1530531
    }, {
      "name" : "Michael Sippey",
      "screen_name" : "sippey",
      "indices" : [ 32, 39 ],
      "id_str" : "4711",
      "id" : 4711
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "377305694891806720",
  "geo" : { },
  "id_str" : "377307377696927744",
  "in_reply_to_user_id" : 115734106,
  "text" : "@kris @stop @brianellin @miradu @sippey Replace \"reply\" with \"mutter\" when appropriate. And long tap for \"scream into pillow\".",
  "id" : 377307377696927744,
  "in_reply_to_status_id" : 377305694891806720,
  "created_at" : "2013-09-10 05:47:43 +0000",
  "in_reply_to_screen_name" : "kris",
  "in_reply_to_user_id_str" : "115734106",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 73 ],
      "url" : "http://t.co/qLJWXXelIT",
      "expanded_url" : "http://flic.kr/p/fNfk12",
      "display_url" : "flic.kr/p/fNfk12"
    } ]
  },
  "geo" : { },
  "id_str" : "377275340655050752",
  "text" : "8:36pm Playing Chutes and Ladders, anarchy edition http://t.co/qLJWXXelIT",
  "id" : 377275340655050752,
  "created_at" : "2013-09-10 03:40:25 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Kathleen Peck",
      "screen_name" : "sarahkpeck",
      "indices" : [ 0, 11 ],
      "id_str" : "196745496",
      "id" : 196745496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "377257115309445120",
  "geo" : { },
  "id_str" : "377257941683814402",
  "in_reply_to_user_id" : 196745496,
  "text" : "@sarahkpeck Like who?? I'd love to follow...",
  "id" : 377257941683814402,
  "in_reply_to_status_id" : 377257115309445120,
  "created_at" : "2013-09-10 02:31:17 +0000",
  "in_reply_to_screen_name" : "sarahkpeck",
  "in_reply_to_user_id_str" : "196745496",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Josuweit",
      "screen_name" : "josablack",
      "indices" : [ 0, 10 ],
      "id_str" : "26769877",
      "id" : 26769877
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "377182292994572288",
  "geo" : { },
  "id_str" : "377182425517809664",
  "in_reply_to_user_id" : 26769877,
  "text" : "@josablack Go for it!",
  "id" : 377182425517809664,
  "in_reply_to_status_id" : 377182292994572288,
  "created_at" : "2013-09-09 21:31:12 +0000",
  "in_reply_to_screen_name" : "josablack",
  "in_reply_to_user_id_str" : "26769877",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Josuweit",
      "screen_name" : "josablack",
      "indices" : [ 0, 10 ],
      "id_str" : "26769877",
      "id" : 26769877
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "377157392003108866",
  "geo" : { },
  "id_str" : "377181858171088896",
  "in_reply_to_user_id" : 26769877,
  "text" : "@josablack I wrote my own parser for that stuff. Keep meaning to find time to open it up, but haven't yet.",
  "id" : 377181858171088896,
  "in_reply_to_status_id" : 377157392003108866,
  "created_at" : "2013-09-09 21:28:57 +0000",
  "in_reply_to_screen_name" : "josablack",
  "in_reply_to_user_id_str" : "26769877",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aimee",
      "screen_name" : "LilHossler",
      "indices" : [ 0, 11 ],
      "id_str" : "123116307",
      "id" : 123116307
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "377125514932011008",
  "geo" : { },
  "id_str" : "377146188778065921",
  "in_reply_to_user_id" : 123116307,
  "text" : "@LilHossler Most reports I heard when I asked around for similar reasons is that AT&amp;T is probably best for Seattle.",
  "id" : 377146188778065921,
  "in_reply_to_status_id" : 377125514932011008,
  "created_at" : "2013-09-09 19:07:13 +0000",
  "in_reply_to_screen_name" : "LilHossler",
  "in_reply_to_user_id_str" : "123116307",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Libby Brittain",
      "screen_name" : "libbybrittain",
      "indices" : [ 0, 14 ],
      "id_str" : "18749271",
      "id" : 18749271
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "377075327899824128",
  "geo" : { },
  "id_str" : "377085617470861312",
  "in_reply_to_user_id" : 18749271,
  "text" : "@libbybrittain Have you created an ads account already? What kind of analytics do you want? I can help: buster@twitter.com",
  "id" : 377085617470861312,
  "in_reply_to_status_id" : 377075327899824128,
  "created_at" : "2013-09-09 15:06:31 +0000",
  "in_reply_to_screen_name" : "libbybrittain",
  "in_reply_to_user_id_str" : "18749271",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http://t.co/HXW2dNdfpB",
      "expanded_url" : "http://bit.ly/17OSDvm",
      "display_url" : "bit.ly/17OSDvm"
    } ]
  },
  "geo" : { },
  "id_str" : "376963783584784384",
  "text" : "I updated my guide to being enraged on the internet with a 3rd option due to recent events on the internet: http://t.co/HXW2dNdfpB",
  "id" : 376963783584784384,
  "created_at" : "2013-09-09 07:02:24 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "megan quinn",
      "screen_name" : "msquinn",
      "indices" : [ 0, 8 ],
      "id_str" : "15293504",
      "id" : 15293504
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "376943942840758273",
  "geo" : { },
  "id_str" : "376959728187740161",
  "in_reply_to_user_id" : 15293504,
  "text" : "@msquinn Or have 3yo boys. I'm totally showing this to Niko first thing tomorrow morning!",
  "id" : 376959728187740161,
  "in_reply_to_status_id" : 376943942840758273,
  "created_at" : "2013-09-09 06:46:17 +0000",
  "in_reply_to_screen_name" : "msquinn",
  "in_reply_to_user_id_str" : "15293504",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 57 ],
      "url" : "http://t.co/Vy7sdqS0GO",
      "expanded_url" : "http://flic.kr/p/fMyL6X",
      "display_url" : "flic.kr/p/fMyL6X"
    } ]
  },
  "geo" : { },
  "id_str" : "376917830559490048",
  "text" : "8:36pm Teaching Niko about selfies http://t.co/Vy7sdqS0GO",
  "id" : 376917830559490048,
  "created_at" : "2013-09-09 03:59:48 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "376837653963890688",
  "text" : "\"Perhaps there is a realm of wisdom from which the logician is exiled.\" - Nietzsche via Antifragile",
  "id" : 376837653963890688,
  "created_at" : "2013-09-08 22:41:12 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Ellin",
      "screen_name" : "brianellin",
      "indices" : [ 31, 42 ],
      "id_str" : "26123649",
      "id" : 26123649
    }, {
      "name" : "Buster",
      "screen_name" : "buster",
      "indices" : [ 44, 51 ],
      "id_str" : "2185",
      "id" : 2185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 75 ],
      "url" : "https://t.co/YO2dahbCJZ",
      "expanded_url" : "https://twitter.com/search?q=mt%20diablo%20fire",
      "display_url" : "twitter.com/search?q=mt%20\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "376833532477206529",
  "geo" : { },
  "id_str" : "376835388607696896",
  "in_reply_to_user_id" : 26123649,
  "text" : "I swear we didn't start it. RT @brianellin: @buster https://t.co/YO2dahbCJZ looks to be just getting started.  glad you made it down!",
  "id" : 376835388607696896,
  "in_reply_to_status_id" : 376833532477206529,
  "created_at" : "2013-09-08 22:32:12 +0000",
  "in_reply_to_screen_name" : "brianellin",
  "in_reply_to_user_id_str" : "26123649",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Ellin",
      "screen_name" : "brianellin",
      "indices" : [ 0, 11 ],
      "id_str" : "26123649",
      "id" : 26123649
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "376830950555938816",
  "geo" : { },
  "id_str" : "376831229531652096",
  "in_reply_to_user_id" : 26123649,
  "text" : "@brianellin Woah! Back down now... it was pretty dry up there...",
  "id" : 376831229531652096,
  "in_reply_to_status_id" : 376830950555938816,
  "created_at" : "2013-09-08 22:15:40 +0000",
  "in_reply_to_screen_name" : "brianellin",
  "in_reply_to_user_id_str" : "26123649",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.mapmyride.com\" rel=\"nofollow\">MapMyRide Mobile</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http://t.co/9oirejcAwm",
      "expanded_url" : "http://mmf.cc/17JF0l7",
      "display_url" : "mmf.cc/17JF0l7"
    } ]
  },
  "geo" : { },
  "id_str" : "376825301340131329",
  "text" : "The route we took yesterday up to Mt Diablo Live Oak campgrounds. Niko's first biking camping trip, of many we hope. http://t.co/9oirejcAwm",
  "id" : 376825301340131329,
  "created_at" : "2013-09-08 21:52:07 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/buster/status/376817039286861825/photo/1",
      "indices" : [ 0, 22 ],
      "url" : "http://t.co/xJSB77CnfR",
      "media_url" : "http://pbs.twimg.com/media/BTq5Gb0CMAAXrzi.jpg",
      "id_str" : "376817039035215872",
      "id" : 376817039035215872,
      "media_url_https" : "https://pbs.twimg.com/media/BTq5Gb0CMAAXrzi.jpg",
      "sizes" : [ {
        "h" : 232,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 77,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 136,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 232,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com/xJSB77CnfR"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "376817039286861825",
  "text" : "http://t.co/xJSB77CnfR",
  "id" : 376817039286861825,
  "created_at" : "2013-09-08 21:19:17 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http://t.co/GN3xmBLGlE",
      "expanded_url" : "http://flic.kr/p/fMm7cT",
      "display_url" : "flic.kr/p/fMm7cT"
    } ]
  },
  "geo" : { },
  "id_str" : "376815044157132803",
  "text" : "Tucked in one of the smaller Mt Diablo wind caves http://t.co/GN3xmBLGlE",
  "id" : 376815044157132803,
  "created_at" : "2013-09-08 21:11:22 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 59 ],
      "url" : "http://t.co/4VLxOLxEav",
      "expanded_url" : "http://flic.kr/p/fM3Srw",
      "display_url" : "flic.kr/p/fM3Srw"
    } ]
  },
  "geo" : { },
  "id_str" : "376550409277415425",
  "text" : "8:36pm Claiming our camp at Live Oak http://t.co/4VLxOLxEav",
  "id" : 376550409277415425,
  "created_at" : "2013-09-08 03:39:48 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://vine.co\" rel=\"nofollow\">Vine - Make a Scene</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https://t.co/ciNxnFPNyT",
      "expanded_url" : "https://vine.co/v/hJVm2pbaV6X",
      "display_url" : "vine.co/v/hJVm2pbaV6X"
    } ]
  },
  "geo" : { },
  "id_str" : "376501830924369920",
  "text" : "Protip: don't carry a kid trailer up to Mt Diablo if you're a biking newbie https://t.co/ciNxnFPNyT",
  "id" : 376501830924369920,
  "created_at" : "2013-09-08 00:26:46 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcel Molina",
      "screen_name" : "noradio",
      "indices" : [ 0, 8 ],
      "id_str" : "3191321",
      "id" : 3191321
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "376382668289478656",
  "geo" : { },
  "id_str" : "376383566264811520",
  "in_reply_to_user_id" : 3191321,
  "text" : "@noradio I've already forgotten what we were talking about.",
  "id" : 376383566264811520,
  "in_reply_to_status_id" : 376382668289478656,
  "created_at" : "2013-09-07 16:36:49 +0000",
  "in_reply_to_screen_name" : "noradio",
  "in_reply_to_user_id_str" : "3191321",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Isaac Hepworth",
      "screen_name" : "isaach",
      "indices" : [ 0, 7 ],
      "id_str" : "7852612",
      "id" : 7852612
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "376224481133334528",
  "geo" : { },
  "id_str" : "376227734592032768",
  "in_reply_to_user_id" : 7852612,
  "text" : "@isaach On your phone too?",
  "id" : 376227734592032768,
  "in_reply_to_status_id" : 376224481133334528,
  "created_at" : "2013-09-07 06:17:36 +0000",
  "in_reply_to_screen_name" : "isaach",
  "in_reply_to_user_id_str" : "7852612",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Porad",
      "screen_name" : "scottporad",
      "indices" : [ 3, 14 ],
      "id_str" : "15876737",
      "id" : 15876737
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http://t.co/W7rMBRpDLP",
      "expanded_url" : "http://bit.ly/15FyWMP",
      "display_url" : "bit.ly/15FyWMP"
    } ]
  },
  "geo" : { },
  "id_str" : "376227588630249472",
  "text" : "RT @scottporad: My 11-year old son just shipped his first iOS app called Kinoki!!  Check it out: http://t.co/W7rMBRpDLP",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 81, 103 ],
        "url" : "http://t.co/W7rMBRpDLP",
        "expanded_url" : "http://bit.ly/15FyWMP",
        "display_url" : "bit.ly/15FyWMP"
      } ]
    },
    "geo" : { },
    "id_str" : "376121591043600384",
    "text" : "My 11-year old son just shipped his first iOS app called Kinoki!!  Check it out: http://t.co/W7rMBRpDLP",
    "id" : 376121591043600384,
    "created_at" : "2013-09-06 23:15:49 +0000",
    "user" : {
      "name" : "Scott Porad",
      "screen_name" : "scottporad",
      "protected" : false,
      "id_str" : "15876737",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/58474218/a545469291_443918_4159_normal.jpg",
      "id" : 15876737,
      "verified" : false
    }
  },
  "id" : 376227588630249472,
  "created_at" : "2013-09-07 06:17:01 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http://t.co/A7yW6PssXF",
      "expanded_url" : "http://instagram.com/p/d8cKo4o0Jg/",
      "display_url" : "instagram.com/p/d8cKo4o0Jg/"
    } ]
  },
  "geo" : { },
  "id_str" : "376188829851721728",
  "text" : "8:36pm Thomas Percy Papa Amelia Adam wasn't in there. Have a nice day!!! (Post by Niko) http://t.co/A7yW6PssXF",
  "id" : 376188829851721728,
  "created_at" : "2013-09-07 03:43:00 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Loving",
      "screen_name" : "adamloving",
      "indices" : [ 3, 14 ],
      "id_str" : "809641",
      "id" : 809641
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http://t.co/6JTwRCw4bp",
      "expanded_url" : "http://tinyletter.com/ben/letters",
      "display_url" : "tinyletter.com/ben/letters"
    } ]
  },
  "geo" : { },
  "id_str" : "376144138955001857",
  "text" : "RT @adamloving: Our ads \"defy logic because they're for our existing customers. We're not going for new leads\" http://t.co/6JTwRCw4bp",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.apple.com\" rel=\"nofollow\">Safari on iOS</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 95, 117 ],
        "url" : "http://t.co/6JTwRCw4bp",
        "expanded_url" : "http://tinyletter.com/ben/letters",
        "display_url" : "tinyletter.com/ben/letters"
      } ]
    },
    "geo" : { },
    "id_str" : "376142139857444865",
    "text" : "Our ads \"defy logic because they're for our existing customers. We're not going for new leads\" http://t.co/6JTwRCw4bp",
    "id" : 376142139857444865,
    "created_at" : "2013-09-07 00:37:29 +0000",
    "user" : {
      "name" : "Adam Loving",
      "screen_name" : "adamloving",
      "protected" : false,
      "id_str" : "809641",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3596120795/6bc52037ad90fa33da999b74316df179_normal.jpeg",
      "id" : 809641,
      "verified" : false
    }
  },
  "id" : 376144138955001857,
  "created_at" : "2013-09-07 00:45:25 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Torrez",
      "screen_name" : "torrez",
      "indices" : [ 3, 10 ],
      "id_str" : "11604",
      "id" : 11604
    }, {
      "name" : "Andy Yang",
      "screen_name" : "andyyang",
      "indices" : [ 79, 88 ],
      "id_str" : "774850",
      "id" : 774850
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http://t.co/9UJG8ga4rb",
      "expanded_url" : "http://coldattic.info/shvedsky/pro/blogs/a-foo-walks-into-a-bar/posts/98",
      "display_url" : "coldattic.info/shvedsky/pro/b\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "376133892798812160",
  "text" : "RT @torrez: So here is your weekend hacking project http://t.co/9UJG8ga4rb via @andyyang",
  "retweeted_status" : {
    "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andy Yang",
        "screen_name" : "andyyang",
        "indices" : [ 67, 76 ],
        "id_str" : "774850",
        "id" : 774850
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 40, 62 ],
        "url" : "http://t.co/9UJG8ga4rb",
        "expanded_url" : "http://coldattic.info/shvedsky/pro/blogs/a-foo-walks-into-a-bar/posts/98",
        "display_url" : "coldattic.info/shvedsky/pro/b\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "376133177217015808",
    "text" : "So here is your weekend hacking project http://t.co/9UJG8ga4rb via @andyyang",
    "id" : 376133177217015808,
    "created_at" : "2013-09-07 00:01:52 +0000",
    "user" : {
      "name" : "Andre Torrez",
      "screen_name" : "torrez",
      "protected" : false,
      "id_str" : "11604",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000453148140/81f9811b882e36af686f52c155deaa4c_normal.png",
      "id" : 11604,
      "verified" : false
    }
  },
  "id" : 376133892798812160,
  "created_at" : "2013-09-07 00:04:42 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Torrez",
      "screen_name" : "torrez",
      "indices" : [ 0, 7 ],
      "id_str" : "11604",
      "id" : 11604
    }, {
      "name" : "Andy Yang",
      "screen_name" : "andyyang",
      "indices" : [ 8, 17 ],
      "id_str" : "774850",
      "id" : 774850
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "376133177217015808",
  "geo" : { },
  "id_str" : "376133873492434944",
  "in_reply_to_user_id" : 11604,
  "text" : "@torrez @andyyang That's rad. Totally gonna copy this idea.",
  "id" : 376133873492434944,
  "in_reply_to_status_id" : 376133177217015808,
  "created_at" : "2013-09-07 00:04:38 +0000",
  "in_reply_to_screen_name" : "torrez",
  "in_reply_to_user_id_str" : "11604",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aimee",
      "screen_name" : "LilHossler",
      "indices" : [ 0, 11 ],
      "id_str" : "123116307",
      "id" : 123116307
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "376124193567289344",
  "geo" : { },
  "id_str" : "376124838923890688",
  "in_reply_to_user_id" : 123116307,
  "text" : "@LilHossler Hilarious! So bad! :)",
  "id" : 376124838923890688,
  "in_reply_to_status_id" : 376124193567289344,
  "created_at" : "2013-09-06 23:28:44 +0000",
  "in_reply_to_screen_name" : "LilHossler",
  "in_reply_to_user_id_str" : "123116307",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Doug Bowman",
      "screen_name" : "stop",
      "indices" : [ 0, 5 ],
      "id_str" : "949521",
      "id" : 949521
    }, {
      "name" : "Mike Kruzeniski",
      "screen_name" : "mkruz",
      "indices" : [ 6, 12 ],
      "id_str" : "6604912",
      "id" : 6604912
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NowPlaying",
      "indices" : [ 13, 24 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "376093541945987072",
  "geo" : { },
  "id_str" : "376094785167032320",
  "in_reply_to_user_id" : 949521,
  "text" : "@stop @mkruz #NowPlaying",
  "id" : 376094785167032320,
  "in_reply_to_status_id" : 376093541945987072,
  "created_at" : "2013-09-06 21:29:18 +0000",
  "in_reply_to_screen_name" : "stop",
  "in_reply_to_user_id_str" : "949521",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Kruzeniski",
      "screen_name" : "mkruz",
      "indices" : [ 0, 6 ],
      "id_str" : "6604912",
      "id" : 6604912
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "376092917292490752",
  "geo" : { },
  "id_str" : "376093077972062208",
  "in_reply_to_user_id" : 6604912,
  "text" : "@mkruz Go crazy.",
  "id" : 376093077972062208,
  "in_reply_to_status_id" : 376092917292490752,
  "created_at" : "2013-09-06 21:22:31 +0000",
  "in_reply_to_screen_name" : "mkruz",
  "in_reply_to_user_id_str" : "6604912",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Torrez",
      "screen_name" : "torrez",
      "indices" : [ 0, 7 ],
      "id_str" : "11604",
      "id" : 11604
    }, {
      "name" : "Derek Powazek",
      "screen_name" : "fraying",
      "indices" : [ 8, 16 ],
      "id_str" : "4999",
      "id" : 4999
    }, {
      "name" : "Taylor Singletary",
      "screen_name" : "episod",
      "indices" : [ 68, 75 ],
      "id_str" : "819797",
      "id" : 819797
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "376089990481985536",
  "geo" : { },
  "id_str" : "376090403247640576",
  "in_reply_to_user_id" : 11604,
  "text" : "@torrez @fraying Looks like a bug. Do you know anything about this, @episod?",
  "id" : 376090403247640576,
  "in_reply_to_status_id" : 376089990481985536,
  "created_at" : "2013-09-06 21:11:54 +0000",
  "in_reply_to_screen_name" : "torrez",
  "in_reply_to_user_id_str" : "11604",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "timoni west",
      "screen_name" : "timoni",
      "indices" : [ 0, 7 ],
      "id_str" : "12615",
      "id" : 12615
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "375991079038111744",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596360118, -122.2754488794 ]
  },
  "id_str" : "375999273315221507",
  "in_reply_to_user_id" : 12615,
  "text" : "@timoni Probably because they're easy to hand off to our younger siblings.",
  "id" : 375999273315221507,
  "in_reply_to_status_id" : 375991079038111744,
  "created_at" : "2013-09-06 15:09:47 +0000",
  "in_reply_to_screen_name" : "timoni",
  "in_reply_to_user_id_str" : "12615",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Medium",
      "screen_name" : "Medium",
      "indices" : [ 3, 10 ],
      "id_str" : "571202103",
      "id" : 571202103
    }, {
      "name" : "Julie Zhuo",
      "screen_name" : "joulee",
      "indices" : [ 101, 108 ],
      "id_str" : "17611446",
      "id" : 17611446
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https://t.co/lrMy0exJGI",
      "expanded_url" : "https://medium.com/the-year-of-the-looking-glass/dbb1a8b173c1?utm_source=TwitterAccount&utm_medium=Twitter&utm_campaign=TwitterAccount",
      "display_url" : "medium.com/the-year-of-th\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "375988924776075264",
  "text" : "RT @Medium: \u201CThe Game of Life: how to deal with the fact that we are all completely irrational. \u201D by @joulee https://t.co/lrMy0exJGI",
  "retweeted_status" : {
    "source" : "<a href=\"http://sproutsocial.com\" rel=\"nofollow\">Sprout Social</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Julie Zhuo",
        "screen_name" : "joulee",
        "indices" : [ 89, 96 ],
        "id_str" : "17611446",
        "id" : 17611446
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 97, 120 ],
        "url" : "https://t.co/lrMy0exJGI",
        "expanded_url" : "https://medium.com/the-year-of-the-looking-glass/dbb1a8b173c1?utm_source=TwitterAccount&utm_medium=Twitter&utm_campaign=TwitterAccount",
        "display_url" : "medium.com/the-year-of-th\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "375984483947663360",
    "text" : "\u201CThe Game of Life: how to deal with the fact that we are all completely irrational. \u201D by @joulee https://t.co/lrMy0exJGI",
    "id" : 375984483947663360,
    "created_at" : "2013-09-06 14:11:01 +0000",
    "user" : {
      "name" : "Medium",
      "screen_name" : "Medium",
      "protected" : false,
      "id_str" : "571202103",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2504297462/wtbq3hoquj8no6t2ysz4_normal.jpeg",
      "id" : 571202103,
      "verified" : true
    }
  },
  "id" : 375988924776075264,
  "created_at" : "2013-09-06 14:28:39 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 71 ],
      "url" : "http://t.co/lUFSGP2uS0",
      "expanded_url" : "http://flic.kr/p/fKxUzv",
      "display_url" : "flic.kr/p/fKxUzv"
    } ]
  },
  "geo" : { },
  "id_str" : "375837965152317440",
  "text" : "8:36pm Watching Skins 3 for no particular reason http://t.co/lUFSGP2uS0",
  "id" : 375837965152317440,
  "created_at" : "2013-09-06 04:28:48 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Max Quinn",
      "screen_name" : "maxbot3000",
      "indices" : [ 0, 11 ],
      "id_str" : "1193706962",
      "id" : 1193706962
    }, {
      "name" : "Magic Recs",
      "screen_name" : "MagicRecs",
      "indices" : [ 12, 22 ],
      "id_str" : "1270746139",
      "id" : 1270746139
    }, {
      "name" : "Michael Sippey",
      "screen_name" : "sippey",
      "indices" : [ 23, 30 ],
      "id_str" : "4711",
      "id" : 4711
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "375770946587480064",
  "geo" : { },
  "id_str" : "375782280683196417",
  "in_reply_to_user_id" : 1193706962,
  "text" : "@maxbot3000 @magicrecs @sippey That's exactly what I was hoping.",
  "id" : 375782280683196417,
  "in_reply_to_status_id" : 375770946587480064,
  "created_at" : "2013-09-06 00:47:32 +0000",
  "in_reply_to_screen_name" : "maxbot3000",
  "in_reply_to_user_id_str" : "1193706962",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Magic Recs",
      "screen_name" : "MagicRecs",
      "indices" : [ 19, 29 ],
      "id_str" : "1270746139",
      "id" : 1270746139
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "375762126763073536",
  "text" : "I want to see your @magicrecs.",
  "id" : 375762126763073536,
  "created_at" : "2013-09-05 23:27:27 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan King",
      "screen_name" : "rk",
      "indices" : [ 0, 3 ],
      "id_str" : "19853",
      "id" : 19853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "375753343747903488",
  "geo" : { },
  "id_str" : "375754202108022784",
  "in_reply_to_user_id" : 19853,
  "text" : "@rk Write about whatever you're currently learning about. The biggest questions you can't currently answer, or only recently solved.",
  "id" : 375754202108022784,
  "in_reply_to_status_id" : 375753343747903488,
  "created_at" : "2013-09-05 22:55:57 +0000",
  "in_reply_to_screen_name" : "rk",
  "in_reply_to_user_id_str" : "19853",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Crocker",
      "screen_name" : "nickcrocker",
      "indices" : [ 3, 15 ],
      "id_str" : "30801469",
      "id" : 30801469
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http://t.co/JPGfNJ4LVc",
      "expanded_url" : "http://bit.ly/17AX0u0",
      "display_url" : "bit.ly/17AX0u0"
    } ]
  },
  "geo" : { },
  "id_str" : "375747825964818432",
  "text" : "RT @nickcrocker: Males. Can you try my 7 Minute Man Stretch and report back pls? http://t.co/JPGfNJ4LVc",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 64, 86 ],
        "url" : "http://t.co/JPGfNJ4LVc",
        "expanded_url" : "http://bit.ly/17AX0u0",
        "display_url" : "bit.ly/17AX0u0"
      } ]
    },
    "geo" : { },
    "id_str" : "375747119816011776",
    "text" : "Males. Can you try my 7 Minute Man Stretch and report back pls? http://t.co/JPGfNJ4LVc",
    "id" : 375747119816011776,
    "created_at" : "2013-09-05 22:27:49 +0000",
    "user" : {
      "name" : "Nick Crocker",
      "screen_name" : "nickcrocker",
      "protected" : false,
      "id_str" : "30801469",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2577105195/r6spl5x57dzylu5tt8yd_normal.png",
      "id" : 30801469,
      "verified" : false
    }
  },
  "id" : 375747825964818432,
  "created_at" : "2013-09-05 22:30:37 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Crocker",
      "screen_name" : "nickcrocker",
      "indices" : [ 0, 12 ],
      "id_str" : "30801469",
      "id" : 30801469
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "375747119816011776",
  "geo" : { },
  "id_str" : "375747775616389120",
  "in_reply_to_user_id" : 30801469,
  "text" : "@nickcrocker I'll try it tonight!",
  "id" : 375747775616389120,
  "in_reply_to_status_id" : 375747119816011776,
  "created_at" : "2013-09-05 22:30:25 +0000",
  "in_reply_to_screen_name" : "nickcrocker",
  "in_reply_to_user_id_str" : "30801469",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leah, agirlandaboy",
      "screen_name" : "agirlandaboy",
      "indices" : [ 0, 13 ],
      "id_str" : "80895925",
      "id" : 80895925
    }, {
      "name" : "Doing My Best",
      "screen_name" : "am_doingmybest",
      "indices" : [ 14, 29 ],
      "id_str" : "292386130",
      "id" : 292386130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "375711395712495616",
  "geo" : { },
  "id_str" : "375711648347979776",
  "in_reply_to_user_id" : 80895925,
  "text" : "@agirlandaboy @am_doingmybest Yes, definitely send me screenshots and notes! The team has fixed several bugs and is open to all feedback.",
  "id" : 375711648347979776,
  "in_reply_to_status_id" : 375711395712495616,
  "created_at" : "2013-09-05 20:06:52 +0000",
  "in_reply_to_screen_name" : "agirlandaboy",
  "in_reply_to_user_id_str" : "80895925",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Kedrosky",
      "screen_name" : "pkedrosky",
      "indices" : [ 3, 13 ],
      "id_str" : "1717291",
      "id" : 1717291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http://t.co/mKqflRWAhq",
      "expanded_url" : "http://www.wimp.com/vegetablemarket/",
      "display_url" : "wimp.com/vegetablemarke\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "375703272125771777",
  "text" : "RT @pkedrosky: Remarkable: How close to a train track can you set up a vegetable market? http://t.co/mKqflRWAhq",
  "retweeted_status" : {
    "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 74, 96 ],
        "url" : "http://t.co/mKqflRWAhq",
        "expanded_url" : "http://www.wimp.com/vegetablemarket/",
        "display_url" : "wimp.com/vegetablemarke\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "375697212040155136",
    "text" : "Remarkable: How close to a train track can you set up a vegetable market? http://t.co/mKqflRWAhq",
    "id" : 375697212040155136,
    "created_at" : "2013-09-05 19:09:30 +0000",
    "user" : {
      "name" : "Paul Kedrosky",
      "screen_name" : "pkedrosky",
      "protected" : false,
      "id_str" : "1717291",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3293726938/94d9c55d04adce1174aefa25eb0d6a02_normal.jpeg",
      "id" : 1717291,
      "verified" : true
    }
  },
  "id" : 375703272125771777,
  "created_at" : "2013-09-05 19:33:34 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "right",
      "indices" : [ 77, 83 ]
    }, {
      "text" : "whatever",
      "indices" : [ 84, 93 ]
    } ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http://t.co/zmDIZEjn9O",
      "expanded_url" : "http://m.adage.com/article?articleSection=digital&articleSectionName=Digital&articleid=http%3A%2F%2Fadage.com%2Fdigital%2Farticle%3Farticle_id%3D243986",
      "display_url" : "m.adage.com/article?articl\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8094119451, -122.2728829489 ]
  },
  "id_str" : "375471963927359488",
  "text" : "\"This represents a significant evolution of the logo\" http://t.co/zmDIZEjn9O #right #whatever",
  "id" : 375471963927359488,
  "created_at" : "2013-09-05 04:14:26 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http://t.co/hzjXUKKnrx",
      "expanded_url" : "http://flic.kr/p/fJVRkP",
      "display_url" : "flic.kr/p/fJVRkP"
    } ]
  },
  "geo" : { },
  "id_str" : "375469868973187072",
  "text" : "8:36pm Date night talking about other people's bizniz http://t.co/hzjXUKKnrx",
  "id" : 375469868973187072,
  "created_at" : "2013-09-05 04:06:07 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Oliver",
      "screen_name" : "orvtech",
      "indices" : [ 3, 11 ],
      "id_str" : "4412471",
      "id" : 4412471
    }, {
      "name" : "Buster",
      "screen_name" : "buster",
      "indices" : [ 13, 20 ],
      "id_str" : "2185",
      "id" : 2185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "375427649599832064",
  "text" : "RT @orvtech: @buster 85.7% of people will believe this",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Buster",
        "screen_name" : "buster",
        "indices" : [ 0, 7 ],
        "id_str" : "2185",
        "id" : 2185
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "375423557959819264",
    "geo" : { },
    "id_str" : "375425300034629632",
    "in_reply_to_user_id" : 2185,
    "text" : "@buster 85.7% of people will believe this",
    "id" : 375425300034629632,
    "in_reply_to_status_id" : 375423557959819264,
    "created_at" : "2013-09-05 01:09:01 +0000",
    "in_reply_to_screen_name" : "buster",
    "in_reply_to_user_id_str" : "2185",
    "user" : {
      "name" : "Oliver",
      "screen_name" : "orvtech",
      "protected" : false,
      "id_str" : "4412471",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/344513261577037439/2a108f7ab6098e4061bec1aa4616b0a0_normal.jpeg",
      "id" : 4412471,
      "verified" : false
    }
  },
  "id" : 375427649599832064,
  "created_at" : "2013-09-05 01:18:21 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7775546397, -122.4160553982 ]
  },
  "id_str" : "375423557959819264",
  "text" : "\"Providing someone with a random numerical forecast increases his risk taking even if he knows the predictions are random.\" - Antifragile",
  "id" : 375423557959819264,
  "created_at" : "2013-09-05 01:02:05 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kelton Lynn",
      "screen_name" : "keltonlynn",
      "indices" : [ 0, 11 ],
      "id_str" : "27674040",
      "id" : 27674040
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "375115423571668992",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597686298, -122.2755667226 ]
  },
  "id_str" : "375115980927557632",
  "in_reply_to_user_id" : 27674040,
  "text" : "@keltonlynn Oh just meant the $400+ options for more data from the blood test. Will definitely let you know how it goes.",
  "id" : 375115980927557632,
  "in_reply_to_status_id" : 375115423571668992,
  "created_at" : "2013-09-04 04:39:53 +0000",
  "in_reply_to_screen_name" : "keltonlynn",
  "in_reply_to_user_id_str" : "27674040",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kelton Lynn",
      "screen_name" : "keltonlynn",
      "indices" : [ 0, 11 ],
      "id_str" : "27674040",
      "id" : 27674040
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "375111350969573376",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597878572, -122.2753849347 ]
  },
  "id_str" : "375111626921238528",
  "in_reply_to_user_id" : 27674040,
  "text" : "@keltonlynn Just signed up. Want to do the more expensive ones but will try it out first. Thanks for the rec!",
  "id" : 375111626921238528,
  "in_reply_to_status_id" : 375111350969573376,
  "created_at" : "2013-09-04 04:22:35 +0000",
  "in_reply_to_screen_name" : "keltonlynn",
  "in_reply_to_user_id_str" : "27674040",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kelton Lynn",
      "screen_name" : "keltonlynn",
      "indices" : [ 0, 11 ],
      "id_str" : "27674040",
      "id" : 27674040
    }, {
      "name" : "WellnessFX",
      "screen_name" : "WellnessFX",
      "indices" : [ 12, 23 ],
      "id_str" : "154189407",
      "id" : 154189407
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "375109364287156224",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597854991, -122.2754557871 ]
  },
  "id_str" : "375109834602844160",
  "in_reply_to_user_id" : 27674040,
  "text" : "@keltonlynn @WellnessFX Thinking of trying it out. What kinds of things did you learn?",
  "id" : 375109834602844160,
  "in_reply_to_status_id" : 375109364287156224,
  "created_at" : "2013-09-04 04:15:28 +0000",
  "in_reply_to_screen_name" : "keltonlynn",
  "in_reply_to_user_id_str" : "27674040",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 41 ],
      "url" : "http://t.co/WalnXfu1Op",
      "expanded_url" : "http://flic.kr/p/fJgyrt",
      "display_url" : "flic.kr/p/fJgyrt"
    } ]
  },
  "geo" : { },
  "id_str" : "375109477474660352",
  "text" : "8:36pm Late dinner http://t.co/WalnXfu1Op",
  "id" : 375109477474660352,
  "created_at" : "2013-09-04 04:14:03 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nassim N. Taleb",
      "screen_name" : "nntaleb",
      "indices" : [ 106, 114 ],
      "id_str" : "381289719",
      "id" : 381289719
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8588038218, -122.2756136769 ]
  },
  "id_str" : "375092956207656960",
  "text" : "\"We have managed to transfer religious belief into gullibility for whatever can masquerade as science.\" - @nntaleb in Antifragility",
  "id" : 375092956207656960,
  "created_at" : "2013-09-04 03:08:24 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.77678127195141, -122.4172618877189 ]
  },
  "id_str" : "375075579143258112",
  "text" : "I just learneded some things.",
  "id" : 375075579143258112,
  "created_at" : "2013-09-04 01:59:21 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "girl jo",
      "screen_name" : "octavekitten",
      "indices" : [ 0, 13 ],
      "id_str" : "16366882",
      "id" : 16366882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "374980804448776192",
  "geo" : { },
  "id_str" : "374981039942160384",
  "in_reply_to_user_id" : 16366882,
  "text" : "@octavekitten Okay, no worries if it's too much trouble. Just gathering feedback.",
  "id" : 374981039942160384,
  "in_reply_to_status_id" : 374980804448776192,
  "created_at" : "2013-09-03 19:43:41 +0000",
  "in_reply_to_screen_name" : "octavekitten",
  "in_reply_to_user_id_str" : "16366882",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "girl jo",
      "screen_name" : "octavekitten",
      "indices" : [ 0, 13 ],
      "id_str" : "16366882",
      "id" : 16366882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "374980531605090304",
  "geo" : { },
  "id_str" : "374980640069795840",
  "in_reply_to_user_id" : 16366882,
  "text" : "@octavekitten Yeah, just take a screenshot of it and let me know what it is about it that you don't like.",
  "id" : 374980640069795840,
  "in_reply_to_status_id" : 374980531605090304,
  "created_at" : "2013-09-03 19:42:06 +0000",
  "in_reply_to_screen_name" : "octavekitten",
  "in_reply_to_user_id_str" : "16366882",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "girl jo",
      "screen_name" : "octavekitten",
      "indices" : [ 0, 13 ],
      "id_str" : "16366882",
      "id" : 16366882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "374979717406789632",
  "geo" : { },
  "id_str" : "374980242516881408",
  "in_reply_to_user_id" : 16366882,
  "text" : "@octavekitten Can you send me a screenshot of it when it's in a state that you hate? Collecting them to pass on.",
  "id" : 374980242516881408,
  "in_reply_to_status_id" : 374979717406789632,
  "created_at" : "2013-09-03 19:40:31 +0000",
  "in_reply_to_screen_name" : "octavekitten",
  "in_reply_to_user_id_str" : "16366882",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Shapiro",
      "screen_name" : "danshapiro",
      "indices" : [ 0, 11 ],
      "id_str" : "8070502",
      "id" : 8070502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "374976111249072129",
  "geo" : { },
  "id_str" : "374976257764495360",
  "in_reply_to_user_id" : 8070502,
  "text" : "@danshapiro It's the smartest thing I've seen in a long time. Well done! Can't wait to play.",
  "id" : 374976257764495360,
  "in_reply_to_status_id" : 374976111249072129,
  "created_at" : "2013-09-03 19:24:41 +0000",
  "in_reply_to_screen_name" : "danshapiro",
  "in_reply_to_user_id_str" : "8070502",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Shapiro",
      "screen_name" : "danshapiro",
      "indices" : [ 44, 55 ],
      "id_str" : "8070502",
      "id" : 8070502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http://t.co/MqC1SoRphA",
      "expanded_url" : "http://kck.st/17BKz3h",
      "display_url" : "kck.st/17BKz3h"
    } ]
  },
  "geo" : { },
  "id_str" : "374962032384040960",
  "text" : "If you have kids 3-8, you HAVE to check out @DanShapiro's Kickstarter game that helps teach programming. Amazing. http://t.co/MqC1SoRphA",
  "id" : 374962032384040960,
  "created_at" : "2013-09-03 18:28:09 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Brewer",
      "screen_name" : "jbrewer",
      "indices" : [ 3, 11 ],
      "id_str" : "12555",
      "id" : 12555
    }, {
      "name" : "Stijn Debrouwere",
      "screen_name" : "stdbrouw",
      "indices" : [ 125, 134 ],
      "id_str" : "334912156",
      "id" : 334912156
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "374958666757062657",
  "text" : "RT @jbrewer: \u201CMetrics are for doing, not for staring. Never measure just because you can. Measure to learn. Measure to fix.\u201D\u2014@stdbrouw",
  "retweeted_status" : {
    "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Stijn Debrouwere",
        "screen_name" : "stdbrouw",
        "indices" : [ 112, 121 ],
        "id_str" : "334912156",
        "id" : 334912156
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "374958595852357632",
    "text" : "\u201CMetrics are for doing, not for staring. Never measure just because you can. Measure to learn. Measure to fix.\u201D\u2014@stdbrouw",
    "id" : 374958595852357632,
    "created_at" : "2013-09-03 18:14:30 +0000",
    "user" : {
      "name" : "Josh Brewer",
      "screen_name" : "jbrewer",
      "protected" : false,
      "id_str" : "12555",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000470238857/de3847a968ebe1c0cb700f4e07356dd3_normal.jpeg",
      "id" : 12555,
      "verified" : false
    }
  },
  "id" : 374958666757062657,
  "created_at" : "2013-09-03 18:14:47 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GeekWire",
      "screen_name" : "geekwire",
      "indices" : [ 13, 22 ],
      "id_str" : "255784266",
      "id" : 255784266
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http://t.co/birsDFhOKD",
      "expanded_url" : "http://goo.gl/fb/u56cP",
      "display_url" : "goo.gl/fb/u56cP"
    } ]
  },
  "in_reply_to_status_id_str" : "374920504635035648",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597762215, -122.2755710712 ]
  },
  "id_str" : "374922181014085632",
  "in_reply_to_user_id" : 255784266,
  "text" : "Exciting! RT @geekwire: Amazon leaks new Kindle Paperwhite set to ship Sept. 30 with Goodreads integration http://t.co/birsDFhOKD",
  "id" : 374922181014085632,
  "in_reply_to_status_id" : 374920504635035648,
  "created_at" : "2013-09-03 15:49:48 +0000",
  "in_reply_to_screen_name" : "geekwire",
  "in_reply_to_user_id_str" : "255784266",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Greg Linden",
      "screen_name" : "greglinden",
      "indices" : [ 3, 14 ],
      "id_str" : "87719108",
      "id" : 87719108
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "374919079187841024",
  "text" : "RT @greglinden: \"We need to relearn how to accept risk, and even embrace it, as essential to human progress and our free society.\" http://t\u2026",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 137 ],
        "url" : "http://t.co/FCMU8zgxEc",
        "expanded_url" : "http://www.schneier.com/blog/archives/2013/09/our_newfound_fe.html",
        "display_url" : "schneier.com/blog/archives/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "374918783464259585",
    "text" : "\"We need to relearn how to accept risk, and even embrace it, as essential to human progress and our free society.\" http://t.co/FCMU8zgxEc",
    "id" : 374918783464259585,
    "created_at" : "2013-09-03 15:36:18 +0000",
    "user" : {
      "name" : "Greg Linden",
      "screen_name" : "greglinden",
      "protected" : false,
      "id_str" : "87719108",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/510925562/glinden_DSCF2569-much-smaller_normal.jpg",
      "id" : 87719108,
      "verified" : false
    }
  },
  "id" : 374919079187841024,
  "created_at" : "2013-09-03 15:37:28 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt",
      "screen_name" : "upthesaints",
      "indices" : [ 0, 12 ],
      "id_str" : "53439304",
      "id" : 53439304
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "374798264102830081",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597551902, -122.2755960191 ]
  },
  "id_str" : "374918464097361920",
  "in_reply_to_user_id" : 53439304,
  "text" : "@upthesaints If you find specifics that illustrate these points, send them along. It helps us figure out how to improve things.",
  "id" : 374918464097361920,
  "in_reply_to_status_id" : 374798264102830081,
  "created_at" : "2013-09-03 15:35:02 +0000",
  "in_reply_to_screen_name" : "upthesaints",
  "in_reply_to_user_id_str" : "53439304",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http://t.co/5XuhyoaPdT",
      "expanded_url" : "http://flic.kr/p/fHRyh4",
      "display_url" : "flic.kr/p/fHRyh4"
    } ]
  },
  "geo" : { },
  "id_str" : "374917688125956096",
  "text" : "Niko and Shylo, heading to first day back at preschool together http://t.co/5XuhyoaPdT",
  "id" : 374917688125956096,
  "created_at" : "2013-09-03 15:31:57 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt",
      "screen_name" : "upthesaints",
      "indices" : [ 0, 12 ],
      "id_str" : "53439304",
      "id" : 53439304
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "374787097179062272",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597631688, -122.2755712269 ]
  },
  "id_str" : "374787443553091584",
  "in_reply_to_user_id" : 53439304,
  "text" : "@upthesaints Can you send me screenshots with notes to buster@twitter.com? I can investigate.",
  "id" : 374787443553091584,
  "in_reply_to_status_id" : 374787097179062272,
  "created_at" : "2013-09-03 06:54:24 +0000",
  "in_reply_to_screen_name" : "upthesaints",
  "in_reply_to_user_id_str" : "53439304",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 68 ],
      "url" : "http://t.co/9K1PuCU1vw",
      "expanded_url" : "http://flic.kr/p/fHM8Mm",
      "display_url" : "flic.kr/p/fHM8Mm"
    } ]
  },
  "geo" : { },
  "id_str" : "374738262390104064",
  "text" : "8:36pm \"That's a family selfie for the ages.\" http://t.co/9K1PuCU1vw",
  "id" : 374738262390104064,
  "created_at" : "2013-09-03 03:38:58 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Doing My Best",
      "screen_name" : "am_doingmybest",
      "indices" : [ 0, 15 ],
      "id_str" : "292386130",
      "id" : 292386130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "374642025993236480",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596278801, -122.2757402485 ]
  },
  "id_str" : "374647965794578432",
  "in_reply_to_user_id" : 292386130,
  "text" : "@am_doingmybest Can you send me a screenshot with some notes on what you hate about it? buster@twitter.com",
  "id" : 374647965794578432,
  "in_reply_to_status_id" : 374642025993236480,
  "created_at" : "2013-09-02 21:40:10 +0000",
  "in_reply_to_screen_name" : "am_doingmybest",
  "in_reply_to_user_id_str" : "292386130",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ed Yong ",
      "screen_name" : "edyong209",
      "indices" : [ 3, 13 ],
      "id_str" : "19767193",
      "id" : 19767193
    }, {
      "name" : "matthew",
      "screen_name" : "matthew",
      "indices" : [ 131, 139 ],
      "id_str" : "822824",
      "id" : 822824
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http://t.co/WjEhar9ke7",
      "expanded_url" : "http://whyevolutionistrue.wordpress.com/2013/08/29/a-most-bizarre-and-mysterious-cocoon/",
      "display_url" : "whyevolutionistrue.wordpress.com/2013/08/29/a-m\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "374571276435611648",
  "text" : "RT @edyong209: Some weird insect is building a white fence around its eggs, and no one knows what it is. http://t.co/WjEhar9ke7 HT @matthew\u2026",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Matthew Cobb",
        "screen_name" : "matthewcobb",
        "indices" : [ 116, 128 ],
        "id_str" : "1524781",
        "id" : 1524781
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 90, 112 ],
        "url" : "http://t.co/WjEhar9ke7",
        "expanded_url" : "http://whyevolutionistrue.wordpress.com/2013/08/29/a-most-bizarre-and-mysterious-cocoon/",
        "display_url" : "whyevolutionistrue.wordpress.com/2013/08/29/a-m\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "374569605932384256",
    "text" : "Some weird insect is building a white fence around its eggs, and no one knows what it is. http://t.co/WjEhar9ke7 HT @matthewcobb",
    "id" : 374569605932384256,
    "created_at" : "2013-09-02 16:28:47 +0000",
    "user" : {
      "name" : "Ed Yong ",
      "screen_name" : "edyong209",
      "protected" : false,
      "id_str" : "19767193",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3074924820/1509a09439deea7f5b49a59907b1bc3d_normal.jpeg",
      "id" : 19767193,
      "verified" : false
    }
  },
  "id" : 374571276435611648,
  "created_at" : "2013-09-02 16:35:26 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Sarver",
      "screen_name" : "rsarver",
      "indices" : [ 0, 8 ],
      "id_str" : "795649",
      "id" : 795649
    }, {
      "name" : "Ted Rheingold",
      "screen_name" : "tedr",
      "indices" : [ 9, 14 ],
      "id_str" : "997",
      "id" : 997
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "374568869567803392",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597382312, -122.2755081596 ]
  },
  "id_str" : "374569482133327872",
  "in_reply_to_user_id" : 795649,
  "text" : "@rsarver @tedr I'm just cheap. :) That said, once the initial backup happened, it now works like a charm.",
  "id" : 374569482133327872,
  "in_reply_to_status_id" : 374568869567803392,
  "created_at" : "2013-09-02 16:28:18 +0000",
  "in_reply_to_screen_name" : "rsarver",
  "in_reply_to_user_id_str" : "795649",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ted Rheingold",
      "screen_name" : "tedr",
      "indices" : [ 0, 5 ],
      "id_str" : "997",
      "id" : 997
    }, {
      "name" : "Ryan Sarver",
      "screen_name" : "rsarver",
      "indices" : [ 6, 14 ],
      "id_str" : "795649",
      "id" : 795649
    }, {
      "name" : "Backblaze",
      "screen_name" : "backblaze",
      "indices" : [ 15, 25 ],
      "id_str" : "18236716",
      "id" : 18236716
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "374565245135495168",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597218602, -122.2755196823 ]
  },
  "id_str" : "374568210080608256",
  "in_reply_to_user_id" : 997,
  "text" : "@tedr @rsarver @backblaze It definitely slowed my network down. I had it start synching at 1am and paused it every morning. Took weeks.",
  "id" : 374568210080608256,
  "in_reply_to_status_id" : 374565245135495168,
  "created_at" : "2013-09-02 16:23:15 +0000",
  "in_reply_to_screen_name" : "tedr",
  "in_reply_to_user_id_str" : "997",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jad Abumrad",
      "screen_name" : "JadAbumrad",
      "indices" : [ 3, 14 ],
      "id_str" : "135316691",
      "id" : 135316691
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http://t.co/UCrYyXr9ow",
      "expanded_url" : "http://buff.ly/15wWvAr",
      "display_url" : "buff.ly/15wWvAr"
    } ]
  },
  "geo" : { },
  "id_str" : "374566369150259200",
  "text" : "RT @JadAbumrad: An astronaut's meditation on friendship, loneliness &amp; spaceship Earth - http://t.co/UCrYyXr9ow",
  "retweeted_status" : {
    "source" : "<a href=\"http://bufferapp.com\" rel=\"nofollow\">Buffer</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 76, 98 ],
        "url" : "http://t.co/UCrYyXr9ow",
        "expanded_url" : "http://buff.ly/15wWvAr",
        "display_url" : "buff.ly/15wWvAr"
      } ]
    },
    "geo" : { },
    "id_str" : "374562138242969600",
    "text" : "An astronaut's meditation on friendship, loneliness &amp; spaceship Earth - http://t.co/UCrYyXr9ow",
    "id" : 374562138242969600,
    "created_at" : "2013-09-02 15:59:07 +0000",
    "user" : {
      "name" : "Jad Abumrad",
      "screen_name" : "JadAbumrad",
      "protected" : false,
      "id_str" : "135316691",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1529014082/Jad-Pic2_normal.jpg",
      "id" : 135316691,
      "verified" : true
    }
  },
  "id" : 374566369150259200,
  "created_at" : "2013-09-02 16:15:56 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tikva Morowati",
      "screen_name" : "tikkers",
      "indices" : [ 14, 22 ],
      "id_str" : "1054551",
      "id" : 1054551
    }, {
      "name" : "Tim Harford",
      "screen_name" : "TimHarford",
      "indices" : [ 26, 37 ],
      "id_str" : "32493647",
      "id" : 32493647
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http://t.co/eeHJpP8F0m",
      "expanded_url" : "http://dlvr.it/3v4mm6",
      "display_url" : "dlvr.it/3v4mm6"
    } ]
  },
  "in_reply_to_status_id_str" : "374419561937780736",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8598025748, -122.2759899339 ]
  },
  "id_str" : "374420984968650752",
  "in_reply_to_user_id" : 32493647,
  "text" : "On legacy /cc @tikkers RT @TimHarford: xkcd: \"Bee Orchid\" Beautiful http://t.co/eeHJpP8F0m",
  "id" : 374420984968650752,
  "in_reply_to_status_id" : 374419561937780736,
  "created_at" : "2013-09-02 06:38:13 +0000",
  "in_reply_to_screen_name" : "TimHarford",
  "in_reply_to_user_id_str" : "32493647",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "chachasikes",
      "screen_name" : "chachasikes",
      "indices" : [ 0, 12 ],
      "id_str" : "14353952",
      "id" : 14353952
    }, {
      "name" : "Tikva Morowati",
      "screen_name" : "tikkers",
      "indices" : [ 13, 21 ],
      "id_str" : "1054551",
      "id" : 1054551
    }, {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 22, 32 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "374389156132040704",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859771037, -122.2755667468 ]
  },
  "id_str" : "374390623903571968",
  "in_reply_to_user_id" : 14353952,
  "text" : "@chachasikes @tikkers @kellianne More bikes and food and hanging out must happen!",
  "id" : 374390623903571968,
  "in_reply_to_status_id" : 374389156132040704,
  "created_at" : "2013-09-02 04:37:35 +0000",
  "in_reply_to_screen_name" : "chachasikes",
  "in_reply_to_user_id_str" : "14353952",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tikva Morowati",
      "screen_name" : "tikkers",
      "indices" : [ 72, 80 ],
      "id_str" : "1054551",
      "id" : 1054551
    }, {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 82, 92 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http://t.co/KIKK9NkPul",
      "expanded_url" : "http://flic.kr/p/fGWGMN",
      "display_url" : "flic.kr/p/fGWGMN"
    } ]
  },
  "geo" : { },
  "id_str" : "374380854836883457",
  "text" : "8:36pm Coming home from a beautiful day of biking and eating spent with @tikkers, @kellianne, and new friends http://t.co/KIKK9NkPul",
  "id" : 374380854836883457,
  "created_at" : "2013-09-02 03:58:46 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Martell",
      "screen_name" : "danmartell",
      "indices" : [ 3, 14 ],
      "id_str" : "10638782",
      "id" : 10638782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "374336467192930305",
  "text" : "RT @danmartell: A \u2018startup\u2019 is a company that is confused about - \n1. What its product is, \n2. Who its customers are. \n3. How to make money\u2026",
  "retweeted_status" : {
    "source" : "<a href=\"http://bufferapp.com\" rel=\"nofollow\">Buffer</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Dave McClure",
        "screen_name" : "davemcclure",
        "indices" : [ 128, 140 ],
        "id_str" : "1081",
        "id" : 1081
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "374336008156090368",
    "text" : "A \u2018startup\u2019 is a company that is confused about - \n1. What its product is, \n2. Who its customers are. \n3. How to make money.\n\n- @DaveMcClure",
    "id" : 374336008156090368,
    "created_at" : "2013-09-02 01:00:33 +0000",
    "user" : {
      "name" : "Dan Martell",
      "screen_name" : "danmartell",
      "protected" : false,
      "id_str" : "10638782",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1169927111/BIO_-_Headshot_normal.jpg",
      "id" : 10638782,
      "verified" : false
    }
  },
  "id" : 374336467192930305,
  "created_at" : "2013-09-02 01:02:23 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "almost",
      "indices" : [ 99, 106 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597388231, -122.2754618806 ]
  },
  "id_str" : "374332330397024256",
  "text" : "The first day of not being sick after being sick for over a week almost makes it worth being sick. #almost",
  "id" : 374332330397024256,
  "created_at" : "2013-09-02 00:45:56 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596635117, -122.2754823324 ]
  },
  "id_str" : "374183948286312448",
  "text" : "Rabbit rabbit! \uD83D\uDC30\uD83D\uDC30",
  "id" : 374183948286312448,
  "created_at" : "2013-09-01 14:56:19 +0000",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000270747347/c72c0d3ecb8c4eb38d3f395c63416890_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
} ]