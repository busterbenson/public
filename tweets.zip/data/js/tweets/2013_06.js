Grailbird.data.tweets_2013_06 = 
 [ {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Medium",
      "screen_name" : "Medium",
      "indices" : [ 0, 7 ],
      "id_str" : "571202103",
      "id" : 571202103
    }, {
      "name" : "Kate Lee",
      "screen_name" : "katelaurielee",
      "indices" : [ 103, 117 ],
      "id_str" : "16063378",
      "id" : 16063378
    }, {
      "name" : "Jonathan Fuchs",
      "screen_name" : "jfuchs",
      "indices" : [ 118, 125 ],
      "id_str" : "1026",
      "id" : 1026
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "351594524428087298",
  "in_reply_to_user_id" : 571202103,
  "text" : "@medium Can you explain why stats and activity aren't on the same page? Seems like they should be. /cc @katelaurielee @jfuchs",
  "id" : 351594524428087298,
  "created_at" : "Mon Jul 01 06:54:01 +0000 2013",
  "in_reply_to_screen_name" : "Medium",
  "in_reply_to_user_id_str" : "571202103",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aimee",
      "screen_name" : "LilHossler",
      "indices" : [ 0, 11 ],
      "id_str" : "123116307",
      "id" : 123116307
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "351560599307689984",
  "geo" : {
  },
  "id_str" : "351588538254499840",
  "in_reply_to_user_id" : 123116307,
  "text" : "@LilHossler As I posted it I vaguely wondered if this would be the one he resents me for most. :)",
  "id" : 351588538254499840,
  "in_reply_to_status_id" : 351560599307689984,
  "created_at" : "Mon Jul 01 06:30:14 +0000 2013",
  "in_reply_to_screen_name" : "LilHossler",
  "in_reply_to_user_id_str" : "123116307",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 71 ],
      "url" : "http://t.co/Nkzx5o0xrW",
      "expanded_url" : "http://flic.kr/p/eZ9ypK",
      "display_url" : "flic.kr/p/eZ9ypK"
    } ]
  },
  "geo" : {
  },
  "id_str" : "351555801019723776",
  "text" : "8:36pm Niko's good at finding letters these days http://t.co/Nkzx5o0xrW",
  "id" : 351555801019723776,
  "created_at" : "Mon Jul 01 04:20:09 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "becky murphy",
      "screen_name" : "beckycmurphy",
      "indices" : [ 0, 13 ],
      "id_str" : "51489072",
      "id" : 51489072
    }, {
      "name" : "Shaun Lind",
      "screen_name" : "shaunlind",
      "indices" : [ 14, 24 ],
      "id_str" : "133799314",
      "id" : 133799314
    }, {
      "name" : "Andy Keil",
      "screen_name" : "alwaysunday",
      "indices" : [ 25, 37 ],
      "id_str" : "16604578",
      "id" : 16604578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "351476503231475712",
  "geo" : {
  },
  "id_str" : "351500387494277120",
  "in_reply_to_user_id" : 51489072,
  "text" : "@beckycmurphy @shaunlind @alwaysunday Thanks!",
  "id" : 351500387494277120,
  "in_reply_to_status_id" : 351476503231475712,
  "created_at" : "Mon Jul 01 00:39:57 +0000 2013",
  "in_reply_to_screen_name" : "beckycmurphy",
  "in_reply_to_user_id_str" : "51489072",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sandor Weisz",
      "screen_name" : "santheo",
      "indices" : [ 3, 11 ],
      "id_str" : "755414",
      "id" : 755414
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/santheo/status/351337069483814912/photo/1",
      "indices" : [ 60, 82 ],
      "url" : "http://t.co/zLJMO2Ylk1",
      "media_url" : "http://pbs.twimg.com/media/BOAzNAeCcAATa_4.jpg",
      "id_str" : "351337069492203520",
      "id" : 351337069492203520,
      "media_url_https" : "https://pbs.twimg.com/media/BOAzNAeCcAATa_4.jpg",
      "sizes" : [ {
        "h" : 763,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 519,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 763,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 763,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com/zLJMO2Ylk1"
    } ],
    "hashtags" : [ {
      "text" : "bookswithalettermissing",
      "indices" : [ 35, 59 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "351492419713368065",
  "text" : "RT @santheo: The Mythical Man-Moth #bookswithalettermissing http://t.co/zLJMO2Ylk1",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http://twitter.com/santheo/status/351337069483814912/photo/1",
        "indices" : [ 47, 69 ],
        "url" : "http://t.co/zLJMO2Ylk1",
        "media_url" : "http://pbs.twimg.com/media/BOAzNAeCcAATa_4.jpg",
        "id_str" : "351337069492203520",
        "id" : 351337069492203520,
        "media_url_https" : "https://pbs.twimg.com/media/BOAzNAeCcAATa_4.jpg",
        "sizes" : [ {
          "h" : 763,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 519,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 763,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 763,
          "resize" : "fit",
          "w" : 500
        } ],
        "display_url" : "pic.twitter.com/zLJMO2Ylk1"
      } ],
      "hashtags" : [ {
        "text" : "bookswithalettermissing",
        "indices" : [ 22, 46 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "351337069483814912",
    "text" : "The Mythical Man-Moth #bookswithalettermissing http://t.co/zLJMO2Ylk1",
    "id" : 351337069483814912,
    "created_at" : "Sun Jun 30 13:50:59 +0000 2013",
    "user" : {
      "name" : "Sandor Weisz",
      "screen_name" : "santheo",
      "protected" : false,
      "id_str" : "755414",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1315029312/chicago.everyblock_normal.jpeg",
      "id" : 755414,
      "verified" : false
    }
  },
  "id" : 351492419713368065,
  "created_at" : "Mon Jul 01 00:08:17 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marshall Haas",
      "screen_name" : "marshal",
      "indices" : [ 0, 8 ],
      "id_str" : "19028099",
      "id" : 19028099
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "351423237252579328",
  "geo" : {
  },
  "id_str" : "351440263459241984",
  "in_reply_to_user_id" : 19028099,
  "text" : "@marshal Ha, that's awesome. Must be a slow news day. :)",
  "id" : 351440263459241984,
  "in_reply_to_status_id" : 351423237252579328,
  "created_at" : "Sun Jun 30 20:41:02 +0000 2013",
  "in_reply_to_screen_name" : "marshal",
  "in_reply_to_user_id_str" : "19028099",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesper Andersen",
      "screen_name" : "jandersen",
      "indices" : [ 3, 13 ],
      "id_str" : "6154922",
      "id" : 6154922
    }, {
      "name" : "Buster",
      "screen_name" : "buster",
      "indices" : [ 15, 22 ],
      "id_str" : "2185",
      "id" : 2185
    }, {
      "name" : "Noah Iliinsky",
      "screen_name" : "noahi",
      "indices" : [ 23, 29 ],
      "id_str" : "15399031",
      "id" : 15399031
    }, {
      "name" : "Daniel Gilbert",
      "screen_name" : "DanTGilbert",
      "indices" : [ 30, 42 ],
      "id_str" : "525785424",
      "id" : 525785424
    }, {
      "name" : "termie",
      "screen_name" : "termie",
      "indices" : [ 86, 93 ],
      "id_str" : "10658",
      "id" : 10658
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http://t.co/aPKyoj6pLj",
      "expanded_url" : "http://www.lastingstatement.com/",
      "display_url" : "lastingstatement.com"
    } ]
  },
  "geo" : {
  },
  "id_str" : "351435785528025089",
  "text" : "RT @jandersen: @buster @noahi @DanTGilbert they were given a really nice treatment by @termie at http://t.co/aPKyoj6pLj",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Buster",
        "screen_name" : "buster",
        "indices" : [ 0, 7 ],
        "id_str" : "2185",
        "id" : 2185
      }, {
        "name" : "Noah Iliinsky",
        "screen_name" : "noahi",
        "indices" : [ 8, 14 ],
        "id_str" : "15399031",
        "id" : 15399031
      }, {
        "name" : "Daniel Gilbert",
        "screen_name" : "DanTGilbert",
        "indices" : [ 15, 27 ],
        "id_str" : "525785424",
        "id" : 525785424
      }, {
        "name" : "termie",
        "screen_name" : "termie",
        "indices" : [ 71, 78 ],
        "id_str" : "10658",
        "id" : 10658
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 82, 104 ],
        "url" : "http://t.co/aPKyoj6pLj",
        "expanded_url" : "http://www.lastingstatement.com/",
        "display_url" : "lastingstatement.com"
      } ]
    },
    "in_reply_to_status_id_str" : "351329069029277696",
    "geo" : {
    },
    "id_str" : "351411181027729408",
    "in_reply_to_user_id" : 2185,
    "text" : "@buster @noahi @DanTGilbert they were given a really nice treatment by @termie at http://t.co/aPKyoj6pLj",
    "id" : 351411181027729408,
    "in_reply_to_status_id" : 351329069029277696,
    "created_at" : "Sun Jun 30 18:45:29 +0000 2013",
    "in_reply_to_screen_name" : "buster",
    "in_reply_to_user_id_str" : "2185",
    "user" : {
      "name" : "Jesper Andersen",
      "screen_name" : "jandersen",
      "protected" : false,
      "id_str" : "6154922",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2381768123/image_normal.jpg",
      "id" : 6154922,
      "verified" : false
    }
  },
  "id" : 351435785528025089,
  "created_at" : "Sun Jun 30 20:23:15 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Menotti Minutillo",
      "screen_name" : "44",
      "indices" : [ 0, 3 ],
      "id_str" : "15067515",
      "id" : 15067515
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "351403121664200704",
  "geo" : {
  },
  "id_str" : "351404919556816896",
  "in_reply_to_user_id" : 15067515,
  "text" : "@44 Yeah Network Connect just hangs indefinitely.",
  "id" : 351404919556816896,
  "in_reply_to_status_id" : 351403121664200704,
  "created_at" : "Sun Jun 30 18:20:36 +0000 2013",
  "in_reply_to_screen_name" : "44",
  "in_reply_to_user_id_str" : "15067515",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luke Millar",
      "screen_name" : "ltm",
      "indices" : [ 0, 4 ],
      "id_str" : "14616067",
      "id" : 14616067
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "351400345664102403",
  "geo" : {
  },
  "id_str" : "351402048404721667",
  "in_reply_to_user_id" : 14616067,
  "text" : "@ltm I would too but my VPN is broken for some reason.",
  "id" : 351402048404721667,
  "in_reply_to_status_id" : 351400345664102403,
  "created_at" : "Sun Jun 30 18:09:11 +0000 2013",
  "in_reply_to_screen_name" : "ltm",
  "in_reply_to_user_id_str" : "14616067",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rand Fitzpatrick",
      "screen_name" : "sixwing",
      "indices" : [ 0, 8 ],
      "id_str" : "903011",
      "id" : 903011
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "351399622800965634",
  "geo" : {
  },
  "id_str" : "351401914509967360",
  "in_reply_to_user_id" : 903011,
  "text" : "@sixwing Apparently the new bridge will go half way, and the rest will take another 5 years, at least.",
  "id" : 351401914509967360,
  "in_reply_to_status_id" : 351399622800965634,
  "created_at" : "Sun Jun 30 18:08:39 +0000 2013",
  "in_reply_to_screen_name" : "sixwing",
  "in_reply_to_user_id_str" : "903011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marianne Elliott",
      "screen_name" : "zenpeacekeeper",
      "indices" : [ 119, 134 ],
      "id_str" : "35667496",
      "id" : 35667496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http://t.co/AIeIa0Orae",
      "expanded_url" : "http://piedmont.patch.com/groups/around-town/p/sf-bay-ferry-will-beef-up-service-if-bart-workers-strike_089c1627",
      "display_url" : "piedmont.patch.com/groups/around-\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "351399595718356993",
  "geo" : {
  },
  "id_str" : "351401673970814976",
  "in_reply_to_user_id" : 35667496,
  "text" : "Looks like the ferry from Jack London Square to Embarcadero will be open during the strike: http://t.co/AIeIa0Orae /cc @zenpeacekeeper",
  "id" : 351401673970814976,
  "in_reply_to_status_id" : 351399595718356993,
  "created_at" : "Sun Jun 30 18:07:42 +0000 2013",
  "in_reply_to_screen_name" : "zenpeacekeeper",
  "in_reply_to_user_id_str" : "35667496",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rand Fitzpatrick",
      "screen_name" : "sixwing",
      "indices" : [ 0, 8 ],
      "id_str" : "903011",
      "id" : 903011
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "351398890852978690",
  "geo" : {
  },
  "id_str" : "351399199172067331",
  "in_reply_to_user_id" : 903011,
  "text" : "@sixwing That would be awesome.",
  "id" : 351399199172067331,
  "in_reply_to_status_id" : 351398890852978690,
  "created_at" : "Sun Jun 30 17:57:52 +0000 2013",
  "in_reply_to_screen_name" : "sixwing",
  "in_reply_to_user_id_str" : "903011",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fun",
      "indices" : [ 108, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "351398573478383616",
  "text" : "BART strike is apparently happening and I'm one of 400,000 people that need to get across the Bay tomorrow. #fun",
  "id" : 351398573478383616,
  "created_at" : "Sun Jun 30 17:55:23 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Sarver",
      "screen_name" : "rsarver",
      "indices" : [ 0, 8 ],
      "id_str" : "795649",
      "id" : 795649
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "351331600379813888",
  "geo" : {
  },
  "id_str" : "351333202482311168",
  "in_reply_to_user_id" : 795649,
  "text" : "@rsarver yeah, I can't stop reading about them.",
  "id" : 351333202482311168,
  "in_reply_to_status_id" : 351331600379813888,
  "created_at" : "Sun Jun 30 13:35:37 +0000 2013",
  "in_reply_to_screen_name" : "rsarver",
  "in_reply_to_user_id_str" : "795649",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Gilbert",
      "screen_name" : "DanTGilbert",
      "indices" : [ 23, 35 ],
      "id_str" : "525785424",
      "id" : 525785424
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http://t.co/2z8dxfg9j6",
      "expanded_url" : "http://bit.ly/18ogibS",
      "display_url" : "bit.ly/18ogibS"
    } ]
  },
  "in_reply_to_status_id_str" : "351298765585522688",
  "geo" : {
  },
  "id_str" : "351329069029277696",
  "in_reply_to_user_id" : 525785424,
  "text" : "Just read them all. RT @DanTGilbert: Texas posts the last words of every person it executes. http://t.co/2z8dxfg9j6",
  "id" : 351329069029277696,
  "in_reply_to_status_id" : 351298765585522688,
  "created_at" : "Sun Jun 30 13:19:12 +0000 2013",
  "in_reply_to_screen_name" : "DanTGilbert",
  "in_reply_to_user_id_str" : "525785424",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Bonner",
      "screen_name" : "seanbonner",
      "indices" : [ 0, 11 ],
      "id_str" : "765",
      "id" : 765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "351202046352953345",
  "geo" : {
  },
  "id_str" : "351215202827649025",
  "in_reply_to_user_id" : 765,
  "text" : "@seanbonner Who's gonna be our next prez?",
  "id" : 351215202827649025,
  "in_reply_to_status_id" : 351202046352953345,
  "created_at" : "Sun Jun 30 05:46:44 +0000 2013",
  "in_reply_to_screen_name" : "seanbonner",
  "in_reply_to_user_id_str" : "765",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Bonner",
      "screen_name" : "seanbonner",
      "indices" : [ 0, 11 ],
      "id_str" : "765",
      "id" : 765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "351213253419991040",
  "geo" : {
  },
  "id_str" : "351214576689352705",
  "in_reply_to_user_id" : 765,
  "text" : "@seanbonner Don't zen koan me. I want your opinion on the matter.",
  "id" : 351214576689352705,
  "in_reply_to_status_id" : 351213253419991040,
  "created_at" : "Sun Jun 30 05:44:14 +0000 2013",
  "in_reply_to_screen_name" : "seanbonner",
  "in_reply_to_user_id_str" : "765",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 43 ],
      "url" : "http://t.co/NWnVdA22uZ",
      "expanded_url" : "http://flic.kr/p/eYyZwb",
      "display_url" : "flic.kr/p/eYyZwb"
    } ]
  },
  "geo" : {
  },
  "id_str" : "351214107099267072",
  "text" : "Niko's ready for bed http://t.co/NWnVdA22uZ",
  "id" : 351214107099267072,
  "created_at" : "Sun Jun 30 05:42:23 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Bonner",
      "screen_name" : "seanbonner",
      "indices" : [ 0, 11 ],
      "id_str" : "765",
      "id" : 765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "351202046352953345",
  "geo" : {
  },
  "id_str" : "351212906492342273",
  "in_reply_to_user_id" : 765,
  "text" : "@seanbonner Are we living in a simulation?",
  "id" : 351212906492342273,
  "in_reply_to_status_id" : 351202046352953345,
  "created_at" : "Sun Jun 30 05:37:36 +0000 2013",
  "in_reply_to_screen_name" : "seanbonner",
  "in_reply_to_user_id_str" : "765",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.apple.com\" rel=\"nofollow\">iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 11, 21 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 71 ],
      "url" : "http://t.co/kFRdQsmnhy",
      "expanded_url" : "http://instagram.com/p/bKxfzxOFVp/",
      "display_url" : "instagram.com/p/bKxfzxOFVp/"
    } ]
  },
  "geo" : {
  },
  "id_str" : "351211341022887939",
  "text" : "Gonna miss @kellianne's bro Joey staying with us http://t.co/kFRdQsmnhy",
  "id" : 351211341022887939,
  "created_at" : "Sun Jun 30 05:31:23 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 58 ],
      "url" : "http://t.co/jX1Gb9rSV9",
      "expanded_url" : "http://flic.kr/p/eYjJsr",
      "display_url" : "flic.kr/p/eYjJsr"
    } ]
  },
  "geo" : {
  },
  "id_str" : "351183187172524035",
  "text" : "8:36pm Niko's food happy smile face http://t.co/jX1Gb9rSV9",
  "id" : 351183187172524035,
  "created_at" : "Sun Jun 30 03:39:31 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://bufferapp.com\" rel=\"nofollow\">Buffer</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Kobar",
      "screen_name" : "chriskobar",
      "indices" : [ 83, 94 ],
      "id_str" : "9379772",
      "id" : 9379772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http://t.co/SrJTtz8740",
      "expanded_url" : "http://bit.ly/12vbDki",
      "display_url" : "bit.ly/12vbDki"
    } ]
  },
  "geo" : {
  },
  "id_str" : "351174266936492034",
  "text" : "My horoscope for July: \u201CYou will learn four new words.\u201D http://t.co/SrJTtz8740 /by @chriskobar",
  "id" : 351174266936492034,
  "created_at" : "Sun Jun 30 03:04:04 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michelle Lu",
      "screen_name" : "lumich1",
      "indices" : [ 62, 70 ],
      "id_str" : "433004647",
      "id" : 433004647
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https://t.co/IIshK42GCF",
      "expanded_url" : "https://medium.com/i-m-h-o/ffa6db26a3fc",
      "display_url" : "medium.com/i-m-h-o/ffa6db\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "351159806947639297",
  "text" : "\u201CThe 3 Keys to\u2026 fuck it, I\u2019m a failure don\u2019t listen to me\u201D by @lumich1 https://t.co/IIshK42GCF",
  "id" : 351159806947639297,
  "created_at" : "Sun Jun 30 02:06:36 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Naval Ravikant",
      "screen_name" : "naval",
      "indices" : [ 0, 6 ],
      "id_str" : "745273",
      "id" : 745273
    }, {
      "name" : "Sam Pullara",
      "screen_name" : "sampullara",
      "indices" : [ 7, 18 ],
      "id_str" : "668473",
      "id" : 668473
    }, {
      "name" : "Aaron Levie",
      "screen_name" : "levie",
      "indices" : [ 19, 25 ],
      "id_str" : "914061",
      "id" : 914061
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "351125520785739776",
  "geo" : {
  },
  "id_str" : "351138207376748544",
  "in_reply_to_user_id" : 745273,
  "text" : "@naval @sampullara @levie It's unsustainable in the sense that you can't keep going after crossing 100%/0%.",
  "id" : 351138207376748544,
  "in_reply_to_status_id" : 351125520785739776,
  "created_at" : "Sun Jun 30 00:40:47 +0000 2013",
  "in_reply_to_screen_name" : "naval",
  "in_reply_to_user_id_str" : "745273",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "gamma sync",
      "screen_name" : "gammasync",
      "indices" : [ 0, 10 ],
      "id_str" : "48071740",
      "id" : 48071740
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "351122440975417344",
  "geo" : {
  },
  "id_str" : "351125584887296001",
  "in_reply_to_user_id" : 48071740,
  "text" : "@gammasync Thanks, I'll get the audiobook!",
  "id" : 351125584887296001,
  "in_reply_to_status_id" : 351122440975417344,
  "created_at" : "Sat Jun 29 23:50:37 +0000 2013",
  "in_reply_to_screen_name" : "gammasync",
  "in_reply_to_user_id_str" : "48071740",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "gamma sync",
      "screen_name" : "gammasync",
      "indices" : [ 0, 10 ],
      "id_str" : "48071740",
      "id" : 48071740
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "351119183888654337",
  "geo" : {
  },
  "id_str" : "351120343374630913",
  "in_reply_to_user_id" : 48071740,
  "text" : "@gammasync Haven't heard of it! Is it good?",
  "id" : 351120343374630913,
  "in_reply_to_status_id" : 351119183888654337,
  "created_at" : "Sat Jun 29 23:29:48 +0000 2013",
  "in_reply_to_screen_name" : "gammasync",
  "in_reply_to_user_id_str" : "48071740",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 61 ],
      "url" : "https://t.co/nbbzPAvZeh",
      "expanded_url" : "https://medium.com/better-humans/20cc8d9c7494",
      "display_url" : "medium.com/better-humans/\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "351117642540662786",
  "text" : "I just published \u201CThe Death Bed Game\u201D https://t.co/nbbzPAvZeh",
  "id" : 351117642540662786,
  "created_at" : "Sat Jun 29 23:19:04 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "351097025158320128",
  "text" : "You get 1 Death Bed Point whenever you do something that you believe will still be valuable/meaningful to you when you're on your death bed.",
  "id" : 351097025158320128,
  "created_at" : "Sat Jun 29 21:57:08 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff S.",
      "screen_name" : "Eigenvariable",
      "indices" : [ 0, 14 ],
      "id_str" : "403233979",
      "id" : 403233979
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cobblershusband",
      "indices" : [ 69, 85 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "351035806393176064",
  "geo" : {
  },
  "id_str" : "351043623409823746",
  "in_reply_to_user_id" : 403233979,
  "text" : "@Eigenvariable Yeah but I'm always the last person to get a haircut. #cobblershusband",
  "id" : 351043623409823746,
  "in_reply_to_status_id" : 351035806393176064,
  "created_at" : "Sat Jun 29 18:24:56 +0000 2013",
  "in_reply_to_screen_name" : "Eigenvariable",
  "in_reply_to_user_id_str" : "403233979",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://vine.co\" rel=\"nofollow\">Vine - Make a Scene</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 35 ],
      "url" : "https://t.co/6oh3cGID36",
      "expanded_url" : "https://vine.co/v/haMzIlTPrp0",
      "display_url" : "vine.co/v/haMzIlTPrp0"
    } ]
  },
  "geo" : {
  },
  "id_str" : "351041911408173056",
  "text" : "Dee-licious https://t.co/6oh3cGID36",
  "id" : 351041911408173056,
  "created_at" : "Sat Jun 29 18:18:08 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ici Ice Cream",
      "screen_name" : "IciIceCream",
      "indices" : [ 86, 98 ],
      "id_str" : "416555801",
      "id" : 416555801
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gooddayforicecream",
      "indices" : [ 62, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http://t.co/P9tOBt9Q2C",
      "expanded_url" : "http://4sq.com/19H3AGD",
      "display_url" : "4sq.com/19H3AGD"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.85735515, -122.253176 ]
  },
  "id_str" : "351036974393610240",
  "text" : "Opens in 4 minutes and there's already a line down the block. #gooddayforicecream (at @IciIceCream) http://t.co/P9tOBt9Q2C",
  "id" : 351036974393610240,
  "created_at" : "Sat Jun 29 17:58:31 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "351025350278524929",
  "text" : "Niko just told me that I look like a cloud. I think it's time for a hair cut.",
  "id" : 351025350278524929,
  "created_at" : "Sat Jun 29 17:12:19 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Isaac Hepworth",
      "screen_name" : "isaach",
      "indices" : [ 0, 7 ],
      "id_str" : "7852612",
      "id" : 7852612
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "350846049277067264",
  "geo" : {
  },
  "id_str" : "350854836360720384",
  "in_reply_to_user_id" : 7852612,
  "text" : "@isaach Sweet. I guess you could just count up from 20...",
  "id" : 350854836360720384,
  "in_reply_to_status_id" : 350846049277067264,
  "created_at" : "Sat Jun 29 05:54:46 +0000 2013",
  "in_reply_to_screen_name" : "isaach",
  "in_reply_to_user_id_str" : "7852612",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Isaac Hepworth",
      "screen_name" : "isaach",
      "indices" : [ 0, 7 ],
      "id_str" : "7852612",
      "id" : 7852612
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "350831870776328192",
  "geo" : {
  },
  "id_str" : "350845357032353792",
  "in_reply_to_user_id" : 7852612,
  "text" : "@isaach Neat! Are all the old tweets somewhere easy to play with?",
  "id" : 350845357032353792,
  "in_reply_to_status_id" : 350831870776328192,
  "created_at" : "Sat Jun 29 05:17:06 +0000 2013",
  "in_reply_to_screen_name" : "isaach",
  "in_reply_to_user_id_str" : "7852612",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 58 ],
      "url" : "http://t.co/YanjRhAOsk",
      "expanded_url" : "http://flic.kr/p/eXCviH",
      "display_url" : "flic.kr/p/eXCviH"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.869791, -122.288314 ]
  },
  "id_str" : "350826037074079746",
  "text" : "8:36pm Heading home from La Mission http://t.co/YanjRhAOsk",
  "id" : 350826037074079746,
  "created_at" : "Sat Jun 29 04:00:19 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Timothy Yip",
      "screen_name" : "tyip",
      "indices" : [ 3, 8 ],
      "id_str" : "12279882",
      "id" : 12279882
    }, {
      "name" : "Buster",
      "screen_name" : "buster",
      "indices" : [ 10, 17 ],
      "id_str" : "2185",
      "id" : 2185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http://t.co/2zYftgeQsC",
      "expanded_url" : "http://www.gamesover.com/walkthroughs/simtower.txt",
      "display_url" : "gamesover.com/walkthroughs/s\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "350654646735474689",
  "text" : "RT @tyip: @buster Section 2 of this document may be helpful: http://t.co/2zYftgeQsC",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Buster",
        "screen_name" : "buster",
        "indices" : [ 0, 7 ],
        "id_str" : "2185",
        "id" : 2185
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 51, 73 ],
        "url" : "http://t.co/2zYftgeQsC",
        "expanded_url" : "http://www.gamesover.com/walkthroughs/simtower.txt",
        "display_url" : "gamesover.com/walkthroughs/s\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "350652815342977024",
    "geo" : {
    },
    "id_str" : "350653935939358720",
    "in_reply_to_user_id" : 2185,
    "text" : "@buster Section 2 of this document may be helpful: http://t.co/2zYftgeQsC",
    "id" : 350653935939358720,
    "in_reply_to_status_id" : 350652815342977024,
    "created_at" : "Fri Jun 28 16:36:27 +0000 2013",
    "in_reply_to_screen_name" : "buster",
    "in_reply_to_user_id_str" : "2185",
    "user" : {
      "name" : "Timothy Yip",
      "screen_name" : "tyip",
      "protected" : false,
      "id_str" : "12279882",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/644038609/Picture_3_normal.jpg",
      "id" : 12279882,
      "verified" : false
    }
  },
  "id" : 350654646735474689,
  "created_at" : "Fri Jun 28 16:39:17 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hackweek",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "350652815342977024",
  "text" : "Can we make the elevator software available for #hackweek?",
  "id" : 350652815342977024,
  "created_at" : "Fri Jun 28 16:32:00 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Isaac Hepworth",
      "screen_name" : "isaach",
      "indices" : [ 3, 10 ],
      "id_str" : "7852612",
      "id" : 7852612
    }, {
      "name" : "Mark S. Luckie",
      "screen_name" : "marksluckie",
      "indices" : [ 29, 41 ],
      "id_str" : "27261369",
      "id" : 27261369
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http://t.co/HJWWlFxWWb",
      "expanded_url" : "http://storify.com/marksluckie/tik-tok-twitter",
      "display_url" : "storify.com/marksluckie/ti\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "350634405305389056",
  "text" : "RT @isaach: a work of art by @marksluckie: http://t.co/HJWWlFxWWb",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mark S. Luckie",
        "screen_name" : "marksluckie",
        "indices" : [ 17, 29 ],
        "id_str" : "27261369",
        "id" : 27261369
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 31, 53 ],
        "url" : "http://t.co/HJWWlFxWWb",
        "expanded_url" : "http://storify.com/marksluckie/tik-tok-twitter",
        "display_url" : "storify.com/marksluckie/ti\u2026"
      } ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 37.7448682923, -122.406101623 ]
    },
    "id_str" : "350631880669933569",
    "text" : "a work of art by @marksluckie: http://t.co/HJWWlFxWWb",
    "id" : 350631880669933569,
    "created_at" : "Fri Jun 28 15:08:49 +0000 2013",
    "user" : {
      "name" : "Isaac Hepworth",
      "screen_name" : "isaach",
      "protected" : false,
      "id_str" : "7852612",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2581404026/image_normal.jpg",
      "id" : 7852612,
      "verified" : false
    }
  },
  "id" : 350634405305389056,
  "created_at" : "Fri Jun 28 15:18:51 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "350470466173018112",
  "text" : "How much of your life is you?",
  "id" : 350470466173018112,
  "created_at" : "Fri Jun 28 04:27:25 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Sarver",
      "screen_name" : "rsarver",
      "indices" : [ 31, 39 ],
      "id_str" : "795649",
      "id" : 795649
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http://t.co/O0gKSbP85C",
      "expanded_url" : "http://flic.kr/p/eWZewa",
      "display_url" : "flic.kr/p/eWZewa"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7714, -122.414362 ]
  },
  "id_str" : "350464452421885952",
  "text" : "8:36pm Lots of people sad that @rsarver is leaving us http://t.co/O0gKSbP85C",
  "id" : 350464452421885952,
  "created_at" : "Fri Jun 28 04:03:31 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    }, {
      "name" : "Nick Crocker",
      "screen_name" : "nickcrocker",
      "indices" : [ 10, 22 ],
      "id_str" : "30801469",
      "id" : 30801469
    }, {
      "name" : "Eric Hekler",
      "screen_name" : "ehekler",
      "indices" : [ 23, 31 ],
      "id_str" : "136385823",
      "id" : 136385823
    }, {
      "name" : "Chris Hogg",
      "screen_name" : "cwhogg",
      "indices" : [ 32, 39 ],
      "id_str" : "15727738",
      "id" : 15727738
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "350310315323428864",
  "geo" : {
  },
  "id_str" : "350359087315304450",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez @nickcrocker @ehekler @cwhogg I pitched in my 2 cents. But am holding myself back from throwing in a couple more dollars. :)",
  "id" : 350359087315304450,
  "in_reply_to_status_id" : 350310315323428864,
  "created_at" : "Thu Jun 27 21:04:50 +0000 2013",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "350155437531873281",
  "text" : "How many things are happening right now that you can't pay attention to?",
  "id" : 350155437531873281,
  "created_at" : "Thu Jun 27 07:35:36 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://vine.co\" rel=\"nofollow\">Vine - Make a Scene</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 37 ],
      "url" : "https://t.co/TB3JpjL5GL",
      "expanded_url" : "https://vine.co/v/hztqWmzFp9D",
      "display_url" : "vine.co/v/hztqWmzFp9D"
    } ]
  },
  "geo" : {
  },
  "id_str" : "350116418454421504",
  "text" : "Scorpion bowl https://t.co/TB3JpjL5GL",
  "id" : 350116418454421504,
  "created_at" : "Thu Jun 27 05:00:33 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Sarver",
      "screen_name" : "rsarver",
      "indices" : [ 27, 35 ],
      "id_str" : "795649",
      "id" : 795649
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 58 ],
      "url" : "http://t.co/mr5o6fMW8e",
      "expanded_url" : "http://flic.kr/p/eWiLoH",
      "display_url" : "flic.kr/p/eWiLoH"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.77695, -122.422989 ]
  },
  "id_str" : "350107674161053696",
  "text" : "8:36pm A million cheers to @rsarver http://t.co/mr5o6fMW8e",
  "id" : 350107674161053696,
  "created_at" : "Thu Jun 27 04:25:48 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Absinthe Brasserie",
      "screen_name" : "AbsintheSF",
      "indices" : [ 53, 64 ],
      "id_str" : "199425544",
      "id" : 199425544
    }, {
      "name" : "Ryan Sarver",
      "screen_name" : "rsarver",
      "indices" : [ 68, 76 ],
      "id_str" : "795649",
      "id" : 795649
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http://t.co/f1sBdL647v",
      "expanded_url" : "http://4sq.com/17DDG5N",
      "display_url" : "4sq.com/17DDG5N"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7773294693, -122.423003912 ]
  },
  "id_str" : "350065811060293632",
  "text" : "Going away dinner :( (@ Absinthe Brasserie and Bar - @absinthesf w/ @rsarver) http://t.co/f1sBdL647v",
  "id" : 350065811060293632,
  "created_at" : "Thu Jun 27 01:39:27 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amelia Greenhall",
      "screen_name" : "ameliagreenhall",
      "indices" : [ 0, 16 ],
      "id_str" : "246531241",
      "id" : 246531241
    }, {
      "name" : "Leigh Honeywell",
      "screen_name" : "hypatiadotca",
      "indices" : [ 17, 30 ],
      "id_str" : "6742522",
      "id" : 6742522
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "350041755871227905",
  "geo" : {
  },
  "id_str" : "350052814128549888",
  "in_reply_to_user_id" : 246531241,
  "text" : "@ameliagreenhall @hypatiadotca Awesome! I've got that article bookmarked for some subway reading.",
  "id" : 350052814128549888,
  "in_reply_to_status_id" : 350041755871227905,
  "created_at" : "Thu Jun 27 00:47:49 +0000 2013",
  "in_reply_to_screen_name" : "ameliagreenhall",
  "in_reply_to_user_id_str" : "246531241",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "349994506306846720",
  "geo" : {
  },
  "id_str" : "349994631049658368",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez I believe so!",
  "id" : 349994631049658368,
  "in_reply_to_status_id" : 349994506306846720,
  "created_at" : "Wed Jun 26 20:56:37 +0000 2013",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "349986661872046082",
  "geo" : {
  },
  "id_str" : "349994360269578240",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez No, unfortunately not this time around\u2026 have a going away party for a friend to attend.",
  "id" : 349994360269578240,
  "in_reply_to_status_id" : 349986661872046082,
  "created_at" : "Wed Jun 26 20:55:32 +0000 2013",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Prevette",
      "screen_name" : "mikeprevette",
      "indices" : [ 0, 13 ],
      "id_str" : "1475531",
      "id" : 1475531
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "349949337331175424",
  "geo" : {
  },
  "id_str" : "349955605651406848",
  "in_reply_to_user_id" : 1475531,
  "text" : "@mikeprevette Tomorrow between 2-4 would work\u2026 maybe more coffee+tour than lunch?",
  "id" : 349955605651406848,
  "in_reply_to_status_id" : 349949337331175424,
  "created_at" : "Wed Jun 26 18:21:32 +0000 2013",
  "in_reply_to_screen_name" : "mikeprevette",
  "in_reply_to_user_id_str" : "1475531",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ginevra",
      "screen_name" : "ginevra",
      "indices" : [ 0, 8 ],
      "id_str" : "35233",
      "id" : 35233
    }, {
      "name" : "David Jacobs",
      "screen_name" : "djacobs",
      "indices" : [ 9, 17 ],
      "id_str" : "774842",
      "id" : 774842
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "349950241396621314",
  "geo" : {
  },
  "id_str" : "349953414203052032",
  "in_reply_to_user_id" : 35233,
  "text" : "@ginevra @djacobs I can't tell you how many I've had to kick out to the curb when they've outstayed their welcome.",
  "id" : 349953414203052032,
  "in_reply_to_status_id" : 349950241396621314,
  "created_at" : "Wed Jun 26 18:12:50 +0000 2013",
  "in_reply_to_screen_name" : "ginevra",
  "in_reply_to_user_id_str" : "35233",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Jacobs",
      "screen_name" : "djacobs",
      "indices" : [ 0, 8 ],
      "id_str" : "774842",
      "id" : 774842
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "349948653819019265",
  "geo" : {
  },
  "id_str" : "349949704768995328",
  "in_reply_to_user_id" : 774842,
  "text" : "@djacobs At first I thought you we're implying I could email BIRGIT or FL\u00D6RT directly and invite them over to my place.",
  "id" : 349949704768995328,
  "in_reply_to_status_id" : 349948653819019265,
  "created_at" : "Wed Jun 26 17:58:06 +0000 2013",
  "in_reply_to_screen_name" : "djacobs",
  "in_reply_to_user_id_str" : "774842",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Explore",
      "screen_name" : "Explorer",
      "indices" : [ 3, 12 ],
      "id_str" : "498328279",
      "id" : 498328279
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http://t.co/oU2ulp4lG3",
      "expanded_url" : "http://j.mp/138yw03",
      "display_url" : "j.mp/138yw03"
    } ]
  },
  "geo" : {
  },
  "id_str" : "349948617018179584",
  "text" : "RT @Explorer: The evolution of marriage equality between 1970 and today's historic ruling, mapped in an animated GIF http://t.co/oU2ulp4lG3",
  "retweeted_status" : {
    "source" : "<a href=\"http://bufferapp.com\" rel=\"nofollow\">Buffer</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 103, 125 ],
        "url" : "http://t.co/oU2ulp4lG3",
        "expanded_url" : "http://j.mp/138yw03",
        "display_url" : "j.mp/138yw03"
      } ]
    },
    "geo" : {
    },
    "id_str" : "349935933874913281",
    "text" : "The evolution of marriage equality between 1970 and today's historic ruling, mapped in an animated GIF http://t.co/oU2ulp4lG3",
    "id" : 349935933874913281,
    "created_at" : "Wed Jun 26 17:03:22 +0000 2013",
    "user" : {
      "name" : "Explore",
      "screen_name" : "Explorer",
      "protected" : false,
      "id_str" : "498328279",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2170469012/twitter_avatar_r_normal.png",
      "id" : 498328279,
      "verified" : false
    }
  },
  "id" : 349948617018179584,
  "created_at" : "Wed Jun 26 17:53:46 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Prevette",
      "screen_name" : "mikeprevette",
      "indices" : [ 0, 13 ],
      "id_str" : "1475531",
      "id" : 1475531
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "349942238903681025",
  "geo" : {
  },
  "id_str" : "349942846561861633",
  "in_reply_to_user_id" : 1475531,
  "text" : "@mikeprevette Wanna come by Twitter HQ for lunch sometime in the next few days?",
  "id" : 349942846561861633,
  "in_reply_to_status_id" : 349942238903681025,
  "created_at" : "Wed Jun 26 17:30:50 +0000 2013",
  "in_reply_to_screen_name" : "mikeprevette",
  "in_reply_to_user_id_str" : "1475531",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Prevette",
      "screen_name" : "mikeprevette",
      "indices" : [ 0, 13 ],
      "id_str" : "1475531",
      "id" : 1475531
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "349937014931599360",
  "geo" : {
  },
  "id_str" : "349939002079592449",
  "in_reply_to_user_id" : 1475531,
  "text" : "@mikeprevette Oh man, we're going to be out of town til after dinner\u2026 wanna come over at like 11? :)",
  "id" : 349939002079592449,
  "in_reply_to_status_id" : 349937014931599360,
  "created_at" : "Wed Jun 26 17:15:34 +0000 2013",
  "in_reply_to_screen_name" : "mikeprevette",
  "in_reply_to_user_id_str" : "1475531",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mihow",
      "screen_name" : "mihow",
      "indices" : [ 3, 9 ],
      "id_str" : "764757",
      "id" : 764757
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SB5",
      "indices" : [ 88, 92 ]
    }, {
      "text" : "DOMA",
      "indices" : [ 93, 98 ]
    }, {
      "text" : "USA",
      "indices" : [ 99, 103 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "349907964045430784",
  "text" : "RT @mihow: That's it! Everyone in the van! I'm taking every American out for ice cream! #SB5 #DOMA #USA",
  "retweeted_status" : {
    "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SB5",
        "indices" : [ 77, 81 ]
      }, {
        "text" : "DOMA",
        "indices" : [ 82, 87 ]
      }, {
        "text" : "USA",
        "indices" : [ 88, 92 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "349902820209721346",
    "text" : "That's it! Everyone in the van! I'm taking every American out for ice cream! #SB5 #DOMA #USA",
    "id" : 349902820209721346,
    "created_at" : "Wed Jun 26 14:51:47 +0000 2013",
    "user" : {
      "name" : "mihow",
      "screen_name" : "mihow",
      "protected" : false,
      "id_str" : "764757",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/344513261566644508/2bd8207376f03b58fdf5b5a4a14382e9_normal.jpeg",
      "id" : 764757,
      "verified" : false
    }
  },
  "id" : 349907964045430784,
  "created_at" : "Wed Jun 26 15:12:14 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrea Grimes",
      "screen_name" : "andreagrimes",
      "indices" : [ 3, 16 ],
      "id_str" : "4209511",
      "id" : 4209511
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SB5",
      "indices" : [ 44, 48 ]
    } ],
    "urls" : [ {
      "indices" : [ 57, 80 ],
      "url" : "https://t.co/NrnB3CDyQ9",
      "expanded_url" : "https://vine.co/v/hzgi2i36QIr",
      "display_url" : "vine.co/v/hzgi2i36QIr"
    } ]
  },
  "geo" : {
  },
  "id_str" : "349791691970060288",
  "text" : "RT @andreagrimes: Wendy Davis confirms that #SB5 IS DEAD https://t.co/NrnB3CDyQ9",
  "retweeted_status" : {
    "source" : "<a href=\"http://vine.co\" rel=\"nofollow\">Vine - Make a Scene</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SB5",
        "indices" : [ 26, 30 ]
      } ],
      "urls" : [ {
        "indices" : [ 39, 62 ],
        "url" : "https://t.co/NrnB3CDyQ9",
        "expanded_url" : "https://vine.co/v/hzgi2i36QIr",
        "display_url" : "vine.co/v/hzgi2i36QIr"
      } ]
    },
    "geo" : {
    },
    "id_str" : "349788666048159744",
    "text" : "Wendy Davis confirms that #SB5 IS DEAD https://t.co/NrnB3CDyQ9",
    "id" : 349788666048159744,
    "created_at" : "Wed Jun 26 07:18:11 +0000 2013",
    "user" : {
      "name" : "Andrea Grimes",
      "screen_name" : "andreagrimes",
      "protected" : false,
      "id_str" : "4209511",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000091434932/78b6e3593f1d7ca815d4d42d11a07535_normal.jpeg",
      "id" : 4209511,
      "verified" : false
    }
  },
  "id" : 349791691970060288,
  "created_at" : "Wed Jun 26 07:30:12 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ingopixel",
      "screen_name" : "ingopixel",
      "indices" : [ 0, 10 ],
      "id_str" : "7943892",
      "id" : 7943892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "349788665922330624",
  "geo" : {
  },
  "id_str" : "349791473287434241",
  "in_reply_to_user_id" : 7943892,
  "text" : "@ingopixel Isn't it sorta great?",
  "id" : 349791473287434241,
  "in_reply_to_status_id" : 349788665922330624,
  "created_at" : "Wed Jun 26 07:29:20 +0000 2013",
  "in_reply_to_screen_name" : "ingopixel",
  "in_reply_to_user_id_str" : "7943892",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "brady forrest",
      "screen_name" : "brady",
      "indices" : [ 3, 9 ],
      "id_str" : "6140",
      "id" : 6140
    }, {
      "name" : "Techmeme",
      "screen_name" : "Techmeme",
      "indices" : [ 85, 94 ],
      "id_str" : "817386",
      "id" : 817386
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http://t.co/6dib3Bdxfo",
      "expanded_url" : "http://readwrite.com/2013/06/25/highway1-pch-international",
      "display_url" : "readwrite.com/2013/06/25/hig\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "349786666778628098",
  "text" : "RT @brady: My latest project - a hardware incubator -&gt; http://t.co/6dib3Bdxfo tip @techmeme",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Techmeme",
        "screen_name" : "Techmeme",
        "indices" : [ 74, 83 ],
        "id_str" : "817386",
        "id" : 817386
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 47, 69 ],
        "url" : "http://t.co/6dib3Bdxfo",
        "expanded_url" : "http://readwrite.com/2013/06/25/highway1-pch-international",
        "display_url" : "readwrite.com/2013/06/25/hig\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "349784716506959872",
    "text" : "My latest project - a hardware incubator -&gt; http://t.co/6dib3Bdxfo tip @techmeme",
    "id" : 349784716506959872,
    "created_at" : "Wed Jun 26 07:02:29 +0000 2013",
    "user" : {
      "name" : "brady forrest",
      "screen_name" : "brady",
      "protected" : false,
      "id_str" : "6140",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1863085951/brady-bw_normal.jpg",
      "id" : 6140,
      "verified" : false
    }
  },
  "id" : 349786666778628098,
  "created_at" : "Wed Jun 26 07:10:14 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "brady forrest",
      "screen_name" : "brady",
      "indices" : [ 0, 6 ],
      "id_str" : "6140",
      "id" : 6140
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "349784716506959872",
  "geo" : {
  },
  "id_str" : "349786626593013760",
  "in_reply_to_user_id" : 6140,
  "text" : "@brady Wow that sounds really cool!",
  "id" : 349786626593013760,
  "in_reply_to_status_id" : 349784716506959872,
  "created_at" : "Wed Jun 26 07:10:05 +0000 2013",
  "in_reply_to_screen_name" : "brady",
  "in_reply_to_user_id_str" : "6140",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "barb dybwad",
      "screen_name" : "doctorparadox",
      "indices" : [ 3, 17 ],
      "id_str" : "1133701",
      "id" : 1133701
    }, {
      "name" : "The Daily Dot",
      "screen_name" : "dailydot",
      "indices" : [ 23, 32 ],
      "id_str" : "211620426",
      "id" : 211620426
    }, {
      "name" : "Wendy Davis",
      "screen_name" : "WendyDavisTexas",
      "indices" : [ 86, 102 ],
      "id_str" : "355906128",
      "id" : 355906128
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SB5",
      "indices" : [ 75, 79 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "349771694124187649",
  "text" : "RT @doctorparadox: the @dailydot has an awesome recap of what went down w/ #SB5 &amp; @WendyDavisTexas's incredible efforts http://t.co/Pl0xJ9p\u2026",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Daily Dot",
        "screen_name" : "dailydot",
        "indices" : [ 4, 13 ],
        "id_str" : "211620426",
        "id" : 211620426
      }, {
        "name" : "Wendy Davis",
        "screen_name" : "WendyDavisTexas",
        "indices" : [ 67, 83 ],
        "id_str" : "355906128",
        "id" : 355906128
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SB5",
        "indices" : [ 56, 60 ]
      } ],
      "urls" : [ {
        "indices" : [ 105, 127 ],
        "url" : "http://t.co/Pl0xJ9pRX2",
        "expanded_url" : "http://www.dailydot.com/politics/wendy-davis-filibuster-texas-sb5/",
        "display_url" : "dailydot.com/politics/wendy\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "349767806390243329",
    "text" : "the @dailydot has an awesome recap of what went down w/ #SB5 &amp; @WendyDavisTexas's incredible efforts http://t.co/Pl0xJ9pRX2",
    "id" : 349767806390243329,
    "created_at" : "Wed Jun 26 05:55:18 +0000 2013",
    "user" : {
      "name" : "barb dybwad",
      "screen_name" : "doctorparadox",
      "protected" : false,
      "id_str" : "1133701",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2866064206/fbb831e8d6878fc45d5b0717f414655e_normal.png",
      "id" : 1133701,
      "verified" : false
    }
  },
  "id" : 349771694124187649,
  "created_at" : "Wed Jun 26 06:10:44 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "standwithwendy",
      "indices" : [ 91, 106 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "349764305111097344",
  "text" : "Force = mass * acceleration, i.e. people speaking up (Wendy Davis) * people passing it on (#standwithwendy).",
  "id" : 349764305111097344,
  "created_at" : "Wed Jun 26 05:41:23 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dammit, Ross!",
      "screen_name" : "Rosscott",
      "indices" : [ 3, 12 ],
      "id_str" : "15811487",
      "id" : 15811487
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "349760997130649600",
  "text" : "RT @Rosscott: AP and CBS calling it passed. Twitter is calling it bullshit. CNN calling muffins fattening.",
  "retweeted_status" : {
    "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "349759060851175425",
    "text" : "AP and CBS calling it passed. Twitter is calling it bullshit. CNN calling muffins fattening.",
    "id" : 349759060851175425,
    "created_at" : "Wed Jun 26 05:20:32 +0000 2013",
    "user" : {
      "name" : "Dammit, Ross!",
      "screen_name" : "Rosscott",
      "protected" : false,
      "id_str" : "15811487",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3033092953/2dce183a32a9bd5c95def2ef056776a9_normal.jpeg",
      "id" : 15811487,
      "verified" : false
    }
  },
  "id" : 349760997130649600,
  "created_at" : "Wed Jun 26 05:28:14 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Greg Greene",
      "screen_name" : "ggreeneva",
      "indices" : [ 3, 13 ],
      "id_str" : "775142",
      "id" : 775142
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "StandWithWendy",
      "indices" : [ 79, 94 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "349760010928140290",
  "text" : "RT @ggreeneva: What confuses Texas Republicans:\n1) Women\n2) Science\n3) Clocks\n\n#StandWithWendy",
  "retweeted_status" : {
    "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "StandWithWendy",
        "indices" : [ 64, 79 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "349757301818802177",
    "text" : "What confuses Texas Republicans:\n1) Women\n2) Science\n3) Clocks\n\n#StandWithWendy",
    "id" : 349757301818802177,
    "created_at" : "Wed Jun 26 05:13:33 +0000 2013",
    "user" : {
      "name" : "Greg Greene",
      "screen_name" : "ggreeneva",
      "protected" : false,
      "id_str" : "775142",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2825600352/f9d951060a5823e15d94a7360bd9c8de_normal.png",
      "id" : 775142,
      "verified" : false
    }
  },
  "id" : 349760010928140290,
  "created_at" : "Wed Jun 26 05:24:19 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 55 ],
      "url" : "http://t.co/9uBVIJnD4g",
      "expanded_url" : "http://flic.kr/p/eVzoaP",
      "display_url" : "flic.kr/p/eVzoaP"
    } ]
  },
  "geo" : {
  },
  "id_str" : "349733672146051072",
  "text" : "8:36pm Niko's a muppet of a man  http://t.co/9uBVIJnD4g",
  "id" : 349733672146051072,
  "created_at" : "Wed Jun 26 03:39:39 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Cole",
      "screen_name" : "irondavy",
      "indices" : [ 0, 9 ],
      "id_str" : "14986129",
      "id" : 14986129
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "349721411398533122",
  "geo" : {
  },
  "id_str" : "349722568959344641",
  "in_reply_to_user_id" : 14986129,
  "text" : "@irondavy I'm not sure! Which animal am I?",
  "id" : 349722568959344641,
  "in_reply_to_status_id" : 349721411398533122,
  "created_at" : "Wed Jun 26 02:55:32 +0000 2013",
  "in_reply_to_screen_name" : "irondavy",
  "in_reply_to_user_id_str" : "14986129",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Cole",
      "screen_name" : "irondavy",
      "indices" : [ 0, 9 ],
      "id_str" : "14986129",
      "id" : 14986129
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "349717921645338624",
  "geo" : {
  },
  "id_str" : "349720175051935747",
  "in_reply_to_user_id" : 14986129,
  "text" : "@irondavy How much to commission a cool animal profile icon like you have?",
  "id" : 349720175051935747,
  "in_reply_to_status_id" : 349717921645338624,
  "created_at" : "Wed Jun 26 02:46:01 +0000 2013",
  "in_reply_to_screen_name" : "irondavy",
  "in_reply_to_user_id_str" : "14986129",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Sippey",
      "screen_name" : "sippey",
      "indices" : [ 0, 7 ],
      "id_str" : "4711",
      "id" : 4711
    }, {
      "name" : "iA Inc.",
      "screen_name" : "iA",
      "indices" : [ 8, 11 ],
      "id_str" : "2087371",
      "id" : 2087371
    }, {
      "name" : "Robin Sloan",
      "screen_name" : "robinsloan",
      "indices" : [ 12, 23 ],
      "id_str" : "13919072",
      "id" : 13919072
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "349702446886555648",
  "geo" : {
  },
  "id_str" : "349716988349779970",
  "in_reply_to_user_id" : 4711,
  "text" : "@sippey @iA @robinsloan I did that at Amazon. It was actually pretty useful... totally forgot about it until just now.",
  "id" : 349716988349779970,
  "in_reply_to_status_id" : 349702446886555648,
  "created_at" : "Wed Jun 26 02:33:22 +0000 2013",
  "in_reply_to_screen_name" : "sippey",
  "in_reply_to_user_id_str" : "4711",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Branch",
      "screen_name" : "branch",
      "indices" : [ 4, 11 ],
      "id_str" : "494518813",
      "id" : 494518813
    }, {
      "name" : "Potluck",
      "screen_name" : "potluck",
      "indices" : [ 26, 34 ],
      "id_str" : "1395445934",
      "id" : 1395445934
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http://t.co/SDjz4LYs0Q",
      "expanded_url" : "http://m.techcrunch.com/2013/06/25/from-the-team-behind-branch-potluck-is-a-new-link-sharing-service-for-the-internets-lurkers-who-dont-tweet-or-blog/",
      "display_url" : "m.techcrunch.com/2013/06/25/fro\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "349536075359850497",
  "text" : "The @branch team launches @potluck - a place for lurkers to talk about stuff. It's fun. Check it: http://t.co/SDjz4LYs0Q",
  "id" : 349536075359850497,
  "created_at" : "Tue Jun 25 14:34:29 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Willo O'Brien",
      "screen_name" : "WilloLovesYou",
      "indices" : [ 0, 14 ],
      "id_str" : "772386",
      "id" : 772386
    }, {
      "name" : "Jay Goldman",
      "screen_name" : "jaygoldman",
      "indices" : [ 15, 26 ],
      "id_str" : "861",
      "id" : 861
    }, {
      "name" : "willo",
      "screen_name" : "willo",
      "indices" : [ 27, 33 ],
      "id_str" : "419",
      "id" : 419
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "349422262157447168",
  "geo" : {
  },
  "id_str" : "349426308968751104",
  "in_reply_to_user_id" : 772386,
  "text" : "@WilloLovesYou @jaygoldman @willo Truce! We're all July 2006 kids, can't we just all get along?",
  "id" : 349426308968751104,
  "in_reply_to_status_id" : 349422262157447168,
  "created_at" : "Tue Jun 25 07:18:18 +0000 2013",
  "in_reply_to_screen_name" : "WilloLovesYou",
  "in_reply_to_user_id_str" : "772386",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay Goldman",
      "screen_name" : "jaygoldman",
      "indices" : [ 0, 11 ],
      "id_str" : "861",
      "id" : 861
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "349414382184300545",
  "geo" : {
  },
  "id_str" : "349414971735674882",
  "in_reply_to_user_id" : 861,
  "text" : "@jaygoldman I'm not but I regret my antisocial tendencies already, from the looks of it.",
  "id" : 349414971735674882,
  "in_reply_to_status_id" : 349414382184300545,
  "created_at" : "Tue Jun 25 06:33:15 +0000 2013",
  "in_reply_to_screen_name" : "jaygoldman",
  "in_reply_to_user_id_str" : "861",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay Goldman",
      "screen_name" : "jaygoldman",
      "indices" : [ 0, 11 ],
      "id_str" : "861",
      "id" : 861
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "349411126741708801",
  "geo" : {
  },
  "id_str" : "349414290614259713",
  "in_reply_to_user_id" : 861,
  "text" : "@jaygoldman I didn't know this was happening! Cool! Let's get a drink when you officially arrive.",
  "id" : 349414290614259713,
  "in_reply_to_status_id" : 349411126741708801,
  "created_at" : "Tue Jun 25 06:30:33 +0000 2013",
  "in_reply_to_screen_name" : "jaygoldman",
  "in_reply_to_user_id_str" : "861",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "asa",
      "screen_name" : "asa",
      "indices" : [ 0, 4 ],
      "id_str" : "407",
      "id" : 407
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "349411826225778688",
  "geo" : {
  },
  "id_str" : "349413193380139010",
  "in_reply_to_user_id" : 407,
  "text" : "@asa As King of All.",
  "id" : 349413193380139010,
  "in_reply_to_status_id" : 349411826225778688,
  "created_at" : "Tue Jun 25 06:26:11 +0000 2013",
  "in_reply_to_screen_name" : "asa",
  "in_reply_to_user_id_str" : "407",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay Goldman",
      "screen_name" : "jaygoldman",
      "indices" : [ 0, 11 ],
      "id_str" : "861",
      "id" : 861
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "349405794271379458",
  "geo" : {
  },
  "id_str" : "349410683307302912",
  "in_reply_to_user_id" : 861,
  "text" : "@jaygoldman Only one way to find out... send me your r\u00E9sum\u00E9! :)",
  "id" : 349410683307302912,
  "in_reply_to_status_id" : 349405794271379458,
  "created_at" : "Tue Jun 25 06:16:13 +0000 2013",
  "in_reply_to_screen_name" : "jaygoldman",
  "in_reply_to_user_id_str" : "861",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lane Collins",
      "screen_name" : "lane",
      "indices" : [ 0, 5 ],
      "id_str" : "541",
      "id" : 541
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "349407137040048128",
  "geo" : {
  },
  "id_str" : "349409850763128832",
  "in_reply_to_user_id" : 541,
  "text" : "@lane Oh man I totally forgot how early you were. Shoulda known better than to open this Pandora's Box.",
  "id" : 349409850763128832,
  "in_reply_to_status_id" : 349407137040048128,
  "created_at" : "Tue Jun 25 06:12:54 +0000 2013",
  "in_reply_to_screen_name" : "lane",
  "in_reply_to_user_id_str" : "541",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Sippey",
      "screen_name" : "sippey",
      "indices" : [ 0, 7 ],
      "id_str" : "4711",
      "id" : 4711
    }, {
      "name" : "Bill Couch",
      "screen_name" : "couch",
      "indices" : [ 8, 14 ],
      "id_str" : "631823",
      "id" : 631823
    }, {
      "name" : "Ian Chan",
      "screen_name" : "chanian",
      "indices" : [ 15, 23 ],
      "id_str" : "22891211",
      "id" : 22891211
    }, {
      "name" : "Justin Chen",
      "screen_name" : "leftparen",
      "indices" : [ 24, 34 ],
      "id_str" : "78154150",
      "id" : 78154150
    }, {
      "name" : "Bob Johnston",
      "screen_name" : "Bob",
      "indices" : [ 45, 49 ],
      "id_str" : "344",
      "id" : 344
    }, {
      "name" : "cg",
      "screen_name" : "cg",
      "indices" : [ 54, 57 ],
      "id_str" : "750",
      "id" : 750
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "349403142380728322",
  "geo" : {
  },
  "id_str" : "349404091815968768",
  "in_reply_to_user_id" : 4711,
  "text" : "@sippey @couch @chanian @leftparen True, but @bob and @cg... time for some anonymous unsolicited peer reviews?",
  "id" : 349404091815968768,
  "in_reply_to_status_id" : 349403142380728322,
  "created_at" : "Tue Jun 25 05:50:01 +0000 2013",
  "in_reply_to_screen_name" : "sippey",
  "in_reply_to_user_id_str" : "4711",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Couch",
      "screen_name" : "couch",
      "indices" : [ 37, 43 ],
      "id_str" : "631823",
      "id" : 631823
    }, {
      "name" : "Ian Chan",
      "screen_name" : "chanian",
      "indices" : [ 44, 52 ],
      "id_str" : "22891211",
      "id" : 22891211
    }, {
      "name" : "Justin Chen",
      "screen_name" : "leftparen",
      "indices" : [ 53, 63 ],
      "id_str" : "78154150",
      "id" : 78154150
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "349402331198140416",
  "text" : "Hanging out with Twitter old timers (@couch @chanian @leftparen) &amp; learned that I'm not the Twitter employee with the lowest user number. :(",
  "id" : 349402331198140416,
  "created_at" : "Tue Jun 25 05:43:01 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Juli\u00E1n Santa Ana",
      "screen_name" : "juliansantaana",
      "indices" : [ 0, 15 ],
      "id_str" : "48196438",
      "id" : 48196438
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "349352805456289793",
  "geo" : {
  },
  "id_str" : "349380444590063616",
  "in_reply_to_user_id" : 48196438,
  "text" : "@juliansantaana Absolutely! Or email me: buster@twitter.com",
  "id" : 349380444590063616,
  "in_reply_to_status_id" : 349352805456289793,
  "created_at" : "Tue Jun 25 04:16:03 +0000 2013",
  "in_reply_to_screen_name" : "juliansantaana",
  "in_reply_to_user_id_str" : "48196438",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http://t.co/fDpFhlDfK0",
      "expanded_url" : "http://flic.kr/p/eV2iCs",
      "display_url" : "flic.kr/p/eV2iCs"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.774947, -122.410003 ]
  },
  "id_str" : "349374132636491776",
  "text" : "8:36pm Quarterly drinks with coworkers http://t.co/fDpFhlDfK0",
  "id" : 349374132636491776,
  "created_at" : "Tue Jun 25 03:50:58 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pejman Pour-Moezzi",
      "screen_name" : "pejmanjohn",
      "indices" : [ 0, 11 ],
      "id_str" : "14358239",
      "id" : 14358239
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "349303886462459904",
  "geo" : {
  },
  "id_str" : "349319237640261632",
  "in_reply_to_user_id" : 14358239,
  "text" : "@pejmanjohn Thanks for spreading the word! Let me know if I can help answer any questions about implementation / best practices.",
  "id" : 349319237640261632,
  "in_reply_to_status_id" : 349303886462459904,
  "created_at" : "Tue Jun 25 00:12:50 +0000 2013",
  "in_reply_to_screen_name" : "pejmanjohn",
  "in_reply_to_user_id_str" : "14358239",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martin Pham",
      "screen_name" : "MartinPham",
      "indices" : [ 0, 11 ],
      "id_str" : "260147903",
      "id" : 260147903
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "349303686687756289",
  "geo" : {
  },
  "id_str" : "349318937537814528",
  "in_reply_to_user_id" : 260147903,
  "text" : "@MartinPham Thanks for the kind words, Martin!",
  "id" : 349318937537814528,
  "in_reply_to_status_id" : 349303686687756289,
  "created_at" : "Tue Jun 25 00:11:39 +0000 2013",
  "in_reply_to_screen_name" : "MartinPham",
  "in_reply_to_user_id_str" : "260147903",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "349271850293018625",
  "geo" : {
  },
  "id_str" : "349273291783024642",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez I do! That was fun. Crazy that it was 2 years ago.",
  "id" : 349273291783024642,
  "in_reply_to_status_id" : 349271850293018625,
  "created_at" : "Mon Jun 24 21:10:16 +0000 2013",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard Dawkins",
      "screen_name" : "RichardDawkins",
      "indices" : [ 22, 37 ],
      "id_str" : "15143478",
      "id" : 15143478
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 79 ],
      "url" : "http://t.co/QqvKj6kj7k",
      "expanded_url" : "http://www.youtube.com/watch?v=GFn-ixX9edg&feature=youtu.be&t=4m44s",
      "display_url" : "youtube.com/watch?v=GFn-ix\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "349209281444315136",
  "text" : "You have to see this. @RichardDawkins creates a... meme? http://t.co/QqvKj6kj7k",
  "id" : 349209281444315136,
  "created_at" : "Mon Jun 24 16:55:55 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amit superamit Gupta",
      "screen_name" : "superamit",
      "indices" : [ 10, 20 ],
      "id_str" : "10609",
      "id" : 10609
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http://t.co/oRIEXqiEl5",
      "expanded_url" : "http://tumblr.amitgupta.com/post/53763508109/fatigue",
      "display_url" : "tumblr.amitgupta.com/post/537635081\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "349198399469412353",
  "geo" : {
  },
  "id_str" : "349205930040238080",
  "in_reply_to_user_id" : 10609,
  "text" : "&lt;3s RT @superamit: Wrote about something that's been effecting me for a while and I'm not sure how to deal with: http://t.co/oRIEXqiEl5",
  "id" : 349205930040238080,
  "in_reply_to_status_id" : 349198399469412353,
  "created_at" : "Mon Jun 24 16:42:36 +0000 2013",
  "in_reply_to_screen_name" : "superamit",
  "in_reply_to_user_id_str" : "10609",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Sippey",
      "screen_name" : "sippey",
      "indices" : [ 0, 7 ],
      "id_str" : "4711",
      "id" : 4711
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "349056573630451712",
  "geo" : {
  },
  "id_str" : "349060697071681536",
  "in_reply_to_user_id" : 4711,
  "text" : "@sippey Mine too. Also, loved that article on a/b testing and coherent false narratives. Relevant to our interests.",
  "id" : 349060697071681536,
  "in_reply_to_status_id" : 349056573630451712,
  "created_at" : "Mon Jun 24 07:05:30 +0000 2013",
  "in_reply_to_screen_name" : "sippey",
  "in_reply_to_user_id_str" : "4711",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.apple.com\" rel=\"nofollow\">iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http://t.co/uQMAyhfLv7",
      "expanded_url" : "http://tmblr.co/ZKHlbyo2T-2Q",
      "display_url" : "tmblr.co/ZKHlbyo2T-2Q"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.855358, -122.278457 ]
  },
  "id_str" : "349049991244939264",
  "text" : "Woah. \"Talk out of the part of yourself than can love instead of the part that just wants to be loved.\" http://t.co/uQMAyhfLv7",
  "id" : 349049991244939264,
  "created_at" : "Mon Jun 24 06:22:57 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luke Millar",
      "screen_name" : "ltm",
      "indices" : [ 0, 4 ],
      "id_str" : "14616067",
      "id" : 14616067
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "349043486147870720",
  "geo" : {
  },
  "id_str" : "349047132885495809",
  "in_reply_to_user_id" : 14616067,
  "text" : "@ltm I actually like Airplane Mode... use it all the time as an easy Save Battery mode. On actual airplanes, not so much.",
  "id" : 349047132885495809,
  "in_reply_to_status_id" : 349043486147870720,
  "created_at" : "Mon Jun 24 06:11:36 +0000 2013",
  "in_reply_to_screen_name" : "ltm",
  "in_reply_to_user_id_str" : "14616067",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TechCrunch",
      "screen_name" : "TechCrunch",
      "indices" : [ 26, 37 ],
      "id_str" : "816653",
      "id" : 816653
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "willingtowait",
      "indices" : [ 8, 22 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http://t.co/RNcxZwqTQ1",
      "expanded_url" : "http://tcrn.ch/15xk7Fm",
      "display_url" : "tcrn.ch/15xk7Fm"
    } ]
  },
  "in_reply_to_status_id_str" : "349029968090640384",
  "geo" : {
  },
  "id_str" : "349039351260389377",
  "in_reply_to_user_id" : 816653,
  "text" : "Awesome #willingtowait RT @TechCrunch: FAA Says It Will Be Months Before In-Flight Electronics Ban Is Lifted http://t.co/RNcxZwqTQ1",
  "id" : 349039351260389377,
  "in_reply_to_status_id" : 349029968090640384,
  "created_at" : "Mon Jun 24 05:40:40 +0000 2013",
  "in_reply_to_screen_name" : "TechCrunch",
  "in_reply_to_user_id_str" : "816653",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "349005525041684482",
  "text" : "1, 2, skip a few, 100!",
  "id" : 349005525041684482,
  "created_at" : "Mon Jun 24 03:26:16 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http://t.co/dndDUyPjcW",
      "expanded_url" : "http://flic.kr/p/eUcFhA",
      "display_url" : "flic.kr/p/eUcFhA"
    } ]
  },
  "geo" : {
  },
  "id_str" : "349002987785555968",
  "text" : "8:36pm Niko's choice of hide 'n seek spots needs some work http://t.co/dndDUyPjcW",
  "id" : 349002987785555968,
  "created_at" : "Mon Jun 24 03:16:11 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Buster",
      "screen_name" : "buster",
      "indices" : [ 0, 7 ],
      "id_str" : "2185",
      "id" : 2185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "348965626221559808",
  "geo" : {
  },
  "id_str" : "348966073741213696",
  "in_reply_to_user_id" : 2185,
  "text" : "@buster Or rather Healdsburg.",
  "id" : 348966073741213696,
  "in_reply_to_status_id" : 348965626221559808,
  "created_at" : "Mon Jun 24 00:49:30 +0000 2013",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://vine.co\" rel=\"nofollow\">Vine - Make a Scene</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 85 ],
      "url" : "https://t.co/taoYi5p8y9",
      "expanded_url" : "https://vine.co/v/hulnDWwlPH1",
      "display_url" : "vine.co/v/hulnDWwlPH1"
    } ]
  },
  "geo" : {
  },
  "id_str" : "348965626221559808",
  "text" : "OH in Heraldsburg: \"Grab a beer and a gun and relax with us.\" https://t.co/taoYi5p8y9",
  "id" : 348965626221559808,
  "created_at" : "Mon Jun 24 00:47:43 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "selfdrivingeverything",
      "indices" : [ 108, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "348924087625715712",
  "text" : "Watching Joe and Jude (10 yo) play Halo 4. Shouldn't their robot suits do the aiming and shooting for them? #selfdrivingeverything",
  "id" : 348924087625715712,
  "created_at" : "Sun Jun 23 22:02:39 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://vine.co\" rel=\"nofollow\">Vine - Make a Scene</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 69 ],
      "url" : "https://t.co/9xxQJcN8pV",
      "expanded_url" : "https://vine.co/v/hu3ttVITOXp",
      "display_url" : "vine.co/v/hu3ttVITOXp"
    } ]
  },
  "geo" : {
  },
  "id_str" : "348903500467552256",
  "text" : "Quivira Vineyards, 100% biodynamic(R) gardens https://t.co/9xxQJcN8pV",
  "id" : 348903500467552256,
  "created_at" : "Sun Jun 23 20:40:51 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http://t.co/jqR2LOlQmf",
      "expanded_url" : "http://4sq.com/11yq33m",
      "display_url" : "4sq.com/11yq33m"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 38.6730015278, -122.934306 ]
  },
  "id_str" : "348886733049450496",
  "text" : "Visiting Healdsburg! (@ Kokomo Winery) http://t.co/jqR2LOlQmf",
  "id" : 348886733049450496,
  "created_at" : "Sun Jun 23 19:34:13 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mari Huertas",
      "screen_name" : "marihuertas",
      "indices" : [ 3, 15 ],
      "id_str" : "195863654",
      "id" : 195863654
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http://t.co/Cxu31QJWvQ",
      "expanded_url" : "http://lightbox.time.com/2013/06/21/they-call-it-the-penguin-hubbles-amazing-photo-of-galaxies-colliding/#1",
      "display_url" : "lightbox.time.com/2013/06/21/the\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "348863174533062656",
  "text" : "RT @marihuertas: In case you were wondering, this is what it looks like when galaxies collide: http://t.co/Cxu31QJWvQ",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 78, 100 ],
        "url" : "http://t.co/Cxu31QJWvQ",
        "expanded_url" : "http://lightbox.time.com/2013/06/21/they-call-it-the-penguin-hubbles-amazing-photo-of-galaxies-colliding/#1",
        "display_url" : "lightbox.time.com/2013/06/21/the\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "348858125991940099",
    "text" : "In case you were wondering, this is what it looks like when galaxies collide: http://t.co/Cxu31QJWvQ",
    "id" : 348858125991940099,
    "created_at" : "Sun Jun 23 17:40:33 +0000 2013",
    "user" : {
      "name" : "Mari Huertas",
      "screen_name" : "marihuertas",
      "protected" : false,
      "id_str" : "195863654",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3677974911/def7e1e5d51808b9b6146a1330ca5908_normal.jpeg",
      "id" : 195863654,
      "verified" : false
    }
  },
  "id" : 348863174533062656,
  "created_at" : "Sun Jun 23 18:00:37 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vinod Khosla",
      "screen_name" : "vkhosla",
      "indices" : [ 3, 11 ],
      "id_str" : "42226885",
      "id" : 42226885
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "348862962682957825",
  "text" : "RT @vkhosla: Big Data: Virtually every field,  science/sports/public health/etc being transformed by data-driven discovery http://t.co/53oe\u2026",
  "retweeted_status" : {
    "source" : "<a href=\"http://bitly.com\" rel=\"nofollow\">bitly</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 110, 132 ],
        "url" : "http://t.co/53oedP1XQN",
        "expanded_url" : "http://nyti.ms/11T0p4O",
        "display_url" : "nyti.ms/11T0p4O"
      } ]
    },
    "geo" : {
    },
    "id_str" : "348498985012572161",
    "text" : "Big Data: Virtually every field,  science/sports/public health/etc being transformed by data-driven discovery http://t.co/53oedP1XQN",
    "id" : 348498985012572161,
    "created_at" : "Sat Jun 22 17:53:27 +0000 2013",
    "user" : {
      "name" : "Vinod Khosla",
      "screen_name" : "vkhosla",
      "protected" : false,
      "id_str" : "42226885",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2398344802/bm0r011ulnx6nd6ndtn9_normal.jpeg",
      "id" : 42226885,
      "verified" : true
    }
  },
  "id" : 348862962682957825,
  "created_at" : "Sun Jun 23 17:59:46 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Animal Life",
      "screen_name" : "fabulousanimals",
      "indices" : [ 3, 19 ],
      "id_str" : "558446365",
      "id" : 558446365
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/fabulousanimals/status/348232657550856192/photo/1",
      "indices" : [ 41, 63 ],
      "url" : "http://t.co/iHKjyd1s9c",
      "media_url" : "http://pbs.twimg.com/media/BNUrwczCUAAw9rx.jpg",
      "id_str" : "348232657555050496",
      "id" : 348232657555050496,
      "media_url_https" : "https://pbs.twimg.com/media/BNUrwczCUAAw9rx.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com/iHKjyd1s9c"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "348848680528384000",
  "text" : "RT @fabulousanimals: Afraid of the rain. http://t.co/iHKjyd1s9c",
  "retweeted_status" : {
    "source" : "<a href=\"http://bufferapp.com\" rel=\"nofollow\">Buffer</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http://twitter.com/fabulousanimals/status/348232657550856192/photo/1",
        "indices" : [ 20, 42 ],
        "url" : "http://t.co/iHKjyd1s9c",
        "media_url" : "http://pbs.twimg.com/media/BNUrwczCUAAw9rx.jpg",
        "id_str" : "348232657555050496",
        "id" : 348232657555050496,
        "media_url_https" : "https://pbs.twimg.com/media/BNUrwczCUAAw9rx.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com/iHKjyd1s9c"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "348232657550856192",
    "text" : "Afraid of the rain. http://t.co/iHKjyd1s9c",
    "id" : 348232657550856192,
    "created_at" : "Sat Jun 22 00:15:10 +0000 2013",
    "user" : {
      "name" : "Animal Life",
      "screen_name" : "fabulousanimals",
      "protected" : false,
      "id_str" : "558446365",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3315780973/f771546322a54648fb557f2808b39694_normal.jpeg",
      "id" : 558446365,
      "verified" : false
    }
  },
  "id" : 348848680528384000,
  "created_at" : "Sun Jun 23 17:03:01 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http://t.co/8jlRWaXnKs",
      "expanded_url" : "http://flic.kr/p/eTmYiW",
      "display_url" : "flic.kr/p/eTmYiW"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.860508, -122.289825 ]
  },
  "id_str" : "348650288506355713",
  "text" : "8:36pm Finishing dinner and awesome bike rides with Kellianne's bro http://t.co/8jlRWaXnKs",
  "id" : 348650288506355713,
  "created_at" : "Sun Jun 23 03:54:41 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James",
      "screen_name" : "Weziington",
      "indices" : [ 3, 14 ],
      "id_str" : "1330444050",
      "id" : 1330444050
    }, {
      "name" : "Buster",
      "screen_name" : "buster",
      "indices" : [ 16, 23 ],
      "id_str" : "2185",
      "id" : 2185
    }, {
      "name" : "Samuel Brown",
      "screen_name" : "Brown",
      "indices" : [ 24, 30 ],
      "id_str" : "3794211",
      "id" : 3794211
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "348618874373144576",
  "text" : "RT @Weziington: @buster @brown",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Buster",
        "screen_name" : "buster",
        "indices" : [ 0, 7 ],
        "id_str" : "2185",
        "id" : 2185
      }, {
        "name" : "Samuel Brown",
        "screen_name" : "Brown",
        "indices" : [ 8, 14 ],
        "id_str" : "3794211",
        "id" : 3794211
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "348614781705535488",
    "in_reply_to_user_id" : 2185,
    "text" : "@buster @brown",
    "id" : 348614781705535488,
    "created_at" : "Sun Jun 23 01:33:35 +0000 2013",
    "in_reply_to_screen_name" : "buster",
    "in_reply_to_user_id_str" : "2185",
    "user" : {
      "name" : "James",
      "screen_name" : "Weziington",
      "protected" : false,
      "id_str" : "1330444050",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000120335781/fb4c7bf8860fa6104b3f900d93a3ee2f_normal.jpeg",
      "id" : 1330444050,
      "verified" : false
    }
  },
  "id" : 348618874373144576,
  "created_at" : "Sun Jun 23 01:49:51 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 45 ],
      "url" : "http://t.co/I9M9cRyAlG",
      "expanded_url" : "http://flic.kr/p/eT5NaF",
      "display_url" : "flic.kr/p/eT5NaF"
    } ]
  },
  "geo" : {
  },
  "id_str" : "348605234894995456",
  "text" : "Getting some park time http://t.co/I9M9cRyAlG",
  "id" : 348605234894995456,
  "created_at" : "Sun Jun 23 00:55:39 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nir Eyal",
      "screen_name" : "nireyal",
      "indices" : [ 0, 8 ],
      "id_str" : "14097392",
      "id" : 14097392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "348535163258564608",
  "geo" : {
  },
  "id_str" : "348541686126882818",
  "in_reply_to_user_id" : 14097392,
  "text" : "@nireyal You can also do without knowing. Do bees know how to make hives? Do successful people know how they got there?",
  "id" : 348541686126882818,
  "in_reply_to_status_id" : 348535163258564608,
  "created_at" : "Sat Jun 22 20:43:08 +0000 2013",
  "in_reply_to_screen_name" : "nireyal",
  "in_reply_to_user_id_str" : "14097392",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://vine.co\" rel=\"nofollow\">Vine - Make a Scene</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 61 ],
      "url" : "https://t.co/PYZfa91Qxw",
      "expanded_url" : "https://vine.co/v/hutQWO9tdha",
      "display_url" : "vine.co/v/hutQWO9tdha"
    } ]
  },
  "geo" : {
  },
  "id_str" : "348507671432937473",
  "text" : "\"Hello, Summer! Welcome to Berkeley!\" https://t.co/PYZfa91Qxw",
  "id" : 348507671432937473,
  "created_at" : "Sat Jun 22 18:27:58 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cameron Walters",
      "screen_name" : "ceedub",
      "indices" : [ 0, 7 ],
      "id_str" : "3922",
      "id" : 3922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "348490283127828480",
  "geo" : {
  },
  "id_str" : "348492888608477185",
  "in_reply_to_user_id" : 3922,
  "text" : "@ceedub Yes!",
  "id" : 348492888608477185,
  "in_reply_to_status_id" : 348490283127828480,
  "created_at" : "Sat Jun 22 17:29:13 +0000 2013",
  "in_reply_to_screen_name" : "ceedub",
  "in_reply_to_user_id_str" : "3922",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cameron Walters",
      "screen_name" : "ceedub",
      "indices" : [ 0, 7 ],
      "id_str" : "3922",
      "id" : 3922
    }, {
      "name" : "Domainr",
      "screen_name" : "domainr",
      "indices" : [ 29, 37 ],
      "id_str" : "16499647",
      "id" : 16499647
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 64 ],
      "url" : "http://t.co/99FY1SLX4C",
      "expanded_url" : "http://iwantmyname.com",
      "display_url" : "iwantmyname.com"
    } ]
  },
  "in_reply_to_status_id_str" : "348485949472256001",
  "geo" : {
  },
  "id_str" : "348489854658691072",
  "in_reply_to_user_id" : 3922,
  "text" : "@ceedub I basically use both @domainr and http://t.co/99FY1SLX4C to find the full set of domains associated with a word. Add more TLDs?",
  "id" : 348489854658691072,
  "in_reply_to_status_id" : 348485949472256001,
  "created_at" : "Sat Jun 22 17:17:10 +0000 2013",
  "in_reply_to_screen_name" : "ceedub",
  "in_reply_to_user_id_str" : "3922",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Monteiro",
      "screen_name" : "Mike_FTW",
      "indices" : [ 110, 119 ],
      "id_str" : "2426",
      "id" : 2426
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http://t.co/uOcnA6khuW",
      "expanded_url" : "http://the-pastry-box-project.net/mike-monteiro/2013-june-22/",
      "display_url" : "the-pastry-box-project.net/mike-monteiro/\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "348489005823836161",
  "text" : "Good advice for any project: \"I can fuck up, but only if I hang around to fix it.\" http://t.co/uOcnA6khuW /by @Mike_FTW",
  "id" : 348489005823836161,
  "created_at" : "Sat Jun 22 17:13:48 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 56, 66 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http://t.co/OprLz5H16q",
      "expanded_url" : "http://flic.kr/p/eSsz8V",
      "display_url" : "flic.kr/p/eSsz8V"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859627, -122.275362 ]
  },
  "id_str" : "348284696658063361",
  "text" : "8:36pm Negotiating dessert and bedtime strategies while @kellianne gets her brother at the airport http://t.co/OprLz5H16q",
  "id" : 348284696658063361,
  "created_at" : "Sat Jun 22 03:41:57 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jane McGonigal",
      "screen_name" : "avantgame",
      "indices" : [ 0, 10 ],
      "id_str" : "681813",
      "id" : 681813
    }, {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 11, 20 ],
      "id_str" : "21135674",
      "id" : 21135674
    }, {
      "name" : "Gary Wolf",
      "screen_name" : "agaricus",
      "indices" : [ 21, 30 ],
      "id_str" : "21678279",
      "id" : 21678279
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "348268410423111680",
  "geo" : {
  },
  "id_str" : "348274728148008960",
  "in_reply_to_user_id" : 681813,
  "text" : "@avantgame @eramirez @agaricus Yes! Pick a date you busy people and I will *be there*.",
  "id" : 348274728148008960,
  "in_reply_to_status_id" : 348268410423111680,
  "created_at" : "Sat Jun 22 03:02:20 +0000 2013",
  "in_reply_to_screen_name" : "avantgame",
  "in_reply_to_user_id_str" : "681813",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Harrison",
      "screen_name" : "sourjayne",
      "indices" : [ 3, 13 ],
      "id_str" : "4981271",
      "id" : 4981271
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "348260111380250624",
  "text" : "RT @sourjayne: The wind of SF would tweet in all caps.",
  "retweeted_status" : {
    "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "348259055183228928",
    "text" : "The wind of SF would tweet in all caps.",
    "id" : 348259055183228928,
    "created_at" : "Sat Jun 22 02:00:03 +0000 2013",
    "user" : {
      "name" : "Sarah Harrison",
      "screen_name" : "sourjayne",
      "protected" : false,
      "id_str" : "4981271",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3675140549/7b33e591a9e57ffb918cc08e97989374_normal.jpeg",
      "id" : 4981271,
      "verified" : false
    }
  },
  "id" : 348260111380250624,
  "created_at" : "Sat Jun 22 02:04:15 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Brewer",
      "screen_name" : "jbrewer",
      "indices" : [ 0, 8 ],
      "id_str" : "12555",
      "id" : 12555
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "348176744064376832",
  "geo" : {
  },
  "id_str" : "348258864069750784",
  "in_reply_to_user_id" : 12555,
  "text" : "@jbrewer Your influence will last here a long time. Have a great next adventure!",
  "id" : 348258864069750784,
  "in_reply_to_status_id" : 348176744064376832,
  "created_at" : "Sat Jun 22 01:59:18 +0000 2013",
  "in_reply_to_screen_name" : "jbrewer",
  "in_reply_to_user_id_str" : "12555",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lawrence T. Bird",
      "screen_name" : "twentitled",
      "indices" : [ 4, 15 ],
      "id_str" : "608686319",
      "id" : 608686319
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ff",
      "indices" : [ 0, 3 ]
    }, {
      "text" : "jointheflock",
      "indices" : [ 16, 29 ]
    }, {
      "text" : "seriously",
      "indices" : [ 30, 40 ]
    }, {
      "text" : "hashtag",
      "indices" : [ 41, 49 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "348246911553241090",
  "text" : "#ff @twentitled #jointheflock #seriously #hashtag",
  "id" : 348246911553241090,
  "created_at" : "Sat Jun 22 01:11:48 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "caitie giauque",
      "screen_name" : "giauquebox",
      "indices" : [ 0, 11 ],
      "id_str" : "29508795",
      "id" : 29508795
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "348238191108710400",
  "geo" : {
  },
  "id_str" : "348242278109806592",
  "in_reply_to_user_id" : 29508795,
  "text" : "@giauquebox Wow, thank YOU for making it worth building! And congrats!",
  "id" : 348242278109806592,
  "in_reply_to_status_id" : 348238191108710400,
  "created_at" : "Sat Jun 22 00:53:23 +0000 2013",
  "in_reply_to_screen_name" : "giauquebox",
  "in_reply_to_user_id_str" : "29508795",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Faisal Misle",
      "screen_name" : "fmisle",
      "indices" : [ 0, 7 ],
      "id_str" : "28609326",
      "id" : 28609326
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "348221226231136257",
  "geo" : {
  },
  "id_str" : "348221371094007812",
  "in_reply_to_user_id" : 28609326,
  "text" : "@fmisle Either\u2026 buster@twitter.com",
  "id" : 348221371094007812,
  "in_reply_to_status_id" : 348221226231136257,
  "created_at" : "Fri Jun 21 23:30:19 +0000 2013",
  "in_reply_to_screen_name" : "fmisle",
  "in_reply_to_user_id_str" : "28609326",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Blue",
      "screen_name" : "ericblue",
      "indices" : [ 0, 9 ],
      "id_str" : "15436941",
      "id" : 15436941
    }, {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 10, 19 ],
      "id_str" : "21135674",
      "id" : 21135674
    }, {
      "name" : "Basis",
      "screen_name" : "mybasis",
      "indices" : [ 20, 28 ],
      "id_str" : "216453702",
      "id" : 216453702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "348220977496342529",
  "geo" : {
  },
  "id_str" : "348221144920358912",
  "in_reply_to_user_id" : 15436941,
  "text" : "@ericblue @eramirez @mybasis It takes about 5 aeons on average. I think they just made another batch though...",
  "id" : 348221144920358912,
  "in_reply_to_status_id" : 348220977496342529,
  "created_at" : "Fri Jun 21 23:29:25 +0000 2013",
  "in_reply_to_screen_name" : "ericblue",
  "in_reply_to_user_id_str" : "15436941",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Faisal Misle",
      "screen_name" : "fmisle",
      "indices" : [ 0, 7 ],
      "id_str" : "28609326",
      "id" : 28609326
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "348220779290296323",
  "geo" : {
  },
  "id_str" : "348220886324752384",
  "in_reply_to_user_id" : 28609326,
  "text" : "@fmisle Send me a screenshot or a specific tweet and I'll look into it.",
  "id" : 348220886324752384,
  "in_reply_to_status_id" : 348220779290296323,
  "created_at" : "Fri Jun 21 23:28:23 +0000 2013",
  "in_reply_to_screen_name" : "fmisle",
  "in_reply_to_user_id_str" : "28609326",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Mathes",
      "screen_name" : "adammathes",
      "indices" : [ 0, 11 ],
      "id_str" : "7337442",
      "id" : 7337442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "348215331006844928",
  "geo" : {
  },
  "id_str" : "348216167409778688",
  "in_reply_to_user_id" : 7337442,
  "text" : "@adammathes True. Every company is always course correcting in real time. This is how we do it.",
  "id" : 348216167409778688,
  "in_reply_to_status_id" : 348215331006844928,
  "created_at" : "Fri Jun 21 23:09:38 +0000 2013",
  "in_reply_to_screen_name" : "adammathes",
  "in_reply_to_user_id_str" : "7337442",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "348214269675962370",
  "geo" : {
  },
  "id_str" : "348215116686299136",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez Yes! When's the next behavior change kvetch session?",
  "id" : 348215116686299136,
  "in_reply_to_status_id" : 348214269675962370,
  "created_at" : "Fri Jun 21 23:05:28 +0000 2013",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "348213172089524224",
  "geo" : {
  },
  "id_str" : "348214118345486336",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez Excellent. That was my goal.",
  "id" : 348214118345486336,
  "in_reply_to_status_id" : 348213172089524224,
  "created_at" : "Fri Jun 21 23:01:29 +0000 2013",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "348211825340465152",
  "geo" : {
  },
  "id_str" : "348212785039159296",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez I have no idea really. But considering how sparse \"what it's like to work here\" data is, every little bit has a big impact.",
  "id" : 348212785039159296,
  "in_reply_to_status_id" : 348211825340465152,
  "created_at" : "Fri Jun 21 22:56:12 +0000 2013",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Mathes",
      "screen_name" : "adammathes",
      "indices" : [ 0, 11 ],
      "id_str" : "7337442",
      "id" : 7337442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "348209975581097985",
  "geo" : {
  },
  "id_str" : "348210756719869952",
  "in_reply_to_user_id" : 7337442,
  "text" : "@adammathes Yeah. But the account *is* by my coworker, and we think it's funny. There are *so many* internal parody accounts.",
  "id" : 348210756719869952,
  "in_reply_to_status_id" : 348209975581097985,
  "created_at" : "Fri Jun 21 22:48:08 +0000 2013",
  "in_reply_to_screen_name" : "adammathes",
  "in_reply_to_user_id_str" : "7337442",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 68 ],
      "url" : "http://t.co/XgwiN2WNbJ",
      "expanded_url" : "http://wayoftheduck.com/jointheflock",
      "display_url" : "wayoftheduck.com/jointheflock"
    } ]
  },
  "geo" : {
  },
  "id_str" : "348207018026352640",
  "text" : "I've gotten 21 resumes so far from this post: http://t.co/XgwiN2WNbJ",
  "id" : 348207018026352640,
  "created_at" : "Fri Jun 21 22:33:17 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Mathes",
      "screen_name" : "adammathes",
      "indices" : [ 0, 11 ],
      "id_str" : "7337442",
      "id" : 7337442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "348199524889665538",
  "geo" : {
  },
  "id_str" : "348206043823738880",
  "in_reply_to_user_id" : 7337442,
  "text" : "@adammathes It may not be obvious from the outside, but that is 100% a parody account.",
  "id" : 348206043823738880,
  "in_reply_to_status_id" : 348199524889665538,
  "created_at" : "Fri Jun 21 22:29:24 +0000 2013",
  "in_reply_to_screen_name" : "adammathes",
  "in_reply_to_user_id_str" : "7337442",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Wright",
      "screen_name" : "webwright",
      "indices" : [ 0, 10 ],
      "id_str" : "786818",
      "id" : 786818
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "348170741654618112",
  "geo" : {
  },
  "id_str" : "348184112063987712",
  "in_reply_to_user_id" : 786818,
  "text" : "@webwright Someone will. Or talking to ourselves will become more culturally acceptable (just like it did with cell phones).",
  "id" : 348184112063987712,
  "in_reply_to_status_id" : 348170741654618112,
  "created_at" : "Fri Jun 21 21:02:15 +0000 2013",
  "in_reply_to_screen_name" : "webwright",
  "in_reply_to_user_id_str" : "786818",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "348168298581606401",
  "text" : "Would you wear Google Glass if it was free and inconspicuous? Because one of its descendants in the not-too-distant future will be.",
  "id" : 348168298581606401,
  "created_at" : "Fri Jun 21 19:59:25 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "George Wenzel",
      "screen_name" : "georgewenzel",
      "indices" : [ 0, 13 ],
      "id_str" : "14753638",
      "id" : 14753638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "348046135807586305",
  "geo" : {
  },
  "id_str" : "348112877082771456",
  "in_reply_to_user_id" : 14753638,
  "text" : "@georgewenzel Definitely. The rate limit was lifted as soon as we detected it, but we should find ways to detect these more quickly.",
  "id" : 348112877082771456,
  "in_reply_to_status_id" : 348046135807586305,
  "created_at" : "Fri Jun 21 16:19:12 +0000 2013",
  "in_reply_to_screen_name" : "georgewenzel",
  "in_reply_to_user_id_str" : "14753638",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 55 ],
      "url" : "http://t.co/MbvFmLvV6a",
      "expanded_url" : "http://flic.kr/p/eS1x3E",
      "display_url" : "flic.kr/p/eS1x3E"
    } ]
  },
  "geo" : {
  },
  "id_str" : "347921989589151744",
  "text" : "8:36pm Niko eats dessert edition http://t.co/MbvFmLvV6a",
  "id" : 347921989589151744,
  "created_at" : "Fri Jun 21 03:40:41 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thor Muller",
      "screen_name" : "tempo",
      "indices" : [ 3, 9 ],
      "id_str" : "5814",
      "id" : 5814
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "347896203133980673",
  "text" : "RT @tempo: \"It is hard to explain to data driven people that risk is in the future, not in the past.\" -Nassim Taleb",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "347887784582852609",
    "text" : "\"It is hard to explain to data driven people that risk is in the future, not in the past.\" -Nassim Taleb",
    "id" : 347887784582852609,
    "created_at" : "Fri Jun 21 01:24:45 +0000 2013",
    "user" : {
      "name" : "Thor Muller",
      "screen_name" : "tempo",
      "protected" : false,
      "id_str" : "5814",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1809986362/265877_10150230867513403_512098402_7439693_1811499_o_normal.jpg",
      "id" : 5814,
      "verified" : false
    }
  },
  "id" : 347896203133980673,
  "created_at" : "Fri Jun 21 01:58:13 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Pell",
      "screen_name" : "davepell",
      "indices" : [ 3, 12 ],
      "id_str" : "224",
      "id" : 224
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "347895023909609473",
  "text" : "RT @davepell: The more i read about privacy invasion, the more i see people excited about new ways to voluntarily share everything they do.",
  "retweeted_status" : {
    "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "347863579258667008",
    "text" : "The more i read about privacy invasion, the more i see people excited about new ways to voluntarily share everything they do.",
    "id" : 347863579258667008,
    "created_at" : "Thu Jun 20 23:48:34 +0000 2013",
    "user" : {
      "name" : "Dave Pell",
      "screen_name" : "davepell",
      "protected" : false,
      "id_str" : "224",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1131225374/twTitle-1_normal.jpg",
      "id" : 224,
      "verified" : false
    }
  },
  "id" : 347895023909609473,
  "created_at" : "Fri Jun 21 01:53:31 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joyce Carol Oates",
      "screen_name" : "JoyceCarolOates",
      "indices" : [ 30, 46 ],
      "id_str" : "845743333",
      "id" : 845743333
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hackweek",
      "indices" : [ 8, 17 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "347893087764365312",
  "geo" : {
  },
  "id_str" : "347894745831456769",
  "in_reply_to_user_id" : 845743333,
  "text" : "My next #hackweek project: RT @JoyceCarolOates: Twitter will finally implode when tweets begin to repeat without human agency.",
  "id" : 347894745831456769,
  "in_reply_to_status_id" : 347893087764365312,
  "created_at" : "Fri Jun 21 01:52:25 +0000 2013",
  "in_reply_to_screen_name" : "JoyceCarolOates",
  "in_reply_to_user_id_str" : "845743333",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Torrez",
      "screen_name" : "torrez",
      "indices" : [ 0, 7 ],
      "id_str" : "11604",
      "id" : 11604
    }, {
      "name" : "Ian Padgham",
      "screen_name" : "origiful",
      "indices" : [ 44, 53 ],
      "id_str" : "15603374",
      "id" : 15603374
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http://t.co/9tfisNDGCe",
      "expanded_url" : "http://origiful.com/vine/",
      "display_url" : "origiful.com/vine/"
    } ]
  },
  "in_reply_to_status_id_str" : "347820464569196544",
  "geo" : {
  },
  "id_str" : "347827101342253057",
  "in_reply_to_user_id" : 11604,
  "text" : "@torrez Thanks! You should check out all of @origiful's Vines if you haven't already: http://t.co/9tfisNDGCe",
  "id" : 347827101342253057,
  "in_reply_to_status_id" : 347820464569196544,
  "created_at" : "Thu Jun 20 21:23:37 +0000 2013",
  "in_reply_to_screen_name" : "torrez",
  "in_reply_to_user_id_str" : "11604",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Ward",
      "screen_name" : "benward",
      "indices" : [ 0, 8 ],
      "id_str" : "12249",
      "id" : 12249
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "347806829746720769",
  "geo" : {
  },
  "id_str" : "347824538035290112",
  "in_reply_to_user_id" : 12249,
  "text" : "@BenWard Also good as long as there aren't any abuses of power. Competition prevents stagnation / spurs evolution, and is good for users.",
  "id" : 347824538035290112,
  "in_reply_to_status_id" : 347806829746720769,
  "created_at" : "Thu Jun 20 21:13:26 +0000 2013",
  "in_reply_to_screen_name" : "benward",
  "in_reply_to_user_id_str" : "12249",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Frank Jania",
      "screen_name" : "fjania",
      "indices" : [ 14, 21 ],
      "id_str" : "797383",
      "id" : 797383
    }, {
      "name" : "Buster",
      "screen_name" : "buster",
      "indices" : [ 23, 30 ],
      "id_str" : "2185",
      "id" : 2185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "347806516142817280",
  "text" : "You're on. RT @fjania: @buster I'm probably better at friendly competition than you.",
  "id" : 347806516142817280,
  "created_at" : "Thu Jun 20 20:01:50 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Sarver",
      "screen_name" : "rsarver",
      "indices" : [ 0, 8 ],
      "id_str" : "795649",
      "id" : 795649
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "347805409488285696",
  "geo" : {
  },
  "id_str" : "347806444080472065",
  "in_reply_to_user_id" : 795649,
  "text" : "@rsarver Ha, yeah. Scoffing at the competition is often an early sign of defeat.",
  "id" : 347806444080472065,
  "in_reply_to_status_id" : 347805409488285696,
  "created_at" : "Thu Jun 20 20:01:32 +0000 2013",
  "in_reply_to_screen_name" : "rsarver",
  "in_reply_to_user_id_str" : "795649",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "347805294950232064",
  "text" : "Friendly competition is a good thing.",
  "id" : 347805294950232064,
  "created_at" : "Thu Jun 20 19:56:58 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shrutarshi Basu",
      "screen_name" : "basus",
      "indices" : [ 0, 6 ],
      "id_str" : "9469312",
      "id" : 9469312
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "347788643764682752",
  "geo" : {
  },
  "id_str" : "347788843350634496",
  "in_reply_to_user_id" : 9469312,
  "text" : "@basus I have a cron every 10 minutes that checks my Gmail stats via their IMAP API, and stores them.",
  "id" : 347788843350634496,
  "in_reply_to_status_id" : 347788643764682752,
  "created_at" : "Thu Jun 20 18:51:36 +0000 2013",
  "in_reply_to_screen_name" : "basus",
  "in_reply_to_user_id_str" : "9469312",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rob Sheppard",
      "screen_name" : "RobSheppard",
      "indices" : [ 0, 12 ],
      "id_str" : "8217542",
      "id" : 8217542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "347759430324080642",
  "geo" : {
  },
  "id_str" : "347772403264397312",
  "in_reply_to_user_id" : 8217542,
  "text" : "@RobSheppard Oh yeah. Super important, and something we can all continue to get better at.",
  "id" : 347772403264397312,
  "in_reply_to_status_id" : 347759430324080642,
  "created_at" : "Thu Jun 20 17:46:16 +0000 2013",
  "in_reply_to_screen_name" : "RobSheppard",
  "in_reply_to_user_id_str" : "8217542",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rob Sheppard",
      "screen_name" : "RobSheppard",
      "indices" : [ 0, 12 ],
      "id_str" : "8217542",
      "id" : 8217542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "347757087750766592",
  "geo" : {
  },
  "id_str" : "347757725570174976",
  "in_reply_to_user_id" : 8217542,
  "text" : "@RobSheppard What in particular at Microsoft?",
  "id" : 347757725570174976,
  "in_reply_to_status_id" : 347757087750766592,
  "created_at" : "Thu Jun 20 16:47:57 +0000 2013",
  "in_reply_to_screen_name" : "RobSheppard",
  "in_reply_to_user_id_str" : "8217542",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rob Sheppard",
      "screen_name" : "RobSheppard",
      "indices" : [ 0, 12 ],
      "id_str" : "8217542",
      "id" : 8217542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "347749900353667073",
  "geo" : {
  },
  "id_str" : "347750982748348417",
  "in_reply_to_user_id" : 8217542,
  "text" : "@RobSheppard Yeah it's still evolving. In meantime, if you get there and aren't building a Twitter clone let me know.",
  "id" : 347750982748348417,
  "in_reply_to_status_id" : 347749900353667073,
  "created_at" : "Thu Jun 20 16:21:09 +0000 2013",
  "in_reply_to_screen_name" : "RobSheppard",
  "in_reply_to_user_id_str" : "8217542",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Washington",
      "screen_name" : "jaywashradio",
      "indices" : [ 0, 13 ],
      "id_str" : "48884463",
      "id" : 48884463
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "347749286802497536",
  "geo" : {
  },
  "id_str" : "347749869554905088",
  "in_reply_to_user_id" : 48884463,
  "text" : "@jaywashradio Oh come on, you *trounce* me in coolness.",
  "id" : 347749869554905088,
  "in_reply_to_status_id" : 347749286802497536,
  "created_at" : "Thu Jun 20 16:16:44 +0000 2013",
  "in_reply_to_screen_name" : "jaywashradio",
  "in_reply_to_user_id_str" : "48884463",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rushir Parikh ",
      "screen_name" : "rushikh",
      "indices" : [ 0, 8 ],
      "id_str" : "135681437",
      "id" : 135681437
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "347739899090333698",
  "geo" : {
  },
  "id_str" : "347746115854155776",
  "in_reply_to_user_id" : 135681437,
  "text" : "@rushikh Anyone can DM me, it's magic.",
  "id" : 347746115854155776,
  "in_reply_to_status_id" : 347739899090333698,
  "created_at" : "Thu Jun 20 16:01:49 +0000 2013",
  "in_reply_to_screen_name" : "rushikh",
  "in_reply_to_user_id_str" : "135681437",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hector Rosales",
      "screen_name" : "rosaleshv",
      "indices" : [ 0, 10 ],
      "id_str" : "58605154",
      "id" : 58605154
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "347745014136336384",
  "geo" : {
  },
  "id_str" : "347745915647426560",
  "in_reply_to_user_id" : 58605154,
  "text" : "@rosaleshv If you wanna come by the SF office one of these days I'd be happy to give you a quick tour.",
  "id" : 347745915647426560,
  "in_reply_to_status_id" : 347745014136336384,
  "created_at" : "Thu Jun 20 16:01:01 +0000 2013",
  "in_reply_to_screen_name" : "rosaleshv",
  "in_reply_to_user_id_str" : "58605154",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "maggim",
      "screen_name" : "maggim",
      "indices" : [ 0, 7 ],
      "id_str" : "14290242",
      "id" : 14290242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "347744882787483649",
  "geo" : {
  },
  "id_str" : "347745500805607425",
  "in_reply_to_user_id" : 14290242,
  "text" : "@maggim I can imagine!",
  "id" : 347745500805607425,
  "in_reply_to_status_id" : 347744882787483649,
  "created_at" : "Thu Jun 20 15:59:22 +0000 2013",
  "in_reply_to_screen_name" : "maggim",
  "in_reply_to_user_id_str" : "14290242",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "maggim",
      "screen_name" : "maggim",
      "indices" : [ 0, 7 ],
      "id_str" : "14290242",
      "id" : 14290242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "347740561307992064",
  "geo" : {
  },
  "id_str" : "347744255395102720",
  "in_reply_to_user_id" : 14290242,
  "text" : "@maggim Haha, thank you for the kind words! Hey I heard you sold your house! Congrats!",
  "id" : 347744255395102720,
  "in_reply_to_status_id" : 347740561307992064,
  "created_at" : "Thu Jun 20 15:54:25 +0000 2013",
  "in_reply_to_screen_name" : "maggim",
  "in_reply_to_user_id_str" : "14290242",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emile v.d.Coevering",
      "screen_name" : "Escapation",
      "indices" : [ 0, 11 ],
      "id_str" : "6615042",
      "id" : 6615042
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 40 ],
      "url" : "http://t.co/yfx322XKpl",
      "expanded_url" : "http://twitter.com/jobs/positions",
      "display_url" : "twitter.com/jobs/positions"
    } ]
  },
  "in_reply_to_status_id_str" : "347740465761767424",
  "geo" : {
  },
  "id_str" : "347743395390816258",
  "in_reply_to_user_id" : 6615042,
  "text" : "@Escapation Check http://t.co/yfx322XKpl and let me know if you have questions about any of them.",
  "id" : 347743395390816258,
  "in_reply_to_status_id" : 347740465761767424,
  "created_at" : "Thu Jun 20 15:51:00 +0000 2013",
  "in_reply_to_screen_name" : "Escapation",
  "in_reply_to_user_id_str" : "6615042",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emile v.d.Coevering",
      "screen_name" : "Escapation",
      "indices" : [ 0, 11 ],
      "id_str" : "6615042",
      "id" : 6615042
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "347740223762993152",
  "geo" : {
  },
  "id_str" : "347743059573878784",
  "in_reply_to_user_id" : 6615042,
  "text" : "@Escapation I call it practicing what I preach. :)",
  "id" : 347743059573878784,
  "in_reply_to_status_id" : 347740223762993152,
  "created_at" : "Thu Jun 20 15:49:40 +0000 2013",
  "in_reply_to_screen_name" : "Escapation",
  "in_reply_to_user_id_str" : "6615042",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hector Rosales",
      "screen_name" : "rosaleshv",
      "indices" : [ 0, 10 ],
      "id_str" : "58605154",
      "id" : 58605154
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "347739016499712001",
  "geo" : {
  },
  "id_str" : "347742827373010944",
  "in_reply_to_user_id" : 58605154,
  "text" : "@rosaleshv It's great! Keep trying! Let me know if I can help! What do you want to do?",
  "id" : 347742827373010944,
  "in_reply_to_status_id" : 347739016499712001,
  "created_at" : "Thu Jun 20 15:48:45 +0000 2013",
  "in_reply_to_screen_name" : "rosaleshv",
  "in_reply_to_user_id_str" : "58605154",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emile v.d.Coevering",
      "screen_name" : "Escapation",
      "indices" : [ 0, 11 ],
      "id_str" : "6615042",
      "id" : 6615042
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "347737999074807808",
  "geo" : {
  },
  "id_str" : "347738979489169409",
  "in_reply_to_user_id" : 6615042,
  "text" : "@Escapation We're somewhat segregated by floor but lots of teams (mine included) are cross-functional and sit together.",
  "id" : 347738979489169409,
  "in_reply_to_status_id" : 347737999074807808,
  "created_at" : "Thu Jun 20 15:33:28 +0000 2013",
  "in_reply_to_screen_name" : "Escapation",
  "in_reply_to_user_id_str" : "6615042",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jm3 / John Manoogian",
      "screen_name" : "jm3",
      "indices" : [ 0, 4 ],
      "id_str" : "59593",
      "id" : 59593
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "347736919582593024",
  "geo" : {
  },
  "id_str" : "347737556147900417",
  "in_reply_to_user_id" : 59593,
  "text" : "@jm3 Hit me with some of those complex feelings! :)",
  "id" : 347737556147900417,
  "in_reply_to_status_id" : 347736919582593024,
  "created_at" : "Thu Jun 20 15:27:48 +0000 2013",
  "in_reply_to_screen_name" : "jm3",
  "in_reply_to_user_id_str" : "59593",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jointheflock",
      "indices" : [ 100, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "347737245366759426",
  "text" : "Have questions about what it's like to work at Twitter? Ask! DM me if you'd rather keep it private. #jointheflock",
  "id" : 347737245366759426,
  "created_at" : "Thu Jun 20 15:26:34 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jointheflock",
      "indices" : [ 79, 92 ]
    } ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http://t.co/XgwiN2WNbJ",
      "expanded_url" : "http://wayoftheduck.com/jointheflock",
      "display_url" : "wayoftheduck.com/jointheflock"
    } ]
  },
  "geo" : {
  },
  "id_str" : "347733338099949568",
  "text" : "Some of the people that I like working with at Twitter. http://t.co/XgwiN2WNbJ #jointheflock",
  "id" : 347733338099949568,
  "created_at" : "Thu Jun 20 15:11:03 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Morelli",
      "screen_name" : "pmorelli",
      "indices" : [ 0, 9 ],
      "id_str" : "14161459",
      "id" : 14161459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "347723998618071040",
  "geo" : {
  },
  "id_str" : "347725238253006849",
  "in_reply_to_user_id" : 14161459,
  "text" : "@pmorelli That's my hope. Maybe I'm being overly optimistic, but seems like a lot to pay for something you want to kill.",
  "id" : 347725238253006849,
  "in_reply_to_status_id" : 347723998618071040,
  "created_at" : "Thu Jun 20 14:38:51 +0000 2013",
  "in_reply_to_screen_name" : "pmorelli",
  "in_reply_to_user_id_str" : "14161459",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Frank Chimero",
      "screen_name" : "fchimero",
      "indices" : [ 3, 12 ],
      "id_str" : "13212522",
      "id" : 13212522
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http://t.co/HQPvdvwB2Q",
      "expanded_url" : "http://www.mcsweeneys.net/articles/an-imagined-conversation-between-the-construction-workers-upstairs-from-me",
      "display_url" : "mcsweeneys.net/articles/an-im\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "347723156540227588",
  "text" : "RT @fchimero: WORKER: It\u2019s 6:37 AM, let\u2019s begin hammering\nhttp://t.co/HQPvdvwB2Q",
  "retweeted_status" : {
    "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 44, 66 ],
        "url" : "http://t.co/HQPvdvwB2Q",
        "expanded_url" : "http://www.mcsweeneys.net/articles/an-imagined-conversation-between-the-construction-workers-upstairs-from-me",
        "display_url" : "mcsweeneys.net/articles/an-im\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "347710072962576384",
    "text" : "WORKER: It\u2019s 6:37 AM, let\u2019s begin hammering\nhttp://t.co/HQPvdvwB2Q",
    "id" : 347710072962576384,
    "created_at" : "Thu Jun 20 13:38:36 +0000 2013",
    "user" : {
      "name" : "Frank Chimero",
      "screen_name" : "fchimero",
      "protected" : false,
      "id_str" : "13212522",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3677885752/0920901175140a207fc049b922de87a0_normal.jpeg",
      "id" : 13212522,
      "verified" : false
    }
  },
  "id" : 347723156540227588,
  "created_at" : "Thu Jun 20 14:30:35 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ReadWrite",
      "screen_name" : "RWW",
      "indices" : [ 28, 32 ],
      "id_str" : "4641021",
      "id" : 4641021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http://t.co/d4dR2gNO34",
      "expanded_url" : "http://readwr.it/h6T",
      "display_url" : "readwr.it/h6T"
    } ]
  },
  "in_reply_to_status_id_str" : "347709598242844673",
  "geo" : {
  },
  "id_str" : "347722624580861952",
  "in_reply_to_user_id" : 4641021,
  "text" : "Go, Bre! Go 3D printing! RT @RWW: MakerBot Merger Will Boost Desktop 3D Printing http://t.co/d4dR2gNO34",
  "id" : 347722624580861952,
  "in_reply_to_status_id" : 347709598242844673,
  "created_at" : "Thu Jun 20 14:28:28 +0000 2013",
  "in_reply_to_screen_name" : "RWW",
  "in_reply_to_user_id_str" : "4641021",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "And\u01DDrs Kh\u0250n Bol\u0131n",
      "screen_name" : "strayl1ght",
      "indices" : [ 0, 11 ],
      "id_str" : "6820962",
      "id" : 6820962
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "347628032716075010",
  "geo" : {
  },
  "id_str" : "347720055833903107",
  "in_reply_to_user_id" : 6820962,
  "text" : "@strayl1ght Doesn't hurt to try! We have a good number of remote employees!",
  "id" : 347720055833903107,
  "in_reply_to_status_id" : 347628032716075010,
  "created_at" : "Thu Jun 20 14:18:16 +0000 2013",
  "in_reply_to_screen_name" : "strayl1ght",
  "in_reply_to_user_id_str" : "6820962",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kimmy",
      "screen_name" : "aRealLiveGhost",
      "indices" : [ 3, 18 ],
      "id_str" : "407895022",
      "id" : 407895022
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "347624480589361152",
  "text" : "RT @aRealLiveGhost: give a man a fish and he will keep and nurture the fish and hold a funeral when it dies. teach a man to fish and he wil\u2026",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "347619980902293504",
    "text" : "give a man a fish and he will keep and nurture the fish and hold a funeral when it dies. teach a man to fish and he will kill and eat a fish",
    "id" : 347619980902293504,
    "created_at" : "Thu Jun 20 07:40:36 +0000 2013",
    "user" : {
      "name" : "kimmy",
      "screen_name" : "aRealLiveGhost",
      "protected" : false,
      "id_str" : "407895022",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3250411496/d47676f00e47f8100b890ad0fc249faf_normal.jpeg",
      "id" : 407895022,
      "verified" : false
    }
  },
  "id" : 347624480589361152,
  "created_at" : "Thu Jun 20 07:58:29 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luke Millar",
      "screen_name" : "ltm",
      "indices" : [ 0, 4 ],
      "id_str" : "14616067",
      "id" : 14616067
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "347615790234742784",
  "geo" : {
  },
  "id_str" : "347620289988923392",
  "in_reply_to_user_id" : 14616067,
  "text" : "@ltm You should do a list of your favorite tweeps too. :) I still need to meet you for real of these days. I've seen you demo.",
  "id" : 347620289988923392,
  "in_reply_to_status_id" : 347615790234742784,
  "created_at" : "Thu Jun 20 07:41:50 +0000 2013",
  "in_reply_to_screen_name" : "ltm",
  "in_reply_to_user_id_str" : "14616067",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Bonner",
      "screen_name" : "seanbonner",
      "indices" : [ 0, 11 ],
      "id_str" : "765",
      "id" : 765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "347612303539179522",
  "geo" : {
  },
  "id_str" : "347612592564477952",
  "in_reply_to_user_id" : 765,
  "text" : "@seanbonner Yeah, it's sort of ridiculous.",
  "id" : 347612592564477952,
  "in_reply_to_status_id" : 347612303539179522,
  "created_at" : "Thu Jun 20 07:11:15 +0000 2013",
  "in_reply_to_screen_name" : "seanbonner",
  "in_reply_to_user_id_str" : "765",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 45 ],
      "url" : "http://t.co/nniEXHwyRq",
      "expanded_url" : "http://bit.ly/11NNalR",
      "display_url" : "bit.ly/11NNalR"
    } ]
  },
  "geo" : {
  },
  "id_str" : "347611206732877824",
  "text" : "Yeah, I just did this. http://t.co/nniEXHwyRq",
  "id" : 347611206732877824,
  "created_at" : "Thu Jun 20 07:05:44 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 66 ],
      "url" : "http://t.co/qWHXv4EMNs",
      "expanded_url" : "http://flic.kr/p/eRjH1o",
      "display_url" : "flic.kr/p/eRjH1o"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859694, -122.275437 ]
  },
  "id_str" : "347560310695141376",
  "text" : "8:36pm \"It's not time for a night nap yet.\" http://t.co/qWHXv4EMNs",
  "id" : 347560310695141376,
  "created_at" : "Thu Jun 20 03:43:30 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "347542896053977089",
  "text" : "Instagrideo. Vidstagram.",
  "id" : 347542896053977089,
  "created_at" : "Thu Jun 20 02:34:18 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Porad",
      "screen_name" : "scottporad",
      "indices" : [ 0, 11 ],
      "id_str" : "15876737",
      "id" : 15876737
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "347257078076821504",
  "geo" : {
  },
  "id_str" : "347397804991320066",
  "in_reply_to_user_id" : 15876737,
  "text" : "@scottporad Totally! I will make a point of keeping it open in a tab and checking it out more often.",
  "id" : 347397804991320066,
  "in_reply_to_status_id" : 347257078076821504,
  "created_at" : "Wed Jun 19 16:57:45 +0000 2013",
  "in_reply_to_screen_name" : "scottporad",
  "in_reply_to_user_id_str" : "15876737",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http://t.co/x64DP52wMZ",
      "expanded_url" : "http://flic.kr/p/eQsz6P",
      "display_url" : "flic.kr/p/eQsz6P"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.860236, -122.283867 ]
  },
  "id_str" : "347234764715081728",
  "text" : "8:36pm Was taking a parenting class with other parents at Niko's daycare http://t.co/x64DP52wMZ",
  "id" : 347234764715081728,
  "created_at" : "Wed Jun 19 06:09:53 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Neil deGrasse Tyson",
      "screen_name" : "neiltyson",
      "indices" : [ 72, 82 ],
      "id_str" : "19725644",
      "id" : 19725644
    }, {
      "name" : "Charlie Park",
      "screen_name" : "charliepark",
      "indices" : [ 111, 123 ],
      "id_str" : "3225381",
      "id" : 3225381
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http://t.co/Vn6z9Ou6wh",
      "expanded_url" : "http://www.youtube.com/watch?feature=player_embedded&v=5ELA3ReWQJY",
      "display_url" : "youtube.com/watch?feature=\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "347193180577476610",
  "geo" : {
  },
  "id_str" : "347210866392973312",
  "in_reply_to_user_id" : 3225381,
  "text" : "Brilliant explanation of light's (non-existent) experience of time from @neiltyson http://t.co/Vn6z9Ou6wh /via @charliepark",
  "id" : 347210866392973312,
  "in_reply_to_status_id" : 347193180577476610,
  "created_at" : "Wed Jun 19 04:34:56 +0000 2013",
  "in_reply_to_screen_name" : "charliepark",
  "in_reply_to_user_id_str" : "3225381",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ingopixel",
      "screen_name" : "ingopixel",
      "indices" : [ 0, 10 ],
      "id_str" : "7943892",
      "id" : 7943892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "347170261205929985",
  "geo" : {
  },
  "id_str" : "347207058258534406",
  "in_reply_to_user_id" : 7943892,
  "text" : "@ingopixel You win best 5-part answer series!",
  "id" : 347207058258534406,
  "in_reply_to_status_id" : 347170261205929985,
  "created_at" : "Wed Jun 19 04:19:48 +0000 2013",
  "in_reply_to_screen_name" : "ingopixel",
  "in_reply_to_user_id_str" : "7943892",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Miller",
      "screen_name" : "joshm",
      "indices" : [ 0, 6 ],
      "id_str" : "42559115",
      "id" : 42559115
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "347101416025907200",
  "geo" : {
  },
  "id_str" : "347167695566938115",
  "in_reply_to_user_id" : 42559115,
  "text" : "@joshm Are you sure Instagram beats them at sheer number of photos? Or just branding?",
  "id" : 347167695566938115,
  "in_reply_to_status_id" : 347101416025907200,
  "created_at" : "Wed Jun 19 01:43:23 +0000 2013",
  "in_reply_to_screen_name" : "joshm",
  "in_reply_to_user_id_str" : "42559115",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Stump",
      "screen_name" : "joestump",
      "indices" : [ 49, 58 ],
      "id_str" : "4234581",
      "id" : 4234581
    }, {
      "name" : "Buster",
      "screen_name" : "buster",
      "indices" : [ 60, 67 ],
      "id_str" : "2185",
      "id" : 2185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "347165441157918720",
  "geo" : {
  },
  "id_str" : "347166981021122561",
  "in_reply_to_user_id" : 4234581,
  "text" : "I think this is true... but isn't that wacky? RT @joestump: @buster Trick question. Light has no perception of time. ;)",
  "id" : 347166981021122561,
  "in_reply_to_status_id" : 347165441157918720,
  "created_at" : "Wed Jun 19 01:40:32 +0000 2013",
  "in_reply_to_screen_name" : "joestump",
  "in_reply_to_user_id_str" : "4234581",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Albert Sun",
      "screen_name" : "albertsun",
      "indices" : [ 0, 10 ],
      "id_str" : "2341001",
      "id" : 2341001
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "347165005449404417",
  "in_reply_to_user_id" : 2341001,
  "text" : "@albertsun I had to take it down unfortunately...",
  "id" : 347165005449404417,
  "created_at" : "Wed Jun 19 01:32:41 +0000 2013",
  "in_reply_to_screen_name" : "albertsun",
  "in_reply_to_user_id_str" : "2341001",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angela Pool Funai",
      "screen_name" : "angfunai",
      "indices" : [ 38, 47 ],
      "id_str" : "66774356",
      "id" : 66774356
    }, {
      "name" : "Buster",
      "screen_name" : "buster",
      "indices" : [ 49, 56 ],
      "id_str" : "2185",
      "id" : 2185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "347164031116779521",
  "geo" : {
  },
  "id_str" : "347164857411436545",
  "in_reply_to_user_id" : 66774356,
  "text" : "True, if you time it from Earth... RT @angfunai: @buster A little longer than 8 minutes, if I remember correctly.",
  "id" : 347164857411436545,
  "in_reply_to_status_id" : 347164031116779521,
  "created_at" : "Wed Jun 19 01:32:06 +0000 2013",
  "in_reply_to_screen_name" : "angfunai",
  "in_reply_to_user_id_str" : "66774356",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "347163451875000320",
  "text" : "From light's perspective, how long does it take to reach Earth from the sun?",
  "id" : 347163451875000320,
  "created_at" : "Wed Jun 19 01:26:31 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Gilman",
      "screen_name" : "jongilman",
      "indices" : [ 0, 10 ],
      "id_str" : "16908938",
      "id" : 16908938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "347150440334491648",
  "geo" : {
  },
  "id_str" : "347151123322372097",
  "in_reply_to_user_id" : 16908938,
  "text" : "@jongilman I recommend it! Definitely needs a public API so you can do more with the data it generates.",
  "id" : 347151123322372097,
  "in_reply_to_status_id" : 347150440334491648,
  "created_at" : "Wed Jun 19 00:37:32 +0000 2013",
  "in_reply_to_screen_name" : "jongilman",
  "in_reply_to_user_id_str" : "16908938",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Abe Stanway",
      "screen_name" : "abestanway",
      "indices" : [ 0, 11 ],
      "id_str" : "248507370",
      "id" : 248507370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https://t.co/g3IkMwk6sf",
      "expanded_url" : "https://github.com/btroia/basis-data-export",
      "display_url" : "github.com/btroia/basis-d\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "347089501195210752",
  "geo" : {
  },
  "id_str" : "347092938020487169",
  "in_reply_to_user_id" : 248507370,
  "text" : "@abestanway It's only accidentally exposed at the moment, but they say they plan to make it official soon: https://t.co/g3IkMwk6sf",
  "id" : 347092938020487169,
  "in_reply_to_status_id" : 347089501195210752,
  "created_at" : "Tue Jun 18 20:46:19 +0000 2013",
  "in_reply_to_screen_name" : "abestanway",
  "in_reply_to_user_id_str" : "248507370",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Abe Stanway",
      "screen_name" : "abestanway",
      "indices" : [ 0, 11 ],
      "id_str" : "248507370",
      "id" : 248507370
    }, {
      "name" : "kellan",
      "screen_name" : "kellan",
      "indices" : [ 12, 19 ],
      "id_str" : "47",
      "id" : 47
    }, {
      "name" : "Marc Hedlund",
      "screen_name" : "marcprecipice",
      "indices" : [ 20, 34 ],
      "id_str" : "226976689",
      "id" : 226976689
    }, {
      "name" : "Basis",
      "screen_name" : "mybasis",
      "indices" : [ 39, 47 ],
      "id_str" : "216453702",
      "id" : 216453702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "347080158706028545",
  "geo" : {
  },
  "id_str" : "347084890535247872",
  "in_reply_to_user_id" : 248507370,
  "text" : "@abestanway @kellan @marcprecipice The @mybasis watch has 4 streams of minute-by-minute data. I'd love to find anomalies/correlations in it.",
  "id" : 347084890535247872,
  "in_reply_to_status_id" : 347080158706028545,
  "created_at" : "Tue Jun 18 20:14:21 +0000 2013",
  "in_reply_to_screen_name" : "abestanway",
  "in_reply_to_user_id_str" : "248507370",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Basis",
      "screen_name" : "mybasis",
      "indices" : [ 0, 8 ],
      "id_str" : "216453702",
      "id" : 216453702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "347044556900007936",
  "geo" : {
  },
  "id_str" : "347044841177350144",
  "in_reply_to_user_id" : 216453702,
  "text" : "@mybasis I'm interested in finding a way to differentiate activity vs stress vs eating in the data. Is it possible? What are the patterns?",
  "id" : 347044841177350144,
  "in_reply_to_status_id" : 347044556900007936,
  "created_at" : "Tue Jun 18 17:35:12 +0000 2013",
  "in_reply_to_screen_name" : "mybasis",
  "in_reply_to_user_id_str" : "216453702",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kellan",
      "screen_name" : "kellan",
      "indices" : [ 1, 8 ],
      "id_str" : "47",
      "id" : 47
    }, {
      "name" : "Marc Hedlund",
      "screen_name" : "marcprecipice",
      "indices" : [ 9, 23 ],
      "id_str" : "226976689",
      "id" : 226976689
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "quantifiedself",
      "indices" : [ 77, 92 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "347043617308803074",
  "text" : ".@kellan @marcprecipice How difficult would it be to adapt Kale to work with #quantifiedself data? Heart rate, perspiration, steps, etc.",
  "id" : 347043617308803074,
  "created_at" : "Tue Jun 18 17:30:20 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Realtime Recs",
      "screen_name" : "MagicRecs",
      "indices" : [ 0, 10 ],
      "id_str" : "1270746139",
      "id" : 1270746139
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "askingforafriend",
      "indices" : [ 89, 106 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "347042349874032640",
  "in_reply_to_user_id" : 1270746139,
  "text" : "@magicrecs Have you ever recommended a tweet of mine? Can you tell me when that happens? #askingforafriend",
  "id" : 347042349874032640,
  "created_at" : "Tue Jun 18 17:25:18 +0000 2013",
  "in_reply_to_screen_name" : "MagicRecs",
  "in_reply_to_user_id_str" : "1270746139",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "adam bain",
      "screen_name" : "adambain",
      "indices" : [ 9, 18 ],
      "id_str" : "14253109",
      "id" : 14253109
    }, {
      "name" : "Deb Roy",
      "screen_name" : "dkroy",
      "indices" : [ 78, 84 ],
      "id_str" : "30569817",
      "id" : 30569817
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CannesLions",
      "indices" : [ 103, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http://t.co/o05BtyOkxs",
      "expanded_url" : "http://youtu.be/rKPfFWOXIh8",
      "display_url" : "youtu.be/rKPfFWOXIh8"
    } ]
  },
  "in_reply_to_status_id_str" : "347031247995936769",
  "geo" : {
  },
  "id_str" : "347036810335096832",
  "in_reply_to_user_id" : 14253109,
  "text" : "Woah. RT @adambain: Here's a sneak peek of the TVxTwitter data visualizations @dkroy will show tmrw at #CannesLions http://t.co/o05BtyOkxs",
  "id" : 347036810335096832,
  "in_reply_to_status_id" : 347031247995936769,
  "created_at" : "Tue Jun 18 17:03:17 +0000 2013",
  "in_reply_to_screen_name" : "adambain",
  "in_reply_to_user_id_str" : "14253109",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benny Wong",
      "screen_name" : "bdotdub",
      "indices" : [ 0, 8 ],
      "id_str" : "3032241",
      "id" : 3032241
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "347022978376151041",
  "geo" : {
  },
  "id_str" : "347035914310127616",
  "in_reply_to_user_id" : 3032241,
  "text" : "@bdotdub If you like data and gadgets. I don't think it will be truly awesome until they have Bluetooth and a (public) API.",
  "id" : 347035914310127616,
  "in_reply_to_status_id" : 347022978376151041,
  "created_at" : "Tue Jun 18 16:59:44 +0000 2013",
  "in_reply_to_screen_name" : "bdotdub",
  "in_reply_to_user_id_str" : "3032241",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Basis",
      "screen_name" : "mybasis",
      "indices" : [ 13, 21 ],
      "id_str" : "216453702",
      "id" : 216453702
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/buster/status/347021530351403009/photo/1",
      "indices" : [ 115, 137 ],
      "url" : "http://t.co/xOKENW4cZK",
      "media_url" : "http://pbs.twimg.com/media/BNDePkaCAAEkMMJ.png",
      "id_str" : "347021530359791617",
      "id" : 347021530359791617,
      "media_url_https" : "https://pbs.twimg.com/media/BNDePkaCAAEkMMJ.png",
      "sizes" : [ {
        "h" : 561,
        "resize" : "fit",
        "w" : 961
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 561,
        "resize" : "fit",
        "w" : 961
      }, {
        "h" : 198,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 350,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com/xOKENW4cZK"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "347021530351403009",
  "text" : "According to @mybasis data, my perspiration might be a better indicator of stress than my heart rate. Interesting. http://t.co/xOKENW4cZK",
  "id" : 347021530351403009,
  "created_at" : "Tue Jun 18 16:02:34 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bethany Clarke",
      "screen_name" : "bethanyy_clarke",
      "indices" : [ 0, 16 ],
      "id_str" : "82688809",
      "id" : 82688809
    }, {
      "name" : "Ruby Galloway",
      "screen_name" : "rubygalloway",
      "indices" : [ 17, 30 ],
      "id_str" : "54711876",
      "id" : 54711876
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "347020197724581888",
  "geo" : {
  },
  "id_str" : "347020587769671682",
  "in_reply_to_user_id" : 82688809,
  "text" : "@bethanyy_clarke @rubygalloway i'm in california, representing all busters of the world. any questions?",
  "id" : 347020587769671682,
  "in_reply_to_status_id" : 347020197724581888,
  "created_at" : "Tue Jun 18 15:58:50 +0000 2013",
  "in_reply_to_screen_name" : "bethanyy_clarke",
  "in_reply_to_user_id_str" : "82688809",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bethany Clarke",
      "screen_name" : "bethanyy_clarke",
      "indices" : [ 0, 16 ],
      "id_str" : "82688809",
      "id" : 82688809
    }, {
      "name" : "Ruby Galloway",
      "screen_name" : "rubygalloway",
      "indices" : [ 17, 30 ],
      "id_str" : "54711876",
      "id" : 54711876
    }, {
      "name" : "Keith McCullough ",
      "screen_name" : "KeithMcCullough",
      "indices" : [ 31, 47 ],
      "id_str" : "18378349",
      "id" : 18378349
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "347018790204215296",
  "geo" : {
  },
  "id_str" : "347019099806773248",
  "in_reply_to_user_id" : 82688809,
  "text" : "@bethanyy_clarke @rubygalloway @keithmccullough Yeeeessss?",
  "id" : 347019099806773248,
  "in_reply_to_status_id" : 347018790204215296,
  "created_at" : "Tue Jun 18 15:52:55 +0000 2013",
  "in_reply_to_screen_name" : "bethanyy_clarke",
  "in_reply_to_user_id_str" : "82688809",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Darya Rose",
      "screen_name" : "summertomato",
      "indices" : [ 21, 34 ],
      "id_str" : "17396212",
      "id" : 17396212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http://t.co/N4p2jagkZH",
      "expanded_url" : "http://bit.ly/12EqA5l",
      "display_url" : "bit.ly/12EqA5l"
    } ]
  },
  "in_reply_to_status_id_str" : "346690700659789824",
  "geo" : {
  },
  "id_str" : "347012121881620481",
  "in_reply_to_user_id" : 17396212,
  "text" : "I like the format RT @summertomato: 10 Reasons You Aren\u2019t Losing Weight When You Think You\u2019re Doing Everything Right http://t.co/N4p2jagkZH",
  "id" : 347012121881620481,
  "in_reply_to_status_id" : 346690700659789824,
  "created_at" : "Tue Jun 18 15:25:11 +0000 2013",
  "in_reply_to_screen_name" : "summertomato",
  "in_reply_to_user_id_str" : "17396212",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chamath Palihapitiya",
      "screen_name" : "chamath",
      "indices" : [ 3, 11 ],
      "id_str" : "3291691",
      "id" : 3291691
    }, {
      "name" : "John Borthwick",
      "screen_name" : "Borthwick",
      "indices" : [ 13, 23 ],
      "id_str" : "4488",
      "id" : 4488
    }, {
      "name" : "Jason Gelman",
      "screen_name" : "jasongelman",
      "indices" : [ 24, 36 ],
      "id_str" : "220137029",
      "id" : 220137029
    }, {
      "name" : "jason",
      "screen_name" : "Jason",
      "indices" : [ 37, 43 ],
      "id_str" : "3840",
      "id" : 3840
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "347005815657463808",
  "text" : "RT @chamath: @Borthwick @jasongelman @Jason after much study, I've determined genetics and cancer as bigger opportunities than RSS. It was \u2026",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "John Borthwick",
        "screen_name" : "Borthwick",
        "indices" : [ 0, 10 ],
        "id_str" : "4488",
        "id" : 4488
      }, {
        "name" : "Jason Gelman",
        "screen_name" : "jasongelman",
        "indices" : [ 11, 23 ],
        "id_str" : "220137029",
        "id" : 220137029
      }, {
        "name" : "jason",
        "screen_name" : "Jason",
        "indices" : [ 24, 30 ],
        "id_str" : "3840",
        "id" : 3840
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "346816606724304896",
    "geo" : {
    },
    "id_str" : "346987825662676992",
    "in_reply_to_user_id" : 4488,
    "text" : "@Borthwick @jasongelman @Jason after much study, I've determined genetics and cancer as bigger opportunities than RSS. It was close, though.",
    "id" : 346987825662676992,
    "in_reply_to_status_id" : 346816606724304896,
    "created_at" : "Tue Jun 18 13:48:39 +0000 2013",
    "in_reply_to_screen_name" : "Borthwick",
    "in_reply_to_user_id_str" : "4488",
    "user" : {
      "name" : "Chamath Palihapitiya",
      "screen_name" : "chamath",
      "protected" : false,
      "id_str" : "3291691",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3736669600/8ffd724b9104d9158f92d16d55992083_normal.jpeg",
      "id" : 3291691,
      "verified" : false
    }
  },
  "id" : 347005815657463808,
  "created_at" : "Tue Jun 18 15:00:08 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lift",
      "screen_name" : "liftapp",
      "indices" : [ 18, 26 ],
      "id_str" : "353195232",
      "id" : 353195232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http://t.co/JIQxvjYMto",
      "expanded_url" : "http://lift.do",
      "display_url" : "lift.do"
    } ]
  },
  "in_reply_to_status_id_str" : "346987939709984768",
  "geo" : {
  },
  "id_str" : "346988864059084801",
  "in_reply_to_user_id" : 353195232,
  "text" : "Looking great! RT @liftapp: Starting today, Lift is available for everyone: http://t.co/JIQxvjYMto use our new web app from any browser.",
  "id" : 346988864059084801,
  "in_reply_to_status_id" : 346987939709984768,
  "created_at" : "Tue Jun 18 13:52:46 +0000 2013",
  "in_reply_to_screen_name" : "liftapp",
  "in_reply_to_user_id_str" : "353195232",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "megan gebhart",
      "screen_name" : "megangebhart",
      "indices" : [ 21, 34 ],
      "id_str" : "32966836",
      "id" : 32966836
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http://t.co/Knn4mQVumo",
      "expanded_url" : "http://bit.ly/13Wzesj",
      "display_url" : "bit.ly/13Wzesj"
    } ]
  },
  "in_reply_to_status_id_str" : "346983120865734658",
  "geo" : {
  },
  "id_str" : "346988036694872065",
  "in_reply_to_user_id" : 32966836,
  "text" : "Great post --&gt; RT @megangebhart: This is why I write something everyday: http://t.co/Knn4mQVumo",
  "id" : 346988036694872065,
  "in_reply_to_status_id" : 346983120865734658,
  "created_at" : "Tue Jun 18 13:49:29 +0000 2013",
  "in_reply_to_screen_name" : "megangebhart",
  "in_reply_to_user_id_str" : "32966836",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 53 ],
      "url" : "http://t.co/mgH4IUANLM",
      "expanded_url" : "http://flic.kr/p/ePCkcn",
      "display_url" : "flic.kr/p/ePCkcn"
    } ]
  },
  "geo" : {
  },
  "id_str" : "346836646915878912",
  "text" : "8:36pm Dessert and dance party http://t.co/mgH4IUANLM",
  "id" : 346836646915878912,
  "created_at" : "Tue Jun 18 03:47:55 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://vine.co\" rel=\"nofollow\">Vine - Make a Scene</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 33 ],
      "url" : "https://t.co/8P8BgP0mXO",
      "expanded_url" : "https://vine.co/v/hBTgBFhlFXB",
      "display_url" : "vine.co/v/hBTgBFhlFXB"
    } ]
  },
  "geo" : {
  },
  "id_str" : "346835802522779648",
  "text" : "Mnah mnah https://t.co/8P8BgP0mXO",
  "id" : 346835802522779648,
  "created_at" : "Tue Jun 18 03:44:33 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "maggim",
      "screen_name" : "maggim",
      "indices" : [ 0, 7 ],
      "id_str" : "14290242",
      "id" : 14290242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "346816420685959168",
  "geo" : {
  },
  "id_str" : "346822309434228736",
  "in_reply_to_user_id" : 14290242,
  "text" : "@maggim Alpacas.",
  "id" : 346822309434228736,
  "in_reply_to_status_id" : 346816420685959168,
  "created_at" : "Tue Jun 18 02:50:56 +0000 2013",
  "in_reply_to_screen_name" : "maggim",
  "in_reply_to_user_id_str" : "14290242",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "346801199716114434",
  "text" : "Where do all of Einstein's quotes come from anyway?",
  "id" : 346801199716114434,
  "created_at" : "Tue Jun 18 01:27:03 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Gates",
      "screen_name" : "BillGates",
      "indices" : [ 3, 13 ],
      "id_str" : "50393960",
      "id" : 50393960
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AIDS",
      "indices" : [ 90, 95 ]
    } ],
    "urls" : [ {
      "indices" : [ 29, 51 ],
      "url" : "http://t.co/wTWMwb4wQH",
      "expanded_url" : "http://ow.ly/i/2nSpl",
      "display_url" : "ow.ly/i/2nSpl"
    } ]
  },
  "geo" : {
  },
  "id_str" : "346800067929317377",
  "text" : "RT @BillGates: Retweet this: http://t.co/wTWMwb4wQH WHY? The Global Fund gets $1 to fight #AIDS every time it gets shared.",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.hootsuite.com\" rel=\"nofollow\">HootSuite</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AIDS",
        "indices" : [ 75, 80 ]
      } ],
      "urls" : [ {
        "indices" : [ 14, 36 ],
        "url" : "http://t.co/wTWMwb4wQH",
        "expanded_url" : "http://ow.ly/i/2nSpl",
        "display_url" : "ow.ly/i/2nSpl"
      } ]
    },
    "geo" : {
    },
    "id_str" : "346788158660300800",
    "text" : "Retweet this: http://t.co/wTWMwb4wQH WHY? The Global Fund gets $1 to fight #AIDS every time it gets shared.",
    "id" : 346788158660300800,
    "created_at" : "Tue Jun 18 00:35:14 +0000 2013",
    "user" : {
      "name" : "Bill Gates",
      "screen_name" : "BillGates",
      "protected" : false,
      "id_str" : "50393960",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1884069342/BGtwitter_normal.JPG",
      "id" : 50393960,
      "verified" : true
    }
  },
  "id" : 346800067929317377,
  "created_at" : "Tue Jun 18 01:22:34 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 0, 9 ],
      "id_str" : "761628",
      "id" : 761628
    }, {
      "name" : "harryh",
      "screen_name" : "harryh",
      "indices" : [ 10, 17 ],
      "id_str" : "4558",
      "id" : 4558
    }, {
      "name" : "Bijan Sabet",
      "screen_name" : "bijan",
      "indices" : [ 18, 24 ],
      "id_str" : "3713811",
      "id" : 3713811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "346725461625290753",
  "geo" : {
  },
  "id_str" : "346726923994537984",
  "in_reply_to_user_id" : 761628,
  "text" : "@RickWebb @harryh @bijan I doubt any time in the past has allowed multi-dimensional selves more than today. We're moving in that direction.",
  "id" : 346726923994537984,
  "in_reply_to_status_id" : 346725461625290753,
  "created_at" : "Mon Jun 17 20:31:55 +0000 2013",
  "in_reply_to_screen_name" : "RickWebb",
  "in_reply_to_user_id_str" : "761628",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "harryh",
      "screen_name" : "harryh",
      "indices" : [ 0, 7 ],
      "id_str" : "4558",
      "id" : 4558
    }, {
      "name" : "Bijan Sabet",
      "screen_name" : "bijan",
      "indices" : [ 8, 14 ],
      "id_str" : "3713811",
      "id" : 3713811
    }, {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 15, 24 ],
      "id_str" : "761628",
      "id" : 761628
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "346720112038010880",
  "geo" : {
  },
  "id_str" : "346723821266550786",
  "in_reply_to_user_id" : 4558,
  "text" : "@harryh @bijan @RickWebb I think a 100% professionally curated public self is more boring than an inconsistent, partially-uncurated self.",
  "id" : 346723821266550786,
  "in_reply_to_status_id" : 346720112038010880,
  "created_at" : "Mon Jun 17 20:19:35 +0000 2013",
  "in_reply_to_screen_name" : "harryh",
  "in_reply_to_user_id_str" : "4558",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "harryh",
      "screen_name" : "harryh",
      "indices" : [ 0, 7 ],
      "id_str" : "4558",
      "id" : 4558
    }, {
      "name" : "Bijan Sabet",
      "screen_name" : "bijan",
      "indices" : [ 8, 14 ],
      "id_str" : "3713811",
      "id" : 3713811
    }, {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 15, 24 ],
      "id_str" : "761628",
      "id" : 761628
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "346720112038010880",
  "geo" : {
  },
  "id_str" : "346723370836041728",
  "in_reply_to_user_id" : 4558,
  "text" : "@harryh @bijan @RickWebb Totally. It's important to keep open some \"uncurated\" channels of ourselves (like 8:36pm), to balance things.",
  "id" : 346723370836041728,
  "in_reply_to_status_id" : 346720112038010880,
  "created_at" : "Mon Jun 17 20:17:48 +0000 2013",
  "in_reply_to_screen_name" : "harryh",
  "in_reply_to_user_id_str" : "4558",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Heitzeberg",
      "screen_name" : "jheitzeb",
      "indices" : [ 3, 12 ],
      "id_str" : "6629572",
      "id" : 6629572
    }, {
      "name" : "Hack Things",
      "screen_name" : "HackThingsBlog",
      "indices" : [ 120, 135 ],
      "id_str" : "1112696238",
      "id" : 1112696238
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http://t.co/EsrRzW7gsq",
      "expanded_url" : "http://www.hackthings.com/lumu-shows-the-disruptive-power-of-dedicated-hardware-paired-with-smart-phones/",
      "display_url" : "hackthings.com/lumu-shows-the\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "346713462837219329",
  "text" : "RT @jheitzeb: Lumu shows the disruptive power of dedicated hardware paired with smart phones http://t.co/EsrRzW7gsq via @hackthingsblog",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Hack Things",
        "screen_name" : "HackThingsBlog",
        "indices" : [ 106, 121 ],
        "id_str" : "1112696238",
        "id" : 1112696238
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 79, 101 ],
        "url" : "http://t.co/EsrRzW7gsq",
        "expanded_url" : "http://www.hackthings.com/lumu-shows-the-disruptive-power-of-dedicated-hardware-paired-with-smart-phones/",
        "display_url" : "hackthings.com/lumu-shows-the\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "346711817730531328",
    "text" : "Lumu shows the disruptive power of dedicated hardware paired with smart phones http://t.co/EsrRzW7gsq via @hackthingsblog",
    "id" : 346711817730531328,
    "created_at" : "Mon Jun 17 19:31:53 +0000 2013",
    "user" : {
      "name" : "Joe Heitzeberg",
      "screen_name" : "jheitzeb",
      "protected" : false,
      "id_str" : "6629572",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3327280103/dae975db99fa2cf33b5613f2f6b8c724_normal.jpeg",
      "id" : 6629572,
      "verified" : false
    }
  },
  "id" : 346713462837219329,
  "created_at" : "Mon Jun 17 19:38:25 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Muellerleile",
      "screen_name" : "jrecursive",
      "indices" : [ 92, 103 ],
      "id_str" : "13002342",
      "id" : 13002342
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https://t.co/Ai8a9eFgfP",
      "expanded_url" : "https://medium.com/what-i-learned-building/736552dd5cc5",
      "display_url" : "medium.com/what-i-learned\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "346678317405052933",
  "text" : "On why Vine's six seconds are powerful. \u201CIt's how I actually recall moments from my life.\u201D \u2014@jrecursive https://t.co/Ai8a9eFgfP",
  "id" : 346678317405052933,
  "created_at" : "Mon Jun 17 17:18:46 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 58 ],
      "url" : "http://t.co/iuSOmmVGxu",
      "expanded_url" : "http://wayoftheduck.com/know-thy-umwelt",
      "display_url" : "wayoftheduck.com/know-thy-umwelt"
    } ]
  },
  "geo" : {
  },
  "id_str" : "346676847356018688",
  "text" : "\"Know thy umwelt\" - Way of the Duck http://t.co/iuSOmmVGxu",
  "id" : 346676847356018688,
  "created_at" : "Mon Jun 17 17:12:56 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Mobile Web (M5)</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Michel",
      "screen_name" : "chrismichel",
      "indices" : [ 3, 15 ],
      "id_str" : "6186392",
      "id" : 6186392
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/chrismichel/status/303257919162556416/photo/1",
      "indices" : [ 111, 131 ],
      "url" : "http://t.co/Pyv9CxMQ",
      "media_url" : "http://pbs.twimg.com/media/BDVjeIOCIAAzU_q.jpg",
      "id_str" : "303257919170945024",
      "id" : 303257919170945024,
      "media_url_https" : "https://pbs.twimg.com/media/BDVjeIOCIAAzU_q.jpg",
      "sizes" : [ {
        "h" : 473,
        "resize" : "fit",
        "w" : 473
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 473,
        "resize" : "fit",
        "w" : 473
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 473,
        "resize" : "fit",
        "w" : 473
      } ],
      "display_url" : "pic.twitter.com/Pyv9CxMQ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "346644183655784449",
  "text" : "RT @chrismichel: \"It keeps me from looking at my phone every two seconds.\" - Another genius New Yorker cartoon http://t.co/Pyv9CxMQ",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http://twitter.com/chrismichel/status/303257919162556416/photo/1",
        "indices" : [ 94, 114 ],
        "url" : "http://t.co/Pyv9CxMQ",
        "media_url" : "http://pbs.twimg.com/media/BDVjeIOCIAAzU_q.jpg",
        "id_str" : "303257919170945024",
        "id" : 303257919170945024,
        "media_url_https" : "https://pbs.twimg.com/media/BDVjeIOCIAAzU_q.jpg",
        "sizes" : [ {
          "h" : 473,
          "resize" : "fit",
          "w" : 473
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 473,
          "resize" : "fit",
          "w" : 473
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 473,
          "resize" : "fit",
          "w" : 473
        } ],
        "display_url" : "pic.twitter.com/Pyv9CxMQ"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "303257919162556416",
    "text" : "\"It keeps me from looking at my phone every two seconds.\" - Another genius New Yorker cartoon http://t.co/Pyv9CxMQ",
    "id" : 303257919162556416,
    "created_at" : "Sun Feb 17 21:41:37 +0000 2013",
    "user" : {
      "name" : "Christopher Michel",
      "screen_name" : "chrismichel",
      "protected" : false,
      "id_str" : "6186392",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000130343346/e4caa92e39dc52d0cb171659bcb12399_normal.jpeg",
      "id" : 6186392,
      "verified" : false
    }
  },
  "id" : 346644183655784449,
  "created_at" : "Mon Jun 17 15:03:08 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Freitas",
      "screen_name" : "ryanchris",
      "indices" : [ 0, 10 ],
      "id_str" : "13349",
      "id" : 13349
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "346483815000203264",
  "geo" : {
  },
  "id_str" : "346490627409715201",
  "in_reply_to_user_id" : 13349,
  "text" : "@ryanchris I'm in for the eve... but we should find some time for a drink soon!",
  "id" : 346490627409715201,
  "in_reply_to_status_id" : 346483815000203264,
  "created_at" : "Mon Jun 17 04:52:57 +0000 2013",
  "in_reply_to_screen_name" : "ryanchris",
  "in_reply_to_user_id_str" : "13349",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Freitas",
      "screen_name" : "ryanchris",
      "indices" : [ 0, 10 ],
      "id_str" : "13349",
      "id" : 13349
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "346477341146509312",
  "geo" : {
  },
  "id_str" : "346482866697412609",
  "in_reply_to_user_id" : 13349,
  "text" : "@ryanchris Just discovered that place last night, too. You're in my hood!",
  "id" : 346482866697412609,
  "in_reply_to_status_id" : 346477341146509312,
  "created_at" : "Mon Jun 17 04:22:07 +0000 2013",
  "in_reply_to_screen_name" : "ryanchris",
  "in_reply_to_user_id_str" : "13349",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 57 ],
      "url" : "http://t.co/OgBjr9m2ex",
      "expanded_url" : "http://flic.kr/p/eNQbW8",
      "display_url" : "flic.kr/p/eNQbW8"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859683, -122.27555 ]
  },
  "id_str" : "346476684448509952",
  "text" : "8:36pm Niko's classic monster face http://t.co/OgBjr9m2ex",
  "id" : 346476684448509952,
  "created_at" : "Mon Jun 17 03:57:33 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "everyunicode",
      "screen_name" : "everyunicode",
      "indices" : [ 3, 16 ],
      "id_str" : "1523237090",
      "id" : 1523237090
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "346448007023165440",
  "text" : "RT @everyunicode: !",
  "retweeted_status" : {
    "source" : "<a href=\"http://nas.sr/everyunicode\" rel=\"nofollow\">Every Unicode</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "346428235384487936",
    "text" : "!",
    "id" : 346428235384487936,
    "created_at" : "Mon Jun 17 00:45:02 +0000 2013",
    "user" : {
      "name" : "everyunicode",
      "screen_name" : "everyunicode",
      "protected" : false,
      "id_str" : "1523237090",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000003064433/3da1d96a7948f989c1c27d9ef4b0e0df_normal.png",
      "id" : 1523237090,
      "verified" : false
    }
  },
  "id" : 346448007023165440,
  "created_at" : "Mon Jun 17 02:03:36 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http://t.co/DhWdqFc2B3",
      "expanded_url" : "http://bit.ly/15aO5Pm",
      "display_url" : "bit.ly/15aO5Pm"
    } ]
  },
  "geo" : {
  },
  "id_str" : "346417056918421504",
  "text" : "Rambling notes on a Sunday afternoon after a sunny bike ride. \"Know thy umwelt.\" - Way of the Duck http://t.co/DhWdqFc2B3",
  "id" : 346417056918421504,
  "created_at" : "Mon Jun 17 00:00:37 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lift",
      "screen_name" : "liftapp",
      "indices" : [ 0, 8 ],
      "id_str" : "353195232",
      "id" : 353195232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "346398042280300545",
  "in_reply_to_user_id" : 353195232,
  "text" : "@liftapp Is there a way to change the name of my habit without losing the streak?",
  "id" : 346398042280300545,
  "created_at" : "Sun Jun 16 22:45:03 +0000 2013",
  "in_reply_to_screen_name" : "liftapp",
  "in_reply_to_user_id_str" : "353195232",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leonard",
      "screen_name" : "lhl",
      "indices" : [ 0, 4 ],
      "id_str" : "12513",
      "id" : 12513
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "346349073416204289",
  "geo" : {
  },
  "id_str" : "346358437006950402",
  "in_reply_to_user_id" : 12513,
  "text" : "@lhl Oooh, thanks for the tip!",
  "id" : 346358437006950402,
  "in_reply_to_status_id" : 346349073416204289,
  "created_at" : "Sun Jun 16 20:07:41 +0000 2013",
  "in_reply_to_screen_name" : "lhl",
  "in_reply_to_user_id_str" : "12513",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "todd sawicki",
      "screen_name" : "sawickipedia",
      "indices" : [ 0, 13 ],
      "id_str" : "1784841",
      "id" : 1784841
    }, {
      "name" : "Basis",
      "screen_name" : "mybasis",
      "indices" : [ 39, 47 ],
      "id_str" : "216453702",
      "id" : 216453702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "346343436028366848",
  "geo" : {
  },
  "id_str" : "346346609480699907",
  "in_reply_to_user_id" : 1784841,
  "text" : "@sawickipedia Ha, I have been stalking @mybasis for over 3 years, since I first heard that a watch would track my heart rate.",
  "id" : 346346609480699907,
  "in_reply_to_status_id" : 346343436028366848,
  "created_at" : "Sun Jun 16 19:20:41 +0000 2013",
  "in_reply_to_screen_name" : "sawickipedia",
  "in_reply_to_user_id_str" : "1784841",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Basis",
      "screen_name" : "mybasis",
      "indices" : [ 33, 41 ],
      "id_str" : "216453702",
      "id" : 216453702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "346341754880016384",
  "text" : "I had some syncing problems with @mybasis watch but their latest replacement seems to have fixed them. Thanks! Waiting anxiously for an API.",
  "id" : 346341754880016384,
  "created_at" : "Sun Jun 16 19:01:23 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Xeni Jardin",
      "screen_name" : "xeni",
      "indices" : [ 33, 38 ],
      "id_str" : "767",
      "id" : 767
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "346285108749279232",
  "geo" : {
  },
  "id_str" : "346287193138003971",
  "in_reply_to_user_id" : 767,
  "text" : "He is still missed every day. RT @xeni: Shout out to the dads who are no longer with the ones who still love them, because of cancer.",
  "id" : 346287193138003971,
  "in_reply_to_status_id" : 346285108749279232,
  "created_at" : "Sun Jun 16 15:24:35 +0000 2013",
  "in_reply_to_screen_name" : "xeni",
  "in_reply_to_user_id_str" : "767",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daryn Nakhuda",
      "screen_name" : "daryn",
      "indices" : [ 0, 6 ],
      "id_str" : "804808",
      "id" : 804808
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "346130427590881280",
  "geo" : {
  },
  "id_str" : "346131760188375040",
  "in_reply_to_user_id" : 804808,
  "text" : "@daryn Was I cc'd because you're not gonna put up with me anymore?",
  "id" : 346131760188375040,
  "in_reply_to_status_id" : 346130427590881280,
  "created_at" : "Sun Jun 16 05:06:57 +0000 2013",
  "in_reply_to_screen_name" : "daryn",
  "in_reply_to_user_id_str" : "804808",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "346123459904024578",
  "text" : "All the zooming on iOS 7 makes me dizzy after 6 drinks.",
  "id" : 346123459904024578,
  "created_at" : "Sun Jun 16 04:33:58 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 79 ],
      "url" : "http://t.co/7wYIZ0mNny",
      "expanded_url" : "http://flic.kr/p/eNdGaN",
      "display_url" : "flic.kr/p/eNdGaN"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.836608, -122.262275 ]
  },
  "id_str" : "346117114819657728",
  "text" : "8:36pm On a boozy pre-Father's Day date night with wifey http://t.co/7wYIZ0mNny",
  "id" : 346117114819657728,
  "created_at" : "Sun Jun 16 04:08:45 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http://t.co/GGHPVQQS5M",
      "expanded_url" : "http://instagram.com/p/amoms9I0Ef/",
      "display_url" : "instagram.com/p/amoms9I0Ef/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.836623, -122.262334 ]
  },
  "id_str" : "346097180819460096",
  "text" : "Squid pizza! @ Pizzaiolo http://t.co/GGHPVQQS5M",
  "id" : 346097180819460096,
  "created_at" : "Sun Jun 16 02:49:32 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katie Jacobs Stanton",
      "screen_name" : "KatieS",
      "indices" : [ 3, 10 ],
      "id_str" : "94143715",
      "id" : 94143715
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Turkey",
      "indices" : [ 71, 78 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "346085440400539648",
  "text" : "RT @KatieS: Here are the short codes to send/receive tweets via SMS in #Turkey Avea, KKTC Telsim, Vodafone 2444; Turkcell 2555",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Turkey",
        "indices" : [ 59, 66 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "346069954044497920",
    "text" : "Here are the short codes to send/receive tweets via SMS in #Turkey Avea, KKTC Telsim, Vodafone 2444; Turkcell 2555",
    "id" : 346069954044497920,
    "created_at" : "Sun Jun 16 01:01:21 +0000 2013",
    "user" : {
      "name" : "Katie Jacobs Stanton",
      "screen_name" : "KatieS",
      "protected" : false,
      "id_str" : "94143715",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3464882666/934970acd27fedc84aa22ac5befb04af_normal.png",
      "id" : 94143715,
      "verified" : false
    }
  },
  "id" : 346085440400539648,
  "created_at" : "Sun Jun 16 02:02:53 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Medium",
      "screen_name" : "Medium",
      "indices" : [ 3, 10 ],
      "id_str" : "571202103",
      "id" : 571202103
    }, {
      "name" : "Gary Vaynerchuk",
      "screen_name" : "garyvee",
      "indices" : [ 84, 92 ],
      "id_str" : "5768872",
      "id" : 5768872
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https://t.co/xurpcW2QB3",
      "expanded_url" : "https://medium.com/i-m-h-o/569e51ae8820?utm_source=TwitterAccount&utm_medium=Twitter&utm_campaign=TwitterAccount",
      "display_url" : "medium.com/i-m-h-o/569e51\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "346055890950045696",
  "text" : "RT @Medium: \u201CRide the Hashtag, Don\u2019t Create it: The true story of social media.\u201D by @garyvee https://t.co/xurpcW2QB3",
  "retweeted_status" : {
    "source" : "<a href=\"http://sproutsocial.com\" rel=\"nofollow\">Sprout Social</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Gary Vaynerchuk",
        "screen_name" : "garyvee",
        "indices" : [ 72, 80 ],
        "id_str" : "5768872",
        "id" : 5768872
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 81, 104 ],
        "url" : "https://t.co/xurpcW2QB3",
        "expanded_url" : "https://medium.com/i-m-h-o/569e51ae8820?utm_source=TwitterAccount&utm_medium=Twitter&utm_campaign=TwitterAccount",
        "display_url" : "medium.com/i-m-h-o/569e51\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "346055282419462144",
    "text" : "\u201CRide the Hashtag, Don\u2019t Create it: The true story of social media.\u201D by @garyvee https://t.co/xurpcW2QB3",
    "id" : 346055282419462144,
    "created_at" : "Sun Jun 16 00:03:03 +0000 2013",
    "user" : {
      "name" : "Medium",
      "screen_name" : "Medium",
      "protected" : false,
      "id_str" : "571202103",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2504297462/wtbq3hoquj8no6t2ysz4_normal.jpeg",
      "id" : 571202103,
      "verified" : true
    }
  },
  "id" : 346055890950045696,
  "created_at" : "Sun Jun 16 00:05:28 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vizify",
      "screen_name" : "vizify",
      "indices" : [ 3, 10 ],
      "id_str" : "295513152",
      "id" : 295513152
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FollowMe",
      "indices" : [ 121, 130 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http://t.co/mkannBT8JI",
      "expanded_url" : "http://ow.ly/lZ76w",
      "display_url" : "ow.ly/lZ76w"
    } ]
  },
  "geo" : {
  },
  "id_str" : "346010789620088832",
  "text" : "RT @vizify: Seen our new project w/Twitter--a movie made from your tweets yet? Make yours here:  http://t.co/mkannBT8JI  #FollowMe",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.hootsuite.com\" rel=\"nofollow\">HootSuite</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FollowMe",
        "indices" : [ 109, 118 ]
      } ],
      "urls" : [ {
        "indices" : [ 85, 107 ],
        "url" : "http://t.co/mkannBT8JI",
        "expanded_url" : "http://ow.ly/lZ76w",
        "display_url" : "ow.ly/lZ76w"
      } ]
    },
    "geo" : {
    },
    "id_str" : "346009927782912000",
    "text" : "Seen our new project w/Twitter--a movie made from your tweets yet? Make yours here:  http://t.co/mkannBT8JI  #FollowMe",
    "id" : 346009927782912000,
    "created_at" : "Sat Jun 15 21:02:49 +0000 2013",
    "user" : {
      "name" : "Vizify",
      "screen_name" : "vizify",
      "protected" : false,
      "id_str" : "295513152",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3405796151/86d61a5a1c5a8b6c7cb9388a33ef292c_normal.png",
      "id" : 295513152,
      "verified" : false
    }
  },
  "id" : 346010789620088832,
  "created_at" : "Sat Jun 15 21:06:15 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://vine.co\" rel=\"nofollow\">Vine - Make a Scene</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 45 ],
      "url" : "https://t.co/eawkRKNY6I",
      "expanded_url" : "https://vine.co/v/hBmng6h97zV",
      "display_url" : "vine.co/v/hBmng6h97zV"
    } ]
  },
  "geo" : {
  },
  "id_str" : "345969361196032000",
  "text" : "Pre-lunch dance party https://t.co/eawkRKNY6I",
  "id" : 345969361196032000,
  "created_at" : "Sat Jun 15 18:21:38 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 66 ],
      "url" : "http://t.co/v3nhFLf6P0",
      "expanded_url" : "http://flic.kr/p/eMJijD",
      "display_url" : "flic.kr/p/eMJijD"
    } ]
  },
  "geo" : {
  },
  "id_str" : "345968881447342080",
  "text" : "Wall of Memes! (Can you identify them all?) http://t.co/v3nhFLf6P0",
  "id" : 345968881447342080,
  "created_at" : "Sat Jun 15 18:19:43 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dian Rosanti",
      "screen_name" : "DianRosanti",
      "indices" : [ 0, 12 ],
      "id_str" : "7101552",
      "id" : 7101552
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "345800438081261568",
  "geo" : {
  },
  "id_str" : "345817871026372608",
  "in_reply_to_user_id" : 7101552,
  "text" : "@DianRosanti Worst I ever saw was a Nordstrom window display that said \"Everyone has a father.\"",
  "id" : 345817871026372608,
  "in_reply_to_status_id" : 345800438081261568,
  "created_at" : "Sat Jun 15 08:19:40 +0000 2013",
  "in_reply_to_screen_name" : "DianRosanti",
  "in_reply_to_user_id_str" : "7101552",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "345778198728019968",
  "text" : "OH (pt2) \"But he met a sad end. He was in our garage and mice at him and nested in his face.\"",
  "id" : 345778198728019968,
  "created_at" : "Sat Jun 15 05:42:01 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "345776105447374848",
  "text" : "OH \"I think I told you guys I was married by a puppet...\"",
  "id" : 345776105447374848,
  "created_at" : "Sat Jun 15 05:33:42 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jinen Kamdar",
      "screen_name" : "jinen",
      "indices" : [ 28, 34 ],
      "id_str" : "11739102",
      "id" : 11739102
    }, {
      "name" : "skamdar",
      "screen_name" : "skamdar",
      "indices" : [ 51, 59 ],
      "id_str" : "9370162",
      "id" : 9370162
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http://t.co/hqBOxtQ0mF",
      "expanded_url" : "http://www.google.com/loon/",
      "display_url" : "google.com/loon/"
    } ]
  },
  "in_reply_to_status_id_str" : "345765499738652672",
  "geo" : {
  },
  "id_str" : "345770906943111169",
  "in_reply_to_user_id" : 11739102,
  "text" : "An actual big deal. Wow. RT @jinen: so my brother (@skamdar) and his team just launched this: http://t.co/hqBOxtQ0mF. no big deal.",
  "id" : 345770906943111169,
  "in_reply_to_status_id" : 345765499738652672,
  "created_at" : "Sat Jun 15 05:13:02 +0000 2013",
  "in_reply_to_screen_name" : "jinen",
  "in_reply_to_user_id_str" : "11739102",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http://t.co/DHA55g5jVT",
      "expanded_url" : "http://flic.kr/p/eMjgmc",
      "display_url" : "flic.kr/p/eMjgmc"
    } ]
  },
  "geo" : {
  },
  "id_str" : "345755479420583936",
  "text" : "8:36pm Waiting for Niko to finish his bath alone time http://t.co/DHA55g5jVT",
  "id" : 345755479420583936,
  "created_at" : "Sat Jun 15 04:11:44 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Galen",
      "screen_name" : "dolface",
      "indices" : [ 0, 8 ],
      "id_str" : "4366051",
      "id" : 4366051
    }, {
      "name" : "Jessica Verrilli",
      "screen_name" : "jess",
      "indices" : [ 9, 14 ],
      "id_str" : "6331462",
      "id" : 6331462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "345667375477161984",
  "geo" : {
  },
  "id_str" : "345667928886239233",
  "in_reply_to_user_id" : 4366051,
  "text" : "@dolface @jess All YouTube video surfing for my son ends with middle-aged men recording narrations of stories involving model trains.",
  "id" : 345667928886239233,
  "in_reply_to_status_id" : 345667375477161984,
  "created_at" : "Fri Jun 14 22:23:51 +0000 2013",
  "in_reply_to_screen_name" : "gln",
  "in_reply_to_user_id_str" : "4366051",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Realtime Recs",
      "screen_name" : "MagicRecs",
      "indices" : [ 0, 10 ],
      "id_str" : "1270746139",
      "id" : 1270746139
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "345641118962167808",
  "in_reply_to_user_id" : 1270746139,
  "text" : "@magicrecs is basically a service that lets me know when my coworkers have created a new parody account.",
  "id" : 345641118962167808,
  "created_at" : "Fri Jun 14 20:37:19 +0000 2013",
  "in_reply_to_screen_name" : "MagicRecs",
  "in_reply_to_user_id_str" : "1270746139",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ariel Aberg-Riger",
      "screen_name" : "Figure1",
      "indices" : [ 0, 8 ],
      "id_str" : "13788172",
      "id" : 13788172
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "345600514018390017",
  "geo" : {
  },
  "id_str" : "345601212474880000",
  "in_reply_to_user_id" : 13788172,
  "text" : "@Figure1 I think it's the former, from what I understand about how memories are stored (aka linearly). But I bet there's room to improve.",
  "id" : 345601212474880000,
  "in_reply_to_status_id" : 345600514018390017,
  "created_at" : "Fri Jun 14 17:58:44 +0000 2013",
  "in_reply_to_screen_name" : "Figure1",
  "in_reply_to_user_id_str" : "13788172",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https://t.co/iqKeBpYyvt",
      "expanded_url" : "https://www.vizify.com/buster-benson/twitter-video?km_source=twitter",
      "display_url" : "vizify.com/buster-benson/\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "345593354664431616",
  "text" : "This is really cool: a 44 animated portrait summarizing my life on twitter. https://t.co/iqKeBpYyvt",
  "id" : 345593354664431616,
  "created_at" : "Fri Jun 14 17:27:31 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "345584574774013952",
  "text" : "Our brains are massively parallel but they're best at understanding things that can be represented linearly.",
  "id" : 345584574774013952,
  "created_at" : "Fri Jun 14 16:52:37 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "345387541496737793",
  "text" : "The easiest way to explain the world to a 3-year old is to use a lot of monsters. In other news, I wonder why religion is so compelling?",
  "id" : 345387541496737793,
  "created_at" : "Fri Jun 14 03:49:41 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lift",
      "screen_name" : "liftapp",
      "indices" : [ 32, 40 ],
      "id_str" : "353195232",
      "id" : 353195232
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/buster/status/345386660558684160/photo/1",
      "indices" : [ 68, 90 ],
      "url" : "http://t.co/ZlrT8PPZ63",
      "media_url" : "http://pbs.twimg.com/media/BMsPVn0CQAE-wK8.jpg",
      "id_str" : "345386660562878465",
      "id" : 345386660562878465,
      "media_url_https" : "https://pbs.twimg.com/media/BMsPVn0CQAE-wK8.jpg",
      "sizes" : [ {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      } ],
      "display_url" : "pic.twitter.com/ZlrT8PPZ63"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "345386660558684160",
  "text" : "Meditated for the 100th time on @liftapp towards my metric Kiloslog http://t.co/ZlrT8PPZ63",
  "id" : 345386660558684160,
  "created_at" : "Fri Jun 14 03:46:11 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http://t.co/nHRfH7yJoO",
      "expanded_url" : "http://flic.kr/p/eLAnig",
      "display_url" : "flic.kr/p/eLAnig"
    } ]
  },
  "geo" : {
  },
  "id_str" : "345384441016881153",
  "text" : "8:36pm Alternate spelling I just now discovered http://t.co/nHRfH7yJoO",
  "id" : 345384441016881153,
  "created_at" : "Fri Jun 14 03:37:22 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stewart Butterfield",
      "screen_name" : "stewart",
      "indices" : [ 0, 8 ],
      "id_str" : "5699",
      "id" : 5699
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "345362995884474370",
  "geo" : {
  },
  "id_str" : "345379503197007872",
  "in_reply_to_user_id" : 5699,
  "text" : "@stewart The futility of feeling peace is the only peace we can have.",
  "id" : 345379503197007872,
  "in_reply_to_status_id" : 345362995884474370,
  "created_at" : "Fri Jun 14 03:17:45 +0000 2013",
  "in_reply_to_screen_name" : "stewart",
  "in_reply_to_user_id_str" : "5699",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel F Lopes",
      "screen_name" : "danflopes",
      "indices" : [ 0, 10 ],
      "id_str" : "878561",
      "id" : 878561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "345314857630986240",
  "geo" : {
  },
  "id_str" : "345320918647709697",
  "in_reply_to_user_id" : 878561,
  "text" : "@danflopes You're welcome! Always happy to hear that there are people out there who think about these same things...",
  "id" : 345320918647709697,
  "in_reply_to_status_id" : 345314857630986240,
  "created_at" : "Thu Jun 13 23:24:57 +0000 2013",
  "in_reply_to_screen_name" : "danflopes",
  "in_reply_to_user_id_str" : "878561",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Bogan",
      "screen_name" : "waferbaby",
      "indices" : [ 0, 10 ],
      "id_str" : "821753",
      "id" : 821753
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "345224879999696897",
  "geo" : {
  },
  "id_str" : "345226095957786625",
  "in_reply_to_user_id" : 821753,
  "text" : "@waferbaby Yeah they're a bit linked up at the moment. That'll change...",
  "id" : 345226095957786625,
  "in_reply_to_status_id" : 345224879999696897,
  "created_at" : "Thu Jun 13 17:08:09 +0000 2013",
  "in_reply_to_screen_name" : "waferbaby",
  "in_reply_to_user_id_str" : "821753",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TechCrunch",
      "screen_name" : "TechCrunch",
      "indices" : [ 33, 44 ],
      "id_str" : "816653",
      "id" : 816653
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http://t.co/20hpglkTUa",
      "expanded_url" : "http://tcrn.ch/1a7utBf",
      "display_url" : "tcrn.ch/1a7utBf"
    } ]
  },
  "in_reply_to_status_id_str" : "345169820267978752",
  "geo" : {
  },
  "id_str" : "345196576261685250",
  "in_reply_to_user_id" : 816653,
  "text" : "See how your tweets are doing RT @TechCrunch: Twitter Opens Up Tweet Performance Analytics To All, For Free http://t.co/20hpglkTUa",
  "id" : 345196576261685250,
  "in_reply_to_status_id" : 345169820267978752,
  "created_at" : "Thu Jun 13 15:10:51 +0000 2013",
  "in_reply_to_screen_name" : "TechCrunch",
  "in_reply_to_user_id_str" : "816653",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 52 ],
      "url" : "http://t.co/J6qIKLL7pS",
      "expanded_url" : "http://flic.kr/p/eL4kFd",
      "display_url" : "flic.kr/p/eL4kFd"
    } ]
  },
  "geo" : {
  },
  "id_str" : "345027670595207168",
  "text" : "8:36pm Forced hug action shot http://t.co/J6qIKLL7pS",
  "id" : 345027670595207168,
  "created_at" : "Thu Jun 13 03:59:41 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Realtime Recs",
      "screen_name" : "MagicRecs",
      "indices" : [ 7, 17 ],
      "id_str" : "1270746139",
      "id" : 1270746139
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "344983411594772480",
  "text" : "Follow @MagicRecs for some really interesting magic... recs... and things. Actually pretty dang awesome.",
  "id" : 344983411594772480,
  "created_at" : "Thu Jun 13 01:03:49 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Artajos",
      "screen_name" : "andrewartajos",
      "indices" : [ 0, 14 ],
      "id_str" : "173407706",
      "id" : 173407706
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "344962544873652224",
  "geo" : {
  },
  "id_str" : "344964806723383297",
  "in_reply_to_user_id" : 173407706,
  "text" : "@andrewartajos Great! Thanks. How did you find it?",
  "id" : 344964806723383297,
  "in_reply_to_status_id" : 344962544873652224,
  "created_at" : "Wed Jun 12 23:49:53 +0000 2013",
  "in_reply_to_screen_name" : "andrewartajos",
  "in_reply_to_user_id_str" : "173407706",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kat Kinnie",
      "screen_name" : "KinnieKat",
      "indices" : [ 0, 10 ],
      "id_str" : "1331153430",
      "id" : 1331153430
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "344953754153537536",
  "geo" : {
  },
  "id_str" : "344960571713658880",
  "in_reply_to_user_id" : 1331153430,
  "text" : "@KinnieKat Thanks for the nudge. I would have totally missed that. Replied via fb\u2026 thanks for the advice!",
  "id" : 344960571713658880,
  "in_reply_to_status_id" : 344953754153537536,
  "created_at" : "Wed Jun 12 23:33:04 +0000 2013",
  "in_reply_to_screen_name" : "KinnieKat",
  "in_reply_to_user_id_str" : "1331153430",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dana McCallum",
      "screen_name" : "DanaDanger",
      "indices" : [ 3, 14 ],
      "id_str" : "821958",
      "id" : 821958
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/DanaDanger/status/344948506387165184/photo/1",
      "indices" : [ 44, 66 ],
      "url" : "http://t.co/B7IF6V9UbA",
      "media_url" : "http://pbs.twimg.com/media/BMmA1sVCMAMGtum.jpg",
      "id_str" : "344948506391359491",
      "id" : 344948506391359491,
      "media_url_https" : "https://pbs.twimg.com/media/BMmA1sVCMAMGtum.jpg",
      "sizes" : [ {
        "h" : 442,
        "resize" : "fit",
        "w" : 590
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 442,
        "resize" : "fit",
        "w" : 590
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 442,
        "resize" : "fit",
        "w" : 590
      } ],
      "display_url" : "pic.twitter.com/B7IF6V9UbA"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "344949868432859136",
  "text" : "RT @DanaDanger: Reminder: Jony Ive ca. 1999 http://t.co/B7IF6V9UbA",
  "retweeted_status" : {
    "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http://twitter.com/DanaDanger/status/344948506387165184/photo/1",
        "indices" : [ 28, 50 ],
        "url" : "http://t.co/B7IF6V9UbA",
        "media_url" : "http://pbs.twimg.com/media/BMmA1sVCMAMGtum.jpg",
        "id_str" : "344948506391359491",
        "id" : 344948506391359491,
        "media_url_https" : "https://pbs.twimg.com/media/BMmA1sVCMAMGtum.jpg",
        "sizes" : [ {
          "h" : 442,
          "resize" : "fit",
          "w" : 590
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 442,
          "resize" : "fit",
          "w" : 590
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 442,
          "resize" : "fit",
          "w" : 590
        } ],
        "display_url" : "pic.twitter.com/B7IF6V9UbA"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "344948506387165184",
    "text" : "Reminder: Jony Ive ca. 1999 http://t.co/B7IF6V9UbA",
    "id" : 344948506387165184,
    "created_at" : "Wed Jun 12 22:45:07 +0000 2013",
    "user" : {
      "name" : "Dana McCallum",
      "screen_name" : "DanaDanger",
      "protected" : false,
      "id_str" : "821958",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000071346152/00cc4afc7b6cce00f058c388cd29ae45_normal.jpeg",
      "id" : 821958,
      "verified" : false
    }
  },
  "id" : 344949868432859136,
  "created_at" : "Wed Jun 12 22:50:32 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://timehop.com/\" rel=\"nofollow\">Timehop</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 38 ],
      "url" : "http://t.co/vCS9mYef1x",
      "expanded_url" : "http://t.imehop.com/19rLpUo",
      "display_url" : "t.imehop.com/19rLpUo"
    } ]
  },
  "geo" : {
  },
  "id_str" : "344937256416583680",
  "text" : "Chunky monkey.  http://t.co/vCS9mYef1x",
  "id" : 344937256416583680,
  "created_at" : "Wed Jun 12 22:00:25 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris O\u2019Shea",
      "screen_name" : "chrisoshea",
      "indices" : [ 26, 37 ],
      "id_str" : "23331266",
      "id" : 23331266
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http://t.co/txiAcjFqKF",
      "expanded_url" : "http://youtu.be/K8uuR2F4Ee8",
      "display_url" : "youtu.be/K8uuR2F4Ee8"
    } ]
  },
  "in_reply_to_status_id_str" : "344881696983896065",
  "geo" : {
  },
  "id_str" : "344883670844309504",
  "in_reply_to_user_id" : 23331266,
  "text" : "Niko's gonna LOVE this RT @chrisoshea: Toca Builder, looks like their most expressive, minecraft-like game yet http://t.co/txiAcjFqKF",
  "id" : 344883670844309504,
  "in_reply_to_status_id" : 344881696983896065,
  "created_at" : "Wed Jun 12 18:27:29 +0000 2013",
  "in_reply_to_screen_name" : "chrisoshea",
  "in_reply_to_user_id_str" : "23331266",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Pusateri",
      "screen_name" : "Cruftbox",
      "indices" : [ 0, 9 ],
      "id_str" : "792738",
      "id" : 792738
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "344856309180547072",
  "geo" : {
  },
  "id_str" : "344860056820527105",
  "in_reply_to_user_id" : 792738,
  "text" : "@Cruftbox And I'd counter that by arguing that brains are DNA/RNA's best invention. What other more important outcomes would it support?",
  "id" : 344860056820527105,
  "in_reply_to_status_id" : 344856309180547072,
  "created_at" : "Wed Jun 12 16:53:39 +0000 2013",
  "in_reply_to_screen_name" : "Cruftbox",
  "in_reply_to_user_id_str" : "792738",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arjun Balaji",
      "screen_name" : "arjunblj",
      "indices" : [ 0, 9 ],
      "id_str" : "25552514",
      "id" : 25552514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "344857618386391040",
  "geo" : {
  },
  "id_str" : "344859592532037632",
  "in_reply_to_user_id" : 25552514,
  "text" : "@arjunblj Absolutely.",
  "id" : 344859592532037632,
  "in_reply_to_status_id" : 344857618386391040,
  "created_at" : "Wed Jun 12 16:51:48 +0000 2013",
  "in_reply_to_screen_name" : "arjunblj",
  "in_reply_to_user_id_str" : "25552514",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Lewis",
      "screen_name" : "plewis67",
      "indices" : [ 0, 9 ],
      "id_str" : "251583860",
      "id" : 251583860
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "344858848756113408",
  "geo" : {
  },
  "id_str" : "344859489058566146",
  "in_reply_to_user_id" : 251583860,
  "text" : "@plewis67 True. But that supports my original statement that reverse engineering the complexity may be important (if only to diffuse it).",
  "id" : 344859489058566146,
  "in_reply_to_status_id" : 344858848756113408,
  "created_at" : "Wed Jun 12 16:51:24 +0000 2013",
  "in_reply_to_screen_name" : "plewis67",
  "in_reply_to_user_id_str" : "251583860",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Lewis",
      "screen_name" : "plewis67",
      "indices" : [ 0, 9 ],
      "id_str" : "251583860",
      "id" : 251583860
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "344856864216989697",
  "geo" : {
  },
  "id_str" : "344858081710178305",
  "in_reply_to_user_id" : 251583860,
  "text" : "@plewis67 What's important about a brain that isn't a direct side effect of its extreme complexity?",
  "id" : 344858081710178305,
  "in_reply_to_status_id" : 344856864216989697,
  "created_at" : "Wed Jun 12 16:45:48 +0000 2013",
  "in_reply_to_screen_name" : "plewis67",
  "in_reply_to_user_id_str" : "251583860",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Winnie Lim",
      "screen_name" : "wynlim",
      "indices" : [ 0, 7 ],
      "id_str" : "7729652",
      "id" : 7729652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "344851977118826496",
  "geo" : {
  },
  "id_str" : "344856716267094016",
  "in_reply_to_user_id" : 7729652,
  "text" : "@wynlim Liked the former, will check out the latter. Thanks!",
  "id" : 344856716267094016,
  "in_reply_to_status_id" : 344851977118826496,
  "created_at" : "Wed Jun 12 16:40:22 +0000 2013",
  "in_reply_to_screen_name" : "wynlim",
  "in_reply_to_user_id_str" : "7729652",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anthony Stevens",
      "screen_name" : "anthonyrstevens",
      "indices" : [ 0, 16 ],
      "id_str" : "12723292",
      "id" : 12723292
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "344855533024575489",
  "geo" : {
  },
  "id_str" : "344856689163513857",
  "in_reply_to_user_id" : 12723292,
  "text" : "@anthonyrstevens Yeah. Great book!",
  "id" : 344856689163513857,
  "in_reply_to_status_id" : 344855533024575489,
  "created_at" : "Wed Jun 12 16:40:16 +0000 2013",
  "in_reply_to_screen_name" : "anthonyrstevens",
  "in_reply_to_user_id_str" : "12723292",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "344855108980457472",
  "text" : "When we can download and copy our minds, and merge them all into one big network that functions like one big brain... (lots of questions)",
  "id" : 344855108980457472,
  "created_at" : "Wed Jun 12 16:33:59 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leo Dirac",
      "screen_name" : "leopd",
      "indices" : [ 0, 6 ],
      "id_str" : "5500632",
      "id" : 5500632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "344852750636572673",
  "geo" : {
  },
  "id_str" : "344854473954443266",
  "in_reply_to_user_id" : 5500632,
  "text" : "@leopd True. But we probably can't reverse engineer the network of brains before brains themselves.",
  "id" : 344854473954443266,
  "in_reply_to_status_id" : 344852750636572673,
  "created_at" : "Wed Jun 12 16:31:28 +0000 2013",
  "in_reply_to_screen_name" : "leopd",
  "in_reply_to_user_id_str" : "5500632",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kurt Revis",
      "screen_name" : "kurtrevis",
      "indices" : [ 61, 71 ],
      "id_str" : "56244113",
      "id" : 56244113
    }, {
      "name" : "Buster",
      "screen_name" : "buster",
      "indices" : [ 73, 80 ],
      "id_str" : "2185",
      "id" : 2185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "344852526115467265",
  "geo" : {
  },
  "id_str" : "344854156349153281",
  "in_reply_to_user_id" : 56244113,
  "text" : "Do any other objects make similarly compelling arguments? RT @kurtrevis: @buster Consider which organ is telling you both of those things.",
  "id" : 344854156349153281,
  "in_reply_to_status_id" : 344852526115467265,
  "created_at" : "Wed Jun 12 16:30:12 +0000 2013",
  "in_reply_to_screen_name" : "kurtrevis",
  "in_reply_to_user_id_str" : "56244113",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "344853594291441664",
  "text" : "What if consciousness is the ability to see what was just integrated /understood in a way that feels like we're just *about* to integrate?",
  "id" : 344853594291441664,
  "created_at" : "Wed Jun 12 16:27:58 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Lewis",
      "screen_name" : "plewis67",
      "indices" : [ 0, 9 ],
      "id_str" : "251583860",
      "id" : 251583860
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "344851903202603008",
  "geo" : {
  },
  "id_str" : "344852573112643584",
  "in_reply_to_user_id" : 251583860,
  "text" : "@plewis67 Because of the 2nd order effects that understanding the complexity would enable, both for understanding the world and ourselves.",
  "id" : 344852573112643584,
  "in_reply_to_status_id" : 344851903202603008,
  "created_at" : "Wed Jun 12 16:23:55 +0000 2013",
  "in_reply_to_screen_name" : "plewis67",
  "in_reply_to_user_id_str" : "251583860",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "344851381640892417",
  "text" : "If the human brain is the most complex object in the universe, reverse-engineering it may be the most important project in the universe. T/F",
  "id" : 344851381640892417,
  "created_at" : "Wed Jun 12 16:19:11 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "344850183059816451",
  "text" : "Reading Kurzwel's \"How to Create a Mind\" again. What's the last book you liked enough to read again?",
  "id" : 344850183059816451,
  "created_at" : "Wed Jun 12 16:14:25 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http://t.co/FS23xVHYYp",
      "expanded_url" : "http://readwrite.com/2013/06/11/sources-and-sinks-twitter-facebook-linkedin-content-flow",
      "display_url" : "readwrite.com/2013/06/11/sou\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "344839247527817216",
  "text" : "I like this \"sources vs sinks\" metaphor for how social data flows. This is where the strategy and drama happen:  http://t.co/FS23xVHYYp",
  "id" : 344839247527817216,
  "created_at" : "Wed Jun 12 15:30:58 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian Padgham",
      "screen_name" : "origiful",
      "indices" : [ 3, 12 ],
      "id_str" : "15603374",
      "id" : 15603374
    }, {
      "name" : "Ian Padgham",
      "screen_name" : "origiful",
      "indices" : [ 45, 54 ],
      "id_str" : "15603374",
      "id" : 15603374
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kidatheart",
      "indices" : [ 55, 66 ]
    } ],
    "urls" : [ {
      "indices" : [ 67, 90 ],
      "url" : "https://t.co/0ue0QugqeO",
      "expanded_url" : "https://vine.co/v/blrW6wMzEpa",
      "display_url" : "vine.co/v/blrW6wMzEpa"
    } ]
  },
  "geo" : {
  },
  "id_str" : "344835516644081664",
  "text" : "RT @origiful: Playing with my toy cars :) by @origiful #kidatheart https://t.co/0ue0QugqeO",
  "retweeted_status" : {
    "source" : "<a href=\"http://vine.co\" rel=\"nofollow\">Vine - Make a Scene</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ian Padgham",
        "screen_name" : "origiful",
        "indices" : [ 31, 40 ],
        "id_str" : "15603374",
        "id" : 15603374
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "kidatheart",
        "indices" : [ 41, 52 ]
      } ],
      "urls" : [ {
        "indices" : [ 53, 76 ],
        "url" : "https://t.co/0ue0QugqeO",
        "expanded_url" : "https://vine.co/v/blrW6wMzEpa",
        "display_url" : "vine.co/v/blrW6wMzEpa"
      } ]
    },
    "geo" : {
    },
    "id_str" : "344828577503649794",
    "text" : "Playing with my toy cars :) by @origiful #kidatheart https://t.co/0ue0QugqeO",
    "id" : 344828577503649794,
    "created_at" : "Wed Jun 12 14:48:34 +0000 2013",
    "user" : {
      "name" : "Ian Padgham",
      "screen_name" : "origiful",
      "protected" : false,
      "id_str" : "15603374",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3760492781/129672f7e46b9842d9833d38f006c45a_normal.jpeg",
      "id" : 15603374,
      "verified" : false
    }
  },
  "id" : 344835516644081664,
  "created_at" : "Wed Jun 12 15:16:08 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 67 ],
      "url" : "http://t.co/AeZCXoF3h3",
      "expanded_url" : "http://flic.kr/p/eKjv3y",
      "display_url" : "flic.kr/p/eKjv3y"
    } ]
  },
  "geo" : {
  },
  "id_str" : "344661373701210113",
  "text" : "8:36pm One little monkey jumping in the bath http://t.co/AeZCXoF3h3",
  "id" : 344661373701210113,
  "created_at" : "Wed Jun 12 03:44:09 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ali Berman",
      "screen_name" : "spangley",
      "indices" : [ 45, 54 ],
      "id_str" : "776429",
      "id" : 776429
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/buster/status/344579400836190209/photo/1",
      "indices" : [ 55, 77 ],
      "url" : "http://t.co/sB6CeSN7bp",
      "media_url" : "http://pbs.twimg.com/media/BMgxI7ACEAEzfjc.jpg",
      "id_str" : "344579400840384513",
      "id" : 344579400840384513,
      "media_url_https" : "https://pbs.twimg.com/media/BMgxI7ACEAEzfjc.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com/sB6CeSN7bp"
    } ],
    "hashtags" : [ {
      "text" : "lildude",
      "indices" : [ 13, 21 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7763822126, -122.4175347633 ]
  },
  "id_str" : "344579400836190209",
  "text" : "Self-branded #lildude visits Twitter HQ with @spangley http://t.co/sB6CeSN7bp",
  "id" : 344579400836190209,
  "created_at" : "Tue Jun 11 22:18:25 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http://t.co/jRqlhocmd4",
      "expanded_url" : "http://bit.ly/productivitytipbusterbenson",
      "display_url" : "bit.ly/productivityti\u2026"
    }, {
      "indices" : [ 115, 137 ],
      "url" : "http://t.co/UeNcYc3JRP",
      "expanded_url" : "http://bit.ly/1172KgW",
      "display_url" : "bit.ly/1172KgW"
    } ]
  },
  "geo" : {
  },
  "id_str" : "344545626693967873",
  "text" : "My favorite productivity hack: Experiment with new habits regularly http://t.co/jRqlhocmd4 \n\nSee what others said: http://t.co/UeNcYc3JRP",
  "id" : 344545626693967873,
  "created_at" : "Tue Jun 11 20:04:13 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ali Berman",
      "screen_name" : "spangley",
      "indices" : [ 0, 9 ],
      "id_str" : "776429",
      "id" : 776429
    }, {
      "name" : "@winfield",
      "screen_name" : "winfield",
      "indices" : [ 10, 19 ],
      "id_str" : "16881995",
      "id" : 16881995
    }, {
      "name" : "nicole sheikh",
      "screen_name" : "nicolesheikh",
      "indices" : [ 20, 33 ],
      "id_str" : "90800956",
      "id" : 90800956
    }, {
      "name" : "Charlie Love",
      "screen_name" : "clove",
      "indices" : [ 34, 40 ],
      "id_str" : "965101",
      "id" : 965101
    }, {
      "name" : "Lindsay Schauer",
      "screen_name" : "SchauerTime",
      "indices" : [ 41, 53 ],
      "id_str" : "19169495",
      "id" : 19169495
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "344518862483632130",
  "geo" : {
  },
  "id_str" : "344526929765994496",
  "in_reply_to_user_id" : 776429,
  "text" : "@spangley @winfield @nicolesheikh @clove @schauertime I'm in! Let me know when you're here.",
  "id" : 344526929765994496,
  "in_reply_to_status_id" : 344518862483632130,
  "created_at" : "Tue Jun 11 18:49:55 +0000 2013",
  "in_reply_to_screen_name" : "spangley",
  "in_reply_to_user_id_str" : "776429",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Frank Chimero",
      "screen_name" : "fchimero",
      "indices" : [ 3, 12 ],
      "id_str" : "13212522",
      "id" : 13212522
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "344498683896791040",
  "text" : "RT @fchimero: \u201CEvery time I assume a talented person isn\u2019t painfully aware of the flaws in their work, I am wrong\u201D Thoughts on iOS7 http://\u2026",
  "retweeted_status" : {
    "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http://t.co/u2yKk3u0Nr",
        "expanded_url" : "http://frankchimero.com/blog/2013/06/generosity-of-perspective/",
        "display_url" : "frankchimero.com/blog/2013/06/g\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "344465200499539969",
    "text" : "\u201CEvery time I assume a talented person isn\u2019t painfully aware of the flaws in their work, I am wrong\u201D Thoughts on iOS7 http://t.co/u2yKk3u0Nr",
    "id" : 344465200499539969,
    "created_at" : "Tue Jun 11 14:44:38 +0000 2013",
    "user" : {
      "name" : "Frank Chimero",
      "screen_name" : "fchimero",
      "protected" : false,
      "id_str" : "13212522",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3677885752/0920901175140a207fc049b922de87a0_normal.jpeg",
      "id" : 13212522,
      "verified" : false
    }
  },
  "id" : 344498683896791040,
  "created_at" : "Tue Jun 11 16:57:41 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "344498141183229953",
  "text" : "Tell-tale sign of both geniuses and idiots: ability to go from initial exposure to staunchly held opinion in 135 milliseconds.",
  "id" : 344498141183229953,
  "created_at" : "Tue Jun 11 16:55:31 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Cottrell",
      "screen_name" : "rgcottrell",
      "indices" : [ 0, 11 ],
      "id_str" : "752553",
      "id" : 752553
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "344327678435921920",
  "geo" : {
  },
  "id_str" : "344328125292875777",
  "in_reply_to_user_id" : 752553,
  "text" : "@rgcottrell Is there a link to the What's New list?",
  "id" : 344328125292875777,
  "in_reply_to_status_id" : 344327678435921920,
  "created_at" : "Tue Jun 11 05:39:57 +0000 2013",
  "in_reply_to_screen_name" : "rgcottrell",
  "in_reply_to_user_id_str" : "752553",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Cottrell",
      "screen_name" : "rgcottrell",
      "indices" : [ 0, 11 ],
      "id_str" : "752553",
      "id" : 752553
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "344325422273683458",
  "geo" : {
  },
  "id_str" : "344326155119247360",
  "in_reply_to_user_id" : 752553,
  "text" : "@rgcottrell Ooh like what?",
  "id" : 344326155119247360,
  "in_reply_to_status_id" : 344325422273683458,
  "created_at" : "Tue Jun 11 05:32:07 +0000 2013",
  "in_reply_to_screen_name" : "rgcottrell",
  "in_reply_to_user_id_str" : "752553",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http://t.co/pca7PGt1sA",
      "expanded_url" : "http://flic.kr/p/eJnto8",
      "display_url" : "flic.kr/p/eJnto8"
    } ]
  },
  "geo" : {
  },
  "id_str" : "344299058590007296",
  "text" : "8:36pm Taking a Daft Punk dance party break to read about trains http://t.co/pca7PGt1sA",
  "id" : 344299058590007296,
  "created_at" : "Tue Jun 11 03:44:27 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "harryh",
      "screen_name" : "harryh",
      "indices" : [ 0, 7 ],
      "id_str" : "4558",
      "id" : 4558
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "344282480255324160",
  "geo" : {
  },
  "id_str" : "344286665206018048",
  "in_reply_to_user_id" : 4558,
  "text" : "@harryh (Successes + bad beats) - (failures + lucky draws)",
  "id" : 344286665206018048,
  "in_reply_to_status_id" : 344282480255324160,
  "created_at" : "Tue Jun 11 02:55:12 +0000 2013",
  "in_reply_to_screen_name" : "harryh",
  "in_reply_to_user_id_str" : "4558",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "344268572148772865",
  "text" : "Remember this about iOS7's design: Q - \"How do we want you to feel?\" A - We want most of you to feel happy &amp; light. And some to feel rage.",
  "id" : 344268572148772865,
  "created_at" : "Tue Jun 11 01:43:18 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Frank",
      "screen_name" : "stevenf",
      "indices" : [ 3, 11 ],
      "id_str" : "733813",
      "id" : 733813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "344136592170033154",
  "text" : "RT @stevenf: Backstage, Tim Cook sips calmly from his morning mint julep. He reclines in an antique oak rocking chair, softly humming a for\u2026",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "344118177585840128",
    "text" : "Backstage, Tim Cook sips calmly from his morning mint julep. He reclines in an antique oak rocking chair, softly humming a forgotten tune.",
    "id" : 344118177585840128,
    "created_at" : "Mon Jun 10 15:45:41 +0000 2013",
    "user" : {
      "name" : "Steven Frank",
      "screen_name" : "stevenf",
      "protected" : false,
      "id_str" : "733813",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/838378818/avatar_normal.png",
      "id" : 733813,
      "verified" : false
    }
  },
  "id" : 344136592170033154,
  "created_at" : "Mon Jun 10 16:58:51 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mari Huertas",
      "screen_name" : "marihuertas",
      "indices" : [ 3, 15 ],
      "id_str" : "195863654",
      "id" : 195863654
    }, {
      "name" : "Hillary Clinton",
      "screen_name" : "HillaryClinton",
      "indices" : [ 27, 42 ],
      "id_str" : "1339835893",
      "id" : 1339835893
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "344122488340480000",
  "text" : "RT @marihuertas: Hey guys? @HillaryClinton. F'real.",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Hillary Clinton",
        "screen_name" : "HillaryClinton",
        "indices" : [ 10, 25 ],
        "id_str" : "1339835893",
        "id" : 1339835893
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "344122056763404288",
    "text" : "Hey guys? @HillaryClinton. F'real.",
    "id" : 344122056763404288,
    "created_at" : "Mon Jun 10 16:01:06 +0000 2013",
    "user" : {
      "name" : "Mari Huertas",
      "screen_name" : "marihuertas",
      "protected" : false,
      "id_str" : "195863654",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3677974911/def7e1e5d51808b9b6146a1330ca5908_normal.jpeg",
      "id" : 195863654,
      "verified" : false
    }
  },
  "id" : 344122488340480000,
  "created_at" : "Mon Jun 10 16:02:49 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PastorDeProyectos",
      "screen_name" : "PastorDeProyect",
      "indices" : [ 0, 16 ],
      "id_str" : "888083341",
      "id" : 888083341
    }, {
      "name" : "Scott Berkun",
      "screen_name" : "berkun",
      "indices" : [ 17, 24 ],
      "id_str" : "30495974",
      "id" : 30495974
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "feelingcontrarytonight",
      "indices" : [ 52, 75 ]
    }, {
      "text" : "survivorshipbias",
      "indices" : [ 76, 93 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "343947292170145792",
  "geo" : {
  },
  "id_str" : "343950408202469376",
  "in_reply_to_user_id" : 888083341,
  "text" : "@PastorDeProyect @berkun That's terrible advice. :) #feelingcontrarytonight #survivorshipbias",
  "id" : 343950408202469376,
  "in_reply_to_status_id" : 343947292170145792,
  "created_at" : "Mon Jun 10 04:39:02 +0000 2013",
  "in_reply_to_screen_name" : "PastorDeProyect",
  "in_reply_to_user_id_str" : "888083341",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Berkun",
      "screen_name" : "berkun",
      "indices" : [ 0, 7 ],
      "id_str" : "30495974",
      "id" : 30495974
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "343947493408657408",
  "geo" : {
  },
  "id_str" : "343949404627156992",
  "in_reply_to_user_id" : 30495974,
  "text" : "@berkun If such a set does exist, it's currently unknowable / a matter of opinion.",
  "id" : 343949404627156992,
  "in_reply_to_status_id" : 343947493408657408,
  "created_at" : "Mon Jun 10 04:35:02 +0000 2013",
  "in_reply_to_screen_name" : "berkun",
  "in_reply_to_user_id_str" : "30495974",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Berkun",
      "screen_name" : "berkun",
      "indices" : [ 0, 7 ],
      "id_str" : "30495974",
      "id" : 30495974
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "343947414010478592",
  "geo" : {
  },
  "id_str" : "343948482647830528",
  "in_reply_to_user_id" : 30495974,
  "text" : "@berkun Technology has solved problems for all of those domains, and will outlast several of them. Do you disagree?",
  "id" : 343948482647830528,
  "in_reply_to_status_id" : 343947414010478592,
  "created_at" : "Mon Jun 10 04:31:23 +0000 2013",
  "in_reply_to_screen_name" : "berkun",
  "in_reply_to_user_id_str" : "30495974",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Berkun",
      "screen_name" : "berkun",
      "indices" : [ 0, 7 ],
      "id_str" : "30495974",
      "id" : 30495974
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "343944092901838849",
  "geo" : {
  },
  "id_str" : "343947149853208576",
  "in_reply_to_user_id" : 30495974,
  "text" : "@berkun What does non-technological mean to you? Technology claims applicability to all problems in the long run.",
  "id" : 343947149853208576,
  "in_reply_to_status_id" : 343944092901838849,
  "created_at" : "Mon Jun 10 04:26:05 +0000 2013",
  "in_reply_to_screen_name" : "berkun",
  "in_reply_to_user_id_str" : "30495974",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http://t.co/lidU1D8cyH",
      "expanded_url" : "http://flic.kr/p/eHvFzx",
      "display_url" : "flic.kr/p/eHvFzx"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.812999, -122.246667 ]
  },
  "id_str" : "343935207759560704",
  "text" : "8:36pm Running back to this bookstore post-dinner in Oakland with Kellianne's cuz http://t.co/lidU1D8cyH",
  "id" : 343935207759560704,
  "created_at" : "Mon Jun 10 03:38:38 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Isaac Hepworth",
      "screen_name" : "isaach",
      "indices" : [ 0, 7 ],
      "id_str" : "7852612",
      "id" : 7852612
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "343903098894446592",
  "geo" : {
  },
  "id_str" : "343903563879161856",
  "in_reply_to_user_id" : 7852612,
  "text" : "@isaach Where's that from?",
  "id" : 343903563879161856,
  "in_reply_to_status_id" : 343903098894446592,
  "created_at" : "Mon Jun 10 01:32:53 +0000 2013",
  "in_reply_to_screen_name" : "isaach",
  "in_reply_to_user_id_str" : "7852612",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Bonner",
      "screen_name" : "seanbonner",
      "indices" : [ 0, 11 ],
      "id_str" : "765",
      "id" : 765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "343834232776445952",
  "geo" : {
  },
  "id_str" : "343836408030564352",
  "in_reply_to_user_id" : 765,
  "text" : "@seanbonner Thanks, deleted.",
  "id" : 343836408030564352,
  "in_reply_to_status_id" : 343834232776445952,
  "created_at" : "Sun Jun 09 21:06:02 +0000 2013",
  "in_reply_to_screen_name" : "seanbonner",
  "in_reply_to_user_id_str" : "765",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "whitney erin boesel",
      "screen_name" : "phenatypical",
      "indices" : [ 3, 16 ],
      "id_str" : "264101497",
      "id" : 264101497
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "343816737524944897",
  "text" : "RT @phenatypical: \"I have no intention of hiding who I am because I know I have done nothing wrong\"\u2014ballsy move from NSA leaker. *wow*: htt\u2026",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http://t.co/gTzB5IbGqB",
        "expanded_url" : "http://www.guardian.co.uk/world/2013/jun/09/edward-snowden-nsa-whistleblower-surveillance",
        "display_url" : "guardian.co.uk/world/2013/jun\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "343809479533531136",
    "text" : "\"I have no intention of hiding who I am because I know I have done nothing wrong\"\u2014ballsy move from NSA leaker. *wow*: http://t.co/gTzB5IbGqB",
    "id" : 343809479533531136,
    "created_at" : "Sun Jun 09 19:19:02 +0000 2013",
    "user" : {
      "name" : "whitney erin boesel",
      "screen_name" : "phenatypical",
      "protected" : false,
      "id_str" : "264101497",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2270262889/sit262rf3jg1n4ne6qp4_normal.jpeg",
      "id" : 264101497,
      "verified" : false
    }
  },
  "id" : 343816737524944897,
  "created_at" : "Sun Jun 09 19:47:52 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mandy Brown",
      "screen_name" : "aworkinglibrary",
      "indices" : [ 3, 19 ],
      "id_str" : "11133442",
      "id" : 11133442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "343743914563485698",
  "text" : "RT @aworkinglibrary: I don\u2019t want breaking news. I want slow, thoughtful, deeply researched news. Especially now.",
  "retweeted_status" : {
    "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "343087061127024640",
    "text" : "I don\u2019t want breaking news. I want slow, thoughtful, deeply researched news. Especially now.",
    "id" : 343087061127024640,
    "created_at" : "Fri Jun 07 19:28:24 +0000 2013",
    "user" : {
      "name" : "Mandy Brown",
      "screen_name" : "aworkinglibrary",
      "protected" : false,
      "id_str" : "11133442",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2919538988/9aeb1ced2ce1134c5eb38038b4c38f3a_normal.jpeg",
      "id" : 11133442,
      "verified" : false
    }
  },
  "id" : 343743914563485698,
  "created_at" : "Sun Jun 09 14:58:30 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 45, 55 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http://t.co/6IG3ADuTZ0",
      "expanded_url" : "http://flic.kr/p/eGDQhz",
      "display_url" : "flic.kr/p/eGDQhz"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.789833, -122.391501 ]
  },
  "id_str" : "343612793062309888",
  "text" : "8:36pm Late:36 of our delightful dinner with @kellianne's old school friends Tom and Allison http://t.co/6IG3ADuTZ0",
  "id" : 343612793062309888,
  "created_at" : "Sun Jun 09 06:17:28 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tiffany Dohzen",
      "screen_name" : "tdohz",
      "indices" : [ 0, 6 ],
      "id_str" : "101424163",
      "id" : 101424163
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "343447673472421888",
  "geo" : {
  },
  "id_str" : "343455849659895809",
  "in_reply_to_user_id" : 101424163,
  "text" : "@tdohz Yeah but we all know that that would make the project completely useless.",
  "id" : 343455849659895809,
  "in_reply_to_status_id" : 343447673472421888,
  "created_at" : "Sat Jun 08 19:53:50 +0000 2013",
  "in_reply_to_screen_name" : "tdohz",
  "in_reply_to_user_id_str" : "101424163",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Neilson",
      "screen_name" : "TheCulprit",
      "indices" : [ 0, 11 ],
      "id_str" : "6726182",
      "id" : 6726182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "343452994194530304",
  "geo" : {
  },
  "id_str" : "343455369110122496",
  "in_reply_to_user_id" : 6726182,
  "text" : "@TheCulprit That would be awesome.",
  "id" : 343455369110122496,
  "in_reply_to_status_id" : 343452994194530304,
  "created_at" : "Sat Jun 08 19:51:55 +0000 2013",
  "in_reply_to_screen_name" : "TheCulprit",
  "in_reply_to_user_id_str" : "6726182",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "harryh",
      "screen_name" : "harryh",
      "indices" : [ 0, 7 ],
      "id_str" : "4558",
      "id" : 4558
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "343449609412153344",
  "geo" : {
  },
  "id_str" : "343452022005190656",
  "in_reply_to_user_id" : 4558,
  "text" : "@harryh Yeah, but at the same time is ad targeting the best use of unlimited data access? Making things relevant... so evil!",
  "id" : 343452022005190656,
  "in_reply_to_status_id" : 343449609412153344,
  "created_at" : "Sat Jun 08 19:38:37 +0000 2013",
  "in_reply_to_screen_name" : "harryh",
  "in_reply_to_user_id_str" : "4558",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "harryh",
      "screen_name" : "harryh",
      "indices" : [ 0, 7 ],
      "id_str" : "4558",
      "id" : 4558
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "343448073508376576",
  "geo" : {
  },
  "id_str" : "343449286182318080",
  "in_reply_to_user_id" : 4558,
  "text" : "@harryh Greatest minds of our generation, etc. :)",
  "id" : 343449286182318080,
  "in_reply_to_status_id" : 343448073508376576,
  "created_at" : "Sat Jun 08 19:27:45 +0000 2013",
  "in_reply_to_screen_name" : "harryh",
  "in_reply_to_user_id_str" : "4558",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hackweek",
      "indices" : [ 86, 95 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "343446967562670080",
  "text" : "If you had access to all the data that NSA supposedly has, what would you do with it? #hackweek",
  "id" : 343446967562670080,
  "created_at" : "Sat Jun 08 19:18:32 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Stump",
      "screen_name" : "joestump",
      "indices" : [ 0, 9 ],
      "id_str" : "4234581",
      "id" : 4234581
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "343442187599622144",
  "geo" : {
  },
  "id_str" : "343443110560399360",
  "in_reply_to_user_id" : 4234581,
  "text" : "@joestump I'm surprised by the reverse.",
  "id" : 343443110560399360,
  "in_reply_to_status_id" : 343442187599622144,
  "created_at" : "Sat Jun 08 19:03:13 +0000 2013",
  "in_reply_to_screen_name" : "joestump",
  "in_reply_to_user_id_str" : "4234581",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "343441993495625728",
  "text" : "And if they did find meaning somehow, I think there's more chance of it benefiting me than harming me.",
  "id" : 343441993495625728,
  "created_at" : "Sat Jun 08 18:58:46 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "343441515781185538",
  "text" : "I honestly have no problem with being tracked. Everyone track me! As someone obsessed with data, I know how difficult it is to find meaning.",
  "id" : 343441515781185538,
  "created_at" : "Sat Jun 08 18:56:52 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Bonner",
      "screen_name" : "seanbonner",
      "indices" : [ 0, 11 ],
      "id_str" : "765",
      "id" : 765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "343412805195669504",
  "geo" : {
  },
  "id_str" : "343417357403824131",
  "in_reply_to_user_id" : 765,
  "text" : "@seanbonner Yeah, when all tech companies were by friends. I feel like there's still a core group of friendly companies/people in tech.",
  "id" : 343417357403824131,
  "in_reply_to_status_id" : 343412805195669504,
  "created_at" : "Sat Jun 08 17:20:53 +0000 2013",
  "in_reply_to_screen_name" : "seanbonner",
  "in_reply_to_user_id_str" : "765",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mari Huertas",
      "screen_name" : "marihuertas",
      "indices" : [ 0, 12 ],
      "id_str" : "195863654",
      "id" : 195863654
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "343245413568110594",
  "geo" : {
  },
  "id_str" : "343249708212445184",
  "in_reply_to_user_id" : 195863654,
  "text" : "@marihuertas Dying of suspense over here!",
  "id" : 343249708212445184,
  "in_reply_to_status_id" : 343245413568110594,
  "created_at" : "Sat Jun 08 06:14:42 +0000 2013",
  "in_reply_to_screen_name" : "marihuertas",
  "in_reply_to_user_id_str" : "195863654",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "~",
      "screen_name" : "iano",
      "indices" : [ 0, 5 ],
      "id_str" : "14409856",
      "id" : 14409856
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "343238684138684416",
  "geo" : {
  },
  "id_str" : "343249068836937728",
  "in_reply_to_user_id" : 14409856,
  "text" : "@iano You rang?",
  "id" : 343249068836937728,
  "in_reply_to_status_id" : 343238684138684416,
  "created_at" : "Sat Jun 08 06:12:09 +0000 2013",
  "in_reply_to_screen_name" : "iano",
  "in_reply_to_user_id_str" : "14409856",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 37 ],
      "url" : "http://t.co/7mepIFskxK",
      "expanded_url" : "http://flic.kr/p/eFLaYe",
      "display_url" : "flic.kr/p/eFLaYe"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859666, -122.2755 ]
  },
  "id_str" : "343210186363768832",
  "text" : "8:36pm Ti-red. http://t.co/7mepIFskxK",
  "id" : 343210186363768832,
  "created_at" : "Sat Jun 08 03:37:39 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jana Messerschmidt",
      "screen_name" : "janamal",
      "indices" : [ 0, 8 ],
      "id_str" : "15526110",
      "id" : 15526110
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "343176395930882048",
  "geo" : {
  },
  "id_str" : "343185284097265664",
  "in_reply_to_user_id" : 15526110,
  "text" : "@janamal I had a great time and made good progress on ideas... thanks for including us.",
  "id" : 343185284097265664,
  "in_reply_to_status_id" : 343176395930882048,
  "created_at" : "Sat Jun 08 01:58:42 +0000 2013",
  "in_reply_to_screen_name" : "janamal",
  "in_reply_to_user_id_str" : "15526110",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "343120150935007232",
  "text" : "\uD83D\uDCA5",
  "id" : 343120150935007232,
  "created_at" : "Fri Jun 07 21:39:53 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tapestry",
      "screen_name" : "tapestry",
      "indices" : [ 3, 12 ],
      "id_str" : "2533401",
      "id" : 2533401
    }, {
      "name" : "Buster",
      "screen_name" : "buster",
      "indices" : [ 79, 86 ],
      "id_str" : "2185",
      "id" : 2185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "343115740473344000",
  "text" : "RT @tapestry: \"If you live 100 times, one of you will die in your first year.\" @buster (one of our most popular stories this week) https://\u2026",
  "retweeted_status" : {
    "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Buster",
        "screen_name" : "buster",
        "indices" : [ 65, 72 ],
        "id_str" : "2185",
        "id" : 2185
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https://t.co/XE2U4fPuaI",
        "expanded_url" : "https://readtapestry.com/s/RVwPvalHq/",
        "display_url" : "readtapestry.com/s/RVwPvalHq/"
      } ]
    },
    "geo" : {
    },
    "id_str" : "343076937863942144",
    "text" : "\"If you live 100 times, one of you will die in your first year.\" @buster (one of our most popular stories this week) https://t.co/XE2U4fPuaI",
    "id" : 343076937863942144,
    "created_at" : "Fri Jun 07 18:48:10 +0000 2013",
    "user" : {
      "name" : "Tapestry",
      "screen_name" : "tapestry",
      "protected" : false,
      "id_str" : "2533401",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000074844294/c8b7e4fc0584dd4e92d5298eee416056_normal.png",
      "id" : 2533401,
      "verified" : false
    }
  },
  "id" : 343115740473344000,
  "created_at" : "Fri Jun 07 21:22:22 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "timoni west",
      "screen_name" : "timoni",
      "indices" : [ 3, 10 ],
      "id_str" : "12615",
      "id" : 12615
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http://t.co/5N0wI7KMuC",
      "expanded_url" : "http://blog.timoni.org/post/52383501463/this-feature-exposes-our-closest-friends",
      "display_url" : "blog.timoni.org/post/523835014\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "343030257181409280",
  "text" : "RT @timoni: Privacy as a means of hiding bad behavior is still so oddly pervasive; almost thought of as a right:  http://t.co/5N0wI7KMuC",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 102, 124 ],
        "url" : "http://t.co/5N0wI7KMuC",
        "expanded_url" : "http://blog.timoni.org/post/52383501463/this-feature-exposes-our-closest-friends",
        "display_url" : "blog.timoni.org/post/523835014\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "343028680269897730",
    "text" : "Privacy as a means of hiding bad behavior is still so oddly pervasive; almost thought of as a right:  http://t.co/5N0wI7KMuC",
    "id" : 343028680269897730,
    "created_at" : "Fri Jun 07 15:36:25 +0000 2013",
    "user" : {
      "name" : "timoni west",
      "screen_name" : "timoni",
      "protected" : false,
      "id_str" : "12615",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3597371770/b7586ff9b8b06a17f7bffeaf1b603d55_normal.png",
      "id" : 12615,
      "verified" : false
    }
  },
  "id" : 343030257181409280,
  "created_at" : "Fri Jun 07 15:42:41 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jack Cheng",
      "screen_name" : "jackcheng",
      "indices" : [ 0, 10 ],
      "id_str" : "146703",
      "id" : 146703
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342773672202891264",
  "geo" : {
  },
  "id_str" : "343028805398577152",
  "in_reply_to_user_id" : 146703,
  "text" : "@jackcheng No, but it looks awesome. I did read the Grisham novel a while back but this looks better. Have you read it?",
  "id" : 343028805398577152,
  "in_reply_to_status_id" : 342773672202891264,
  "created_at" : "Fri Jun 07 15:36:55 +0000 2013",
  "in_reply_to_screen_name" : "jackcheng",
  "in_reply_to_user_id_str" : "146703",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Liam Moore",
      "screen_name" : "ismooreliam",
      "indices" : [ 0, 12 ],
      "id_str" : "219687529",
      "id" : 219687529
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342912906129731584",
  "geo" : {
  },
  "id_str" : "343024008582807552",
  "in_reply_to_user_id" : 219687529,
  "text" : "@ismooreliam It's subjective all the way down!",
  "id" : 343024008582807552,
  "in_reply_to_status_id" : 342912906129731584,
  "created_at" : "Fri Jun 07 15:17:51 +0000 2013",
  "in_reply_to_screen_name" : "ismooreliam",
  "in_reply_to_user_id_str" : "219687529",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 66 ],
      "url" : "http://t.co/FDTeyyrfuW",
      "expanded_url" : "http://flic.kr/p/eF24Ep",
      "display_url" : "flic.kr/p/eF24Ep"
    } ]
  },
  "geo" : {
  },
  "id_str" : "342862791075581952",
  "text" : "8:36pm Date night with my beauteous maximus http://t.co/FDTeyyrfuW",
  "id" : 342862791075581952,
  "created_at" : "Fri Jun 07 04:37:14 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "datenight",
      "indices" : [ 0, 10 ]
    } ],
    "urls" : [ {
      "indices" : [ 46, 68 ],
      "url" : "http://t.co/ItOjpwClLR",
      "expanded_url" : "http://4sq.com/15Qjo4P",
      "display_url" : "4sq.com/15Qjo4P"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8093096726, -122.2727465667 ]
  },
  "id_str" : "342842218966556672",
  "text" : "#datenight (@ Hopscotch Restaurant &amp; Bar) http://t.co/ItOjpwClLR",
  "id" : 342842218966556672,
  "created_at" : "Fri Jun 07 03:15:29 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "startupidea",
      "indices" : [ 4, 16 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "342774280616046592",
  "text" : "New #startupidea: Find My Phone app that only uses NSA data.",
  "id" : 342774280616046592,
  "created_at" : "Thu Jun 06 22:45:31 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "342772871657037825",
  "text" : "Startup idea: nanobots that live on our teeth &amp; gums and text us when we have early signs of trouble.",
  "id" : 342772871657037825,
  "created_at" : "Thu Jun 06 22:39:55 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Spurlin",
      "screen_name" : "samspurlin",
      "indices" : [ 0, 11 ],
      "id_str" : "14544979",
      "id" : 14544979
    }, {
      "name" : "99U",
      "screen_name" : "99u",
      "indices" : [ 12, 16 ],
      "id_str" : "17636894",
      "id" : 17636894
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342756262024470529",
  "geo" : {
  },
  "id_str" : "342768552908054528",
  "in_reply_to_user_id" : 14544979,
  "text" : "@samspurlin @99u Thanks! And sorry that I lost you a reader in the comments. :)",
  "id" : 342768552908054528,
  "in_reply_to_status_id" : 342756262024470529,
  "created_at" : "Thu Jun 06 22:22:45 +0000 2013",
  "in_reply_to_screen_name" : "samspurlin",
  "in_reply_to_user_id_str" : "14544979",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Britt Crawford",
      "screen_name" : "britt",
      "indices" : [ 0, 6 ],
      "id_str" : "5362",
      "id" : 5362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342674442553536513",
  "geo" : {
  },
  "id_str" : "342674911552233472",
  "in_reply_to_user_id" : 5362,
  "text" : "@britt Ah, that's the recommendation I was waiting for. Thanks!",
  "id" : 342674911552233472,
  "in_reply_to_status_id" : 342674442553536513,
  "created_at" : "Thu Jun 06 16:10:40 +0000 2013",
  "in_reply_to_screen_name" : "britt",
  "in_reply_to_user_id_str" : "5362",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay Holler",
      "screen_name" : "jayholler",
      "indices" : [ 0, 10 ],
      "id_str" : "14110325",
      "id" : 14110325
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342524385606893568",
  "geo" : {
  },
  "id_str" : "342524671364833280",
  "in_reply_to_user_id" : 14110325,
  "text" : "@jayholler Awesome! Thanks for the rec, I'll check them out.",
  "id" : 342524671364833280,
  "in_reply_to_status_id" : 342524385606893568,
  "created_at" : "Thu Jun 06 06:13:40 +0000 2013",
  "in_reply_to_screen_name" : "jayholler",
  "in_reply_to_user_id_str" : "14110325",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "david reeves",
      "screen_name" : "dreeves",
      "indices" : [ 0, 8 ],
      "id_str" : "947851",
      "id" : 947851
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342521441415229440",
  "geo" : {
  },
  "id_str" : "342523603914473473",
  "in_reply_to_user_id" : 947851,
  "text" : "@dreeves I hurt it by being over-zealous on a run and in particular on a steep downhill. Madison, between 18th and 28th, in particular.",
  "id" : 342523603914473473,
  "in_reply_to_status_id" : 342521441415229440,
  "created_at" : "Thu Jun 06 06:09:25 +0000 2013",
  "in_reply_to_screen_name" : "dreeves",
  "in_reply_to_user_id_str" : "947851",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http://t.co/CkfvQNhwbQ",
      "expanded_url" : "http://bit.ly/ZQRoPn",
      "display_url" : "bit.ly/ZQRoPn"
    } ]
  },
  "in_reply_to_status_id_str" : "342518556803600386",
  "geo" : {
  },
  "id_str" : "342520573651468288",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez I saw that a while ago. I took it again and scored 4 for ITBS and 5 for PFPS. I think it might actually be http://t.co/CkfvQNhwbQ",
  "id" : 342520573651468288,
  "in_reply_to_status_id" : 342518556803600386,
  "created_at" : "Thu Jun 06 05:57:23 +0000 2013",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Reichhold",
      "screen_name" : "jreichhold",
      "indices" : [ 0, 11 ],
      "id_str" : "14934401",
      "id" : 14934401
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342517816508952576",
  "geo" : {
  },
  "id_str" : "342517915939131392",
  "in_reply_to_user_id" : 14934401,
  "text" : "@jreichhold Yeah, that wouldn't be much of a problem.",
  "id" : 342517915939131392,
  "in_reply_to_status_id" : 342517816508952576,
  "created_at" : "Thu Jun 06 05:46:49 +0000 2013",
  "in_reply_to_screen_name" : "jreichhold",
  "in_reply_to_user_id_str" : "14934401",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Reichhold",
      "screen_name" : "jreichhold",
      "indices" : [ 0, 11 ],
      "id_str" : "14934401",
      "id" : 14934401
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342517609301954560",
  "geo" : {
  },
  "id_str" : "342517798406352896",
  "in_reply_to_user_id" : 14934401,
  "text" : "@jreichhold Any recommendations for people in SF? :)",
  "id" : 342517798406352896,
  "in_reply_to_status_id" : 342517609301954560,
  "created_at" : "Thu Jun 06 05:46:21 +0000 2013",
  "in_reply_to_screen_name" : "jreichhold",
  "in_reply_to_user_id_str" : "14934401",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Reichhold",
      "screen_name" : "jreichhold",
      "indices" : [ 0, 11 ],
      "id_str" : "14934401",
      "id" : 14934401
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342516692330627072",
  "geo" : {
  },
  "id_str" : "342517194070061057",
  "in_reply_to_user_id" : 14934401,
  "text" : "@jreichhold Left leg, under the kneecap in the front and on the inner side of my leg. It sometimes has shooting pain up the leg too.",
  "id" : 342517194070061057,
  "in_reply_to_status_id" : 342516692330627072,
  "created_at" : "Thu Jun 06 05:43:57 +0000 2013",
  "in_reply_to_screen_name" : "jreichhold",
  "in_reply_to_user_id_str" : "14934401",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Reichhold",
      "screen_name" : "jreichhold",
      "indices" : [ 0, 11 ],
      "id_str" : "14934401",
      "id" : 14934401
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342515923774746624",
  "geo" : {
  },
  "id_str" : "342516177949569024",
  "in_reply_to_user_id" : 14934401,
  "text" : "@jreichhold No idea really. Every description I read seems to be a little off from my experience. Haven't seen anyone about it yet either.",
  "id" : 342516177949569024,
  "in_reply_to_status_id" : 342515923774746624,
  "created_at" : "Thu Jun 06 05:39:55 +0000 2013",
  "in_reply_to_screen_name" : "jreichhold",
  "in_reply_to_user_id_str" : "14934401",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "342516030754672640",
  "text" : "Can anyone recommend an orthopedist in SF or Berkeley that would have experience diagnosing runner's knee?",
  "id" : 342516030754672640,
  "created_at" : "Thu Jun 06 05:39:20 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342514894777749504",
  "geo" : {
  },
  "id_str" : "342515814135640064",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez I suppose so, if it could be conclusive.",
  "id" : 342515814135640064,
  "in_reply_to_status_id" : 342514894777749504,
  "created_at" : "Thu Jun 06 05:38:28 +0000 2013",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342514241611366400",
  "geo" : {
  },
  "id_str" : "342514444854784001",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez Is there a simple test that could conclusively determine if it's one or the other?",
  "id" : 342514444854784001,
  "in_reply_to_status_id" : 342514241611366400,
  "created_at" : "Thu Jun 06 05:33:01 +0000 2013",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "342514128323235842",
  "text" : "I haven't run since March, and it still consistently hurts when walking, sitting cross-legged, etc. It's just not going away on its own.",
  "id" : 342514128323235842,
  "created_at" : "Thu Jun 06 05:31:46 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anil Dash",
      "screen_name" : "anildash",
      "indices" : [ 0, 9 ],
      "id_str" : "36823",
      "id" : 36823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342513593062936578",
  "geo" : {
  },
  "id_str" : "342513924912082944",
  "in_reply_to_user_id" : 36823,
  "text" : "@anildash Which exercises helped you most?",
  "id" : 342513924912082944,
  "in_reply_to_status_id" : 342513593062936578,
  "created_at" : "Thu Jun 06 05:30:57 +0000 2013",
  "in_reply_to_screen_name" : "anildash",
  "in_reply_to_user_id_str" : "36823",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342513512297414656",
  "geo" : {
  },
  "id_str" : "342513848521207808",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez I've read up on a bunch and it seems inconclusive (I haven't had it checked out).",
  "id" : 342513848521207808,
  "in_reply_to_status_id" : 342513512297414656,
  "created_at" : "Thu Jun 06 05:30:39 +0000 2013",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "342513635840626689",
  "text" : "I stretch and do lunges regularly. I probably need a knee brace (which one)? And I should probably see someone (who?).",
  "id" : 342513635840626689,
  "created_at" : "Thu Jun 06 05:29:49 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "342513289995091968",
  "text" : "I hurt my knee last Oct, but foolishly didn't stop running til Mar. Now it hurts all the time. I want to run a marathon in Sept. Advice?",
  "id" : 342513289995091968,
  "created_at" : "Thu Jun 06 05:28:26 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http://t.co/miqTvNZqpm",
      "expanded_url" : "http://flic.kr/p/eEbD4X",
      "display_url" : "flic.kr/p/eEbD4X"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859666, -122.2755 ]
  },
  "id_str" : "342485940431888386",
  "text" : "8:36pm Niko's photo of the day is a close-up of our hamper http://t.co/miqTvNZqpm",
  "id" : 342485940431888386,
  "created_at" : "Thu Jun 06 03:39:45 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http://t.co/0RxwAbFEtf",
      "expanded_url" : "http://readtapestry.com/s/RVwPvalHq/?p=23",
      "display_url" : "readtapestry.com/s/RVwPvalHq/?p\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "342449365979381760",
  "text" : "If you lived 100 times, what do you think the last two of you would be like? http://t.co/0RxwAbFEtf",
  "id" : 342449365979381760,
  "created_at" : "Thu Jun 06 01:14:25 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Neil deGrasse Tyson",
      "screen_name" : "neiltyson",
      "indices" : [ 0, 10 ],
      "id_str" : "19725644",
      "id" : 19725644
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342443434033942530",
  "geo" : {
  },
  "id_str" : "342444475022458880",
  "in_reply_to_user_id" : 19725644,
  "text" : "@neiltyson Feelings aren't known for taking Bayesian priors very seriously.",
  "id" : 342444475022458880,
  "in_reply_to_status_id" : 342443434033942530,
  "created_at" : "Thu Jun 06 00:54:59 +0000 2013",
  "in_reply_to_screen_name" : "neiltyson",
  "in_reply_to_user_id_str" : "19725644",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Medium",
      "screen_name" : "Medium",
      "indices" : [ 3, 10 ],
      "id_str" : "571202103",
      "id" : 571202103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 75 ],
      "url" : "https://t.co/9WRHIKKynz",
      "expanded_url" : "https://medium.com/writers-on-writing/2018f8c30c83?utm_source=TwitterAccount&utm_medium=Twitter&utm_campaign=TwitterAccount",
      "display_url" : "medium.com/writers-on-wri\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "342378489153978368",
  "text" : "RT @Medium: \"Your Brain Is Broken\" @sinincorporated https://t.co/9WRHIKKynz",
  "retweeted_status" : {
    "source" : "<a href=\"http://sproutsocial.com\" rel=\"nofollow\">Sprout Social</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 40, 63 ],
        "url" : "https://t.co/9WRHIKKynz",
        "expanded_url" : "https://medium.com/writers-on-writing/2018f8c30c83?utm_source=TwitterAccount&utm_medium=Twitter&utm_campaign=TwitterAccount",
        "display_url" : "medium.com/writers-on-wri\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "342377891704737792",
    "text" : "\"Your Brain Is Broken\" @sinincorporated https://t.co/9WRHIKKynz",
    "id" : 342377891704737792,
    "created_at" : "Wed Jun 05 20:30:25 +0000 2013",
    "user" : {
      "name" : "Medium",
      "screen_name" : "Medium",
      "protected" : false,
      "id_str" : "571202103",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2504297462/wtbq3hoquj8no6t2ysz4_normal.jpeg",
      "id" : 571202103,
      "verified" : true
    }
  },
  "id" : 342378489153978368,
  "created_at" : "Wed Jun 05 20:32:47 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jessica Scheibach",
      "screen_name" : "jshy",
      "indices" : [ 0, 5 ],
      "id_str" : "804659",
      "id" : 804659
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342377554931486722",
  "geo" : {
  },
  "id_str" : "342377993836044289",
  "in_reply_to_user_id" : 804659,
  "text" : "@jshy I'd settle for WITH!",
  "id" : 342377993836044289,
  "in_reply_to_status_id" : 342377554931486722,
  "created_at" : "Wed Jun 05 20:30:49 +0000 2013",
  "in_reply_to_screen_name" : "jshy",
  "in_reply_to_user_id_str" : "804659",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jessica Scheibach",
      "screen_name" : "jshy",
      "indices" : [ 0, 5 ],
      "id_str" : "804659",
      "id" : 804659
    }, {
      "name" : "ArielMeadowStallings",
      "screen_name" : "OffbeatAriel",
      "indices" : [ 6, 19 ],
      "id_str" : "14095370",
      "id" : 14095370
    }, {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 20, 30 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342368566089232384",
  "geo" : {
  },
  "id_str" : "342375578940354560",
  "in_reply_to_user_id" : 804659,
  "text" : "@jshy @OffbeatAriel @kellianne Jess taught me a ton about product, and played a BIG role in getting me my first developer job. Thanks, Jess!",
  "id" : 342375578940354560,
  "in_reply_to_status_id" : 342368566089232384,
  "created_at" : "Wed Jun 05 20:21:13 +0000 2013",
  "in_reply_to_screen_name" : "jshy",
  "in_reply_to_user_id_str" : "804659",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TweetDeck",
      "screen_name" : "TweetDeck",
      "indices" : [ 24, 34 ],
      "id_str" : "14803701",
      "id" : 14803701
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https://t.co/F6HgvOpgbd",
      "expanded_url" : "https://blog.twitter.com/2013/introducing-new-look-tweetdeck",
      "display_url" : "blog.twitter.com/2013/introduci\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "342347265412841472",
  "text" : "TweetDeck is my jam. RT @TweetDeck: Introducing a new look for TweetDeck - lighter and simpler design: https://t.co/F6HgvOpgbd",
  "id" : 342347265412841472,
  "created_at" : "Wed Jun 05 18:28:43 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "William Morgan",
      "screen_name" : "wm",
      "indices" : [ 0, 3 ],
      "id_str" : "15504330",
      "id" : 15504330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342327762482233344",
  "geo" : {
  },
  "id_str" : "342344504583528448",
  "in_reply_to_user_id" : 15504330,
  "text" : "@wm I think so!!!",
  "id" : 342344504583528448,
  "in_reply_to_status_id" : 342327762482233344,
  "created_at" : "Wed Jun 05 18:17:45 +0000 2013",
  "in_reply_to_screen_name" : "wm",
  "in_reply_to_user_id_str" : "15504330",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    }, {
      "name" : "Nick Crocker",
      "screen_name" : "nickcrocker",
      "indices" : [ 68, 80 ],
      "id_str" : "30801469",
      "id" : 30801469
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342342460095221760",
  "geo" : {
  },
  "id_str" : "342344116144836608",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez That's closer to my personal take, at least. Curious what @nickcrocker thinks.",
  "id" : 342344116144836608,
  "in_reply_to_status_id" : 342342460095221760,
  "created_at" : "Wed Jun 05 18:16:12 +0000 2013",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernesto Ramirez",
      "screen_name" : "eramirez",
      "indices" : [ 0, 9 ],
      "id_str" : "21135674",
      "id" : 21135674
    }, {
      "name" : "Nick Crocker",
      "screen_name" : "nickcrocker",
      "indices" : [ 10, 22 ],
      "id_str" : "30801469",
      "id" : 30801469
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342341771264659458",
  "geo" : {
  },
  "id_str" : "342342217509265409",
  "in_reply_to_user_id" : 21135674,
  "text" : "@eramirez @nickcrocker I think a time capsule might be too easily forgotten. The key is to think about the 10yr self regularly (monthly?).",
  "id" : 342342217509265409,
  "in_reply_to_status_id" : 342341771264659458,
  "created_at" : "Wed Jun 05 18:08:39 +0000 2013",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Crocker",
      "screen_name" : "nickcrocker",
      "indices" : [ 0, 12 ],
      "id_str" : "30801469",
      "id" : 30801469
    }, {
      "name" : "Sessions",
      "screen_name" : "joinsessions",
      "indices" : [ 111, 124 ],
      "id_str" : "360907906",
      "id" : 360907906
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "342339278560448512",
  "in_reply_to_user_id" : 30801469,
  "text" : "@nickcrocker I really think you're on to something with this 10 year goal thing. Are you incorporating it into @joinsessions?",
  "id" : 342339278560448512,
  "created_at" : "Wed Jun 05 17:56:59 +0000 2013",
  "in_reply_to_screen_name" : "nickcrocker",
  "in_reply_to_user_id_str" : "30801469",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fred Sharples",
      "screen_name" : "fredsharples",
      "indices" : [ 0, 13 ],
      "id_str" : "18338254",
      "id" : 18338254
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342318738479149057",
  "geo" : {
  },
  "id_str" : "342321037406531584",
  "in_reply_to_user_id" : 18338254,
  "text" : "@fredsharples Thanks! The data goes deep, this is just the surface. I wish more people were be playing around with it!",
  "id" : 342321037406531584,
  "in_reply_to_status_id" : 342318738479149057,
  "created_at" : "Wed Jun 05 16:44:29 +0000 2013",
  "in_reply_to_screen_name" : "fredsharples",
  "in_reply_to_user_id_str" : "18338254",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tapestry",
      "screen_name" : "tapestry",
      "indices" : [ 92, 101 ],
      "id_str" : "2533401",
      "id" : 2533401
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https://t.co/M8cPpqDMmg",
      "expanded_url" : "https://readtapestry.com/s/RVwPvalHq/",
      "display_url" : "readtapestry.com/s/RVwPvalHq/"
    } ]
  },
  "geo" : {
  },
  "id_str" : "342310140483100672",
  "text" : "My morbid tale of predicting my year of death, now even morbid-er as a tap essay on the new @tapestry! https://t.co/M8cPpqDMmg",
  "id" : 342310140483100672,
  "created_at" : "Wed Jun 05 16:01:11 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benjamin Hawkyard",
      "screen_name" : "nhqe",
      "indices" : [ 0, 5 ],
      "id_str" : "44999727",
      "id" : 44999727
    }, {
      "name" : "Nick Crocker",
      "screen_name" : "nickcrocker",
      "indices" : [ 6, 18 ],
      "id_str" : "30801469",
      "id" : 30801469
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342290617004593153",
  "geo" : {
  },
  "id_str" : "342293552086278144",
  "in_reply_to_user_id" : 44999727,
  "text" : "@nhqe @nickcrocker Name them!",
  "id" : 342293552086278144,
  "in_reply_to_status_id" : 342290617004593153,
  "created_at" : "Wed Jun 05 14:55:16 +0000 2013",
  "in_reply_to_screen_name" : "nhqe",
  "in_reply_to_user_id_str" : "44999727",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Crocker",
      "screen_name" : "nickcrocker",
      "indices" : [ 101, 113 ],
      "id_str" : "30801469",
      "id" : 30801469
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https://t.co/3KK4p71s1I",
      "expanded_url" : "https://medium.com/health-the-future/a2f8856d7c20",
      "display_url" : "medium.com/health-the-fut\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "342289278203723776",
  "text" : "How do I sign up? \"My new goal is to lose 1 pound in the next 10 years.\" https://t.co/3KK4p71s1I /by @nickcrocker",
  "id" : 342289278203723776,
  "created_at" : "Wed Jun 05 14:38:18 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Isaac Hepworth",
      "screen_name" : "isaach",
      "indices" : [ 0, 7 ],
      "id_str" : "7852612",
      "id" : 7852612
    }, {
      "name" : "dick costolo",
      "screen_name" : "dickc",
      "indices" : [ 127, 133 ],
      "id_str" : "6385432",
      "id" : 6385432
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342284679770144769",
  "geo" : {
  },
  "id_str" : "342288360687161344",
  "in_reply_to_user_id" : 7852612,
  "text" : "@isaach OH \"To know that you tweet what you tweet, and that you do not tweet what you do not tweet, that is true knowledge.\" - @dickc",
  "id" : 342288360687161344,
  "in_reply_to_status_id" : 342284679770144769,
  "created_at" : "Wed Jun 05 14:34:39 +0000 2013",
  "in_reply_to_screen_name" : "isaach",
  "in_reply_to_user_id_str" : "7852612",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grant Monroe",
      "screen_name" : "tnarg",
      "indices" : [ 3, 9 ],
      "id_str" : "36519354",
      "id" : 36519354
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "342284560471572480",
  "text" : "RT @tnarg: Historical fiction is kind of like fan fiction for reality.",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "342283409063821312",
    "text" : "Historical fiction is kind of like fan fiction for reality.",
    "id" : 342283409063821312,
    "created_at" : "Wed Jun 05 14:14:58 +0000 2013",
    "user" : {
      "name" : "Grant Monroe",
      "screen_name" : "tnarg",
      "protected" : false,
      "id_str" : "36519354",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000037403801/3a6a5d63dff13e8287e420fda9ca126d_normal.jpeg",
      "id" : 36519354,
      "verified" : false
    }
  },
  "id" : 342284560471572480,
  "created_at" : "Wed Jun 05 14:19:33 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http://t.co/UvWOvVqDJj",
      "expanded_url" : "http://bit.ly/1b3hOwL",
      "display_url" : "bit.ly/1b3hOwL"
    } ]
  },
  "geo" : {
  },
  "id_str" : "342184308406095872",
  "text" : "\"Experimenting with subjectivity\" - Way of the Duck http://t.co/UvWOvVqDJj",
  "id" : 342184308406095872,
  "created_at" : "Wed Jun 05 07:41:11 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sara Mauskopf",
      "screen_name" : "sm",
      "indices" : [ 0, 3 ],
      "id_str" : "22273667",
      "id" : 22273667
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "342126004837429249",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596193424, -122.275636716 ]
  },
  "id_str" : "342126657374658563",
  "in_reply_to_user_id" : 22273667,
  "text" : "@sm It's a mish mash of Brio, Thomas, and organic hippy trains. Some tracks have to be forced together with pliers.",
  "id" : 342126657374658563,
  "in_reply_to_status_id" : 342126004837429249,
  "created_at" : "Wed Jun 05 03:52:06 +0000 2013",
  "in_reply_to_screen_name" : "sm",
  "in_reply_to_user_id_str" : "22273667",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 55 ],
      "url" : "http://t.co/MEUNVWs8tE",
      "expanded_url" : "http://flic.kr/p/eDoJW7",
      "display_url" : "flic.kr/p/eDoJW7"
    } ]
  },
  "geo" : {
  },
  "id_str" : "342124841123577856",
  "text" : "8:36pm Playin' trains. As we do. http://t.co/MEUNVWs8tE",
  "id" : 342124841123577856,
  "created_at" : "Wed Jun 05 03:44:53 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cameron Marlow",
      "screen_name" : "cameronmarlow",
      "indices" : [ 0, 14 ],
      "id_str" : "5491",
      "id" : 5491
    }, {
      "name" : "Anil Dash",
      "screen_name" : "anildash",
      "indices" : [ 15, 24 ],
      "id_str" : "36823",
      "id" : 36823
    }, {
      "name" : "Andy Baio",
      "screen_name" : "waxpancake",
      "indices" : [ 25, 36 ],
      "id_str" : "13461",
      "id" : 13461
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "341968637353136129",
  "geo" : {
  },
  "id_str" : "341969172902854656",
  "in_reply_to_user_id" : 5491,
  "text" : "@cameronmarlow @anildash @waxpancake Long llve Blogdex!",
  "id" : 341969172902854656,
  "in_reply_to_status_id" : 341968637353136129,
  "created_at" : "Tue Jun 04 17:26:18 +0000 2013",
  "in_reply_to_screen_name" : "cameronmarlow",
  "in_reply_to_user_id_str" : "5491",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elyssa Toda",
      "screen_name" : "Elyssa",
      "indices" : [ 9, 16 ],
      "id_str" : "20193866",
      "id" : 20193866
    }, {
      "name" : "KC James",
      "screen_name" : "iamkcjames",
      "indices" : [ 50, 61 ],
      "id_str" : "353954626",
      "id" : 353954626
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "vine",
      "indices" : [ 37, 42 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https://t.co/Uix9IQkMkl",
      "expanded_url" : "https://vine.co/v/bYDwAOzhrJt",
      "display_url" : "vine.co/v/bYDwAOzhrJt"
    } ]
  },
  "in_reply_to_status_id_str" : "341955592837009408",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7764819768, -122.4166893916 ]
  },
  "id_str" : "341960789525143553",
  "in_reply_to_user_id" : 20193866,
  "text" : "Done. RT @Elyssa: follow this guy on #vine now RT @iamkcjames How to recover from an embarrassing trip up stairs https://t.co/Uix9IQkMkl",
  "id" : 341960789525143553,
  "in_reply_to_status_id" : 341955592837009408,
  "created_at" : "Tue Jun 04 16:53:00 +0000 2013",
  "in_reply_to_screen_name" : "Elyssa",
  "in_reply_to_user_id_str" : "20193866",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.783822808, -122.403990612 ]
  },
  "id_str" : "341956421740544001",
  "text" : "The past's future is pretty awesome.",
  "id" : 341956421740544001,
  "created_at" : "Tue Jun 04 16:35:38 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lane Becker",
      "screen_name" : "monstro",
      "indices" : [ 108, 116 ],
      "id_str" : "4030",
      "id" : 4030
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "madmen",
      "indices" : [ 117, 124 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http://t.co/O2ZFEF1Sra",
      "expanded_url" : "http://mobile.slate.com/articles/arts/tv_club/features/2013/mad_men_season_6/week_9/mad_men_recap_solving_the_mystery_of_bob_benson.html",
      "display_url" : "mobile.slate.com/articles/arts/\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596806527, -122.2754860205 ]
  },
  "id_str" : "341932325757657090",
  "text" : "I admit to being confused by the mystery of Bob Benson (anti-Don or anti-Pete?) http://t.co/O2ZFEF1Sra /via @monstro #madmen",
  "id" : 341932325757657090,
  "created_at" : "Tue Jun 04 14:59:53 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Ewing",
      "screen_name" : "hoverbird",
      "indices" : [ 0, 10 ],
      "id_str" : "792690",
      "id" : 792690
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "341800624574312448",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859747461, -122.275462017 ]
  },
  "id_str" : "341816527328272385",
  "in_reply_to_user_id" : 792690,
  "text" : "@hoverbird True, but it would be more for me than for him anyway.",
  "id" : 341816527328272385,
  "in_reply_to_status_id" : 341800624574312448,
  "created_at" : "Tue Jun 04 07:19:45 +0000 2013",
  "in_reply_to_screen_name" : "hoverbird",
  "in_reply_to_user_id_str" : "792690",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GoT",
      "indices" : [ 38, 42 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596693411, -122.2755971403 ]
  },
  "id_str" : "341799213362978816",
  "text" : "Why can't the things that happened on #GoT happen to Pete Campbell instead?",
  "id" : 341799213362978816,
  "created_at" : "Tue Jun 04 06:10:57 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian Chan",
      "screen_name" : "chanian",
      "indices" : [ 0, 8 ],
      "id_str" : "22891211",
      "id" : 22891211
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "shipit",
      "indices" : [ 9, 16 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "341790647772147712",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597678257, -122.2755798629 ]
  },
  "id_str" : "341797190911541248",
  "in_reply_to_user_id" : 22891211,
  "text" : "@chanian #shipit",
  "id" : 341797190911541248,
  "in_reply_to_status_id" : 341790647772147712,
  "created_at" : "Tue Jun 04 06:02:55 +0000 2013",
  "in_reply_to_screen_name" : "chanian",
  "in_reply_to_user_id_str" : "22891211",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http://t.co/0acJ8CEcqG",
      "expanded_url" : "http://flic.kr/p/eCr6VJ",
      "display_url" : "flic.kr/p/eCr6VJ"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859833, -122.275667 ]
  },
  "id_str" : "341777315778396161",
  "text" : "8:36pm Niko was throwing his toothbrush out of the bath http://t.co/0acJ8CEcqG",
  "id" : 341777315778396161,
  "created_at" : "Tue Jun 04 04:43:56 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/this-american-life/id348530331?mt=8&uo=4\" rel=\"nofollow\">This American Life on iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ThisAmericanLife",
      "indices" : [ 20, 37 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http://t.co/pC7HAWI4bd",
      "expanded_url" : "http://thisamericanlife.org/Radio_Episode.aspx?episode=496",
      "display_url" : "thisamericanlife.org/Radio_Episode.\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "341738596102991872",
  "text" : "3 mins into the new #ThisAmericanLife sequel to When Patents Attack and I'm already full of rage http://t.co/pC7HAWI4bd",
  "id" : 341738596102991872,
  "created_at" : "Tue Jun 04 02:10:05 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GeekWire",
      "screen_name" : "geekwire",
      "indices" : [ 32, 41 ],
      "id_str" : "255784266",
      "id" : 255784266
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http://t.co/355AMPlJZx",
      "expanded_url" : "http://goo.gl/fb/cMI4x",
      "display_url" : "goo.gl/fb/cMI4x"
    } ]
  },
  "geo" : {
  },
  "id_str" : "341634257590034432",
  "text" : "Except for everyone that did RT @geekwire: Zynga CEO Mark Pincus: \u2018None of us ever expected to face a day like today\u2019 http://t.co/355AMPlJZx",
  "id" : 341634257590034432,
  "created_at" : "Mon Jun 03 19:15:28 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tanner Christensen",
      "screen_name" : "tannerc",
      "indices" : [ 0, 8 ],
      "id_str" : "9161482",
      "id" : 9161482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "341590792877531136",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.7764812709, -122.4167059721 ]
  },
  "id_str" : "341597041702604800",
  "in_reply_to_user_id" : 9161482,
  "text" : "@tannerc Exactly. And some rocks skip magically across the river.",
  "id" : 341597041702604800,
  "in_reply_to_status_id" : 341590792877531136,
  "created_at" : "Mon Jun 03 16:47:35 +0000 2013",
  "in_reply_to_screen_name" : "tannerc",
  "in_reply_to_user_id_str" : "9161482",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.820530803, -122.2691810934 ]
  },
  "id_str" : "341590235416784896",
  "text" : "Tweeting is like skipping rocks across a bumpy river.",
  "id" : 341590235416784896,
  "created_at" : "Mon Jun 03 16:20:33 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Craig Mod",
      "screen_name" : "craigmod",
      "indices" : [ 3, 12 ],
      "id_str" : "1835951",
      "id" : 1835951
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "341552739978973184",
  "text" : "RT @craigmod: Since the release of iPhone, Americans spend on average an additional six hours in the bathroom every day.",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 40.6438212466, -73.7824982679 ]
    },
    "id_str" : "341550948407181312",
    "text" : "Since the release of iPhone, Americans spend on average an additional six hours in the bathroom every day.",
    "id" : 341550948407181312,
    "created_at" : "Mon Jun 03 13:44:26 +0000 2013",
    "user" : {
      "name" : "Craig Mod",
      "screen_name" : "craigmod",
      "protected" : false,
      "id_str" : "1835951",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2644801549/787bf94df02d213d1359133d48d673b6_normal.png",
      "id" : 1835951,
      "verified" : false
    }
  },
  "id" : 341552739978973184,
  "created_at" : "Mon Jun 03 13:51:33 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sara Haider",
      "screen_name" : "pandemona",
      "indices" : [ 3, 13 ],
      "id_str" : "18337283",
      "id" : 18337283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 80 ],
      "url" : "https://t.co/ChRARvXCrG",
      "expanded_url" : "https://blog.twitter.com/2013/vine-android-every-robot-has-its-day",
      "display_url" : "blog.twitter.com/2013/vine-andr\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "341551930713194498",
  "text" : "RT @pandemona: Vine for Android: Every robot has its day https://t.co/ChRARvXCrG",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 42, 65 ],
        "url" : "https://t.co/ChRARvXCrG",
        "expanded_url" : "https://blog.twitter.com/2013/vine-android-every-robot-has-its-day",
        "display_url" : "blog.twitter.com/2013/vine-andr\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "341549129513705473",
    "text" : "Vine for Android: Every robot has its day https://t.co/ChRARvXCrG",
    "id" : 341549129513705473,
    "created_at" : "Mon Jun 03 13:37:12 +0000 2013",
    "user" : {
      "name" : "Sara Haider",
      "screen_name" : "pandemona",
      "protected" : false,
      "id_str" : "18337283",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3424193754/26ba01bfc8af74ea1dcb9411e45fcee5_normal.png",
      "id" : 18337283,
      "verified" : false
    }
  },
  "id" : 341551930713194498,
  "created_at" : "Mon Jun 03 13:48:20 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bees",
      "screen_name" : "hallstorm",
      "indices" : [ 0, 10 ],
      "id_str" : "249876633",
      "id" : 249876633
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "341363248668495873",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597737331, -122.2755880638 ]
  },
  "id_str" : "341551189399322625",
  "in_reply_to_user_id" : 249876633,
  "text" : "@hallstorm Woah, you sorta do! I",
  "id" : 341551189399322625,
  "in_reply_to_status_id" : 341363248668495873,
  "created_at" : "Mon Jun 03 13:45:23 +0000 2013",
  "in_reply_to_screen_name" : "hallstorm",
  "in_reply_to_user_id_str" : "249876633",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Logan Bowers",
      "screen_name" : "loganb",
      "indices" : [ 0, 7 ],
      "id_str" : "6072622",
      "id" : 6072622
    }, {
      "name" : "Ariel Waldman",
      "screen_name" : "arielwaldman",
      "indices" : [ 8, 21 ],
      "id_str" : "814304",
      "id" : 814304
    }, {
      "name" : "Physics arXiv Blog",
      "screen_name" : "arxivblog",
      "indices" : [ 22, 32 ],
      "id_str" : "259771124",
      "id" : 259771124
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "341431054013460480",
  "geo" : {
  },
  "id_str" : "341436155650260994",
  "in_reply_to_user_id" : 6072622,
  "text" : "@loganb @arielwaldman @arxivblog Sounds about right to me. Either way we should probably come up with a new name for whatever this is about.",
  "id" : 341436155650260994,
  "in_reply_to_status_id" : 341431054013460480,
  "created_at" : "Mon Jun 03 06:08:17 +0000 2013",
  "in_reply_to_screen_name" : "loganb",
  "in_reply_to_user_id_str" : "6072622",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://vine.co\" rel=\"nofollow\">Vine - Make a Scene</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 59 ],
      "url" : "https://t.co/5wcXyrufTa",
      "expanded_url" : "https://vine.co/v/b35O3UD7KZv",
      "display_url" : "vine.co/v/b35O3UD7KZv"
    } ]
  },
  "geo" : {
  },
  "id_str" : "341412689416957952",
  "text" : "Niko working on his okcupid profile https://t.co/5wcXyrufTa",
  "id" : 341412689416957952,
  "created_at" : "Mon Jun 03 04:35:02 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Garbin, CFA PRM",
      "screen_name" : "CoherentCapital",
      "indices" : [ 3, 19 ],
      "id_str" : "15272540",
      "id" : 15272540
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "twitter",
      "indices" : [ 30, 38 ]
    }, {
      "text" : "Erdogan",
      "indices" : [ 88, 96 ]
    }, {
      "text" : "Turkishdaf",
      "indices" : [ 128, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "341360341395062784",
  "text" : "RT @CoherentCapital: You know #twitter is doing something right when Turkish PM Nirmrod #Erdogan calls it a 'menace to society' #Turkishdaf\u2026",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "twitter",
        "indices" : [ 9, 17 ]
      }, {
        "text" : "Erdogan",
        "indices" : [ 67, 75 ]
      }, {
        "text" : "Turkishdaffy",
        "indices" : [ 107, 120 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "341359964452945923",
    "text" : "You know #twitter is doing something right when Turkish PM Nirmrod #Erdogan calls it a 'menace to society' #Turkishdaffy",
    "id" : 341359964452945923,
    "created_at" : "Mon Jun 03 01:05:32 +0000 2013",
    "user" : {
      "name" : "Mark Garbin, CFA PRM",
      "screen_name" : "CoherentCapital",
      "protected" : false,
      "id_str" : "15272540",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1174066100/Coherent_Capital_Logo_normal.jpg",
      "id" : 15272540,
      "verified" : false
    }
  },
  "id" : 341360341395062784,
  "created_at" : "Mon Jun 03 01:07:02 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://vine.co\" rel=\"nofollow\">Vine - Make a Scene</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 50 ],
      "url" : "https://t.co/YS1SGulSCF",
      "expanded_url" : "https://vine.co/v/b3eMMp6Bxin",
      "display_url" : "vine.co/v/b3eMMp6Bxin"
    } ]
  },
  "geo" : {
  },
  "id_str" : "341345087554482176",
  "text" : "\"That ball is outta here!\" https://t.co/YS1SGulSCF",
  "id" : 341345087554482176,
  "created_at" : "Mon Jun 03 00:06:25 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian Bogost",
      "screen_name" : "ibogost",
      "indices" : [ 0, 8 ],
      "id_str" : "6825792",
      "id" : 6825792
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "341342104989093889",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596903631, -122.2755440065 ]
  },
  "id_str" : "341343233168793600",
  "in_reply_to_user_id" : 6825792,
  "text" : "@ibogost Not really. Only 10k google results for it. Or maybe they all just got written out of history.",
  "id" : 341343233168793600,
  "in_reply_to_status_id" : 341342104989093889,
  "created_at" : "Sun Jun 02 23:59:03 +0000 2013",
  "in_reply_to_screen_name" : "ibogost",
  "in_reply_to_user_id_str" : "6825792",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian Bogost",
      "screen_name" : "ibogost",
      "indices" : [ 49, 57 ],
      "id_str" : "6825792",
      "id" : 6825792
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http://t.co/XE6Ef9Kvjp",
      "expanded_url" : "http://higheredstrategy.com/coursera-jumps-the-shark/",
      "display_url" : "higheredstrategy.com/coursera-jumps\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "341340284933775360",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597531561, -122.2758041137 ]
  },
  "id_str" : "341342009128271873",
  "in_reply_to_user_id" : 6825792,
  "text" : "Nice wishful thinking on the disruptee's part RT @ibogost: \"Coursera Jumps the Shark,\" http://t.co/XE6Ef9Kvjp",
  "id" : 341342009128271873,
  "in_reply_to_status_id" : 341340284933775360,
  "created_at" : "Sun Jun 02 23:54:11 +0000 2013",
  "in_reply_to_screen_name" : "ibogost",
  "in_reply_to_user_id_str" : "6825792",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kurt Revis",
      "screen_name" : "kurtrevis",
      "indices" : [ 3, 13 ],
      "id_str" : "56244113",
      "id" : 56244113
    }, {
      "name" : "Buster",
      "screen_name" : "buster",
      "indices" : [ 15, 22 ],
      "id_str" : "2185",
      "id" : 2185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "341339301319159809",
  "text" : "RT @kurtrevis: @buster Skip that and go straight to \"implant first\"",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Buster",
        "screen_name" : "buster",
        "indices" : [ 0, 7 ],
        "id_str" : "2185",
        "id" : 2185
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "341337077226545153",
    "geo" : {
    },
    "id_str" : "341338107448291329",
    "in_reply_to_user_id" : 2185,
    "text" : "@buster Skip that and go straight to \"implant first\"",
    "id" : 341338107448291329,
    "in_reply_to_status_id" : 341337077226545153,
    "created_at" : "Sun Jun 02 23:38:41 +0000 2013",
    "in_reply_to_screen_name" : "buster",
    "in_reply_to_user_id_str" : "2185",
    "user" : {
      "name" : "Kurt Revis",
      "screen_name" : "kurtrevis",
      "protected" : false,
      "id_str" : "56244113",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3097522690/f3ea30f597e75d567a7ce9508a32c351_normal.jpeg",
      "id" : 56244113,
      "verified" : false
    }
  },
  "id" : 341339301319159809,
  "created_at" : "Sun Jun 02 23:43:25 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fred Oliveira",
      "screen_name" : "f",
      "indices" : [ 0, 2 ],
      "id_str" : "5511",
      "id" : 5511
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "341338996057710592",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597815524, -122.2757571376 ]
  },
  "id_str" : "341339171421556736",
  "in_reply_to_user_id" : 5511,
  "text" : "@f I'll take that bet if I can have the under.",
  "id" : 341339171421556736,
  "in_reply_to_status_id" : 341338996057710592,
  "created_at" : "Sun Jun 02 23:42:54 +0000 2013",
  "in_reply_to_screen_name" : "f",
  "in_reply_to_user_id_str" : "5511",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "placeyourbets",
      "indices" : [ 49, 63 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597666043, -122.2755096151 ]
  },
  "id_str" : "341337077226545153",
  "text" : "How many days until \"wearable-first\" is a thing? #placeyourbets",
  "id" : 341337077226545153,
  "created_at" : "Sun Jun 02 23:34:35 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ariel Waldman",
      "screen_name" : "arielwaldman",
      "indices" : [ 3, 16 ],
      "id_str" : "814304",
      "id" : 814304
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "341326889144692736",
  "text" : "RT @arielwaldman: One of my fave space topics: Multiverses! Evidence of other universes \u201Cbeating up\u201D our universe (there are bruises!) http\u2026",
  "retweeted_status" : {
    "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http://t.co/AxrY8ezw2G",
        "expanded_url" : "http://www.technologyreview.com/view/421999/astronomers-find-first-evidence-of-other-universes/",
        "display_url" : "technologyreview.com/view/421999/as\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "341320825317777408",
    "text" : "One of my fave space topics: Multiverses! Evidence of other universes \u201Cbeating up\u201D our universe (there are bruises!) http://t.co/AxrY8ezw2G",
    "id" : 341320825317777408,
    "created_at" : "Sun Jun 02 22:30:00 +0000 2013",
    "user" : {
      "name" : "Ariel Waldman",
      "screen_name" : "arielwaldman",
      "protected" : false,
      "id_str" : "814304",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2530407461/xujyyx9bdf3wi65o5a60_normal.jpeg",
      "id" : 814304,
      "verified" : false
    }
  },
  "id" : 341326889144692736,
  "created_at" : "Sun Jun 02 22:54:06 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marshall Haas",
      "screen_name" : "marshal",
      "indices" : [ 0, 8 ],
      "id_str" : "19028099",
      "id" : 19028099
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "341289207517544448",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8615316978, -122.280849044 ]
  },
  "id_str" : "341289506168766464",
  "in_reply_to_user_id" : 19028099,
  "text" : "@marshal I like that idea.",
  "id" : 341289506168766464,
  "in_reply_to_status_id" : 341289207517544448,
  "created_at" : "Sun Jun 02 20:25:33 +0000 2013",
  "in_reply_to_screen_name" : "marshal",
  "in_reply_to_user_id_str" : "19028099",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marshall Haas",
      "screen_name" : "marshal",
      "indices" : [ 0, 8 ],
      "id_str" : "19028099",
      "id" : 19028099
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "341288207410950146",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8614657655, -122.2808193031 ]
  },
  "id_str" : "341288630024822784",
  "in_reply_to_user_id" : 19028099,
  "text" : "@marshal Do it! Add me as a collaborator. :) I did a talk on 8:36pm that could turn into a post...",
  "id" : 341288630024822784,
  "in_reply_to_status_id" : 341288207410950146,
  "created_at" : "Sun Jun 02 20:22:04 +0000 2013",
  "in_reply_to_screen_name" : "marshal",
  "in_reply_to_user_id_str" : "19028099",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marshall Haas",
      "screen_name" : "marshal",
      "indices" : [ 0, 8 ],
      "id_str" : "19028099",
      "id" : 19028099
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "341275658854490112",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8596753132, -122.2755258983 ]
  },
  "id_str" : "341282316603232257",
  "in_reply_to_user_id" : 19028099,
  "text" : "@marshal Looks great! I keep meaning to build something like that.",
  "id" : 341282316603232257,
  "in_reply_to_status_id" : 341275658854490112,
  "created_at" : "Sun Jun 02 19:56:59 +0000 2013",
  "in_reply_to_screen_name" : "marshal",
  "in_reply_to_user_id_str" : "19028099",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Rosser Eldon",
      "screen_name" : "eldon",
      "indices" : [ 3, 9 ],
      "id_str" : "7982802",
      "id" : 7982802
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "341280088660262912",
  "text" : "RT @eldon: By 2014, 25% of all communication will be via stickers, according to Pew",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 37.7586976918, -122.4035931591 ]
    },
    "id_str" : "341278931103653889",
    "text" : "By 2014, 25% of all communication will be via stickers, according to Pew",
    "id" : 341278931103653889,
    "created_at" : "Sun Jun 02 19:43:32 +0000 2013",
    "user" : {
      "name" : "Eric Rosser Eldon",
      "screen_name" : "eldon",
      "protected" : false,
      "id_str" : "7982802",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2046149481/Screen_Shot_2012-04-05_at_4.40.49_PM_normal.png",
      "id" : 7982802,
      "verified" : true
    }
  },
  "id" : 341280088660262912,
  "created_at" : "Sun Jun 02 19:48:08 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sara M. Watson",
      "screen_name" : "smwat",
      "indices" : [ 0, 6 ],
      "id_str" : "20609587",
      "id" : 20609587
    }, {
      "name" : "Stan James",
      "screen_name" : "wanderingstan",
      "indices" : [ 7, 21 ],
      "id_str" : "1541421",
      "id" : 1541421
    }, {
      "name" : "Diana Kimball",
      "screen_name" : "dianakimball",
      "indices" : [ 22, 35 ],
      "id_str" : "14471007",
      "id" : 14471007
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "341104766333644800",
  "geo" : {
  },
  "id_str" : "341277009869168640",
  "in_reply_to_user_id" : 20609587,
  "text" : "@smwat @wanderingstan @dianakimball Ha, awesome. We should make it official and come up with a name for our private journaling bully group.",
  "id" : 341277009869168640,
  "in_reply_to_status_id" : 341104766333644800,
  "created_at" : "Sun Jun 02 19:35:54 +0000 2013",
  "in_reply_to_screen_name" : "smwat",
  "in_reply_to_user_id_str" : "20609587",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin Frey",
      "screen_name" : "erinfrey",
      "indices" : [ 0, 9 ],
      "id_str" : "20031223",
      "id" : 20031223
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/buster/status/341240696952475651/photo/1",
      "indices" : [ 46, 68 ],
      "url" : "http://t.co/gzpmtoen7n",
      "media_url" : "http://pbs.twimg.com/media/BLxUmx1CUAAULcx.jpg",
      "id_str" : "341240696960864256",
      "id" : 341240696960864256,
      "media_url_https" : "https://pbs.twimg.com/media/BLxUmx1CUAAULcx.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com/gzpmtoen7n"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "341239012624850946",
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.859699009, -122.275514016 ]
  },
  "id_str" : "341240696952475651",
  "in_reply_to_user_id" : 20031223,
  "text" : "@erinfrey We have an Irrelephant in our home: http://t.co/gzpmtoen7n",
  "id" : 341240696952475651,
  "in_reply_to_status_id" : 341239012624850946,
  "created_at" : "Sun Jun 02 17:11:36 +0000 2013",
  "in_reply_to_screen_name" : "erinfrey",
  "in_reply_to_user_id_str" : "20031223",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 54 ],
      "url" : "http://t.co/FVQQCiQZsJ",
      "expanded_url" : "http://flic.kr/p/eAaDXM",
      "display_url" : "flic.kr/p/eAaDXM"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.867833, -122.284334 ]
  },
  "id_str" : "341037513139429376",
  "text" : "8:36pm Kid birthday after party http://t.co/FVQQCiQZsJ",
  "id" : 341037513139429376,
  "created_at" : "Sun Jun 02 03:44:13 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Courtney Love Cobain",
      "screen_name" : "Courtney",
      "indices" : [ 3, 12 ],
      "id_str" : "43522180",
      "id" : 43522180
    }, {
      "name" : "Evan Williams",
      "screen_name" : "ev",
      "indices" : [ 14, 17 ],
      "id_str" : "20",
      "id" : 20
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "341033949918789634",
  "text" : "RT @Courtney: @ev  its Courtney Love, can you DM me, I have a quick question for you  xc",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Evan Williams",
        "screen_name" : "ev",
        "indices" : [ 0, 3 ],
        "id_str" : "20",
        "id" : 20
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "341025970372890624",
    "geo" : {
    },
    "id_str" : "341026622645886976",
    "in_reply_to_user_id" : 20,
    "text" : "@ev  its Courtney Love, can you DM me, I have a quick question for you  xc",
    "id" : 341026622645886976,
    "in_reply_to_status_id" : 341025970372890624,
    "created_at" : "Sun Jun 02 03:00:57 +0000 2013",
    "in_reply_to_screen_name" : "ev",
    "in_reply_to_user_id_str" : "20",
    "user" : {
      "name" : "Courtney Love Cobain",
      "screen_name" : "Courtney",
      "protected" : false,
      "id_str" : "43522180",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3445148737/24ba7f677fb109aff037b883edeeea2b_normal.jpeg",
      "id" : 43522180,
      "verified" : true
    }
  },
  "id" : 341033949918789634,
  "created_at" : "Sun Jun 02 03:30:04 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Clayton Cubitt",
      "screen_name" : "claytoncubitt",
      "indices" : [ 3, 17 ],
      "id_str" : "15875898",
      "id" : 15875898
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "340949466980954112",
  "text" : "RT @claytoncubitt: Polls are great ways to find out what people bored enough to answer polls think.",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "340948208685559808",
    "text" : "Polls are great ways to find out what people bored enough to answer polls think.",
    "id" : 340948208685559808,
    "created_at" : "Sat Jun 01 21:49:22 +0000 2013",
    "user" : {
      "name" : "Clayton Cubitt",
      "screen_name" : "claytoncubitt",
      "protected" : false,
      "id_str" : "15875898",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3075653539/845e95185df48c18ba4947439774fcfe_normal.jpeg",
      "id" : 15875898,
      "verified" : false
    }
  },
  "id" : 340949466980954112,
  "created_at" : "Sat Jun 01 21:54:22 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amelia Greenhall",
      "screen_name" : "ameliagreenhall",
      "indices" : [ 0, 16 ],
      "id_str" : "246531241",
      "id" : 246531241
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "340919207317340160",
  "geo" : {
  },
  "id_str" : "340919383318732800",
  "in_reply_to_user_id" : 246531241,
  "text" : "@ameliagreenhall Okee doke!",
  "id" : 340919383318732800,
  "in_reply_to_status_id" : 340919207317340160,
  "created_at" : "Sat Jun 01 19:54:49 +0000 2013",
  "in_reply_to_screen_name" : "ameliagreenhall",
  "in_reply_to_user_id_str" : "246531241",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Brewer",
      "screen_name" : "jbrewer",
      "indices" : [ 0, 8 ],
      "id_str" : "12555",
      "id" : 12555
    }, {
      "name" : "naveen",
      "screen_name" : "naveen",
      "indices" : [ 9, 16 ],
      "id_str" : "5215",
      "id" : 5215
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "340854776071856128",
  "geo" : {
  },
  "id_str" : "340861317801971715",
  "in_reply_to_user_id" : 12555,
  "text" : "@jbrewer @naveen Yes!",
  "id" : 340861317801971715,
  "in_reply_to_status_id" : 340854776071856128,
  "created_at" : "Sat Jun 01 16:04:05 +0000 2013",
  "in_reply_to_screen_name" : "jbrewer",
  "in_reply_to_user_id_str" : "12555",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter for  iPhone</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.8597056496, -122.2756635823 ]
  },
  "id_str" : "340855342697152512",
  "text" : "Rabbit rabbit!",
  "id" : 340855342697152512,
  "created_at" : "Sat Jun 01 15:40:21 +0000 2013",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
} ]