Grailbird.data.tweets_2012_07 = 
 [ {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael S Galpert",
      "screen_name" : "msg",
      "indices" : [ 13, 17 ],
      "id_str" : "937961",
      "id" : 937961
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 69 ],
      "url" : "http://t.co/z4dAXOLP",
      "expanded_url" : "http://4sq.com/OlIWwy",
      "display_url" : "4sq.com/OlIWwy"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.71975505, -73.957924 ]
  },
  "id_str" : "230505038907310081",
  "text" : "Meeting with @msg. (@ Hotel Delmano w/ 4 others) http://t.co/z4dAXOLP",
  "id" : 230505038907310081,
  "created_at" : "Wed Aug 01 03:27:38 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rusty Foster",
      "screen_name" : "rustyk5",
      "indices" : [ 0, 8 ],
      "id_str" : "577124971",
      "id" : 577124971
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "230495327151587329",
  "geo" : {
  },
  "id_str" : "230499741090320388",
  "in_reply_to_user_id" : 577124971,
  "text" : "@rustyk5 Can\u2019t tell if that\u2019s sarcasm. Trying is easier to sustain when you don\u2019t have incorrect expectations of results.",
  "id" : 230499741090320388,
  "in_reply_to_status_id" : 230495327151587329,
  "created_at" : "Wed Aug 01 03:06:35 +0000 2012",
  "in_reply_to_screen_name" : "rustyk5",
  "in_reply_to_user_id_str" : "577124971",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 50 ],
      "url" : "http://t.co/V6eXrmyh",
      "expanded_url" : "http://bit.ly/NjrhUC",
      "display_url" : "bit.ly/NjrhUC"
    } ]
  },
  "geo" : {
  },
  "id_str" : "230405876761104384",
  "text" : "Why \"just do it\" is bullshit. http://t.co/V6eXrmyh",
  "id" : 230405876761104384,
  "created_at" : "Tue Jul 31 20:53:36 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Abigail Taylor",
      "screen_name" : "magneticabby",
      "indices" : [ 24, 37 ],
      "id_str" : "22070310",
      "id" : 22070310
    }, {
      "name" : "Anti-Buster",
      "screen_name" : "busterbenson",
      "indices" : [ 39, 52 ],
      "id_str" : "1024917050",
      "id" : 1024917050
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "230385007301124096",
  "text" : "Best answers so far: RT @magneticabby: @busterbenson flibberflabber? pickleshoe?",
  "id" : 230385007301124096,
  "created_at" : "Tue Jul 31 19:30:40 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "230382872387805185",
  "text" : "\u201CNonsense\u201D almost works, but it doesn\u2019t address the somewhat malevolent nature of bullshit. Jabberwocky is cute. Bullshit stinks.",
  "id" : 230382872387805185,
  "created_at" : "Tue Jul 31 19:22:11 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "230382464575623169",
  "text" : "Suggestions so far: bollocks, poppycock, balderdash, gibberish, baloney, rubbish. Do the Brits have a monopoly on euphemizing bullshit?",
  "id" : 230382464575623169,
  "created_at" : "Tue Jul 31 19:20:34 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "230381276954259456",
  "text" : "What's a nicer word for bullshit?",
  "id" : 230381276954259456,
  "created_at" : "Tue Jul 31 19:15:51 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daryn Nakhuda",
      "screen_name" : "daryn",
      "indices" : [ 77, 83 ],
      "id_str" : "804808",
      "id" : 804808
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 105 ],
      "url" : "http://t.co/9qCA5Quk",
      "expanded_url" : "http://4sq.com/QXk7Ye",
      "display_url" : "4sq.com/QXk7Ye"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.4436465828, -122.3025941849 ]
  },
  "id_str" : "230363646545498112",
  "text" : "Seattle -&gt; NYC for a day (@ Seattle-Tacoma International Airport (SEA) w/ @daryn) http://t.co/9qCA5Quk",
  "id" : 230363646545498112,
  "created_at" : "Tue Jul 31 18:05:47 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ali.",
      "screen_name" : "knockedup",
      "indices" : [ 0, 10 ],
      "id_str" : "518079559",
      "id" : 518079559
    }, {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 21, 31 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "228932155328323585",
  "geo" : {
  },
  "id_str" : "230339320626675713",
  "in_reply_to_user_id" : 518079559,
  "text" : "@knockedup I removed @kellianne from detail duty near the end of her pregnancy. Locking keys in car is just the beginning. Just go with it!",
  "id" : 230339320626675713,
  "in_reply_to_status_id" : 228932155328323585,
  "created_at" : "Tue Jul 31 16:29:08 +0000 2012",
  "in_reply_to_screen_name" : "knockedup",
  "in_reply_to_user_id_str" : "518079559",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u028E\u01DD\u029E\u0254\u0131\u0265 \u0287\u0287\u0250\u026F",
      "screen_name" : "matthickey",
      "indices" : [ 0, 11 ],
      "id_str" : "8710082",
      "id" : 8710082
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "230176322176028674",
  "geo" : {
  },
  "id_str" : "230176922179604480",
  "in_reply_to_user_id" : 8710082,
  "text" : "@matthickey Also, how does it not only escape black holes but create them? Also, woah.",
  "id" : 230176922179604480,
  "in_reply_to_status_id" : 230176322176028674,
  "created_at" : "Tue Jul 31 05:43:49 +0000 2012",
  "in_reply_to_screen_name" : "matthickey",
  "in_reply_to_user_id_str" : "8710082",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u028E\u01DD\u029E\u0254\u0131\u0265 \u0287\u0287\u0250\u026F",
      "screen_name" : "matthickey",
      "indices" : [ 0, 11 ],
      "id_str" : "8710082",
      "id" : 8710082
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "230176322176028674",
  "geo" : {
  },
  "id_str" : "230176729975631873",
  "in_reply_to_user_id" : 8710082,
  "text" : "@matthickey The whole \"gravity travels at the speed of light\" blows my mind. Also how could something possibly respond to EVERYTHING's pull?",
  "id" : 230176729975631873,
  "in_reply_to_status_id" : 230176322176028674,
  "created_at" : "Tue Jul 31 05:43:03 +0000 2012",
  "in_reply_to_screen_name" : "matthickey",
  "in_reply_to_user_id_str" : "8710082",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u028E\u01DD\u029E\u0254\u0131\u0265 \u0287\u0287\u0250\u026F",
      "screen_name" : "matthickey",
      "indices" : [ 0, 11 ],
      "id_str" : "8710082",
      "id" : 8710082
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "230159002716233728",
  "geo" : {
  },
  "id_str" : "230175571760521216",
  "in_reply_to_user_id" : 8710082,
  "text" : "@matthickey Which documentary was it? I'd love to see it. Can't get gravity out of my head.",
  "id" : 230175571760521216,
  "in_reply_to_status_id" : 230159002716233728,
  "created_at" : "Tue Jul 31 05:38:27 +0000 2012",
  "in_reply_to_screen_name" : "matthickey",
  "in_reply_to_user_id_str" : "8710082",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenn Van Grove",
      "screen_name" : "jbruin",
      "indices" : [ 12, 19 ],
      "id_str" : "6193182",
      "id" : 6193182
    }, {
      "name" : "Andy Hickl",
      "screen_name" : "andyhickl",
      "indices" : [ 116, 126 ],
      "id_str" : "9684932",
      "id" : 9684932
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 111 ],
      "url" : "http://t.co/MPwEuxFQ",
      "expanded_url" : "http://bit.ly/OhCaIb",
      "display_url" : "bit.ly/OhCaIb"
    } ]
  },
  "geo" : {
  },
  "id_str" : "230153987054247937",
  "text" : "Awesome! RT @jbruin: Saga, an intelligent companion for iPhone, aims to do what Siri can't http://t.co/MPwEuxFQ /cc @andyhickl",
  "id" : 230153987054247937,
  "created_at" : "Tue Jul 31 04:12:41 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 118 ],
      "url" : "http://t.co/EDyfLwym",
      "expanded_url" : "http://instagr.am/p/NuyLk-I0KJ/",
      "display_url" : "instagr.am/p/NuyLk-I0KJ/"
    } ]
  },
  "geo" : {
  },
  "id_str" : "230150961128153089",
  "text" : "8:36pm Niko pointed to the dark green dot and said \"fast out\" to explain the sloppiness I presume http://t.co/EDyfLwym",
  "id" : 230150961128153089,
  "created_at" : "Tue Jul 31 04:00:39 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Flock App",
      "screen_name" : "TheFlockApp",
      "indices" : [ 60, 72 ],
      "id_str" : "618544932",
      "id" : 618544932
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 131 ],
      "url" : "http://t.co/NpcyJcn7",
      "expanded_url" : "http://bit.ly/MguGK1",
      "display_url" : "bit.ly/MguGK1"
    } ]
  },
  "geo" : {
  },
  "id_str" : "230144350200406016",
  "text" : "Opening apps is too much work for most things. I agree that @TheFlockApp  is an early sign of a big new trend. http://t.co/NpcyJcn7",
  "id" : 230144350200406016,
  "created_at" : "Tue Jul 31 03:34:23 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Neil deGrasse Tyson",
      "screen_name" : "neiltyson",
      "indices" : [ 124, 134 ],
      "id_str" : "19725644",
      "id" : 19725644
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "230117395782590466",
  "text" : "Does every particle of matter have a gravitational pull on every other particle of matter in the universe at all times? /cc @neiltyson",
  "id" : 230117395782590466,
  "created_at" : "Tue Jul 31 01:47:17 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 93 ],
      "url" : "http://t.co/V0HPiJmu",
      "expanded_url" : "http://www.amazon.com/gp/product/0316069884/ref=as_li_ss_tl?ie=UTF8&camp=1789&creative=390957&creativeASIN=0316069884&linkCode=as2&tag=mockerybird",
      "display_url" : "amazon.com/gp/product/031\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "230112066210504704",
  "text" : "Have any of you read \"Eating Animals\" by Jonathan Safran Foer? Worth it? http://t.co/V0HPiJmu",
  "id" : 230112066210504704,
  "created_at" : "Tue Jul 31 01:26:06 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Neil deGrasse Tyson",
      "screen_name" : "neiltyson",
      "indices" : [ 3, 13 ],
      "id_str" : "19725644",
      "id" : 19725644
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "230075366218268672",
  "text" : "RT @neiltyson: Scientific Method is doing whatever it takes not to fool oneself into thinking what's true is false, or what's false is true.",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "225648867700514816",
    "text" : "Scientific Method is doing whatever it takes not to fool oneself into thinking what's true is false, or what's false is true.",
    "id" : 225648867700514816,
    "created_at" : "Wed Jul 18 17:50:57 +0000 2012",
    "user" : {
      "name" : "Neil deGrasse Tyson",
      "screen_name" : "neiltyson",
      "protected" : false,
      "id_str" : "19725644",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/74188698/NeilTysonOriginsA-Crop_normal.jpg",
      "id" : 19725644,
      "verified" : true
    }
  },
  "id" : 230075366218268672,
  "created_at" : "Mon Jul 30 23:00:16 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Kleon",
      "screen_name" : "austinkleon",
      "indices" : [ 3, 15 ],
      "id_str" : "9698942",
      "id" : 9698942
    }, {
      "name" : "Julie Bosman",
      "screen_name" : "juliebosman",
      "indices" : [ 34, 46 ],
      "id_str" : "29263488",
      "id" : 29263488
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "230000184669638656",
  "text" : "RT @austinkleon: Holy shnikes. MT @juliebosman: Jonah Lehrer Resigns From New Yorker After Making Up Dylan Quotes for His Book http://t. ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Julie Bosman",
        "screen_name" : "juliebosman",
        "indices" : [ 17, 29 ],
        "id_str" : "29263488",
        "id" : 29263488
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 110, 130 ],
        "url" : "http://t.co/MFWnKLgd",
        "expanded_url" : "http://nyti.ms/NEaqld",
        "display_url" : "nyti.ms/NEaqld"
      } ]
    },
    "geo" : {
    },
    "id_str" : "229999367929614338",
    "text" : "Holy shnikes. MT @juliebosman: Jonah Lehrer Resigns From New Yorker After Making Up Dylan Quotes for His Book http://t.co/MFWnKLgd",
    "id" : 229999367929614338,
    "created_at" : "Mon Jul 30 17:58:17 +0000 2012",
    "user" : {
      "name" : "Austin Kleon",
      "screen_name" : "austinkleon",
      "protected" : false,
      "id_str" : "9698942",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3038907321/a05e135c68afa8f62ea148fe58012419_normal.jpeg",
      "id" : 9698942,
      "verified" : false
    }
  },
  "id" : 230000184669638656,
  "created_at" : "Mon Jul 30 18:01:31 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mari Huertas",
      "screen_name" : "marihuertas",
      "indices" : [ 0, 12 ],
      "id_str" : "195863654",
      "id" : 195863654
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "229786065601454080",
  "geo" : {
  },
  "id_str" : "229996547901911041",
  "in_reply_to_user_id" : 195863654,
  "text" : "@marihuertas Yes, I\u2019m beta testing it right now and it\u2019s pretty dang slick. Definitely worth trying out.",
  "id" : 229996547901911041,
  "in_reply_to_status_id" : 229786065601454080,
  "created_at" : "Mon Jul 30 17:47:04 +0000 2012",
  "in_reply_to_screen_name" : "marihuertas",
  "in_reply_to_user_id_str" : "195863654",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Positively Positive",
      "screen_name" : "PosPositive",
      "indices" : [ 3, 15 ],
      "id_str" : "148857281",
      "id" : 148857281
    }, {
      "name" : "Gretchen Rubin",
      "screen_name" : "gretchenrubin",
      "indices" : [ 81, 95 ],
      "id_str" : "14289835",
      "id" : 14289835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 77 ],
      "url" : "http://t.co/BSlgtJxc",
      "expanded_url" : "http://bit.ly/LVuhLA",
      "display_url" : "bit.ly/LVuhLA"
    } ]
  },
  "geo" : {
  },
  "id_str" : "229964789953212416",
  "text" : "RT @PosPositive: Want to Have More Fun? Go on a Mission. http://t.co/BSlgtJxc by @gretchenrubin",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.hootsuite.com\" rel=\"nofollow\">HootSuite</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Gretchen Rubin",
        "screen_name" : "gretchenrubin",
        "indices" : [ 64, 78 ],
        "id_str" : "14289835",
        "id" : 14289835
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 40, 60 ],
        "url" : "http://t.co/BSlgtJxc",
        "expanded_url" : "http://bit.ly/LVuhLA",
        "display_url" : "bit.ly/LVuhLA"
      } ]
    },
    "geo" : {
    },
    "id_str" : "229941955679907842",
    "text" : "Want to Have More Fun? Go on a Mission. http://t.co/BSlgtJxc by @gretchenrubin",
    "id" : 229941955679907842,
    "created_at" : "Mon Jul 30 14:10:09 +0000 2012",
    "user" : {
      "name" : "Positively Positive",
      "screen_name" : "PosPositive",
      "protected" : false,
      "id_str" : "148857281",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1600029120/PP_AVATAR1_normal.png",
      "id" : 148857281,
      "verified" : false
    }
  },
  "id" : 229964789953212416,
  "created_at" : "Mon Jul 30 15:40:53 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jared Tame",
      "screen_name" : "jmtame",
      "indices" : [ 3, 10 ],
      "id_str" : "15032404",
      "id" : 15032404
    }, {
      "name" : "Paul Graham",
      "screen_name" : "paulg",
      "indices" : [ 99, 105 ],
      "id_str" : "183749519",
      "id" : 183749519
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "229963275012562945",
  "text" : "RT @jmtame: \"it's hard to do a really good job on anything you don't think about in the shower.\" - @paulg",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Paul Graham",
        "screen_name" : "paulg",
        "indices" : [ 87, 93 ],
        "id_str" : "183749519",
        "id" : 183749519
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "229813835803000833",
    "text" : "\"it's hard to do a really good job on anything you don't think about in the shower.\" - @paulg",
    "id" : 229813835803000833,
    "created_at" : "Mon Jul 30 05:41:02 +0000 2012",
    "user" : {
      "name" : "Jared Tame",
      "screen_name" : "jmtame",
      "protected" : false,
      "id_str" : "15032404",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3605694212/182565f365722b34d468cad9fa2688b6_normal.jpeg",
      "id" : 15032404,
      "verified" : false
    }
  },
  "id" : 229963275012562945,
  "created_at" : "Mon Jul 30 15:34:51 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 76 ],
      "url" : "http://t.co/iyaUFTqs",
      "expanded_url" : "http://flic.kr/p/cG8RGL",
      "display_url" : "flic.kr/p/cG8RGL"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.608666, -122.306167 ]
  },
  "id_str" : "229787642433257472",
  "text" : "8:36pm Reading a new Little Blue Truck book for bedtime http://t.co/iyaUFTqs",
  "id" : 229787642433257472,
  "created_at" : "Mon Jul 30 03:56:57 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Jones-Dilworth",
      "screen_name" : "joshdilworth",
      "indices" : [ 3, 16 ],
      "id_str" : "1159301",
      "id" : 1159301
    }, {
      "name" : "TechCrunch",
      "screen_name" : "TechCrunch",
      "indices" : [ 98, 109 ],
      "id_str" : "816653",
      "id" : 816653
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 130 ],
      "url" : "http://t.co/3CHtd819",
      "expanded_url" : "http://techcrunch.com/2012/07/28/from-information-to-understanding-moving-beyond-search-in-the-age-of-siri/",
      "display_url" : "techcrunch.com/2012/07/28/fro\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "229689674602536960",
  "text" : "RT @joshdilworth: By Nadav Gur, CEO of new stealth SRI spinout Desti -- Beyond Siri and Search in @techcrunch http://t.co/3CHtd819",
  "retweeted_status" : {
    "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "TechCrunch",
        "screen_name" : "TechCrunch",
        "indices" : [ 80, 91 ],
        "id_str" : "816653",
        "id" : 816653
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 112 ],
        "url" : "http://t.co/3CHtd819",
        "expanded_url" : "http://techcrunch.com/2012/07/28/from-information-to-understanding-moving-beyond-search-in-the-age-of-siri/",
        "display_url" : "techcrunch.com/2012/07/28/fro\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "229676248471851009",
    "text" : "By Nadav Gur, CEO of new stealth SRI spinout Desti -- Beyond Siri and Search in @techcrunch http://t.co/3CHtd819",
    "id" : 229676248471851009,
    "created_at" : "Sun Jul 29 20:34:19 +0000 2012",
    "user" : {
      "name" : "Josh Jones-Dilworth",
      "screen_name" : "joshdilworth",
      "protected" : false,
      "id_str" : "1159301",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2394509089/fzhst0ty8b1lgfmy1699_normal.jpeg",
      "id" : 1159301,
      "verified" : false
    }
  },
  "id" : 229689674602536960,
  "created_at" : "Sun Jul 29 21:27:40 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Arrington",
      "screen_name" : "arrington",
      "indices" : [ 3, 13 ],
      "id_str" : "37570179",
      "id" : 37570179
    }, {
      "name" : "Uncrunched",
      "screen_name" : "Uncrunched",
      "indices" : [ 102, 113 ],
      "id_str" : "461361001",
      "id" : 461361001
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 97 ],
      "url" : "http://t.co/E9IC6fhH",
      "expanded_url" : "http://wp.me/p1RmvN-il",
      "display_url" : "wp.me/p1RmvN-il"
    } ]
  },
  "geo" : {
  },
  "id_str" : "229683242335342592",
  "text" : "RT @arrington: Craigslist (and Silicon Valley) Greatly Offends The NY Times: http://t.co/E9IC6fhH via @Uncrunched",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Uncrunched",
        "screen_name" : "Uncrunched",
        "indices" : [ 87, 98 ],
        "id_str" : "461361001",
        "id" : 461361001
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 62, 82 ],
        "url" : "http://t.co/E9IC6fhH",
        "expanded_url" : "http://wp.me/p1RmvN-il",
        "display_url" : "wp.me/p1RmvN-il"
      } ]
    },
    "geo" : {
    },
    "id_str" : "229681029986779137",
    "text" : "Craigslist (and Silicon Valley) Greatly Offends The NY Times: http://t.co/E9IC6fhH via @Uncrunched",
    "id" : 229681029986779137,
    "created_at" : "Sun Jul 29 20:53:19 +0000 2012",
    "user" : {
      "name" : "Michael Arrington",
      "screen_name" : "arrington",
      "protected" : false,
      "id_str" : "37570179",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3439210570/43ecb9359319ef753f0b4157104d8d14_normal.png",
      "id" : 37570179,
      "verified" : true
    }
  },
  "id" : 229683242335342592,
  "created_at" : "Sun Jul 29 21:02:06 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shane Mac",
      "screen_name" : "ShaneMac",
      "indices" : [ 13, 22 ],
      "id_str" : "44378228",
      "id" : 44378228
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 114 ],
      "url" : "http://t.co/3Ri9F2G7",
      "expanded_url" : "http://bit.ly/O9DgZf",
      "display_url" : "bit.ly/O9DgZf"
    } ]
  },
  "geo" : {
  },
  "id_str" : "229646242450374657",
  "text" : "Cool idea RT @ShaneMac: 3 weeks ago, I set a daily reminder to email me this video - Love it. http://t.co/3Ri9F2G7",
  "id" : 229646242450374657,
  "created_at" : "Sun Jul 29 18:35:05 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dalton Caldwell",
      "screen_name" : "daltonc",
      "indices" : [ 15, 23 ],
      "id_str" : "9151842",
      "id" : 9151842
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 96 ],
      "url" : "http://t.co/VGGABibf",
      "expanded_url" : "http://bit.ly/P6JS73",
      "display_url" : "bit.ly/P6JS73"
    } ]
  },
  "geo" : {
  },
  "id_str" : "229645908105654272",
  "text" : "Smart stuff RT @daltonc: New blog post, \"Critical Mass vs Network Effects\": http://t.co/VGGABibf",
  "id" : 229645908105654272,
  "created_at" : "Sun Jul 29 18:33:45 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 130 ],
      "url" : "http://t.co/LESm6rcB",
      "expanded_url" : "http://read.bi/P5Oom4",
      "display_url" : "read.bi/P5Oom4"
    } ]
  },
  "geo" : {
  },
  "id_str" : "229595008955719682",
  "text" : "I hope Google Fiber disrupts broadband service just as Gmail did for email (seems like a huge project though) http://t.co/LESm6rcB",
  "id" : 229595008955719682,
  "created_at" : "Sun Jul 29 15:11:30 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 50 ],
      "url" : "http://t.co/m3PgBR7W",
      "expanded_url" : "http://instagr.am/p/NpmUgmI0Kh/",
      "display_url" : "instagr.am/p/NpmUgmI0Kh/"
    } ]
  },
  "geo" : {
  },
  "id_str" : "229420726795501568",
  "text" : "8:36pm Lazy part of the party http://t.co/m3PgBR7W",
  "id" : 229420726795501568,
  "created_at" : "Sun Jul 29 03:38:58 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 57 ],
      "url" : "http://t.co/KU7bzrwL",
      "expanded_url" : "http://instagr.am/p/NpWdaPo0M4/",
      "display_url" : "instagr.am/p/NpWdaPo0M4/"
    } ]
  },
  "geo" : {
  },
  "id_str" : "229385949279289344",
  "text" : "Likes a mean burger at a block party http://t.co/KU7bzrwL",
  "id" : 229385949279289344,
  "created_at" : "Sun Jul 29 01:20:46 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "josh",
      "screen_name" : "joshc",
      "indices" : [ 0, 6 ],
      "id_str" : "2015",
      "id" : 2015
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "229319874546118656",
  "geo" : {
  },
  "id_str" : "229326139741593600",
  "in_reply_to_user_id" : 2015,
  "text" : "@joshc Hm\u2026 yeah, I'm sure they'll be around. There are definitely businesses around coupons and gambling, they just aren't very interesting.",
  "id" : 229326139741593600,
  "in_reply_to_status_id" : 229319874546118656,
  "created_at" : "Sat Jul 28 21:23:07 +0000 2012",
  "in_reply_to_screen_name" : "joshc",
  "in_reply_to_user_id_str" : "2015",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Oliver Burkeman",
      "screen_name" : "oliverburkeman",
      "indices" : [ 0, 15 ],
      "id_str" : "112037009",
      "id" : 112037009
    }, {
      "name" : "Ed Yong ",
      "screen_name" : "edyong209",
      "indices" : [ 16, 26 ],
      "id_str" : "19767193",
      "id" : 19767193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "229306885872959489",
  "geo" : {
  },
  "id_str" : "229315104603242496",
  "in_reply_to_user_id" : 112037009,
  "text" : "@oliverburkeman @edyong209 Yes: Tweetbot.",
  "id" : 229315104603242496,
  "in_reply_to_status_id" : 229306885872959489,
  "created_at" : "Sat Jul 28 20:39:16 +0000 2012",
  "in_reply_to_screen_name" : "oliverburkeman",
  "in_reply_to_user_id_str" : "112037009",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Predictions",
      "indices" : [ 0, 12 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "229314416716439554",
  "text" : "#Predictions for 5 years from now: Apple, Twitter, and Facebook valuations are way up, Groupon and Zynga\u2019s valuations are way down.",
  "id" : 229314416716439554,
  "created_at" : "Sat Jul 28 20:36:32 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http://t.co/Xh5kQbJZ",
      "expanded_url" : "http://instagr.am/p/NoopvOo0JY/",
      "display_url" : "instagr.am/p/NoopvOo0JY/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6073529621, -122.342274785 ]
  },
  "id_str" : "229285573960032256",
  "text" : "Nikopus  @ Seattle Aquarium http://t.co/Xh5kQbJZ",
  "id" : 229285573960032256,
  "created_at" : "Sat Jul 28 18:41:55 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Jacobs",
      "screen_name" : "evanjacobs",
      "indices" : [ 0, 11 ],
      "id_str" : "14803483",
      "id" : 14803483
    }, {
      "name" : "Marcelo Calbucci",
      "screen_name" : "calbucci",
      "indices" : [ 12, 21 ],
      "id_str" : "14232711",
      "id" : 14232711
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "229244180285751296",
  "geo" : {
  },
  "id_str" : "229244562852438017",
  "in_reply_to_user_id" : 14803483,
  "text" : "@evanjacobs @calbucci I've decided to just skip watching the Olympics rather than figure out cable. I'll watch via Twitter.",
  "id" : 229244562852438017,
  "in_reply_to_status_id" : 229244180285751296,
  "created_at" : "Sat Jul 28 15:58:57 +0000 2012",
  "in_reply_to_screen_name" : "evanjacobs",
  "in_reply_to_user_id_str" : "14803483",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 99 ],
      "url" : "http://t.co/ZOsJnP8G",
      "expanded_url" : "http://flic.kr/p/cETfoh",
      "display_url" : "flic.kr/p/cETfoh"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.608666, -122.305834 ]
  },
  "id_str" : "229058451660238848",
  "text" : "8:36pm Locked out and wondering where Kellianne and Niko are. Who's seen them? http://t.co/ZOsJnP8G",
  "id" : 229058451660238848,
  "created_at" : "Sat Jul 28 03:39:25 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aimee",
      "screen_name" : "LilHossler",
      "indices" : [ 0, 11 ],
      "id_str" : "123116307",
      "id" : 123116307
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "228951794020147200",
  "geo" : {
  },
  "id_str" : "228951989365645312",
  "in_reply_to_user_id" : 123116307,
  "text" : "@LilHossler Yeah, me too. I just turn it on and am surprised when things work, but don\u2019t expect it to. Mountain Lion makes it better tho.",
  "id" : 228951989365645312,
  "in_reply_to_status_id" : 228951794020147200,
  "created_at" : "Fri Jul 27 20:36:22 +0000 2012",
  "in_reply_to_screen_name" : "LilHossler",
  "in_reply_to_user_id_str" : "123116307",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aimee",
      "screen_name" : "LilHossler",
      "indices" : [ 0, 11 ],
      "id_str" : "123116307",
      "id" : 123116307
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "228917694945173504",
  "geo" : {
  },
  "id_str" : "228951428381691904",
  "in_reply_to_user_id" : 123116307,
  "text" : "@LilHossler It actually works with iCloud, I think\u2026 so you don\u2019t even need to upload them to Flickr/Instagram/etc to share them.",
  "id" : 228951428381691904,
  "in_reply_to_status_id" : 228917694945173504,
  "created_at" : "Fri Jul 27 20:34:08 +0000 2012",
  "in_reply_to_screen_name" : "LilHossler",
  "in_reply_to_user_id_str" : "123116307",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Dean",
      "screen_name" : "dandean",
      "indices" : [ 0, 8 ],
      "id_str" : "9525212",
      "id" : 9525212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "228917220644900865",
  "geo" : {
  },
  "id_str" : "228919561402068992",
  "in_reply_to_user_id" : 9525212,
  "text" : "@dandean Yes! Are you in Seattle today? Come to Cal Anderson tonight?",
  "id" : 228919561402068992,
  "in_reply_to_status_id" : 228917220644900865,
  "created_at" : "Fri Jul 27 18:27:31 +0000 2012",
  "in_reply_to_screen_name" : "dandean",
  "in_reply_to_user_id_str" : "9525212",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.apple.com\" rel=\"nofollow\">iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 118 ],
      "url" : "http://t.co/p1xsVgkZ",
      "expanded_url" : "http://itun.es/us/yk_yG.i",
      "display_url" : "itun.es/us/yk_yG.i"
    } ]
  },
  "geo" : {
  },
  "id_str" : "228916033468125184",
  "text" : "Can more of you install this Flock app so I can see if the magical photo-gathering works? Thanks! http://t.co/p1xsVgkZ",
  "id" : 228916033468125184,
  "created_at" : "Fri Jul 27 18:13:30 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Wright",
      "screen_name" : "webwright",
      "indices" : [ 0, 10 ],
      "id_str" : "786818",
      "id" : 786818
    }, {
      "name" : "Scott Berkun",
      "screen_name" : "berkun",
      "indices" : [ 11, 18 ],
      "id_str" : "30495974",
      "id" : 30495974
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "228893886880309248",
  "geo" : {
  },
  "id_str" : "228894463089598465",
  "in_reply_to_user_id" : 786818,
  "text" : "@webwright @berkun Yes, I strongly believe so. Product/person fit. Also applies to services and ideas.",
  "id" : 228894463089598465,
  "in_reply_to_status_id" : 228893886880309248,
  "created_at" : "Fri Jul 27 16:47:47 +0000 2012",
  "in_reply_to_screen_name" : "webwright",
  "in_reply_to_user_id_str" : "786818",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Berkun",
      "screen_name" : "berkun",
      "indices" : [ 0, 7 ],
      "id_str" : "30495974",
      "id" : 30495974
    }, {
      "name" : "Tony Wright",
      "screen_name" : "webwright",
      "indices" : [ 8, 18 ],
      "id_str" : "786818",
      "id" : 786818
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "228891853448179712",
  "geo" : {
  },
  "id_str" : "228892093240733696",
  "in_reply_to_user_id" : 30495974,
  "text" : "@berkun @webwright Another way to look at it, there\u2019s no such thing as quality, only fit.",
  "id" : 228892093240733696,
  "in_reply_to_status_id" : 228891853448179712,
  "created_at" : "Fri Jul 27 16:38:22 +0000 2012",
  "in_reply_to_screen_name" : "berkun",
  "in_reply_to_user_id_str" : "30495974",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Larry McSheffery",
      "screen_name" : "larrymcsheffery",
      "indices" : [ 3, 19 ],
      "id_str" : "52441862",
      "id" : 52441862
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 117 ],
      "url" : "http://t.co/Xr8pE26A",
      "expanded_url" : "http://ow.ly/cxHqQ",
      "display_url" : "ow.ly/cxHqQ"
    } ]
  },
  "geo" : {
  },
  "id_str" : "228858815796363266",
  "text" : "RT @larrymcsheffery: Esther Dyson on health data, \u201Cpreemptive healthcare\u201D and the next big thing http://t.co/Xr8pE26A",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.hootsuite.com\" rel=\"nofollow\">HootSuite</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 76, 96 ],
        "url" : "http://t.co/Xr8pE26A",
        "expanded_url" : "http://ow.ly/cxHqQ",
        "display_url" : "ow.ly/cxHqQ"
      } ]
    },
    "geo" : {
    },
    "id_str" : "228844047165431808",
    "text" : "Esther Dyson on health data, \u201Cpreemptive healthcare\u201D and the next big thing http://t.co/Xr8pE26A",
    "id" : 228844047165431808,
    "created_at" : "Fri Jul 27 13:27:27 +0000 2012",
    "user" : {
      "name" : "Larry McSheffery",
      "screen_name" : "larrymcsheffery",
      "protected" : false,
      "id_str" : "52441862",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3414110138/59c52e8e12fa321068fbc4bc6f047a46_normal.jpeg",
      "id" : 52441862,
      "verified" : false
    }
  },
  "id" : 228858815796363266,
  "created_at" : "Fri Jul 27 14:26:08 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 76 ],
      "url" : "http://t.co/jBgFElt3",
      "expanded_url" : "http://instagr.am/p/Nkbg3Ro0F7/",
      "display_url" : "instagr.am/p/Nkbg3Ro0F7/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6899069974, -122.403048 ]
  },
  "id_str" : "228695438822342657",
  "text" : "8:36pm Sunset family beach times  @ Golden Gardens Park http://t.co/jBgFElt3",
  "id" : 228695438822342657,
  "created_at" : "Fri Jul 27 03:36:56 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 72 ],
      "url" : "http://t.co/5lJN7QBG",
      "expanded_url" : "http://instagr.am/p/NkbMeJI0Fu/",
      "display_url" : "instagr.am/p/NkbMeJI0Fu/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6899069974, -122.403048 ]
  },
  "id_str" : "228692626751250432",
  "text" : "Seattle is being purty again  @ Golden Gardens Park http://t.co/5lJN7QBG",
  "id" : 228692626751250432,
  "created_at" : "Fri Jul 27 03:25:45 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.apple.com\" rel=\"nofollow\">YouTube on iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http://t.co/s5jEKncc",
      "expanded_url" : "http://www.youtube.com/watch?v=tHjd45FpC_Y&feature=youtube_gdata_player",
      "display_url" : "youtube.com/watch?v=tHjd45\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "228688347927822336",
  "text" : "Obligatory \"Whoop, there it is\" moment http://t.co/s5jEKncc",
  "id" : 228688347927822336,
  "created_at" : "Fri Jul 27 03:08:45 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "228598974276321280",
  "text" : "OH \u201CNominalization is a nominalization.\u201D",
  "id" : 228598974276321280,
  "created_at" : "Thu Jul 26 21:13:37 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ellen Chisa",
      "screen_name" : "ellenchisa",
      "indices" : [ 0, 11 ],
      "id_str" : "14620776",
      "id" : 14620776
    }, {
      "name" : "Vizify",
      "screen_name" : "vizify",
      "indices" : [ 121, 128 ],
      "id_str" : "295513152",
      "id" : 295513152
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "228581823964393472",
  "geo" : {
  },
  "id_str" : "228582107050561538",
  "in_reply_to_user_id" : 14620776,
  "text" : "@ellenchisa Yeah, I was confused about that too\u2026 tried to edit it to say 8:36pm but unfortunately it\u2019s not editable. /cc @vizify",
  "id" : 228582107050561538,
  "in_reply_to_status_id" : 228581823964393472,
  "created_at" : "Thu Jul 26 20:06:35 +0000 2012",
  "in_reply_to_screen_name" : "ellenchisa",
  "in_reply_to_user_id_str" : "14620776",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vizify",
      "screen_name" : "vizify",
      "indices" : [ 25, 32 ],
      "id_str" : "295513152",
      "id" : 295513152
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 97 ],
      "url" : "https://t.co/nN8XZVaQ",
      "expanded_url" : "https://www.vizify.com/buster-benson",
      "display_url" : "vizify.com/buster-benson"
    } ]
  },
  "geo" : {
  },
  "id_str" : "228578423709265921",
  "text" : "VERY impressed with what @vizify has cooked up. Check out my graphical bio: https://t.co/nN8XZVaQ",
  "id" : 228578423709265921,
  "created_at" : "Thu Jul 26 19:51:57 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Koloskov",
      "screen_name" : "xenocid",
      "indices" : [ 0, 8 ],
      "id_str" : "7777252",
      "id" : 7777252
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "228392391772610560",
  "geo" : {
  },
  "id_str" : "228393281325764608",
  "in_reply_to_user_id" : 7777252,
  "text" : "@xenocid He bought 6000 rounds via mail order. What benefit do we get from that that outweighs mass murders and enabling crazy people?",
  "id" : 228393281325764608,
  "in_reply_to_status_id" : 228392391772610560,
  "created_at" : "Thu Jul 26 07:36:16 +0000 2012",
  "in_reply_to_screen_name" : "xenocid",
  "in_reply_to_user_id_str" : "7777252",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Koloskov",
      "screen_name" : "xenocid",
      "indices" : [ 0, 8 ],
      "id_str" : "7777252",
      "id" : 7777252
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "228384781379964928",
  "geo" : {
  },
  "id_str" : "228391946077483009",
  "in_reply_to_user_id" : 7777252,
  "text" : "@xenocid Which stricter rules? Buying 6000 rounds via mail order is probably one easy rule to avoid.",
  "id" : 228391946077483009,
  "in_reply_to_status_id" : 228384781379964928,
  "created_at" : "Thu Jul 26 07:30:57 +0000 2012",
  "in_reply_to_screen_name" : "xenocid",
  "in_reply_to_user_id_str" : "7777252",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 43 ],
      "url" : "http://t.co/KjKVls5i",
      "expanded_url" : "http://flic.kr/p/cDPG7b",
      "display_url" : "flic.kr/p/cDPG7b"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6085, -122.305834 ]
  },
  "id_str" : "228333718102761472",
  "text" : "8:36pm Carinna's back! http://t.co/KjKVls5i",
  "id" : 228333718102761472,
  "created_at" : "Thu Jul 26 03:39:35 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cori Ready",
      "screen_name" : "CoriReady",
      "indices" : [ 0, 10 ],
      "id_str" : "12426422",
      "id" : 12426422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "228281091507761154",
  "geo" : {
  },
  "id_str" : "228303522179985408",
  "in_reply_to_user_id" : 12426422,
  "text" : "@CoriReady Hi! Yeah lots going on. We should hang out soon!",
  "id" : 228303522179985408,
  "in_reply_to_status_id" : 228281091507761154,
  "created_at" : "Thu Jul 26 01:39:36 +0000 2012",
  "in_reply_to_screen_name" : "CoriReady",
  "in_reply_to_user_id_str" : "12426422",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.apple.com/\" rel=\"nofollow\">OS X</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.621562, -122.336495 ]
  },
  "id_str" : "228289455134494721",
  "text" : "Tweeting from my new notification center in Mountain Lion. The notebook paper aesthetic is a little weird, but okay.",
  "id" : 228289455134494721,
  "created_at" : "Thu Jul 26 00:43:42 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laura Grasso",
      "screen_name" : "Lowrha",
      "indices" : [ 0, 7 ],
      "id_str" : "16252045",
      "id" : 16252045
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "reality",
      "indices" : [ 49, 57 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "228256728880406529",
  "geo" : {
  },
  "id_str" : "228265925709811712",
  "in_reply_to_user_id" : 16252045,
  "text" : "@Lowrha That\u2019s pretty hilarious. Welcome back to #reality, Laura. :)",
  "id" : 228265925709811712,
  "in_reply_to_status_id" : 228256728880406529,
  "created_at" : "Wed Jul 25 23:10:12 +0000 2012",
  "in_reply_to_screen_name" : "Lowrha",
  "in_reply_to_user_id_str" : "16252045",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "effective efforts",
      "screen_name" : "effectivefforts",
      "indices" : [ 0, 16 ],
      "id_str" : "629344793",
      "id" : 629344793
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "228240614490243073",
  "geo" : {
  },
  "id_str" : "228245951284932608",
  "in_reply_to_user_id" : 629344793,
  "text" : "@effectivefforts Thank you! Yes, good catch on the missing tip too.",
  "id" : 228245951284932608,
  "in_reply_to_status_id" : 228240614490243073,
  "created_at" : "Wed Jul 25 21:50:50 +0000 2012",
  "in_reply_to_screen_name" : "effectivefforts",
  "in_reply_to_user_id_str" : "629344793",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BJ Fogg",
      "screen_name" : "bjfogg",
      "indices" : [ 4, 11 ],
      "id_str" : "1118691",
      "id" : 1118691
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 92 ],
      "url" : "http://t.co/4ukpmA39",
      "expanded_url" : "http://branch.com/b/what-are-your-current-best-practices-for-building-habits",
      "display_url" : "branch.com/b/what-are-you\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "228209478162608130",
  "text" : "Hey @bjfogg I\u2019d love your feedback on this if you have some time today: http://t.co/4ukpmA39",
  "id" : 228209478162608130,
  "created_at" : "Wed Jul 25 19:25:54 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Donahue",
      "screen_name" : "johnmdonahue",
      "indices" : [ 0, 13 ],
      "id_str" : "23723225",
      "id" : 23723225
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "228201132256808960",
  "geo" : {
  },
  "id_str" : "228202259186601984",
  "in_reply_to_user_id" : 23723225,
  "text" : "@johnmdonahue That\u2019s a really cool habit trick. :)",
  "id" : 228202259186601984,
  "in_reply_to_status_id" : 228201132256808960,
  "created_at" : "Wed Jul 25 18:57:13 +0000 2012",
  "in_reply_to_screen_name" : "johnmdonahue",
  "in_reply_to_user_id_str" : "23723225",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aimee",
      "screen_name" : "LilHossler",
      "indices" : [ 0, 11 ],
      "id_str" : "123116307",
      "id" : 123116307
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "228200080618958848",
  "geo" : {
  },
  "id_str" : "228200728164958208",
  "in_reply_to_user_id" : 123116307,
  "text" : "@LilHossler Thanks, Aimee! Lots of stuff in the works now\u2026 hope to make the best of an unfortunate situation.",
  "id" : 228200728164958208,
  "in_reply_to_status_id" : 228200080618958848,
  "created_at" : "Wed Jul 25 18:51:08 +0000 2012",
  "in_reply_to_screen_name" : "LilHossler",
  "in_reply_to_user_id_str" : "123116307",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "elyse holladay",
      "screen_name" : "elyseholladay",
      "indices" : [ 3, 17 ],
      "id_str" : "3392991",
      "id" : 3392991
    }, {
      "name" : "Anti-Buster",
      "screen_name" : "busterbenson",
      "indices" : [ 19, 32 ],
      "id_str" : "1024917050",
      "id" : 1024917050
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "228200374157340672",
  "text" : "RT @elyseholladay: @busterbenson \u2014 definitely agree with planning for bad days. that's how i always screw myself up! +1 for \"inspiration ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Anti-Buster",
        "screen_name" : "busterbenson",
        "indices" : [ 0, 13 ],
        "id_str" : "1024917050",
        "id" : 1024917050
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "228197264542281728",
    "in_reply_to_user_id" : 2185,
    "text" : "@busterbenson \u2014 definitely agree with planning for bad days. that's how i always screw myself up! +1 for \"inspiration\" as well.",
    "id" : 228197264542281728,
    "created_at" : "Wed Jul 25 18:37:22 +0000 2012",
    "in_reply_to_screen_name" : "buster",
    "in_reply_to_user_id_str" : "2185",
    "user" : {
      "name" : "elyse holladay",
      "screen_name" : "elyseholladay",
      "protected" : false,
      "id_str" : "3392991",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3668534952/05fdc1c4155a5064c001ad84a4ceb21c_normal.jpeg",
      "id" : 3392991,
      "verified" : false
    }
  },
  "id" : 228200374157340672,
  "created_at" : "Wed Jul 25 18:49:43 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 131 ],
      "url" : "http://t.co/4Wi5ziAh",
      "expanded_url" : "http://wayoftheduck.com/habit-manifesto",
      "display_url" : "wayoftheduck.com/habit-manifesto"
    } ]
  },
  "geo" : {
  },
  "id_str" : "228192373027528704",
  "text" : "Looking for feedback on this habit manifesto I just posted. Which of the 11 points do you agree/disagree with? http://t.co/4Wi5ziAh",
  "id" : 228192373027528704,
  "created_at" : "Wed Jul 25 18:17:55 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 114 ],
      "url" : "http://t.co/4ukpmA39",
      "expanded_url" : "http://branch.com/b/what-are-your-current-best-practices-for-building-habits",
      "display_url" : "branch.com/b/what-are-you\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "228192097566601217",
  "text" : "Invited a few of my most admired habit-studiers to a conversation about habit best practices: http://t.co/4ukpmA39 Who else wants to join?",
  "id" : 228192097566601217,
  "created_at" : "Wed Jul 25 18:16:50 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.branch.com\" rel=\"nofollow\">Branch Inc</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leo Babauta",
      "screen_name" : "zen_habits",
      "indices" : [ 0, 11 ],
      "id_str" : "15859268",
      "id" : 15859268
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 73 ],
      "url" : "http://t.co/YSvzK3EU",
      "expanded_url" : "http://branch.com/b/what-are-your-current-best-practices-for-building-habits?showsignin=true&inviter=Buster%20Benson",
      "display_url" : "branch.com/b/what-are-you\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "228191405565165568",
  "in_reply_to_user_id" : 15859268,
  "text" : "@zen_habits Will you join my conversation on Branch? http://t.co/YSvzK3EU",
  "id" : 228191405565165568,
  "created_at" : "Wed Jul 25 18:14:05 +0000 2012",
  "in_reply_to_screen_name" : "zen_habits",
  "in_reply_to_user_id_str" : "15859268",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 3, 12 ],
      "id_str" : "761628",
      "id" : 761628
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "228184448456327169",
  "text" : "RT @RickWebb: If Twitter and Yahoo are \"media companies\" isn't Google just an Ad Agency?",
  "retweeted_status" : {
    "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "228184270856937472",
    "text" : "If Twitter and Yahoo are \"media companies\" isn't Google just an Ad Agency?",
    "id" : 228184270856937472,
    "created_at" : "Wed Jul 25 17:45:44 +0000 2012",
    "user" : {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "protected" : false,
      "id_str" : "761628",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/23078492/img_2085_normal.jpg",
      "id" : 761628,
      "verified" : false
    }
  },
  "id" : 228184448456327169,
  "created_at" : "Wed Jul 25 17:46:26 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Andersen",
      "screen_name" : "lookatpete",
      "indices" : [ 0, 11 ],
      "id_str" : "140711007",
      "id" : 140711007
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 65 ],
      "url" : "http://t.co/EKvwzvyT",
      "expanded_url" : "http://bit.ly/QFcauY",
      "display_url" : "bit.ly/QFcauY"
    } ]
  },
  "in_reply_to_status_id_str" : "228182688891297792",
  "geo" : {
  },
  "id_str" : "228182999777288192",
  "in_reply_to_user_id" : 140711007,
  "text" : "@lookatpete Something screwey with that. Try http://t.co/EKvwzvyT",
  "id" : 228182999777288192,
  "in_reply_to_status_id" : 228182688891297792,
  "created_at" : "Wed Jul 25 17:40:41 +0000 2012",
  "in_reply_to_screen_name" : "lookatpete",
  "in_reply_to_user_id_str" : "140711007",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "228159506008375296",
  "geo" : {
  },
  "id_str" : "228160305904099328",
  "in_reply_to_user_id" : 171754967,
  "text" : "@1CharlesH Thanks, Charles!",
  "id" : 228160305904099328,
  "in_reply_to_status_id" : 228159506008375296,
  "created_at" : "Wed Jul 25 16:10:30 +0000 2012",
  "in_reply_to_screen_name" : "cch",
  "in_reply_to_user_id_str" : "171754967",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 132 ],
      "url" : "http://t.co/4Wi5ziAh",
      "expanded_url" : "http://wayoftheduck.com/habit-manifesto",
      "display_url" : "wayoftheduck.com/habit-manifesto"
    } ]
  },
  "geo" : {
  },
  "id_str" : "228158513455718400",
  "text" : "Just posted my habit manifesto which includes everything I (currently) know about hot to start and keep habits: http://t.co/4Wi5ziAh",
  "id" : 228158513455718400,
  "created_at" : "Wed Jul 25 16:03:23 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Rainert",
      "screen_name" : "arainert",
      "indices" : [ 0, 9 ],
      "id_str" : "7482",
      "id" : 7482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "228125409663930368",
  "geo" : {
  },
  "id_str" : "228125695572865024",
  "in_reply_to_user_id" : 7482,
  "text" : "@arainert Totally. I end up following most of the people on my lists just because I\u2019m never gonna see them otherwise.",
  "id" : 228125695572865024,
  "in_reply_to_status_id" : 228125409663930368,
  "created_at" : "Wed Jul 25 13:52:58 +0000 2012",
  "in_reply_to_screen_name" : "arainert",
  "in_reply_to_user_id_str" : "7482",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Rainert",
      "screen_name" : "arainert",
      "indices" : [ 0, 9 ],
      "id_str" : "7482",
      "id" : 7482
    }, {
      "name" : "Best of Buster",
      "screen_name" : "bestofbuster",
      "indices" : [ 56, 69 ],
      "id_str" : "637064633",
      "id" : 637064633
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "228092597749559296",
  "geo" : {
  },
  "id_str" : "228125130415550465",
  "in_reply_to_user_id" : 7482,
  "text" : "@arainert That\u2019s a pretty great idea. I recently made a @bestofbuster script but I think your idea is way more useful.",
  "id" : 228125130415550465,
  "in_reply_to_status_id" : 228092597749559296,
  "created_at" : "Wed Jul 25 13:50:44 +0000 2012",
  "in_reply_to_screen_name" : "arainert",
  "in_reply_to_user_id_str" : "7482",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Koloskov",
      "screen_name" : "xenocid",
      "indices" : [ 0, 8 ],
      "id_str" : "7777252",
      "id" : 7777252
    }, {
      "name" : "Nikolay Ruban",
      "screen_name" : "nrhm",
      "indices" : [ 9, 14 ],
      "id_str" : "4011261",
      "id" : 4011261
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "227988798896754688",
  "geo" : {
  },
  "id_str" : "227996580807065601",
  "in_reply_to_user_id" : 7777252,
  "text" : "@xenocid @nrhm That\u2019s all I\u2019m personally interested in: strict rules for who can carry a gun. A \u201Cwell-regulated militia\u201D sounds right to me.",
  "id" : 227996580807065601,
  "in_reply_to_status_id" : 227988798896754688,
  "created_at" : "Wed Jul 25 05:19:55 +0000 2012",
  "in_reply_to_screen_name" : "xenocid",
  "in_reply_to_user_id_str" : "7777252",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 44 ],
      "url" : "http://t.co/mKkr8gIm",
      "expanded_url" : "http://instagr.am/p/NfSx18I0BQ/",
      "display_url" : "instagr.am/p/NfSx18I0BQ/"
    } ]
  },
  "geo" : {
  },
  "id_str" : "227970436711972865",
  "text" : "8:36pm Seattle is purty http://t.co/mKkr8gIm",
  "id" : 227970436711972865,
  "created_at" : "Wed Jul 25 03:36:02 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mena Trott",
      "screen_name" : "dollarshort",
      "indices" : [ 0, 12 ],
      "id_str" : "14127387",
      "id" : 14127387
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "227955326828294144",
  "geo" : {
  },
  "id_str" : "227956198098497536",
  "in_reply_to_user_id" : 14127387,
  "text" : "@dollarshort Wait, you mean it gets worse? - parent of 2yo",
  "id" : 227956198098497536,
  "in_reply_to_status_id" : 227955326828294144,
  "created_at" : "Wed Jul 25 02:39:27 +0000 2012",
  "in_reply_to_screen_name" : "dollarshort",
  "in_reply_to_user_id_str" : "14127387",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "227954762874773504",
  "text" : "If someone created a bill outlawing cars AND guns, I\u2019d vote for it. Good chaos would ensue. How would you vote?",
  "id" : 227954762874773504,
  "created_at" : "Wed Jul 25 02:33:45 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Koloskov",
      "screen_name" : "xenocid",
      "indices" : [ 0, 8 ],
      "id_str" : "7777252",
      "id" : 7777252
    }, {
      "name" : "Nikolay Ruban",
      "screen_name" : "nrhm",
      "indices" : [ 9, 14 ],
      "id_str" : "4011261",
      "id" : 4011261
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "227952503717769216",
  "geo" : {
  },
  "id_str" : "227953223279996930",
  "in_reply_to_user_id" : 7777252,
  "text" : "@xenocid @nrhm That would only matter if 12 deaths in a movie theater or 10,000 per year were acceptable. What do we get for these losses?",
  "id" : 227953223279996930,
  "in_reply_to_status_id" : 227952503717769216,
  "created_at" : "Wed Jul 25 02:27:38 +0000 2012",
  "in_reply_to_screen_name" : "xenocid",
  "in_reply_to_user_id_str" : "7777252",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Koloskov",
      "screen_name" : "xenocid",
      "indices" : [ 0, 8 ],
      "id_str" : "7777252",
      "id" : 7777252
    }, {
      "name" : "Nikolay Ruban",
      "screen_name" : "nrhm",
      "indices" : [ 9, 14 ],
      "id_str" : "4011261",
      "id" : 4011261
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "227950208007430144",
  "geo" : {
  },
  "id_str" : "227951692153503745",
  "in_reply_to_user_id" : 7777252,
  "text" : "@xenocid @nrhm I agree that all should be considered, weighed, and tested. Each can be worked on independently and in parallel.",
  "id" : 227951692153503745,
  "in_reply_to_status_id" : 227950208007430144,
  "created_at" : "Wed Jul 25 02:21:33 +0000 2012",
  "in_reply_to_screen_name" : "xenocid",
  "in_reply_to_user_id_str" : "7777252",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Koloskov",
      "screen_name" : "xenocid",
      "indices" : [ 0, 8 ],
      "id_str" : "7777252",
      "id" : 7777252
    }, {
      "name" : "Nikolay Ruban",
      "screen_name" : "nrhm",
      "indices" : [ 9, 14 ],
      "id_str" : "4011261",
      "id" : 4011261
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "227949720893550593",
  "geo" : {
  },
  "id_str" : "227951195229126657",
  "in_reply_to_user_id" : 7777252,
  "text" : "@xenocid @nrhm There is *statistical evidence* that fewer people would die. Why not at least consider, weigh, and test potential remedies?",
  "id" : 227951195229126657,
  "in_reply_to_status_id" : 227949720893550593,
  "created_at" : "Wed Jul 25 02:19:34 +0000 2012",
  "in_reply_to_screen_name" : "xenocid",
  "in_reply_to_user_id_str" : "7777252",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Koloskov",
      "screen_name" : "xenocid",
      "indices" : [ 0, 8 ],
      "id_str" : "7777252",
      "id" : 7777252
    }, {
      "name" : "Nikolay Ruban",
      "screen_name" : "nrhm",
      "indices" : [ 9, 14 ],
      "id_str" : "4011261",
      "id" : 4011261
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "227949544929910784",
  "geo" : {
  },
  "id_str" : "227950429651230720",
  "in_reply_to_user_id" : 7777252,
  "text" : "@xenocid @nrhm Just because *all* homicides aren\u2019t caused by guns doesn\u2019t mean they should stay easily accessible. More red herring.",
  "id" : 227950429651230720,
  "in_reply_to_status_id" : 227949544929910784,
  "created_at" : "Wed Jul 25 02:16:32 +0000 2012",
  "in_reply_to_screen_name" : "xenocid",
  "in_reply_to_user_id_str" : "7777252",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Koloskov",
      "screen_name" : "xenocid",
      "indices" : [ 0, 8 ],
      "id_str" : "7777252",
      "id" : 7777252
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "227948898751229952",
  "geo" : {
  },
  "id_str" : "227949675683119104",
  "in_reply_to_user_id" : 7777252,
  "text" : "@xenocid I\u2019m just saying that it\u2019s not a coincidence that gun ownership and homicides are statistically linked. Are you arguing otherwise?",
  "id" : 227949675683119104,
  "in_reply_to_status_id" : 227948898751229952,
  "created_at" : "Wed Jul 25 02:13:32 +0000 2012",
  "in_reply_to_screen_name" : "xenocid",
  "in_reply_to_user_id_str" : "7777252",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Koloskov",
      "screen_name" : "xenocid",
      "indices" : [ 0, 8 ],
      "id_str" : "7777252",
      "id" : 7777252
    }, {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 9, 18 ],
      "id_str" : "761628",
      "id" : 761628
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "227937544405413889",
  "geo" : {
  },
  "id_str" : "227947396745809920",
  "in_reply_to_user_id" : 7777252,
  "text" : "@xenocid @RickWebb When guns are involved it\u2019s not a stretch to assume that guns DO cause homicides. That\u2019s what they are for.",
  "id" : 227947396745809920,
  "in_reply_to_status_id" : 227937544405413889,
  "created_at" : "Wed Jul 25 02:04:29 +0000 2012",
  "in_reply_to_screen_name" : "xenocid",
  "in_reply_to_user_id_str" : "7777252",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Koloskov",
      "screen_name" : "xenocid",
      "indices" : [ 0, 8 ],
      "id_str" : "7777252",
      "id" : 7777252
    }, {
      "name" : "Nikolay Ruban",
      "screen_name" : "nrhm",
      "indices" : [ 9, 14 ],
      "id_str" : "4011261",
      "id" : 4011261
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "227936440854659073",
  "geo" : {
  },
  "id_str" : "227946966724784128",
  "in_reply_to_user_id" : 7777252,
  "text" : "@xenocid @nrhm They might try, but probably won\u2019t kill 20 people and injure 40 more. Again: better tools = better results.",
  "id" : 227946966724784128,
  "in_reply_to_status_id" : 227936440854659073,
  "created_at" : "Wed Jul 25 02:02:46 +0000 2012",
  "in_reply_to_screen_name" : "xenocid",
  "in_reply_to_user_id_str" : "7777252",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Koloskov",
      "screen_name" : "xenocid",
      "indices" : [ 0, 8 ],
      "id_str" : "7777252",
      "id" : 7777252
    }, {
      "name" : "Nikolay Ruban",
      "screen_name" : "nrhm",
      "indices" : [ 9, 14 ],
      "id_str" : "4011261",
      "id" : 4011261
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "227936105721380864",
  "geo" : {
  },
  "id_str" : "227946504269217792",
  "in_reply_to_user_id" : 7777252,
  "text" : "@xenocid @nrhm Two wrongs don\u2019t make a right fallacy. Also, red herring fallacy.",
  "id" : 227946504269217792,
  "in_reply_to_status_id" : 227936105721380864,
  "created_at" : "Wed Jul 25 02:00:56 +0000 2012",
  "in_reply_to_screen_name" : "xenocid",
  "in_reply_to_user_id_str" : "7777252",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "girl jo",
      "screen_name" : "octavekitten",
      "indices" : [ 0, 13 ],
      "id_str" : "16366882",
      "id" : 16366882
    }, {
      "name" : "Aimee",
      "screen_name" : "LilHossler",
      "indices" : [ 14, 25 ],
      "id_str" : "123116307",
      "id" : 123116307
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "227925653452910592",
  "geo" : {
  },
  "id_str" : "227928210216726529",
  "in_reply_to_user_id" : 16366882,
  "text" : "@octavekitten @LilHossler I think I skipped that one. Oops.",
  "id" : 227928210216726529,
  "in_reply_to_status_id" : 227925653452910592,
  "created_at" : "Wed Jul 25 00:48:14 +0000 2012",
  "in_reply_to_screen_name" : "octavekitten",
  "in_reply_to_user_id_str" : "16366882",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "girl jo",
      "screen_name" : "octavekitten",
      "indices" : [ 0, 13 ],
      "id_str" : "16366882",
      "id" : 16366882
    }, {
      "name" : "Aimee",
      "screen_name" : "LilHossler",
      "indices" : [ 14, 25 ],
      "id_str" : "123116307",
      "id" : 123116307
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "227923161084223488",
  "geo" : {
  },
  "id_str" : "227925584695664640",
  "in_reply_to_user_id" : 16366882,
  "text" : "@octavekitten @LilHossler Which books did you ever like by him? He\u2019s a great reader but I\u2019ve never liked his books.",
  "id" : 227925584695664640,
  "in_reply_to_status_id" : 227923161084223488,
  "created_at" : "Wed Jul 25 00:37:48 +0000 2012",
  "in_reply_to_screen_name" : "octavekitten",
  "in_reply_to_user_id_str" : "16366882",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Koloskov",
      "screen_name" : "xenocid",
      "indices" : [ 0, 8 ],
      "id_str" : "7777252",
      "id" : 7777252
    }, {
      "name" : "Nikolay Ruban",
      "screen_name" : "nrhm",
      "indices" : [ 9, 14 ],
      "id_str" : "4011261",
      "id" : 4011261
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "227824655568879616",
  "geo" : {
  },
  "id_str" : "227879958863806464",
  "in_reply_to_user_id" : 7777252,
  "text" : "@xenocid @nrhm Does 10,000 deaths a year seem acceptable?",
  "id" : 227879958863806464,
  "in_reply_to_status_id" : 227824655568879616,
  "created_at" : "Tue Jul 24 21:36:30 +0000 2012",
  "in_reply_to_screen_name" : "xenocid",
  "in_reply_to_user_id_str" : "7777252",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nikolay Ruban",
      "screen_name" : "nrhm",
      "indices" : [ 0, 5 ],
      "id_str" : "4011261",
      "id" : 4011261
    }, {
      "name" : "Alex Koloskov",
      "screen_name" : "xenocid",
      "indices" : [ 6, 14 ],
      "id_str" : "7777252",
      "id" : 7777252
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "227785063889264640",
  "geo" : {
  },
  "id_str" : "227787602143612929",
  "in_reply_to_user_id" : 4011261,
  "text" : "@nrhm @xenocid Did the guards kill 31,224 people last year? That's how many gun-related homicides there were in the US in 2007.",
  "id" : 227787602143612929,
  "in_reply_to_status_id" : 227785063889264640,
  "created_at" : "Tue Jul 24 15:29:31 +0000 2012",
  "in_reply_to_screen_name" : "nrhm",
  "in_reply_to_user_id_str" : "4011261",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http://t.co/YddoJOR2",
      "expanded_url" : "http://instagr.am/p/Ncu8kNo0As/",
      "display_url" : "instagr.am/p/Ncu8kNo0As/"
    } ]
  },
  "geo" : {
  },
  "id_str" : "227610274729963520",
  "text" : "8:36pm Cleaning up train track fossils http://t.co/YddoJOR2",
  "id" : 227610274729963520,
  "created_at" : "Tue Jul 24 03:44:52 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim O'Reilly",
      "screen_name" : "timoreilly",
      "indices" : [ 16, 27 ],
      "id_str" : "2384071",
      "id" : 2384071
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "teamsparrow",
      "indices" : [ 0, 12 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 137 ],
      "url" : "http://t.co/EvCJ8XP2",
      "expanded_url" : "http://bit.ly/SRaFbC",
      "display_url" : "bit.ly/SRaFbC"
    } ]
  },
  "geo" : {
  },
  "id_str" : "227609304457424897",
  "text" : "#teamsparrow RT @timoreilly: The Sparrow Problem: analysis of just how hard it is to make a living via the App Store http://t.co/EvCJ8XP2",
  "id" : 227609304457424897,
  "created_at" : "Tue Jul 24 03:41:01 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ANNE LAMOTT",
      "screen_name" : "ANNELAMOTT",
      "indices" : [ 3, 14 ],
      "id_str" : "389974502",
      "id" : 389974502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "227607300590948352",
  "text" : "RT @ANNELAMOTT: My friend Paul O said that we're like children in those car seats w/ steering wheels, convinced we're making the car tur ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://blackberry.com/twitter\" rel=\"nofollow\">Twitter for BlackBerry\u00AE</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "227606806770352129",
    "text" : "My friend Paul O said that we're like children in those car seats w/ steering wheels, convinced we're making the car turn right or left.",
    "id" : 227606806770352129,
    "created_at" : "Tue Jul 24 03:31:06 +0000 2012",
    "user" : {
      "name" : "ANNE LAMOTT",
      "screen_name" : "ANNELAMOTT",
      "protected" : false,
      "id_str" : "389974502",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1836893156/mom_twitter_normal.jpg",
      "id" : 389974502,
      "verified" : true
    }
  },
  "id" : 227607300590948352,
  "created_at" : "Tue Jul 24 03:33:03 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "L.M. Murphy",
      "screen_name" : "murphyslawyer22",
      "indices" : [ 0, 16 ],
      "id_str" : "91969309",
      "id" : 91969309
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "227547037435047936",
  "geo" : {
  },
  "id_str" : "227547411927666689",
  "in_reply_to_user_id" : 91969309,
  "text" : "@murphyslawyer22 Maybe you\u2019d be matched together but not told which strongly held belief you differ on?",
  "id" : 227547411927666689,
  "in_reply_to_status_id" : 227547037435047936,
  "created_at" : "Mon Jul 23 23:35:05 +0000 2012",
  "in_reply_to_screen_name" : "murphyslawyer22",
  "in_reply_to_user_id_str" : "91969309",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Derek Shanahooligan",
      "screen_name" : "dshanahan",
      "indices" : [ 0, 10 ],
      "id_str" : "992071682",
      "id" : 992071682
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "227546714888884224",
  "geo" : {
  },
  "id_str" : "227547149724962816",
  "in_reply_to_user_id" : 6579512,
  "text" : "@dshanahan 1) think of question 2) ask twitter 3) think some more. :) But no, haven\u2019t written much about it. It seems intangible.",
  "id" : 227547149724962816,
  "in_reply_to_status_id" : 227546714888884224,
  "created_at" : "Mon Jul 23 23:34:02 +0000 2012",
  "in_reply_to_screen_name" : "dshan",
  "in_reply_to_user_id_str" : "6579512",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Renee DiResta",
      "screen_name" : "noUpside",
      "indices" : [ 3, 12 ],
      "id_str" : "24254084",
      "id" : 24254084
    }, {
      "name" : "Anti-Buster",
      "screen_name" : "busterbenson",
      "indices" : [ 14, 27 ],
      "id_str" : "1024917050",
      "id" : 1024917050
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "227546826159554561",
  "text" : "RT @noUpside: @busterbenson beyond beliefs, i'd be interested in a penpal w/different lifestyle choices.  curious about stay-at-home mom ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Anti-Buster",
        "screen_name" : "busterbenson",
        "indices" : [ 0, 13 ],
        "id_str" : "1024917050",
        "id" : 1024917050
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "227544373343186944",
    "geo" : {
    },
    "id_str" : "227546276777046016",
    "in_reply_to_user_id" : 2185,
    "text" : "@busterbenson beyond beliefs, i'd be interested in a penpal w/different lifestyle choices.  curious about stay-at-home moms, for example.",
    "id" : 227546276777046016,
    "in_reply_to_status_id" : 227544373343186944,
    "created_at" : "Mon Jul 23 23:30:34 +0000 2012",
    "in_reply_to_screen_name" : "buster",
    "in_reply_to_user_id_str" : "2185",
    "user" : {
      "name" : "Renee DiResta",
      "screen_name" : "noUpside",
      "protected" : false,
      "id_str" : "24254084",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1246331423/pic_normal.jpg",
      "id" : 24254084,
      "verified" : false
    }
  },
  "id" : 227546826159554561,
  "created_at" : "Mon Jul 23 23:32:45 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Renee DiResta",
      "screen_name" : "noUpside",
      "indices" : [ 0, 9 ],
      "id_str" : "24254084",
      "id" : 24254084
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "227546276777046016",
  "geo" : {
  },
  "id_str" : "227546823445860353",
  "in_reply_to_user_id" : 24254084,
  "text" : "@noUpside Ooh that\u2019s a great idea. Hadn\u2019t thought of that angle.",
  "id" : 227546823445860353,
  "in_reply_to_status_id" : 227546276777046016,
  "created_at" : "Mon Jul 23 23:32:44 +0000 2012",
  "in_reply_to_screen_name" : "noUpside",
  "in_reply_to_user_id_str" : "24254084",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "L.M. Murphy",
      "screen_name" : "murphyslawyer22",
      "indices" : [ 0, 16 ],
      "id_str" : "91969309",
      "id" : 91969309
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "227546244996816896",
  "geo" : {
  },
  "id_str" : "227546686254354432",
  "in_reply_to_user_id" : 91969309,
  "text" : "@murphyslawyer22 Maybe. I think the double opt-in of both people wanting to talk might allow more open communication. Haven\u2019t tested it tho.",
  "id" : 227546686254354432,
  "in_reply_to_status_id" : 227546244996816896,
  "created_at" : "Mon Jul 23 23:32:12 +0000 2012",
  "in_reply_to_screen_name" : "murphyslawyer22",
  "in_reply_to_user_id_str" : "91969309",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ingopixel",
      "screen_name" : "ingopixel",
      "indices" : [ 3, 13 ],
      "id_str" : "7943892",
      "id" : 7943892
    }, {
      "name" : "Anti-Buster",
      "screen_name" : "busterbenson",
      "indices" : [ 15, 28 ],
      "id_str" : "1024917050",
      "id" : 1024917050
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "227546371132108800",
  "text" : "RT @ingopixel: @busterbenson I'd like to talk to a creationist about evolution. or a sexist man or woman about women's rights. or a vega ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Anti-Buster",
        "screen_name" : "busterbenson",
        "indices" : [ 0, 13 ],
        "id_str" : "1024917050",
        "id" : 1024917050
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "227545215026724864",
    "geo" : {
    },
    "id_str" : "227545878351720449",
    "in_reply_to_user_id" : 2185,
    "text" : "@busterbenson I'd like to talk to a creationist about evolution. or a sexist man or woman about women's rights. or a vegan about food.",
    "id" : 227545878351720449,
    "in_reply_to_status_id" : 227545215026724864,
    "created_at" : "Mon Jul 23 23:28:59 +0000 2012",
    "in_reply_to_screen_name" : "buster",
    "in_reply_to_user_id_str" : "2185",
    "user" : {
      "name" : "ingopixel",
      "screen_name" : "ingopixel",
      "protected" : false,
      "id_str" : "7943892",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3340386384/2d7c3a3726c459f4621182f7f221dca5_normal.jpeg",
      "id" : 7943892,
      "verified" : false
    }
  },
  "id" : 227546371132108800,
  "created_at" : "Mon Jul 23 23:30:57 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Derek Shanahooligan",
      "screen_name" : "dshanahan",
      "indices" : [ 3, 13 ],
      "id_str" : "992071682",
      "id" : 992071682
    }, {
      "name" : "Anti-Buster",
      "screen_name" : "busterbenson",
      "indices" : [ 15, 28 ],
      "id_str" : "1024917050",
      "id" : 1024917050
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "227545815391010816",
  "text" : "RT @dshanahan: @busterbenson Technology; broadly optimistic vs pessimistic (I'm the former).",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.hootsuite.com\" rel=\"nofollow\">HootSuite</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Anti-Buster",
        "screen_name" : "busterbenson",
        "indices" : [ 0, 13 ],
        "id_str" : "1024917050",
        "id" : 1024917050
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "227544373343186944",
    "geo" : {
    },
    "id_str" : "227545522498588673",
    "in_reply_to_user_id" : 2185,
    "text" : "@busterbenson Technology; broadly optimistic vs pessimistic (I'm the former).",
    "id" : 227545522498588673,
    "in_reply_to_status_id" : 227544373343186944,
    "created_at" : "Mon Jul 23 23:27:34 +0000 2012",
    "in_reply_to_screen_name" : "buster",
    "in_reply_to_user_id_str" : "2185",
    "user" : {
      "name" : "Derek Shanahan",
      "screen_name" : "dshan",
      "protected" : false,
      "id_str" : "6579512",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3222848849/63a9224fa6151ff51fd9def9849742c0_normal.jpeg",
      "id" : 6579512,
      "verified" : false
    }
  },
  "id" : 227545815391010816,
  "created_at" : "Mon Jul 23 23:28:44 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Derek Shanahooligan",
      "screen_name" : "dshanahan",
      "indices" : [ 0, 10 ],
      "id_str" : "992071682",
      "id" : 992071682
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "227545522498588673",
  "geo" : {
  },
  "id_str" : "227545791043100672",
  "in_reply_to_user_id" : 6579512,
  "text" : "@dshanahan I like that one and hadn\u2019t thought of it before.",
  "id" : 227545791043100672,
  "in_reply_to_status_id" : 227545522498588673,
  "created_at" : "Mon Jul 23 23:28:38 +0000 2012",
  "in_reply_to_screen_name" : "dshan",
  "in_reply_to_user_id_str" : "6579512",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "L.M. Murphy",
      "screen_name" : "murphyslawyer22",
      "indices" : [ 0, 16 ],
      "id_str" : "91969309",
      "id" : 91969309
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "227544698275909632",
  "geo" : {
  },
  "id_str" : "227545598738452480",
  "in_reply_to_user_id" : 91969309,
  "text" : "@murphyslawyer22 Would potentially volatile conversations be less volatile in a friendly penpal context maybe?",
  "id" : 227545598738452480,
  "in_reply_to_status_id" : 227544698275909632,
  "created_at" : "Mon Jul 23 23:27:52 +0000 2012",
  "in_reply_to_screen_name" : "murphyslawyer22",
  "in_reply_to_user_id_str" : "91969309",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "227545215026724864",
  "text" : "For the previous penpal question, assume that your identities are both protected during the duration of said penpalship.",
  "id" : 227545215026724864,
  "created_at" : "Mon Jul 23 23:26:21 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "227544373343186944",
  "text" : "If you could get a penpal who differed from you in one strongly held belief, which issue would you want to talk about?",
  "id" : 227544373343186944,
  "created_at" : "Mon Jul 23 23:23:00 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Koloskov",
      "screen_name" : "xenocid",
      "indices" : [ 0, 8 ],
      "id_str" : "7777252",
      "id" : 7777252
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http://t.co/8qdYfLzw",
      "expanded_url" : "http://www.unicri.eu/documentation_centre/publications/series/understanding/19_GUN_OWNERSHIP.pdf",
      "display_url" : "unicri.eu/documentation_\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "227485516700999680",
  "geo" : {
  },
  "id_str" : "227487412077604864",
  "in_reply_to_user_id" : 7777252,
  "text" : "@xenocid Would you believe studies that have confirmed gun control lowers suicide and homicide rates internationally? http://t.co/8qdYfLzw",
  "id" : 227487412077604864,
  "in_reply_to_status_id" : 227485516700999680,
  "created_at" : "Mon Jul 23 19:36:40 +0000 2012",
  "in_reply_to_screen_name" : "xenocid",
  "in_reply_to_user_id_str" : "7777252",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Cole",
      "screen_name" : "irondavy",
      "indices" : [ 3, 12 ],
      "id_str" : "14986129",
      "id" : 14986129
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "227482227393564673",
  "text" : "RT @irondavy: AWESOME question: What are cool, inexpensive home science experiments can I do to blow my son's mind? 8 Answers: http://t. ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.quora.com/\" rel=\"nofollow\">Quora</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 133 ],
        "url" : "http://t.co/Et7SJfUa",
        "expanded_url" : "http://qr.ae/8PkGA",
        "display_url" : "qr.ae/8PkGA"
      } ]
    },
    "geo" : {
    },
    "id_str" : "227481957368463360",
    "text" : "AWESOME question: What are cool, inexpensive home science experiments can I do to blow my son's mind? 8 Answers: http://t.co/Et7SJfUa",
    "id" : 227481957368463360,
    "created_at" : "Mon Jul 23 19:14:59 +0000 2012",
    "user" : {
      "name" : "David Cole",
      "screen_name" : "irondavy",
      "protected" : false,
      "id_str" : "14986129",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/344513261572048058/33bdbd456c7c062e7edfbe58b9d90fcb_normal.png",
      "id" : 14986129,
      "verified" : false
    }
  },
  "id" : 227482227393564673,
  "created_at" : "Mon Jul 23 19:16:04 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Bold Academy",
      "screen_name" : "BoldAcademy",
      "indices" : [ 3, 15 ],
      "id_str" : "502177948",
      "id" : 502177948
    }, {
      "name" : "Anti-Buster",
      "screen_name" : "busterbenson",
      "indices" : [ 81, 94 ],
      "id_str" : "1024917050",
      "id" : 1024917050
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "boldacademy",
      "indices" : [ 61, 73 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 115 ],
      "url" : "http://t.co/3f6hwg8c",
      "expanded_url" : "http://www.boldacademy.com/fail-proof-your-habit-decisions/",
      "display_url" : "boldacademy.com/fail-proof-you\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "227481408522813440",
  "text" : "RT @BoldAcademy: Fail-proof your habit decisions. A story by #boldacademy mentor @busterbenson http://t.co/3f6hwg8c",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Anti-Buster",
        "screen_name" : "busterbenson",
        "indices" : [ 64, 77 ],
        "id_str" : "1024917050",
        "id" : 1024917050
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "boldacademy",
        "indices" : [ 44, 56 ]
      } ],
      "urls" : [ {
        "indices" : [ 78, 98 ],
        "url" : "http://t.co/3f6hwg8c",
        "expanded_url" : "http://www.boldacademy.com/fail-proof-your-habit-decisions/",
        "display_url" : "boldacademy.com/fail-proof-you\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "227465338340651008",
    "text" : "Fail-proof your habit decisions. A story by #boldacademy mentor @busterbenson http://t.co/3f6hwg8c",
    "id" : 227465338340651008,
    "created_at" : "Mon Jul 23 18:08:57 +0000 2012",
    "user" : {
      "name" : "The Bold Academy",
      "screen_name" : "BoldAcademy",
      "protected" : false,
      "id_str" : "502177948",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2218780046/bold_fb_normal.jpg",
      "id" : 502177948,
      "verified" : false
    }
  },
  "id" : 227481408522813440,
  "created_at" : "Mon Jul 23 19:12:48 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BJ Fogg",
      "screen_name" : "bjfogg",
      "indices" : [ 0, 7 ],
      "id_str" : "1118691",
      "id" : 1118691
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 127 ],
      "url" : "http://t.co/LuHmv0Jt",
      "expanded_url" : "http://www.geekwire.com/2012/day-rest-life/",
      "display_url" : "geekwire.com/2012/day-rest-\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "227477359207526400",
  "geo" : {
  },
  "id_str" : "227479991347204099",
  "in_reply_to_user_id" : 1118691,
  "text" : "@bjfogg Finally, here\u2019s the full story of how my 8:36pm habit got started, and has continued for 4+ years: http://t.co/LuHmv0Jt",
  "id" : 227479991347204099,
  "in_reply_to_status_id" : 227477359207526400,
  "created_at" : "Mon Jul 23 19:07:10 +0000 2012",
  "in_reply_to_screen_name" : "bjfogg",
  "in_reply_to_user_id_str" : "1118691",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BJ Fogg",
      "screen_name" : "bjfogg",
      "indices" : [ 0, 7 ],
      "id_str" : "1118691",
      "id" : 1118691
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "227477359207526400",
  "geo" : {
  },
  "id_str" : "227479768830988288",
  "in_reply_to_user_id" : 1118691,
  "text" : "@bjfogg Another phone-related habit is to drink 2 glasses of water before looking at my phone in the morning.",
  "id" : 227479768830988288,
  "in_reply_to_status_id" : 227477359207526400,
  "created_at" : "Mon Jul 23 19:06:17 +0000 2012",
  "in_reply_to_screen_name" : "bjfogg",
  "in_reply_to_user_id_str" : "1118691",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BJ Fogg",
      "screen_name" : "bjfogg",
      "indices" : [ 0, 7 ],
      "id_str" : "1118691",
      "id" : 1118691
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "227477359207526400",
  "geo" : {
  },
  "id_str" : "227479529906655232",
  "in_reply_to_user_id" : 1118691,
  "text" : "@bjfogg I have a 8:30am alarm to do 33 pushups, a 3pm alarm to stand up &amp; stretch, &amp; an 8:36pm alarm to take a picture. Happy to talk more!",
  "id" : 227479529906655232,
  "in_reply_to_status_id" : 227477359207526400,
  "created_at" : "Mon Jul 23 19:05:20 +0000 2012",
  "in_reply_to_screen_name" : "bjfogg",
  "in_reply_to_user_id_str" : "1118691",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amy Jo Kim",
      "screen_name" : "amyjokim",
      "indices" : [ 0, 9 ],
      "id_str" : "780991",
      "id" : 780991
    }, {
      "name" : "BJ Fogg",
      "screen_name" : "bjfogg",
      "indices" : [ 10, 17 ],
      "id_str" : "1118691",
      "id" : 1118691
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "227467371147845633",
  "geo" : {
  },
  "id_str" : "227473888697802752",
  "in_reply_to_user_id" : 780991,
  "text" : "@amyjokim @bjfogg Same here. I have started and maintained several long-term habits with simple alarms.",
  "id" : 227473888697802752,
  "in_reply_to_status_id" : 227467371147845633,
  "created_at" : "Mon Jul 23 18:42:55 +0000 2012",
  "in_reply_to_screen_name" : "amyjokim",
  "in_reply_to_user_id_str" : "780991",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Koloskov",
      "screen_name" : "xenocid",
      "indices" : [ 0, 8 ],
      "id_str" : "7777252",
      "id" : 7777252
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "227470020316372992",
  "geo" : {
  },
  "id_str" : "227471348392411137",
  "in_reply_to_user_id" : 7777252,
  "text" : "@xenocid I think crazy people can kill more people with guns than knives. Even more if bombs were legal. Better tools = better results.",
  "id" : 227471348392411137,
  "in_reply_to_status_id" : 227470020316372992,
  "created_at" : "Mon Jul 23 18:32:50 +0000 2012",
  "in_reply_to_screen_name" : "xenocid",
  "in_reply_to_user_id_str" : "7777252",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Koloskov",
      "screen_name" : "xenocid",
      "indices" : [ 0, 8 ],
      "id_str" : "7777252",
      "id" : 7777252
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "227343103739187200",
  "geo" : {
  },
  "id_str" : "227413230283272192",
  "in_reply_to_user_id" : 7777252,
  "text" : "@xenocid I think it's so that fewer people get killed by them / kill with them.",
  "id" : 227413230283272192,
  "in_reply_to_status_id" : 227343103739187200,
  "created_at" : "Mon Jul 23 14:41:53 +0000 2012",
  "in_reply_to_screen_name" : "xenocid",
  "in_reply_to_user_id_str" : "7777252",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ArielMeadowStallings",
      "screen_name" : "OffbeatAriel",
      "indices" : [ 0, 13 ],
      "id_str" : "14095370",
      "id" : 14095370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "227231423759785984",
  "geo" : {
  },
  "id_str" : "227261970942926849",
  "in_reply_to_user_id" : 14095370,
  "text" : "@OffbeatAriel Yeah he\u2019s definitely expanding my understanding of the depth of train videos on YouTube.",
  "id" : 227261970942926849,
  "in_reply_to_status_id" : 227231423759785984,
  "created_at" : "Mon Jul 23 04:40:50 +0000 2012",
  "in_reply_to_screen_name" : "OffbeatAriel",
  "in_reply_to_user_id_str" : "14095370",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 8, 17 ],
      "id_str" : "761628",
      "id" : 761628
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 97 ],
      "url" : "http://t.co/gaLUwIgO",
      "expanded_url" : "http://bit.ly/MieiUE",
      "display_url" : "bit.ly/MieiUE"
    } ]
  },
  "geo" : {
  },
  "id_str" : "227261338869710849",
  "text" : "On team @rickwebb as he talks about guns and drugs today via Tumblr Q&amp;A: http://t.co/gaLUwIgO",
  "id" : 227261338869710849,
  "created_at" : "Mon Jul 23 04:38:20 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 49 ],
      "url" : "http://t.co/N4H2hHxA",
      "expanded_url" : "http://flic.kr/p/cBZ8SA",
      "display_url" : "flic.kr/p/cBZ8SA"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.611, -122.343 ]
  },
  "id_str" : "227246302436683777",
  "text" : "8:36pm Eating grilled cheese http://t.co/N4H2hHxA",
  "id" : 227246302436683777,
  "created_at" : "Mon Jul 23 03:38:35 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anti-Buster",
      "screen_name" : "busterbenson",
      "indices" : [ 0, 13 ],
      "id_str" : "1024917050",
      "id" : 1024917050
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "227201406690525184",
  "geo" : {
  },
  "id_str" : "227201644675354624",
  "in_reply_to_user_id" : 2185,
  "text" : "@busterbenson Thanks, Niko.",
  "id" : 227201644675354624,
  "in_reply_to_status_id" : 227201406690525184,
  "created_at" : "Mon Jul 23 00:41:07 +0000 2012",
  "in_reply_to_screen_name" : "buster",
  "in_reply_to_user_id_str" : "2185",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.apple.com\" rel=\"nofollow\">YouTube on iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "v",
      "indices" : [ 5, 7 ]
    } ],
    "urls" : [ {
      "indices" : [ 30, 50 ],
      "url" : "http://t.co/wbVNtDI2",
      "expanded_url" : "http://www.youtube.com/watch?v=GcH9ZhZPaJU&feature=youtube_gdata_player",
      "display_url" : "youtube.com/watch?v=GcH9Zh\u2026"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.608625, -122.306246 ]
  },
  "id_str" : "227201406690525184",
  "text" : "@. @##v kkkiiiuuuuiuhuujhnbbb http://t.co/wbVNtDI2",
  "id" : 227201406690525184,
  "created_at" : "Mon Jul 23 00:40:11 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Noah Iliinsky",
      "screen_name" : "noahi",
      "indices" : [ 127, 133 ],
      "id_str" : "15399031",
      "id" : 15399031
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 121 ],
      "url" : "http://t.co/Nldf2jEA",
      "expanded_url" : "http://www.nytimes.com/2012/07/22/opinion/sunday/our-ridiculous-approach-to-retirement.html",
      "display_url" : "nytimes.com/2012/07/22/opi\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "227200373088219136",
  "text" : "Our ridiculous approach to retirement (I haven't added to my 401K since starting my own businesses): http://t.co/Nldf2jEA /via @noahi",
  "id" : 227200373088219136,
  "created_at" : "Mon Jul 23 00:36:04 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 97 ],
      "url" : "http://t.co/y0MB3Lpv",
      "expanded_url" : "http://instagr.am/p/NZmE3ko0Ga/",
      "display_url" : "instagr.am/p/NZmE3ko0Ga/"
    } ]
  },
  "geo" : {
  },
  "id_str" : "227168665332764672",
  "text" : "After several hours of debate I learn \"No nap!\" only applies to bedroom naps http://t.co/y0MB3Lpv",
  "id" : 227168665332764672,
  "created_at" : "Sun Jul 22 22:30:05 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 85 ],
      "url" : "http://t.co/9l8r2BGF",
      "expanded_url" : "http://instagr.am/p/NWtCUyI0GE/",
      "display_url" : "instagr.am/p/NWtCUyI0GE/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6081305535, -122.299547195 ]
  },
  "id_str" : "226761607068393473",
  "text" : "Ping pong on our first Saturday Familyday ever!  @ Twilight Exit http://t.co/9l8r2BGF",
  "id" : 226761607068393473,
  "created_at" : "Sat Jul 21 19:32:34 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erik F. Kastner",
      "screen_name" : "kastner",
      "indices" : [ 0, 8 ],
      "id_str" : "627303",
      "id" : 627303
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "226727910801817601",
  "geo" : {
  },
  "id_str" : "226728793971240960",
  "in_reply_to_user_id" : 627303,
  "text" : "@kastner They had 128 processors. :)",
  "id" : 226728793971240960,
  "in_reply_to_status_id" : 226727910801817601,
  "created_at" : "Sat Jul 21 17:22:11 +0000 2012",
  "in_reply_to_screen_name" : "kastner",
  "in_reply_to_user_id_str" : "627303",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Foursquare",
      "screen_name" : "foursquare",
      "indices" : [ 52, 63 ],
      "id_str" : "14120151",
      "id" : 14120151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 131 ],
      "url" : "http://t.co/6oYGnMhb",
      "expanded_url" : "http://4sq.com/ONasoP",
      "display_url" : "4sq.com/ONasoP"
    } ]
  },
  "geo" : {
  },
  "id_str" : "226727026873225216",
  "text" : "I just reached Level 7 of the \"Fresh Brew\" badge on @foursquare. I\u2019ve checked in at 30 different coffee shops! http://t.co/6oYGnMhb",
  "id" : 226727026873225216,
  "created_at" : "Sat Jul 21 17:15:10 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 111 ],
      "url" : "http://t.co/WUqWtSg0",
      "expanded_url" : "http://flic.kr/p/cANfT3",
      "display_url" : "flic.kr/p/cANfT3"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.608666, -122.305834 ]
  },
  "id_str" : "226562923840036864",
  "text" : "8:36pm Was watching The Proposal with Loren and Tyler but forgot to take a picture [rerun] http://t.co/WUqWtSg0",
  "id" : 226562923840036864,
  "created_at" : "Sat Jul 21 06:23:05 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 35 ],
      "url" : "http://t.co/EB47RVb7",
      "expanded_url" : "http://instagr.am/p/NU7f4no0O3/",
      "display_url" : "instagr.am/p/NU7f4no0O3/"
    } ]
  },
  "geo" : {
  },
  "id_str" : "226511900014432257",
  "text" : "I love my team http://t.co/EB47RVb7",
  "id" : 226511900014432257,
  "created_at" : "Sat Jul 21 03:00:20 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "226509475689930752",
  "text" : "Idea: email penpal service that matches you with someone from a demographic that you\u2019re prejudiced against or who is prejudiced against you.",
  "id" : 226509475689930752,
  "created_at" : "Sat Jul 21 02:50:42 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "226416150660145152",
  "text" : "Modeling the lifespan of the simplest cell takes 128 computers and 10 hours of crunching. How long til we can do it faster than nature?",
  "id" : 226416150660145152,
  "created_at" : "Fri Jul 20 20:39:51 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 139 ],
      "url" : "http://t.co/MsIKMXyK",
      "expanded_url" : "http://www.nytimes.com/2012/07/21/science/in-a-first-an-entire-organism-is-simulated-by-software.html",
      "display_url" : "nytimes.com/2012/07/21/sci\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "226414231048843264",
  "text" : "\u201CRunning a simulation for a single cell to divide only 1 time takes 10 hours and generates .5GB of data.\u201D - Dr. Covert\nhttp://t.co/MsIKMXyK",
  "id" : 226414231048843264,
  "created_at" : "Fri Jul 20 20:32:13 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cap Watkins",
      "screen_name" : "cap",
      "indices" : [ 0, 4 ],
      "id_str" : "2182141",
      "id" : 2182141
    }, {
      "name" : "Kevin Cheng",
      "screen_name" : "k",
      "indices" : [ 5, 7 ],
      "id_str" : "11222",
      "id" : 11222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "226354070754045952",
  "geo" : {
  },
  "id_str" : "226355546486366209",
  "in_reply_to_user_id" : 2182141,
  "text" : "@cap @k And also explains why they haven\u2019t gotten it working in iOS 6.0 beta yet. Formatting is broken. I hope they at least fix that.",
  "id" : 226355546486366209,
  "in_reply_to_status_id" : 226354070754045952,
  "created_at" : "Fri Jul 20 16:39:02 +0000 2012",
  "in_reply_to_screen_name" : "cap",
  "in_reply_to_user_id_str" : "2182141",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Galen Ward",
      "screen_name" : "galenward",
      "indices" : [ 0, 10 ],
      "id_str" : "2854761",
      "id" : 2854761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "226120895096303616",
  "geo" : {
  },
  "id_str" : "226126975742377985",
  "in_reply_to_user_id" : 2854761,
  "text" : "@galenward The universe loves you anyway.",
  "id" : 226126975742377985,
  "in_reply_to_status_id" : 226120895096303616,
  "created_at" : "Fri Jul 20 01:30:46 +0000 2012",
  "in_reply_to_screen_name" : "galenward",
  "in_reply_to_user_id_str" : "2854761",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http://t.co/a4EpLCWb",
      "expanded_url" : "http://instagr.am/p/NSMSI8o0PB/",
      "display_url" : "instagr.am/p/NSMSI8o0PB/"
    } ]
  },
  "geo" : {
  },
  "id_str" : "226126696389165057",
  "text" : "\"Honey bee hat\" http://t.co/a4EpLCWb",
  "id" : 226126696389165057,
  "created_at" : "Fri Jul 20 01:29:40 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Skotzko",
      "screen_name" : "askotzko",
      "indices" : [ 119, 128 ],
      "id_str" : "15391002",
      "id" : 15391002
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 113 ],
      "url" : "http://t.co/oLWaVWW0",
      "expanded_url" : "http://htwins.net/scale2/",
      "display_url" : "htwins.net/scale2/"
    } ]
  },
  "geo" : {
  },
  "id_str" : "226116777610977280",
  "text" : "Beautiful demonstration of the scale of things in our universe (zoom all the way out first): http://t.co/oLWaVWW0 /via @askotzko",
  "id" : 226116777610977280,
  "created_at" : "Fri Jul 20 00:50:15 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sara Jensen",
      "screen_name" : "sarajensen",
      "indices" : [ 0, 11 ],
      "id_str" : "22135588",
      "id" : 22135588
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "226103847075074050",
  "geo" : {
  },
  "id_str" : "226114036079673344",
  "in_reply_to_user_id" : 22135588,
  "text" : "@sarajensen Or your bras are.",
  "id" : 226114036079673344,
  "in_reply_to_status_id" : 226103847075074050,
  "created_at" : "Fri Jul 20 00:39:21 +0000 2012",
  "in_reply_to_screen_name" : "sarajensen",
  "in_reply_to_user_id_str" : "22135588",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Berkun",
      "screen_name" : "berkun",
      "indices" : [ 13, 20 ],
      "id_str" : "30495974",
      "id" : 30495974
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ideas",
      "indices" : [ 90, 96 ]
    }, {
      "text" : "creativity",
      "indices" : [ 97, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 69, 89 ],
      "url" : "http://t.co/KXgubZuI",
      "expanded_url" : "http://wp.me/p4vkk-2wB",
      "display_url" : "wp.me/p4vkk-2wB"
    } ]
  },
  "geo" : {
  },
  "id_str" : "226075672341254146",
  "text" : "Right on! RT @berkun: How to become creative: the short honest truth http://t.co/KXgubZuI #ideas #creativity",
  "id" : 226075672341254146,
  "created_at" : "Thu Jul 19 22:06:55 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian McAllister",
      "screen_name" : "ianmcall",
      "indices" : [ 0, 9 ],
      "id_str" : "2035631",
      "id" : 2035631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "226037848111996928",
  "geo" : {
  },
  "id_str" : "226046864632471552",
  "in_reply_to_user_id" : 2035631,
  "text" : "@ianmcall Great! What time tomorrow can you come by to get it?",
  "id" : 226046864632471552,
  "in_reply_to_status_id" : 226037848111996928,
  "created_at" : "Thu Jul 19 20:12:26 +0000 2012",
  "in_reply_to_screen_name" : "ianmcall",
  "in_reply_to_user_id_str" : "2035631",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.623015428, -122.3381295149 ]
  },
  "id_str" : "226026643167272960",
  "text" : "Anybody in Seattle want a freestanding pull up bar? It\u2019s free if you can come pick it up in SLU by tomorrow!",
  "id" : 226026643167272960,
  "created_at" : "Thu Jul 19 18:52:05 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "dearinternet",
      "indices" : [ 18, 31 ]
    } ],
    "urls" : [ {
      "indices" : [ 70, 90 ],
      "url" : "http://t.co/NbtElVQe",
      "expanded_url" : "http://www.flickr.com/dearinternet",
      "display_url" : "flickr.com/dearinternet"
    }, {
      "indices" : [ 104, 124 ],
      "url" : "http://t.co/3hdalGYl",
      "expanded_url" : "http://dearmarissamayer.com",
      "display_url" : "dearmarissamayer.com"
    } ]
  },
  "geo" : {
  },
  "id_str" : "226015473144328192",
  "text" : "Flickr responds: \"#dearinternet - thanks! Come make Flickr awesomer.\" http://t.co/NbtElVQe (previously: http://t.co/3hdalGYl)",
  "id" : 226015473144328192,
  "created_at" : "Thu Jul 19 18:07:42 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tracey Ryan Briones",
      "screen_name" : "trbriones",
      "indices" : [ 0, 10 ],
      "id_str" : "17550502",
      "id" : 17550502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "226006465507377152",
  "geo" : {
  },
  "id_str" : "226007082225266688",
  "in_reply_to_user_id" : 17550502,
  "text" : "@trbriones Oh, that\u2019s so awesome. I\u2019m jealous. What can you make with them?",
  "id" : 226007082225266688,
  "in_reply_to_status_id" : 226006465507377152,
  "created_at" : "Thu Jul 19 17:34:22 +0000 2012",
  "in_reply_to_screen_name" : "trbriones",
  "in_reply_to_user_id_str" : "17550502",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 45 ],
      "url" : "http://t.co/fZ98qE3R",
      "expanded_url" : "http://flic.kr/p/czJSPu",
      "display_url" : "flic.kr/p/czJSPu"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.618666, -122.387834 ]
  },
  "id_str" : "225825204516036608",
  "text" : "8:36pm Reading Gone Girl http://t.co/fZ98qE3R",
  "id" : 225825204516036608,
  "created_at" : "Thu Jul 19 05:31:39 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "quantifiedself",
      "screen_name" : "quantifiedself",
      "indices" : [ 16, 31 ],
      "id_str" : "35056570",
      "id" : 35056570
    }, {
      "name" : "measured me",
      "screen_name" : "measuredme",
      "indices" : [ 46, 57 ],
      "id_str" : "624737777",
      "id" : 624737777
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 131 ],
      "url" : "http://t.co/Nzy4DB6b",
      "expanded_url" : "http://bit.ly/NQLeSy",
      "display_url" : "bit.ly/NQLeSy"
    } ]
  },
  "geo" : {
  },
  "id_str" : "225789690475868160",
  "text" : "I like this! RT @quantifiedself: Interesting! @measuredme talks about a framework for measuring impact/karma - http://t.co/Nzy4DB6b",
  "id" : 225789690475868160,
  "created_at" : "Thu Jul 19 03:10:31 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Willo O'Brien",
      "screen_name" : "WilloToons",
      "indices" : [ 0, 11 ],
      "id_str" : "1099629326",
      "id" : 1099629326
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "225769724397633536",
  "geo" : {
  },
  "id_str" : "225771484109488128",
  "in_reply_to_user_id" : 772386,
  "text" : "@WilloToons Bummer, I was just there! Had to leave to catch a flight. Hello!",
  "id" : 225771484109488128,
  "in_reply_to_status_id" : 225769724397633536,
  "created_at" : "Thu Jul 19 01:58:11 +0000 2012",
  "in_reply_to_screen_name" : "WilloLovesYou",
  "in_reply_to_user_id_str" : "772386",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helena Price",
      "screen_name" : "helena",
      "indices" : [ 0, 7 ],
      "id_str" : "19699682",
      "id" : 19699682
    }, {
      "name" : "Matt Galligan",
      "screen_name" : "mg",
      "indices" : [ 8, 11 ],
      "id_str" : "607",
      "id" : 607
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "225768108089040896",
  "geo" : {
  },
  "id_str" : "225771243377422336",
  "in_reply_to_user_id" : 19699682,
  "text" : "@helena @mg Tell me about your new shoes! Do they/can they track time standing?",
  "id" : 225771243377422336,
  "in_reply_to_status_id" : 225768108089040896,
  "created_at" : "Thu Jul 19 01:57:13 +0000 2012",
  "in_reply_to_screen_name" : "helena",
  "in_reply_to_user_id_str" : "19699682",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "225767959187034112",
  "text" : "Someone should build a gadget that simply measures time standing up per day. Pressure sensitive Bluetooth socks anyone?",
  "id" : 225767959187034112,
  "created_at" : "Thu Jul 19 01:44:10 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tumblr.com/\" rel=\"nofollow\">Tumblr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 131 ],
      "url" : "http://t.co/Daw20Y3k",
      "expanded_url" : "http://tmblr.co/ZQJvayPeUGJp",
      "display_url" : "tmblr.co/ZQJvayPeUGJp"
    } ]
  },
  "geo" : {
  },
  "id_str" : "225763721438449664",
  "text" : "\"Habit is the intersection of knowledge (what to do), skill (how to do), and desire (want to do).\" - Steven... http://t.co/Daw20Y3k",
  "id" : 225763721438449664,
  "created_at" : "Thu Jul 19 01:27:20 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim O'Reilly",
      "screen_name" : "timoreilly",
      "indices" : [ 43, 54 ],
      "id_str" : "2384071",
      "id" : 2384071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 122 ],
      "url" : "http://t.co/3Z5ra1NY",
      "expanded_url" : "http://bit.ly/MkrQ4v",
      "display_url" : "bit.ly/MkrQ4v"
    } ]
  },
  "geo" : {
  },
  "id_str" : "225608333149732864",
  "text" : "Can\u2019t wait til Niko can play with these RT @timoreilly: Can Littlebits become the Legos of a new era? http://t.co/3Z5ra1NY",
  "id" : 225608333149732864,
  "created_at" : "Wed Jul 18 15:09:52 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 140 ],
      "url" : "https://t.co/BLUSTzt7",
      "expanded_url" : "https://twitter.com/busterbenson/status/11195/",
      "display_url" : "twitter.com/busterbenson/s\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "225607901669097475",
  "text" : "Yesterday was the 6-yr bday for my Twitter account and the 6-yr anniversary of going to Rendezvous to see Todd\u2019s band: https://t.co/BLUSTzt7",
  "id" : 225607901669097475,
  "created_at" : "Wed Jul 18 15:08:10 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Greg Biggers",
      "screen_name" : "bigs",
      "indices" : [ 0, 5 ],
      "id_str" : "2374611",
      "id" : 2374611
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "225451252434210816",
  "geo" : {
  },
  "id_str" : "225454122491588608",
  "in_reply_to_user_id" : 2374611,
  "text" : "@bigs If it was a look-alike that would be a huge coincidence since I was definitely on that street! Hello!",
  "id" : 225454122491588608,
  "in_reply_to_status_id" : 225451252434210816,
  "created_at" : "Wed Jul 18 04:57:06 +0000 2012",
  "in_reply_to_screen_name" : "bigs",
  "in_reply_to_user_id_str" : "2374611",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 49 ],
      "url" : "http://t.co/z6fDk07U",
      "expanded_url" : "http://flic.kr/p/cz9o9s",
      "display_url" : "flic.kr/p/cz9o9s"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 37.616166, -122.391834 ]
  },
  "id_str" : "225443168752111618",
  "text" : "8:36pm Waiting for the train http://t.co/z6fDk07U",
  "id" : 225443168752111618,
  "created_at" : "Wed Jul 18 04:13:34 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Geri-Ayn Gaul",
      "screen_name" : "geriayn",
      "indices" : [ 0, 8 ],
      "id_str" : "14514761",
      "id" : 14514761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "225396636870909954",
  "geo" : {
  },
  "id_str" : "225402824597581824",
  "in_reply_to_user_id" : 14514761,
  "text" : "@geriayn Thank you! Not sure what\u2019s next exactly but still very interested in the problem.",
  "id" : 225402824597581824,
  "in_reply_to_status_id" : 225396636870909954,
  "created_at" : "Wed Jul 18 01:33:15 +0000 2012",
  "in_reply_to_screen_name" : "geriayn",
  "in_reply_to_user_id_str" : "14514761",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Wright",
      "screen_name" : "webwright",
      "indices" : [ 0, 10 ],
      "id_str" : "786818",
      "id" : 786818
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "225395045996560384",
  "geo" : {
  },
  "id_str" : "225402611531124739",
  "in_reply_to_user_id" : 786818,
  "text" : "@webwright Not enough time on this trip but will be back soon I\u2019m sure.",
  "id" : 225402611531124739,
  "in_reply_to_status_id" : 225395045996560384,
  "created_at" : "Wed Jul 18 01:32:25 +0000 2012",
  "in_reply_to_screen_name" : "webwright",
  "in_reply_to_user_id_str" : "786818",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 118 ],
      "url" : "http://t.co/JB7s76Jr",
      "expanded_url" : "http://instagr.am/p/NM-d-bI0Ai/",
      "display_url" : "instagr.am/p/NM-d-bI0Ai/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.4436465828, -122.302594185 ]
  },
  "id_str" : "225392797606354947",
  "text" : "Seattle -&gt; San Francisco for a day inspires song  @ Seattle-Tacoma International Airport (SEA) http://t.co/JB7s76Jr",
  "id" : 225392797606354947,
  "created_at" : "Wed Jul 18 00:53:25 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Maggie Mason",
      "screen_name" : "Maggie",
      "indices" : [ 0, 7 ],
      "id_str" : "448",
      "id" : 448
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "225315315716861952",
  "geo" : {
  },
  "id_str" : "225315775911690240",
  "in_reply_to_user_id" : 448,
  "text" : "@Maggie Thanks, Maggie.",
  "id" : 225315775911690240,
  "in_reply_to_status_id" : 225315315716861952,
  "created_at" : "Tue Jul 17 19:47:21 +0000 2012",
  "in_reply_to_screen_name" : "Maggie",
  "in_reply_to_user_id_str" : "448",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "225257672621047809",
  "geo" : {
  },
  "id_str" : "225257873364615169",
  "in_reply_to_user_id" : 4636,
  "text" : "@RyanLuikens Totally.",
  "id" : 225257873364615169,
  "in_reply_to_status_id" : 225257672621047809,
  "created_at" : "Tue Jul 17 15:57:16 +0000 2012",
  "in_reply_to_screen_name" : "rlukns",
  "in_reply_to_user_id_str" : "4636",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tumblr.com/\" rel=\"nofollow\">Tumblr</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Health Month",
      "screen_name" : "healthmonth",
      "indices" : [ 31, 43 ],
      "id_str" : "154236895",
      "id" : 154236895
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 65 ],
      "url" : "http://t.co/8hKmldlH",
      "expanded_url" : "http://tmblr.co/ZQJvayPXZr12",
      "display_url" : "tmblr.co/ZQJvayPXZr12"
    } ]
  },
  "geo" : {
  },
  "id_str" : "225228369472667648",
  "text" : "Letter to people who've played @healthmonth: http://t.co/8hKmldlH",
  "id" : 225228369472667648,
  "created_at" : "Tue Jul 17 14:00:02 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Kaminsky",
      "screen_name" : "dakami",
      "indices" : [ 3, 10 ],
      "id_str" : "8917142",
      "id" : 8917142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "225091746122563585",
  "text" : "RT @dakami: \"The real problem of humanity is the following: we have paleolithic emotions; medieval institutions; and god-like technology ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "225079323676254209",
    "text" : "\"The real problem of humanity is the following: we have paleolithic emotions; medieval institutions; and god-like technology\" EO Wilson",
    "id" : 225079323676254209,
    "created_at" : "Tue Jul 17 04:07:47 +0000 2012",
    "user" : {
      "name" : "Dan Kaminsky",
      "screen_name" : "dakami",
      "protected" : false,
      "id_str" : "8917142",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1781434177/kaminsky2_normal.png",
      "id" : 8917142,
      "verified" : false
    }
  },
  "id" : 225091746122563585,
  "created_at" : "Tue Jul 17 04:57:08 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Sutter",
      "screen_name" : "pinwheel",
      "indices" : [ 0, 9 ],
      "id_str" : "22483",
      "id" : 22483
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "225081917735837696",
  "geo" : {
  },
  "id_str" : "225090888207052801",
  "in_reply_to_user_id" : 22483,
  "text" : "@pinwheel Why didn\u2019t you like her? I thought everyone liked her.",
  "id" : 225090888207052801,
  "in_reply_to_status_id" : 225081917735837696,
  "created_at" : "Tue Jul 17 04:53:44 +0000 2012",
  "in_reply_to_screen_name" : "pinwheel",
  "in_reply_to_user_id_str" : "22483",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tara Tiger Brown",
      "screen_name" : "tara",
      "indices" : [ 0, 5 ],
      "id_str" : "10959642",
      "id" : 10959642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "225071391706333188",
  "geo" : {
  },
  "id_str" : "225074010164178944",
  "in_reply_to_user_id" : 10959642,
  "text" : "@tara Woah.",
  "id" : 225074010164178944,
  "in_reply_to_status_id" : 225071391706333188,
  "created_at" : "Tue Jul 17 03:46:40 +0000 2012",
  "in_reply_to_screen_name" : "tara",
  "in_reply_to_user_id_str" : "10959642",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 46 ],
      "url" : "http://t.co/PczCMMvi",
      "expanded_url" : "http://flic.kr/p/cyvN8m",
      "display_url" : "flic.kr/p/cyvN8m"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.608666, -122.306 ]
  },
  "id_str" : "225073545217196032",
  "text" : "8:36pm Considering dinner http://t.co/PczCMMvi",
  "id" : 225073545217196032,
  "created_at" : "Tue Jul 17 03:44:49 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NYT Obituaries",
      "screen_name" : "NYTObits",
      "indices" : [ 35, 44 ],
      "id_str" : "16929470",
      "id" : 16929470
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "obitoftheday",
      "indices" : [ 18, 31 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 125 ],
      "url" : "http://t.co/fS2UdAgS",
      "expanded_url" : "http://bit.ly/Q0P2GW",
      "display_url" : "bit.ly/Q0P2GW"
    } ]
  },
  "geo" : {
  },
  "id_str" : "225062647220023296",
  "text" : "I love his books. #obitoftheday RT @NYTObits: Donald J. Sobol, Creator of Encyclopedia Brown, Dies at 87 http://t.co/fS2UdAgS",
  "id" : 225062647220023296,
  "created_at" : "Tue Jul 17 03:01:31 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BJ Fogg",
      "screen_name" : "bjfogg",
      "indices" : [ 0, 7 ],
      "id_str" : "1118691",
      "id" : 1118691
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "225050173439623169",
  "geo" : {
  },
  "id_str" : "225051836015575041",
  "in_reply_to_user_id" : 1118691,
  "text" : "@bjfogg AA by far, it seems to me.",
  "id" : 225051836015575041,
  "in_reply_to_status_id" : 225050173439623169,
  "created_at" : "Tue Jul 17 02:18:33 +0000 2012",
  "in_reply_to_screen_name" : "bjfogg",
  "in_reply_to_user_id_str" : "1118691",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Techmeme",
      "screen_name" : "Techmeme",
      "indices" : [ 45, 54 ],
      "id_str" : "817386",
      "id" : 817386
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 133 ],
      "url" : "http://t.co/45KzL8Rc",
      "expanded_url" : "http://bit.ly/MC66xI",
      "display_url" : "bit.ly/MC66xI"
    } ]
  },
  "geo" : {
  },
  "id_str" : "225051568439963650",
  "text" : "I\u2019m suddenly rooting for Yahoo. Let\u2019s go! RT @Techmeme: Marc Andreessen Tells Us What He Thinks Of New Yahoo CEO http://t.co/45KzL8Rc",
  "id" : 225051568439963650,
  "created_at" : "Tue Jul 17 02:17:29 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dustin curtis",
      "screen_name" : "dcurtis",
      "indices" : [ 29, 37 ],
      "id_str" : "9395832",
      "id" : 9395832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 139 ],
      "url" : "https://t.co/TvjctWXl",
      "expanded_url" : "https://svbtle.com/apply",
      "display_url" : "svbtle.com/apply"
    } ]
  },
  "geo" : {
  },
  "id_str" : "225024659052171264",
  "text" : "Friends who write: apply! RT @dcurtis: About to invite a few people to Svbtle. If you want to apply, now is the time: https://t.co/TvjctWXl",
  "id" : 225024659052171264,
  "created_at" : "Tue Jul 17 00:30:34 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mule Design Studio",
      "screen_name" : "muledesign",
      "indices" : [ 59, 70 ],
      "id_str" : "21672315",
      "id" : 21672315
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 20 ],
      "url" : "http://t.co/JOgTdjt5",
      "expanded_url" : "http://evening-edition.com",
      "display_url" : "evening-edition.com"
    } ]
  },
  "geo" : {
  },
  "id_str" : "225017903752290304",
  "text" : "http://t.co/JOgTdjt5 (@eveninged) is brilliant. Nice work, @muledesign!",
  "id" : 225017903752290304,
  "created_at" : "Tue Jul 17 00:03:43 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Neilson",
      "screen_name" : "TheCulprit",
      "indices" : [ 0, 11 ],
      "id_str" : "6726182",
      "id" : 6726182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "224965776438853632",
  "geo" : {
  },
  "id_str" : "224996687146520576",
  "in_reply_to_user_id" : 6726182,
  "text" : "@TheCulprit Thanks, Scott!  And thanks for being a big part of what made it all meaningful.",
  "id" : 224996687146520576,
  "in_reply_to_status_id" : 224965776438853632,
  "created_at" : "Mon Jul 16 22:39:25 +0000 2012",
  "in_reply_to_screen_name" : "TheCulprit",
  "in_reply_to_user_id_str" : "6726182",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amy Jo Kim",
      "screen_name" : "amyjokim",
      "indices" : [ 0, 9 ],
      "id_str" : "780991",
      "id" : 780991
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "224963089060200448",
  "geo" : {
  },
  "id_str" : "224964228006686722",
  "in_reply_to_user_id" : 780991,
  "text" : "@amyjokim I\u2019m writing something up about training yourself to be triggerable. I think it\u2019s a major reason for habit failure.",
  "id" : 224964228006686722,
  "in_reply_to_status_id" : 224963089060200448,
  "created_at" : "Mon Jul 16 20:30:26 +0000 2012",
  "in_reply_to_screen_name" : "amyjokim",
  "in_reply_to_user_id_str" : "780991",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "marissamayer",
      "screen_name" : "marissamayer",
      "indices" : [ 3, 16 ],
      "id_str" : "17503180",
      "id" : 17503180
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "224963611896983553",
  "text" : "RT @marissamayer: Finally breaking in to Breaking Bad after tons of recommendations.  Am going to try to watch just one episode a day.   ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "219483668807299072",
    "text" : "Finally breaking in to Breaking Bad after tons of recommendations.  Am going to try to watch just one episode a day.  Can it be done?",
    "id" : 219483668807299072,
    "created_at" : "Sun Jul 01 17:32:39 +0000 2012",
    "user" : {
      "name" : "marissamayer",
      "screen_name" : "marissamayer",
      "protected" : false,
      "id_str" : "17503180",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/323982494/marissa_new4_normal.jpg",
      "id" : 17503180,
      "verified" : true
    }
  },
  "id" : 224963611896983553,
  "created_at" : "Mon Jul 16 20:27:59 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amy Jo Kim",
      "screen_name" : "amyjokim",
      "indices" : [ 0, 9 ],
      "id_str" : "780991",
      "id" : 780991
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "224963089060200448",
  "geo" : {
  },
  "id_str" : "224963473262657536",
  "in_reply_to_user_id" : 780991,
  "text" : "@amyjokim I use alarms to remember things that happen daily and weekly. Then, force myself to hit snooze until I actually do them.",
  "id" : 224963473262657536,
  "in_reply_to_status_id" : 224963089060200448,
  "created_at" : "Mon Jul 16 20:27:26 +0000 2012",
  "in_reply_to_screen_name" : "amyjokim",
  "in_reply_to_user_id_str" : "780991",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "indices" : [ 3, 12 ],
      "id_str" : "761628",
      "id" : 761628
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "224961596366143488",
  "text" : "RT @RickWebb: Marissa Mayhem!! Somebody invent a cocktail! A dance move! A salute! SO EXCITING.",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/#!/download/ipad\" rel=\"nofollow\">Twitter for iPad</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "224959440087031809",
    "text" : "Marissa Mayhem!! Somebody invent a cocktail! A dance move! A salute! SO EXCITING.",
    "id" : 224959440087031809,
    "created_at" : "Mon Jul 16 20:11:24 +0000 2012",
    "user" : {
      "name" : "Rick Webb",
      "screen_name" : "RickWebb",
      "protected" : false,
      "id_str" : "761628",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/23078492/img_2085_normal.jpg",
      "id" : 761628,
      "verified" : false
    }
  },
  "id" : 224961596366143488,
  "created_at" : "Mon Jul 16 20:19:58 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amy Jo Kim",
      "screen_name" : "amyjokim",
      "indices" : [ 0, 9 ],
      "id_str" : "780991",
      "id" : 780991
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "224959783847985152",
  "geo" : {
  },
  "id_str" : "224961528108023809",
  "in_reply_to_user_id" : 780991,
  "text" : "@amyjokim How about the alarm clock app?  :)",
  "id" : 224961528108023809,
  "in_reply_to_status_id" : 224959783847985152,
  "created_at" : "Mon Jul 16 20:19:42 +0000 2012",
  "in_reply_to_screen_name" : "amyjokim",
  "in_reply_to_user_id_str" : "780991",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 0, 10 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ {
      "expanded_url" : "http://twitter.com/buster/status/224952239360450561/photo/1",
      "indices" : [ 45, 65 ],
      "url" : "http://t.co/eQiT8HE2",
      "media_url" : "http://pbs.twimg.com/media/Ax8w3q8CIAADhQ4.jpg",
      "id_str" : "224952239368839168",
      "id" : 224952239368839168,
      "media_url_https" : "https://pbs.twimg.com/media/Ax8w3q8CIAADhQ4.jpg",
      "sizes" : [ {
        "h" : 294,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1948,
        "resize" : "fit",
        "w" : 3972
      }, {
        "h" : 167,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 502,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com/eQiT8HE2"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "224951356128108544",
  "geo" : {
  },
  "id_str" : "224952239360450561",
  "in_reply_to_user_id" : 7362142,
  "text" : "@kellianne Congrats, you\u2019re from Bangladesh! http://t.co/eQiT8HE2",
  "id" : 224952239360450561,
  "in_reply_to_status_id" : 224951356128108544,
  "created_at" : "Mon Jul 16 19:42:48 +0000 2012",
  "in_reply_to_screen_name" : "kellianne",
  "in_reply_to_user_id_str" : "7362142",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kellianne",
      "screen_name" : "kellianne",
      "indices" : [ 0, 10 ],
      "id_str" : "7362142",
      "id" : 7362142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "224950956977160194",
  "geo" : {
  },
  "id_str" : "224951149848035328",
  "in_reply_to_user_id" : 7362142,
  "text" : "@kellianne Want me to fill it in for you and send you the results?",
  "id" : 224951149848035328,
  "in_reply_to_status_id" : 224950956977160194,
  "created_at" : "Mon Jul 16 19:38:28 +0000 2012",
  "in_reply_to_screen_name" : "kellianne",
  "in_reply_to_user_id_str" : "7362142",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Anderegg",
      "screen_name" : "NickAnderegg",
      "indices" : [ 0, 13 ],
      "id_str" : "95100239",
      "id" : 95100239
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "224949108522221568",
  "geo" : {
  },
  "id_str" : "224949260578328576",
  "in_reply_to_user_id" : 95100239,
  "text" : "@NickAnderegg We ran out of money.",
  "id" : 224949260578328576,
  "in_reply_to_status_id" : 224949108522221568,
  "created_at" : "Mon Jul 16 19:30:57 +0000 2012",
  "in_reply_to_screen_name" : "NickAnderegg",
  "in_reply_to_user_id_str" : "95100239",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Max Daniels",
      "screen_name" : "maxdaniels",
      "indices" : [ 0, 11 ],
      "id_str" : "17490227",
      "id" : 17490227
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "224947347199754240",
  "geo" : {
  },
  "id_str" : "224948850513813505",
  "in_reply_to_user_id" : 17490227,
  "text" : "@maxdaniels Thank YOU for helping make the community there awesome. Definitely its greatest strength.",
  "id" : 224948850513813505,
  "in_reply_to_status_id" : 224947347199754240,
  "created_at" : "Mon Jul 16 19:29:19 +0000 2012",
  "in_reply_to_screen_name" : "maxdaniels",
  "in_reply_to_user_id_str" : "17490227",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Anderegg",
      "screen_name" : "NickAnderegg",
      "indices" : [ 0, 13 ],
      "id_str" : "95100239",
      "id" : 95100239
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "224940814210572289",
  "geo" : {
  },
  "id_str" : "224948748093104128",
  "in_reply_to_user_id" : 95100239,
  "text" : "@NickAnderegg For now, just getting my life in order and starting to think about options.",
  "id" : 224948748093104128,
  "in_reply_to_status_id" : 224940814210572289,
  "created_at" : "Mon Jul 16 19:28:55 +0000 2012",
  "in_reply_to_screen_name" : "NickAnderegg",
  "in_reply_to_user_id_str" : "95100239",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BBCNews",
      "indices" : [ 4, 12 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http://t.co/0pChHXj4",
      "expanded_url" : "http://www.bbc.co.uk/news/health-18770328",
      "display_url" : "bbc.co.uk/news/health-18\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "224945429505261569",
  "text" : "The #BBCNews body fat calculator says I'm most like someone from Malaysia (&amp; slimmer than 87% of US males my age) http://t.co/0pChHXj4",
  "id" : 224945429505261569,
  "created_at" : "Mon Jul 16 19:15:44 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip Skillern",
      "screen_name" : "PhilipSkillern",
      "indices" : [ 0, 15 ],
      "id_str" : "14749562",
      "id" : 14749562
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "224911243029389312",
  "geo" : {
  },
  "id_str" : "224915814032216065",
  "in_reply_to_user_id" : 14749562,
  "text" : "@PhilipSkillern On the first day.",
  "id" : 224915814032216065,
  "in_reply_to_status_id" : 224911243029389312,
  "created_at" : "Mon Jul 16 17:18:03 +0000 2012",
  "in_reply_to_screen_name" : "PhilipSkillern",
  "in_reply_to_user_id_str" : "14749562",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pamela J. Stubbart",
      "screen_name" : "amelapay",
      "indices" : [ 0, 9 ],
      "id_str" : "23123041",
      "id" : 23123041
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "224915073624317953",
  "geo" : {
  },
  "id_str" : "224915646796922880",
  "in_reply_to_user_id" : 23123041,
  "text" : "@amelapay Ha, yes true! I hope I don\u2019t lose everyone!",
  "id" : 224915646796922880,
  "in_reply_to_status_id" : 224915073624317953,
  "created_at" : "Mon Jul 16 17:17:23 +0000 2012",
  "in_reply_to_screen_name" : "amelapay",
  "in_reply_to_user_id_str" : "23123041",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Best of Buster",
      "screen_name" : "bestofbuster",
      "indices" : [ 10, 23 ],
      "id_str" : "637064633",
      "id" : 637064633
    }, {
      "name" : "Stellar",
      "screen_name" : "yo_stellar",
      "indices" : [ 94, 105 ],
      "id_str" : "180817904",
      "id" : 180817904
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "224914634640068612",
  "text" : "Testing a @bestofbuster twitter account, which only has the tweets that someone likes. Thanks @yo_stellar for making it easy. Unfollow me!",
  "id" : 224914634640068612,
  "created_at" : "Mon Jul 16 17:13:22 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stellar",
      "screen_name" : "yo_stellar",
      "indices" : [ 0, 11 ],
      "id_str" : "180817904",
      "id" : 180817904
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "224902248583544832",
  "in_reply_to_user_id" : 180817904,
  "text" : "@yo_stellar I want to use Stellar to create a \"best of\" feed for myself, but the feed doesn't consistently include tweet id. Pretty please?",
  "id" : 224902248583544832,
  "created_at" : "Mon Jul 16 16:24:09 +0000 2012",
  "in_reply_to_screen_name" : "yo_stellar",
  "in_reply_to_user_id_str" : "180817904",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Micah Baldwin",
      "screen_name" : "micah",
      "indices" : [ 0, 6 ],
      "id_str" : "5469512",
      "id" : 5469512
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "224555465458192384",
  "geo" : {
  },
  "id_str" : "224740419941040130",
  "in_reply_to_user_id" : 5469512,
  "text" : "@micah Thanks, Micah. Didn\u2019t realize til after choosing the new blog name that we\u2019re both duck-related! Quack.",
  "id" : 224740419941040130,
  "in_reply_to_status_id" : 224555465458192384,
  "created_at" : "Mon Jul 16 05:41:06 +0000 2012",
  "in_reply_to_screen_name" : "micah",
  "in_reply_to_user_id_str" : "5469512",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Messina\u2122",
      "screen_name" : "chrismessina",
      "indices" : [ 0, 13 ],
      "id_str" : "1186",
      "id" : 1186
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "224739491234070529",
  "geo" : {
  },
  "id_str" : "224739921515118592",
  "in_reply_to_user_id" : 1186,
  "text" : "@chrismessina Thanks. I\u2019ve got to get my house in order a bit, but hope to be back in the game shortly.",
  "id" : 224739921515118592,
  "in_reply_to_status_id" : 224739491234070529,
  "created_at" : "Mon Jul 16 05:39:07 +0000 2012",
  "in_reply_to_screen_name" : "chrismessina",
  "in_reply_to_user_id_str" : "1186",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Messina\u2122",
      "screen_name" : "chrismessina",
      "indices" : [ 0, 13 ],
      "id_str" : "1186",
      "id" : 1186
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "224736613790523392",
  "geo" : {
  },
  "id_str" : "224737414550265856",
  "in_reply_to_user_id" : 1186,
  "text" : "@chrismessina I think the new owners will do good things with it.",
  "id" : 224737414550265856,
  "in_reply_to_status_id" : 224736613790523392,
  "created_at" : "Mon Jul 16 05:29:09 +0000 2012",
  "in_reply_to_screen_name" : "chrismessina",
  "in_reply_to_user_id_str" : "1186",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 69 ],
      "url" : "http://t.co/6yYWIyWF",
      "expanded_url" : "http://instagr.am/p/NIIS8uI0I2/",
      "display_url" : "instagr.am/p/NIIS8uI0I2/"
    } ]
  },
  "geo" : {
  },
  "id_str" : "224711893632290818",
  "text" : "8:36pm \"Dada bye bye. Mama home. Nurse. No nap!\" http://t.co/6yYWIyWF",
  "id" : 224711893632290818,
  "created_at" : "Mon Jul 16 03:47:45 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "harryh",
      "screen_name" : "harryh",
      "indices" : [ 0, 7 ],
      "id_str" : "4558",
      "id" : 4558
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "224651121841541121",
  "geo" : {
  },
  "id_str" : "224652750951153664",
  "in_reply_to_user_id" : 4558,
  "text" : "@harryh Ooh, I need a new bag to carry my laptop too\u2026 I\u2019ll keep an eye on your replies.",
  "id" : 224652750951153664,
  "in_reply_to_status_id" : 224651121841541121,
  "created_at" : "Sun Jul 15 23:52:44 +0000 2012",
  "in_reply_to_screen_name" : "harryh",
  "in_reply_to_user_id_str" : "4558",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Berkun",
      "screen_name" : "berkun",
      "indices" : [ 0, 7 ],
      "id_str" : "30495974",
      "id" : 30495974
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "224643583779684353",
  "geo" : {
  },
  "id_str" : "224649378491678722",
  "in_reply_to_user_id" : 30495974,
  "text" : "@berkun Once I get my life in order a bit, I think that might be a great idea. Would you be in?",
  "id" : 224649378491678722,
  "in_reply_to_status_id" : 224643583779684353,
  "created_at" : "Sun Jul 15 23:39:20 +0000 2012",
  "in_reply_to_screen_name" : "berkun",
  "in_reply_to_user_id_str" : "30495974",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Kathleen Peck",
      "screen_name" : "sarahkpeck",
      "indices" : [ 17, 28 ],
      "id_str" : "196745496",
      "id" : 196745496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 78 ],
      "url" : "http://t.co/tNEm1ovR",
      "expanded_url" : "http://itstartswith.com/movement/walk-talk/",
      "display_url" : "itstartswith.com/movement/walk-\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "224640548991008770",
  "text" : "A cool idea from @sarahkpeck: a walk + talk meetup group: http://t.co/tNEm1ovR",
  "id" : 224640548991008770,
  "created_at" : "Sun Jul 15 23:04:15 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GOOD ",
      "screen_name" : "GOOD",
      "indices" : [ 34, 39 ],
      "id_str" : "19621110",
      "id" : 19621110
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 104 ],
      "url" : "http://t.co/rRoKNqvj",
      "expanded_url" : "http://bit.ly/NtCvLo",
      "display_url" : "bit.ly/NtCvLo"
    } ]
  },
  "geo" : {
  },
  "id_str" : "224613814526685184",
  "text" : "There\u2019s something awesome here RT @GOOD: How $5 changed the way I read the internet http://t.co/rRoKNqvj",
  "id" : 224613814526685184,
  "created_at" : "Sun Jul 15 21:18:01 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 64 ],
      "url" : "http://t.co/BAr1wBfp",
      "expanded_url" : "http://instagr.am/p/NFjpjZI0Il/",
      "display_url" : "instagr.am/p/NFjpjZI0Il/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.551888, -122.320287067 ]
  },
  "id_str" : "224348498798190592",
  "text" : "8:36pm Best dressed!  @ The Corson Building http://t.co/BAr1wBfp",
  "id" : 224348498798190592,
  "created_at" : "Sun Jul 15 03:43:44 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 54 ],
      "url" : "http://t.co/44nK4OrM",
      "expanded_url" : "http://instagr.am/p/NFX1_2o0O5/",
      "display_url" : "instagr.am/p/NFX1_2o0O5/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.551888, -122.320287067 ]
  },
  "id_str" : "224322471338319872",
  "text" : "Bounce cup  @ The Corson Building http://t.co/44nK4OrM",
  "id" : 224322471338319872,
  "created_at" : "Sun Jul 15 02:00:19 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "samantha",
      "screen_name" : "samantham",
      "indices" : [ 51, 61 ],
      "id_str" : "1771141",
      "id" : 1771141
    }, {
      "name" : "&y",
      "screen_name" : "andypixel",
      "indices" : [ 62, 72 ],
      "id_str" : "10015122",
      "id" : 10015122
    }, {
      "name" : "ingopixel",
      "screen_name" : "ingopixel",
      "indices" : [ 73, 83 ],
      "id_str" : "7943892",
      "id" : 7943892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 105 ],
      "url" : "http://t.co/FuWMrbo0",
      "expanded_url" : "http://4sq.com/Mqbs4o",
      "display_url" : "4sq.com/Mqbs4o"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.551888, -122.3202870667 ]
  },
  "id_str" : "224294586456096772",
  "text" : "Happy Bastille Day F\u00EAte! (@ The Corson Building w/ @samantham @andypixel @ingopixel) http://t.co/FuWMrbo0",
  "id" : 224294586456096772,
  "created_at" : "Sun Jul 15 00:09:31 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "224284094274600962",
  "geo" : {
  },
  "id_str" : "224284429235929089",
  "in_reply_to_user_id" : 220226736,
  "text" : "@digitalmiss You definitely have a point. It\u2019s not all unidirectional, but more of a positive feedback loop for the experience as a whole.",
  "id" : 224284429235929089,
  "in_reply_to_status_id" : 224284094274600962,
  "created_at" : "Sat Jul 14 23:29:09 +0000 2012",
  "in_reply_to_screen_name" : "KristyT",
  "in_reply_to_user_id_str" : "220226736",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Wang",
      "screen_name" : "brianmwang",
      "indices" : [ 0, 11 ],
      "id_str" : "93478440",
      "id" : 93478440
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "224283680871428096",
  "geo" : {
  },
  "id_str" : "224284162004234240",
  "in_reply_to_user_id" : 93478440,
  "text" : "@brianmwang I think that implies good things for your future. :)",
  "id" : 224284162004234240,
  "in_reply_to_status_id" : 224283680871428096,
  "created_at" : "Sat Jul 14 23:28:05 +0000 2012",
  "in_reply_to_screen_name" : "brianmwang",
  "in_reply_to_user_id_str" : "93478440",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "224283583609712640",
  "geo" : {
  },
  "id_str" : "224283922622713857",
  "in_reply_to_user_id" : 220226736,
  "text" : "@digitalmiss Hm\u2026 possible, though arguable it\u2019s also easiest to follow crushes on Twitter.",
  "id" : 224283922622713857,
  "in_reply_to_status_id" : 224283583609712640,
  "created_at" : "Sat Jul 14 23:27:08 +0000 2012",
  "in_reply_to_screen_name" : "KristyT",
  "in_reply_to_user_id_str" : "220226736",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "224283434669981696",
  "geo" : {
  },
  "id_str" : "224283540026699777",
  "in_reply_to_user_id" : 220226736,
  "text" : "@digitalmiss What do you mean?",
  "id" : 224283540026699777,
  "in_reply_to_status_id" : 224283434669981696,
  "created_at" : "Sat Jul 14 23:25:37 +0000 2012",
  "in_reply_to_screen_name" : "KristyT",
  "in_reply_to_user_id_str" : "220226736",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Watson",
      "screen_name" : "paulmwatson",
      "indices" : [ 3, 15 ],
      "id_str" : "11214",
      "id" : 11214
    }, {
      "name" : "Anti-Buster",
      "screen_name" : "busterbenson",
      "indices" : [ 17, 30 ],
      "id_str" : "1024917050",
      "id" : 1024917050
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "224283247490777090",
  "text" : "RT @paulmwatson: @busterbenson Twitter and Twitter.",
  "id" : 224283247490777090,
  "created_at" : "Sat Jul 14 23:24:27 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "224282633872474113",
  "text" : "Where do you have the most crushes: Twitter, Facebook, Path, Instagram, or Foursquare? Unrelated: which app do you like most?",
  "id" : 224282633872474113,
  "created_at" : "Sat Jul 14 23:22:01 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Colin Henry",
      "screen_name" : "jchenry",
      "indices" : [ 0, 8 ],
      "id_str" : "113988145",
      "id" : 113988145
    }, {
      "name" : "Path",
      "screen_name" : "path",
      "indices" : [ 18, 23 ],
      "id_str" : "106333951",
      "id" : 106333951
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "224280266003316736",
  "geo" : {
  },
  "id_str" : "224280847518400513",
  "in_reply_to_user_id" : 113988145,
  "text" : "@jchenry Not with @path. They\u2019re much more interesting on Twitter or Instagram.",
  "id" : 224280847518400513,
  "in_reply_to_status_id" : 224280266003316736,
  "created_at" : "Sat Jul 14 23:14:55 +0000 2012",
  "in_reply_to_screen_name" : "jchenry",
  "in_reply_to_user_id_str" : "113988145",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "224280697718849536",
  "text" : "Theory: in order to actually like any new app or social network you need to have a crush or two in there.",
  "id" : 224280697718849536,
  "created_at" : "Sat Jul 14 23:14:19 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Colin Henry",
      "screen_name" : "jchenry",
      "indices" : [ 0, 8 ],
      "id_str" : "113988145",
      "id" : 113988145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "224279604817428480",
  "geo" : {
  },
  "id_str" : "224279968643952642",
  "in_reply_to_user_id" : 113988145,
  "text" : "@jchenry I do like the people in my network, though. I\u2019ve pruned it a couple times.",
  "id" : 224279968643952642,
  "in_reply_to_status_id" : 224279604817428480,
  "created_at" : "Sat Jul 14 23:11:26 +0000 2012",
  "in_reply_to_screen_name" : "jchenry",
  "in_reply_to_user_id_str" : "113988145",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Colin Henry",
      "screen_name" : "jchenry",
      "indices" : [ 0, 8 ],
      "id_str" : "113988145",
      "id" : 113988145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "224279099689025536",
  "geo" : {
  },
  "id_str" : "224279412676366337",
  "in_reply_to_user_id" : 113988145,
  "text" : "@jchenry It is difficult to scan and relatively low levels of \u201Cinteresting\u201D stuff per page of scrolling.",
  "id" : 224279412676366337,
  "in_reply_to_status_id" : 224279099689025536,
  "created_at" : "Sat Jul 14 23:09:13 +0000 2012",
  "in_reply_to_screen_name" : "jchenry",
  "in_reply_to_user_id_str" : "113988145",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "girl jo",
      "screen_name" : "octavekitten",
      "indices" : [ 0, 13 ],
      "id_str" : "16366882",
      "id" : 16366882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "224278800744194048",
  "geo" : {
  },
  "id_str" : "224279021402324993",
  "in_reply_to_user_id" : 16366882,
  "text" : "@octavekitten Yeah, that was a big fumble for sure. I\u2019d forgive them if I just liked the app, though. :)",
  "id" : 224279021402324993,
  "in_reply_to_status_id" : 224278800744194048,
  "created_at" : "Sat Jul 14 23:07:40 +0000 2012",
  "in_reply_to_screen_name" : "octavekitten",
  "in_reply_to_user_id_str" : "16366882",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Govella",
      "screen_name" : "austingovella",
      "indices" : [ 0, 14 ],
      "id_str" : "2543461",
      "id" : 2543461
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "224278616945594368",
  "geo" : {
  },
  "id_str" : "224278904565809152",
  "in_reply_to_user_id" : 2543461,
  "text" : "@austingovella I\u2019ve looked at it consistently since launch, each time hoping for some kind of reason to come back.",
  "id" : 224278904565809152,
  "in_reply_to_status_id" : 224278616945594368,
  "created_at" : "Sat Jul 14 23:07:12 +0000 2012",
  "in_reply_to_screen_name" : "austingovella",
  "in_reply_to_user_id_str" : "2543461",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "girl jo",
      "screen_name" : "octavekitten",
      "indices" : [ 0, 13 ],
      "id_str" : "16366882",
      "id" : 16366882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "224278204775538688",
  "geo" : {
  },
  "id_str" : "224278384400797696",
  "in_reply_to_user_id" : 16366882,
  "text" : "@octavekitten I think it\u2019s done \u201Cwell\u201D in the sense of quality work, but it just doesn\u2019t resonate with my actual life at all.",
  "id" : 224278384400797696,
  "in_reply_to_status_id" : 224278204775538688,
  "created_at" : "Sat Jul 14 23:05:08 +0000 2012",
  "in_reply_to_screen_name" : "octavekitten",
  "in_reply_to_user_id_str" : "16366882",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Path",
      "screen_name" : "path",
      "indices" : [ 15, 20 ],
      "id_str" : "106333951",
      "id" : 106333951
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "224278089352486913",
  "text" : "I wish I liked @path.",
  "id" : 224278089352486913,
  "created_at" : "Sat Jul 14 23:03:58 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "chris jones",
      "screen_name" : "cjlikearockstar",
      "indices" : [ 0, 16 ],
      "id_str" : "34383091",
      "id" : 34383091
    }, {
      "name" : "HIPSTER RUNOFF",
      "screen_name" : "hipsterrunoff",
      "indices" : [ 37, 51 ],
      "id_str" : "12866742",
      "id" : 12866742
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FROYOLO",
      "indices" : [ 53, 61 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "224269604585881600",
  "in_reply_to_user_id" : 34383091,
  "text" : "@cjlikearockstar this is for you. RT @hipsterrunoff: #FROYOLO: u only pick ur toppings once.",
  "id" : 224269604585881600,
  "created_at" : "Sat Jul 14 22:30:15 +0000 2012",
  "in_reply_to_screen_name" : "cjlikearockstar",
  "in_reply_to_user_id_str" : "34383091",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "&y",
      "screen_name" : "andypixel",
      "indices" : [ 92, 102 ],
      "id_str" : "10015122",
      "id" : 10015122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 124 ],
      "url" : "http://t.co/4VgQvzLS",
      "expanded_url" : "http://4sq.com/LY09vG",
      "display_url" : "4sq.com/LY09vG"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6140743653, -122.319101515 ]
  },
  "id_str" : "224205283243720705",
  "text" : "Working before heading to Bastille Day party at the Corson Building later. (@ Caff\u00E9 Vita w/ @andypixel) http://t.co/4VgQvzLS",
  "id" : 224205283243720705,
  "created_at" : "Sat Jul 14 18:14:39 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "224204993048223744",
  "text" : "Scala is pretty neat.",
  "id" : 224204993048223744,
  "created_at" : "Sat Jul 14 18:13:30 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Seitz",
      "screen_name" : "BillSeitz",
      "indices" : [ 0, 10 ],
      "id_str" : "1239971",
      "id" : 1239971
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 54 ],
      "url" : "http://t.co/aJpKFA6k",
      "expanded_url" : "http://bit.ly/M92VRg",
      "display_url" : "bit.ly/M92VRg"
    } ]
  },
  "in_reply_to_status_id_str" : "224155542808047616",
  "geo" : {
  },
  "id_str" : "224170716671643649",
  "in_reply_to_user_id" : 1239971,
  "text" : "@BillSeitz Yes! That\u2019s my plan on http://t.co/aJpKFA6k once I get my life in order a bit.",
  "id" : 224170716671643649,
  "in_reply_to_status_id" : 224155542808047616,
  "created_at" : "Sat Jul 14 15:57:18 +0000 2012",
  "in_reply_to_screen_name" : "BillSeitz",
  "in_reply_to_user_id_str" : "1239971",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "224004340753498112",
  "text" : "The hungrier I get, the more I want a hamburger. But the later it gets, the more I want a hotdog. This will get interesting.",
  "id" : 224004340753498112,
  "created_at" : "Sat Jul 14 04:56:11 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 61 ],
      "url" : "http://t.co/HHdakZed",
      "expanded_url" : "http://flic.kr/p/cwyLW3",
      "display_url" : "flic.kr/p/cwyLW3"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6215, -122.336167 ]
  },
  "id_str" : "223984716192296961",
  "text" : "8:36pm Studying under fluorescent lights http://t.co/HHdakZed",
  "id" : 223984716192296961,
  "created_at" : "Sat Jul 14 03:38:12 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "App.net",
      "screen_name" : "AppDotNet",
      "indices" : [ 0, 10 ],
      "id_str" : "104558396",
      "id" : 104558396
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "joinus",
      "indices" : [ 105, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 48, 68 ],
      "url" : "http://t.co/AE3mquHi",
      "expanded_url" : "http://App.net",
      "display_url" : "App.net"
    }, {
      "indices" : [ 84, 104 ],
      "url" : "http://t.co/J1nqe302",
      "expanded_url" : "http://join.app.net/ngdpqvnk",
      "display_url" : "join.app.net/ngdpqvnk"
    } ]
  },
  "geo" : {
  },
  "id_str" : "223960266965135360",
  "in_reply_to_user_id" : 104558396,
  "text" : "@AppDotNet I'm joining the movement and backing http://t.co/AE3mquHi. Sign up here: http://t.co/J1nqe302 #joinus",
  "id" : 223960266965135360,
  "created_at" : "Sat Jul 14 02:01:03 +0000 2012",
  "in_reply_to_screen_name" : "AppDotNet",
  "in_reply_to_user_id_str" : "104558396",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dennis Crowley",
      "screen_name" : "dens",
      "indices" : [ 3, 8 ],
      "id_str" : "418",
      "id" : 418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "223946656134070273",
  "text" : "RT @dens: Great car game: 2 people each throw out a word, the words form a company name, third person has to pitch a fictional startup b ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "223943440138911744",
    "text" : "Great car game: 2 people each throw out a word, the words form a company name, third person has to pitch a fictional startup based on name",
    "id" : 223943440138911744,
    "created_at" : "Sat Jul 14 00:54:11 +0000 2012",
    "user" : {
      "name" : "Dennis Crowley",
      "screen_name" : "dens",
      "protected" : false,
      "id_str" : "418",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3180393492/9236f9d84c75e755a98de9d67f8d1460_normal.jpeg",
      "id" : 418,
      "verified" : true
    }
  },
  "id" : 223946656134070273,
  "created_at" : "Sat Jul 14 01:06:58 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aimee",
      "screen_name" : "LilHossler",
      "indices" : [ 0, 11 ],
      "id_str" : "123116307",
      "id" : 123116307
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "223894913497051136",
  "geo" : {
  },
  "id_str" : "223900426750279681",
  "in_reply_to_user_id" : 123116307,
  "text" : "@LilHossler That\u2019s one of the strangest questions I\u2019ve ever heard! How did you answer?",
  "id" : 223900426750279681,
  "in_reply_to_status_id" : 223894913497051136,
  "created_at" : "Fri Jul 13 22:03:16 +0000 2012",
  "in_reply_to_screen_name" : "LilHossler",
  "in_reply_to_user_id_str" : "123116307",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Au",
      "screen_name" : "Alan_Au",
      "indices" : [ 0, 8 ],
      "id_str" : "20404593",
      "id" : 20404593
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "223898479322337280",
  "geo" : {
  },
  "id_str" : "223898732431810560",
  "in_reply_to_user_id" : 20404593,
  "text" : "@Alan_Au Is it important to do in PERL versus other languages?",
  "id" : 223898732431810560,
  "in_reply_to_status_id" : 223898479322337280,
  "created_at" : "Fri Jul 13 21:56:32 +0000 2012",
  "in_reply_to_screen_name" : "Alan_Au",
  "in_reply_to_user_id_str" : "20404593",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "223894142231650305",
  "text" : "What are the best technical interview questions you\u2019ve ever asked or been asked?",
  "id" : 223894142231650305,
  "created_at" : "Fri Jul 13 21:38:17 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Maura McGovern",
      "screen_name" : "mmcgovern",
      "indices" : [ 0, 10 ],
      "id_str" : "15856582",
      "id" : 15856582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "223885457270902785",
  "geo" : {
  },
  "id_str" : "223885829922242561",
  "in_reply_to_user_id" : 15856582,
  "text" : "@mmcgovern I\u2019m happy to hear that you made it! Email me at busterbenson@gmail.com\u2026 I\u2019d love to hear more.",
  "id" : 223885829922242561,
  "in_reply_to_status_id" : 223885457270902785,
  "created_at" : "Fri Jul 13 21:05:16 +0000 2012",
  "in_reply_to_screen_name" : "mmcgovern",
  "in_reply_to_user_id_str" : "15856582",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Maura McGovern",
      "screen_name" : "mmcgovern",
      "indices" : [ 0, 10 ],
      "id_str" : "15856582",
      "id" : 15856582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "223884995389952001",
  "geo" : {
  },
  "id_str" : "223885533691125760",
  "in_reply_to_user_id" : 15856582,
  "text" : "@mmcgovern I have a rather crazy belief that we can\u2019t change what we do without changing who we are. I should probably write it up.",
  "id" : 223885533691125760,
  "in_reply_to_status_id" : 223884995389952001,
  "created_at" : "Fri Jul 13 21:04:05 +0000 2012",
  "in_reply_to_screen_name" : "mmcgovern",
  "in_reply_to_user_id_str" : "15856582",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Maura McGovern",
      "screen_name" : "mmcgovern",
      "indices" : [ 0, 10 ],
      "id_str" : "15856582",
      "id" : 15856582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "223856547636326403",
  "geo" : {
  },
  "id_str" : "223872553905684480",
  "in_reply_to_user_id" : 15856582,
  "text" : "@mmcgovern In my mind, they\u2019re the same, but I\u2019d love to hear your thoughts.",
  "id" : 223872553905684480,
  "in_reply_to_status_id" : 223856547636326403,
  "created_at" : "Fri Jul 13 20:12:30 +0000 2012",
  "in_reply_to_screen_name" : "mmcgovern",
  "in_reply_to_user_id_str" : "15856582",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Coleman",
      "screen_name" : "aarondcoleman",
      "indices" : [ 0, 14 ],
      "id_str" : "1379965428",
      "id" : 1379965428
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "223800435176243201",
  "geo" : {
  },
  "id_str" : "223800612595306497",
  "in_reply_to_user_id" : 9609062,
  "text" : "@aarondcoleman They got rid of the glass in front of the screen. Glare is said to be down 70% but I haven't tested it yet.",
  "id" : 223800612595306497,
  "in_reply_to_status_id" : 223800435176243201,
  "created_at" : "Fri Jul 13 15:26:38 +0000 2012",
  "in_reply_to_screen_name" : "aaronc",
  "in_reply_to_user_id_str" : "9609062",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Coleman",
      "screen_name" : "aarondcoleman",
      "indices" : [ 0, 14 ],
      "id_str" : "1379965428",
      "id" : 1379965428
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "223799825123127296",
  "geo" : {
  },
  "id_str" : "223800068430499841",
  "in_reply_to_user_id" : 9609062,
  "text" : "@aarondcoleman The glossy is WAY better than before.",
  "id" : 223800068430499841,
  "in_reply_to_status_id" : 223799825123127296,
  "created_at" : "Fri Jul 13 15:24:28 +0000 2012",
  "in_reply_to_screen_name" : "aaronc",
  "in_reply_to_user_id_str" : "9609062",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian McKellar",
      "screen_name" : "ian",
      "indices" : [ 0, 4 ],
      "id_str" : "259",
      "id" : 259
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "223638682685550592",
  "geo" : {
  },
  "id_str" : "223638994758541312",
  "in_reply_to_user_id" : 259,
  "text" : "@ian It\u2019s the fonts that really bug me. I assume they\u2019ll fix it soon and then I\u2019ll switch back.",
  "id" : 223638994758541312,
  "in_reply_to_status_id" : 223638682685550592,
  "created_at" : "Fri Jul 13 04:44:26 +0000 2012",
  "in_reply_to_screen_name" : "ian",
  "in_reply_to_user_id_str" : "259",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aimee",
      "screen_name" : "LilHossler",
      "indices" : [ 0, 11 ],
      "id_str" : "123116307",
      "id" : 123116307
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "223629802966487040",
  "geo" : {
  },
  "id_str" : "223638192736317441",
  "in_reply_to_user_id" : 123116307,
  "text" : "@LilHossler 2.6. But I thought the choice was between 2.6 and 2.7?",
  "id" : 223638192736317441,
  "in_reply_to_status_id" : 223629802966487040,
  "created_at" : "Fri Jul 13 04:41:14 +0000 2012",
  "in_reply_to_screen_name" : "LilHossler",
  "in_reply_to_user_id_str" : "123116307",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "223638003011170305",
  "text" : "Wow Chrome really looks terrible on the new Retina display.",
  "id" : 223638003011170305,
  "created_at" : "Fri Jul 13 04:40:29 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "223629289634021377",
  "text" : "I\u2019ve decided not to import all the crap from my previous MacBook onto this new one. Using Dropbox instead. And being picky about apps.",
  "id" : 223629289634021377,
  "created_at" : "Fri Jul 13 04:05:52 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 58 ],
      "url" : "http://t.co/0f5bzS7n",
      "expanded_url" : "http://flic.kr/p/cw3oZG",
      "display_url" : "flic.kr/p/cw3oZG"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.608666, -122.306167 ]
  },
  "id_str" : "223628966521614336",
  "text" : "8:36pm Got my new retina MacBook Pro! http://t.co/0f5bzS7n",
  "id" : 223628966521614336,
  "created_at" : "Fri Jul 13 04:04:35 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ingopixel",
      "screen_name" : "ingopixel",
      "indices" : [ 3, 13 ],
      "id_str" : "7943892",
      "id" : 7943892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 133 ],
      "url" : "http://t.co/qhtSmkhw",
      "expanded_url" : "http://jezebel.com/5925186/how-to-make-a-rape-joke",
      "display_url" : "jezebel.com/5925186/how-to\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "223499830117408770",
  "text" : "RT @ingopixel: Required reading for any person who ever said a thing to make another person laugh. So. Everyone. http://t.co/qhtSmkhw",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 98, 118 ],
        "url" : "http://t.co/qhtSmkhw",
        "expanded_url" : "http://jezebel.com/5925186/how-to-make-a-rape-joke",
        "display_url" : "jezebel.com/5925186/how-to\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "223496106020052992",
    "text" : "Required reading for any person who ever said a thing to make another person laugh. So. Everyone. http://t.co/qhtSmkhw",
    "id" : 223496106020052992,
    "created_at" : "Thu Jul 12 19:16:38 +0000 2012",
    "user" : {
      "name" : "ingopixel",
      "screen_name" : "ingopixel",
      "protected" : false,
      "id_str" : "7943892",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3340386384/2d7c3a3726c459f4621182f7f221dca5_normal.jpeg",
      "id" : 7943892,
      "verified" : false
    }
  },
  "id" : 223499830117408770,
  "created_at" : "Thu Jul 12 19:31:26 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emilio Ramirez",
      "screen_name" : "e_ramirez",
      "indices" : [ 0, 10 ],
      "id_str" : "1273564632",
      "id" : 1273564632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "223448460119113728",
  "geo" : {
  },
  "id_str" : "223451435843600385",
  "in_reply_to_user_id" : 21135674,
  "text" : "@e_ramirez Thank you, Ernesto.",
  "id" : 223451435843600385,
  "in_reply_to_status_id" : 223448460119113728,
  "created_at" : "Thu Jul 12 16:19:08 +0000 2012",
  "in_reply_to_screen_name" : "eramirez",
  "in_reply_to_user_id_str" : "21135674",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 47 ],
      "url" : "http://t.co/brUHcFST",
      "expanded_url" : "http://bit.ly/KUfWO0",
      "display_url" : "bit.ly/KUfWO0"
    }, {
      "indices" : [ 54, 74 ],
      "url" : "http://t.co/fPwSrzvF",
      "expanded_url" : "http://bit.ly/Nk3vfg",
      "display_url" : "bit.ly/Nk3vfg"
    } ]
  },
  "geo" : {
  },
  "id_str" : "223451251776569344",
  "text" : "First post on my new ducky http://t.co/brUHcFST blog: http://t.co/fPwSrzvF",
  "id" : 223451251776569344,
  "created_at" : "Thu Jul 12 16:18:24 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Otir",
      "screen_name" : "angelwingsweb",
      "indices" : [ 0, 14 ],
      "id_str" : "236176051",
      "id" : 236176051
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "223431340832464896",
  "geo" : {
  },
  "id_str" : "223433247705665536",
  "in_reply_to_user_id" : 236176051,
  "text" : "@angelwingsweb No that\u2019s not my domain but if you search Google for pocket mod you\u2019ll probably find the right instructions.",
  "id" : 223433247705665536,
  "in_reply_to_status_id" : 223431340832464896,
  "created_at" : "Thu Jul 12 15:06:52 +0000 2012",
  "in_reply_to_screen_name" : "angelwingsweb",
  "in_reply_to_user_id_str" : "236176051",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "twilio",
      "screen_name" : "twilio",
      "indices" : [ 17, 24 ],
      "id_str" : "15936194",
      "id" : 15936194
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 123 ],
      "url" : "http://t.co/Ue9rRB1U",
      "expanded_url" : "http://bit.ly/OA3wsh",
      "display_url" : "bit.ly/OA3wsh"
    } ]
  },
  "geo" : {
  },
  "id_str" : "223427076877856768",
  "text" : "Awesome news! RT @twilio: SMS Everywhere: Twilio Now Enables Messaging to over 150 Countries Worldwide http://t.co/Ue9rRB1U",
  "id" : 223427076877856768,
  "created_at" : "Thu Jul 12 14:42:20 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "IFTF",
      "screen_name" : "iftf",
      "indices" : [ 3, 8 ],
      "id_str" : "14620544",
      "id" : 14620544
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "InternetHuman",
      "indices" : [ 76, 90 ]
    } ],
    "urls" : [ {
      "indices" : [ 55, 75 ],
      "url" : "http://t.co/LZ4cBypL",
      "expanded_url" : "http://www.extremetech.com/extreme/126843-think-gps-is-cool-ips-will-blow-your-mind",
      "display_url" : "extremetech.com/extreme/126843\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "223426183797288961",
  "text" : "RT @iftf: Think GPS is cool? IPS will blow your mind - http://t.co/LZ4cBypL #InternetHuman",
  "retweeted_status" : {
    "source" : "<a href=\"http://www.tweetdeck.com\" rel=\"nofollow\">TweetDeck</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "InternetHuman",
        "indices" : [ 66, 80 ]
      } ],
      "urls" : [ {
        "indices" : [ 45, 65 ],
        "url" : "http://t.co/LZ4cBypL",
        "expanded_url" : "http://www.extremetech.com/extreme/126843-think-gps-is-cool-ips-will-blow-your-mind",
        "display_url" : "extremetech.com/extreme/126843\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "223418357381210112",
    "text" : "Think GPS is cool? IPS will blow your mind - http://t.co/LZ4cBypL #InternetHuman",
    "id" : 223418357381210112,
    "created_at" : "Thu Jul 12 14:07:41 +0000 2012",
    "user" : {
      "name" : "IFTF",
      "screen_name" : "iftf",
      "protected" : false,
      "id_str" : "14620544",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3496025091/51e55928594eb40d5610bce931749672_normal.png",
      "id" : 14620544,
      "verified" : false
    }
  },
  "id" : 223426183797288961,
  "created_at" : "Thu Jul 12 14:38:47 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ash bhoopathy",
      "screen_name" : "ashbhoopathy",
      "indices" : [ 0, 13 ],
      "id_str" : "19888257",
      "id" : 19888257
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "223301158704394240",
  "geo" : {
  },
  "id_str" : "223301963956236288",
  "in_reply_to_user_id" : 19888257,
  "text" : "@ashbhoopathy Thank you! Yeah, it's a bummer but is part of the deal that I signed up for. And yeah, Svbtle is pretty cool.",
  "id" : 223301963956236288,
  "in_reply_to_status_id" : 223301158704394240,
  "created_at" : "Thu Jul 12 06:25:11 +0000 2012",
  "in_reply_to_screen_name" : "ashbhoopathy",
  "in_reply_to_user_id_str" : "19888257",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andre Torrez",
      "screen_name" : "torrez",
      "indices" : [ 0, 7 ],
      "id_str" : "11604",
      "id" : 11604
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 52 ],
      "url" : "http://t.co/nS6REHi7",
      "expanded_url" : "http://thenounproject.com",
      "display_url" : "thenounproject.com"
    }, {
      "indices" : [ 73, 93 ],
      "url" : "http://t.co/J4zurvyC",
      "expanded_url" : "http://colourlovers.com",
      "display_url" : "colourlovers.com"
    } ]
  },
  "in_reply_to_status_id_str" : "223300545300008961",
  "geo" : {
  },
  "id_str" : "223300705597931520",
  "in_reply_to_user_id" : 11604,
  "text" : "@torrez You pick your logo from http://t.co/nS6REHi7 and your color from http://t.co/J4zurvyC. Pretty clever way to do it!",
  "id" : 223300705597931520,
  "in_reply_to_status_id" : 223300545300008961,
  "created_at" : "Thu Jul 12 06:20:11 +0000 2012",
  "in_reply_to_screen_name" : "torrez",
  "in_reply_to_user_id_str" : "11604",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 33 ],
      "url" : "http://t.co/SpjyBjZP",
      "expanded_url" : "http://svbtle.com",
      "display_url" : "svbtle.com"
    }, {
      "indices" : [ 40, 60 ],
      "url" : "http://t.co/bBJaraQw",
      "expanded_url" : "http://wayoftheduck.com",
      "display_url" : "wayoftheduck.com"
    } ]
  },
  "geo" : {
  },
  "id_str" : "223299537589116929",
  "text" : "Look! My new http://t.co/SpjyBjZP blog: http://t.co/bBJaraQw",
  "id" : 223299537589116929,
  "created_at" : "Thu Jul 12 06:15:33 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http://t.co/brUHcFST",
      "expanded_url" : "http://bit.ly/KUfWO0",
      "display_url" : "bit.ly/KUfWO0"
    } ]
  },
  "geo" : {
  },
  "id_str" : "223276596952436736",
  "text" : "Stoked to have an invite to http://t.co/brUHcFST.",
  "id" : 223276596952436736,
  "created_at" : "Thu Jul 12 04:44:23 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Strogatz",
      "screen_name" : "stevenstrogatz",
      "indices" : [ 3, 18 ],
      "id_str" : "579299426",
      "id" : 579299426
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "223264566912614400",
  "text" : "RT @stevenstrogatz: Here are two words with all the vowels in order: Facetiously &amp; Abstemiously. Any others?",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "223256732447678465",
    "text" : "Here are two words with all the vowels in order: Facetiously &amp; Abstemiously. Any others?",
    "id" : 223256732447678465,
    "created_at" : "Thu Jul 12 03:25:27 +0000 2012",
    "user" : {
      "name" : "Steven Strogatz",
      "screen_name" : "stevenstrogatz",
      "protected" : false,
      "id_str" : "579299426",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/2220536257/fence_normal.jpeg",
      "id" : 579299426,
      "verified" : false
    }
  },
  "id" : 223264566912614400,
  "created_at" : "Thu Jul 12 03:56:35 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 62 ],
      "url" : "http://t.co/fjEmz47k",
      "expanded_url" : "http://flic.kr/p/cvvnh5",
      "display_url" : "flic.kr/p/cvvnh5"
    } ]
  },
  "geo" : {
  },
  "id_str" : "223261132511645696",
  "text" : "8:36pm Just Eatery'd this in the backyard http://t.co/fjEmz47k",
  "id" : 223261132511645696,
  "created_at" : "Thu Jul 12 03:42:56 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 73 ],
      "url" : "http://t.co/oLKXAQDp",
      "expanded_url" : "http://www.youtube.com/watch?v=nuuyx0fpGt8",
      "display_url" : "youtube.com/watch?v=nuuyx0\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "223241943788949504",
  "text" : "Niko's version of \"If you're happy and you know it\": http://t.co/oLKXAQDp",
  "id" : 223241943788949504,
  "created_at" : "Thu Jul 12 02:26:41 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 95 ],
      "url" : "http://t.co/jyBoZnp0",
      "expanded_url" : "http://flic.kr/p/cuWAhf",
      "display_url" : "flic.kr/p/cuWAhf"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.598833, -122.324167 ]
  },
  "id_str" : "222897601220050946",
  "text" : "8:36pm Cracking up at Patrick's in-between reader banter at Salon of Shame http://t.co/jyBoZnp0",
  "id" : 222897601220050946,
  "created_at" : "Wed Jul 11 03:38:24 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 72 ],
      "url" : "http://t.co/eRR23DEl",
      "expanded_url" : "http://4sq.com/NkE8su",
      "display_url" : "4sq.com/NkE8su"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.598913, -122.324055 ]
  },
  "id_str" : "222888851054665729",
  "text" : "Salon of Shame! (@ Theatre Off Jackson w/ 9 others) http://t.co/eRR23DEl",
  "id" : 222888851054665729,
  "created_at" : "Wed Jul 11 03:03:37 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/download/iphone\" rel=\"nofollow\">Twitter for iPhone</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jimmy James Hall",
      "screen_name" : "JimmyJameson",
      "indices" : [ 0, 13 ],
      "id_str" : "35141809",
      "id" : 35141809
    }, {
      "name" : "chris jones",
      "screen_name" : "cjlikearockstar",
      "indices" : [ 14, 30 ],
      "id_str" : "34383091",
      "id" : 34383091
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "222787780730822656",
  "geo" : {
  },
  "id_str" : "222879961193783296",
  "in_reply_to_user_id" : 35141809,
  "text" : "@JimmyJameson @cjlikearockstar I think I can commit to that! Need to double check.",
  "id" : 222879961193783296,
  "in_reply_to_status_id" : 222787780730822656,
  "created_at" : "Wed Jul 11 02:28:18 +0000 2012",
  "in_reply_to_screen_name" : "JimmyJameson",
  "in_reply_to_user_id_str" : "35141809",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "222715440185618432",
  "text" : "Ooh\u2026 my MacBook Pro w/ Retina is finally preparing for shipment!",
  "id" : 222715440185618432,
  "created_at" : "Tue Jul 10 15:34:33 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "New Object",
      "screen_name" : "newobject",
      "indices" : [ 0, 10 ],
      "id_str" : "115230056",
      "id" : 115230056
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "222575870005612545",
  "geo" : {
  },
  "id_str" : "222576964656046081",
  "in_reply_to_user_id" : 115230056,
  "text" : "@newobject Healio.",
  "id" : 222576964656046081,
  "in_reply_to_status_id" : 222575870005612545,
  "created_at" : "Tue Jul 10 06:24:18 +0000 2012",
  "in_reply_to_screen_name" : "newobject",
  "in_reply_to_user_id_str" : "115230056",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyler LePard",
      "screen_name" : "tylepard",
      "indices" : [ 0, 9 ],
      "id_str" : "18297300",
      "id" : 18297300
    }, {
      "name" : "Loren Drummond",
      "screen_name" : "girlonfoot",
      "indices" : [ 10, 21 ],
      "id_str" : "16407047",
      "id" : 16407047
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "222546790082285568",
  "geo" : {
  },
  "id_str" : "222548160831176704",
  "in_reply_to_user_id" : 18297300,
  "text" : "@tylepard @girlonfoot It was Healio\u2019s tahini veggie bowl that made me feel sick\u2026",
  "id" : 222548160831176704,
  "in_reply_to_status_id" : 222546790082285568,
  "created_at" : "Tue Jul 10 04:29:50 +0000 2012",
  "in_reply_to_screen_name" : "tylepard",
  "in_reply_to_user_id_str" : "18297300",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyler LePard",
      "screen_name" : "tylepard",
      "indices" : [ 0, 9 ],
      "id_str" : "18297300",
      "id" : 18297300
    }, {
      "name" : "Loren Drummond",
      "screen_name" : "girlonfoot",
      "indices" : [ 10, 21 ],
      "id_str" : "16407047",
      "id" : 16407047
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "222546790082285568",
  "geo" : {
  },
  "id_str" : "222547278697738240",
  "in_reply_to_user_id" : 18297300,
  "text" : "@tylepard @girlonfoot I\u2019m very serious!",
  "id" : 222547278697738240,
  "in_reply_to_status_id" : 222546790082285568,
  "created_at" : "Tue Jul 10 04:26:20 +0000 2012",
  "in_reply_to_screen_name" : "tylepard",
  "in_reply_to_user_id_str" : "18297300",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 78 ],
      "url" : "http://t.co/mWIR8SuZ",
      "expanded_url" : "http://flic.kr/p/cukHzy",
      "display_url" : "flic.kr/p/cukHzy"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.608666, -122.306167 ]
  },
  "id_str" : "222540637793288192",
  "text" : "8:36pm Tried a new vegan restaurant and now feel nauseous http://t.co/mWIR8SuZ",
  "id" : 222540637793288192,
  "created_at" : "Tue Jul 10 03:59:57 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "222540141993000961",
  "text" : "What\u2019s a good relaxing iPhone game I should get?",
  "id" : 222540141993000961,
  "created_at" : "Tue Jul 10 03:57:59 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Waxy.org Links Feed",
      "screen_name" : "waxylinks",
      "indices" : [ 3, 13 ],
      "id_str" : "219952089",
      "id" : 219952089
    }, {
      "name" : "At Reply",
      "screen_name" : "reply",
      "indices" : [ 51, 57 ],
      "id_str" : "130584275",
      "id" : 130584275
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "222469690348404737",
  "text" : "RT @waxylinks: Rabble digs into the history of the @reply on Twitter: using Kellan's oldtweets, a searchable archive of Twitter... http: ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitterfeed.com\" rel=\"nofollow\">twitterfeed</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "At Reply",
        "screen_name" : "reply",
        "indices" : [ 36, 42 ],
        "id_str" : "130584275",
        "id" : 130584275
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 136 ],
        "url" : "http://t.co/OuaWY04h",
        "expanded_url" : "http://bit.ly/PIdvCc",
        "display_url" : "bit.ly/PIdvCc"
      } ]
    },
    "geo" : {
    },
    "id_str" : "222467893827338240",
    "text" : "Rabble digs into the history of the @reply on Twitter: using Kellan's oldtweets, a searchable archive of Twitter... http://t.co/OuaWY04h",
    "id" : 222467893827338240,
    "created_at" : "Mon Jul 09 23:10:53 +0000 2012",
    "user" : {
      "name" : "Waxy.org Links Feed",
      "screen_name" : "waxylinks",
      "protected" : false,
      "id_str" : "219952089",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1175952227/Screen_shot_2010-11-26_at_11.48.43_normal.png",
      "id" : 219952089,
      "verified" : false
    }
  },
  "id" : 222469690348404737,
  "created_at" : "Mon Jul 09 23:18:02 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Micah Baldwin",
      "screen_name" : "micah",
      "indices" : [ 26, 32 ],
      "id_str" : "5469512",
      "id" : 5469512
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 104 ],
      "url" : "http://t.co/UUlGQL7G",
      "expanded_url" : "http://bit.ly/ROtZGd",
      "display_url" : "bit.ly/ROtZGd"
    } ]
  },
  "geo" : {
  },
  "id_str" : "222360574397394944",
  "text" : "Pretty high apparently RT @micah: What\u2019s the probability we live in the Matrix now? http://t.co/UUlGQL7G",
  "id" : 222360574397394944,
  "created_at" : "Mon Jul 09 16:04:26 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tikva Morowati",
      "screen_name" : "tikkers",
      "indices" : [ 0, 8 ],
      "id_str" : "1054551",
      "id" : 1054551
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "222197390365573120",
  "geo" : {
  },
  "id_str" : "222197724907450369",
  "in_reply_to_user_id" : 1054551,
  "text" : "@tikkers Yeah haven\u2019t gotten to that section yet. :)",
  "id" : 222197724907450369,
  "in_reply_to_status_id" : 222197390365573120,
  "created_at" : "Mon Jul 09 05:17:20 +0000 2012",
  "in_reply_to_screen_name" : "tikkers",
  "in_reply_to_user_id_str" : "1054551",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "222195390202646528",
  "text" : "Ducks bear no grudges.",
  "id" : 222195390202646528,
  "created_at" : "Mon Jul 09 05:08:03 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin McGillivray",
      "screen_name" : "kev_mcg",
      "indices" : [ 0, 8 ],
      "id_str" : "108109409",
      "id" : 108109409
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "222193011558318080",
  "geo" : {
  },
  "id_str" : "222193133327368192",
  "in_reply_to_user_id" : 108109409,
  "text" : "@kev_mcg You're welcome!",
  "id" : 222193133327368192,
  "in_reply_to_status_id" : 222193011558318080,
  "created_at" : "Mon Jul 09 04:59:05 +0000 2012",
  "in_reply_to_screen_name" : "kev_mcg",
  "in_reply_to_user_id_str" : "108109409",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http://t.co/zYbfN0wJ",
      "expanded_url" : "http://bustr.me/post/26813501615/what-were-really-doing-when-we-attempt-to-achieve",
      "display_url" : "bustr.me/post/268135016\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "222191888776708096",
  "text" : "\"The desire for security and the feeling of insecurity are the same thing. To hold your breath is to lose your breath.\" http://t.co/zYbfN0wJ",
  "id" : 222191888776708096,
  "created_at" : "Mon Jul 09 04:54:09 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 77 ],
      "url" : "http://t.co/k7oX0lLM",
      "expanded_url" : "http://flic.kr/p/ctDTpC",
      "display_url" : "flic.kr/p/ctDTpC"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.608666, -122.306 ]
  },
  "id_str" : "222173274564599808",
  "text" : "8:36pm Reading while Niko learns to float in the bathtub http://t.co/k7oX0lLM",
  "id" : 222173274564599808,
  "created_at" : "Mon Jul 09 03:40:11 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "222153199010848768",
  "text" : "\u201CThe more you try to avoid suffering, the more you suffer, because more insignificant things begin to torture you.\u201D - The Antidote pg 135",
  "id" : 222153199010848768,
  "created_at" : "Mon Jul 09 02:20:24 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kellan",
      "screen_name" : "kellan",
      "indices" : [ 128, 135 ],
      "id_str" : "47",
      "id" : 47
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 122 ],
      "url" : "http://t.co/4FzM10Cu",
      "expanded_url" : "http://kellan.io/oldtweets?q=userid%3Abusterbenson&search=Search",
      "display_url" : "kellan.io/oldtweets?q=us\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "222141808052944896",
  "text" : "I'm not positive that these are my oldest tweets, but they're at least grandpa age in Internet Years: http://t.co/4FzM10Cu /thx @kellan",
  "id" : 222141808052944896,
  "created_at" : "Mon Jul 09 01:35:08 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "chris jones",
      "screen_name" : "cjlikearockstar",
      "indices" : [ 0, 16 ],
      "id_str" : "34383091",
      "id" : 34383091
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "222128188619366400",
  "geo" : {
  },
  "id_str" : "222130311193047040",
  "in_reply_to_user_id" : 34383091,
  "text" : "@cjlikearockstar Yeah cheese and ice cream have been making me ignore the obvious for years.",
  "id" : 222130311193047040,
  "in_reply_to_status_id" : 222128188619366400,
  "created_at" : "Mon Jul 09 00:49:27 +0000 2012",
  "in_reply_to_screen_name" : "cjlikearockstar",
  "in_reply_to_user_id_str" : "34383091",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tara Tiger Brown",
      "screen_name" : "tara",
      "indices" : [ 31, 36 ],
      "id_str" : "10959642",
      "id" : 10959642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http://t.co/DT5cAmEX",
      "expanded_url" : "http://nyti.ms/RJhHim",
      "display_url" : "nyti.ms/RJhHim"
    } ]
  },
  "geo" : {
  },
  "id_str" : "222127732618821632",
  "text" : "I\u2019m pretty much over dairy. RT @tara: \u201CGot Milk? You Don\u2019t Need It\u201D FYI: 50M people in the US are lactose intolerant. http://t.co/DT5cAmEX",
  "id" : 222127732618821632,
  "created_at" : "Mon Jul 09 00:39:13 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NYT Obituaries",
      "screen_name" : "NYTObits",
      "indices" : [ 17, 26 ],
      "id_str" : "16929470",
      "id" : 16929470
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "obitoftheday",
      "indices" : [ 0, 13 ]
    } ],
    "urls" : [ {
      "indices" : [ 68, 88 ],
      "url" : "http://t.co/ejMPer17",
      "expanded_url" : "http://bit.ly/LXnIHe",
      "display_url" : "bit.ly/LXnIHe"
    } ]
  },
  "geo" : {
  },
  "id_str" : "222119140809379840",
  "text" : "#obitoftheday RT @NYTObits: Daphne Zepos, Cheese Expert, Dies at 52 http://t.co/ejMPer17",
  "id" : 222119140809379840,
  "created_at" : "Mon Jul 09 00:05:04 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 97 ],
      "url" : "http://t.co/LMxlI78M",
      "expanded_url" : "http://4sq.com/N9Trmc",
      "display_url" : "4sq.com/N9Trmc"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.615071, -122.354059 ]
  },
  "id_str" : "222109152086994944",
  "text" : "Choospotting a day early because he couldn't wait. (@ Old Spaghetti Factory) http://t.co/LMxlI78M",
  "id" : 222109152086994944,
  "created_at" : "Sun Jul 08 23:25:23 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jimmy James Hall",
      "screen_name" : "JimmyJameson",
      "indices" : [ 0, 13 ],
      "id_str" : "35141809",
      "id" : 35141809
    }, {
      "name" : "chris jones",
      "screen_name" : "cjlikearockstar",
      "indices" : [ 14, 30 ],
      "id_str" : "34383091",
      "id" : 34383091
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "222078651074744320",
  "geo" : {
  },
  "id_str" : "222080321099808770",
  "in_reply_to_user_id" : 35141809,
  "text" : "@JimmyJameson @cjlikearockstar I've been busy this last couple weeks too but that should be clearing up soon! Let's hang out!",
  "id" : 222080321099808770,
  "in_reply_to_status_id" : 222078651074744320,
  "created_at" : "Sun Jul 08 21:30:49 +0000 2012",
  "in_reply_to_screen_name" : "JimmyJameson",
  "in_reply_to_user_id_str" : "35141809",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Massive Health",
      "screen_name" : "massivehealth",
      "indices" : [ 28, 42 ],
      "id_str" : "224938017",
      "id" : 224938017
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "222062511195832320",
  "text" : "I\u2019m getting back into using @massivehealth\u2019s Eatery app\u2026 it\u2019s pretty great. Anyone else using it?",
  "id" : 222062511195832320,
  "created_at" : "Sun Jul 08 20:20:03 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave McClure",
      "screen_name" : "davemcclure",
      "indices" : [ 128, 140 ],
      "id_str" : "1081",
      "id" : 1081
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 123 ],
      "url" : "http://t.co/7m48TTyY",
      "expanded_url" : "http://500hats.com/late-bloomer",
      "display_url" : "500hats.com/late-bloomer"
    } ]
  },
  "geo" : {
  },
  "id_str" : "222029358729150465",
  "text" : "\"Most of the time I think of myself as a failure. When I'm optimistic I think I'm just a late bloomer\" http://t.co/7m48TTyY /by @davemcclure",
  "id" : 222029358729150465,
  "created_at" : "Sun Jul 08 18:08:18 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Lieber",
      "screen_name" : "AllTom",
      "indices" : [ 0, 7 ],
      "id_str" : "1017201",
      "id" : 1017201
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 45 ],
      "url" : "http://t.co/7m48TTyY",
      "expanded_url" : "http://500hats.com/late-bloomer",
      "display_url" : "500hats.com/late-bloomer"
    } ]
  },
  "in_reply_to_status_id_str" : "222025524430635008",
  "geo" : {
  },
  "id_str" : "222029187614121985",
  "in_reply_to_user_id" : 1017201,
  "text" : "@AllTom Oops, wrong url: http://t.co/7m48TTyY :)",
  "id" : 222029187614121985,
  "in_reply_to_status_id" : 222025524430635008,
  "created_at" : "Sun Jul 08 18:07:38 +0000 2012",
  "in_reply_to_screen_name" : "AllTom",
  "in_reply_to_user_id_str" : "1017201",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 53 ],
      "url" : "http://t.co/8DL9oDi5",
      "expanded_url" : "http://flic.kr/p/csWfJo",
      "display_url" : "flic.kr/p/csWfJo"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.608666, -122.306 ]
  },
  "id_str" : "221811081646055425",
  "text" : "8:36pm Looking out from bathtime http://t.co/8DL9oDi5",
  "id" : 221811081646055425,
  "created_at" : "Sun Jul 08 03:40:57 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http://t.co/Bvs1LcUy",
      "expanded_url" : "http://instagr.am/p/MzaaMTI0AD/",
      "display_url" : "instagr.am/p/MzaaMTI0AD/"
    } ]
  },
  "geo" : {
  },
  "id_str" : "221795017335902209",
  "text" : "Eating the bird http://t.co/Bvs1LcUy",
  "id" : 221795017335902209,
  "created_at" : "Sun Jul 08 02:37:07 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 69 ],
      "url" : "http://t.co/d09xYyDd",
      "expanded_url" : "http://instagr.am/p/MzZQ4lI0PI/",
      "display_url" : "instagr.am/p/MzZQ4lI0PI/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6170123598, -122.319116592 ]
  },
  "id_str" : "221792376883134464",
  "text" : "Jungle park baby badminton   @ Cal Anderson Park http://t.co/d09xYyDd",
  "id" : 221792376883134464,
  "created_at" : "Sun Jul 08 02:26:38 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Cook",
      "screen_name" : "johnhcook",
      "indices" : [ 3, 13 ],
      "id_str" : "14326765",
      "id" : 14326765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 85 ],
      "url" : "http://t.co/9VKYs6SD",
      "expanded_url" : "http://www.geekwire.com/2012/report-yep-amazon-making-smartphone/",
      "display_url" : "geekwire.com/2012/report-ye\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "221702368952188928",
  "text" : "RT @johnhcook: Report: Yep, Amazon is making its own smartphone: http://t.co/9VKYs6SD",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 50, 70 ],
        "url" : "http://t.co/9VKYs6SD",
        "expanded_url" : "http://www.geekwire.com/2012/report-yep-amazon-making-smartphone/",
        "display_url" : "geekwire.com/2012/report-ye\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "221266483756531715",
    "text" : "Report: Yep, Amazon is making its own smartphone: http://t.co/9VKYs6SD",
    "id" : 221266483756531715,
    "created_at" : "Fri Jul 06 15:36:55 +0000 2012",
    "user" : {
      "name" : "John Cook",
      "screen_name" : "johnhcook",
      "protected" : false,
      "id_str" : "14326765",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/403089484/john-headshot_normal.jpg",
      "id" : 14326765,
      "verified" : false
    }
  },
  "id" : 221702368952188928,
  "created_at" : "Sat Jul 07 20:28:58 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Coates",
      "screen_name" : "tomcoates",
      "indices" : [ 3, 13 ],
      "id_str" : "12514",
      "id" : 12514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "221698629495304193",
  "text" : "RT @tomcoates: Apparently dolphins might communicate by sending echo-location like noise pictures of objects to each other. Which is awe ...",
  "retweeted_status" : {
    "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "221693396241219584",
    "text" : "Apparently dolphins might communicate by sending echo-location like noise pictures of objects to each other. Which is awesome.",
    "id" : 221693396241219584,
    "created_at" : "Sat Jul 07 19:53:19 +0000 2012",
    "user" : {
      "name" : "Tom Coates",
      "screen_name" : "tomcoates",
      "protected" : false,
      "id_str" : "12514",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1212320564/Screen_shot_2011-01-10_at_4.24.33_PM_normal.png",
      "id" : 12514,
      "verified" : false
    }
  },
  "id" : 221698629495304193,
  "created_at" : "Sat Jul 07 20:14:06 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robin Sloan",
      "screen_name" : "robinsloan",
      "indices" : [ 16, 27 ],
      "id_str" : "13919072",
      "id" : 13919072
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 137 ],
      "url" : "http://t.co/9ubP871b",
      "expanded_url" : "http://bit.ly/L0yNTP",
      "display_url" : "bit.ly/L0yNTP"
    } ]
  },
  "geo" : {
  },
  "id_str" : "221696417465499648",
  "text" : "This is big! RT @robinsloan: Perfect use for Twitter's new search: find out what your peeps think about a new movie. http://t.co/9ubP871b",
  "id" : 221696417465499648,
  "created_at" : "Sat Jul 07 20:05:19 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diana Kimball",
      "screen_name" : "dianakimball",
      "indices" : [ 6, 19 ],
      "id_str" : "14471007",
      "id" : 14471007
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 132 ],
      "url" : "http://t.co/lmpZ54HC",
      "expanded_url" : "http://blog.dianakimball.com/post/26707936522",
      "display_url" : "blog.dianakimball.com/post/267079365\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "221670794298785793",
  "text" : "Look! @dianakimball is reading the entirety of \"The Information\" by James Gleick in 1 day and live-tweeting it: http://t.co/lmpZ54HC",
  "id" : 221670794298785793,
  "created_at" : "Sat Jul 07 18:23:30 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diana Kimball",
      "screen_name" : "dianakimball",
      "indices" : [ 0, 13 ],
      "id_str" : "14471007",
      "id" : 14471007
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "221658202419363841",
  "geo" : {
  },
  "id_str" : "221666340820357121",
  "in_reply_to_user_id" : 14471007,
  "text" : "@dianakimball I totally love that you're doing this! I wish there was a RunKeeper-like app that let us follow your reading in real time.",
  "id" : 221666340820357121,
  "in_reply_to_status_id" : 221658202419363841,
  "created_at" : "Sat Jul 07 18:05:48 +0000 2012",
  "in_reply_to_screen_name" : "dianakimball",
  "in_reply_to_user_id_str" : "14471007",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "web",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diana Kimball",
      "screen_name" : "dianakimball",
      "indices" : [ 0, 13 ],
      "id_str" : "14471007",
      "id" : 14471007
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "221635991407042560",
  "geo" : {
  },
  "id_str" : "221666024137818113",
  "in_reply_to_user_id" : 14471007,
  "text" : "@dianakimball I read G\u00F6del, Escher, Bach years ago but it is still one of my favorites ever.",
  "id" : 221666024137818113,
  "in_reply_to_status_id" : 221635991407042560,
  "created_at" : "Sat Jul 07 18:04:33 +0000 2012",
  "in_reply_to_screen_name" : "dianakimball",
  "in_reply_to_user_id_str" : "14471007",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 75 ],
      "url" : "http://t.co/HfViHYMM",
      "expanded_url" : "http://bustr.me/post/26703115535/the-feeling-of-feeling-like-it-or-not",
      "display_url" : "bustr.me/post/267031155\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "221644488274219008",
  "text" : "Playing with the feeling of \"feeling like it\" (or not) http://t.co/HfViHYMM",
  "id" : 221644488274219008,
  "created_at" : "Sat Jul 07 16:38:58 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Al Ibrahim",
      "screen_name" : "FailedImitator",
      "indices" : [ 0, 15 ],
      "id_str" : "14210174",
      "id" : 14210174
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "221635711344967680",
  "geo" : {
  },
  "id_str" : "221636007987122177",
  "in_reply_to_user_id" : 14210174,
  "text" : "@FailedImitator There isn't, yet, primarily for that reason. Typing 750 words is going to be tedious on a phone\u2026",
  "id" : 221636007987122177,
  "in_reply_to_status_id" : 221635711344967680,
  "created_at" : "Sat Jul 07 16:05:16 +0000 2012",
  "in_reply_to_screen_name" : "FailedImitator",
  "in_reply_to_user_id_str" : "14210174",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 50 ],
      "url" : "http://t.co/GE3PtvM9",
      "expanded_url" : "http://flic.kr/p/cspero",
      "display_url" : "flic.kr/p/cspero"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.6085, -122.306 ]
  },
  "id_str" : "221471691560321024",
  "text" : "8:36pm Being boring and tired http://t.co/GE3PtvM9",
  "id" : 221471691560321024,
  "created_at" : "Sat Jul 07 05:12:20 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "221426583280435201",
  "text" : "It cracks me up how many disclaimers and follow-ups Ira Glass now feels compelled to provide whenever someone else tells a story.",
  "id" : 221426583280435201,
  "created_at" : "Sat Jul 07 02:13:06 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rhiannon Llewellyn",
      "screen_name" : "rhiannon_z",
      "indices" : [ 0, 11 ],
      "id_str" : "796155",
      "id" : 796155
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "221413806725795840",
  "geo" : {
  },
  "id_str" : "221414018361999361",
  "in_reply_to_user_id" : 796155,
  "text" : "@rhiannon_z Nope. :)",
  "id" : 221414018361999361,
  "in_reply_to_status_id" : 221413806725795840,
  "created_at" : "Sat Jul 07 01:23:10 +0000 2012",
  "in_reply_to_screen_name" : "rhiannon_z",
  "in_reply_to_user_id_str" : "796155",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "221413624470716416",
  "text" : "You\u2019ve got tweets.",
  "id" : 221413624470716416,
  "created_at" : "Sat Jul 07 01:21:36 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Veronica Belmont",
      "screen_name" : "Veronica",
      "indices" : [ 3, 12 ],
      "id_str" : "10350",
      "id" : 10350
    }, {
      "name" : "io9",
      "screen_name" : "io9",
      "indices" : [ 84, 88 ],
      "id_str" : "13215132",
      "id" : 13215132
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 109 ],
      "url" : "http://t.co/Kj5zdOQY",
      "expanded_url" : "http://io9.com/5923828/dont-worry-people--nasa-has-a-plan-for-moving-the-earth",
      "display_url" : "io9.com/5923828/dont-w\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "221401782264406018",
  "text" : "RT @Veronica: Phew! \"Don't worry, people! NASA has a plan for moving the Earth\" via @io9 http://t.co/Kj5zdOQY",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "io9",
        "screen_name" : "io9",
        "indices" : [ 70, 74 ],
        "id_str" : "13215132",
        "id" : 13215132
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 75, 95 ],
        "url" : "http://t.co/Kj5zdOQY",
        "expanded_url" : "http://io9.com/5923828/dont-worry-people--nasa-has-a-plan-for-moving-the-earth",
        "display_url" : "io9.com/5923828/dont-w\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "221396277705981954",
    "text" : "Phew! \"Don't worry, people! NASA has a plan for moving the Earth\" via @io9 http://t.co/Kj5zdOQY",
    "id" : 221396277705981954,
    "created_at" : "Sat Jul 07 00:12:40 +0000 2012",
    "user" : {
      "name" : "Veronica Belmont",
      "screen_name" : "Veronica",
      "protected" : false,
      "id_str" : "10350",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3567013392/8fd5e6ee5524d211c764547b829f4399_normal.jpeg",
      "id" : 10350,
      "verified" : true
    }
  },
  "id" : 221401782264406018,
  "created_at" : "Sat Jul 07 00:34:32 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Derek Thornton",
      "screen_name" : "thorntonderek",
      "indices" : [ 0, 14 ],
      "id_str" : "243778873",
      "id" : 243778873
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "221384199188381696",
  "geo" : {
  },
  "id_str" : "221387954797559808",
  "in_reply_to_user_id" : 243778873,
  "text" : "@thorntonderek Hm\u2026 let's say turning off your alarm is okay but you can't launch any apps until you drink your water.",
  "id" : 221387954797559808,
  "in_reply_to_status_id" : 221384199188381696,
  "created_at" : "Fri Jul 06 23:39:36 +0000 2012",
  "in_reply_to_screen_name" : "thorntonderek",
  "in_reply_to_user_id_str" : "243778873",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Schoonover",
      "screen_name" : "billschoonover",
      "indices" : [ 0, 15 ],
      "id_str" : "15652883",
      "id" : 15652883
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "221376964517310466",
  "geo" : {
  },
  "id_str" : "221379676864651264",
  "in_reply_to_user_id" : 15652883,
  "text" : "@billschoonover No, drink 2 big glasses of water.  Then coffee!  :)",
  "id" : 221379676864651264,
  "in_reply_to_status_id" : 221376964517310466,
  "created_at" : "Fri Jul 06 23:06:42 +0000 2012",
  "in_reply_to_screen_name" : "billschoonover",
  "in_reply_to_user_id_str" : "15652883",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "IFTTT",
      "screen_name" : "IFTTT",
      "indices" : [ 0, 6 ],
      "id_str" : "75079616",
      "id" : 75079616
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "221373496041811970",
  "geo" : {
  },
  "id_str" : "221374847425589248",
  "in_reply_to_user_id" : 75079616,
  "text" : "@IFTTT Oooh!  Please let me be a beta tester!  :)",
  "id" : 221374847425589248,
  "in_reply_to_status_id" : 221373496041811970,
  "created_at" : "Fri Jul 06 22:47:31 +0000 2012",
  "in_reply_to_screen_name" : "IFTTT",
  "in_reply_to_user_id_str" : "75079616",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "IFTTT",
      "screen_name" : "IFTTT",
      "indices" : [ 0, 6 ],
      "id_str" : "75079616",
      "id" : 75079616
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "221368418908114944",
  "geo" : {
  },
  "id_str" : "221372035270586369",
  "in_reply_to_user_id" : 75079616,
  "text" : "@IFTTT Just looking for ways to integrate with you without asking to become an official channel.  Generic webhooks would also work!",
  "id" : 221372035270586369,
  "in_reply_to_status_id" : 221368418908114944,
  "created_at" : "Fri Jul 06 22:36:20 +0000 2012",
  "in_reply_to_screen_name" : "IFTTT",
  "in_reply_to_user_id_str" : "75079616",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "IFTTT",
      "screen_name" : "IFTTT",
      "indices" : [ 0, 6 ],
      "id_str" : "75079616",
      "id" : 75079616
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "221367173208219648",
  "in_reply_to_user_id" : 75079616,
  "text" : "@IFTTT Ideally it would come from the address verified by your email channel. Would allow small sites to play nice with you.",
  "id" : 221367173208219648,
  "created_at" : "Fri Jul 06 22:17:01 +0000 2012",
  "in_reply_to_screen_name" : "IFTTT",
  "in_reply_to_user_id_str" : "75079616",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "IFTTT",
      "screen_name" : "IFTTT",
      "indices" : [ 0, 6 ],
      "id_str" : "75079616",
      "id" : 75079616
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "221366785738424321",
  "in_reply_to_user_id" : 75079616,
  "text" : "@IFTTT Any plans to allow recipe actions to email any address?",
  "id" : 221366785738424321,
  "created_at" : "Fri Jul 06 22:15:29 +0000 2012",
  "in_reply_to_screen_name" : "IFTTT",
  "in_reply_to_user_id_str" : "75079616",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Owen Thomas",
      "screen_name" : "owenthomas",
      "indices" : [ 12, 23 ],
      "id_str" : "3034251",
      "id" : 3034251
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 106 ],
      "url" : "http://t.co/0NthoO1q",
      "expanded_url" : "http://bit.ly/MGwonf",
      "display_url" : "bit.ly/MGwonf"
    } ]
  },
  "geo" : {
  },
  "id_str" : "221325061032910849",
  "text" : "Awesome! RT @owenthomas: Finally, you can search among your friends' tweets. FINALLY! http://t.co/0NthoO1q",
  "id" : 221325061032910849,
  "created_at" : "Fri Jul 06 19:29:41 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "221323085981298689",
  "text" : "New habit challenge: don\u2019t look at your phone in the morning until you drink 2 glasses of water. Add more steps after 7 days. Are you in?",
  "id" : 221323085981298689,
  "created_at" : "Fri Jul 06 19:21:50 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"https://path.com/\" rel=\"nofollow\">Path</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NikeFuel",
      "screen_name" : "NikeFuel",
      "indices" : [ 3, 12 ],
      "id_str" : "466807381",
      "id" : 466807381
    }, {
      "name" : "Path",
      "screen_name" : "path",
      "indices" : [ 37, 42 ],
      "id_str" : "106333951",
      "id" : 106333951
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "221279361062551552",
  "text" : "My @nikefuel stats only showed up in @path once when I first connected. Anyone else having trouble with it?",
  "id" : 221279361062551552,
  "created_at" : "Fri Jul 06 16:28:05 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 120 ],
      "url" : "http://t.co/nRN5zFgQ",
      "expanded_url" : "http://bbc.in/MaqAPg",
      "display_url" : "bbc.in/MaqAPg"
    } ]
  },
  "geo" : {
  },
  "id_str" : "221274983798804482",
  "text" : "Still don\u2019t know what a Higgs Field or Higgs Boson is? This explanation is really good (and funny): http://t.co/nRN5zFgQ",
  "id" : 221274983798804482,
  "created_at" : "Fri Jul 06 16:10:41 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 94 ],
      "url" : "http://t.co/sPtlPgJO",
      "expanded_url" : "http://idealab.talkingpointsmemo.com/2012/07/maple-seed-drones-will-swarm-the-future.php",
      "display_url" : "idealab.talkingpointsmemo.com/2012/07/maple-\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "221266117245673472",
  "text" : "Cheap, small, drones shaped like maple seeds with 360 degree video feeds. http://t.co/sPtlPgJO",
  "id" : 221266117245673472,
  "created_at" : "Fri Jul 06 15:35:27 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Seth Webster \u24CB",
      "screen_name" : "sethwebster",
      "indices" : [ 0, 12 ],
      "id_str" : "14573883",
      "id" : 14573883
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "221085995943206913",
  "geo" : {
  },
  "id_str" : "221086103741018112",
  "in_reply_to_user_id" : 14573883,
  "text" : "@sethwebster \u201Cdiapers!\u201D",
  "id" : 221086103741018112,
  "in_reply_to_status_id" : 221085995943206913,
  "created_at" : "Fri Jul 06 03:40:09 +0000 2012",
  "in_reply_to_screen_name" : "sethwebster",
  "in_reply_to_user_id_str" : "14573883",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Niko Benson",
      "screen_name" : "nikobenson",
      "indices" : [ 38, 49 ],
      "id_str" : "142467448",
      "id" : 142467448
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 79 ],
      "url" : "http://t.co/ybUuIKP9",
      "expanded_url" : "http://instagr.am/p/MuXwLGo0G5/",
      "display_url" : "instagr.am/p/MuXwLGo0G5/"
    } ]
  },
  "geo" : {
  },
  "id_str" : "221085304071782400",
  "text" : "8:36pm Hidden message from daycare on @nikobenson's diaper http://t.co/ybUuIKP9",
  "id" : 221085304071782400,
  "created_at" : "Fri Jul 06 03:36:58 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "atheists",
      "indices" : [ 23, 32 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "221061359998210048",
  "text" : "RT @randeezydogge: Hey #atheists!! Guess who created you're beloved Higgs-Boson \"God particle\"??? God!! To bad you are to dumb too see t ...",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "atheists",
        "indices" : [ 4, 13 ]
      }, {
        "text" : "atheism",
        "indices" : [ 123, 131 ]
      }, {
        "text" : "atheist",
        "indices" : [ 132, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "221010870384345088",
    "text" : "Hey #atheists!! Guess who created you're beloved Higgs-Boson \"God particle\"??? God!! To bad you are to dumb too see that!! #atheism #atheist",
    "id" : 221010870384345088,
    "created_at" : "Thu Jul 05 22:41:12 +0000 2012",
    "user" : {
      "name" : "Steve Job's",
      "screen_name" : "chiIIdog",
      "protected" : false,
      "id_str" : "31208130",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000081232806/f158dd96c23cfec99d1e1d5d6b3ecb2c_normal.jpeg",
      "id" : 31208130,
      "verified" : false
    }
  },
  "id" : 221061359998210048,
  "created_at" : "Fri Jul 06 02:01:50 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 76 ],
      "url" : "http://t.co/0Aey8ZbR",
      "expanded_url" : "http://blog.stephenwolfram.com/2012/07/a-moment-for-particle-physics-the-end-of-a-40-year-story/",
      "display_url" : "blog.stephenwolfram.com/2012/07/a-mome\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "220984526661361664",
  "text" : "Thank you, Stephen Wolfram, for writing this blog post: http://t.co/0Aey8ZbR",
  "id" : 220984526661361664,
  "created_at" : "Thu Jul 05 20:56:31 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Maria Popova",
      "screen_name" : "brainpicker",
      "indices" : [ 126, 138 ],
      "id_str" : "9207632",
      "id" : 9207632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 120 ],
      "url" : "http://t.co/fQDnuSeP",
      "expanded_url" : "http://j.mp/PiHUqv",
      "display_url" : "j.mp/PiHUqv"
    } ]
  },
  "geo" : {
  },
  "id_str" : "220977221370785792",
  "text" : "I haven't seen a review this glowing in a while. Added \"Where The Heart Beats\" to top of read pile: http://t.co/fQDnuSeP /via @brainpicker",
  "id" : 220977221370785792,
  "created_at" : "Thu Jul 05 20:27:29 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://mobile.twitter.com\" rel=\"nofollow\">Mobile Web</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anil Dash",
      "screen_name" : "anildash",
      "indices" : [ 13, 22 ],
      "id_str" : "36823",
      "id" : 36823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 106 ],
      "url" : "http://t.co/1r7AE2ye",
      "expanded_url" : "http://2.dashes.com/O9Gs3r",
      "display_url" : "2.dashes.com/O9Gs3r"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.622427321, -122.3356951683 ]
  },
  "id_str" : "220959456371032065",
  "text" : "Right on! RT @anildash: Let's choose our apps based on how obsessed the creators are: http://t.co/1r7AE2ye",
  "id" : 220959456371032065,
  "created_at" : "Thu Jul 05 19:16:54 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Morris",
      "screen_name" : "mozbloke",
      "indices" : [ 0, 9 ],
      "id_str" : "15280028",
      "id" : 15280028
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "220922891171151872",
  "geo" : {
  },
  "id_str" : "220923593343770624",
  "in_reply_to_user_id" : 15280028,
  "text" : "@mozbloke Thank you for trying it out!",
  "id" : 220923593343770624,
  "in_reply_to_status_id" : 220922891171151872,
  "created_at" : "Thu Jul 05 16:54:23 +0000 2012",
  "in_reply_to_screen_name" : "mozbloke",
  "in_reply_to_user_id_str" : "15280028",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Kathleen Peck",
      "screen_name" : "sarahkpeck",
      "indices" : [ 3, 14 ],
      "id_str" : "196745496",
      "id" : 196745496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 80 ],
      "url" : "http://t.co/Yi0BhTjf",
      "expanded_url" : "http://itstartswith.com/2012/07/how-to-live/",
      "display_url" : "itstartswith.com/2012/07/how-to\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "220910591404032000",
  "text" : "RT @sarahkpeck: Life checklist? How about a life LIVE list? http://t.co/Yi0BhTjf",
  "retweeted_status" : {
    "source" : "web",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 44, 64 ],
        "url" : "http://t.co/Yi0BhTjf",
        "expanded_url" : "http://itstartswith.com/2012/07/how-to-live/",
        "display_url" : "itstartswith.com/2012/07/how-to\u2026"
      } ]
    },
    "geo" : {
    },
    "id_str" : "220236789481353216",
    "text" : "Life checklist? How about a life LIVE list? http://t.co/Yi0BhTjf",
    "id" : 220236789481353216,
    "created_at" : "Tue Jul 03 19:25:17 +0000 2012",
    "user" : {
      "name" : "Sarah Kathleen Peck",
      "screen_name" : "sarahkpeck",
      "protected" : false,
      "id_str" : "196745496",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/3459962896/4d0b50de5c22e42a4113858dfeef8814_normal.jpeg",
      "id" : 196745496,
      "verified" : false
    }
  },
  "id" : 220910591404032000,
  "created_at" : "Thu Jul 05 16:02:43 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 81 ],
      "url" : "http://t.co/sbn99D7o",
      "expanded_url" : "http://flic.kr/p/crdCmj",
      "display_url" : "flic.kr/p/crdCmj"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 39.858666, -104.672334 ]
  },
  "id_str" : "220707296110575616",
  "text" : "8:36pm Denver -&gt; Seattle, missing parties and family time http://t.co/sbn99D7o",
  "id" : 220707296110575616,
  "created_at" : "Thu Jul 05 02:34:54 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Bold Academy",
      "screen_name" : "BoldAcademy",
      "indices" : [ 34, 46 ],
      "id_str" : "502177948",
      "id" : 502177948
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "boldacademy",
      "indices" : [ 126, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 125 ],
      "url" : "http://t.co/KTIgbHr6",
      "expanded_url" : "http://bit.ly/M780HO",
      "display_url" : "bit.ly/M780HO"
    } ]
  },
  "geo" : {
  },
  "id_str" : "220699324676440066",
  "text" : "These are truly awesome people RT @BoldAcademy: Snapshots from the first three days of The Bold Academy: http://t.co/KTIgbHr6 #boldacademy",
  "id" : 220699324676440066,
  "created_at" : "Thu Jul 05 02:03:14 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Pierre ",
      "screen_name" : "peacelovejp",
      "indices" : [ 8, 20 ],
      "id_str" : "177614242",
      "id" : 177614242
    }, {
      "name" : "The Bold Academy",
      "screen_name" : "BoldAcademy",
      "indices" : [ 120, 132 ],
      "id_str" : "502177948",
      "id" : 502177948
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "220696721901096960",
  "text" : "I think @peacelovejp provided the straw-breaking-camel\u2019s-back argument for me today that dairy is gross to the max. /cc @BoldAcademy",
  "id" : 220696721901096960,
  "created_at" : "Thu Jul 05 01:52:53 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://leapfor.it\" rel=\"nofollow\">Leap Application</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leap",
      "screen_name" : "leap",
      "indices" : [ 51, 56 ],
      "id_str" : "257098055",
      "id" : 257098055
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "leapchallenge",
      "indices" : [ 33, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 114 ],
      "url" : "http://t.co/Dw7F6rSG",
      "expanded_url" : "http://leapfor.it/c/g2n",
      "display_url" : "leapfor.it/c/g2n"
    } ]
  },
  "geo" : {
  },
  "id_str" : "220683027746000896",
  "text" : "Just created the Eat Half Plants #leapchallenge on @leap. Anyone can join in. Come take me on http://t.co/Dw7F6rSG",
  "id" : 220683027746000896,
  "created_at" : "Thu Jul 05 00:58:28 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Antonio Neves",
      "screen_name" : "TheAntonioNeves",
      "indices" : [ 0, 16 ],
      "id_str" : "20932488",
      "id" : 20932488
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "220560902104158211",
  "geo" : {
  },
  "id_str" : "220678277969358848",
  "in_reply_to_user_id" : 20932488,
  "text" : "@TheAntonioNeves Thank you, Tony. I had such a blast.",
  "id" : 220678277969358848,
  "in_reply_to_status_id" : 220560902104158211,
  "created_at" : "Thu Jul 05 00:39:36 +0000 2012",
  "in_reply_to_screen_name" : "TheAntonioNeves",
  "in_reply_to_user_id_str" : "20932488",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shrutarshi Basu",
      "screen_name" : "basus",
      "indices" : [ 0, 6 ],
      "id_str" : "9469312",
      "id" : 9469312
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "220572723678683136",
  "geo" : {
  },
  "id_str" : "220678090567860225",
  "in_reply_to_user_id" : 9469312,
  "text" : "@basus Yeah, on the account page you can export everything in a text file.",
  "id" : 220678090567860225,
  "in_reply_to_status_id" : 220572723678683136,
  "created_at" : "Thu Jul 05 00:38:51 +0000 2012",
  "in_reply_to_screen_name" : "basus",
  "in_reply_to_user_id_str" : "9469312",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 125 ],
      "url" : "http://t.co/osKCvclw",
      "expanded_url" : "http://4sq.com/Nn86e9",
      "display_url" : "4sq.com/Nn86e9"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 39.8519728928, -104.673743248 ]
  },
  "id_str" : "220674660986126337",
  "text" : "It was nice of them to keep the airport open for me. (@ Denver International Airport (DEN) w/ 67 others) http://t.co/osKCvclw",
  "id" : 220674660986126337,
  "created_at" : "Thu Jul 05 00:25:13 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 75 ],
      "url" : "http://t.co/s6da3YiY",
      "expanded_url" : "http://4sq.com/MxEU7M",
      "display_url" : "4sq.com/MxEU7M"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.006797, -105.277759 ]
  },
  "id_str" : "220595502817869826",
  "text" : "Did my talk! Super amazing people here. (@ Bold Manor) http://t.co/s6da3YiY",
  "id" : 220595502817869826,
  "created_at" : "Wed Jul 04 19:10:40 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tumblr.com/\" rel=\"nofollow\">Tumblr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http://t.co/7di4R6IM",
      "expanded_url" : "http://tmblr.co/ZQJvayOgzWrY",
      "display_url" : "tmblr.co/ZQJvayOgzWrY"
    } ]
  },
  "geo" : {
  },
  "id_str" : "220517581415645185",
  "text" : "The Hybrid Age: http://t.co/7di4R6IM",
  "id" : 220517581415645185,
  "created_at" : "Wed Jul 04 14:01:03 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 86 ],
      "url" : "http://t.co/aBsJGdhl",
      "expanded_url" : "http://flic.kr/p/cqGqZj",
      "display_url" : "flic.kr/p/cqGqZj"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 40.007, -105.277834 ]
  },
  "id_str" : "220400734032764928",
  "text" : "8:36pm In my Bold room reading and preparing for my talk tomorrow http://t.co/aBsJGdhl",
  "id" : 220400734032764928,
  "created_at" : "Wed Jul 04 06:16:44 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 103 ],
      "url" : "http://t.co/XLrwdQMT",
      "expanded_url" : "http://4sq.com/M4EoLm",
      "display_url" : "4sq.com/M4EoLm"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 39.8519728928, -104.673743248 ]
  },
  "id_str" : "220255929323634689",
  "text" : "Hello, Denver! It's warm here. (@ Denver International Airport (DEN) w/ 73 others) http://t.co/XLrwdQMT",
  "id" : 220255929323634689,
  "created_at" : "Tue Jul 03 20:41:20 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "April Schiller",
      "screen_name" : "the_april",
      "indices" : [ 0, 10 ],
      "id_str" : "16644937",
      "id" : 16644937
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "220201051448549379",
  "geo" : {
  },
  "id_str" : "220205574250438658",
  "in_reply_to_user_id" : 16644937,
  "text" : "@the_april Oops, I can\u2019t watch it on my phone so will try again at a computer.",
  "id" : 220205574250438658,
  "in_reply_to_status_id" : 220201051448549379,
  "created_at" : "Tue Jul 03 17:21:14 +0000 2012",
  "in_reply_to_screen_name" : "the_april",
  "in_reply_to_user_id_str" : "16644937",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Maggie Mason",
      "screen_name" : "Maggie",
      "indices" : [ 0, 7 ],
      "id_str" : "448",
      "id" : 448
    }, {
      "name" : "Oliver Burkeman",
      "screen_name" : "oliverburkeman",
      "indices" : [ 115, 130 ],
      "id_str" : "112037009",
      "id" : 112037009
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "220204738673778689",
  "geo" : {
  },
  "id_str" : "220205323523325952",
  "in_reply_to_user_id" : 448,
  "text" : "@Maggie I\u2019m taking the negative path to happiness! (while reading The Antidote which is sorta blowing my mind) /cc @oliverburkeman",
  "id" : 220205323523325952,
  "in_reply_to_status_id" : 220204738673778689,
  "created_at" : "Tue Jul 03 17:20:15 +0000 2012",
  "in_reply_to_screen_name" : "Maggie",
  "in_reply_to_user_id_str" : "448",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://foursquare.com\" rel=\"nofollow\">foursquare</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Bold Academy",
      "screen_name" : "BoldAcademy",
      "indices" : [ 35, 47 ],
      "id_str" : "502177948",
      "id" : 502177948
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http://t.co/qivvgtb3",
      "expanded_url" : "http://4sq.com/P6Q592",
      "display_url" : "4sq.com/P6Q592"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.4436465828, -122.3025941849 ]
  },
  "id_str" : "220204749671247873",
  "text" : "Seattle -&gt; Denver for 2 days at @boldacademy. Excited! (@ Seattle-Tacoma International Airport (SEA) w/ 63 others) http://t.co/qivvgtb3",
  "id" : 220204749671247873,
  "created_at" : "Tue Jul 03 17:17:58 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Katsen",
      "screen_name" : "pavtalk",
      "indices" : [ 0, 8 ],
      "id_str" : "237133992",
      "id" : 237133992
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 64 ],
      "url" : "http://t.co/Bb1p0svp",
      "expanded_url" : "http://bit.ly/NxOJUj",
      "display_url" : "bit.ly/NxOJUj"
    } ]
  },
  "in_reply_to_status_id_str" : "220189379757477889",
  "geo" : {
  },
  "id_str" : "220194808617111553",
  "in_reply_to_user_id" : 237133992,
  "text" : "@pavtalk Thanks! If you like that check out http://t.co/Bb1p0svp as well and let me know what you think.",
  "id" : 220194808617111553,
  "in_reply_to_status_id" : 220189379757477889,
  "created_at" : "Tue Jul 03 16:38:28 +0000 2012",
  "in_reply_to_screen_name" : "pavtalk",
  "in_reply_to_user_id_str" : "237133992",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cheers",
      "indices" : [ 29, 36 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "220194531545591808",
  "text" : "Remember you and I will die. #cheers",
  "id" : 220194531545591808,
  "created_at" : "Tue Jul 03 16:37:21 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 37 ],
      "url" : "http://t.co/a5CBr7Tr",
      "expanded_url" : "http://instagr.am/p/MmqtSuI0Fg/",
      "display_url" : "instagr.am/p/MmqtSuI0Fg/"
    } ]
  },
  "geo" : {
  },
  "id_str" : "220001309070344192",
  "text" : "8:36pm \"No nap.\" http://t.co/a5CBr7Tr",
  "id" : 220001309070344192,
  "created_at" : "Tue Jul 03 03:49:34 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Azumio Inc.",
      "screen_name" : "azumioinc",
      "indices" : [ 3, 13 ],
      "id_str" : "252827423",
      "id" : 252827423
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "stress",
      "indices" : [ 40, 47 ]
    } ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "219966048554852352",
  "text" : "RT @azumioinc: How do you moderate your #stress and what advice would you give to others?",
  "retweeted_status" : {
    "source" : "<a href=\"http://sproutsocial.com\" rel=\"nofollow\">Sprout Social</a>",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "stress",
        "indices" : [ 25, 32 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
    },
    "id_str" : "219965935740649473",
    "text" : "How do you moderate your #stress and what advice would you give to others?",
    "id" : 219965935740649473,
    "created_at" : "Tue Jul 03 01:29:00 +0000 2012",
    "user" : {
      "name" : "Azumio Inc.",
      "screen_name" : "azumioinc",
      "protected" : false,
      "id_str" : "252827423",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1638992066/twitter_azumio_500x500_normal.png",
      "id" : 252827423,
      "verified" : false
    }
  },
  "id" : 219966048554852352,
  "created_at" : "Tue Jul 03 01:29:27 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://www.tumblr.com/\" rel=\"nofollow\">Tumblr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 110 ],
      "url" : "http://t.co/TsCTGLYA",
      "expanded_url" : "http://tmblr.co/ZQJvayOYSE-0",
      "display_url" : "tmblr.co/ZQJvayOYSE-0"
    } ]
  },
  "geo" : {
  },
  "id_str" : "219807906843987968",
  "text" : "Reading the obits in the morning is my favorite new habit. Here's how you can try it too: http://t.co/TsCTGLYA",
  "id" : 219807906843987968,
  "created_at" : "Mon Jul 02 15:01:03 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://tapbots.com/tweetbot\" rel=\"nofollow\">Tweetbot for iOS</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles Duhigg",
      "screen_name" : "cduhigg",
      "indices" : [ 3, 11 ],
      "id_str" : "20570290",
      "id" : 20570290
    }, {
      "name" : "Brain Pickings",
      "screen_name" : "brainpickings",
      "indices" : [ 83, 97 ],
      "id_str" : "79783264",
      "id" : 79783264
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 77 ],
      "url" : "http://t.co/u15qGEnR",
      "expanded_url" : "http://bit.ly/ObBxCD",
      "display_url" : "bit.ly/ObBxCD"
    } ]
  },
  "geo" : {
  },
  "id_str" : "219772812917866496",
  "text" : "RT @cduhigg: The Science of Waiting and the Art of Delay http://t.co/u15qGEnR from @brainpickings",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitterfeed.com\" rel=\"nofollow\">twitterfeed</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Brain Pickings",
        "screen_name" : "brainpickings",
        "indices" : [ 70, 84 ],
        "id_str" : "79783264",
        "id" : 79783264
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 44, 64 ],
        "url" : "http://t.co/u15qGEnR",
        "expanded_url" : "http://bit.ly/ObBxCD",
        "display_url" : "bit.ly/ObBxCD"
      } ]
    },
    "geo" : {
    },
    "id_str" : "219747862119071744",
    "text" : "The Science of Waiting and the Art of Delay http://t.co/u15qGEnR from @brainpickings",
    "id" : 219747862119071744,
    "created_at" : "Mon Jul 02 11:02:27 +0000 2012",
    "user" : {
      "name" : "Charles Duhigg",
      "screen_name" : "cduhigg",
      "protected" : false,
      "id_str" : "20570290",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/79455504/topics_duhigg_190_normal.jpg",
      "id" : 20570290,
      "verified" : true
    }
  },
  "id" : 219772812917866496,
  "created_at" : "Mon Jul 02 12:41:36 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://instagram.com\" rel=\"nofollow\">Instagram</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http://t.co/m0Mju09H",
      "expanded_url" : "http://instagr.am/p/MkM_EtI0Ny/",
      "display_url" : "instagr.am/p/MkM_EtI0Ny/"
    } ]
  },
  "geo" : {
  },
  "id_str" : "219654223539863552",
  "text" : "List of things  http://t.co/m0Mju09H",
  "id" : 219654223539863552,
  "created_at" : "Mon Jul 02 04:50:22 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://simplymeasured.com\" rel=\"nofollow\">Simply Measured</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Simply Measured",
      "screen_name" : "simplymeasured",
      "indices" : [ 12, 27 ],
      "id_str" : "92162698",
      "id" : 92162698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 90 ],
      "url" : "http://t.co/5kjEdQHJ",
      "expanded_url" : "http://bit.ly/owpX5r",
      "display_url" : "bit.ly/owpX5r"
    } ]
  },
  "geo" : {
  },
  "id_str" : "219651104626057217",
  "text" : "I just used @simplymeasured to analyze my Twitter followers in Excel. http://t.co/5kjEdQHJ",
  "id" : 219651104626057217,
  "created_at" : "Mon Jul 02 04:37:58 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "elise b",
      "screen_name" : "meditatecreate",
      "indices" : [ 0, 15 ],
      "id_str" : "274385610",
      "id" : 274385610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "219639176818212865",
  "geo" : {
  },
  "id_str" : "219639610807029760",
  "in_reply_to_user_id" : 274385610,
  "text" : "@meditatecreate Thank you! Unfortunately not\u2026 will you take some notes for me?",
  "id" : 219639610807029760,
  "in_reply_to_status_id" : 219639176818212865,
  "created_at" : "Mon Jul 02 03:52:18 +0000 2012",
  "in_reply_to_screen_name" : "meditatecreate",
  "in_reply_to_user_id_str" : "274385610",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://flickr.com/services/twitter/\" rel=\"nofollow\">Flickr</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 69 ],
      "url" : "http://t.co/TLhs83Si",
      "expanded_url" : "http://flic.kr/p/cpnsyf",
      "display_url" : "flic.kr/p/cpnsyf"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 47.608666, -122.306167 ]
  },
  "id_str" : "219638593902215168",
  "text" : "8:36pm Laughing about friends with broken gaydar http://t.co/TLhs83Si",
  "id" : 219638593902215168,
  "created_at" : "Mon Jul 02 03:48:16 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nir Eyal",
      "screen_name" : "nireyal",
      "indices" : [ 0, 8 ],
      "id_str" : "14097392",
      "id" : 14097392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "219589418657382401",
  "geo" : {
  },
  "id_str" : "219590758641049601",
  "in_reply_to_user_id" : 14097392,
  "text" : "@nireyal Sure thing. Definitely got my thoughts moving around today, thanks for putting it together.",
  "id" : 219590758641049601,
  "in_reply_to_status_id" : 219589418657382401,
  "created_at" : "Mon Jul 02 00:38:11 +0000 2012",
  "in_reply_to_screen_name" : "nireyal",
  "in_reply_to_user_id_str" : "14097392",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brad Feld",
      "screen_name" : "bfeld",
      "indices" : [ 3, 9 ],
      "id_str" : "3754891",
      "id" : 3754891
    }, {
      "name" : "The Guardian",
      "screen_name" : "guardian",
      "indices" : [ 77, 86 ],
      "id_str" : "87818409",
      "id" : 87818409
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 72 ],
      "url" : "http://t.co/rIzISJxs",
      "expanded_url" : "http://gu.com/p/38k7e/tw",
      "display_url" : "gu.com/p/38k7e/tw"
    } ]
  },
  "geo" : {
  },
  "id_str" : "219587840173031424",
  "text" : "RT @bfeld: Apple's patent absurdity exposed at last http://t.co/rIzISJxs via @guardian",
  "retweeted_status" : {
    "source" : "<a href=\"http://twitter.com/tweetbutton\" rel=\"nofollow\">Tweet Button</a>",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Guardian",
        "screen_name" : "guardian",
        "indices" : [ 66, 75 ],
        "id_str" : "87818409",
        "id" : 87818409
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 41, 61 ],
        "url" : "http://t.co/rIzISJxs",
        "expanded_url" : "http://gu.com/p/38k7e/tw",
        "display_url" : "gu.com/p/38k7e/tw"
      } ]
    },
    "geo" : {
    },
    "id_str" : "219586657987469312",
    "text" : "Apple's patent absurdity exposed at last http://t.co/rIzISJxs via @guardian",
    "id" : 219586657987469312,
    "created_at" : "Mon Jul 02 00:21:53 +0000 2012",
    "user" : {
      "name" : "Brad Feld",
      "screen_name" : "bfeld",
      "protected" : false,
      "id_str" : "3754891",
      "profile_image_url_https" : "https://si0.twimg.com/profile_images/1779442552/image1327462410_normal.png",
      "id" : 3754891,
      "verified" : true
    }
  },
  "id" : 219587840173031424,
  "created_at" : "Mon Jul 02 00:26:35 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 103 ],
      "url" : "http://t.co/ayAROzfX",
      "expanded_url" : "http://opinionator.blogs.nytimes.com/2012/06/30/the-busy-trap/",
      "display_url" : "opinionator.blogs.nytimes.com/2012/06/30/the\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "219585660410015745",
  "text" : "\"Busyness serves as a kind of existential reassurance, a hedge against emptiness.\" http://t.co/ayAROzfX",
  "id" : 219585660410015745,
  "created_at" : "Mon Jul 02 00:17:55 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 135 ],
      "url" : "http://t.co/pkr1FYjK",
      "expanded_url" : "http://techcrunch.com/2012/07/01/the-art-of-manipulation/",
      "display_url" : "techcrunch.com/2012/07/01/the\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "219575944585805826",
  "text" : "The Art of Manipulation: \"The matrix seeks to help you answer not, 'Can I hook users?' but 'Should I attempt to?'\" http://t.co/pkr1FYjK",
  "id" : 219575944585805826,
  "created_at" : "Sun Jul 01 23:39:19 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emma Welles",
      "screen_name" : "emmarocks",
      "indices" : [ 7, 17 ],
      "id_str" : "766566",
      "id" : 766566
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : {
  },
  "id_str" : "219575265142124544",
  "text" : "Um\u2026 RT @emmarocks: What did you do with your extra second today?",
  "id" : 219575265142124544,
  "created_at" : "Sun Jul 01 23:36:37 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kai Davis",
      "screen_name" : "kaisdavis",
      "indices" : [ 0, 10 ],
      "id_str" : "63337932",
      "id" : 63337932
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 34 ],
      "url" : "http://t.co/rGqF5BZV",
      "expanded_url" : "http://everydayfortherestofmylife.com",
      "display_url" : "everydayfortherestofmylife.com"
    } ]
  },
  "in_reply_to_status_id_str" : "219572627625345024",
  "geo" : {
  },
  "id_str" : "219573245953847296",
  "in_reply_to_user_id" : 63337932,
  "text" : "@kaisdavis On http://t.co/rGqF5BZV I recommend setting a monthly alarm for that stuff.",
  "id" : 219573245953847296,
  "in_reply_to_status_id" : 219572627625345024,
  "created_at" : "Sun Jul 01 23:28:35 +0000 2012",
  "in_reply_to_screen_name" : "kaisdavis",
  "in_reply_to_user_id_str" : "63337932",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 107 ],
      "url" : "https://t.co/swnHuoCE",
      "expanded_url" : "https://www.fontfont.com/how-to-use-ff-chartwell",
      "display_url" : "fontfont.com/how-to-use-ff-\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "219568842433769472",
  "text" : "FF Chartwell is a font that you can use to make all kinds of charts. Neat and pretty. https://t.co/swnHuoCE",
  "id" : 219568842433769472,
  "created_at" : "Sun Jul 01 23:11:06 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rob Long",
      "screen_name" : "rcbl",
      "indices" : [ 17, 22 ],
      "id_str" : "4902931",
      "id" : 4902931
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "obitoftheday",
      "indices" : [ 0, 13 ]
    } ],
    "urls" : [ {
      "indices" : [ 46, 66 ],
      "url" : "http://t.co/XFzKlrH9",
      "expanded_url" : "http://www.telegraph.co.uk/news/obituaries/9365640/Count-Robert-de-La-Rochefoucauld.html",
      "display_url" : "telegraph.co.uk/news/obituarie\u2026"
    } ]
  },
  "geo" : {
  },
  "id_str" : "219531559169032194",
  "text" : "#obitoftheday RT @rcbl: Best. Obituary. Ever. http://t.co/XFzKlrH9",
  "id" : 219531559169032194,
  "created_at" : "Sun Jul 01 20:42:57 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
}, {
  "source" : "<a href=\"http://itunes.apple.com/us/app/twitter/id409789998?mt=12\" rel=\"nofollow\">Twitter for Mac</a>",
  "entities" : {
    "user_mentions" : [ {
      "name" : "gottaFeeling",
      "screen_name" : "gottafeelingApp",
      "indices" : [ 29, 45 ],
      "id_str" : "219092435",
      "id" : 219092435
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 96 ],
      "url" : "http://t.co/U4LlIgJj",
      "expanded_url" : "http://ow.ly/bWyVX",
      "display_url" : "ow.ly/bWyVX"
    } ]
  },
  "geo" : {
  },
  "id_str" : "219482668734226433",
  "text" : "Death and social networks RT @gottafeelingApp: What's uncomfortable online: http://t.co/U4LlIgJj",
  "id" : 219482668734226433,
  "created_at" : "Sun Jul 01 17:28:40 +0000 2012",
  "user" : {
    "name" : "Buster",
    "screen_name" : "buster",
    "protected" : false,
    "id_str" : "2185",
    "profile_image_url_https" : "https://si0.twimg.com/profile_images/378800000145751179/8638aaef844f12ddfa1f6687b607633b_normal.jpeg",
    "id" : 2185,
    "verified" : false
  }
} ]